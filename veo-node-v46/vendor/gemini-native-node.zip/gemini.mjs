import { readFileSync } from "node:fs";
import { readFile, stat, writeFile, mkdir, rename } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright-core";

const gemini = "https://gemini.google.com";
const responses = "model-response";
const mediaHosts = new Set(["gemini.google.com", "lh3.google.com", "lh3.googleusercontent.com"]);
const formats = ["image/png", "image/jpeg", "image/webp"];

export function imageSource(value, identified, width, height) {
  if (width < 256 || height < 256) return false;
  let url;
  try { url = new URL(value); } catch { return false; }
  if (url.protocol === "blob:") return identified && url.origin === gemini;
  if (url.protocol === "data:") return identified && /^data:image\/(png|jpeg|webp);base64,/i.test(value);
  return url.protocol === "https:" && !url.port && !url.username && !url.password &&
    mediaHosts.has(url.hostname) && (identified || /^\/(?:gg|gg-dl|rd-gg)(?:\/|$)/.test(url.pathname));
}

export function imageInstruction(prompt) {
  return "Hãy tạo và trả về một ảnh mới dựa trên mô tả dưới đây.\n\n" + prompt;
}

async function editorFor(page) {
  const editor = page.locator('rich-textarea [contenteditable="true"]:visible, .ql-editor[contenteditable="true"]:visible, [contenteditable="true"][role="textbox"]:visible').first();
  try { await editor.waitFor({state:"visible", timeout: 22000}); }
  catch { throw new Error("Không thấy ô chat. Bấm Kết nối Gemini và đăng nhập trong cửa sổ của app."); }
  return editor;
}

async function submit(page, editor, prompt) {
  const count = await page.locator(responses).count();
  await editor.fill(prompt);
  const send = page.getByRole("button", {name:/^(send( message| prompt)?|gửi( tin nhắn| lời nhắc)?)$/i})
    .or(page.locator("button.send-button")).first();
  await send.click({timeout:12000});
  return page.locator(responses).nth(count);
}

async function waitForText(page, answer) {
  await answer.waitFor({state:"visible", timeout:75000});
  const stop = page.getByRole("button", {name:/^(stop|dừng|ngừng)(\b|\s)/i}).first();
  const end = Date.now()+45000;
  let last = "", changed = Date.now();
  while (Date.now() < end) {
    const message = answer.locator("message-content, .markdown").first();
    const text = (await (await message.count() ? message : answer).innerText({timeout:4000})).trim();
    if (text !== last) { last = text; changed = Date.now(); }
    if (text && !(await stop.isVisible()) && Date.now() - changed >= 2500) return text;
    await new Promise(resolve => setTimeout(resolve, 400));
  }
  throw new Error("Gemini chưa viết xong prompt.");
}

async function waitForImage(response) {
  await response.waitFor({state:"visible",timeout:90000});
  const end = Date.now() + 120000;
  while (Date.now() < end) {
    const elements = response.locator("img");
    const images = await elements.evaluateAll(nodes => nodes.map((image, index) => ({
      index,
      url: image.currentSrc,
      identified: Boolean(image.closest("generated-image, generated-image-container, single-image, image-generation")),
      width: image.naturalWidth, height: image.naturalHeight,
    })));
    const image = images.find(item => imageSource(item.url, item.identified, item.width, item.height));
    if (image) return {...image, element: elements.nth(image.index)};
    await new Promise(resolve => setTimeout(resolve, 600));
  }
  throw new Error("Gemini chưa trả ảnh mới cho lượt này. Có thể yêu cầu chỉ nhận phản hồi văn bản.");
}

async function downloadImage(context, page, image) {
  let bytes, type;
  if (image.url.startsWith("blob:") || image.url.startsWith("data:")) {
    const result = await page.evaluate(async url => {
      const response = await fetch(url, {signal: AbortSignal.timeout(15000)});
      const type = response.headers.get("content-type")?.split(";")[0];
      const blob = await response.blob();
      if (blob.size > 24_000_000) throw Error("Ảnh quá lớn.");
      return await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve({type, data: reader.result.split(",")[1]});
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    }, image.url);
    bytes = Buffer.from(result.data, "base64");
    type = result.type;
  } else {
    const request = await context.request.get(image.url, {
      maxRedirects:0, timeout:20000, headers:{referer:gemini+"/"},
    });
    try {
      if (!request.ok()) throw new Error("Gemini hiện ảnh nhưng Studio chưa tải được file.");
      type = request.headers()["content-type"]?.split(";")[0];
      bytes = await request.body();
    } finally {
      await request.dispose();
    }
  }
  if (!formats.includes(type) || !bytes.length || bytes.length > 24_000_000) {
    throw new Error("File ảnh không hợp lệ hoặc vượt quá 24 MB.");
  }
  return bytes;
}

async function downloadFromGemini(page, answer, image) {
  await image.element.hover({timeout:5000});
  const buttonName = /download|tải xuống|tải ảnh/i;
  const figure = image.element.locator("xpath=ancestor::*[self::generated-image or self::generated-image-container or self::single-image or self::image-generation][1]");
  const downloadControl = scope => scope.getByRole("button", {name:buttonName})
    .or(scope.getByRole("link", {name:buttonName})).filter({visible:true});
  const local = downloadControl(figure);
  const control = await local.count() ? local : downloadControl(answer);
  if (await control.count() !== 1) throw new Error("Không xác định được nút tải ảnh của Gemini.");

  const pending = page.waitForEvent("download", {timeout:20000}).catch(() => null);
  try {
    await control.click({timeout:5000});
  } catch {
    // A click can trigger a download before the browser reports a navigation error.
  }
  const download = await pending;
  if (!download) throw new Error("Gemini chưa gửi file ảnh tải xuống.");
  let timeout;
  try {
    const path = await Promise.race([
      download.path(),
      new Promise((_, reject) => {
        timeout = setTimeout(() => reject(new Error("Gemini tải ảnh quá lâu.")), 15000);
      }),
    ]);
    if ((await stat(path)).size > 24_000_000) throw new Error("Ảnh vượt quá 24 MB.");
    const bytes = await readFile(path);
    const png = bytes.subarray(0, 8).toString("hex") === "89504e470d0a1a0a";
    const jpeg = bytes.subarray(0, 3).toString("hex") === "ffd8ff";
    const webp = bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP";
    if (!png && !jpeg && !webp) throw new Error("File tải xuống không phải ảnh được hỗ trợ.");
    return bytes;
  } finally {
    clearTimeout(timeout);
    await download.cancel().catch(() => {});
    await download.delete().catch(() => {});
  }
}

async function copyImagePixels(image) {
  const data = await image.element.evaluate((element, url) => {
    const {naturalWidth:width, naturalHeight:height} = element;
    if (element.currentSrc !== url || width < 256 || height < 256 || width * height > 25_000_000) {
      throw new Error("Ảnh kết quả không còn sẵn sàng.");
    }
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    canvas.getContext("2d").drawImage(element, 0, 0);
    return canvas.toDataURL("image/png").split(",", 2)[1];
  }, image.url, {timeout:5000});
  if (!data || data.length > 32_000_000) throw new Error("Ảnh vượt quá 24 MB.");
  return Buffer.from(data, "base64");
}

async function saveResult(context, page, answer, image, output) {
  const bytes = await downloadFromGemini(page, answer, image).catch(() =>
    downloadImage(context, page, image)).catch(() =>
    copyImagePixels(image)).catch(() => {
    throw new Error("Gemini đã hiện ảnh nhưng app chưa tải được file ảnh. Hãy thử lại.");
  });
  await writeFile(output, bytes, {flag:"wx"});
}

// SceneForge additions: attachments and durable receive-only receipts.
let sceneForgePhase = "connect";
async function attachReferences(page, refs = []) {
  if (!refs.length) return;
  if (refs.length > 8) throw new Error("Tối đa 8 ảnh nguồn / tham chiếu.");
  const input = page.locator("input[type=file]").first();
  if (!await input.count()) await page.getByRole("button", {name:/upload|add files|attach|tải lên|thêm tệp|đính kèm/i}).first().click({timeout:10000});
  await input.waitFor({state:"attached",timeout:10000});
  const files = refs.map((r, i) => {
    const ext = {"image/png":"png","image/jpeg":"jpg","image/webp":"webp"}[r.mime_type];
    if (!ext) throw new Error("Ảnh tham chiếu không hợp lệ.");
    return {name:`SceneForge-reference-${i+1}.${ext}`,mimeType:r.mime_type,buffer:Buffer.from(r.data,"base64")};
  });
  await input.setInputFiles(files, {timeout:30000});
  await page.waitForFunction(n => {
    const previews = [...document.querySelectorAll("user-query img,.input-area-container img,.file-preview img,.attachment-preview img,.attachment img,.preview-container img")].filter(i => i.complete && i.naturalWidth);
    const labels = [...document.querySelectorAll("[aria-label],[title]")].map(e => (e.getAttribute("aria-label")||"")+" "+(e.title||""));
    return previews.length >= n || Array.from({length:n},(_,i)=>labels.some(t=>t.includes(`SceneForge-reference-${i+1}`))).every(Boolean);
  }, files.length, {timeout:45000});
}
async function saveReceipt(request, page, context, state) {
  if (!request.receipt) return;
  const session=await context.newCDPSession(page);
  let target;
  try { target=(await session.send("Target.getTargetInfo")).targetInfo.targetId; }
  finally { await session.detach(); }
  await writeFile(request.receipt+".tmp",JSON.stringify({request_id:request.request_id,target,kind:request.action,answer:await page.locator(responses).count(),...state}));
  await rename(request.receipt+".tmp",request.receipt);
}
async function receiveExisting(context, request) {
  const turn=JSON.parse(await readFile(request.receipt,"utf8"));
  if (turn.request_id !== request.request_id || turn.kind !== "image") throw new Error("Không có lượt ảnh tương ứng; không tự tạo lại.");
  let page;
  for (const candidate of context.pages()) {
    const session=await context.newCDPSession(candidate);
    try { if ((await session.send("Target.getTargetInfo")).targetInfo.targetId===turn.target) page=candidate; }
    finally { await session.detach(); }
    if (page) break;
  }
  if (!page || new URL(page.url()).origin !== gemini) throw new Error("Tab xử lý của lượt cũ không còn; không tự tạo lại.");
  sceneForgePhase="wait_image";
  const answer=page.locator(responses).nth(turn.answer);
  const image=await waitForImage(answer);
  sceneForgePhase="download_image";
  await saveResult(context,page,answer,image,request.output);
  await page.goto("about:blank", {timeout:5000,waitUntil:"commit"}).catch(()=>{});
  return {saved:true};
}

async function run(port, request) {
  const browser = await chromium.connectOverCDP("http://127.0.0.1:" + port, {timeout:12000});
  try {
    if (request.action === "shutdown") {
      const session = await browser.newBrowserCDPSession();
      await session.send("Browser.close").catch(() => {});
      return {};
    }
    const context = browser.contexts()[0];
    if (!context) throw new Error("Không tìm thấy hồ sơ Chrome của app.");
    if (request.action === "receive") return await receiveExisting(context, request);
    const page = context.pages().find(item => item.url() === "about:blank") || await context.newPage();
    let completed=false, submitted=false;
    if (!page) throw new Error("Không tìm thấy tab xử lý nền. Hãy thoát app và mở lại.");
    try {
      await page.goto(gemini + "/app", {waitUntil:"domcontentloaded", timeout:30000});
      if (new URL(page.url()).origin !== gemini) throw new Error("Hãy hoàn tất đăng nhập bằng nút Đăng nhập Gemini.");
      const cookies = await context.cookies(gemini + "/app");
      if (!cookies.some(({name}) => name === "__Secure-1PSID")) {
        throw new Error("Chưa thấy phiên Google đã đăng nhập trong hồ sơ Gemini của app.");
      }
      sceneForgePhase="editor";
      const editor = await editorFor(page);
      if (request.action === "verify") { completed=true; return {signedIn:true}; }
      sceneForgePhase="attach_references";
      await attachReferences(page,request.references);
      if (request.action === "text") {
        await saveReceipt(request,page,context,{accepted:null});submitted=true;
        sceneForgePhase="send_text";
        const answer=await submit(page,editor,request.prompt);
        const result={text:await waitForText(page,answer)};completed=true;return result;
      }
      if (request.action === "prompt") {
        const instruction = "Viết lại mô tả dưới đây thành một prompt tạo ảnh chi tiết. Giữ nguyên ngôn ngữ, " +
          "chủ thể và ý định chính. Mô tả rõ bố cục và ánh sáng nếu phù hợp. Chỉ trả prompt.\n\n" + request.prompt;
        return {text: await waitForText(page, await submit(page, editor, instruction))};
      }
      if (request.action !== "image") throw new Error("Yêu cầu Gemini không hợp lệ.");
      sceneForgePhase="send_prompt";
      await saveReceipt(request,page,context,{accepted:null});submitted=true;
      const answer = await submit(page, editor, imageInstruction(request.prompt));
      sceneForgePhase="wait_image";
      const image = await waitForImage(answer);
      sceneForgePhase="download_image";
      await saveResult(context, page, answer, image, request.output);
      completed=true;return {saved:true};
    } finally {
      if (completed || !submitted) await page.goto("about:blank", {timeout:5000, waitUntil:"commit"}).catch(() => {});
    }
  } finally {
    await browser.close().catch(() => {});
  }
}

async function main() {
  try {
    const {port, request} = JSON.parse(readFileSync(0, "utf8"));
    if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error("Chrome chưa sẵn sàng.");
    process.stdout.write(JSON.stringify({result:await run(port, request)}));
  } catch (error) {
    const message = error.name === "TimeoutError" ? "Hết thời gian chờ Gemini." : error.message;
    process.stdout.write(JSON.stringify({error:message.split("\n")[0].slice(0,300),phase:sceneForgePhase,error_type:error.name}));
    process.exitCode = 1;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) await main();
