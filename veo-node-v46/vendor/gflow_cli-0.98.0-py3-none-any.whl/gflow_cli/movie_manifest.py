"""Movie manifest — parse and validate a movie.toml project file.

A movie.toml describes a self-contained film production: a set of named
characters (with face / body reference prompts) and an ordered list of
scenes (each specifying a generation type, prompt, and optional character
references).  The runner in :mod:`gflow_cli.cli_movie` consumes this
manifest and orchestrates ``gflow character`` + ``gflow video`` operations
automatically.

Run state is written to a sibling ``<stem>-state.json`` file so that a
crashed or interrupted run can resume without re-spending credits.
"""

from __future__ import annotations

import json
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import cast

from gflow_cli.api.video import VideoModel, validate_duration_for_model
from gflow_cli.composition import (
    FRAMING,
    Character,
    DialogueLine,
    ManifestCard,
    Scene,
    SceneInstructions,
    StyleSpec,
    resume_hash,
)
from gflow_cli.errors import ConfigurationError

__all__ = [
    "AssemblyDef",
    "CharacterState",
    "MovieManifest",
    "MovieState",
    "SceneState",
]

# Type aliases for TOML-shaped ``cast(...)`` targets. Extracted so the quoted
# cast strings are not duplicated (SonarCloud S1192); module-level aliases keep
# ruff's TC006 happy since call sites pass a bare name, not a subscript.
_TomlObj = dict[str, object]
_TomlList = list[object]

# ---------------------------------------------------------------------------
# Allowed values
# ---------------------------------------------------------------------------

_VALID_VIDEO_ASPECTS: frozenset[str] = frozenset({"9:16", "16:9", "1:1"})
_VALID_DURATIONS: frozenset[int] = frozenset(range(3, 16))
_VALID_CHARACTER_MODELS: frozenset[str] = frozenset({"nano2", "nanopro"})


# ---------------------------------------------------------------------------
# Manifest DTOs
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AssemblyDef:
    """Optional assembly step — render all scenes into one .mp4."""

    output: str | None = None


@dataclass(frozen=True)
class MovieManifest:
    """Validated, immutable representation of a movie.toml file (scene = clip)."""

    title: str
    project: str
    style: StyleSpec
    characters: dict[str, Character]  # keyed by name
    scenes: tuple[Scene, ...]
    continuity: str = "independent"
    assemble: AssemblyDef | None = None
    output_dir: str | None = None
    schema_version: int = 1
    instructions: tuple[ManifestCard, ...] = ()

    @classmethod
    def from_toml_path(cls, path: Path) -> MovieManifest:
        """Parse and validate *path*; raise :class:`ConfigurationError` on any problem."""
        if not path.exists():
            raise ConfigurationError(f"Manifest not found: {path}")
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ConfigurationError(f"Cannot read {path}: {exc}") from exc
        try:
            _raw = tomllib.loads(raw)
        except tomllib.TOMLDecodeError as exc:
            raise ConfigurationError(f"Failed to parse {path}: {exc}") from exc
        return cls._from_dict(cast(_TomlObj, _raw))

    @classmethod
    def _from_dict(cls, data: dict[str, object]) -> MovieManifest:
        title = _require_nonempty_str(data, "title")
        project = _require_nonempty_str(data, "project")
        output_dir = _optional_str(data, "output_dir")
        schema_version = _require_int(data, "schema_version", default=1)
        style = _parse_style(data.get("style"))
        characters = _parse_characters(data)
        scenes = _parse_scenes(data, characters, style)
        continuity = _parse_continuity(data)
        assemble = _parse_assemble(data)
        instructions = _parse_global_instructions(data)

        return cls(
            title=title,
            project=project,
            style=style,
            characters=characters,
            scenes=scenes,
            continuity=continuity,
            assemble=assemble,
            output_dir=output_dir,
            schema_version=schema_version,
            instructions=instructions,
        )


# ---------------------------------------------------------------------------
# Internal parsers
# ---------------------------------------------------------------------------


def _require_nonempty_str(data: dict[str, object], key: str) -> str:
    """Extract a required non-empty string from data."""
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ConfigurationError(f"'{key}' must be a non-empty string.")
    return value.strip()


def _optional_str(data: dict[str, object], key: str) -> str | None:
    """Extract an optional string from data."""
    value = data.get(key)
    if value is not None and not isinstance(value, str):
        raise ConfigurationError(f"'{key}' must be a string.")
    return value


def _require_int(data: dict[str, object], key: str, default: int = 0) -> int:
    """Extract a required integer from data."""
    value = data.get(key, default)
    if not isinstance(value, int):
        raise ConfigurationError(f"'{key}' must be an integer.")
    return value


def _parse_manifest_card(c: object, idx: int) -> ManifestCard:
    if not isinstance(c, dict):
        raise ConfigurationError(f"instructions.card[{idx}] must be a table/object.")
    c_dict = cast(_TomlObj, c)
    title = c_dict.get("title")
    if not isinstance(title, str) or not title.strip():
        raise ConfigurationError(f"instructions.card[{idx}].title must be a non-empty string.")

    text = c_dict.get("text", "")
    if not isinstance(text, str):
        raise ConfigurationError(f"instructions.card[{idx}].text must be a string.")

    enabled = c_dict.get("enabled", True)
    if not isinstance(enabled, bool):
        raise ConfigurationError(f"instructions.card[{idx}].enabled must be a boolean.")

    raw_ref = c_dict.get("ref", ())
    if isinstance(raw_ref, str):
        ref = (raw_ref,)
    elif isinstance(raw_ref, list):
        ref = tuple(str(r) for r in cast(_TomlList, raw_ref))
    else:
        ref = ()

    return ManifestCard(
        title=title.strip(),
        text=text,
        ref=ref,
        enabled=enabled,
    )


def _parse_global_instructions(data: dict[str, object]) -> tuple[ManifestCard, ...]:
    inst_raw = data.get("instructions")
    if inst_raw is None:
        return ()
    if not isinstance(inst_raw, dict):
        raise ConfigurationError("'instructions' must be a table/object.")

    inst_dict = cast(_TomlObj, inst_raw)
    cards_raw = inst_dict.get("card", [])
    if not isinstance(cards_raw, list):
        raise ConfigurationError("'instructions.card' must be an array.")

    cards: list[ManifestCard] = []
    for i, c in enumerate(cast(_TomlList, cards_raw)):
        cards.append(_parse_manifest_card(c, i))
    return tuple(cards)


def _parse_scene_instructions(inst_raw: object, idx: int) -> SceneInstructions | None:
    if inst_raw is None:
        return None
    if not isinstance(inst_raw, dict):
        raise ConfigurationError(f"scenes[{idx}].instructions must be a table/object.")

    inst_dict = cast(_TomlObj, inst_raw)
    disable_raw = inst_dict.get("disable", [])
    if isinstance(disable_raw, str):
        disable = (disable_raw,)
    elif isinstance(disable_raw, list):
        disable = tuple(str(d) for d in cast(_TomlList, disable_raw))
    else:
        raise ConfigurationError(
            f"scenes[{idx}].instructions.disable must be a list of strings or a string."
        )

    cards_raw = inst_dict.get("card", [])
    if not isinstance(cards_raw, list):
        raise ConfigurationError(f"scenes[{idx}].instructions.card must be an array.")

    cards: list[ManifestCard] = []
    for i, c in enumerate(cast(_TomlList, cards_raw)):
        cards.append(_parse_manifest_card(c, i))

    return SceneInstructions(
        disable=disable,
        card=tuple(cards),
    )


def _parse_characters(data: dict[str, object]) -> dict[str, Character]:
    """Parse characters from data."""
    chars_raw = data.get("characters", [])
    if not isinstance(chars_raw, list):
        raise ConfigurationError("'characters' must be a TOML array.")
    chars_list = cast(_TomlList, chars_raw)
    characters: dict[str, Character] = {}
    for i, c in enumerate(chars_list):
        parsed = _parse_character(c, i)
        if parsed.name in characters:
            raise ConfigurationError(f"Duplicate character name: {parsed.name!r}")
        characters[parsed.name] = parsed
    return characters


def _parse_scenes(
    data: dict[str, object],
    characters: dict[str, Character],
    style: StyleSpec,
) -> tuple[Scene, ...]:
    """Parse scenes from data."""
    scenes_raw = data.get("scenes", [])
    if not isinstance(scenes_raw, list):
        raise ConfigurationError("'scenes' must be a TOML array.")
    if not scenes_raw:
        raise ConfigurationError("At least one [[scenes]] entry is required.")
    scenes_list = cast(_TomlList, scenes_raw)
    char_names = set(characters)
    style_variant_names = set(style.variants)
    scenes = tuple(
        _parse_scene(s, i, char_names, characters, style_variant_names)
        for i, s in enumerate(scenes_list)
    )
    scene_ids: set[str] = set()
    for s in scenes:
        if s.id in scene_ids:
            raise ConfigurationError(f"Duplicate scene id: {s.id!r}")
        scene_ids.add(s.id)
    return scenes


def _parse_continuity(data: dict[str, object]) -> str:
    """Parse continuity setting from data."""
    continuity = "independent"
    movie_raw = data.get("movie")
    if isinstance(movie_raw, dict):
        raw_cont = cast(_TomlObj, movie_raw).get("continuity", "independent")
        if not isinstance(raw_cont, str):
            raise ConfigurationError("movie.continuity must be a string.")
        continuity = raw_cont
    return continuity


def _parse_assemble(data: dict[str, object]) -> AssemblyDef | None:
    """Parse assemble setting from data."""
    assemble_raw = data.get("assemble")
    if assemble_raw is None:
        return None
    if not isinstance(assemble_raw, dict):
        raise ConfigurationError("[assemble] must be a TOML table.")
    assemble_dict = cast(_TomlObj, assemble_raw)
    output = assemble_dict.get("output")
    if output is not None and not isinstance(output, str):
        raise ConfigurationError("assemble.output must be a string path.")
    return AssemblyDef(output=output)


def _parse_style(data: object) -> StyleSpec:
    if data is None:
        return StyleSpec()
    if not isinstance(data, dict):
        raise ConfigurationError("[style] must be a TOML table.")
    d = cast(_TomlObj, data)

    def s(key: str) -> str | None:
        v = d.get(key)
        if v is not None and not isinstance(v, str):
            raise ConfigurationError(f"style.{key} must be a string.")
        return v.strip() if isinstance(v, str) else None

    variants = _parse_style_variants(d)

    return StyleSpec(
        look=s("look"),
        palette=s("palette"),
        environment=s("environment"),
        camera=s("camera"),
        lighting=s("lighting"),
        mood=s("mood"),
        negative=s("negative"),
        prefix=s("prefix"),
        suffix=s("suffix"),
        variants=variants,
    )


def _parse_style_variants(d: _TomlObj) -> dict[str, str]:
    """Parse [style.variants.*] sub-tables into a name → suffix mapping."""
    variants_raw = d.get("variants")
    if variants_raw is None:
        return {}
    if not isinstance(variants_raw, dict):
        raise ConfigurationError("[style.variants] must be a TOML table.")
    variants: dict[str, str] = {}
    for raw_name, val in cast(_TomlObj, variants_raw).items():
        name = str(raw_name).strip()
        if not name:
            raise ConfigurationError("[style.variants] names must be non-empty.")
        if name == "none":
            raise ConfigurationError(
                '[style.variants.none] is not allowed: "none" is reserved for '
                "scenes[].style_variant to opt out of the style suffix."
            )
        if not isinstance(val, dict):
            raise ConfigurationError(f"[style.variants.{name}] must be a TOML table.")
        variant_d = cast(_TomlObj, val)
        suffix_val = variant_d.get("suffix")
        if not isinstance(suffix_val, str):
            raise ConfigurationError(f"style.variants.{name}.suffix must be a string.")
        variants[name] = suffix_val.strip()
    return variants


def _parse_character_variants(d: _TomlObj, idx: int) -> dict[str, str]:
    """Parse the optional variants table for a character entry."""
    variants_raw = d.get("variants", {})
    if not isinstance(variants_raw, dict):
        raise ConfigurationError(f"characters[{idx}].variants must be a table.")
    return {str(k): str(v) for k, v in cast(_TomlObj, variants_raw).items()}


def _character_opt_str(d: _TomlObj, key: str, idx: int) -> str | None:
    """Read an optional string field from a character dict; raise on wrong type."""
    v = d.get(key)
    if v is not None and not isinstance(v, str):
        raise ConfigurationError(f"characters[{idx}].{key} must be a string.")
    return v.strip() if isinstance(v, str) else None


def _scene_opt_str(d: _TomlObj, key: str, idx: int) -> str | None:
    """Read an optional string field from a scene dict; raise on wrong type."""
    v = d.get(key)
    if v is not None and not isinstance(v, str):
        raise ConfigurationError(f"scenes[{idx}].{key} must be a string.")
    return v.strip() if isinstance(v, str) else None


def _parse_character(data: object, idx: int) -> Character:
    if not isinstance(data, dict):
        raise ConfigurationError(f"characters[{idx}] must be a TOML table.")
    d = cast(_TomlObj, data)

    name = d.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ConfigurationError(f"characters[{idx}].name must be a non-empty string.")

    identity = d.get("identity", "text")
    if identity not in ("text", "entity"):
        raise ConfigurationError(f"characters[{idx}].identity must be 'text' or 'entity'.")

    variants = _parse_character_variants(d, idx)

    model = d.get("model", "nano2")
    if not isinstance(model, str) or model not in _VALID_CHARACTER_MODELS:
        raise ConfigurationError(
            f"characters[{idx}].model must be one of "
            f"{sorted(_VALID_CHARACTER_MODELS)} (got {model!r})."
        )

    face_prompt = _character_opt_str(d, "face_prompt", idx)
    if identity == "entity" and not face_prompt:
        raise ConfigurationError(f"characters[{idx}] identity='entity' requires face_prompt.")
    if identity == "entity" and variants:
        # A variant is a prose delta; an entity's body reference already fixes the outfit (#724).
        fix = (
            "Model each costume as its own [[characters]] entry with identity='entity', "
            "the same face_prompt (byte-identical) and that costume's body_prompt, "
            "and name that entry in the scenes that use it."
        )
        raise ConfigurationError(
            f"characters[{idx}] identity='entity' cannot have variants: the entity's body "
            f"reference fixes one outfit, so a variant's text would conflict with it. {fix}",
            remediation_hint=fix,
        )

    return Character(
        name=name.strip(),
        appearance=_character_opt_str(d, "appearance", idx),
        identity=str(identity),
        voice=_character_opt_str(d, "voice", idx),
        variants=variants,
        face_prompt=face_prompt,
        body_prompt=_character_opt_str(d, "body_prompt", idx),
        model=str(model),
    )


def _parse_scene_chars(d: _TomlObj, idx: int, char_names: set[str]) -> list[str]:
    """Parse and validate the characters array for a scene."""
    chars_raw = d.get("characters", [])
    if not isinstance(chars_raw, list):
        raise ConfigurationError(f"scenes[{idx}].characters must be an array.")
    chars: list[str] = []
    for cn in cast(_TomlList, chars_raw):
        if not isinstance(cn, str) or cn not in char_names:
            raise ConfigurationError(f"scenes[{idx}] references unknown character {cn!r}.")
        chars.append(cn)
    return chars


def _parse_scene_shorthand_dialogue(
    d: _TomlObj,
    idx: int,
    chars: list[str],
) -> tuple[list[DialogueLine], object, object]:
    """Parse shorthand speaker/line/variant fields; return (dialogue, speaker, variant).

    Also validates that shorthand fields are not used when >1 character is present.
    """
    dialogue: list[DialogueLine] = []
    speaker = d.get("speaker")
    line = d.get("line")
    variant = d.get("variant")

    if (speaker is not None or line is not None or variant is not None) and len(chars) > 1:
        raise ConfigurationError(
            f"scenes[{idx}]: speaker/line/variant shorthand is invalid with >1 character; "
            "use per-character [[scenes.characters_detail]] entries."
        )

    if speaker is not None:
        if speaker not in chars:
            raise ConfigurationError(f"scenes[{idx}].speaker {speaker!r} not in characters.")
        if not isinstance(line, str) or not line.strip():
            raise ConfigurationError(f"scenes[{idx}].line must be a non-empty string.")
        dialogue.append(DialogueLine(speaker=str(speaker), line=line.strip()))

    return dialogue, speaker, variant


def _parse_scene_per_char_dialogue(
    d: _TomlObj,
    idx: int,
    chars: list[str],
) -> list[DialogueLine]:
    """Parse the optional [[scenes.characters_detail]] per-character dialogue table."""
    dialogue: list[DialogueLine] = []
    per_char = d.get("characters_detail")
    if not isinstance(per_char, list):
        return dialogue
    for e in cast(_TomlList, per_char):
        if not isinstance(e, dict):
            continue
        ed = cast(_TomlObj, e)
        nm = ed.get("name")
        ln = ed.get("line")
        if nm not in chars:
            raise ConfigurationError(
                f"scenes[{idx}].characters_detail name {nm!r} not in characters."
            )
        if isinstance(ln, str) and ln.strip():
            dialogue.append(DialogueLine(speaker=str(nm), line=ln.strip()))
    return dialogue


def _validate_scene_variant(
    variant: object,
    chars: list[str],
    characters: dict[str, Character],
    idx: int,
) -> None:
    """Validate that the shorthand variant name exists on the (single) character."""
    if not isinstance(variant, str) or len(chars) != 1:
        return
    ch = characters.get(chars[0])
    if ch is not None and variant not in ch.variants:
        raise ConfigurationError(
            f"scenes[{idx}].variant {variant!r} is not a variant of "
            f"character {chars[0]!r} (defined: {sorted(ch.variants)!r})."
        )


def _parse_scene_numeric_fields(d: _TomlObj, idx: int) -> tuple[str, object]:
    """Parse and validate aspect and duration; return (aspect_str, duration_raw)."""
    aspect = d.get("aspect", "16:9")
    if not isinstance(aspect, str) or aspect not in _VALID_VIDEO_ASPECTS:
        raise ConfigurationError(
            f"scenes[{idx}].aspect must be one of {sorted(_VALID_VIDEO_ASPECTS)}."
        )

    duration = d.get("duration")
    if duration is not None and duration not in _VALID_DURATIONS:
        raise ConfigurationError(
            f"scenes[{idx}].duration must be one of {sorted(_VALID_DURATIONS)}."
        )

    return str(aspect), duration


def _validate_scene_framing(framing: object, idx: int) -> None:
    """Validate that scene framing, if given, is one of the allowed values."""
    if framing is not None and framing not in FRAMING:
        raise ConfigurationError(
            f"scenes[{idx}].framing must be one of {sorted(FRAMING)} (got {framing!r})."
        )


def _validate_scene_model(model: object, idx: int, duration: int | None) -> None:
    """Validate the scene's model alias, and its compatibility with *duration*.

    Both checks belong at PARSE time (#634). Before this, the alias was only
    checked to be a *string* and ``duration`` only to be one of 4/6/8/10 — the
    two were never checked against each other, and the alias itself was not
    resolved until ``VideoModel.from_cli`` ran inside the per-scene render loop.
    Either failure therefore landed mid-run, after earlier scenes had generated
    and billed, as exit 1 "Unexpected error".
    """
    if model is None:
        if duration is not None:
            try:
                validate_duration_for_model(None, duration)
            except ValueError as exc:
                raise ConfigurationError(f"scenes[{idx}].duration: {exc}") from exc
        # No model means Flow's sticky UI default, which is unknowable here, so the
        # duration is held to the legacy 4/6/8/10 set (#632); only an explicit
        # omni-1.2-flash unlocks the rest of 3-15.
        return
    if not isinstance(model, str):
        raise ConfigurationError(f"scenes[{idx}].model must be a string.")
    try:
        resolved = VideoModel.from_cli(model)
    except ValueError as exc:
        raise ConfigurationError(
            f"scenes[{idx}].model {model!r} is not a known model alias: {exc}"
        ) from exc
    if duration is not None and resolved is not None:
        try:
            validate_duration_for_model(resolved, duration)
        except ValueError as exc:
            raise ConfigurationError(
                f"scenes[{idx}].duration {duration} is invalid for {model!r}: {exc}"
            ) from exc


def _validate_scene_style_variant(
    style_variant: str | None, idx: int, style_variant_names: set[str]
) -> None:
    """Validate that style_variant, if given, is 'none' or a defined style variant."""
    if (
        style_variant is not None
        and style_variant != "none"
        and style_variant not in style_variant_names
    ):
        raise ConfigurationError(
            f"scenes[{idx}].style_variant {style_variant!r} is not a defined "
            f"style variant (defined: {sorted(style_variant_names)!r})."
        )


def _scene_opt_field(d: _TomlObj, key: str) -> str | None:
    """Read an optional string field from a scene dict, stripped; non-str values become None."""
    v = d.get(key)
    return v.strip() if isinstance(v, str) else None


def _parse_scene(
    data: object,
    idx: int,
    char_names: set[str],
    characters: dict[str, Character],
    style_variant_names: set[str],
) -> Scene:
    if not isinstance(data, dict):
        raise ConfigurationError(f"scenes[{idx}] must be a TOML table.")
    d = cast(_TomlObj, data)

    sid = d.get("id")
    if not isinstance(sid, str) or not sid.strip():
        raise ConfigurationError(f"scenes[{idx}].id must be a non-empty string.")

    action = d.get("action")
    if not isinstance(action, str) or not action.strip():
        raise ConfigurationError(f"scenes[{idx}].action must be a non-empty string.")

    framing = d.get("framing")
    _validate_scene_framing(framing, idx)

    chars = _parse_scene_chars(d, idx, char_names)

    # Dialogue: shorthand (speaker/line) for single-char scenes, else per-character table.
    shorthand_dialogue, _, variant = _parse_scene_shorthand_dialogue(d, idx, chars)
    per_char_dialogue = _parse_scene_per_char_dialogue(d, idx, chars)
    dialogue = shorthand_dialogue + per_char_dialogue

    _validate_scene_variant(variant, chars, characters, idx)

    aspect, duration_raw = _parse_scene_numeric_fields(d, idx)
    # Coerce BEFORE the model cross-check, so the guard tests the value the Scene
    # will actually carry. `4.0 in {4, 6, 8, 10}` is True, so a float slips past
    # the value check but is then dropped here — guarding the raw value would
    # reject a manifest that previously rendered fine (duration silently unset).
    duration = duration_raw if isinstance(duration_raw, int) else None

    model = d.get("model")
    _validate_scene_model(model, idx, duration)

    style_variant = _scene_opt_str(d, "style_variant", idx)
    _validate_scene_style_variant(style_variant, idx, style_variant_names)

    style_suffix = _scene_opt_str(d, "style_suffix", idx)
    instructions = _parse_scene_instructions(d.get("instructions"), idx)

    return Scene(
        id=sid.strip(),
        action=action.strip(),
        title=_scene_opt_field(d, "title"),
        setting=_scene_opt_field(d, "setting"),
        framing=str(framing) if framing else None,
        camera=_scene_opt_field(d, "camera"),
        lighting=_scene_opt_field(d, "lighting"),
        mood=_scene_opt_field(d, "mood"),
        negative=_scene_opt_field(d, "negative"),
        characters=tuple(chars),
        variant=str(variant) if isinstance(variant, str) else None,
        dialogue=tuple(dialogue),
        duration=duration,
        model=model if isinstance(model, str) else None,
        aspect=aspect,
        count=1,
        style_variant=style_variant,
        style_suffix=style_suffix,
        instructions=instructions,
    )


# ---------------------------------------------------------------------------
# Run state — crash-recoverable JSON written alongside the manifest
# ---------------------------------------------------------------------------


@dataclass
class CharacterState:
    """Persisted state for a created character."""

    entity_id: str
    image_paths: list[str | None]

    def to_dict(self) -> dict[str, object]:
        return {"entity_id": self.entity_id, "image_paths": self.image_paths}

    @classmethod
    def from_dict(cls, d: dict[str, object]) -> CharacterState:
        eid = d.get("entity_id")
        raw_paths = d.get("image_paths")
        paths: list[str | None] = []
        if isinstance(raw_paths, list):
            for p in cast(_TomlList, raw_paths):
                paths.append(str(p) if isinstance(p, str) else None)
        return cls(
            entity_id=str(eid) if eid is not None else "",
            image_paths=paths,
        )


@dataclass
class SceneState:
    """Persisted state for a generated scene."""

    media_id: str
    flow_operation_id: str | None
    local_path: str | None
    status: str  # "completed" | "failed"
    prompt: str | None = None  # composed Veo prompt (for handoff projection)
    consistency_method: str = "text"  # "text" | "entity" | "degraded" (P2)
    style_hash: str | None = None  # SHA-256 of composed prompt for resume detection

    def is_stale_for(self, prompt: str) -> bool:
        """True when *prompt* no longer matches what this scene was generated with.

        Prefers the persisted ``style_hash``; falls back to comparing the stored
        prompt text (state files written before ``style_hash`` existed). With
        neither record, assume not stale — never re-spend credits on a guess.
        """
        if self.style_hash is not None:
            return self.style_hash != resume_hash(prompt)
        if self.prompt is not None:
            return self.prompt != prompt
        return False

    def to_dict(self) -> dict[str, object]:
        return {
            "media_id": self.media_id,
            "flow_operation_id": self.flow_operation_id,
            "local_path": self.local_path,
            "status": self.status,
            "prompt": self.prompt,
            "consistency_method": self.consistency_method,
            "style_hash": self.style_hash,
        }

    @classmethod
    def from_dict(cls, d: dict[str, object]) -> SceneState:
        raw_op_id = d.get("flow_operation_id")
        raw_path = d.get("local_path")
        raw_prompt = d.get("prompt")
        raw_method = d.get("consistency_method", "text")
        raw_hash = d.get("style_hash")
        return cls(
            media_id=str(d.get("media_id") or ""),
            flow_operation_id=str(raw_op_id) if isinstance(raw_op_id, str) else None,
            local_path=str(raw_path) if isinstance(raw_path, str) else None,
            status=str(d.get("status") or "completed"),
            prompt=str(raw_prompt) if isinstance(raw_prompt, str) else None,
            consistency_method=str(raw_method) if isinstance(raw_method, str) else "text",
            style_hash=str(raw_hash) if isinstance(raw_hash, str) else None,
        )


class MovieState:
    """Crash-recoverable run state for a movie project.

    Written as JSON alongside the manifest file after each phase completes
    so that a re-run can skip already-completed characters and scenes.
    """

    VERSION = 2

    def __init__(self, *, title: str, project: str) -> None:
        self.title = title
        self.project = project
        self.characters: dict[str, CharacterState] = {}
        self.scenes: dict[str, SceneState] = {}

    @staticmethod
    def state_path_for(manifest_path: Path) -> Path:
        """Return the sibling state file path for *manifest_path*."""
        return manifest_path.parent / (manifest_path.stem + "-state.json")

    @classmethod
    def load(cls, path: Path, *, title: str, project: str) -> MovieState:
        """Load existing state or return a fresh empty state on any error."""
        state = cls(title=title, project=project)
        if not path.exists():
            return state
        try:
            raw: object = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return state
        if not isinstance(raw, dict):
            return state
        data = cast(_TomlObj, raw)

        chars_raw = data.get("characters")
        if isinstance(chars_raw, dict):
            for name, raw_char in cast(_TomlObj, chars_raw).items():
                if isinstance(raw_char, dict):
                    state.characters[name] = CharacterState.from_dict(cast(_TomlObj, raw_char))
        scenes_raw = data.get("scenes")
        if isinstance(scenes_raw, dict):
            for title_key, raw_scene in cast(_TomlObj, scenes_raw).items():
                if isinstance(raw_scene, dict):
                    state.scenes[title_key] = SceneState.from_dict(cast(_TomlObj, raw_scene))
        return state

    def save(self, path: Path) -> None:
        """Persist state to *path* (creates parent dirs if missing)."""
        path.parent.mkdir(parents=True, exist_ok=True)
        payload: dict[str, object] = {
            "version": self.VERSION,
            "title": self.title,
            "project": self.project,
            "characters": {n: c.to_dict() for n, c in self.characters.items()},
            "scenes": {t: s.to_dict() for t, s in self.scenes.items()},
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
