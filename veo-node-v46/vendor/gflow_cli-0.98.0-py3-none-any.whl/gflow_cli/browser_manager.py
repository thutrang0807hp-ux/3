"""Chrome discovery and Playwright-channel helpers.

.. note::

   This module previously also shipped a packaged CDP (Chrome DevTools
   Protocol) attach/spawn lifecycle — ``get_or_launch_browser`` /
   ``close_browser`` / lockfile-managed detached Chrome — for research use
   and non-Flow use cases. It was removed 2026-07-19 (see
   ``.superpowers/sdd/cdp-decision.md`` in the
   ``chore/production-readiness-hardening`` history): zero production
   consumers shipped in the wheel, the no-lock attach path would connect to
   *any* Chrome answering on the port (a documented hijack vector), and the
   externally-discoverable CDP debug port this pattern relies on was itself
   rejected by Google's Flow surface on `aisandbox-pa.googleapis.com` in a
   2026-05-12 empirical test. The production transport is
   :class:`gflow_cli.api.transports.ui_automation.UiAutomationTransport`,
   which uses Playwright's internal CDP port (Playwright manages it
   privately, never externally exposed) rather than an externally-exposed
   debug port. CDP-attach as a distinct opt-in transport remains a parked
   backlog idea — see PLAN.md ADR #13 and the "CDP Attach Transport —
   BACKLOG" section — should a future contributor want to revisit it with a
   safe ownership model.

Single responsibility: locate the system Chrome binary and decide which
Playwright ``channel`` (if any) a given profile should launch with.

Public API
----------
is_chrome_available() -> bool
    True if a Google Chrome (or Chromium fallback) binary can be found.

resolved_chrome_binary() -> str | None
    The resolved Chrome binary path, or None. Never raises.

is_playwright_chrome_channel_available() -> bool
    True only if Google Chrome proper sits at one of the paths Playwright's
    ``channel="chrome"`` hard-codes. Stricter than ``is_chrome_available()``,
    which accepts Chromium; ``CHROME_BINARY`` does not satisfy it.

channel_for_profile(profile_dir) -> str | None
    ``"chrome"`` if the profile's strategy marker requests it AND Google
    Chrome proper is available at Playwright's expected paths; else None.

chrome_strategy_requested(profile_dir) -> bool
    True if the profile's ``.gflow_browser_strategy`` marker requests
    system Chrome (independent of whether Chrome is actually available).

disable_features_args() -> tuple[str, ...]
    One ``--disable-features`` switch merging the active engine's list with
    gflow's (#1140); empty when that list cannot be read.

ensure_profile_engine_compatible(profile_dir, channel) -> None
    Raise ``ProfileEngineDowngradeError`` when the bundled Chromium about to
    open ``profile_dir`` is older than the Chromium that last wrote it (#477).

Internal helpers (exported for tests)
--------------------------------------
_find_chrome_binary() -> str
"""

from __future__ import annotations

import json
import os
import re
import shutil
import sys
from pathlib import Path
from typing import Any

import structlog

from gflow_cli.errors import (
    ConfigurationError,
    ProfileEngineDowngradeError,
    ProfileLockedError,
)

log = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Chrome binary detection
# ---------------------------------------------------------------------------


def _find_chrome_binary() -> str:
    """Locate the system Chrome binary.

    Resolution order:
    1. ``CHROME_BINARY`` env var (override)
    2. ``shutil.which("chrome")`` / ``shutil.which("google-chrome")``
    3. Platform-standard install paths (including Chromium as last resort for
       non-Playwright-channel uses such as auth login).

    .. note::
        This function accepts Chromium as a fallback for the auth use-case.
        It must NOT be used to decide whether Playwright's ``channel="chrome"``
        is available — use :func:`is_playwright_chrome_channel_available` for
        that, which checks only the exact paths Playwright hard-codes.

    Raises ``ConfigurationError`` if nothing found.
    """
    # 1. Environment override
    env_override = os.environ.get("CHROME_BINARY")
    if env_override:
        return env_override

    # 2. PATH probe — Google Chrome names first, Chromium last-resort
    for candidate in ("chrome", "google-chrome", "chromium"):
        found = shutil.which(candidate)
        if found:
            return found

    # 3. Platform-specific standard paths
    if sys.platform == "win32":
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        platform_paths = [
            Path("C:/Program Files/Google/Chrome/Application/chrome.exe"),
            Path("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"),
            Path(local_app_data or "") / "Google" / "Chrome" / "Application" / "chrome.exe",
        ]
    elif sys.platform == "darwin":
        platform_paths = [
            Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
    else:
        # Linux / other POSIX
        platform_paths = [
            Path("/usr/bin/google-chrome"),
            Path("/usr/bin/chromium"),
            Path("/usr/bin/chromium-browser"),
        ]

    for p in platform_paths:
        if p.exists():
            return str(p)

    msg = (
        "Chrome not found. Install from https://www.google.com/chrome/"
        " or set CHROME_BINARY env var."
    )
    raise ConfigurationError(
        msg,
    )


def is_playwright_chrome_channel_available() -> bool:
    """Return True only when Playwright's ``channel="chrome"`` can find Chrome.

    Playwright's ``launch_persistent_context(channel="chrome")`` looks for
    **Google Chrome proper** at platform-specific hardcoded paths — it does NOT
    accept a plain Chromium binary. This function replicates those paths so
    callers can gate the ``channel="chrome"`` argument on a binary that Playwright
    will actually find, avoiding the misleading
    ``Chromium distribution 'chrome' is not found at /opt/google/chrome/chrome``
    error that occurs when only system Chromium is present.

    ``CHROME_BINARY`` is deliberately **ignored** here, unlike in
    :func:`_find_chrome_binary`: Playwright honours a custom binary only via
    ``executable_path=``, never via ``channel=``. Treating the env var as proof of
    a resolvable channel passed this gate and then failed at launch.
    """
    # Playwright's own resolution paths for channel="chrome". Derived from
    # playwright/_impl/_browser_type.py executables(). channel="chrome" resolves
    # ONLY to these exact Google-Chrome paths — a system Chromium does NOT
    # satisfy it, so we must not list Chromium or distro chrome shims here.
    if sys.platform == "win32":
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        chrome_paths: list[Path] = [
            Path("C:/Program Files/Google/Chrome/Application/chrome.exe"),
            Path("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"),
            Path(local_app_data or "") / "Google" / "Chrome" / "Application" / "chrome.exe",
        ]
    elif sys.platform == "darwin":
        chrome_paths = [
            Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
    else:
        # Linux — Playwright resolves channel="chrome" only to this path.
        chrome_paths = [
            Path("/opt/google/chrome/chrome"),
        ]

    return any(p.exists() for p in chrome_paths)


def is_chrome_available() -> bool:
    """Return True if a Google Chrome (or Chromium fallback) binary can be found.

    This is used for the auth login flow. It intentionally accepts Chromium as
    a fallback so the auth browser can open even when only Chromium is
    installed. For deciding whether Playwright's ``channel="chrome"`` can be
    used, call :func:`is_playwright_chrome_channel_available` instead.
    """
    try:
        _find_chrome_binary()
        return True
    except ConfigurationError:
        return False


def resolved_chrome_binary() -> str | None:
    """Return the system Chrome binary path, or ``None`` if Chrome can't be found.

    Public, exception-free wrapper around :func:`_find_chrome_binary` for
    diagnostics/logging callers that want the path without handling errors. It
    must NEVER raise: it feeds ``_log_and_guard_launch``'s observability log, and
    a best-effort path probe should never abort a launch. Besides
    :class:`ConfigurationError` (no binary found), ``shutil.which`` can raise on
    odd environments (e.g. an OS-detection mismatch), so any error resolves to
    ``None``.
    """
    try:
        return _find_chrome_binary()
    except Exception:  # noqa: BLE001 — exception-free by contract; any failure → None
        return None


def window_position_args(position: str) -> list[str]:
    """Chrome args placing the headed generation window (#923); '' keeps Chrome's own.

    Shared by both generation launch sites (``FlowApiClient`` and the standalone
    ``UiAutomationTransport``) so they cannot drift. Login launches stay visible.
    """
    return [f"--window-position={position}"] if position else []


#: Chrome features gflow turns off on top of the driver's own list (#1140):
#: CloudSyncedFolderChecker's startup task (a Windows cloud-files COM call) can never
#: answer, and Chrome's shutdown, headed or headless, waits on it until the 30 s
#: close timeout.
_EXTRA_DISABLED_FEATURES = ("CloudSyncedFolderChecker",)

# Where Playwright 1.61 builds its switch; the pin test fails loudly if this moves.
_PW_LIST_RE = re.compile(r"disabledFeatures = \[(.*?)\]\.filter\(Boolean\)", re.DOTALL)
_PW_SWITCH_USE = '"--disable-features=" + disabledFeatures.join(",")'

#: Successful reads only, per bundle: a failed read is retried on the next launch, so
#: a transient lock does not cost a long-lived ``gflow mcp run`` the slow close.
_DISABLE_FEATURES_CACHE: dict[Path, tuple[str, ...]] = {}


def _engine_package_dir() -> Path:
    """The ACTIVE engine's package dir: ``patchright`` when selected, else ``playwright``."""
    import importlib

    from gflow_cli.api._engine import active_engine
    from gflow_cli.config import BrowserEngine

    name = "patchright" if active_engine() == BrowserEngine.PATCHRIGHT else "playwright"
    return Path(str(importlib.import_module(name).__file__)).parent


def _engine_bundle() -> Path:
    return _engine_package_dir() / "driver" / "package" / "lib" / "coreBundle.js"


def disable_features_args() -> tuple[str, ...]:
    """ONE ``--disable-features`` switch: the driver's own list plus gflow's (#1140).

    Chrome honours only the last such switch, so a second one would silently
    re-enable the driver's (measured: HttpsUpgrades came back). The list is read from
    the active engine's driver bundle (patchright keeps a different one); if it cannot
    be read as plain string literals, the switch is left out, which keeps the old
    (slow-close) behaviour rather than a wrong feature set. Shared by every
    Playwright launch site, headed or headless.
    """
    try:
        bundle = _engine_bundle()
    except ImportError:  # the engine is not installed; its launch fails on its own
        return ()
    if (cached := _DISABLE_FEATURES_CACHE.get(bundle)) is not None:
        return cached
    try:
        js = bundle.read_text(encoding="utf-8")
    except (OSError, ValueError):  # ValueError covers a truncated, non-UTF-8 bundle
        js = ""
    match = _PW_LIST_RE.search(js)
    body = re.sub(r"//[^\n]*", "", match.group(1)) if match else ""
    features = re.findall(r'"([^"]+)"', body)
    # Anything but quoted names and commas (e.g. a platform conditional) is unreadable.
    if not features or _PW_SWITCH_USE not in js or re.sub(r'"[^"]*"|[\s,]', "", body):
        log.warning("browser_manager.playwright_disabled_features_unreadable")
        return ()
    result = ("--disable-features=" + ",".join([*features, *_EXTRA_DISABLED_FEATURES]),)
    _DISABLE_FEATURES_CACHE[bundle] = result
    return result


#: Playwright's launch error when Chrome hands the profile to a running instance
#: (#984, measured 2026-10-23, Windows, Chrome 141), e.g. the user's own Chrome window.
_PROFILE_IN_USE_MARKER = "profile is already in use by another instance"


def profile_in_use_error(exc: BaseException, profile_dir: Path) -> ProfileLockedError | None:
    """The typed error for a launch refused because another Chrome holds the profile.

    ``None`` for any other launch failure. ``ProfileLease`` cannot see a Chrome gflow did
    not start, so this message is the only signal; it states the cause outright.
    """
    msg = str(exc)
    # A read-only profile shares the header; its lock-file line marks it (#1059).
    if _PROFILE_IN_USE_MARKER not in msg or "Lock file can not be created" in msg:
        return None
    return ProfileLockedError(
        detail=(
            f"Chrome reports the profile dir {profile_dir} is already in use by another "
            "Chrome window, so gflow cannot open it"
        ),
        remediation_hint=(
            "Close the Chrome window that is using this profile (one you opened yourself, "
            "or one left by a crashed gflow run) and re-run, or use a different --profile."
        ),
    )


def browser_proxy_kwargs(proxy: str | None) -> dict[str, Any]:
    """Playwright ``proxy`` launch kwarg for GFLOW_CLI_BROWSER_PROXY (#1036); {} when unset.

    Always the kwarg, never ``--proxy-server`` in ``args``, so every launch site
    carries it the same way. The value is already validated by ``Settings``.
    """
    return {"proxy": {"server": proxy}} if proxy else {}


def channel_for_profile(profile_dir: Path) -> str | None:
    """Return the Playwright channel to use for ``profile_dir``, or None.

    Reads the ``.gflow_browser_strategy`` marker written by
    :class:`~gflow_cli.auth.real_chrome.RealChromeStrategy`. When the marker
    is ``"chrome"`` and **Google Chrome proper** is available at the paths
    Playwright expects, returns ``"chrome"`` so callers can pass it to
    ``launch_persistent_context(channel=...)`` — avoiding the downgrade-cleanup
    exit-33 that occurs when Playwright's bundled Chromium opens a profile
    created by Chrome 130+.

    Critically, this gate uses :func:`is_playwright_chrome_channel_available`
    (not :func:`is_chrome_available`) so that a system with only Chromium
    installed does NOT request ``channel="chrome"`` — Playwright's
    ``channel="chrome"`` resolves to hardcoded Google-Chrome paths and would
    otherwise fail with
    ``Chromium distribution 'chrome' is not found at /opt/google/chrome/chrome``.

    Logs a warning when the marker requests Chrome but Chrome is no longer
    available at the expected Playwright paths, as the resulting launch against
    bundled Chromium will likely fail with the same exit-33 error.
    """
    import structlog as _structlog

    _log = _structlog.get_logger(__name__)
    marker = profile_dir / ".gflow_browser_strategy"
    if not marker.exists():
        return None
    strategy = marker.read_text(encoding="utf-8").strip()
    if strategy != "chrome":
        return None
    if is_playwright_chrome_channel_available():
        return "chrome"
    _log.warning(
        "browser_manager.chrome_marker_but_unavailable",
        profile_dir=str(profile_dir),
        hint="Profile was captured with system Chrome but Google Chrome is not "
        "found at the paths Playwright expects (e.g. /opt/google/chrome/chrome). "
        "Falling back to Playwright's bundled Chromium. "
        "Re-run `gflow auth login --browser chrome` after installing Chrome if "
        "you need the Chrome channel.",
    )
    return None


def chrome_strategy_requested(profile_dir: Path) -> bool:
    """True if the profile's ``.gflow_browser_strategy`` marker requests system Chrome.

    Distinct from :func:`channel_for_profile`, which returns ``None`` both when no
    marker is present (legitimate bundled-Chromium use) AND when the marker says
    ``chrome`` but Chrome can't be found (a silent downgrade). Callers use this to
    tell those two cases apart — see ``FlowApiClient._log_and_guard_launch`` and
    issue #222 (macOS: a chrome→bundled downgrade yields cookies the bundled
    Chromium can't decrypt → 401).
    """
    marker = profile_dir / ".gflow_browser_strategy"
    try:
        return marker.exists() and marker.read_text(encoding="utf-8").strip() == "chrome"
    except OSError:
        return False


# ---------------------------------------------------------------------------
# #477: profile-engine (Chromium version) downgrade guard
# ---------------------------------------------------------------------------


def profile_last_version(profile_dir: Path) -> str | None:
    """The Chromium version that last wrote ``profile_dir``, or None.

    Chromium maintains a plain-text ``Last Version`` file at the user-data-dir
    root; it is exactly what Chromium's own startup downgrade detection reads.
    Best-effort: missing/blank/unreadable resolves to None.
    """
    try:
        text = (profile_dir / "Last Version").read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        return None
    return text or None


def installed_chromium_version() -> str | None:
    """The bundled Chromium version of the ACTIVE engine's package, or None.

    Read from the driver's ``browsers.json`` registry (the same file
    ``playwright install`` uses), so no browser process is spawned. Resolves the
    registry via the active engine — ``patchright`` when
    ``GFLOW_CLI_BROWSER_ENGINE`` selects it, ``playwright`` otherwise — so the
    guard compares against the Chromium that will actually open the profile.
    Best-effort: any failure resolves to None.
    """
    try:
        registry_path = _engine_package_dir() / "driver" / "package" / "browsers.json"
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
        for browser in registry.get("browsers", []):
            if browser.get("name") == "chromium":
                version = browser.get("browserVersion")
                return str(version) if version else None
    except Exception:  # noqa: BLE001 — best-effort by contract; any failure → None
        return None
    return None


def _major_version(version: str) -> int | None:
    try:
        return int(version.split(".", 1)[0])
    except ValueError:
        return None


def ensure_profile_engine_compatible(profile_dir: Path, channel: str | None) -> None:
    """Refuse to open ``profile_dir`` with an older bundled Chromium **major
    version** than last wrote it (#477).

    Opening a Chrome profile with an older engine triggers Chromium's downgrade
    cleanup, which can leave the newer store — session cookies included —
    unreadable, surfacing later as a mystery logout. The compare is
    major-version (milestone) only: the destructive cleanup is keyed to
    milestone downgrades, and a same-milestone build rollback (e.g. pinning
    Playwright back one patch release) is safe and must not brick generation.
    Skipped when ``channel`` resolves to ``"chrome"`` (real Google Chrome
    manages its own profile lifecycle) and whenever either version is unknown
    or unparseable (best-effort guard, never a new failure mode on odd hosts).
    Login is deliberately unguarded: it re-mints the session and rewrites the
    profile, making it the recovery path the remediation points at.
    """
    if channel is not None:
        return
    profile_version = profile_last_version(profile_dir)
    engine_version = installed_chromium_version()
    if profile_version is None or engine_version is None:
        return
    profile_major = _major_version(profile_version)
    engine_major = _major_version(engine_version)
    if profile_major is None or engine_major is None:
        return
    if engine_major >= profile_major:
        return
    log.error(
        "browser_manager.profile_engine_downgrade",
        profile_dir=str(profile_dir),
        profile_chromium=profile_version,
        engine_chromium=engine_version,
    )
    msg = (
        f"Profile at {profile_dir} was last written by Chromium {profile_version}, "
        "but the bundled Chromium about to open it is an older major version "
        f"({engine_version}). Opening it would trigger Chromium's downgrade cleanup, "
        "which can leave the session store unreadable."
    )
    # Remedy lives in ProfileEngineDowngradeError._default_remediation — naming
    # it here too printed the remedy twice in the CLI human output.
    raise ProfileEngineDowngradeError(msg)
