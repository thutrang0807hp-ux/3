from pathlib import Path
import re,hashlib
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo';p=d/'photos.html';s=p.read_text()
s=s.replace('</head>','<style id="photo-input-script-css">'+(r/'scripts/photo-studio/input-script.css').read_text()+'</style></head>',1)
s=s.replace('</body>',''.join('<script id="photo-'+name+'">'+(r/'scripts/photo-studio'/name).read_text()+'</script>'for name in ['input-script.js','input-refs.js'])+'</body>',1);p.write_text(s)
h=hashlib.sha256(p.read_bytes()).hexdigest()[:12]
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=d/name;s=p.read_text();s=re.sub(r'<script id="photo-input-bridge">[\s\S]*?</script>','',s);s=re.sub(r'photos\.html\?v=[0-9a-f]+','photos.html?v='+h,s);s=s.replace('</body>','<script id="photo-input-bridge">'+(r/'scripts/app-shell/photo-input-bridge.js').read_text()+'</script></body>',1);p.write_text(s)
print('Applied product-first room references and lossless plain script node')
