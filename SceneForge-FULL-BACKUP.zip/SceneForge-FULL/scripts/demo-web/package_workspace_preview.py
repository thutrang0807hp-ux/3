from pathlib import Path
import base64,json,re,zipfile,os
photo_preview=os.environ.get('SCENEFORGE_PREVIEW_MODE')=='photos'
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo';batch_preview=os.environ.get('SCENEFORGE_PREVIEW_MODE')=='batch';recipe_preview=os.environ.get('SCENEFORGE_PREVIEW_MODE')in('recipes','recipes_v4');v4_preview=os.environ.get('SCENEFORGE_PREVIEW_MODE')=='recipes_v4';intake_preview=os.environ.get('SCENEFORGE_PREVIEW_MODE')=='intake'
font='data:font/ttf;base64,'+base64.b64encode((d/'fonts/SceneForgeSans.ttf').read_bytes()).decode()
children={}
for f in ['workflow.html','photos.html','native/index.html']:
 s=(d/f).read_text().replace('../fonts/SceneForgeSans.ttf',font)
 s=s.replace('location.search',"window.__sfPreviewSearch")
 s='<script>window.__sfPreviewSearch=__SF_PREVIEW_QUERY__;</script>'+s
 s=s.replace('location.origin','parent.location.origin').replace(',parent.location.origin)',",(parent.location.origin==='null'?'*':parent.location.origin))")
 children[f]=base64.b64encode(s.encode()).decode()
boot='''<script>
// Offline UI demonstration. Embedded real workspace bundles; no provider calls.
window.__sfPreviewFrames=PAYLOAD;
const originalSrc=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'src');
Object.defineProperty(HTMLIFrameElement.prototype,'src',{get(){return this.dataset.previewSrc||originalSrc.get.call(this)},set(v){const key=Object.keys(window.__sfPreviewFrames).find(k=>String(v).split('?')[0].replace(/^\\.\\//,'')===k);if(key){this.dataset.previewSrc=v;this.srcdoc=new TextDecoder().decode(Uint8Array.from(atob(window.__sfPreviewFrames[key]),c=>c.charCodeAt(0))).replace('__SF_PREVIEW_QUERY__',JSON.stringify(String(v).includes('?')?'?'+String(v).split('?').slice(1).join('?'):''));}else originalSrc.set.call(this,v)}});
const originalFetch=window.fetch.bind(window);
window.fetch=(input,options)=>{const u=String(input?.url||input);if(!u.startsWith('data:')&&!u.startsWith('blob:'))return Promise.reject(new Error('Bản mô phỏng offline: không gọi dịch vụ thật.'));return originalFetch(input,options)};
</script>'''.replace('PAYLOAD',json.dumps(children))
s=(d/'index.html').read_text().replace('new URLSearchParams(location.search).get(\'demo\')',"'1'").replace('sceneforge-app-showcase','sceneforge-workspace-offline-20261027')
s=re.sub(r'<link rel="preload" href="./fonts/SceneForgeSans.ttf"[^>]*>','',s).replace('./fonts/SceneForgeSans.ttf',font)
s=s.replace(',location.origin)',",(location.origin==='null'?'*':location.origin))")
s=s.replace("if(frame.contentWindow?.[name]?.getReadiness?.())","if(frame.contentWindow?.[name]?.getReadiness?.() && typeof frame.contentWindow[name].flushRoom==='function')")
s=s.replace('<head>','<head>'+boot,1)
# Open directly to the new shared workspace once fixture seeding finishes.
s=s.replace('</body>', '''<script>(()=>{const timer=setInterval(()=>{if(!appBootReady||!rooms.length)return;clearInterval(timer);const r=rooms.find(r=>r.mode!=='photos');if(r)openRoom(r.id,'analysis');},60);})();</script></body>''',1)
if photo_preview:
 opening='(async()=>{const r=rooms.find(r=>r.mode==="photos"&&!r.editorInitialized)||rooms.find(r=>r.mode==="photos");if(!r)return;await openRoom(r.id,"analysis");const w=document.querySelector("#workflowFrame").contentWindow;await w.eval('+json.dumps("(async()=>{if(!draft.previewPostSeeded){for(const b of draft.beats){const p=draft.plan.find(p=>p.beatId===b.id);if(p&&!b.clips?.length)b.clips=[{id:'preview-'+b.id,part:'a',key:p.key,name:'Clip minh họa có sẵn',poster:p.poster,duration:p.sourceDuration,version:1,origin:'preview-sample'}];}draft.previewPostSeeded=true;await save();render();fit();}})()")+');})();'
 s=s.replace("const r=rooms.find(r=>r.mode!=='photos');if(r)openRoom(r.id,'analysis');",opening).replace('sceneforge-workspace-offline-20261027','sceneforge-photo-post-preview-20261027')
if batch_preview:s=s.replace("const r=rooms.find(r=>r.mode!=='photos');if(r)openRoom(r.id,'analysis');","openBatchStudio().then(async()=>{if(!batchState.jobs.length){document.querySelector('#batchSample').click();await batchEnqueue();}});")
if recipe_preview:s=s.replace("const r=rooms.find(r=>r.mode!=='photos');if(r)openRoom(r.id,'analysis');","g6OpenRecipes();").replace('sceneforge-workspace-offline-20261027','sceneforge-recipes-offline-20261027')
if intake_preview:
 s=s.replace("const r=rooms.find(r=>r.mode!=='photos');if(r)openRoom(r.id,'analysis');","SceneForgeApp.videoIntake.open('video');").replace('sceneforge-workspace-offline-20261027','sceneforge-intake-offline-20261027')
 s=s.replace('<div id=\"videoIntake\"><p>', '<div id=\"videoIntake\"><p><b>Mô phỏng giao diện · không tải link hoặc gọi AI.</b></p><p>')
if v4_preview:
 sample={'id':'preview-v4-script','kind':'script','name':'Son kem lì · review nhanh','body':'[Cảnh 1 – cận mặt]\nMình thử cây son này trong hôm nay.\n\n[Cảnh 2 – cầm son]\nĐây là màu son trên tay mình dưới ánh sáng tự nhiên.\n\n[Cảnh 3]\nXem thêm thông tin sản phẩm trong giỏ hàng nhé!','beats':[],'source':'manual','productIds':[],'createdAt':1793088000000}
 opening='(async()=>{const lib=await recipeLibrary();if(!lib.items.some(r=>r.id===\"preview-v4-script\"))await putRecipe('+json.dumps(sample,ensure_ascii=False)+');await g6OpenRecipes();kv.selected=\"preview-v4-script\";kv.tab=\"body\";await kvDraw();})();'
 s=s.replace('g6OpenRecipes();},60);',''+opening+'},60);').replace('sceneforge-recipes-offline-20261027','sceneforge-recipes-v4-offline-20261027')
stem='SceneForge-MoPhong-AnhThanhVideo' if photo_preview else 'SceneForge-MoPhong-KhoKichBan-v4' if v4_preview else 'SceneForge-MoPhong-NhapVideo' if intake_preview else 'SceneForge-MoPhong-KhoKichBan' if recipe_preview else 'SceneForge-MoPhong-TaoAnhHangLoat' if batch_preview else 'SceneForge-MoPhong-HaiLuong'
out=r/('artifacts/'+stem+'.html');out.write_text(s);out.chmod(0o644)
with zipfile.ZipFile(r/('artifacts/'+stem+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 z.write(out,out.name)
 z.writestr('DOC-TRUOC.txt','Giải nén, mở '+out.name+' bằng Chrome/Edge.\nDữ liệu minh họa, không đăng nhập hoặc gen AI thật, không trừ credit.\n'+('Mở sẵn Kho kịch bản. Thử tìm, kéo vạch giữa cột, sửa/lưu, Dùng công thức và Thùng rác.\n' if recipe_preview else 'Chọn chế độ cần xem bằng thanh điều hướng.\n'))
(r/('artifacts/'+stem+'.zip')).chmod(0o644)
print(out,out.stat().st_size)
