"""Browser checks for shell automation endpoints and minimap selection; no cloud sends."""
from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT/'dist/web-demo')))
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1700,'height':1050});errors=[];posts=[]
  page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:posts.append(r.url) if r.method=='POST' and '/local-api/' in r.url else None)
  page.goto(f'http://127.0.0.1:{server.server_port}/?demo=1');page.wait_for_function('appBootReady&&rooms.length===7')
  ref=page.evaluate('rooms.find(r=>r.mode!=="photos").id');page.evaluate('(id)=>openRoom(id,"analysis")',ref)
  page.wait_for_function('!!document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.workspaceAutoPlan?.()')
  frame=page.locator('#workflowFrame').element_handle().content_frame()
  page.locator('#workspaceMore').click();expect(page.locator('#workspaceMoreMenu>[data-ws-extra]')).to_have_count(3);expect(page.locator('#workspaceMoreMenu')).not_to_contain_text('Chạy tự động sẽ làm gì');expect(page.locator('#workspaceMoreMenu [data-ws-extra=progress] small')).to_contain_text('clip xong');page.locator('#workspaceMore').click()
  page.locator('#workspaceAuto').click();expect(page.locator('[data-auto-scope=frames]')).to_have_attribute('aria-pressed','true');expect(page.locator('#workspaceAutoPanel li')).to_have_count(4);expect(page.locator('#workspaceAutoPanel')).not_to_contain_text('không tính phí');page.screenshot(path=str(ROOT/'artifacts/workspace-auto-reference.png'))
  # Stale content invalidates the pane's plan before invoking any step.
  frame.evaluate('project.settings.costs.lite=123');page.locator('#wsAutoRun').click();expect(page.locator('#wsAutoError')).to_contain_text('Dữ liệu đã đổi');page.locator('#wsAutoClose').click()
  # Deterministic CPU fixture: no provider is invoked; next manual gate must remain intact.
  frame.evaluate('''()=>{window.testCalls=[];SceneForgeWorkflow.runAnalysisPipeline=async opts=>{testCalls.push(opts);project.analysis.local={source:project.source.asset};project.analysis.pipeline6={};project.analysis.semantic=true;};delete project.analysis.local;delete project.analysis.semantic;delete project.analysis.aiRequest;delete project.analysis.pendingAI;}''')
  result=frame.evaluate('async()=>{const p=SceneForgeWorkflow.workspaceAutoPlan();return SceneForgeWorkflow.workspaceRunAutomatic("analysis",p.signature)}');assert 'đúng phạm vi' in result['message'];assert frame.evaluate('testCalls.length')==1;assert frame.evaluate('testCalls[0].allowGemini') is False
  # Reference stops at unapproved frame; it never bulk approves or generates over it.
  frame.evaluate('''()=>{window.originalApproved=frameApproved;frameApproved=()=>false;window.originalSlots=SFMediaNodes.slots;SFMediaNodes.slots=k=>k==='frame'?project.scenes.map(s=>({s,bucket:'done',has:true})):[];window.directCalls=[];directDialog=async(...args)=>directCalls.push(args);}''')
  result=frame.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("clips",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert 'duyệt ảnh khung' in result['message'];assert frame.evaluate('directCalls.length')==0
  # Only exact eligible missing slot reaches existing preflight; unknown blocks all new sends.
  frame.evaluate('''()=>{frameApproved=()=>true;SFMediaNodes.slots=k=>k==='frame'?project.scenes.map(s=>({s,bucket:'approved',has:true})):[{s:project.scenes[0],p:'a',bucket:'waiting',has:false}];}''')
  frame.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("frames",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert frame.evaluate('directCalls.length')==0
  frame.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("clips",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert frame.evaluate('directCalls[0][1].slots[0].part')=='a';assert frame.evaluate('directCalls[0][1].source')=='flow'
  frame.evaluate('''()=>{directCalls=[];SFMediaNodes.slots=k=>k==='frame'?project.scenes.map(s=>({s,bucket:'approved',has:true})):[{s:project.scenes[0],p:'a',bucket:'unknown',has:false}];}''')
  frame.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("clips",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert frame.evaluate('directCalls.length')==0
  # Remember only scope, per room. Reopening always shows the pane and current plan.
  page.locator('#workspaceAuto').click();page.locator('[data-auto-scope=analysis]').click();page.locator('#wsAutoRemember').check();page.locator('#wsAutoRun').click();expect(page.locator('#workspaceAutoPanel')).to_be_hidden();page.locator('#workspaceAuto').click();expect(page.locator('[data-auto-scope=analysis]')).to_have_attribute('aria-pressed','true');page.keyboard.press('Escape');expect(page.locator('#workspaceAutoPanel')).to_be_hidden()
  # Costs navigation must carry room scope; mixed monitoring rows remain isolated.
  page.locator('#workspaceMore').click();page.locator('[data-ws-extra=costs]').click();page.wait_for_function('monitorOpen&&!monitorLoading');assert page.evaluate('monitorRoom')==ref
  page.evaluate('''id=>{monitorData={rows:[{room_id:id,at:Date.now()/1000,source:'flow',cost:7,cost_unit:'credit'},{room_id:'other',at:Date.now()/1000,source:'flow',cost:99,cost_unit:'credit'}],exports:[]};}''',ref);assert page.evaluate('monitorFiltered().length')==1;assert page.evaluate('monitorStats(monitorFiltered()).spent')==7
  photo=page.evaluate('rooms.find(r=>r.mode==="photos"&&!r.editorInitialized).id');page.evaluate('(id)=>openRoom(id,"analysis")',photo);page.wait_for_function('currentRoom?.mode==="photos"&&!!document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.workspaceAutoPlan?.()')
  frame=page.locator('#workflowFrame').element_handle().content_frame();fl=page.frame_locator('#workflowFrame');fl.locator('[data-ws-tool=fit]').click()
  # Real pointer clicks select photo nodes; minimap follows and clears previous highlight.
  fl.locator('[data-node=script]>header').click();expect(fl.locator('#wsMinimap i.minimapSelected')).to_have_count(1);first=frame.evaluate('Array.from(document.querySelectorAll("#wsMinimap i")).findIndex(n=>n.classList.contains("minimapSelected"))')
  fl.locator('[data-node=storyboard]>header').click();frame.wait_for_function('(first)=>Array.from(document.querySelectorAll("#wsMinimap i")).findIndex(n=>n.classList.contains("minimapSelected"))!==first',arg=first);expect(fl.locator('#wsMinimap i.minimapSelected')).to_have_count(1);second=frame.evaluate('Array.from(document.querySelectorAll("#wsMinimap i")).findIndex(n=>n.classList.contains("minimapSelected"))');assert first!=second
  assert frame.evaluate('getComputedStyle(document.querySelector("#wsMinimap i.minimapSelected")).backgroundColor')=='rgb(212, 245, 60)'
  page.locator('#workspaceAuto').click();expect(page.locator('[data-auto-scope=frames]')).to_have_attribute('aria-pressed','true');expect(page.locator('#workspaceAutoPanel')).to_contain_text('Storyboard tổng');expect(page.locator('#workspaceAutoPanel')).not_to_contain_text('Đọc video trên máy');page.screenshot(path=str(ROOT/'artifacts/workspace-auto-photos.png'));page.locator('#workspaceAuto').click();expect(page.locator('#workspaceAutoPanel')).to_be_hidden()
  # Photo endpoint preserves whole-draft approval and doesn't generate when stop is before clips.
  frame.evaluate('''()=>{photoToolbarStep=()=>({key:'clips',label:'Tạo clip'});window.photoCalls=0;photoToolbarNext=async()=>{photoCalls++};}''')
  result=frame.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("frames",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert 'Dừng trước' in result['message'];assert frame.evaluate('photoCalls')==0
  frame.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("clips",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert frame.evaluate('photoCalls')==1
  page.set_viewport_size({'width':390,'height':844});page.locator('#workspaceAuto').evaluate('b=>b.click()');expect(page.locator('#workspaceAutoPanel')).to_be_visible();assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');panel=page.locator('#workspaceAutoPanel').bounding_box();assert panel['x']>=0 and panel['x']+panel['width']<=390
  assert not errors,errors;assert not posts,posts
  print('PASS shell three-item live menu, room-filtered costs, two mode-specific stop panes, stale-plan rejection, remembered scope without bypassing review, CPU-only preparation fixture, stop on unapproved frames/unknown clips, exact eligible clip preflight, photo whole-draft boundary, real pointer minimap selection, mobile bounds, no generation POST')
  browser.close()
finally:server.shutdown()
