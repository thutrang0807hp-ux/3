"""Storyboard -> batched prompts -> project board -> whole draft -> real editor.
Chromium + actual SQLite/library; deterministic provider transport, no online AI.
"""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64,json
from pathlib import Path
from playwright.sync_api import sync_playwright


def main():
 root=Path(__file__).resolve().parents[1]
 sample=root/'scripts/native-preview/assets/subtitle-sample.mp4'
 if sample.exists():video=sample.read_bytes()
 else:
  with tempfile.TemporaryDirectory(prefix='sf-story-video-')as fixture_dir:
   sample=Path(fixture_dir)/'sample.mp4'
   subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=180x320:rate=12:duration=8','-c:v','libx264','-pix_fmt','yuv420p',str(sample)],check=True)
   video=sample.read_bytes()
 with tempfile.TemporaryDirectory(prefix='sf-story-production-') as data:
  with socket.socket() as sock:
   sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];sent=[];responses={}
    page.on('pageerror',lambda e:errors.append(str(e)))
    status={'installed':True,'configured':True,'account_binding':True,'models':['veo-portrait'],'accounts':[],'per_account':2,'max_concurrency':3,'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'token'}}
    for service in ['gemini-chat','flow','muse']:
     page.route('**/local-api/'+service+'/status',lambda route:route.fulfill(json=status))
    def dispatch(route):
     body=route.request.post_data_json;sent.append(body);rid=body['request_id']
     if body['kind']=='text':
      source=json.loads(body['prompt'].split('\n',1)[1]);rows=[]
      for b in source['beats']:
       rows.append({k:b[k] for k in ['id','type','seconds','text']}|{'angle':'Medium','movement':'Slow push','visualPrompt':'Original product on table','motionPrompt':'One slow camera push','refRoles':['product'],'partPrompts':{p['id']:{'visualPrompt':'Original product','motionPrompt':'Slow push '+p['id']}for p in b['parts']}})
      responses[rid]={'id':rid,'state':'done','result':{'text':json.dumps({'beats':rows}),'account_id':'fixture-gemini'}}
     elif body['kind']=='video':
      responses[rid]={'id':rid,'state':'done','result':{'mime_type':'video/mp4','account_id':'fixture-flow'}}
     route.fulfill(json={'id':rid,'state':'submitted'})
    for service in ['gemini-chat','flow','muse']:
     page.route('**/local-api/'+service+'/jobs',dispatch)
     page.route('**/local-api/'+service+'/jobs/*',lambda route:route.fulfill(json=responses.get(route.request.url.rsplit('/',1)[-1],{'state':'unknown'})))
     page.route('**/local-api/'+service+'/files/*',lambda route:route.fulfill(body=video,content_type='video/mp4'))
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'story-fixture',name:'Story production',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoPrepareStoryboard==="function"')
    wf.evaluate('''async()=>{const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=800;canvas.getContext('2d').fillRect(0,0,1200,800);const image=canvas.toDataURL(),key=room.id+':story';await bridge.putFile(key,await(await fetch(image)).blob());draft.refs={product:{images:[{id:'p',name:'Original',image}]},person:{images:[]},background:{images:[]}};draft.idea='Giới thiệu sản phẩm';draft.voice.mode='native';draft.beats=Array.from({length:9},(_,i)=>({id:'b'+i,name:'Cảnh '+(i+1),type:'wide',seconds:4,text:'Xin chào.',clips:[]}));draft.providers={creative:'gemini',video:'flow',flowModel:'veo-portrait'};draft.flowJobs=[];draft.geminiJobs=[];draft.storyboardImages=[{id:'one',key,preview:image,name:'Overall',version:1}];draft.storyboardImage='one';await save();render();await photoToolbarRefresh(true);}''')
    assert wf.locator('[data-node=frames]').count()==0
    assert wf.locator('[data-node=bank] .productionSlot').count()==9
    assert wf.locator('.productionDirections').evaluate('(n)=>!n.open')
    wf.locator('#photoNext').click();wf.locator('#productionPrepareSend').wait_for();assert not sent
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoMediaBusy&&!photoProductionWorking')
    assert len(sent)==2 and all(j['kind']=='text' for j in sent)
    assert [len(json.loads(j['prompt'].split('\n',1)[1])['beats'])for j in sent]==[8,1]
    assert all(len(j['references'])==2 for j in sent)
    assert wf.evaluate("async refs=>{const r=refs.at(-1),b=await createImageBitmap(await(await fetch('data:'+r.mime_type+';base64,'+r.data)).blob());return b.width;}",sent[0]['references'])==1200
    # Restart with durable intents. Recovery never dispatches again.
    page.evaluate('async()=>{await flushFrames();await SceneForgeStorage.checkpoint();}')
    page.reload();page.wait_for_function('!!db&&SceneForgeStorage.state.active')
    page.evaluate("async()=>{document.querySelector('#shellDialog').close();await openRoom('story-fixture','analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoWorkflowReceive==="function"')
    wf.evaluate('async()=>{await photoWorkflowReceive();await photoWorkflowReceive();}')
    assert len(sent)==2
    assert wf.evaluate('photoPromptsCurrent()')
    assert wf.locator('#photoApplyChat').count()==0
    assert wf.evaluate('draft.beats.every(b=>b.partPrompts.a.motionPrompt==="Slow push a")')
    # Sending videos still needs one explicit confirmation, after displaying count.
    wf.locator('#photoNext').click();wf.locator('#photoConfirmFlow').wait_for();assert len(sent)==2
    assert '9 yêu cầu' in wf.locator('#photoConfirmFlow').inner_text()
    wf.locator('#photoConfirmFlow').click();wf.wait_for_function('!photoMediaBusy')
    assert len(sent)==11
    assert all(len(j['references'])==1 for j in sent[2:])
    wf.evaluate('async()=>{await photoWorkflowReceive();}')
    assert wf.evaluate('photoDraftCounts().ready')==9
    assert wf.evaluate('photoToolbarCounts().approved')==0
    wf.evaluate("()=>{view.z=.9;photoToolbarFocus('bank');}");wf.locator('#photoViewport').screenshot(path=str(root/'artifacts/photo-story-production-board.png'))
    assert wf.locator('[data-node=frames]').count()==0
    # Regenerate only one part. Old clip retained until whole-draft final.
    before=wf.evaluate("photoLatest(draft.beats[0],'a').id")
    wf.evaluate("async()=>{await photoSlotDialog('b0','a');}")
    wf.locator('#photoPartMotion').fill('A different slow camera push')
    wf.locator('#photoSavePartText').click();wf.wait_for_function('photoPromptsCurrent()')
    wf.locator('#photoRegenerateSlot').click()
    assert '1 yêu cầu' in wf.locator('#photoConfirmFlow').inner_text()
    wf.locator('#photoConfirmFlow').click();wf.wait_for_function('!photoMediaBusy');wf.evaluate('async()=>{await photoWorkflowReceive();}')
    assert len(sent)==12
    assert wf.evaluate('draft.beats[0].clips.length')==2
    assert wf.evaluate("photoLatest(draft.beats[0],'a').id")!=before
    wf.evaluate('''async()=>{try{await photoRunClips();throw Error('Unexpected second send');}catch(e){if(e.message==='Unexpected second send')throw e;}}''')
    assert len(sent)==12
    # Incomplete draft marks a gap rather than sliding later clips left.
    wf.evaluate("async()=>{draft.beats[8].clips[0].duration=1;await photoPreviewDraft();}")
    assert wf.locator('#productionFinal').is_disabled()
    assert wf.evaluate('photoPreviewSession.payload.clips.at(-1).missing')
    assert wf.evaluate('photoPreviewSession.payload.clips.at(-1).start')==32
    wf.locator('#closePhotoDialog').click()
    wf.evaluate('''async()=>{draft.beats[8].clips[0].duration=12;await save();await photoPreviewDraft();}''')
    (root/'artifacts').mkdir(exist_ok=True);wf.locator('#photoDialog').screenshot(path=str(root/'artifacts/photo-story-production-review.png'))
    wf.locator('#productionPlay').click();wf.wait_for_function('photoPreviewSession.time>.3')
    assert wf.locator('#productionVideo').evaluate('(v)=>!v.paused')
    wf.locator('#productionPlay').click()
    # No cleanup on playback / opening the slot.
    assert wf.evaluate('draft.beats[0].clips.length')==2
    wf.locator('[data-production-fix="0"]').click();wf.locator('#photoRegenerateSlot').wait_for()
    assert wf.locator('#photoApproveSlot').count()==0
    assert wf.evaluate('photoPreviewSession===null')
    wf.locator('#closePhotoDialog').click()
    # Stale custom captions or a missing voice stop final preflight before cleanup.
    wf.evaluate("async()=>{draft.post.captions=true;draft.post.cues=[];draft.post.cueSignature='stale';try{await photoPreviewDraft();throw Error('Unexpected preview');}catch(e){if(e.message==='Unexpected preview')throw e;}draft.post.captions=false;}")
    assert wf.evaluate('draft.beats[0].clips.length')==2
    # Final confirmation uses the actual existing cleanup transaction then real editor import.
    wf.evaluate('async()=>{await photoPreviewDraft();}')
    wf.locator('#productionFinal').click()
    page.wait_for_function("!!document.querySelector('#standaloneEditorDemo')?.contentWindow.SceneForgeEditor")
    ed=page.locator('#standaloneEditorDemo').element_handle().content_frame()
    ed.wait_for_function('SceneForgeEditor.getState().items.filter(i=>i.kind==="video").length===9')
    items=ed.evaluate('SceneForgeEditor.getState().items.filter(i=>i.kind==="video")')
    assert [c['start'] for c in items]==list(range(0,36,4))
    assert sum(c['duration']for c in items)==36
    canonical=page.evaluate("SceneForgeApp.getState().rooms.find(r=>r.id==='story-fixture').photoDraft")
    assert len(canonical['beats'][0]['clips'])==1
    assert len(sent)==12
    # Opened previews cannot finalize a later revision, even when only music settings change.
    page.evaluate("async()=>{await openRoom('story-fixture','analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoPreviewDraft==="function"')
    wf.evaluate('async()=>{await photoPreviewDraft();draft.post.musicVolume=.3;}')
    wf.locator('#productionFinal').click();wf.wait_for_function('!photoProductionWorking')
    assert 'đã đổi' in wf.locator('#productionFinalError').inner_text()
    wf.locator('#closePhotoDialog').click()
    # A result for an older storyboard/script is kept separately, never applied.
    wf.evaluate("async()=>{draft.flowJobs=[];draft.geminiJobs=[];draft.production={version:1,promptJobs:[]};draft.beats=[{id:'stale',name:'Stale',type:'wide',seconds:4,text:'Câu ban đầu.',clips:[]}];await save();render();await photoPrepareStoryboard();}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoMediaBusy&&!photoProductionWorking')
    assert len(sent)==13,(len(sent),wf.evaluate('({error:photoProductionState().error,jobs:draft.geminiJobs,active:parent.SceneForgeStorage.state.active})'))
    wf.evaluate("async()=>{draft.beats[0].text='Nội dung mới.';await photoWorkflowReceive();}")
    assert wf.evaluate("draft.geminiJobs[0].stale&&draft.geminiJobs[0].state==='discarded'&&!photoPromptsCurrent()&&!draft.beats[0].partPrompts")
    assert len(sent)==13,(len(sent),wf.evaluate('({error:photoProductionState().error,jobs:draft.geminiJobs,active:parent.SceneForgeStorage.state.active})'))
    # Ambiguous POST is one attempted dispatch; reopening or polling never replays it.
    page.unroute('**/local-api/gemini-chat/jobs',dispatch)
    def ambiguous(route):
     sent.append(route.request.post_data_json);route.fulfill(status=504,json={'detail':'Fixture timeout after send'})
    page.route('**/local-api/gemini-chat/jobs',ambiguous)
    wf.evaluate('async()=>{await photoPrepareStoryboard();}')
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoMediaBusy&&!photoProductionWorking')
    assert len(sent)==14
    assert wf.evaluate("draft.geminiJobs.at(-1).state==='unknown'")
    wf.locator('#closePhotoDialog').click();wf.evaluate('async()=>{await photoWorkflowReceive();await photoWorkflowReceive();}')
    assert len(sent)==14
    assert not errors,errors
    browser.close()
   print('PASS storyboard production: 8+1 prompt batches; original refs + one full storyboard; zero sends before confirmation; restart/repeated read no replay; automatic validated prompt application; 9 clip receipts; unified project board; no per-clip approval for sequential draft playback; exact-slot regeneration retains prior version; skips ready unapproved clips; missing gap, stale captions, stale prompt results, changed preview and ambiguous send; final confirmation cleans alternatives and imports real 36s editor timeline. Actual Chromium/SQLite/storage, provider fixtures only.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()

if __name__=='__main__':main()
