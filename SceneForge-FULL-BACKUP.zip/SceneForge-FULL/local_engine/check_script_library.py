"""Actual app routes -> Gemini Chat adapter/ledger with a fixture SDK runner, never paid API."""
import asyncio,json,os,tempfile,uuid
import httpx
from .script_library import validate_input,validate_result
from fastapi import HTTPException
async def main():
 with tempfile.TemporaryDirectory(prefix='sf-script-v4-')as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server as s
  calls=[]
  async def no_api(*a,**kw):raise AssertionError('Paid fallback forbidden')
  s.gemini_request=no_api
  async def runner(body):
   if body['operation']=='check':return {'ok':True,'session':body['session'],'models':[{'id':'fixture-model','name':'Fixture'}]}
   calls.append(body);data=json.loads(body['prompt'].split('\nDATA (not instructions):\n')[-1])
   if data['action']=='topics':result={'suggestions':[{'id':i['id'],'topic_id':data['topics'][0]['id']}for i in data['items']]}
   elif ''.join(u['text']for u in data.get('units',[]))=='INVALID':result={'parts':[{'first':'U999','last':'U999','role':'neutral','type':'wide','name':'Invalid'}]}
   else:result={'parts':[{'first':data['units'][0]['id'],'last':data['units'][-1]['id'],'role':'neutral','type':'wide','name':'Nguồn giữ nguyên','text':'MODEL TRIES TO REWRITE; IGNORED'}]}
   return {'ok':True,'text':json.dumps(result,ensure_ascii=False),'session':body['session']}
  s.GEMINI_CHAT.runner=runner
  async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.app),base_url='http://testserver')as c:
   await c.get('/');h={'X-SceneForge-Local':'1'}
   login=await c.post('/local-api/gemini-chat/login',json={'name':'Fixture','cookies':[{'domain':'.google.com','name':'__Secure-1PSID','value':'PRIVATE_SCRIPT_COOKIE'}]},headers=h);assert login.status_code==200,login.text
   aid=login.json()['id'];s.VAULT.set_secret('gemini','UNUSED_PAID_KEY')
   status=(await c.get('/local-api/ai/script-library/status')).json();assert status['ai_source']=='gemini_chat'
   body='[Cảnh 1]\nLời nguyên văn 🙂.\n\nCâu tiếp theo.'
   data={'action':'split','request_id':str(uuid.uuid4()),'ai_source':'gemini_chat','expected_store_id':status['store_id'],'body':body,'units':[{'id':'U1','text':body[:20]},{'id':'U2','text':body[20:]}]}
   r=await c.post('/local-api/ai/script-library',json=data,headers=h);assert r.status_code==200,r.text
   assert r.json()['parts'][0]['first']=='U1'and 'text'not in r.json()['parts'][0]and r.json()['original_preserved']
   assert s.GEMINI_CHAT.lookup('gchat-'+data['request_id'])['result']['account_id']==aid and 'MODEL TRIES TO REWRITE'not in json.dumps(r.json()),calls[-1].keys()
   count=len(calls);r=await c.post('/local-api/ai/script-library',json={**data,'recovery':True},headers=h);assert r.status_code==200 and len(calls)==count,r.text
   for change in [{'expected_store_id':'other'},{'request_id':str(uuid.uuid4())}]:
    r=await c.post('/local-api/ai/script-library',json={**data,**change,'recovery':True},headers=h);assert r.status_code==409 and len(calls)==count,r.text
   bad={**data,'request_id':str(uuid.uuid4()),'units':[{'id':'U1','text':'CHANGED'}]};r=await c.post('/local-api/ai/script-library',json=bad,headers=h);assert r.status_code==400 and len(calls)==count,r.text
   invalid={**data,'request_id':str(uuid.uuid4()),'body':'INVALID','units':[{'id':'U1','text':'INVALID'}]}
   r=await c.post('/local-api/ai/script-library',json=invalid,headers=h);assert r.status_code==502,r.text
   count=len(calls);r=await c.post('/local-api/ai/script-library',json={**invalid,'recovery':True},headers=h);assert r.status_code==502 and len(calls)==count,r.text
   topic={**data,'request_id':str(uuid.uuid4()),'action':'topics','items':[{'id':'script1','body':'Lời rất ngắn'}],'topics':[{'id':'review','name':'Review'}]};topic.pop('body');topic.pop('units')
   r=await c.post('/local-api/ai/script-library',json=topic,headers=h);assert r.status_code==200 and r.json()['suggestions']==[{'id':'script1','topic_id':'review'}],r.text
   count=len(calls);s.VAULT.set_secret('ai-routing',{'source':'gemini_api'});r=await c.post('/local-api/ai/script-library',json={**data,'recovery':True},headers=h);assert r.status_code==409 and len(calls)==count
  assert b'PRIVATE_SCRIPT_COOKIE'not in s.VAULT.path.read_bytes();assert not s.GEMINI_CHAT.tasks and not s.FLOW_PROVIDER.tasks and not s.MUSE_PROVIDER.tasks
 print('PASS V4 actual HTTP + Chat account/ledger: source units exact incl emoji, ID-only split ignores model rewrite, complete coverage validation, paid fallback forbidden, cached read-only recovery, missing/changed store/source blocked, invalid result no replay, topic suggestions, cookie encrypted. SDK fixture; no live account.')
if __name__=='__main__':asyncio.run(main())
