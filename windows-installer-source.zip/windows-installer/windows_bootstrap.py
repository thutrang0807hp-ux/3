"""Bundled-Python entry; no core pip installation/download during ordinary startup."""
import os,sys,subprocess
from pathlib import Path

def browser():
    if os.environ.get('SCENEFORGE_BROWSER'):return
    for root in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
        base=os.environ.get(root)
        if not base:continue
        for relative in ('Google/Chrome/Application/chrome.exe','Microsoft/Edge/Application/msedge.exe'):
            candidate=Path(base)/relative
            if candidate.is_file():
                os.environ['SCENEFORGE_BROWSER']=str(candidate);return

def main():
    app=Path(__file__).resolve().parent
    os.chdir(app)
    if str(app)not in sys.path:sys.path.insert(0,str(app))
    if '--setup-whisper'in sys.argv[1:]:
        print('Installing optional CPU tools and Whisper base. Internet required; model is about 150 MB.',flush=True)
        subprocess.run([sys.executable,'-E','-s','-X','utf8','-m','pip','install','-r',str(app/'local_engine/requirements-cpu.txt')],check=True)
        subprocess.run([sys.executable,'-E','-s','-X','utf8','-m','local_engine.prepare_whisper','--model','base','--download'],check=True)
        print('Whisper installed. FFmpeg/ffprobe are also required for video transcription. Restart SceneForge.',flush=True)
        input('Press Enter to close. ');return
    browser()
    os.environ['SCENEFORGE_OPEN_BROWSER']='0'if os.environ.get('SCENEFORGE_NO_BROWSER')=='1'else'1'
    from local_engine.__main__ import main as run
    run()

if __name__=='__main__':main()
