$ErrorActionPreference = 'Stop'
$version = '@VERSION@'
$expectedHash = '@HASH@'
$payloadSize = [long]'@SIZE@'
$destination = Join-Path $env:LOCALAPPDATA "SceneForge\releases\$version"
$staging = $destination + '.install-' + [guid]::NewGuid().ToString('N')
$archive = Join-Path ([IO.Path]::GetTempPath()) ('sceneforge-' + [guid]::NewGuid().ToString('N') + '.zip')
try {
    $marker = Join-Path $destination 'installation.json'
    if (Test-Path -LiteralPath $destination) {
        if (!(Test-Path -LiteralPath $marker) -or ((Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json).payload_sha256 -ne $expectedHash)) {
            throw 'This version folder already exists but is incomplete/different. No files were overwritten.'
        }
    } else {
        Write-Host 'Checking and extracting the bundled application...'
        $source = [IO.File]::OpenRead($env:SF_INSTALL_FILE)
        $output = [IO.File]::Create($archive)
        try {
            if ($source.Length -le $payloadSize) { throw 'Installer is truncated.' }
            [void]$source.Seek(-$payloadSize, [IO.SeekOrigin]::End)
            $source.CopyTo($output)
        } finally { $output.Dispose(); $source.Dispose() }
        if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { throw 'Installer integrity check failed. Download the file again.' }
        [void](New-Item -ItemType Directory -Path $staging)
        Expand-Archive -LiteralPath $archive -DestinationPath $staging
        foreach ($required in @('SceneForge.exe','runtime\python.exe','app\windows_bootstrap.py','app\dist\web-demo\index.html')) {
            if (!(Test-Path -LiteralPath (Join-Path $staging $required))) { throw "Missing application file: $required" }
        }
        @{version=$version;payload_sha256=$expectedHash;installed_at=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $staging 'installation.json') -Encoding UTF8
        Move-Item -LiteralPath $staging -Destination $destination
    }
    $exe = Join-Path $destination 'SceneForge.exe'
    # Shortcuts are convenient, not a prerequisite for a valid installation.
    try {
        $ws = New-Object -ComObject WScript.Shell
        $desktop = [Environment]::GetFolderPath('Desktop')
        if ($desktop) {
            $link = $ws.CreateShortcut((Join-Path $desktop 'SceneForge.lnk'))
            $link.TargetPath=$exe; $link.WorkingDirectory=$destination; $link.Save()
        }
        $menu=Join-Path ([Environment]::GetFolderPath('Programs')) 'SceneForge'
        [void](New-Item -ItemType Directory -Path $menu -Force)
        foreach ($item in @(@('SceneForge',''), @('SceneForge - Cai Whisper','--setup-whisper'))) {
            $link=$ws.CreateShortcut((Join-Path $menu ($item[0]+'.lnk')))
            $link.TargetPath=$exe; $link.Arguments=$item[1]; $link.WorkingDirectory=$destination; $link.Save()
        }
    } catch { Write-Host "Shortcut was not created: $_. Open $exe directly." }
    Write-Host "Installed: $destination"
    Write-Host 'Starting SceneForge. Close its console window when finished.'
    if ($env:SCENEFORGE_INSTALL_TEST -ne '1') { Start-Process -FilePath $exe -WorkingDirectory $destination }
} catch {
    Write-Host "SceneForge installation failed: $_" -ForegroundColor Red
    exit 1
} finally {
    if (Test-Path -LiteralPath $archive) { Remove-Item -LiteralPath $archive }
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse }
}
