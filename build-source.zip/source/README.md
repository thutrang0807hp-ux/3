# SceneForge · mã nguồn đầy đủ · 28/10/2026

Đây là gói để chuyển sang máy/môi trường khác tiếp tục phát triển. Bao gồm frontend có thể chỉnh sửa, backend Python, tài nguyên giao diện/editor, tài liệu và thiết kế gốc, kiểm thử, cùng source làm bộ cài Windows. Gói không kèm môi trường Python/Node đã cài, model AI, dữ liệu dự án cá nhân, key/cookie hoặc tài khoản.

Đọc `BAT-DAU-TU-DAY.md` để chạy/build. Đọc `NGU-CANH-BAN-GIAO.md` trước khi sửa tính năng. `MANIFEST-SHA256.json` ghi kích thước và SHA-256 của từng file.

**Kho kịch bản v5 đang tạm hoãn theo yêu cầu người dùng.** ZIP thiết kế v5 được giữ trong `design/original-uploads/`; nó không phải bằng chứng tính năng v5 đã được triển khai.

- Frontend nguồn: `scripts/recovered`, `scripts/app-shell`, `scripts/workflow`, `scripts/photo-studio`, `scripts/shared` và các thư mục tính năng khác trong `scripts`.
- Trang đã dựng và tài nguyên chạy: `dist/web-demo`.
- Backend và requirements: `local_engine`.
- Source installer Windows: `scripts/windows-installer`.
- Tài liệu và test reports: `docs`, `docs/checks`.
- Thiết kế/tệp người dùng đã gửi: `design`, `design/original-uploads/INDEX.json`.
- Thông tin file EXE đã phát hành và link tải: `releases/windows-release.json`.

Bộ cài Windows đã kiểm trên Windows build 26100: cài, mở backend bằng Python kèm theo, mở shell/cả hai canvas trong Chrome, chạy lại dùng chung instance và cài lại không thay thư mục đã cài. Kiểm đó không chứng nhận tạo ảnh/video bằng tài khoản online. Các bài kiểm prompt/provider dùng fixture; đọc báo cáo để phân biệt.
