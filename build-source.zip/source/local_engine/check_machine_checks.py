"""Real machine output and serialization; no provider requests."""
import asyncio,os,tempfile
from pathlib import Path
from unittest.mock import patch
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-checks-')
from fastapi.testclient import TestClient
from local_engine import server,machine_checks
with TestClient(server.app)as client:
 client.get('/')  # obtain the document's loopback session cookie
 assert client.post('/local-api/checks/self-test',json={}).status_code==403
 r=client.post('/local-api/checks/self-test',json={},headers={'X-SceneForge-Local':'1'})
 assert r.status_code==200,r.text
 report=r.json();mp4=next(c for c in report['checks']if c['id']=='mp4');assert mp4['state']=='passed',mp4
 assert mp4['measurements']['bytes']>1000 and report['provider_requests']==0
 assert not list(server.DATA.glob('machine-check-*'))
 assert client.get('/local-api/checks/last').json()['report']==report
async def checks():
 with tempfile.TemporaryDirectory()as d,patch.object(machine_checks.shutil,'which',return_value=None):
  report=await machine_checks.measure_machine(Path(d));assert next(c for c in report['checks']if c['id']=='mp4')['state']=='unavailable'
 server.VAULT.set_secret('ai-routing',{'source':'gemini_api'});server.VAULT.set_secret('gemini','fixture-not-a-real-key')
 active=peak=0
 async def fake(*args):
  nonlocal active,peak
  active+=1;peak=max(peak,active);await asyncio.sleep(.03);active-=1;return {}
 with patch.object(server,'gemini_request',fake):await asyncio.gather(server.gemini({},'one'),server.gemini({},'two'))
 assert peak==1,peak
asyncio.run(checks())
print('PASS real H264/AAC encode/probe/decode, cleanup, encrypted persisted report, missing tools, POST guard; global Gemini serialization with mocked transport. No provider calls.')
