"""Regression: real browser intercepted pages + actual HTTP/ledger/library, no online AI."""
import asyncio,base64,io,json,os,tempfile,uuid
from pathlib import Path
from PIL import Image
import httpx
from .web_images import filtered_state,SITES,conversation_url
from .account_pool import AccountPool
async def main():
 with tempfile.TemporaryDirectory(prefix='sf-chat-reliability-')as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server as s
  from playwright.async_api import async_playwright
  service=s.WEB_IMAGES;site=SITES['chatgpt'];mode=['images'];clicks=[];urls=[]
  for color in ['red','green','blue','yellow']:
   b=io.BytesIO();Image.new('RGB',(256,256),color).save(b,format='PNG');urls.append('data:image/png;base64,'+base64.b64encode(b.getvalue()).decode())
  async def browser(headless=False):
   pw=await async_playwright().start();b=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);original=b.new_context
   async def context(**kw):
    c=await original(**kw)
    async def route(r):
     if r.request.url.endswith('/fixture-sent'):clicks.append(1);return await r.fulfill(body='ok')
     if r.request.resource_type!='document':return await r.abort()
     note='<button>Log in</button>'if mode[0]=='auth'else'<div role="alert">You have reached the image generation limit</div>'if mode[0]=='quota'else''
     html='<textarea id="prompt-textarea"></textarea><button data-testid="send-button">Send</button><div data-message-author-role="assistant"></div>'+note+'''<script>document.querySelector('button[data-testid="send-button"]').onclick=()=>{fetch('/fixture-sent',{method:'POST'});history.pushState({},'', '/c/fixture-conversation?secret=DO_NOT_SAVE#secret');const a=document.querySelector('[data-message-author-role]'),busy=document.createElement('div');busy.dataset.generationState='pending';document.body.append(busy);const urls='''+json.dumps(urls)+''';const add=url=>{const i=new Image();i.alt='Generated image';i.src=url;a.append(i);};add(urls[0]);setTimeout(()=>{urls.slice(1).forEach(add);busy.remove();},350);};</script>'''
     await r.fulfill(body=html,content_type='text/html')
    await c.route('**/*',route);return c
   b.new_context=context;return pw,b
  service.new_browser=browser
  login=await service.login('chatgpt','Fixture A');entry=service.logins[login['login_id']]
  await entry['context'].add_cookies([{'name':'session_token','value':'CHAT_SECRET','url':site['url']},{'name':'SID','value':'GOOGLE_SECRET','url':'https://accounts.google.com/'}])
  aid=(await service.save_login(login['login_id']))['id'];state=s.VAULT.secret('web-image-session:'+aid);assert [x['value']for x in state['cookies']]==['CHAT_SECRET']
  assert filtered_state({'cookies':[],'origins':[{'origin':'https://accounts.google.com','localStorage':[{'name':'token','value':'SSO'}]}]},site)['origins']==[]
  async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.app,client=('127.0.0.1',1234)),base_url='http://127.0.0.1:8765',headers={'X-SceneForge-Local':'1','Origin':'http://127.0.0.1:8765'})as c:
   await c.get('/')
   def body():return {'source':'chatgpt','request_id':'webimage-'+str(uuid.uuid4()),'prompt':'A product','kind':'image','aspect':'1:1','confirm_send':True,'selection_token':service.status('chatgpt')['selection']['token'],'product_id':'fixture-product'}
   async def submit():
    b=body();r=await c.post('/local-api/web-images/jobs',json=b);assert r.status_code==200,r.text;await asyncio.gather(*list(service.tasks.values()));return b,(await c.get('/local-api/web-images/jobs/'+b['request_id'])).json()
   b,record=await submit();assert record['state']=='done',record;images=record['result']['images'];assert len(images)==4
   assert record['conversation_url']=='https://chatgpt.com/c/fixture-conversation'
   assert service.row(aid)['generation_verified']is True and service.row(aid)['successes']==1
   with s.LIBRARY.db()as db:protected=s.LIBRARY.lifecycle.protected(db,False)
   for index,image in enumerate(images):
    response=await c.get('/local-api/web-images/files/'+b['request_id'],params={'index':index});assert response.status_code==200
    with Image.open(io.BytesIO(response.content))as im:assert im.size==(256,256)
    assert image['result_hash']in protected and not(service.root/image['file']).exists()
   assert len(clicks)==1;assert(await c.post('/local-api/web-images/jobs',json=b)).status_code==200;assert len(clicks)==1
   assert(await c.get('/local-api/web-images/files/'+b['request_id'],params={'index':4})).status_code==404
   mode[0]='auth';b,record=await submit();assert record['state']=='failed'and record['error_code']=='AUTH_REQUIRED';assert service.row(aid)['state']=='expired'and not service.row(aid)['session_verified'];assert len(clicks)==1
   # Balanced selection can recover from a broken old selection without mutating it into ready.
   other=str(uuid.uuid4());s.VAULT.put('accounts',{'id':other,'service':'chatgpt','name':'Fixture B','enabled':True,'active':False,'state':'ready','session_verified':True})
   r=await c.post('/local-api/web-images/chatgpt/selection',json={'mode':'balanced','account_id':aid});assert r.status_code==200,r.text;assert r.json()['selection']['permitted']==[other]
   # Explicit quota deactivates eligibility, but a later session check must not erase quota.
   row=service.row(aid);row.update(state='ready',session_verified=True);s.VAULT.put('accounts',row);AccountPool(s.VAULT,'chatgpt').select({'mode':'selected','account_id':aid});mode[0]='quota'
   b,record=await submit();assert record['state']=='failed'and record['error_code']=='QUOTA_EXHAUSTED';assert service.row(aid)['state']=='exhausted';assert len(clicks)==1
   mode[0]='images';await service.check(aid);assert service.row(aid)['state']=='exhausted'
   response=await c.post('/local-api/accounts/allow-retry',json={'id':aid,'confirm':True});assert response.status_code==200,response.text;assert service.row(aid)['state']=='ready'and len(clicks)==1
   # A network failure after dispatch is unknown, never auto-rotated or replayed.
   row=service.row(aid);row.update(state='ready',session_verified=True);s.VAULT.put('accounts',row)
   async def uncertain(rid,payload,path,sent):sent();raise OSError('PRIVATE_NETWORK_TOKEN')
   service.runner=uncertain;b,record=await submit();assert record['state']=='unknown'and service.row(aid)['state']=='ready';r=await c.post('/local-api/web-images/jobs',json=b);assert r.status_code==409
   assert all(secret not in json.dumps(s.VAULT.rows('logs'))for secret in ['CHAT_SECRET','GOOGLE_SECRET','PRIVATE_NETWORK_TOKEN'])
   # If canonical promotion fails halfway, keep EVERY original, not only the first.
   async def two_images(rid,payload,path,sent):
    sent();paths=[path,service.root/(rid+'.1.partial')]
    for index,target in enumerate(paths):target.write_bytes(base64.b64decode(urls[index].split(',')[1]))
    return paths
   service.runner=two_images;original=s.LIBRARY.add_file;count=[0]
   def failing_capture(*args,**kw):
    count[0]+=1
    if count[0]==2:raise OSError('fixture full disk during second promotion')
    return original(*args,**kw)
   s.LIBRARY.add_file=failing_capture
   try:b,record=await submit()
   finally:s.LIBRARY.add_file=original
   assert record['state']=='done'and len(record['result']['images'])==2
   for index,image in enumerate(record['result']['images']):
    assert not image.get('result_hash')and(service.root/image['file']).exists()
    assert(await c.get('/local-api/web-images/files/'+b['request_id'],params={'index':index})).status_code==200
   assert conversation_url('https://chatgpt.com/c/ok?token=private',site)=='https://chatgpt.com/c/ok'
   assert conversation_url('https://evil.example/c/id',site)is None
  await service.close()
 print('PASS 4 delayed images/one send -> HTTP original downloads -> all hashes protected, backend duplicates removed, partial promotion failure keeps every original; encrypted service-only session, safe conversation URL, expired/quota account states, quota survives session check, balanced fallback selection, unknown network no retry or account rotation. Real Chromium/SQLite/library with intercepted service; no online generation.')
if __name__=='__main__':asyncio.run(main())
