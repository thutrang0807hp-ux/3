"""Browser integration of staged prompts, local voice, heard captions and handoff."""
import base64,io,json,hashlib,subprocess,tempfile,wave
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from threading import Thread
from PIL import Image
from playwright.sync_api import sync_playwright

def main():
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    root=Path(__file__).resolve().parents[1]
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')))
    Thread(target=server.serve_forever,daemon=True).start()
    picture=io.BytesIO();Image.new('RGB',(90,160),'red').save(picture,format='PNG');image='data:image/png;base64,'+base64.b64encode(picture.getvalue()).decode()
    wav=io.BytesIO()
    with wave.open(wav,'wb')as out:out.setparams((1,2,16000,0,'NONE','not compressed'));out.writeframes(b'\0'*12800)
    state={'tts':0,'speech':0,'jobs':{},'writes':[],'cpu_uploads':0}
    def route(r):
        path=r.request.url.split('/local-api/')[1]
        if path=='analysis/local/capabilities':data={'available':True,'binary_upload':True,'max_bytes':500*1024**2,'max_seconds':600,'ocr':False,'whisper_model':True,'whisper':False}
        elif path.startswith('analysis/local/upload?'):
            assert r.request.headers['content-type']=='application/octet-stream'and r.request.post_data_buffer and 'transcribe=false'in path;state['cpu_uploads']+=1
            data={'id':'cpu-fixture','state':'done','result':{'source_sha256':hashlib.sha256(r.request.post_data_buffer).hexdigest(),'scenes':[{'start':0,'end':.4,'thumbs':[image],'warnings':[],'faces':{'detected':False},'ocr':[],'camera':{'reliable':False,'labels':[]}}],'cuts':[0,.4],'transcript':[],'speech':{'state':'no_audio','audio_present':False},'ocr_state':'not_requested'}}
        elif path=='tts/status':data={'model_ready':True,'voices':[{'id':'fixture-voice','label':'Giọng fixture'}]}
        elif path=='tts':state['tts']+=1;data={'url':'/local-api/media/fixture.wav','duration':.4,'segments':[{'id':'voice','start':0,'end':.4}]}
        elif path=='media/fixture.wav':return r.fulfill(body=wav.getvalue(),content_type='audio/wav')
        elif path=='speech/capabilities':data={'available':True}
        elif path=='speech/transcribe':state['speech']+=1;data={'segments':[{'start':0,'end':.3,'text':'Phụ đề từ âm thanh'}],'duration':.4}
        elif path=='gemini-chat/status':data={'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'fixture-choice'}}
        elif path=='gemini-chat/jobs':
            body=r.request.post_data_json;state['writes'].append(body)
            if 'Write one initial-frame prompt'in body['prompt']:result={'promptFrame':{'vi':'Khung sản phẩm thử','en':'Fixture product frame'}}
            else:result={group:{lang:{key:'Fixture '+key for key in keys}for lang in('vi','en')}for group,keys in [('visual',['person','product','scale','composition','background','lighting']),('motion',['camera','initial','action','final'])]}
            state['jobs'][body['request_id']]={'state':'done','result':{'text':json.dumps(result)}};data={'state':'submitted'}
        elif path.startswith('gemini-chat/jobs/'):data=state['jobs'][path.split('/')[-1]]
        else:data={}
        r.fulfill(json=data)
    try:
        with tempfile.TemporaryDirectory()as tmp,sync_playwright()as pw:
            file=Path(tmp)/'fixture.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=red:s=90x160:r=10:d=0.4','-c:v','libx264',str(file)],check=True)
            browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.route('**/local-api/**',route)
            page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html?room=voice-room');page.wait_for_function('!!window.SceneForgeWorkflow')
            page.evaluate('''image=>{project=blankProject();project.id='voice-room';project.source={poster:image,duration:.4};project.scenes=[sceneRecord(0,.4,0,[image])];project.refs.product.images=[{image}];project.scenes[0].refsUsed=['product'];project.script=[{id:'original',start:0,end:.4,original:'原文',translation:'Bản dịch',newText:'Lời tôi sửa'}];render();}''',image)
            page.evaluate("actions['voice-over']()");page.locator('#voGenerate:not([disabled])').wait_for();page.locator('#voFromScript').click();assert page.locator('#voText').input_value()=='Lời tôi sửa';page.locator('#voGenerate').click();page.wait_for_function('voiceOverDraft().versions.length===1');assert state['tts']==1
            page.evaluate("actions['production-caption-audio']()");page.locator('#applyAudioCaptions').wait_for();assert page.evaluate('!project.merge.captionDraft');page.locator('#applyAudioCaptions').click();page.wait_for_function('!document.querySelector("#modal").open');assert page.evaluate("project.merge.captionDraft[0].text==='Phụ đề từ âm thanh'&&project.script[0].original==='原文'&&project.script[0].newText==='Lời tôi sửa'");assert state['speech']==1
            page.evaluate('referencePromptDialog()');page.locator('#referencePromptStage').select_option('video');page.locator('#referencePromptPrepare').click();page.wait_for_function('document.querySelector("#referencePromptError").textContent.includes("duyệt ảnh khung")');assert not state['writes']
            page.locator('#referencePromptStage').select_option('image');page.locator('#referencePromptPrepare').click();page.locator('#sendReferencePrompt').click();page.wait_for_function('project.referencePromptJobs[0]?.state==="submitted"');assert len(state['writes'][0]['references'])==2
            page.evaluate('recoverReferencePrompts()');page.locator('#applyReferencePrompt').click();page.wait_for_function('!document.querySelector("#modal").open');assert page.evaluate('project.scenes[0].promptFrame.en==="Fixture product frame"&&!frameApproved(project.scenes[0])')
            page.evaluate('''async image=>{const b=await(await fetch(image)).blob();await addFrame(new File([b],'frame.png',{type:'image/png'}),project.scenes[0].id);approve(project.scenes[0]);}''',image)
            assert page.evaluate('frameApproved(project.scenes[0])')
            page.evaluate('referencePromptDialog()');page.locator('#referencePromptStage').select_option('video');page.locator('#referencePromptPrepare').click();page.locator('#sendReferencePrompt').click();page.wait_for_function('project.referencePromptJobs[1]?.state==="submitted"');assert len(state['writes'][1]['references'])==3
            page.evaluate('recoverReferencePrompts()');page.locator('#applyReferencePrompt').click();page.wait_for_function('!document.querySelector("#modal").open');assert page.evaluate('project.scenes[0].motion.en.camera==="Fixture camera"&&frameApproved(project.scenes[0])')
            page.evaluate('''async data=>{const file=new File([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],'clip.mp4',{type:'video/mp4'});await addClip(file,{id:project.scenes[0].id,part:clipParts(project.scenes[0])[0].id});await approvalApprove('clip',approvalSlots('clip'));voiceOverDraft().clipSound='mute';project.merge.captions=false;window.voicePayload=null;window.addEventListener('message',e=>{if(e.data.type==='sceneforge:workflow-open-editor')window.voicePayload=e.data.payload;});await openInEditor();}''',base64.b64encode(file.read_bytes()).decode())
            page.wait_for_function('!!window.voicePayload');assert page.evaluate('voicePayload.clipVolume===0&&voicePayload.audio[0].role==="voice"&&voicePayload.audio[0].file instanceof Blob')
            # Listening and repeated editor imports use one pinned random track.
            page.evaluate('''async data=>{const blob=new Blob([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],{type:'audio/wav'}),a=putAsset(blob),b=putAsset(blob),m=productionSettings();m.musicLibrary=[{asset:a,name:'Track A'},{asset:b,name:'Track B'}];m.musicMode='random';const oldRandom=Math.random;Math.random=()=>.9;await actions['production-listen']();window.musicPin=m.musicChoice;Math.random=()=>.1;closeModal();await openInEditor();Math.random=oldRandom;}''',base64.b64encode(wav.getvalue()).decode())
            assert page.evaluate("productionSettings().musicChoice===musicPin&&voicePayload.audio.find(a=>a.role==='music').name===productionSettings().musicLibrary.find(a=>a.asset===musicPin).name")
            page.evaluate('''async data=>{project=blankProject();project.id='voice-room';const file=new File([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],'source.mp4',{type:'video/mp4'});project.source={asset:putAsset(file),duration:.4,poster:''};window.analyzeSource=()=>{throw Error('Duplicate browser scene detection must not run');};await g6AnalyzePipeline({allowGemini:false});}''',base64.b64encode(file.read_bytes()).decode());assert state['cpu_uploads']==1;assert page.evaluate('project.scenes.length===1&&project.analysis.pipeline6.steps.cuts==="done"')
            assert not errors,errors;browser.close();print('PASS: browser local voice, reviewed heard captions preserving source, frame prompt -> approval -> video prompt, reference attachments, and voice/mute handoff. Service fixtures, real media only.')
    finally:server.shutdown()

if __name__=='__main__':main()
