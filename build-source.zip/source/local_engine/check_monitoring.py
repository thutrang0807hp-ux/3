"""Real HTTP/SQLite projection and file measurement, no remote providers or model work."""
import json,os,tempfile,time
from pathlib import Path
from unittest.mock import patch
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-monitor-test-')
from fastapi.testclient import TestClient
from . import server as s
now=time.time();lib=s.LIBRARY
with lib.db()as db:
 for store,key,value in [('products','P',{'id':'P','name':'Son'}),('products','Q',{'id':'Q','name':'Khác'}),('rooms','R',{'id':'R','productId':'P','name':'Video A','exportedAt':now*1000}),('prefs','batch-studio-v1',{'jobs':[{'requestId':'flow-regenerated','regeneratedFrom':'flow-original'}]})]:db.execute('INSERT OR REPLACE INTO record VALUES(?,?,?,?)',('sceneforge-app-shell',store,json.dumps(key),json.dumps(value)))
s.VAULT.put('accounts',{'id':'A','service':'flow','name':'Flow A','state':'ready','active':True,'credit':99,'checked_at':now,'cookie':'DO_NOT_EXPOSE_ACCOUNT_COOKIE'})
for rid,raw,meta in [
 ('flow-original',{'kind':'Flow','state':'done','cost':10,'cost_unit':'credit'},{'provider':'flow','room_id':'R','scene_id':'S','account_id':'A','kind':'video'}),
 ('flow-uncertain',{'kind':'Flow','state':'unknown','cost':None},{'provider':'flow','room_id':'R','scene_id':'S','account_id':'A','kind':'video'}),
 ('flow-regenerated',{'kind':'Flow','state':'done','cost':20,'cost_unit':'credit'},{'provider':'flow','room_id':'R','scene_id':'S','account_id':'A','kind':'video'}),
 ('gemini-unknown',{'kind':'Gemini','state':'done','cost':None},{'provider':'gemini_api','room_id':'R','kind':'text'}),
 ('gemini-known',{'kind':'Gemini','state':'done','cost':.12,'cost_unit':'USD'},{'provider':'gemini_api','room_id':'R','kind':'text'}),
 ('invalid-cost',{'kind':'Flow','state':'done','cost':-8,'cost_unit':'credit'},{'provider':'flow','room_id':'R','kind':'image'})]:
 s.VAULT.put('logs',{'id':rid,'at':now,**raw,'api_key':'DO_NOT_EXPOSE_KEY','prompt_excerpt':'PRIVATE_PROMPT'});s.REQUESTS.set_metadata(rid,{**meta,'references':['PRIVATE_REF'],'cookie':'PRIVATE_COOKIE'})
work=s.DATA/'fixtures';work.mkdir();(work/'export.bin').write_bytes(b'EXPORTED');(work/'project.bin').write_bytes(b'PROJECT')
exported=lib.add_file(work/'export.bin','video/mp4');project=lib.add_file(work/'project.bin','image/png')
with lib.db()as db:db.execute('INSERT INTO asset_ref VALUES(?,?,?,?)',('sceneforge-app-shell','files',json.dumps('R:export'),exported['hash']))
(lib.root/'xuat/copy.mp4').write_bytes(b'EXPORTED');(lib.root/'cache/thu-vien-old.zip').write_bytes(b'OLD_CACHE');os.utime(lib.root/'cache/thu-vien-old.zip',(now-7200,now-7200));(lib.root/'cache/other.bin').write_bytes(b'OTHER')
models=s.DATA/'models';models.mkdir();(models/'weights.bin').write_bytes(b'MODEL_WEIGHT');outside=s.DATA/'outside-secret';outside.write_bytes(b'NEVER_COUNT_THIS')
try:(lib.root/'cache/link').symlink_to(outside)
except OSError:pass
with TestClient(s.app)as c:
 assert c.get('/local-api/monitoring').status_code==403;c.get('/');r=c.get('/local-api/monitoring');assert r.status_code==200,r.text;data=r.json();rows={r['id']:r for r in data['rows']}
 assert rows['flow-original']['room_name']=='Video A'and rows['flow-original']['product_name']=='Son'and rows['flow-original']['account_name']=='Flow A'
 assert rows['flow-original']['cost']==10 and rows['gemini-known']['cost_unit']=='USD';assert rows['flow-uncertain']['cost']is None and rows['invalid-cost']['cost']is None
 assert rows['flow-regenerated']['is_regeneration']and not rows['flow-uncertain']['is_regeneration'];assert data['exports'][0]['id']=='R'
 for secret in ['DO_NOT_EXPOSE','PRIVATE_PROMPT','PRIVATE_COOKIE','PRIVATE_REF']:assert secret not in r.text,r.text
 before=lib.status()['revision'];r=c.get('/local-api/library/storage-breakdown');assert r.status_code==200,r.text;measure=r.json();assert measure['complete']and measure['categories']['models']==len(b'MODEL_WEIGHT');assert measure['categories']['exports']==2*len(b'EXPORTED');assert measure['categories']['cache']==len(b'OLD_CACHEOTHER');assert measure['safe_cache_bytes']==len(b'OLD_CACHE');assert measure['total_bytes']==sum(measure['categories'].values())and lib.status()['revision']==before
 assert(lib.root/'cache/thu-vien-old.zip').exists()and outside.read_bytes()==b'NEVER_COUNT_THIS'
 with patch('subprocess.Popen')as opener:
  r=c.post('/local-api/library/open-root',json={'path':'/arbitrary-ignored'},headers={'X-SceneForge-Local':'1'});assert r.status_code==200 and r.json()['path']==str(lib.root);assert opener.call_args[0][0][-1]==str(lib.root)
print('PASS monitoring route joins ledger/account/room/product, explicit regeneration only, unknown/invalid fees never 0, separate USD/credit, secrets omitted; read-only physical storage categories/cache eligibility/symlink exclusion; open-root fixed to configured root. No provider calls or file cleanup.')
