"""Source intake: real media probing/routes, bounded network fixtures, no AI generation."""
import asyncio,base64,io,json,os,tempfile,subprocess,hashlib
from pathlib import Path
from unittest.mock import patch
import httpx
from PIL import Image
from fastapi import HTTPException
from .video_import import VideoImport,public_url,MAX_BYTES,PublicNetwork

async def main():
 with tempfile.TemporaryDirectory(prefix='sf-video-intake-')as tmp:
  root=Path(tmp);sample=root/'fixture.mp4'
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=green:s=160x90:d=1','-c:v','libx264','-pix_fmt','yuv420p',str(sample)],check=True)
  payload=sample.read_bytes();service=VideoImport(root)
  for bad in ['http://127.0.0.1/a.mp4','http://[::1]/a.mp4','http://169.254.169.254/a.mp4','file:///tmp/a','https://user:pass@example.com/a','http://localhost/a']:
   try:await public_url(bad)
   except ValueError:pass
   else:raise AssertionError('Accepted private URL '+bad)
  async def fakepublic(url):return url
  calls=[]
  async def resolve(jid,url):calls.append(url);return url,{},{}
  async def download(jid,url,headers):service.path(jid).write_bytes(payload);service.jobs[jid]['bytes']=len(payload);return hashlib.sha256(payload).hexdigest()
  with patch('local_engine.video_import.public_url',fakepublic):
   service.resolve=resolve;service.download=download
   j=await service.create({'url':'https://example.com/a.mp4'});duplicate=await service.create({'url':'https://example.com/a.mp4'});assert duplicate['id']==j['id']
   await service.tasks[j['id']];result=service.get(j['id']);assert result['state']=='done'and result['width']==160 and result['height']==90,result
   assert len(calls)==1
   await service.release(j['id']);assert not service.path(j['id']).exists()
   # A downloaded HTML/HLS disguise must not reach ffprobe.
   async def badfile(jid,url,headers):service.path(jid).write_text('#EXTM3U\nfile:///etc/passwd');return 'bad'
   service.download=badfile;j=await service.create({'url':'https://example.com/b.mp4'});await service.tasks[j['id']];assert service.get(j['id'])['state']=='error'and not service.path(j['id']).exists()
   async def stalled(jid,url,headers):await asyncio.Event().wait()
   service.download=stalled;j=await service.create({'url':'https://example.com/c.mp4'});await asyncio.sleep(.01);await service.release(j['id']);assert not service.tasks
  # Stream size cap and redirect-to-loopback fail before accepting any content.
  async def handler(request):return httpx.Response(302,headers={'location':'http://127.0.0.1/internal'})
  service.jobs['test']={'bytes':0}
  with patch('local_engine.video_import.public_transport',lambda:httpx.MockTransport(handler)):
   try:await VideoImport.download(service,'test','https://example.com/a.mp4',{})
   except ValueError:pass
   else:raise AssertionError('Private redirect accepted')
  async def huge(request):return httpx.Response(200,headers={'content-length':str(MAX_BYTES+1)})
  with patch('local_engine.video_import.public_transport',lambda:httpx.MockTransport(huge)),patch('local_engine.video_import.public_url',fakepublic):
   try:await VideoImport.download(service,'test','https://example.com/a.mp4',{})
   except ValueError:pass
   else:raise AssertionError('Oversize accepted')
  os.environ['SCENEFORGE_LOCAL_DATA']=str(root/'app')
  from . import server as s
  async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.app),base_url='http://127.0.0.1')as client:
   await client.get('/');headers={'X-SceneForge-Local':'1'}
   assert (await client.post('/local-api/video-import/jobs',json={'url':'http://localhost/x.mp4'},headers=headers)).status_code==400
   assert (await client.post('/local-api/video-import/jobs',json={'url':'http://localhost/x.mp4'})).status_code==403
   status=(await client.get('/local-api/ai/recipe-evidence/status')).json();assert status['ai_source']=='gemini_chat'
   image=Image.new('RGB',(160,90),'green');buf=io.BytesIO();image.save(buf,format='JPEG');uri='data:image/jpeg;base64,'+base64.b64encode(buf.getvalue()).decode()
   recipe={'name':'Minh họa','industry':'Chung','videoType':'Show','tips':'Ảnh lấy mẫu, chưa rõ chuyển động.','beats':[{'name':'Giới thiệu','role':'solution','type':'wide','start':0,'end':1,'purpose':'Giới thiệu bố cục','example':''}]}
   calls=[]
   async def execute(body,instruction,media=None,**kwargs):calls.append((body.copy(),media,kwargs));return recipe
   with patch.object(s.GEMINI_CHAT,'execute_json',execute):
    body={'request_id':'12345678-abcd','ai_source':'gemini_chat','room_id':'room1','duration':1,'scenes':[{'code':'S1','start':0,'end':1}],'lines':[],'pictures':[{'code':'S1','image':uri}],'expected_store_id':status['store_id']}
    response=await client.post('/local-api/ai/recipe-evidence',json=body,headers=headers);assert response.status_code==200,response.text
    body['recovery']=True;response=await client.post('/local-api/ai/recipe-evidence',json=body,headers=headers);assert response.status_code==200,response.text
    assert calls[0][0]==calls[1][0]and calls[0][1]==calls[1][1]and calls[1][2]['read_only']is True
    body['expected_store_id']='other';assert (await client.post('/local-api/ai/recipe-evidence',json=body,headers=headers)).status_code==409;assert len(calls)==2
   assert not s.FLOW_PROVIDER.tasks and not s.MUSE_PROVIDER.tasks and not s.WEB_IMAGES.tasks
  # Existing export/generation/CPU budgets also account for unfinished URL imports.
  from collections import namedtuple
  Usage=namedtuple('Usage','total used free');floor=s.STORAGE_JOBS.limits()['minimum_free_mb']*1024**2
  with patch('local_engine.storage_jobs.shutil.disk_usage',lambda _:Usage(100*1024**3,0,floor+400*1024**2)):
   s.STORAGE_JOBS.reserve_local(1024**2)
   s.VIDEO_IMPORT.jobs['budget-fixture']={'bytes':0};s.VIDEO_IMPORT.tasks['budget-fixture']=None
   try:s.STORAGE_JOBS.reserve_local(1024**2)
   except HTTPException as e:assert e.status_code==507
   else:raise AssertionError('Other jobs ignored active source download reservation')
   s.VIDEO_IMPORT.tasks.pop('budget-fixture');s.VIDEO_IMPORT.jobs.pop('budget-fixture')
  await s.VIDEO_IMPORT.close()
 print('PASS public URL/private redirect rejection, duplicate reuse, real landscape MP4 probe, disguised playlist rejection, size bounds, cancellation/file cleanup, shared storage reservation, session guard, Gemini evidence + pinned read-only recovery, no image/video generation.')
if __name__=='__main__':asyncio.run(main())
