"""Use the paired native browser for Flow frontend RPCs; no cookie transplant."""
from contextvars import ContextVar
from datetime import datetime,timedelta,timezone
from functools import wraps
import inspect,json,re
from urllib.parse import urlsplit

KEY='sceneforge_native_flow'
ACTIVE=ContextVar('sceneforge_native_flow',default=None)


def route_of(storage):
    try:value=json.loads(storage)if isinstance(storage,str)else storage
    except (ValueError,TypeError):return None
    return clean_route(value.get(KEY))if isinstance(value,dict)else None


def clean_route(value):
    if not isinstance(value,dict):return None
    if not all(isinstance(value.get(k),str)for k in ('id','key','endpoint','origin')):return None
    if not re.fullmatch(r'[A-Za-z0-9_-]{20,80}',value['id'])or not re.fullmatch(r'[A-Za-z0-9_-]{32,100}',value['key']):return None
    try:
        u=urlsplit(value['endpoint'])
        if u.scheme!='http'or u.hostname!='127.0.0.1'or u.username or u.password or u.path!='/local-api/browser-bridge/flow-execute'or u.query or u.fragment or not u.port:return None
    except ValueError:return None
    if not re.fullmatch(r'chrome-extension://[a-p]{32}',value['origin']):return None
    return {k:value[k]for k in ('id','key','endpoint','origin')}


def envelope(storage,route):
    route=clean_route(route)
    if not route:return storage
    value=json.loads(storage)if isinstance(storage,str)else storage
    if isinstance(value,list):value={'cookies':value}
    return json.dumps({**value,KEY:route},separators=(',',':'))


class NativeFailure(RuntimeError):
    def __init__(self,status,uncertain=False,code=None):
        super().__init__('Flow native browser HTTP '+str(status));self.status_code=status;self.outcome_unknown=uncertain
        self.native_code=code if code in {'FLOW_BROWSER_UNAVAILABLE','FLOW_BROWSER_ACCOUNT_CHANGED','FLOW_BROWSER_REQUEST_FAILED','FLOW_BROWSER_OUTCOME_UNKNOWN'}else ('FLOW_BROWSER_OUTCOME_UNKNOWN' if uncertain else 'FLOW_BROWSER_REQUEST_FAILED')


async def call(route,request,timeout=120):
    import httpx
    timeout=max(5,min(timeout or 120,600))
    async with httpx.AsyncClient(trust_env=False)as client:
        try:
            response=await client.post(route['endpoint'],json={'id':route['id'],'key':route['key'],'request':request,'timeout':timeout},headers={'Origin':route['origin'],'X-SceneForge-Bridge':'1'},timeout=timeout+5)
        except Exception:raise NativeFailure(503,True)from None
    if response.status_code!=200:
        try:detail=response.json().get('detail',{})
        except ValueError:detail={}
        if not isinstance(detail,dict):detail={}
        raise NativeFailure(response.status_code,response.status_code in (503,504) and detail.get('sent')is not False,detail.get('code'))
    if len(response.content)>20*1024**2:raise NativeFailure(502,True)
    value=response.json()
    if type(value.get('status'))is not int:raise NativeFailure(502,True)
    if value['status']!=200:raise NativeFailure(value['status'],bool(value.get('uncertain')),value.get('code'))
    return value


def install(engine):
    manager=engine.token_manager;client=getattr(manager,'flow_client',None)or getattr(engine,'flow_client',None)
    if client is None or getattr(client,'_sceneforge_native_transport',False):return
    client._sceneforge_native_transport=True
    async def resolve(arguments):
        route=route_of(arguments.get('google_cookies')or arguments.get('cookie_storage'))or ACTIVE.get()
        aid=arguments.get('token_id')
        if not route and type(aid)is int and getattr(client,'db',None):
            row=await client.db.get_token(aid)
            if row:route=route_of(getattr(row,'google_cookies',None))
        return route
    def wrap(owner,name):
        original=getattr(owner,name,None)
        if not callable(original):return
        signature=inspect.signature(original)
        @wraps(original)
        async def native(*args,**kwargs):
            args_map=signature.bind(*args,**kwargs).arguments
            route=await resolve(args_map)
            if not route:return await original(*args,**kwargs)
            marker=ACTIVE.set(route)
            try:
                if name=='_call_flow_frontend_rpc':
                    result=await call(route,{'kind':'rpc','rpc_id':args_map['rpc_id'],'argument':args_map['argument']},args_map.get('timeout',120))
                    frames=client._parse_batchexecute_frames(result.get('text',''))
                    client._raise_batchexecute_error(frames,args_map['rpc_id'])
                    payload=client._extract_batchexecute_payload(frames,args_map['rpc_id'])
                    if payload is None:raise NativeFailure(502)
                    return payload
                if name=='_call_flow_stream_chat':
                    body=client._build_stream_chat_request(project_id=args_map['project_id'],prompt=args_map['prompt'],recaptcha_token=args_map['recaptcha_token'],session_id=args_map['session_id'])
                    result=await call(route,{'kind':'stream','f_request':body},args_map.get('timeout',120));text=result.get('text','')
                    if re.search(r'PUBLIC_ERROR_[A-Z_]+',text):raise NativeFailure(502)
                    frames=client._parse_batchexecute_frames(text)
                    client._raise_batchexecute_error(frames,'')
                    return {'frames':frames,'mediaIds':client._extract_stream_chat_media_ids(frames),'mediaUrls':list(dict.fromkeys(re.findall(r'https://flow-content\.google/(?:image|video)/[^"\\\s]+',text))),'rawLength':len(text),'responseText':text}
                if name in ('st_to_at','detect_account_identity'):
                    meta=await call(route,{'kind':'bootstrap'})
                    email=meta.get('email','')
                    if not isinstance(email,str)or '@'not in email or len(email)>254:raise NativeFailure(401)
                    storage=args_map.get('google_cookies')or ''
                    storage=envelope(storage,route)
                    if name=='detect_account_identity':
                        import hashlib
                        return {'email':email,'google_cookies':storage,'st':'frontend-'+hashlib.sha256(storage.encode()).hexdigest()[:32]}
                    # The actual credit RPC still authenticates before accepting an account.
                    credits=await client.get_credits(client.FRONTEND_ACCESS_TOKEN,google_cookies=storage)
                    return {'access_token':client.FRONTEND_ACCESS_TOKEN,'expires':(datetime.now(timezone.utc)+timedelta(minutes=55)).isoformat(),'user':{'email':email},'credits':credits.get('credits'),'userPaygateTier':credits.get('userPaygateTier'),'google_cookies':storage}
                if name=='_get_recaptcha_token':
                    result=await call(route,{'kind':'captcha','action':args_map.get('action','IMAGE_GENERATION')},90)
                    token=result.get('token')
                    if not isinstance(token,str)or not token:raise NativeFailure(403)
                    setter=getattr(client,'_set_captcha_request_context',None)
                    if setter:
                        import asyncio
                        setter({'method':'sceneforge_native','browser_ref':None,'owner':asyncio.current_task()})
                    return token,None
                return await original(*args,**kwargs)
            finally:ACTIVE.reset(marker)
        setattr(owner,name,native)
    for name in ('st_to_at','_call_flow_frontend_rpc','_call_flow_stream_chat','_get_recaptcha_token'):wrap(client,name)
    wrap(manager,'detect_account_identity')
    original=getattr(client,'get_updated_flow_cookies',None)
    if callable(original):
        @wraps(original)
        def updated(storage):
            route=route_of(storage)or ACTIVE.get();value=original(storage)
            return envelope(value,route)if route else value
        client.get_updated_flow_cookies=updated
