"""Use the actual pinned vendor cookie validator, then verify safe error relaying."""
import asyncio,importlib.util,json,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
import httpx
from fastapi import FastAPI,HTTPException
from .flow_connection import validate,MESSAGES
from .flow_accounts import FlowAccounts
from .vault import Vault


async def main(source):
    spec=importlib.util.spec_from_file_location('reviewed_flow_cookie_contract',source/'src/services/browser_cookie_utils.py')
    vendor=importlib.util.module_from_spec(spec);spec.loader.exec_module(vendor)
    root={'domain':'.google.com','path':'/','name':'SID','value':'fixture-root-private','secure':True}
    host={'domain':'flow.google.com','path':'/','name':'OSID','value':'fixture-flow-private','hostOnly':True,'secure':True,'httpOnly':True}
    legacy=[root,{'domain':'.labs.google','path':'/','name':'fixture-labs','value':'fixture-private'}]
    for fn in [validate,vendor.validate_flow_cookie_storage]:
        try:fn(legacy)
        except (ValueError,HTTPException):pass
        else:raise AssertionError('Old extension cookie set was wrongly accepted')
        fn([root,host])
    assert ('OSID','fixture-flow-private')in vendor.cookie_pairs_for_url([root,host],'https://flow.google.com/projects')
    assert 'OSID'not in dict(vendor.cookie_pairs_for_url([root,host],'https://google.com/'))
    manifest=json.loads((Path(__file__).resolve().parents[1]/'scripts/browser-extension/manifest.json').read_text())
    assert 'https://flow.google.com/*'in manifest['host_permissions']
    with tempfile.TemporaryDirectory() as tmp:
        state={'known':True};app=FastAPI()
        @app.post('/sceneforge/accounts')
        async def endpoint():
            raise HTTPException(409,{'code':'FLOW_ACCOUNT_BUSY'if state['known']else'UNTRUSTED','message':'PRIVATE-PROVIDER-COOKIE'})
        fake=SimpleNamespace(vault=Vault(Path(tmp)),config=lambda:{'url':'http://fixture','key':'fixture-key'},client_factory=lambda:httpx.AsyncClient(transport=httpx.ASGITransport(app)))
        accounts=FlowAccounts(fake)
        for known in [True,False]:
            state['known']=known
            try:await accounts.request('POST','accounts',{})
            except HTTPException as e:
                assert e.detail['code']==('FLOW_ACCOUNT_BUSY'if known else'FLOW_ENGINE_REJECTED')
                assert e.detail['message']==MESSAGES[e.detail['code']] and 'PRIVATE'not in str(e.detail)
            else:raise AssertionError('Error not propagated')
    print('PASS ACTUAL pinned Flow cookie validator rejects old Google/Labs-only transfer and accepts host-only flow.google.com OSID + Google identity; host scope preserved; extension permission present; safe engine-stage codes relay without provider secrets. No Google network calls.')


if __name__=='__main__':
    asyncio.run(main(Path(sys.argv[1])if len(sys.argv)>1 else Path('/tmp/sceneforge-flow-pinned')))
