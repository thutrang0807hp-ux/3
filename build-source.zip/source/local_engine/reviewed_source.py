"""Use a verified bundled checkout without requiring Git on the user's PC."""
import hashlib,json,subprocess,shutil
from pathlib import Path

def revision(checkout,expected):
    checkout=Path(checkout)
    marker=checkout/'.sceneforge-source.json'
    if marker.is_file():
        data=json.loads(marker.read_text(encoding='utf-8'))
        if data['revision']!=expected:raise RuntimeError('Bundled source revision mismatch')
        for entry in data['files']:
            path=(checkout/entry['path']).resolve()
            if not path.is_relative_to(checkout.resolve())or not path.is_file()or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('Bundled source changed: '+entry['path'])
        return expected
    if not shutil.which('git'):raise RuntimeError('Missing bundled source; Git is needed for an online developer setup.')
    return subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()

def pip_arguments():
    import os
    wheels=os.environ.get('SCENEFORGE_OFFLINE_WHEELS')
    return ['--no-index','--find-links',wheels]if wheels else []
