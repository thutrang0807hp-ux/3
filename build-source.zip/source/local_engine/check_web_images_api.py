"""ASGI routes + real vault/ledger/library; no external generation."""
import asyncio,io,os,tempfile,uuid,base64,json
from PIL import Image
import httpx
async def main():
 with tempfile.TemporaryDirectory(prefix='sf-web-api-')as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server as s
  from .account_pool import AccountPool
  image=io.BytesIO();Image.new('RGB',(256,256),'green').save(image,format='PNG');raw=image.getvalue();calls=[];gate=asyncio.Event();gate.set()
  async def runner(rid,payload,path,sent):
   await gate.wait();sent();calls.append(payload);path.write_bytes(raw)
  s.WEB_IMAGES.runner=runner
  async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.app,client=('127.0.0.1',1234)),base_url='http://127.0.0.1:8765',headers={'X-SceneForge-Local':'1','Origin':'http://127.0.0.1:8765'})as c:
   await c.get('/')
   for source in ['grok','chatgpt','meta']:
    aid=str(uuid.uuid4());s.VAULT.put('accounts',{'id':aid,'name':'Fixture '+source,'service':source,'enabled':True,'state':'ready','active':True,'session_verified':True});s.VAULT.set_secret('web-image-session:'+aid,{'cookies':[],'origins':[]})
    status=(await c.get('/local-api/web-images/'+source+'/status')).json();assert status.get('selection',{}).get('available'),status
    rid='webimage-'+str(uuid.uuid4());body={'source':source,'request_id':rid,'kind':'image','prompt':'A green product','aspect':'1:1','references':[{'mime_type':'image/png','data':base64.b64encode(raw).decode()}],'confirm_send':True,'selection_token':status['selection']['token'],'product_id':'fixture-product'}
    gate.clear();r=await c.post('/local-api/web-images/jobs',json=body);assert r.status_code==200,r.text
    assert s.LIBRARY.lifecycle.active_job(rid)
    with s.LIBRARY.db()as db:row=db.execute('SELECT provider,room_id,kind,state FROM generation_job WHERE id=?',(rid,)).fetchone()
    assert row==('web-images','fixture-product','image','submitted'),row
    # Busy account cannot be removed while its job awaits browser access.
    r=await c.post('/local-api/accounts/remove',json={'id':aid});assert r.status_code==409,r.text
    gate.set();await asyncio.gather(*list(s.WEB_IMAGES.tasks.values()));r=await c.get('/local-api/web-images/jobs/'+rid);record=r.json();assert record['state']=='done'and record['store_id']==s.REQUESTS.store_id,record
    assert record['result']['account_id']==aid and record['result']['origin']==source and record['result']['result_hash']
    assert (await c.get('/local-api/web-images/files/'+rid)).content==raw
    assert not (s.DATA/'web-image-results'/record['result']['file']).exists(),'canonical import should remove duplicate backend image'
    before=len(calls);r=await c.post('/local-api/web-images/jobs',json=body);assert r.status_code==200 and len(calls)==before
    # Unknown IDs never fall back to another source.
    r=await c.get('/local-api/web-images/jobs/webimage-'+str(uuid.uuid4()));assert r.status_code==404
   assert len(calls)==3
   assert 'cookies'not in json.dumps((await c.get('/local-api/status')).json())
  await s.WEB_IMAGES.close()
 print('PASS web image HTTP routes + encrypted vault + durable ledger + library original-file promotion, duplicate cleanup, account removal protection, active-job cleanup protection, exact account/source and no duplicate generation; runner fixture only.')
if __name__=='__main__':asyncio.run(main())
