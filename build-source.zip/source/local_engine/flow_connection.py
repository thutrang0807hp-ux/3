"""Bounded Flow connection diagnostics. Never expose provider messages or cookies."""
from fastapi import HTTPException

MESSAGES={
 'FLOW_SESSION_COOKIE_MISSING':'Chưa nhận được phiên tại flow.google.com. Mở https://flow.google.com/ và đăng nhập; tải lại tiện ích SceneForge mới, cấp quyền Flow nếu trình duyệt hỏi, rồi tạo mã mới.',
 'FLOW_GOOGLE_COOKIE_MISSING':'Thiếu phiên Google đi kèm Flow. Đăng nhập Flow trong đúng trình duyệt có tiện ích rồi tạo mã mới.',
 'FLOW_ENGINE_NOT_CONFIGURED':'Engine Flow cục bộ chưa được cấu hình. Kiểm tra kết nối engine trong Cài đặt.',
 'FLOW_ENGINE_UNREACHABLE':'Không liên lạc được với engine Flow cục bộ. Kiểm tra engine đang chạy rồi kết nối lại.',
 'FLOW_ENGINE_REJECTED':'Engine Flow nhận yêu cầu nhưng từ chối nhập/kiểm tra phiên. Chưa gửi tạo nội dung.',
 'FLOW_IMPORT_REJECTED':'Engine đã nhận phiên nhưng chưa nhập được tài khoản Flow (xác minh đăng nhập hoặc khởi tạo dự án). Chưa gửi tạo nội dung.',
 'FLOW_ACCOUNT_BUSY':'Tài khoản Flow đang có việc chạy; chưa đổi phiên. Chờ xong rồi kết nối lại.',
 'FLOW_ACCOUNT_NOT_ELIGIBLE':'Không tìm được tài khoản Flow đang bật khớp với phiên vừa nhập. Chưa thay tài khoản cũ.',
 'FLOW_ACCOUNT_ID_MISSING':'Engine chưa trả đúng mã tài khoản vừa nhập. Chưa chọn một tài khoản khác để thay thế.',
 'FLOW_SESSION_CHECK_FAILED':'Đã nhập tài khoản vào engine nhưng chưa kiểm tra được phiên Flow. Tài khoản cũ được giữ để kiểm tra tiếp.',
 'FLOW_AUTH_EXPIRED':'Flow không chấp nhận phiên đăng nhập này. Mở flow.google.com trong đúng trình duyệt, đăng nhập lại rồi tạo mã mới.',
}
GOOGLE_NAMES={'SID','HSID','SSID','APISID','SAPISID','__Secure-1PSID','__Secure-3PSID'}


def error(code,stage='connect'):
    code=code if code in MESSAGES else 'FLOW_ENGINE_REJECTED'
    return HTTPException(409,{'code':code,'stage':stage,'message':MESSAGES[code]})


def validate(cookies):
    rows=[c for c in cookies if isinstance(c,dict) and c.get('value')] if isinstance(cookies,list) else []
    if not any(c.get('name')in {'OSID','__Secure-OSID'} and str(c.get('domain','')).lstrip('.')=='flow.google.com' and not c.get('partitionKey') for c in rows):
        raise error('FLOW_SESSION_COOKIE_MISSING','cookies')
    if not any(c.get('name')in GOOGLE_NAMES and str(c.get('domain','')).lstrip('.')=='google.com' for c in rows):
        raise error('FLOW_GOOGLE_COOKIE_MISSING','cookies')


def public_error(exc):
    detail=exc.detail if isinstance(exc,HTTPException)else None
    if isinstance(detail,dict) and detail.get('code')in MESSAGES:
        code=detail['code']
        return {'code':code,'message':MESSAGES[code]}
    return {'code':'FLOW_ENGINE_REJECTED','message':MESSAGES['FLOW_ENGINE_REJECTED']}
