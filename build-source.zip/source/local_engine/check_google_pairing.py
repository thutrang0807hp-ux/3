"""Joint browser pairing through real app/Flow adapters, with fixture provider I/O."""
import os,json,tempfile,time
from pathlib import Path
from fastapi.testclient import TestClient


def main():
    with tempfile.TemporaryDirectory(prefix='sf-google-pair-') as tmp:
        os.environ['SCENEFORGE_LOCAL_DATA']=tmp
        from . import server as s
        calls=[];flow_rows=[];flow_bodies=[];fail={'flow':False}
        async def runner(body):
            assert body['operation']=='check','No generation permitted'
            calls.append(body)
            return {'ok':True,'session':body['session'],'models':[]}
        async def flow_request(method,path,body=None):
            if method=='POST' and path=='accounts':
                flow_bodies.append(body['cookies'])
                assert all(c['domain'].lstrip('.') in {'google.com','labs.google','flow.google.com'} for c in body['cookies'])
                i=len(flow_rows)+1;flow_rows.append({'id':i,'name':'flow-'+str(i)+'@fixture.invalid','enabled':True})
                return {'id':i}
            if method=='GET' and path=='accounts':return {'protocol':'sceneforge-account-pin-v1','single_attempt':True,'accounts':flow_rows}
            if path.endswith('/check'):return {'ok':not fail['flow'],'credit':0}
            raise AssertionError((method,path))
        s.GEMINI_CHAT.runner=runner;s.FLOW_ACCOUNTS.request=flow_request
        s.VAULT.set_secret('flow-engine',{'url':'http://fixture.invalid','key':'not-a-real-engine-key'})
        bridge=s.BROWSER_BRIDGE
        with TestClient(s.app) as c:
            c.get('/');local={'X-SceneForge-Local':'1'};wire={'Origin':bridge.origin,'X-SceneForge-Bridge':'1'}
            def pair(services,cookie='fixture-Google-A',protocol=2):
                p=c.post('/local-api/browser-bridge/pairs',headers=local,json={'service':services[0],'services':services,'name':'Google fixture'}).json()
                claim=c.post('/local-api/browser-bridge/claim',headers=wire,json={'code':p['code']}).json()
                assert claim['services']==services
                cookies=[{'domain':'.google.com','name':'__Secure-1PSID','value':cookie}]
                if 'flow'in services:cookies.extend([{'domain':'.labs.google','name':'fixture-labs','value':'private-labs'},{'domain':'flow.google.com','name':'OSID','value':'private-flow-session','hostOnly':True}])
                response=c.post('/local-api/browser-bridge/complete',headers=wire,json={'code':p['code'],'submission':claim['submission'],'cookies':cookies,'protocol':protocol})
                if response.status_code!=200:return p,response
                for _ in range(100):
                    status=c.get('/local-api/browser-bridge/pairs/'+p['id']).json()
                    if status['state']!='checking':return status,response
                    time.sleep(.02)
                raise AssertionError('Pair did not settle')
            status,response=pair(['gemini_chat','flow'])
            assert response.status_code==200 and status['state']=='done',status
            state=c.get('/local-api/browser-bridge/google-status').json()
            assert state['shared'] and all(r['ready'] for r in state['services'].values()),state
            chat_id=state['services']['gemini_chat']['id'];flow_id=state['services']['flow']['id']
            assert s.FLOW_ACCOUNTS.pool.status()['account_id']==flow_id
            assert all('labs.google'not in str(x['session']) for x in calls)
            assert 'private-labs'not in json.dumps(status)+json.dumps(state)
            # An old extension cannot silently claim it transferred both services.
            old,response=pair(['gemini_chat','flow'],protocol=1)
            assert response.status_code==409 and 'tiện ích'in response.text
            # The v7 bug: only root Google/Labs cookies cannot pass the current Flow contract.
            missing=c.post('/local-api/browser-bridge/pairs',headers=local,json={'service':'flow','name':'Missing Flow cookie'}).json()
            claim=c.post('/local-api/browser-bridge/claim',headers=wire,json={'code':missing['code']}).json()
            before=len(flow_bodies)
            c.post('/local-api/browser-bridge/complete',headers=wire,json={'code':missing['code'],'submission':claim['submission'],'cookies':[{'domain':'.google.com','name':'SID','value':'never-log'}]})
            for _ in range(100):
                result=c.get('/local-api/browser-bridge/pairs/'+missing['id']).json()
                if result['state']!='checking':break
                time.sleep(.01)
            assert result['state']=='failed' and result['results']['flow']['code']=='FLOW_SESSION_COOKIE_MISSING'
            assert 'flow.google.com'in result['message'] and len(flow_bodies)==before
            # A Flow-only connection selects its imported row without changing Chat.
            status,_=pair(['flow'],'fixture-Google-B')
            assert status['state']=='done'
            state=c.get('/local-api/browser-bridge/google-status').json()
            assert state['services']['gemini_chat']['id']==chat_id and state['services']['flow']['id']!=flow_id and not state['shared']
            # Connecting a different Chat account alone does not change Flow.
            flow_id2=state['services']['flow']['id']
            status,_=pair(['gemini_chat'],'fixture-Google-C')
            assert status['state']=='done'
            state=c.get('/local-api/browser-bridge/google-status').json()
            assert state['services']['flow']['id']==flow_id2 and state['services']['gemini_chat']['id']!=chat_id
            # Partial success stays explicit, with the previous Flow selection retained.
            fail['flow']=True
            status,_=pair(['gemini_chat','flow'],'fixture-Google-D')
            assert status['state']=='partial' and status['results']['gemini_chat']['state']=='done' and status['results']['flow']['state']=='failed'
            assert s.FLOW_ACCOUNTS.pool.status()['account_id']==flow_id2
            assert 'fixture-Google'not in c.get('/local-api/browser-bridge/google-status').text
            assert b'private-labs'not in s.VAULT.path.read_bytes()
            assert c.get('/local-api/browser-bridge/google-status',headers={'Origin':bridge.origin}).status_code==403
        for handler in list(s.RUNTIME_LOG.handlers):handler.close();s.RUNTIME_LOG.removeHandler(handler)
        s.LIBRARY._root_guard.instance.close()
        print('PASS real app joint code -> two scoped provider adapters -> independent checks and exact account selection; linked names; separate Chat/Flow preserves other selection; partial success, old-extension guard and secret isolation. Fixture providers only; zero generation.')


if __name__=='__main__':main()
