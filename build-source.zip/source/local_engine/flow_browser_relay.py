"""Loopback capability broker for explicitly paired, native-browser Flow jobs.

Queues are memory-only, jobs dispatch once, and uncertain jobs never retry.
Route keys live in the existing private vault and never enter public status.
"""
import asyncio,json,secrets,time
from fastapi import HTTPException

PREFIX='/local-api/browser-bridge/flow-'
PATHS={PREFIX+n for n in ('execute','poll','result','disconnect')}
KINDS={'bootstrap','rpc','stream','captcha'}


class BrowserRelay:
    def __init__(self,app,vault):
        self.vault=vault
        self.routes={r['id']:r for r in vault.secret('flow-native-browser-routes')or []}
        self.queues={};self.jobs={};self.online={};self.closed=False
        self.install(app)

    def issue(self,endpoint,origin):
        if len(self.routes)>=32:raise HTTPException(409,'Có nhiều phiên Flow; ngắt phiên không dùng trước.')
        rid=secrets.token_urlsafe(24)
        row={'id':rid,'browser_key':secrets.token_urlsafe(32),'engine_key':secrets.token_urlsafe(32),'endpoint':endpoint,'origin':origin,'created':time.time()}
        self.routes[rid]=row;self.save()
        return {'id':rid,'browser_key':row['browser_key']},{'id':rid,'key':row['engine_key'],'endpoint':endpoint,'origin':origin}

    def save(self):self.vault.set_secret('flow-native-browser-routes',list(self.routes.values()))

    def auth(self,body,role):
        rid=body.get('id');key=body.get('key');row=self.routes.get(rid) if isinstance(rid,str)else None
        if not row or not isinstance(key,str)or not secrets.compare_digest(row[role+'_key'],key):raise HTTPException(403,'Phiên trình duyệt không hợp lệ.')
        return row

    def revoke(self,rid):
        self.routes.pop(rid,None);self.online.pop(rid,None);self.save()
        for job in list(self.jobs.values()):
            if job['id']==rid and not job['future'].done():job['future'].set_exception(HTTPException(503,'Flow native route revoked; outcome unknown.'))

    async def close(self):
        self.closed=True
        for job in list(self.jobs.values()):
            if not job['future'].done():job['future'].set_exception(HTTPException(503,'Flow browser offline; outcome unknown.'))
        self.jobs.clear()
        for queue in self.queues.values():queue.put_nowait(None)

    def install(self,app):
        @app.post(PREFIX+'execute')
        async def execute(body:dict):
            row=self.auth(body,'engine');rid=row['id'];request=body.get('request')
            if not isinstance(request,dict)or request.get('kind')not in KINDS:raise HTTPException(400,'Loại yêu cầu Flow không hợp lệ.')
            if time.monotonic()-self.online.get(rid,-1e9)>50:raise HTTPException(503,{'code':'FLOW_BROWSER_UNAVAILABLE','sent':False})
            if sum(j['id']==rid for j in self.jobs.values())>=16:raise HTTPException(429,'Flow browser queue full; no request sent.')
            timeout=body.get('timeout',120)
            if type(timeout)not in (int,float):timeout=120
            timeout=max(5,min(timeout,600));jid=secrets.token_urlsafe(24)
            future=asyncio.get_running_loop().create_future()
            self.jobs[jid]={'id':rid,'request':request,'future':future,'dispatched':False,'deadline':time.monotonic()+timeout}
            self.queues.setdefault(rid,asyncio.Queue()).put_nowait(jid)
            try:return await asyncio.wait_for(future,timeout)
            except asyncio.TimeoutError:raise HTTPException(504,{'code':'FLOW_BROWSER_OUTCOME_UNKNOWN','sent':self.jobs.get(jid,{}).get('dispatched',True)})from None
            finally:self.jobs.pop(jid,None)

        @app.post(PREFIX+'poll')
        async def poll(body:dict):
            row=self.auth(body,'browser');rid=row['id'];self.online[rid]=time.monotonic()
            if body.get('hello')is True:return {'job':None}
            queue=self.queues.setdefault(rid,asyncio.Queue())
            while True:
                if self.closed:return {'job':None}
                try:jid=await asyncio.wait_for(queue.get(),15)
                except asyncio.TimeoutError:return {'job':None}
                job=self.jobs.get(jid)
                if not job or job['future'].done()or job['dispatched']:continue
                job['dispatched']=True
                return {'job':{'id':jid,'request':job['request'],'timeout':max(1,int(job['deadline']-time.monotonic()))}}

        @app.post(PREFIX+'result')
        async def result(body:dict):
            row=self.auth(body,'browser');jid=body.get('job_id');job=self.jobs.get(jid)if isinstance(jid,str)else None
            if not job or job['id']!=row['id']or not job['dispatched']or job['future'].done():raise HTTPException(409,'Kết quả Flow đã hết hạn hoặc đã nhận.')
            value=body.get('result')
            if not isinstance(value,dict)or type(value.get('status'))is not int or not 100<=value['status']<=599:raise HTTPException(400,'Kết quả Flow không hợp lệ.')
            if len(json.dumps(value))>20*1024**2:raise HTTPException(413,'Kết quả Flow quá lớn.')
            self.online[row['id']]=time.monotonic();job['future'].set_result(value)
            return {'accepted':True}

        @app.post(PREFIX+'disconnect')
        async def disconnect(body:dict):
            row=self.auth(body,'browser');rid=row['id'];self.online.pop(rid,None)
            for job in list(self.jobs.values()):
                if job['id']==rid and not job['future'].done():job['future'].set_exception(HTTPException(503,'Flow browser disconnected; outcome unknown.'))
            return {'ok':True}
