"""Adapter contract test with declared fixture models; no online generation claim."""
import asyncio,base64,io,json,tempfile,subprocess,uuid
from pathlib import Path
import httpx
from PIL import Image
from fastapi import HTTPException
from .flow_provider import FlowProvider
from .vault import Vault
from .request_ledger import RequestLedger
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);video=root/'clip.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=90x160:r=10:d=0.5','-c:v','libx264',str(video)],check=True)
  refs=[]
  for color in ['red','blue']:
   p=io.BytesIO();Image.new('RGB',(90,160),color).save(p,format='PNG');refs.append({'mime_type':'image/png','data':base64.b64encode(p.getvalue()).decode()})
  enabled=False;posts=[]
  async def transport(req):
   if req.url.path=='/v1/models':return httpx.Response(200,json={'data':[{'id':'fixture-portrait','description':'first last image video',**({'sceneforge_inputs':{'transport':'ordered_images','first_image':'start','second_image':'end','text_to_video':True}}if enabled else{})}]})
   if req.method=='POST':posts.append(json.loads(req.content));return httpx.Response(200,json={'choices':[{'message':{'content':'<video src="http://127.0.0.1:8766/output.mp4"></video>'}}]})
   return httpx.Response(200,content=video.read_bytes(),headers={'content-type':'video/mp4'})
  service=FlowProvider(Vault(root),root,RequestLedger(root),lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)));service.configure({'url':'http://127.0.0.1:8766','key':'LOCAL_TEST_KEY_12345'});await service.discover()
  body={'request_id':'flow-'+str(uuid.uuid4()),'kind':'video','model':'fixture-portrait','prompt':'First is start, second is end.','references':refs,'confirm_send':True,'room_id':'storyboard-room','scene_id':'scene-1','part':'a','frame_inputs':{'mode':'pair','start_id':'version-start','end_id':'version-end','slot':'scene-1:a'}}
  try:await service.submit(body);raise AssertionError('Unknown contract accepted')
  except HTTPException as e:assert e.status_code==409
  assert not posts
  enabled=True;status=await service.discover();assert status['model_details'][0]['sceneforge_inputs']['second_image']=='end'
  body['request_id']='flow-'+str(uuid.uuid4())
  await service.submit(body)
  for _ in range(200):
   result=service.lookup(body['request_id'])
   if result['state']in ('done','failed','unknown'):break
   await asyncio.sleep(.025)
  assert result['state']=='done',result
  assert len(posts)==1
  images=[p['image_url']['url']for p in posts[0]['messages'][0]['content']if p['type']=='image_url'];assert images==['data:image/png;base64,'+r['data']for r in refs]
  await service.submit(body);assert len(posts)==1  # durable same intent is not resent
  try:await service.submit({**body,'request_id':'flow-'+str(uuid.uuid4()),'references':refs[:1]});raise AssertionError('Missing end bytes accepted')
  except HTTPException as e:assert e.status_code==400
  try:await service.submit({**body,'request_id':'flow-'+str(uuid.uuid4()),'frame_inputs':{**body['frame_inputs'],'slot':'other:a'}});raise AssertionError('Mismatched slot accepted')
  except HTTPException as e:assert e.status_code==400
  assert len(posts)==1
  print('PASS model description alone never enables pair, explicit ordered contract retained, missing-end rejection before send, exact start/end bytes and order on wire, idempotent receipt; fixture provider only')
if __name__=='__main__':asyncio.run(main())
