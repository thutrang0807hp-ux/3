@echo off
cd /d "%~dp0\.."
python -m playwright install chromium
pause
