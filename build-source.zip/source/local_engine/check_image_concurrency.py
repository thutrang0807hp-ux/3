"""Concurrent same-account IMAGE tasks through actual adapters; no online sends."""
import asyncio,io,json,tempfile,uuid
from pathlib import Path
import httpx
from PIL import Image
from fastapi import HTTPException
from .vault import Vault
from .request_ledger import RequestLedger
from .gemini_chat import GeminiChat
from .web_images import WebImages
from .flow_provider import FlowProvider
from .flow_accounts import FlowAccounts
from .image_slots import ImageSlots

async def main():
 with tempfile.TemporaryDirectory(prefix='sf-image-slots-')as tmp:
  base=Path(tmp)
  for source in ['gemini_chat','grok','chatgpt','meta','flow']:
   root=base/source;root.mkdir();vault=Vault(root);ledger=RequestLedger(root);active=peak=0;arrived=asyncio.Event();release=asyncio.Event();calls=[];engine=[]
   async def render(identity):
    nonlocal active,peak
    calls.append(identity);active+=1;peak=max(peak,active)
    if active==3:arrived.set()
    try:await release.wait()
    finally:active-=1
    im=io.BytesIO();Image.new('RGB',(64,64),(int(identity.split()[-1])*25,30,90)).save(im,format='PNG');return im.getvalue()
   if source=='gemini_chat':
    async def runner(body):
     assert body['operation']=='generate';raw=await render(body['prompt']);Path(body['output']).write_bytes(raw);return {'ok':True,'session':{'changed':'must not overwrite shared cookie'}}
    provider=GeminiChat(vault,root,ledger,runner);vault.set_secret('gemini-chat-session:A',{'identity':'A'});slots=provider.image_slots;prefix='gchat-'
   elif source=='flow':
    async def transport(req):
     if req.url.path.endswith('/image-concurrency'):
      v=json.loads(req.content)['per_account'];engine.append(v);return httpx.Response(200,json={'per_account':v,'kind':'image'})
     if req.url.path.endswith('/check'):return httpx.Response(200,json={'ok':True,'credit':100})
     if req.url.path=='/v1/chat/completions':
      assert req.headers['x-sceneforge-account']=='1';body=json.loads(req.content);text=body['messages'][0]['content'][0]['text'];raw=await render(text);out[text]=raw;return httpx.Response(200,json={'url':'http://127.0.0.1:8766/output/'+text.split()[-1]},headers={'x-sceneforge-account':'1'})
     return httpx.Response(200,content=out['image '+req.url.path.split('/')[-1]],headers={'content-type':'image/png'})
    out={};provider=FlowProvider(vault,root,ledger,lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)));provider.configure({'url':'http://127.0.0.1:8766','key':'fixture-private-key'});c=provider.config();c.update(models=['fixture-image'],account_binding=True);vault.set_secret('flow-engine',c);provider.account_service=FlowAccounts(provider);slots=provider.image_slots;prefix='flow-'
   else:
    async def runner(rid,payload,path,sent):sent();path.write_bytes(await render(payload['prompt']));return [path]
    provider=WebImages(vault,root,ledger,runner);vault.set_secret('web-image-session:A',{'cookies':[],'origins':[]});slots=provider.image_slots[source];prefix='webimage-'
   vault.put('accounts',{'id':'A','name':'Single account','service':source,'engine_id':1,'enabled':True,'session_verified':True,'state':'ready','active':True});assert slots.limit()==1;slots.configure({'per_account':3});assert ImageSlots(Vault(root),source).limit()==3
   for bad in [0,5,True,'3']:
    try:slots.configure({'per_account':bad});raise AssertionError('accepted invalid setting')
    except HTTPException as e:assert e.status_code==400
   ids=[]
   for i in range(7):
    rid=prefix+str(uuid.uuid4());ids.append(rid);status=provider.status()if source in ['gemini_chat','flow']else provider.status(source);await provider.submit({'request_id':rid,'source':source,'kind':'image','role':'image','model':'fixture-image','prompt':'image '+str(i),'aspect':'9:16','references':[],'confirm_send':True,'selection_token':status['selection']['token'],'room_id':'room','scene_id':'scene-'+str(i)})
   try:
    await asyncio.wait_for(arrived.wait(),5);assert peak==3 and len(calls)==3,(source,peak,calls)
    try:slots.configure({'per_account':2},True);raise AssertionError('changed busy')
    except HTTPException as e:assert e.status_code==409
   finally:release.set()
   await asyncio.gather(*list(provider.tasks.values()));assert len(calls)==7 and peak==3
   for i,rid in enumerate(ids):
    record=provider.lookup(rid);assert record['state']=='done',(source,record);file=provider.file(rid);assert Path(file.path).is_file();assert Image.open(file.path).getpixel((0,0))[0]==i*25,(source,rid)
   if source=='gemini_chat':assert vault.secret('gemini-chat-session:A')=={'identity':'A'}
   if source=='flow':
    assert engine==[3]*7
    original=provider.account_service.request
    async def no_image_ack(method,path,body=None):
     if path.endswith('/image-concurrency'):return {'per_account':3}
     return await original(method,path,body)
    provider.account_service.request=no_image_ack;rid='flow-'+str(uuid.uuid4());await provider.submit({'request_id':rid,'source':'flow','kind':'image','model':'fixture-image','prompt':'image 99','references':[],'confirm_send':True,'selection_token':provider.status()['selection']['token']});await asyncio.gather(*list(provider.tasks.values()));assert provider.lookup(rid)['state']=='failed' and len(calls)==7

   assert not slots.active
   # Fetching completed receipts never calls runner again.
   for rid in ids:provider.lookup(rid)
   assert len(calls)==7
   print('PASS',source,': single account, peak 3 of 7 images, bounded slots, 7 isolated correct PNG results, persistence, idle-only setting, no cookie clobber/replay; fixtures only')
  # Cancellation releases permits, exclusive maintenance waits for active images.
  work=base/'gates';work.mkdir();slots=ImageSlots(Vault(work),'test');slots.configure({'per_account':2});started=asyncio.Event();hold=asyncio.Event();exclusive=asyncio.Event()
  async def job():
   async with slots.slot('A'):started.set();await hold.wait()
  task=asyncio.create_task(job());await started.wait()
  async def maintenance():
   async with slots.exclusive('A'):exclusive.set()
  check=asyncio.create_task(maintenance());await asyncio.sleep(.01);assert not exclusive.is_set();task.cancel();await asyncio.gather(task,return_exceptions=True);await check;assert not slots.active and not slots.exclusive_accounts
  print('PASS cancellation releases image permit; maintenance is exclusive')

if __name__=='__main__':asyncio.run(main())
