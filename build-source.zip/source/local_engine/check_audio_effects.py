"""Real FFmpeg bytes and canonical storage; no AI/model dependency."""
import asyncio,hashlib,json,math,os,tempfile,wave,io,array
from pathlib import Path
import httpx
from .audio_effects import normalize
from fastapi import HTTPException

def wav(seconds,kind='music'):
 rate=24000;out=io.BytesIO();data=array.array('h')
 for i in range(int(seconds*rate)):
  t=i/rate;amplitude=.35 if kind=='music'else .6 if .6<=t<1.3 else 0
  data.append(int(amplitude*32767*math.sin(2*math.pi*(440 if kind=='music'else 220)*t)))
 with wave.open(out,'wb')as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes(data.tobytes())
 return out.getvalue()
def rms(blob,start,end):
 with wave.open(io.BytesIO(blob),'rb')as w:
  w.setpos(int(start*w.getframerate()));data=array.array('h',w.readframes(int((end-start)*w.getframerate())))
 return math.sqrt(sum((n/32768)**2 for n in data)/len(data))
async def main():
 with tempfile.TemporaryDirectory(prefix='sf-audiofx-')as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server as s
  async with httpx.AsyncClient(transport=httpx.ASGITransport(app=s.app),base_url='http://testserver')as c:
   await c.get('/');headers={'X-SceneForge-Local':'1'}
   async def upload(data):
    response=await c.post('/local-api/library/assets',content=data,headers={**headers,'Content-Type':'audio/wav'});assert response.status_code==200,response.text;return response.json()['hash']
   source=await upload(wav(2));guide=await upload(wav(2,'voice'))
   response=await c.post('/local-api/audio-effects/render',headers=headers,json={'mode':'tempo','source':source,'speed':1.25});assert response.status_code==200,response.text
   value=response.json();assert abs(value['duration']-1.6)<.1 and value['provider_requests']==0,value
   tempo=await c.get(value['url']);assert tempo.status_code==200 and tempo.content[:4]==b'RIFF'
   response=await c.post('/local-api/audio-effects/render',headers=headers,json={'mode':'tempo','source':source,'speed':1.25});assert response.json()['cached']and response.json()['hash']==value['hash']
   model={'mode':'music','source':source,'duration':3,'duck':True,'guides':[{'asset':guide,'start':0,'duration':2}]}
   response=await c.post('/local-api/audio-effects/render',headers=headers,json=model);assert response.status_code==200,response.text;result=response.json();audio=(await c.get(result['url'])).content
   assert abs(result['duration']-3)<.05 and rms(audio,.8,1.2)<rms(audio,.1,.4)*.65,(result,rms(audio,.8,1.2),rms(audio,.1,.4))
   assert rms(audio,2.5,2.8)>0.05 # short source loops to fill the final duration
   response=await c.post('/local-api/audio-effects/render',headers=headers,json=model);assert response.json()['cached']and response.json()['hash']==result['hash']
   assert s.LIBRARY.asset_path(result['hash']).is_file()and not any(Path(tmp).glob('audio-effects-*/*result.wav'))
   for bad in [{'mode':'tempo','source':source,'speed':0},{'mode':'music','source':source,'duration':601},{'mode':'music','source':source,'duration':2,'duck':True,'guides':[]},{'mode':'tempo','source':'../../etc/passwd','speed':1}]:
    response=await c.post('/local-api/audio-effects/render',headers=headers,json=bad);assert response.status_code in (400,409),response.text
   assert (await c.post('/local-api/audio-effects/render',json=model)).status_code==403
   assert not s.FLOW_PROVIDER.tasks and not s.GEMINI_CHAT.tasks and not s.MUSE_PROVIDER.tasks
 print('PASS actual FFmpeg tempo duration, real ducking RMS reduction, loop/trim exact duration, canonical media + cache reuse, malformed/path/bounds/session rejection, temp cleanup, zero AI calls.')
if __name__=='__main__':asyncio.run(main())
