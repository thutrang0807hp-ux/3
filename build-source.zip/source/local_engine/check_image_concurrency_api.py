"""Image slot routes and owned Flow extension with fixture managers, not upstream generation."""
import asyncio,os,tempfile,sys,types
from types import SimpleNamespace
import httpx
from fastapi import FastAPI,Header,HTTPException
async def main():
 with tempfile.TemporaryDirectory(prefix='sf-image-api-')as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server as s
  async with httpx.AsyncClient(transport=httpx.ASGITransport(s.app,client=('127.0.0.1',1234)),base_url='http://127.0.0.1:8840',headers={'Origin':'http://127.0.0.1:8840','X-SceneForge-Local':'1'})as c:
   await c.get('/')
   sources=[('gemini-chat/image-concurrency','gemini-chat/status',s.GEMINI_CHAT.image_slots,s.GEMINI_CHAT),('flow/image-concurrency','flow/status',s.FLOW_PROVIDER.image_slots,s.FLOW_PROVIDER)]+[('web-images/'+n+'/concurrency','web-images/'+n+'/status',s.WEB_IMAGES.image_slots[n],s.WEB_IMAGES)for n in ['grok','chatgpt','meta']]
   for path,status,slots,provider in sources:
    result=await c.post('/local-api/'+path,json={'per_account':3});assert result.status_code==200,result.text;assert result.json()['image_per_account']==3
    assert(await c.get('/local-api/'+status)).json()['image_per_account']==3
    for value in [True,0,5,'3']:assert(await c.post('/local-api/'+path,json={'per_account':value})).status_code==400
   s.GEMINI_CHAT.tasks['pending']=object();assert(await c.post('/local-api/gemini-chat/image-concurrency',json={'per_account':2})).status_code==409;s.GEMINI_CHAT.tasks.clear()
   assert(await c.post('/local-api/gemini-chat/image-concurrency',json={'per_account':2})).status_code==200
   with s.REQUESTS.connect()as db:assert db.execute('SELECT COUNT(*) FROM request').fetchone()[0]==0
  print('PASS real app setting routes, strict 1..4, busy blocks, status reads persisted values; no generation submitted')
 # Minimal imports for exercising our owned Flow extension, not the vendor implementation.
 saved={k:sys.modules.get(k)for k in ['src','src.core','src.core.auth','src.core.config']}
 for name in saved:sys.modules[name]=types.ModuleType(name)
 async def auth(authorization:str=Header(default='')):
  if authorization!='Bearer fixture':raise HTTPException(401,'Unauthorized')
 sys.modules['src.core.auth'].verify_api_key_header=auth;sys.modules['src.core.config'].config=SimpleNamespace(flow_max_retries=1)
 try:
  from .flow_account_engine import extend
  row=SimpleNamespace(id=1,email='fixture',name='',is_active=True,image_concurrency=1,video_concurrency=7);updates=[];resets=[];active={'image':0,'video':0}
  class Tokens:
   async def get_active_tokens(self):return [row]
   async def get_all_tokens(self):return [row]
   async def get_token(self,aid):return row if aid==1 else None
   async def update_token(self,aid,**kw):updates.append(kw);[setattr(row,k,v)for k,v in kw.items()]
  class Limits:
   async def get_image_inflight(self,aid):return active['image']
   async def get_video_inflight(self,aid):return active['video']
   async def reset_token(self,aid,**kw):resets.append(kw)
  app=extend(SimpleNamespace(app=FastAPI(),token_manager=Tokens(),concurrency_manager=Limits()))
  async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://fixture',headers={'Authorization':'Bearer fixture'})as c:
   path='/sceneforge/accounts/1/image-concurrency';res=await c.post(path,json={'per_account':3});assert res.json()=={'per_account':3,'kind':'image'};assert resets[-1]=={'image_concurrency':3,'video_concurrency':7}
   active['image']=2;count=len(resets);assert(await c.post(path,json={'per_account':3})).status_code==200;assert len(resets)==count;assert(await c.post(path,json={'per_account':4})).status_code==409;assert row.image_concurrency==3
   active['image']=0;assert(await c.post('/sceneforge/accounts/1/concurrency',json={'per_account':12})).json()=={'per_account':12};assert resets[-1]=={'image_concurrency':3,'video_concurrency':12}
   for value in [0,5,True,'3']:assert(await c.post(path,json={'per_account':value})).status_code==400
   assert(await c.post('/sceneforge/accounts/2/image-concurrency',json={'per_account':3})).status_code==404
   assert(await c.post(path,json={'per_account':3},headers={'Authorization':''})).status_code==401
  print('PASS owned Flow image negotiation, preserves video limit, unchanged setting never resets live semaphore, changed setting blocks in-flight, strict bounds/auth; fixture SDK managers only')
 finally:
  for name,value in saved.items():
   if value is None:sys.modules.pop(name,None)
   else:sys.modules[name]=value
if __name__=='__main__':asyncio.run(main())
