"""Account labels, enabled state and per-service ordering; never fabricate verification/credit."""
import json
from fastapi import HTTPException

def install_account_settings(app,vault):
 @app.post('/local-api/accounts/update')
 async def update(body:dict):
  if set(body)-{'id','name','enabled','note'}:raise HTTPException(400,'Chỉ sửa tên, bật/tắt hoặc ghi chú tài khoản.')
  with vault.lock:
   row=next((r for r in vault.rows('accounts')if r['id']==body.get('id')),None)
   if row is None:raise HTTPException(404,'Không có tài khoản.')
   if 'name'in body:
    if not isinstance(body['name'],str)or not 1<=len(body['name'].strip())<=80:raise HTTPException(400,'Tên cần 1–80 ký tự.')
    row['name']=body['name'].strip()
   if 'note'in body:
    if not isinstance(body['note'],str)or len(body['note'])>500:raise HTTPException(400,'Ghi chú tối đa 500 ký tự.')
    row['note']=body['note']
   if 'enabled'in body:
    if type(body['enabled'])is not bool:raise HTTPException(400,'Bật/tắt cần giá trị hợp lệ.')
    row['enabled']=body['enabled']
    if not row['enabled']:row['active']=False
   vault.put('accounts',row)
  return {'account':row}
 @app.post('/local-api/accounts/order')
 async def order(body:dict):
  service=body.get('service');ids=body.get('ids')
  if service not in ('flow','muse','gemini_chat','grok','chatgpt','meta')or not isinstance(ids,list)or len(ids)>1000 or any(not isinstance(i,str)for i in ids)or len(set(ids))!=len(ids):raise HTTPException(400,'Thứ tự tài khoản không hợp lệ.')
  with vault.lock:
   rows={r['id']:r for r in vault.rows('accounts')if r.get('service')==service}
   if set(rows)!=set(ids):raise HTTPException(409,'Danh sách tài khoản đã đổi; làm mới rồi sắp lại.')
   with vault.db()as db:
    for priority,id in enumerate(ids):
     rows[id]['priority']=priority;db.execute('UPDATE accounts SET data=? WHERE id=?',(json.dumps(rows[id],ensure_ascii=False),id))
  return {'ordered':True,'ids':ids}

 @app.post('/local-api/logs/clear-service')
 async def clear_service(body:dict):
  service=body.get('service')
  if service not in ('flow','muse','gemini_chat','grok','chatgpt','meta'):raise HTTPException(400,'Dịch vụ không hợp lệ.')
  ids={r['id']for r in vault.rows('accounts')if r.get('service')==service}
  with vault.lock,vault.db()as db:
   rows=vault.rows('logs');deleted=0
   for row in rows:
    if row.get('service')==service or row.get('account_id')in ids:db.execute('DELETE FROM logs WHERE id=?',(row['id'],));deleted+=1
  return {'ok':True,'deleted':deleted}
