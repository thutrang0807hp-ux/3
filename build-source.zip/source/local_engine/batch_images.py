"""Explicit Gemini image submission, durable claims and recoverable immutable files.
No automatic retries, account rotation, guessed model fallback or remote URL fetching.
"""
import asyncio,base64,binascii,hashlib,io,json,os,re,time,uuid
from pathlib import Path
import httpx
from PIL import Image
from fastapi import HTTPException
from fastapi.responses import FileResponse
from .request_ledger import RequestConflict,NO_RESULT

class BatchImages:
 def __init__(self,vault,root,ledger,client_factory=None):
  self.vault=vault;self.root=Path(root)/'batch-images';self.root.mkdir(exist_ok=True,mode=0o700);self.ledger=ledger
  self.client_factory=client_factory or (lambda:httpx.AsyncClient(timeout=180,follow_redirects=False));self.tasks={};self.lane=asyncio.Semaphore(4)
 def models(self):
  cached=self.vault.secret('gemini-image-models')or{}
  return {'configured':bool(self.vault.secret('gemini')),'models':cached.get('models',[]),'checked_at':cached.get('at'),'generation_verified':False,'automatic_retry':False,'max_concurrency':4}
 async def discover(self):
  key=self.vault.secret('gemini')
  if not key:raise HTTPException(409,'Lưu key Gemini trong Cài đặt → Phân tích (AI) trước.')
  names=[];token=None
  try:
   async with self.client_factory()as client:
    for _ in range(10):
     params={'pageSize':100}
     if token:params['pageToken']=token
     r=await client.get('https://generativelanguage.googleapis.com/v1beta/models',headers={'x-goog-api-key':key},params=params)
     if r.status_code!=200:raise HTTPException(r.status_code,'Gemini chưa cho phép đọc danh sách model tạo ảnh.')
     data=r.json()
     for model in data.get('models',[]):
      name=model.get('name','')
      if re.fullmatch(r'models/[A-Za-z0-9._-]+',name)and 'image'in name.lower()and'generateContent'in model.get('supportedGenerationMethods',[]):names.append(name.removeprefix('models/'))
     token=data.get('nextPageToken')
     if not token:break
    else:raise HTTPException(502,'Danh sách model quá dài; chưa lưu kết quả không đầy đủ.')
  except (httpx.HTTPError,ValueError,TypeError):raise HTTPException(502,'Chưa đọc được danh sách model Gemini. Không có yêu cầu tạo ảnh nào được gửi.')
  self.vault.set_secret('gemini-image-models',{'models':sorted(set(names)),'at':time.time()});return self.models()
 def lookup(self,request_id):
  self.valid_id(request_id)
  with self.ledger.connect()as db:row=db.execute('SELECT state,result,updated FROM request WHERE id=?',(request_id,)).fetchone()
  if not row:raise HTTPException(404,'Chưa có yêu cầu tạo ảnh với mã này.')
  # Requests are namespaced to prevent exposing results from unrelated AI helpers.
  if row[0]=='done'and not str(json.loads(row[1]).get('file','')).startswith(request_id+'.'):raise HTTPException(409,'Mã này không phải kết quả tạo ảnh.')
  return {'request_id':request_id,'state':row[0],'result':json.loads(row[1])if row[0]=='done'else None,'updated':row[2],'automatic_retry':False}
 @staticmethod
 def valid_id(value):
  if not isinstance(value,str)or not re.fullmatch(r'batch-image-[a-f0-9-]{36}',value):raise HTTPException(400,'Mã lượt tạo ảnh không hợp lệ.')
  try:uuid.UUID(value.removeprefix('batch-image-'))
  except ValueError:raise HTTPException(400,'Mã lượt tạo ảnh không hợp lệ.')
 @staticmethod
 def decode_image(value):
  if not isinstance(value,dict)or value.get('mime_type')not in {'image/png','image/jpeg','image/webp'}or not isinstance(value.get('data'),str)or len(value['data'])>8*1024**2:raise HTTPException(400,'Ảnh tham chiếu PNG/JPEG/WebP tối đa 6 MB.')
  try:
   raw=base64.b64decode(value['data'],validate=True)
   with Image.open(io.BytesIO(raw))as im:
    if im.width*im.height>40_000_000 or Image.MIME.get(im.format)!=value['mime_type']:raise ValueError()
    im.verify()
  except (ValueError,binascii.Error,OSError,Image.DecompressionBombError):raise HTTPException(400,'Ảnh tham chiếu không đọc được hoặc sai định dạng.')
  return len(raw)
 async def submit(self,body):
  if body.get('confirm_send')is not True:raise HTTPException(409,'Cần xác nhận gửi prompt/ảnh tới Gemini; lượt tạo có thể tính phí.')
  request_id=body.get('request_id');self.valid_id(request_id)
  prompt=body.get('prompt');model=body.get('model');refs=body.get('references',[]);aspect=body.get('aspect')
  if not isinstance(prompt,str)or not prompt.strip()or len(prompt)>4000 or aspect not in {'9:16','16:9','1:1','4:5'}:raise HTTPException(400,'Prompt hoặc tỉ lệ ảnh không hợp lệ.')
  if model not in self.models()['models']:raise HTTPException(409,'Đọc danh sách model và chọn model tạo ảnh có trong key trước.')
  key=self.vault.secret('gemini')
  if not key:raise HTTPException(409,'Chưa có key Gemini trên máy.')
  if not isinstance(refs,list)or len(refs)>8:raise HTTPException(400,'Tối đa 8 ảnh tham chiếu.')
  if sum(self.decode_image(r)for r in refs)>24*1024**2:raise HTTPException(400,'Tổng ảnh tham chiếu tối đa 24 MB.')
  if len(self.tasks)>=16 and request_id not in self.tasks:raise HTTPException(429,'Hàng chờ tạo ảnh cục bộ đang đầy. Chưa gửi yêu cầu mới.')
  payload={'kind':'batch-image','room_id':str(body.get('room_id',''))[:100],'scene_id':str(body.get('scene_id',''))[:100],'model':model,'prompt':prompt,'aspect':aspect,'references':refs,'product_id':str(body.get('product_id',''))[:100]}
  try:
   _,cached=self.ledger.claim(request_id,payload)
  except (RequestConflict,ValueError)as e:raise HTTPException(409,str(e))
  if cached is not NO_RESULT:return self.lookup(request_id)
  # Claim is durable BEFORE any network call; a duplicate cannot send twice.
  self.tasks[request_id]=asyncio.create_task(self.run(request_id,payload,key));self.tasks[request_id].add_done_callback(lambda t:self.tasks.pop(request_id,None))
  return {'request_id':request_id,'state':'submitted','automatic_retry':False}
 async def run(self,request_id,payload,key):
  started=time.monotonic();state='unknown';result=None;code='UNKNOWN'
  try:
   async with self.lane:
    parts=[{'text':payload['prompt']}]+[{'inline_data':r}for r in payload['references']]
    async with self.client_factory()as client:
     async with client.stream('POST','https://generativelanguage.googleapis.com/v1beta/models/'+payload['model']+':generateContent',headers={'x-goog-api-key':key},json={'contents':[{'role':'user','parts':parts}],'generationConfig':{'responseModalities':['TEXT','IMAGE'],'imageConfig':{'aspectRatio':payload['aspect']}}})as response:
      if response.status_code!=200:
       state='failed'if 400<=response.status_code<500 else'unknown';code='HTTP_'+str(response.status_code);return
      chunks=[];size=0
      async for chunk in response.aiter_bytes():
       size+=len(chunk)
       if size>24*1024**2:raise ValueError('response size')
       chunks.append(chunk)
    data=json.loads(b''.join(chunks));images=[p.get('inlineData',p.get('inline_data'))for c in data.get('candidates',[])for p in c.get('content',{}).get('parts',[])if p.get('inlineData')or p.get('inline_data')]
    if not images:code='NO_IMAGE';return
    image=images[0];mime=image.get('mimeType',image.get('mime_type'));encoded=image.get('data');self.decode_image({'mime_type':mime,'data':encoded});raw=base64.b64decode(encoded,validate=True)
    with Image.open(io.BytesIO(raw))as im:width,height=im.size
    ext={'image/png':'.png','image/jpeg':'.jpg','image/webp':'.webp'}[mime];name=request_id+ext;path=self.root/name;tmp=self.root/(request_id+'.partial')
    with tmp.open('xb')as output:output.write(raw);output.flush();os.fsync(output.fileno())
    os.replace(tmp,path)
    result={'file':name,'mime_type':mime,'width':width,'height':height,'model':payload['model'],'sha256':hashlib.sha256(raw).hexdigest(),'usage':data.get('usageMetadata'),'cost':None,'cost_note':'Chưa xác minh phí thực tế.','origin':'gemini'};state='done';code='DONE'
  except asyncio.CancelledError:code='INTERRUPTED';raise
  except Exception:code='NETWORK_OR_RESPONSE_UNKNOWN'
  finally:
   self.ledger.finish(request_id,state,result)
   self.vault.put('logs',{'id':request_id,'kind':'Gemini image','state':state,'at':time.time(),'duration':round(time.monotonic()-started,3),'model':payload['model'],'product_id':payload['product_id'],'code':code,'cost':None,'usage':result.get('usage')if result else None})
 def file(self,request_id):
  if self.ledger.storage:
   stored=self.ledger.storage.file(request_id)
   if stored is not None:
    record=self.lookup(request_id)
    if record['state']=='done':return FileResponse(stored,media_type=record['result'].get('mime_type','image/png'),filename=record['result'].get('file',request_id))
  record=self.lookup(request_id)
  if record['state']!='done':raise HTTPException(409,'Lượt này chưa có ảnh hoàn tất được ghi nhận.')
  result=record['result'];name=result.get('file','')
  if name not in {request_id+'.png',request_id+'.jpg',request_id+'.webp'}:raise HTTPException(409,'Tên file kết quả không hợp lệ.')
  path=self.root/name
  if not path.is_file():raise HTTPException(404,'Thiếu file kết quả. Không gửi tạo lại tự động.')
  return FileResponse(path,media_type=result['mime_type'],filename=path.name)
 async def close(self):
  tasks=list(self.tasks.values())
  for task in tasks:task.cancel()
  if tasks:await asyncio.gather(*tasks,return_exceptions=True)

def install_batch_images(app,vault,root,ledger):
 service=BatchImages(vault,root,ledger)
 @app.get('/local-api/batch/images')
 async def status():return service.models()
 @app.post('/local-api/batch/images/models')
 async def models():return await service.discover()
 @app.post('/local-api/batch/images')
 async def submit(body:dict):return await service.submit(body)
 @app.get('/local-api/batch/images/{request_id}')
 async def result(request_id:str):return service.lookup(request_id)
 @app.get('/local-api/batch/images/{request_id}/file')
 async def file(request_id:str):return service.file(request_id)
 return service
