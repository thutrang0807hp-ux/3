"""Storyboard -> batched prompts -> project board -> whole draft -> real editor.
Chromium + actual SQLite/library; deterministic provider transport, no online AI.
"""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64,json
from pathlib import Path
from playwright.sync_api import sync_playwright


def main():
 root=Path(__file__).resolve().parents[1]
 video=(root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()
 with tempfile.TemporaryDirectory(prefix='sf-story-production-') as data:
  with socket.socket() as sock:
   sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];sent=[];responses={};reads=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    status={'installed':True,'configured':True,'account_binding':True,'models':['veo-portrait'],'accounts':[],'per_account':2,'max_concurrency':3,'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'token'}}
    for service in ['gemini-chat','flow','muse']:
     page.route('**/local-api/'+service+'/status',lambda route:route.fulfill(json=status))
    def dispatch(route):
     body=route.request.post_data_json;sent.append(body);rid=body['request_id']
     if body['kind']=='text':
      source=json.loads(body['prompt'].split('\n',1)[1]);rows=[]
      for b in source['beats']:
       rows.append({k:b[k] for k in ['id','type','seconds','text']}|{'angle':'Medium','movement':'Slow push','visualPrompt':'Original product on table','motionPrompt':'One slow camera push','refRoles':['product'],'partPrompts':{p['id']:{'visualPrompt':'Original product','motionPrompt':'Slow push '+p['id']}for p in b['parts']}})
      responses[rid]={'id':rid,'state':'done','result':{'text':json.dumps({'beats':rows}),'account_id':'fixture-gemini'}}
     elif body['kind']=='video':
      responses[rid]={'id':rid,'state':'done','result':{'mime_type':'video/mp4','account_id':'fixture-flow'}}
     route.fulfill(json={'id':rid,'state':'submitted'})
    for service in ['gemini-chat','flow','muse']:
     page.route('**/local-api/'+service+'/jobs',dispatch)
     page.route('**/local-api/'+service+'/jobs/*',lambda route:(reads.append(route.request.url),route.fulfill(json=responses.get(route.request.url.rsplit('/',1)[-1],{'state':'unknown'})))[-1])
     page.route('**/local-api/'+service+'/files/*',lambda route:route.fulfill(body=video,content_type='video/mp4'))
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'story-fixture',name:'Story production',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoPrepareStoryboard==="function"')
    wf.evaluate('''async()=>{const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=800;canvas.getContext('2d').fillRect(0,0,1200,800);const image=canvas.toDataURL(),key=room.id+':story';await bridge.putFile(key,await(await fetch(image)).blob());draft.refs={product:{images:[{id:'p',name:'Original',image}]},person:{images:[]},background:{images:[]}};draft.idea='Giới thiệu sản phẩm';draft.voice.mode='native';draft.beats=Array.from({length:9},(_,i)=>({id:'b'+i,name:'Cảnh '+(i+1),type:'wide',seconds:4,text:'Xin chào.',clips:[]}));draft.providers={creative:'gemini',video:'flow',flowModel:'veo-portrait'};draft.flowJobs=[];draft.geminiJobs=[];draft.storyboardImages=[{id:'one',key,preview:image,name:'Overall',version:1}];draft.storyboardImage='one';await save();render();await photoToolbarRefresh(true);}''')
    assert wf.locator('[data-node=frames]').count()==0
    assert wf.locator('[data-node=bank] .productionSlot').count()==9
    assert wf.locator('.productionDirections').evaluate('(n)=>!n.open')
    wf.locator('#photoNext').click();wf.locator('#productionPrepareSend').wait_for();assert not sent
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoMediaBusy&&!photoProductionWorking')
    assert len(sent)==2 and all(j['kind']=='text' for j in sent)
    assert [len(json.loads(j['prompt'].split('\n',1)[1])['beats'])for j in sent]==[8,1]
    assert all(len(j['references'])==2 for j in sent)
    assert wf.evaluate("async refs=>{const r=refs.at(-1),b=await createImageBitmap(await(await fetch('data:'+r.mime_type+';base64,'+r.data)).blob());return b.width;}",sent[0]['references'])==1200
    # Restart with durable intents. Recovery never dispatches again.
    page.evaluate('async()=>{await flushFrames();await SceneForgeStorage.checkpoint();}')
    page.reload();page.wait_for_function('!!db&&SceneForgeStorage.state.active')
    page.evaluate("async()=>{document.querySelector('#shellDialog').close();await openRoom('story-fixture','analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoWorkflowReceive==="function"')
    wf.evaluate('async()=>{await photoWorkflowReceive();await photoWorkflowReceive();}')
    assert len(sent)==2
    assert wf.evaluate('photoPromptsCurrent()')
    assert wf.locator('#photoApplyChat').count()==0
    assert wf.evaluate('draft.beats.every(b=>b.partPrompts.a.motionPrompt==="Slow push a")')
    # Legacy echoes tolerate harmless formatting; app-owned words stay intact.
    assert wf.evaluate("()=>{const j=draft.geminiJobs[1],r=JSON.parse(j.rawResult);r.beats[0].seconds=4.000000000000001;r.beats[0].text='  Xin chào.  ';return photoValidatePromptBatch(j,JSON.stringify(r)).length===1&&draft.beats[8].text==='Xin chào.';}")
    # Malformed response goes to invalid, stops polling and remains editable
    # through the actual history dialog, without any generation POST.
    wf.evaluate("async()=>{draft.beats[8].text='Lời sửa.';await save();await photoPrepareStoryboard();}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    rid=sent[-1]['request_id'];valid=responses[rid]['result']['text'];bad=json.loads(valid);bad['beats'][0]['partPrompts']={};responses[rid]['result']['text']=json.dumps(bad)
    wf.evaluate('photoWorkflowReceive()');assert wf.evaluate("draft.geminiJobs.at(-1).state==='invalid'")
    before=len(reads);wf.evaluate('photoWorkflowReceive()');assert len(reads)==before and len(sent)==3
    wf.evaluate('photoSentJobs()');wf.locator('[data-photo-fix-json]').click()
    wf.locator('#photoPromptJson').fill('{"beats":[]}');wf.locator('#photoSavePromptJson').click()
    assert wf.locator('#photoPromptJsonError').inner_text()
    corrected=json.loads(valid)
    for row in corrected['beats']:
     for k in ['text','seconds','type']:row.pop(k)
    wf.locator('#photoPromptJson').fill(json.dumps(corrected));wf.locator('#photoSavePromptJson').click();wf.wait_for_function('photoPromptsCurrent()')
    assert len(sent)==3 and wf.evaluate("draft.geminiJobs.at(-1).state==='imported'&&!!draft.geminiJobs.at(-1).rawResult&&!!draft.geminiJobs.at(-1).correctedText")
    # Actual slot edit + real stored clip in a sibling. Regenerating a changed
    # group must preserve both manual directions and the untouched clip signature.
    wf.evaluate("photoSlotDialog('b0','a')");wf.locator('#photoPartMotion').fill('USER CAMERA');wf.locator('#photoSavePartText').click();wf.wait_for_function('draft.beats[0].manualDirections===true');wf.locator('#closePhotoDialog').click()
    wf.evaluate("async()=>{const b=draft.beats[2],p=photoParts(b)[0],blob=await(await fetch('/local-api/flow/files/existing')).blob(),key=room.id+':retained';await bridge.putFile(key,blob);b.clips=[{id:'retained',key,part:p.id,version:1,signature:photoSceneSignature(b,p),...await photoReadClip(blob,p.generationDuration||p.duration)}];window.retainedSignature=b.clips[0].signature;draft.beats[1].text='Chỉ nhịp này thay lời.';await save();await photoPrepareStoryboard();}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    rid=sent[-1]['request_id'];data=json.loads(responses[rid]['result']['text'])
    for row in data['beats']:
     row['movement']='NEW';row['partPrompts']['a']['motionPrompt']='NEW'
    responses[rid]['result']['text']=json.dumps(data)
    wf.evaluate('photoWorkflowReceive()')
    assert wf.evaluate("draft.beats[0].partPrompts.a.motionPrompt==='USER CAMERA'&&draft.beats[1].partPrompts.a.motionPrompt==='NEW'&&draft.beats[2].clips[0].signature===retainedSignature&&photoDraftReady(draft.beats[2],photoParts(draft.beats[2])[0])")
    assert len(sent)==4
    # A user direction edit while a request is in flight also wins over AI.
    wf.evaluate("async()=>{draft.beats[3].text='Nhịp ba thay lời.';await save();await photoPrepareStoryboard();}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    wf.evaluate("()=>{const input=document.querySelector('[data-story-card=\"b3\"] [data-story-field=\"motionPrompt\"]');input.value='EDIT WHILE WAITING';input.dispatchEvent(new Event('input',{bubbles:true}));}")
    wf.evaluate('photoWorkflowReceive()');assert wf.evaluate("draft.beats[3].motionPrompt==='EDIT WHILE WAITING'&&draft.geminiJobs.at(-1).preservedBeats.includes('b3')")
    assert len(sent)==5
    # Explicitly preserving manual directions adopts the new context locally;
    # these records must not cause another cloud request or strand the project.
    wf.evaluate("async()=>{for(const b of draft.beats)b.manualDirections=true;draft.idea='Ý chính mới, giữ chỉ dẫn tay';await save();await photoPrepareStoryboard();}")
    assert len(sent)==5 and wf.evaluate('photoPromptsCurrent()')
    # Pin actual audio bytes once for listening, draft preview and old handoff.
    wf.evaluate("async()=>{const blob=await(await fetch('/local-api/flow/files/music')).blob();await bridge.putFile('song-a',blob);await bridge.putFile('song-b',blob);Object.assign(photoProduction(),{musicMode:'random',musicKey:'song-a',music:[{key:'song-a',name:'Song A'},{key:'song-b',name:'Song B'}]});await actions['photo-listen-music']();window.songKey=photoProductionState().musicChoice;}")
    assert wf.locator('#photoMusicListen').get_attribute('src')
    wf.locator('#closePhotoDialog').click()
    assert wf.evaluate("async()=>{const a=await photoBuildDraftPayload(),b=await photoBuildDraftPayload(),old={audio:[],placement:'library'},placement=draft.placement;draft.placement='library';try{await photoProductionHandoff(old);}finally{draft.placement=placement;}return a.payload.audio.find(a=>a.role==='music').key===songKey&&b.payload.audio.find(a=>a.role==='music').key===songKey&&old.audio.find(a=>a.role==='music').key===songKey;}")
    page.evaluate('async()=>{await flushFrames();await SceneForgeStorage.checkpoint();}');page.reload();page.wait_for_function('!!db&&SceneForgeStorage.state.active');page.evaluate("async()=>{document.querySelector('#shellDialog').close();await openRoom('story-fixture','analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoChosenMusic==="function"')
    assert wf.evaluate("async()=>{const selected=photoProductionState().musicChoice;return !!selected&&(await photoChosenMusic()).key===selected;}")
    assert len(sent)==5 and not errors,errors
    browser.close()
    print('PASS prompt repair/music: legacy numeric/whitespace echo accepted without changing script; invalid stops polling; actual JSON edit UI repairs schema-only reply without another job; changed group preserves manual sibling and real ready clip/file signature; random music shared by listen/preview/handoff and SQLite restart. Provider transport fixtures only.')
  finally:
   proc.terminate();proc.wait(timeout=15)

if __name__=='__main__':main()
