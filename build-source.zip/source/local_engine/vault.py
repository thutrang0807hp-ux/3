"""Encrypted-at-rest credentials. The UI never receives stored secret values."""
from pathlib import Path
import base64,json,os,secrets,sqlite3,threading
from contextlib import contextmanager
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

class Vault:
 def __init__(self,root):
  self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True,mode=0o700);os.chmod(self.root,0o700)
  self.path=self.root/'vault.sqlite';keyfile=self.root/'vault.key';self.lock=threading.RLock()
  if keyfile.exists():raw=keyfile.read_bytes();self.key=self._windows_unprotect(raw) if os.name=='nt' else raw
  else:
   self.key=secrets.token_bytes(32);raw=self._windows_protect(self.key) if os.name=='nt' else self.key
   fd=os.open(keyfile,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   with os.fdopen(fd,'wb') as f:f.write(raw)
  from .schema import migrate
  migrate(self.path,[
   'CREATE TABLE IF NOT EXISTS secrets (name TEXT PRIMARY KEY, value BLOB NOT NULL)',
   'CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, data TEXT NOT NULL)',
   'CREATE TABLE IF NOT EXISTS logs (id TEXT PRIMARY KEY, data TEXT NOT NULL)'])
  os.chmod(self.path,0o600)
 @staticmethod
 def _dpapi(raw,protect):
  import ctypes
  from ctypes import wintypes
  class Blob(ctypes.Structure):_fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]
  buf=ctypes.create_string_buffer(raw);src=Blob(len(raw),ctypes.cast(buf,ctypes.POINTER(ctypes.c_byte)));out=Blob()
  fn=ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
  if protect:ok=fn(ctypes.byref(src),None,None,None,None,0,ctypes.byref(out))
  else:ok=fn(ctypes.byref(src),None,None,None,None,0,ctypes.byref(out))
  if not ok:raise OSError('Không mở được khóa của người dùng Windows.')
  try:return ctypes.string_at(out.pbData,out.cbData)
  finally:ctypes.windll.kernel32.LocalFree(out.pbData)
 @classmethod
 def _windows_protect(cls,raw):return cls._dpapi(raw,True)
 @classmethod
 def _windows_unprotect(cls,raw):return cls._dpapi(raw,False)
 @contextmanager
 def db(self):
  db=sqlite3.connect(self.path,timeout=30)
  try:
   with db:yield db
  finally:db.close()
 def set_secret(self,name,value):
  nonce=secrets.token_bytes(12);cipher=nonce+AESGCM(self.key).encrypt(nonce,json.dumps(value).encode(),name.encode())
  with self.lock,self.db() as db:db.execute('INSERT OR REPLACE INTO secrets VALUES (?,?)',(name,cipher))
 def set_secrets(self,values,remove=()):
  """Commit related credential/check metadata together; never expose plaintext to the UI."""
  rows=[]
  for name,value in values.items():
   nonce=secrets.token_bytes(12);cipher=nonce+AESGCM(self.key).encrypt(nonce,json.dumps(value).encode(),name.encode());rows.append((name,cipher))
  with self.lock,self.db()as db:
   db.executemany('DELETE FROM secrets WHERE name=?',[(name,)for name in remove]);db.executemany('INSERT OR REPLACE INTO secrets VALUES (?,?)',rows)
 def secret(self,name):
  with self.db() as db:row=db.execute('SELECT value FROM secrets WHERE name=?',(name,)).fetchone()
  if not row:return None
  value=bytes(row[0]);return json.loads(AESGCM(self.key).decrypt(value[:12],value[12:],name.encode()))
 def delete_secret(self,name):
  with self.lock,self.db() as db:db.execute('DELETE FROM secrets WHERE name=?',(name,))
 def rows(self,kind):
  if kind not in {'accounts','logs'}:raise ValueError(kind)
  with self.db() as db:rows=[json.loads(r[0]) for r in db.execute('SELECT data FROM '+kind)]
  if kind=='logs':
   from .package5 import scrub
   return scrub(rows)
  return rows
 def put(self,kind,row):
  if kind not in {'accounts','logs'}:raise ValueError(kind)
  if kind=='logs':
   from .package5 import scrub
   row=scrub(row)
  with self.lock,self.db() as db:
   db.execute('INSERT OR REPLACE INTO '+kind+' VALUES (?,?)',(row['id'],json.dumps(row,ensure_ascii=False)))
   if kind=='logs':db.execute('DELETE FROM logs WHERE rowid NOT IN (SELECT rowid FROM logs ORDER BY rowid DESC LIMIT 5000)')
 def delete(self,kind,id):
  if kind not in {'accounts','logs'}:raise ValueError(kind)
  with self.lock,self.db() as db:db.execute('DELETE FROM '+kind+' WHERE id=?',(id,))
