"""Offline tempo and music-bed rendering from canonical assets. Never invokes AI."""
import asyncio,hashlib,json,math,shutil,tempfile,wave,os
from pathlib import Path
from fastapi import HTTPException
from .machine_checks import run_command

def num(v,low,high):
 if type(v)not in (int,float)or not math.isfinite(v)or not low<=v<=high:raise HTTPException(400,'Thông số âm thanh không hợp lệ.')
 return round(v,5)
def normalize(body):
 mode=body.get('mode');source=body.get('source')
 if mode not in ('tempo','music')or not isinstance(source,str)or len(source)!=64 or any(c not in '0123456789abcdef'for c in source):raise HTTPException(400,'Cần nguồn âm thanh trong kho.')
 out={'mode':mode,'source':source}
 if mode=='tempo':out['speed']=num(body.get('speed',1),.5,2)
 else:
  out['duration']=num(body.get('duration'),.02,600);out['duck']=body.get('duck')is True;out['guides']=[]
  guides=body.get('guides',[])
  if not isinstance(guides,list)or len(guides)>150:raise HTTPException(400,'Tối đa 150 đoạn tiếng dẫn.')
  for g in guides:
   if not isinstance(g,dict):raise HTTPException(400,'Đoạn tiếng dẫn không hợp lệ.')
   asset=g.get('asset')
   if not isinstance(asset,str)or len(asset)!=64 or any(c not in '0123456789abcdef'for c in asset):raise HTTPException(400,'Mã tiếng dẫn không hợp lệ.')
   row={'asset':asset,'start':num(g.get('start',0),0,600),'offset':num(g.get('offset',0),0,36000),'duration':num(g.get('duration'),.02,600)}
   if row['start']+row['duration']>out['duration']+.05:raise HTTPException(400,'Tiếng dẫn vượt bản ghép.')
   out['guides'].append(row)
  if out['duck']and not guides:raise HTTPException(409,'Chưa có tiếng giọng/clip để hạ nhạc theo. Thêm tiếng hoặc tắt chế độ hạ nhạc.')
 return out

class AudioEffects:
 def __init__(self,data,library,budget):
  self.data=Path(data);self.library=library;self.budget=budget;self.lock=asyncio.Lock();self.index=self.data/'audio-effects-cache.json'
  try:self.cache=json.loads(self.index.read_text())
  except (OSError,ValueError):self.cache={}
 def source(self,h):
  path=self.library.asset_path(h)
  if not path.is_file():raise HTTPException(409,'Tệp âm thanh đã thiếu hoặc đang ở khu chờ xóa. Chọn lại nguồn.')
  if path.stat().st_size>500*1024**2:raise HTTPException(413,'Nguồn tối đa 500 MB.')
  return path
 async def probe(self,path):
  rc,out,_=await run_command('ffprobe','-v','error','-protocol_whitelist','file,pipe','-show_streams','-show_format','-of','json',str(path),timeout=30)
  try:
   info=json.loads(out);duration=float(info['format']['duration']);audio=any(s.get('codec_type')=='audio'for s in info['streams'])
   if rc or not math.isfinite(duration)or not 0<duration<=36000:raise ValueError()
   return duration,audio
  except (ValueError,KeyError,TypeError):raise HTTPException(400,'Không đọc được âm thanh nguồn.')from None
 async def render(self,body):
  if not(shutil.which('ffmpeg')and shutil.which('ffprobe')):raise HTTPException(409,'Cần FFmpeg/ffprobe để xử lý âm thanh trên máy.')
  model=normalize(body);signature=hashlib.sha256(json.dumps(model,sort_keys=True).encode()).hexdigest()
  async with self.lock:
   inputs=[self.source(model['source'])]+[self.source(g['asset'])for g in model.get('guides',[])]
   previous=self.cache.get(signature)
   if previous and self.library.asset_path(previous['hash']).is_file():return {**previous,'cached':True,'provider_requests':0}
   self.budget(150*1024**2)
   length,has_audio=await self.probe(inputs[0])
   if not has_audio:raise HTTPException(400,'File nguồn không có âm thanh.')
   args=['ffmpeg','-v','error','-nostdin','-threads','2','-filter_complex_threads','1']
   if model['mode']=='tempo':
    if length/model['speed']>1800:raise HTTPException(400,'Giọng sau đổi tốc độ tối đa 30 phút.')
    args+=['-protocol_whitelist','file,pipe','-i',str(inputs[0]),'-vn','-af','atempo='+str(model['speed'])]
    duration=length/model['speed']
   else:
    duration=model['duration'];args+=['-stream_loop','-1','-protocol_whitelist','file,pipe','-i',str(inputs[0])]
    filters=[f'[0:a]atrim=duration={duration},asetpts=PTS-STARTPTS,aresample=24000,aformat=channel_layouts=stereo[bed]'];guides=[]
    for n,(g,path)in enumerate(zip(model['guides'],inputs[1:]),1):
     glength,has_audio=await self.probe(path)
     args+=['-protocol_whitelist','file,pipe','-i',str(path)]
     if not has_audio or g['offset']>=glength:continue
     end=min(g['duration'],glength-g['offset']);filters.append(f'[{n}:a]atrim=start={g["offset"]}:duration={end},asetpts=PTS-STARTPTS,aresample=24000,aformat=channel_layouts=stereo,apad,atrim=duration={g["duration"]},adelay={round(g["start"]*1000)}:all=1[g{n}]');guides.append(f'[g{n}]')
    if model['duck']:
     if not guides:raise HTTPException(409,'Các clip đã chọn không có tiếng để hạ nhạc theo.')
     filters.append(''.join(guides)+f'amix=inputs={len(guides)}:duration=longest:normalize=0,apad,atrim=duration={duration}[guide]')
     filters.append('[bed][guide]sidechaincompress=threshold=0.025:ratio=8:attack=15:release=250[out]')
    else:filters.append('[bed]anull[out]')
    args+=['-filter_complex',';'.join(filters),'-map','[out]']
   with tempfile.TemporaryDirectory(prefix='audio-effects-',dir=self.data)as temp:
    output=Path(temp)/'result.wav';args+=['-t',str(duration),'-ar','24000','-ac','2','-c:a','pcm_s16le','-y',str(output)]
    rc,_,_=await run_command(*args,timeout=300,tree=True)
    if rc or not output.is_file():raise HTTPException(503,'FFmpeg chưa xử lý được âm thanh. Giữ file gốc, không đổi clip.')
    with wave.open(str(output),'rb')as audio:actual=audio.getnframes()/audio.getframerate()
    if not math.isfinite(actual)or abs(actual-duration)>.15:raise HTTPException(503,'Thời lượng âm thanh sau xử lý chưa khớp. Chưa áp dụng.')
    saved=self.library.add_file(output,mime='audio/wav');h=saved['hash'];result={'hash':h,'url':'/local-api/library/assets/'+h,'duration':actual,'signature':signature,'mode':model['mode']}
   self.cache[signature]=result
   # Cache indexes only. Media itself is owned/reclaimed by the existing library lifecycle.
   if len(self.cache)>500:self.cache=dict(list(self.cache.items())[-500:])
   temp=self.index.with_suffix('.tmp');temp.write_text(json.dumps(self.cache));os.replace(temp,self.index)
   return {**result,'cached':False,'provider_requests':0}

def install_audio_effects(app,data,library,budget):
 service=AudioEffects(data,library,budget)
 @app.get('/local-api/audio-effects/status')
 async def status():return {'available':bool(shutil.which('ffmpeg')and shutil.which('ffprobe')),'local':True,'busy':service.lock.locked(),'voice_clone':False}
 @app.post('/local-api/audio-effects/render')
 async def render(body:dict):return await service.render(body)
 return service
