"""Configurable local image admission. Provider quotas are never changed or retried."""
import asyncio
from contextlib import asynccontextmanager
from fastapi import HTTPException

class ImageSlots:
    maximum = 4
    def __init__(self, vault, service):
        self.vault,self.service=vault,service
        self.condition=asyncio.Condition();self.active={};self.exclusive_accounts=set()
    def limit(self):
        value=(self.vault.secret(self.service+'-image-slots')or{}).get('per_account',1)
        return value if type(value)is int and 1<=value<=self.maximum else 1
    def status(self):
        return {'image_per_account':self.limit(),'image_max_concurrency':self.maximum,
                'image_maximum_setting':self.maximum,'image_active_by_account':dict(self.active)}
    def configure(self,body,busy=False):
        value=body.get('per_account')
        if type(value)is not int or not 1<=value<=self.maximum:
            raise HTTPException(400,'Số ảnh đồng thời mỗi tài khoản phải từ 1 đến 4.')
        if busy or self.active or self.exclusive_accounts:
            raise HTTPException(409,'Đợi công việc của nguồn này hoàn tất trước khi đổi số ảnh đồng thời.')
        self.vault.set_secret(self.service+'-image-slots',{'per_account':value})
        return self.status()
    @asynccontextmanager
    async def slot(self,aid):
        async with self.condition:
            await self.condition.wait_for(lambda:aid not in self.exclusive_accounts and self.active.get(aid,0)<self.limit() and sum(self.active.values())<self.maximum)
            self.active[aid]=self.active.get(aid,0)+1
        try:yield
        finally:
            async with self.condition:
                self.active[aid]-=1
                if not self.active[aid]:self.active.pop(aid)
                self.condition.notify_all()
    @asynccontextmanager
    async def exclusive(self,aid):
        async with self.condition:
            await self.condition.wait_for(lambda:aid not in self.exclusive_accounts and not self.active.get(aid))
            self.exclusive_accounts.add(aid)
        try:yield
        finally:
            async with self.condition:
                self.exclusive_accounts.remove(aid);self.condition.notify_all()
