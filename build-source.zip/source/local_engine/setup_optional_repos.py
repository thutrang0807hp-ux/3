"""Prepare reviewed repositories without accounts, browser startup or model download.

python -m local_engine.setup_optional_repos muse
python -m local_engine.setup_optional_repos voice
python -m local_engine.setup_optional_repos gemini

The Muse repository targets muse.ai; it is NOT a verified Meta AI integration.
"""
import argparse
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import venv

REPOS = {
    'gemini': {'url': 'https://github.com/HanaokaYuzu/Gemini-API.git',
               'revision': '1ad0d4a93e505e77c79769d78ef2997641f973c8', 'directory': 'gemini-web',
               'site': 'https://gemini.google.com/', 'minimum_python': (3, 11)},
    'muse': {'url': 'https://github.com/czg86389-hub/muse2api.git',
             'revision': '5542a479ec6ba036a9717e8776380ff5aacf3fe7', 'directory': 'muse2api', 'site': 'https://muse.ai/'},
    'voice': {'url': 'https://github.com/pnnbao97/VieNeu-TTS.git',
              'revision': '04044e1b8f822f946bafb2c88b716459f4164152', 'directory': 'vieneu', 'site': None},
}


def prepare(name, directory, source=None):
    spec = REPOS[name]
    minimum_python = spec.get('minimum_python', (3, 10))
    if sys.version_info[:2] < minimum_python:
        raise RuntimeError('Repo này cần Python '+'.'.join(map(str,minimum_python))+' trở lên; không đổi Python của app tự động.')
    root = Path(directory).resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    checkout, environment = root / 'source', root / 'venv'
    if not checkout.exists() and not shutil.which('git'):
        raise RuntimeError('Cần cài Git trước.')
    if not checkout.exists():
        subprocess.run(['git', 'clone', '--no-hardlinks', source or spec['url'], str(checkout)], check=True)
        subprocess.run(['git', '-C', str(checkout), 'checkout', '--detach', spec['revision']], check=True)
    from .reviewed_source import revision as source_revision, pip_arguments
    revision = source_revision(checkout,spec['revision'])
    if revision != spec['revision']:
        raise RuntimeError('Repo khác revision đã kiểm tra; không tự ghi đè.')
    if not environment.exists():
        venv.EnvBuilder(with_pip=True).create(environment)
    python = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    dependency_args = ['-r', str(checkout / 'requirements.txt')] if name == 'muse' else ([str(next(Path(os.environ['SCENEFORGE_OFFLINE_WHEELS']).glob('gemini_webapi-*.whl')))] if name=='gemini' and os.environ.get('SCENEFORGE_OFFLINE_WHEELS') else [str(checkout)])
    subprocess.run([str(python), '-m', 'pip', 'install', *pip_arguments(), *dependency_args], check=True)
    subprocess.run([str(python), '-m', 'pip', 'check'], check=True)
    runtime = root / 'runtime'
    runtime.mkdir(exist_ok=True, mode=0o700)
    env = {**os.environ, 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'HF_HOME': os.environ.get('HF_HOME',str(runtime / 'hf-cache'))}
    if name == 'muse':
        # Import creates local metadata directories; scope them to this private runtime.
        # Do not enter the ASGI lifespan: upstream startup runs keepalive/browser work.
        keyfile = runtime / 'engine-key'
        if not keyfile.exists():
            with keyfile.open('x') as out:
                os.chmod(keyfile, 0o600)
                out.write(secrets.token_urlsafe(32))
        env.update(MUSE2API_HOME=str(runtime), MUSE2API_PROFILE_ROOT=str(runtime / 'profiles'),
                   MUSE2API_HOST='127.0.0.1', MUSE2API_KEY=keyfile.read_text(), MUSE2API_SITE=spec['site'])
        code = "from app import app; paths={r.path for r in app.routes}; assert '/v1/models' in paths and '/v1/videos' in paths; print('Muse import and routes OK; no startup/account calls')"
    elif name == 'gemini':
        # Import and SDK-contract fixture only: no init, cookie access, browser or network calls.
        code = None
    else:
        code = "from vieneu import Vieneu; import importlib.util; assert importlib.util.find_spec('torch') is None; print('VieNeu CPU SDK import OK; no model loaded or downloaded')"
    if name == 'gemini':
        subprocess.run([str(python), str(Path(__file__).with_name('check_gemini_web_sdk.py'))], cwd=runtime, env=env, check=True)
    else:
        subprocess.run([str(python), '-c', code], cwd=checkout, env=env, check=True)
    marker = {'repository': spec['url'], 'revision': revision, 'site': spec['site'],
              'dependencies_checked': True, 'import_checked': True, 'account_verified': False,
              'model_loaded': False, 'generation_verified': False, 'enabled_in_app': False}
    if name == 'gemini':
        marker.update(sdk_contract_checked=True, fixture_only=True, login_ui_implemented=True, enabled_in_app=True,
                      browser_started=False, cookies_imported=False, license='AGPL-3.0', python=str(python))
    (root / 'installation.json').write_text(json.dumps(marker, indent=2), encoding='utf-8')
    return marker


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', choices=REPOS)
    parser.add_argument('--directory', type=Path)
    parser.add_argument('--source', help='Existing reviewed Git clone for offline source installation.')
    args = parser.parse_args()
    if args.repo == 'gemini':
        print('Preparing Gemini web SDK only; no Google login, messages, browser or cookie extraction.', flush=True)
    if args.repo == 'muse':
        print('Preparing muse.ai repository only; this does not enable Meta AI in SceneForge.', flush=True)
    data = Path(os.environ.get('SCENEFORGE_LOCAL_DATA', str(Path.home() / '.sceneforge-local')))
    marker = prepare(args.repo, args.directory or data / 'engines' / REPOS[args.repo]['directory'], args.source)
    print('Repository installed and import checked:', marker['repository'])
    print('No account or generation test. No model download. App adapter is not enabled by this installer.')
    if args.repo == 'muse':
        print('This repository targets muse.ai, NOT a verified Meta AI service.')


if __name__ == '__main__':
    main()
