"""Candidate model discovery mocked; credential validation and atomic vault commit are real."""
import os,tempfile
from unittest.mock import patch
from fastapi import HTTPException
from fastapi.testclient import TestClient
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-verify-key-')
from . import server as s,ai_providers
old='OLD_PRIVATE_FIXTURE_KEY';new='NEW_PRIVATE_FIXTURE_KEY'
s.VAULT.set_secret('gemini',old);s.VAULT.set_secret('gemini-models',{'main':'old-model'});s.VAULT.set_secret('gemini-image-models',{'models':['old-image']})
async def discover(v,provider,client=None):
 key=v.secret(provider)
 if 'BAD'in key:raise HTTPException(401,'Key chưa được chấp nhận · fixture')
 if 'RACE'in key:s.VAULT.set_secret(provider,'OTHER_CLIENT_FIXTURE_KEY')
 result={'ok':True,'provider':provider,'model':'fixture-lite','note':'Key đã kiểm model, chưa kiểm quota.'};v.set_secret(provider+'-models',{'main':'fixture-lite','simple':'fixture-lite'});v.set_secret(provider+'-check',result);return result
with patch.object(ai_providers,'discover',discover),TestClient(s.app)as c:
 assert c.post('/local-api/ai/providers/verify-save',json={}).status_code==403;c.get('/');h={'X-SceneForge-Local':'1'}
 r=c.post('/local-api/ai/providers/verify-save',headers=h,json={'provider':'gemini','value':'BAD_PRIVATE_FIXTURE_KEY'});assert r.status_code==401 and s.VAULT.secret('gemini')==old and s.VAULT.secret('gemini-models')=={'main':'old-model'}and s.VAULT.secret('gemini-image-models')
 r=c.post('/local-api/ai/providers/verify-save',headers=h,json={'provider':'gemini','value':new});assert r.status_code==200 and r.json()['saved'];assert s.VAULT.secret('gemini')==new and s.VAULT.secret('gemini-models')['main']=='fixture-lite'and s.VAULT.secret('gemini-check')['ok']and s.VAULT.secret('gemini-image-models')is None
 r=c.post('/local-api/ai/providers/verify-save',headers=h,json={'provider':'gemini'});assert r.status_code==200 and s.VAULT.secret('gemini')==new
 r=c.post('/local-api/ai/providers/verify-save',headers=h,json={'provider':'gemini','value':'RACE_PRIVATE_FIXTURE_KEY'});assert r.status_code==409 and s.VAULT.secret('gemini')=='OTHER_CLIENT_FIXTURE_KEY'
 assert c.post('/local-api/ai/providers/verify-save',headers=h,json={'provider':'fake','value':new}).status_code==400
 assert new not in s.VAULT.path.read_bytes().decode('latin1');assert new not in c.get('/local-api/status').text
print('PASS same-origin guard, invalid candidate keeps old credential/models, valid key+models/check committed encrypted together, stale image cache removed, existing-key check, concurrent-change conflict; fixture discovery only, no Google/OpenAI requests.')
