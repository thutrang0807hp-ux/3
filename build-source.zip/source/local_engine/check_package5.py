"""No live services: exercise settings, secret masking, measured health and safe retries."""
import os,tempfile,asyncio,json
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sceneforge-g5-')
from fastapi.testclient import TestClient
import httpx
from unittest.mock import patch,AsyncMock
from local_engine import server
from local_engine.package5 import gemini_retry_delay,scrub
server.VAULT.set_secret('ai-routing',{'source':'gemini_api'})
headers={'X-SceneForge-Local':'1'}
with TestClient(server.app)as client:
 client.get('/')
 assert client.get('/local-api/settings').json()['autoWatermark']is True
 assert client.post('/local-api/settings',headers=headers,json={'fps':45}).status_code==400
 assert client.post('/local-api/settings',headers=headers,json={'password':'secret'}).status_code==400
 assert client.post('/local-api/settings',headers=headers,json={'fps':60,'aiTier':'free'}).json()['fps']==60
 system=client.get('/local-api/system').json();assert system['disk']['free']>0;assert {'flow2api','Muse web SDK','Gemini Chat SDK','vieneu','FFmpeg','Chat browser · Playwright/Chromium'}=={e['name']for e in system['engines']}
 key='AIzaTestNotARealKey0123456789';client.post('/local-api/settings/secret',headers=headers,json={'name':'gemini','value':key})
 server.log('Gemini','failed',{'idea':'api_key=DO_NOT_LEAK'},__import__('time').monotonic())
 redacted=client.get('/local-api/diagnostics').text;assert key not in redacted;assert 'DO_NOT_LEAK'not in redacted
 assert client.get('/local-api/ai/usage').json()['costVND']is None
 assert scrub({'cookie':'secret','nested':{'authorization':'value'},'message':'key=AIzaLongSensitiveKey0123456789'})['cookie']=='[ẨN]'
 async def check_retries(statuses,expected,exception=False):
  responses=[httpx.Response(s,json={'candidates':[{'content':{'parts':[{'text':'{}'}]}}]})for s in statuses]
  mock=AsyncMock(side_effect=httpx.ReadTimeout('uncertain')if exception else responses)
  with patch.object(httpx.AsyncClient,'post',mock),patch.object(server.asyncio,'sleep',AsyncMock()):
   try:await server.gemini({},'test')
   except Exception:pass
  assert mock.await_count==expected,(statuses,mock.await_count)
 asyncio.run(check_retries([429,200],2));asyncio.run(check_retries([429,429,429],3));asyncio.run(check_retries([403],1));asyncio.run(check_retries([],1,True))
 client.post('/local-api/settings',headers=headers,json={'aiTier':'paid'});asyncio.run(check_retries([429],1))
 assert gemini_retry_delay(httpx.Response(429,headers={'Retry-After':'120'}),0,{})is None
 assert gemini_retry_delay(httpx.Response(429,headers={'Retry-After':'nan'}),0,{})is None
print('PASS: validated persisted settings, real disk/FFmpeg health, diagnostics redacted, unknown costs retained; only confirmed free 429 retries (max 2), never 403/network/paid/long Retry-After. No live calls.')
