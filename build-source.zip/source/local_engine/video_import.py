"""Bounded public video intake. Downloads are temporary until the browser checkpoints them."""
import asyncio, hashlib, ipaddress, json, shutil, socket, time, uuid
from pathlib import Path
from urllib.parse import urlsplit, urljoin, urlunsplit
import httpx
from fastapi import HTTPException
from fastapi.responses import FileResponse

MAX_BYTES=500*1024**2
PLATFORMS=('youtube.com','youtu.be','tiktok.com','instagram.com','facebook.com','fb.watch','douyin.com')

def checked_url(value):
 if not isinstance(value,str) or len(value)>4096:raise ValueError('Link video không hợp lệ.')
 p=urlsplit(value.strip())
 if p.scheme not in ('https','http') or not p.hostname or p.username or p.password or p.port not in (None,80,443):raise ValueError('Chỉ nhận link HTTP/HTTPS công khai, không kèm tài khoản.')
 return urlunsplit((p.scheme,p.netloc,p.path,p.query,''))

async def public_url(value):
 value=checked_url(value);p=urlsplit(value)
 try:rows=await asyncio.get_running_loop().getaddrinfo(p.hostname,p.port or (443 if p.scheme=='https' else 80),type=socket.SOCK_STREAM)
 except OSError:raise ValueError('Không tìm thấy máy chủ video.') from None
 if not rows or any(not ipaddress.ip_address(row[4][0]).is_global for row in rows):raise ValueError('Không nhận link vào mạng nội bộ hoặc máy cục bộ.')
 return value

class PublicNetwork:
 """Pin every TCP connection to a checked public address, including redirects."""
 def __init__(self):
  from httpcore._backends.auto import AutoBackend
  self.backend=AutoBackend()
 async def connect_tcp(self,host,port,timeout=None,local_address=None,socket_options=None):
  name=host.decode() if isinstance(host,bytes) else host
  rows=await asyncio.get_running_loop().getaddrinfo(name,port,type=socket.SOCK_STREAM)
  if not rows or any(not ipaddress.ip_address(r[4][0]).is_global for r in rows):raise ValueError('Không tải từ mạng nội bộ.')
  return await self.backend.connect_tcp(rows[0][4][0],port,timeout,local_address,socket_options)
 async def connect_unix_socket(self,*args,**kwargs):raise ValueError('Không nhận socket nội bộ.')
 async def sleep(self,seconds):await asyncio.sleep(seconds)

def public_transport():
 import httpcore
 transport=httpx.AsyncHTTPTransport(retries=0)
 transport._pool=httpcore.AsyncConnectionPool(network_backend=PublicNetwork())
 return transport

class VideoImport:
 def __init__(self,root,budget=None):
  self.budget=budget
  self.root=Path(root)/'video-import';self.root.mkdir(parents=True,exist_ok=True)
  self.jobs={};self.tasks={};self.processes={}
  # Files from an interrupted import have no live browser consumer.
  for p in self.root.iterdir():
   if p.is_file():p.unlink(missing_ok=True)
 @property
 def reserved_bytes(self):return sum(max(0,MAX_BYTES-self.jobs[jid].get('bytes',0))for jid in self.tasks if jid in self.jobs)
 def cleanup(self):
  for jid,j in list(self.jobs.items()):
   if jid not in self.tasks and time.time()-j['at']>3600:
    self.path(jid).unlink(missing_ok=True);self.jobs.pop(jid,None)
 def path(self,jid):return self.root/(jid+'.video')
 def get(self,jid):
  self.cleanup()
  if jid not in self.jobs:raise HTTPException(404,'Lượt nhập đã hết hạn; chọn lại nguồn.')
  return self.jobs[jid]
 async def create(self,body):
  self.cleanup()
  try:url=await public_url(body.get('url'))
  except (ValueError,TypeError):raise HTTPException(400,'Cần link video HTTP/HTTPS công khai, không phải địa chỉ nội bộ.') from None
  if not shutil.which('ffprobe'):raise HTTPException(409,'Cần cài FFmpeg/ffprobe trong động cơ local trước khi tải video. Vẫn có thể chọn file trên máy.')
  key=hashlib.sha256(url.encode()).hexdigest()
  for j in self.jobs.values():
   if j['url_key']==key and j['state'] in ('queued','running','done'):return dict(j)
  if len(self.tasks)>=2:raise HTTPException(409,'Đang nhập hai video. Chờ xong rồi nhập tiếp.')
  if sum(self.path(jid).stat().st_size for jid in self.jobs if self.path(jid).exists())>MAX_BYTES*2:raise HTTPException(409,'Lưu hoặc bỏ các video đã tải trước khi nhập thêm.')
  if shutil.disk_usage(self.root).free<MAX_BYTES+256*1024**2:raise HTTPException(507,'Cần ít nhất 756 MB trống để tải video an toàn.')
  if self.budget:self.budget(MAX_BYTES)
  jid=str(uuid.uuid4());j={'id':jid,'state':'queued','phase':'Chờ đọc link','bytes':0,'at':time.time(),'url_key':key};self.jobs[jid]=j
  self.tasks[jid]=asyncio.create_task(self.run(jid,url));return dict(j)
 async def subprocess(self,jid,*args):
  proc=await asyncio.create_subprocess_exec(*args,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL);self.processes[jid]=proc
  try:
   stdout,_=await asyncio.wait_for(proc.communicate(),75)
   if proc.returncode or len(stdout)>8*1024**2:raise ValueError('Không đọc được video công khai. Trang có thể yêu cầu đăng nhập; hãy tải file rồi nhập vào app.')
   return stdout
  finally:
   if proc.returncode is None:
    proc.kill();await proc.wait()
   self.processes.pop(jid,None)
 async def resolve(self,jid,url):
  p=urlsplit(url);host=p.hostname.lower()
  if p.path.lower().endswith(('.mp4','.webm','.mov','.m4v')):return url,{},{}
  if not any(host==h or host.endswith('.'+h) for h in PLATFORMS):raise ValueError('Link này chưa hỗ trợ. Dùng link file MP4/WebM hoặc tải file rồi nhập.')
  import sys,importlib.util
  if not importlib.util.find_spec('yt_dlp'):raise ValueError('Thiếu yt-dlp. Chạy lại bước cài động cơ local; vẫn có thể nhập file.')
  raw=await self.subprocess(jid,sys.executable,'-m','yt_dlp','--ignore-config','--no-playlist','--skip-download','--dump-single-json','--no-cache-dir','--retries','0','--extractor-retries','0','--socket-timeout','15',url)
  info=json.loads(raw)
  if info.get('_type') in ('playlist','multi_video') or float(info.get('duration') or 0)>600:raise ValueError('Chọn một video tối đa 10 phút, không phải danh sách.')
  formats=info.get('formats') or [info]
  formats=[f for f in formats if f.get('url') and f.get('protocol','https') in ('http','https') and f.get('vcodec')!='none' and f.get('acodec')!='none' and (f.get('height') or 0)<=1080 and (f.get('filesize') or 0)<=MAX_BYTES]
  if not formats:raise ValueError('Nguồn chỉ có luồng phân mảnh hoặc âm thanh tách riêng. Hãy tải video có tiếng rồi nhập file; app chưa tự ghép các luồng này.')
  f=max(formats,key=lambda x:(x.get('height') or 0,x.get('tbr') or 0))
  # Do not forward cookies/authorization supplied by an extractor.
  headers={k:v for k,v in (f.get('http_headers') or info.get('http_headers') or {}).items() if k.lower() in ('user-agent','referer')}
  return await public_url(f['url']),headers,{'title':str(info.get('title') or 'Video')[:160],'selected_height':f.get('height')}
 async def download(self,jid,url,headers):
  job=self.jobs[jid];digest=hashlib.sha256()
  async with httpx.AsyncClient(follow_redirects=False,trust_env=False,transport=public_transport(),timeout=httpx.Timeout(30,read=45)) as client:
   for _ in range(6):
    url=await public_url(url)
    async with client.stream('GET',url,headers=headers) as response:
     if response.status_code in (301,302,303,307,308):
      url=urljoin(url,response.headers.get('location',''));continue
     if response.status_code!=200:raise ValueError('Máy chủ không cho tải video. Hãy nhập file đã tải trên máy.')
     try:length=int(response.headers.get('content-length','0'))
     except ValueError:length=0
     if length>MAX_BYTES:raise ValueError('Video vượt 500 MB.')
     with self.path(jid).open('wb') as out:
      async for chunk in response.aiter_bytes(256*1024):
       if job['bytes']+len(chunk)>MAX_BYTES:raise ValueError('Video vượt 500 MB.')
       if self.budget and job['bytes']//(16*1024**2)!=(job['bytes']+len(chunk))//(16*1024**2):self.budget(0)
       out.write(chunk);digest.update(chunk);job.update(bytes=job['bytes']+len(chunk),phase='Đang tải video',at=time.time())
     return digest.hexdigest()
   raise ValueError('Link chuyển hướng quá nhiều lần.')
 async def run(self,jid,url):
  j=self.jobs[jid];j.update(state='running',phase='Đang đọc nguồn công khai')
  try:
   async with asyncio.timeout(600):
    url,headers,meta=await self.resolve(jid,url);digest=await self.download(jid,url,headers)
    with self.path(jid).open('rb')as source:header=source.read(32)
    if not(header[4:8]==b'ftyp' or header[:4]==b'\x1aE\xdf\xa3'):raise ValueError('Chỉ nhận tệp MP4/MOV/WebM thật, không phải trang web hoặc danh sách phát.')
    raw=await self.subprocess(jid,'ffprobe','-protocol_whitelist','file,pipe','-v','error','-show_format','-show_streams','-of','json',str(self.path(jid)))
    info=json.loads(raw);video=next((s for s in info.get('streams',[]) if s.get('codec_type')=='video'),None);seconds=float(info.get('format',{}).get('duration') or 0)
    if not video or not 0<seconds<=600:raise ValueError('Nguồn không phải video hợp lệ từ 0 đến 10 phút.')
    ext='webm' if 'webm' in info.get('format',{}).get('format_name','') else 'mp4'
    j.update(state='done',phase='Đã tải · chờ lưu vào dự án',sha256=digest,duration=seconds,width=video.get('width'),height=video.get('height'),name='video-'+digest[:12]+'.'+ext,mime='video/webm' if ext=='webm' else 'video/mp4',**meta)
  except asyncio.CancelledError:j.update(state='cancelled',phase='Đã bỏ lượt tải');self.path(jid).unlink(missing_ok=True)
  except Exception as e:
   j.update(state='error',phase='Chưa nhập được video',error=str(e.detail) if isinstance(e,HTTPException) else str(e) if isinstance(e,ValueError) else 'Tải video bị ngắt hoặc quá thời gian. Có thể chọn file trên máy.');self.path(jid).unlink(missing_ok=True)
  finally:j['at']=time.time();self.tasks.pop(jid,None)
 async def release(self,jid):
  self.get(jid);task=self.tasks.get(jid)
  if task:
   task.cancel()
   try:await task
   except asyncio.CancelledError:pass
  self.tasks.pop(jid,None);self.path(jid).unlink(missing_ok=True);self.jobs.pop(jid,None)
  return {'released':True}
 async def close(self):
  for jid in list(self.tasks):await self.release(jid)

def install_video_import(app,root,budget=None):
 service=VideoImport(root,budget)
 @app.post('/local-api/video-import/jobs')
 async def create(body:dict):return await service.create(body)
 @app.get('/local-api/video-import/jobs')
 async def listing():
  service.cleanup();return {'jobs':[dict(j) for j in service.jobs.values()]}
 @app.get('/local-api/video-import/jobs/{jid}')
 async def status(jid:str):return dict(service.get(jid))
 @app.get('/local-api/video-import/jobs/{jid}/file')
 async def file(jid:str):
  j=service.get(jid)
  if j['state']!='done' or not service.path(jid).is_file():raise HTTPException(409,'Video chưa tải xong.')
  return FileResponse(service.path(jid),media_type=j['mime'],filename=j['name'])
 @app.post('/local-api/video-import/jobs/{jid}/release')
 async def release(jid:str,body:dict):return await service.release(jid)
 return service
