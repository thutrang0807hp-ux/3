"""Actual unpacked extension -> local app -> fixture SDK -> encrypted vault.

No Google login/generation or real accounts. The browser cookie permission and
extension-origin transport are real, not a mocked chrome.cookies API.
"""
import asyncio
import json
import os
from pathlib import Path
import socket
import tempfile
from threading import Thread
import time
import urllib.request
import zipfile

import httpx
import uvicorn
from playwright.sync_api import sync_playwright


def main():
    root=Path(__file__).resolve().parents[1]
    with tempfile.TemporaryDirectory(prefix='sf-extension-test-') as data:
        os.environ['SCENEFORGE_LOCAL_DATA']=data
        from . import server
        calls=[];flow=[]
        secret='fixture-session-never-log-8d80be'
        async def runner(body):
            assert body['operation']=='check','Generation forbidden in connection test'
            calls.append(body['operation'])
            assert body['session']['cookies']['__Secure-1PSID']==secret
            return {'ok':True,'session':body['session'],'models':[{'id':'fixture','name':'Fixture only'}]}
        async def import_flow(cookies):
            flow.append(cookies)
            return {'accounts':[]}
        server.GEMINI_CHAT.runner=runner
        server.FLOW_ACCOUNTS.import_session=import_flow
        bridge=server.BROWSER_BRIDGE
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        host=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'))
        thread=Thread(target=host.run,daemon=True);thread.start()
        base='http://127.0.0.1:'+str(port)
        try:
            for _ in range(100):
                try:urllib.request.urlopen(base+'/local-api/health',timeout=.3);break
                except OSError:time.sleep(.1)
            with httpx.Client(base_url=base) as client:
                client.get('/')
                headers={'X-SceneForge-Local':'1'}
                assert client.get('/local-api/browser-bridge/setup').status_code==200
                issued=client.post('/local-api/browser-bridge/pairs',headers=headers,json={'service':'gemini_chat','name':'Browser fixture'}).json()
                code=issued['code']
                wire={'Origin':bridge.origin,'X-SceneForge-Bridge':'1'}
                preflight={'Origin':bridge.origin,'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'content-type,x-sceneforge-bridge'}
                assert client.options('/local-api/browser-bridge/claim',headers=preflight).status_code==200
                # Web pages and extension attempts to bypass the app's other APIs stay blocked.
                assert client.post('/local-api/browser-bridge/claim',headers={**wire,'Origin':'https://evil.example'},json={'code':code}).status_code==403
                assert client.post('/local-api/browser-bridge/pairs',headers={**wire,**headers},json={'service':'flow','name':'x'}).status_code==403
                assert client.post('/local-api/browser-bridge/claim',headers=wire,json={'code':'bad'}).status_code==400
                assert client.get('/local-api/browser-bridge/pairs/'+issued['id'],headers={'Origin':bridge.origin}).status_code==403
                with sync_playwright() as pw:
                    context=pw.chromium.launch_persistent_context(str(Path(data)/'browser'),executable_path=os.environ.get('SCENEFORGE_BRIDGE_TEST_BROWSER')or pw.chromium.executable_path,headless=True,args=['--no-sandbox','--disable-extensions-except='+str(bridge.root),'--load-extension='+str(bridge.root)],ignore_default_args=['--disable-extensions'])
                    context.route('https://**/*',lambda route:route.abort())
                    context.add_cookies([{'name':'__Secure-1PSID','value':secret,'domain':'.google.com','path':'/','secure':True,'httpOnly':True},{'name':'unrelated','value':'not-for-app','domain':'.example.org','path':'/'}])
                    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                    # Real popup context: cookie access and Origin are supplied by Chromium.
                    page.goto(bridge.origin+'/popup.html')
                    page.locator('#code').fill(code)
                    page.locator('summary').click();page.locator('#port').fill(str(port))
                    page.locator('#submit').click()
                    page.wait_for_function("document.querySelector('#status').dataset.state==='done'||document.querySelector('#status').dataset.state==='error'",timeout=30000)
                    assert page.locator('#status').get_attribute('data-state')=='done',page.locator('#status').inner_text()
                    for _ in range(100):
                        status=client.get('/local-api/browser-bridge/pairs/'+issued['id']).json()
                        if status['state'] in {'done','failed'}:break
                        time.sleep(.1)
                    assert status['state']=='done',status
                    assert calls==['check'],calls
                    assert secret not in json.dumps(status)
                    assert client.post('/local-api/browser-bridge/claim',headers=wire,json={'code':code}).status_code==409
                    assert client.post('/local-api/browser-bridge/complete',headers=wire,json={'code':code,'submission':'replay','cookies':[]}).status_code==409
                    assert secret not in client.get('/local-api/status').text
                    assert secret.encode()not in (Path(data)/'vault.sqlite').read_bytes()
                    assert secret not in (Path(data)/'logs/runtime.log').read_text()
                    # Full application UI issues and revokes a second code without a browser-login window.
                    app=context.new_page();app.on('pageerror',lambda e:errors.append(str(e)));app.goto(base)
                    app.wait_for_function('appBootReady&&SceneForgeStorage.state.active')
                    app.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();await accountScreen('gemini_chat')}")
                    app.locator('#connectAccount').click();app.locator('#bridgeCreate').click()
                    app.wait_for_function("document.querySelector('#bridgeCode')?.value.length===8")
                    code2=app.locator('#bridgeCode').input_value()
                    assert code2!=code
                    pair2=next(p for p in bridge.pairs.values()if p['code']==code2)
                    app.locator('#bridgeBack').click()
                    for _ in range(50):
                        if pair2['state']=='cancelled':break
                        time.sleep(.05)
                    assert pair2['state']=='cancelled',pair2
                    # Same extension can connect Flow only under a Flow-issued pairing code.
                    flow_pair=client.post('/local-api/browser-bridge/pairs',headers=headers,json={'service':'flow','name':'Flow fixture'}).json()
                    page.reload();page.locator('#code').fill(flow_pair['code']);page.locator('summary').click();page.locator('#port').fill(str(port));page.locator('#submit').click()
                    page.wait_for_function("document.querySelector('#status').dataset.state==='done'||document.querySelector('#status').dataset.state==='error'")
                    assert page.locator('#status').get_attribute('data-state')=='done',page.locator('#status').inner_text()
                    for _ in range(50):
                        if flow:break
                        time.sleep(.05)
                    assert flow and all(c['domain'].lstrip('.') in {'google.com','labs.google','flow.google.com'}for c in flow[0])
                    assert not errors,errors
                    context.close()
                # Expiration, mixed-domain input and duplicate submissions fail before any SDK call.
                p=client.post('/local-api/browser-bridge/pairs',headers=headers,json={'service':'gemini_chat','name':'Expired'}).json();bridge.pairs[p['id']]['expires_at']=time.time()-1
                assert client.post('/local-api/browser-bridge/claim',headers=wire,json={'code':p['code']}).status_code==410
                p=client.post('/local-api/browser-bridge/pairs',headers=headers,json={'service':'gemini_chat','name':'Invalid scope'}).json();claim=client.post('/local-api/browser-bridge/claim',headers=wire,json={'code':p['code']}).json()
                bad=client.post('/local-api/browser-bridge/complete',headers=wire,json={'code':p['code'],'submission':claim['submission'],'cookies':[{'name':'x','value':secret,'domain':'.evil.example'}]})
                assert bad.status_code==400
                assert calls==['check']
                assert client.post('/local-api/browser-bridge/complete',headers=wire,content=b'x'*131073).status_code==413
                print('PASS real unpacked Chromium extension cookie permission, exact extension-origin loopback transport, actual app pairing/cancel UI, encrypted Gemini session, Flow scoping, one-use/expiry/replay/origin/body-size guards. Synthetic account; one SDK check, zero generation.')
        finally:
            host.should_exit=True;thread.join(timeout=15)
            for handler in list(server.RUNTIME_LOG.handlers):handler.close();server.RUNTIME_LOG.removeHandler(handler)


if __name__=='__main__':main()
