"""Three same-account browser contexts; provider pages intercepted locally, no live service."""
import asyncio,base64,io,json,tempfile,uuid
from pathlib import Path
from PIL import Image
from .web_images import WebImages,SITES
from .vault import Vault
from .request_ledger import RequestLedger
async def main():
 with tempfile.TemporaryDirectory(prefix='sf-image-browser-')as tmp:
  root=Path(tmp);vault=Vault(root);ledger=RequestLedger(root);urls=[]
  for i in range(3):
   image=io.BytesIO();Image.new('RGB',(128,128),(i*50,20,30)).save(image,format='PNG');urls.append('data:image/png;base64,'+base64.b64encode(image.getvalue()).decode())
  sites={s:{**v,'editor':'#prompt','send':'#send','images':'img.generated'}for s,v in SITES.items()};service=WebImages(vault,root,ledger,sites=sites);source='grok';aid='A';state={'cookies':[{'name':'session_token','value':'FIXTURE_PRIVATE','domain':'.grok.com','path':'/','expires':-1,'httpOnly':False,'secure':True,'sameSite':'Lax'}],'origins':[]};vault.set_secret('web-image-session:A',state);vault.put('accounts',{'id':aid,'service':source,'name':'Single fixture account','active':True,'enabled':True,'session_verified':True,'state':'ready'});service.image_slots[source].configure({'per_account':3});clicks=[];opened=peak=0
  async def browser(headless=False):
   nonlocal opened,peak
   from playwright.async_api import async_playwright
   pw=await async_playwright().start();b=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);opened+=1;peak=max(peak,opened);original=b.new_context;close=b.close
   async def done(*a,**kw):
    nonlocal opened
    try:return await close(*a,**kw)
    finally:opened-=1
   b.close=done
   async def context(**kw):
    c=await original(**kw)
    async def route(r):
     if r.request.resource_type!='document':return await r.abort()
     await r.fulfill(content_type='text/html',body='<textarea id="prompt"></textarea><button id="send">Send</button><script>const urls='+json.dumps(urls)+';document.querySelector("#send").onclick=()=>{const p=document.querySelector("#prompt").value;const n=Number(p.match(/image ([0-9]+)/)[1]);const i=new Image();i.className="generated";i.src=urls[n];document.body.append(i);fetch("/fixture-sent",{method:"POST",body:p});};</script>')
    async def sent(r):clicks.append(r.request.post_data);await r.fulfill(body='ok')
    await c.route('**/*',route);await c.route('**/fixture-sent',sent);return c
   b.new_context=context;return pw,b
  service.new_browser=browser;ids=[]
  for i in range(3):
   rid='webimage-'+str(uuid.uuid4());ids.append(rid);await service.submit({'request_id':rid,'source':source,'kind':'image','prompt':'image '+str(i),'aspect':'1:1','references':[],'confirm_send':True,'selection_token':service.status(source)['selection']['token']})
  await asyncio.gather(*list(service.tasks.values()));assert peak==3 and len(clicks)==3,(peak,clicks)
  for i,rid in enumerate(ids):
   assert service.lookup(rid)['state']=='done',service.lookup(rid);assert Image.open(service.file(rid).path).getpixel((0,0))[0]==i*50
  assert vault.secret('web-image-session:A')==state;await service.close();print('PASS three actual Chromium workers overlap on one fixture account, isolated prompt/result PNG per request, cookie unchanged, exactly one send each; all provider pages intercepted, no online generation.')
if __name__=='__main__':asyncio.run(main())
