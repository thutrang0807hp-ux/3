// Shared request identity, negative receipts and tolerant JSON. No dispatch here.
(function(){
function jobWireId(job){const id=job.id||job.request_id;return job.source==='gemini_chat'&&!id?.startsWith('gchat-')?'gchat-'+id:id;}
function jobPostFailure(job,error){const d=error.detail,id=jobWireId(job);job.error=error.message;job.updatedAt=Date.now();if(d?.submitted===false&&d.request_id===id&&typeof d.store_id==='string'){job.state='not_submitted';job.store_id=d.store_id;job.negativeReceipt=structuredClone(d);}else job.state=d?.code==='INVALID_JSON'?'invalid':'unknown';}
function jobReadRecord(job,record){if(job.store_id&&record.store_id&&job.store_id!==record.store_id){job.state='unknown';throw Error('Kho dữ liệu động cơ đã đổi; chưa thể đối soát lượt cũ.');}if(record.store_id)job.store_id=record.store_id;job.state=record.state;job.updatedAt=Date.now();if(record.state==='not_submitted'&&record.submitted===false)job.negativeReceipt=structuredClone(record);}
function jobReadError(job,error){job.error=error.message;job.updatedAt=Date.now();if(error.status===404){job.state='missing';job.error='Không tìm thấy ở động cơ hiện tại. Kiểm tra đúng thư mục dữ liệu/lịch sử dịch vụ trước khi bỏ lượt; chưa kết luận là chưa gửi.';}}
function workflowJsonObject(text){if(typeof text!=='string'||text.length>500000)throw Error('JSON quá lớn hoặc không hợp lệ.');try{const data=JSON.parse(text);if(data&&typeof data==='object'&&!Array.isArray(data))return data;}catch{}const found=[];let start=-1,depth=0,quoted=false,escape=false;for(let i=0;i<text.length;i++){const c=text[i];if(start<0){if(c==='{'){start=i;depth=1;quoted=false;escape=false;}continue;}if(quoted){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')quoted=false;}else if(c==='"')quoted=true;else if(c==='{')depth++;else if(c==='}'&&!--depth){try{const value=JSON.parse(text.slice(start,i+1));if(value&&typeof value==='object'&&!Array.isArray(value))found.push(value);}catch{}start=-1;if(found.length>1)throw Error('Có nhiều khối JSON; chọn/sửa rõ kết quả trước khi áp dụng.');}}if(found.length!==1||start>=0)throw Error('JSON thiếu hoặc chưa hoàn chỉnh. Có thể sửa JSON đã nhận, không tự gửi lại.');return found[0];}
const pendingStates=['prepared','preparing','submitted','queued','running','downloading','unknown','missing','invalid','done'];
async function persistIntent(job,save,store){
 if(job.state!=='prepared')throw Error('Chỉ ghi ý định trước khi gửi lượt mới.');
 try{await save();if(!store?.managed)return;
  for(let attempt=0;attempt<6;attempt++){
   if(!store.state.active)throw Error('Kho máy chưa sẵn sàng; chưa gửi AI.');
   try{await store.checkpoint();if(!store.state.active)throw Error('Kho máy chưa xác nhận lưu.');if(!store.state.dirty)return;}
   catch(error){if(!error.message.includes('Dữ liệu đang thay đổi')||attempt===5)throw error;}
   if(attempt<5)await new Promise(resolve=>setTimeout(resolve,80));
  }throw Error('Dữ liệu chưa ổn định để lưu ý định; chưa gửi AI.');
 }catch(error){job.state='not_submitted';job.error=error.message;try{await save();}catch{}throw error;}
}
function chooseMusic(state,rows,mode,selected,key){
 if(mode==='off')return null;
 let song;if(mode==='random'){
  song=state.musicChoice?rows.find(r=>r[key]===state.musicChoice):rows[Math.floor(Math.random()*rows.length)];
  if(state.musicChoice&&!song)throw Error('Bài nhạc đã chốt không còn tệp. Chọn lại chế độ nhạc hoặc chọn một bài khác.');
 }else song=rows.find(r=>r[key]===selected);
 if(!song)throw Error('Chọn bài nhạc còn tệp hoặc tắt nhạc.');
 if(mode==='random')state.musicChoice=song[key];return song;
}
window.SFProviderReceipts={jobWireId,jobPostFailure,jobReadRecord,jobReadError,workflowJsonObject,pendingStates,persistIntent,chooseMusic};
})();
