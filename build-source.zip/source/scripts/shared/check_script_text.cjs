const fs=require('fs'),vm=require('vm'),assert=require('assert');const root=__dirname+'/../..';const {SFScript,SFRecipes}=vm.runInNewContext(fs.readFileSync(root+'/scripts/shared/recipes.js','utf8')+'\n'+fs.readFileSync(root+'/scripts/shared/script-text.js','utf8')+'\n({SFScript,SFRecipes})',{crypto:require('crypto').webcrypto});
for(const body of ['  [Cảnh 1 – cận mặt]\r\nLời thứ nhất 🙂.\r\n\r\n[Cảnh 2]\r\nLời thứ hai!  ','Một câu. Câu thứ hai? Cuối cùng!','\n\n[Cảnh 1]\nDùng [sản phẩm] theo hướng dẫn.\n[Cảnh 2]\nĐọc tiếp.\n\n']){
 for(const ranges of [SFScript.units(body),SFScript.blocks(body)])assert.equal(ranges.map(p=>body.slice(p.start,p.end)).join(''),body);
 const script=SFRecipes.validate({id:'s',kind:'script',name:'Tên',body,beats:[]});assert.equal(script.body,body);assert.equal(script.beats.length,0);
 const production=SFScript.production(script);assert.equal(production.sourceBody,body);assert(!production.scriptBody.some(p=>p.text.includes('[Cảnh')));assert(SFRecipes.strip(production).body===body);
}
assert.equal(SFScript.spoken('[Cảnh 1]\nDùng [sản phẩm].'),'Dùng [sản phẩm].');assert(!SFScript.matches('person','son'));assert(SFScript.matches('SON đỏ','son'));assert.equal(SFScript.title('[Cảnh 1]\n\nLời thật'), 'Lời thật');
const huge='Lời dài '.repeat(5000);assert.equal(SFRecipes.validate({kind:'script',name:'Dài',body:huge,beats:[]}).body,huge);assert.throws(()=>SFScript.production({kind:'script',name:'Dài',body:huge,beats:[]}));
assert.throws(()=>SFScript.validParts('abcdef',[{start:0,end:3,role:'neutral',type:'wide'}]));assert.throws(()=>SFScript.validParts('abcdef',[{start:1,end:6,role:'neutral',type:'wide'}]));
console.log('PASS script text: exact CRLF/emoji/whitespace coverage, no required beats, annotation/speech separation, placeholders retained, product word boundary, full source snapshots, long documents saved without silent truncation, oversized production and incomplete ranges blocked.');
