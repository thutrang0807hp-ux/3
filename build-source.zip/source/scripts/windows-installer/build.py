"""Cross-build the Windows x64 installer from verified CPython and Windows wheels.
Usage: python build.py --python-tar ... --wheels ... --zig-python ...
No application accounts, user data, model weights or development venv are packaged.
"""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import argparse,base64,gzip,email,hashlib,json,os,shutil,struct,subprocess,tarfile,tempfile
from packaging.requirements import Requirement
from packaging.markers import default_environment
from packaging.utils import canonicalize_name

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
VERSION='2026.10.28.2'
PYTHON_SHA='1f2ab53880fc67ea323398c6388e05af28addc99a8e389209f08a51fdff4b149'

def digest(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        while block:=f.read(1024*1024):h.update(block)
    return h.hexdigest()

def pe(path):
    data=path.read_bytes();assert data[:2]==b'MZ',path
    offset=struct.unpack_from('<I',data,0x3c)[0]
    assert data[offset:offset+4]==b'PE\0\0'and struct.unpack_from('<H',data,offset+4)[0]==0x8664,path

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--python-tar',type=Path,required=True);ap.add_argument('--wheels',type=Path,required=True);ap.add_argument('--zig-python',required=True);ap.add_argument('--resources',type=Path,required=True);ap.add_argument('--output',type=Path,default=ROOT/'artifacts/windows');args=ap.parse_args()
    assert digest(args.python_tar)==PYTHON_SHA,'CPython distribution hash mismatch'
    wheels=sorted(args.wheels.glob('*.whl'));assert wheels
    # pip cross-download evaluates some markers on the build host. Audit again as Windows.
    env={**default_environment(),'sys_platform':'win32','os_name':'nt','platform_machine':'AMD64','platform_system':'Windows','python_version':'3.12','python_full_version':'3.12.16','extra':''}
    distributions={};metadata=[]
    for wheel in wheels:
        assert wheel.name.endswith(('win_amd64.whl','none-any.whl')),wheel
        with ZipFile(wheel)as z:info=email.message_from_bytes(z.read(next(n for n in z.namelist()if n.endswith('.dist-info/METADATA'))))
        distributions[canonicalize_name(info['Name'])]=info['Version'];metadata.append(info)
    for info in metadata:
        for text in info.get_all('Requires-Dist',[]):
            req=Requirement(text)
            if req.marker and not req.marker.evaluate(env):continue
            version=distributions.get(canonicalize_name(req.name));assert version and version in req.specifier,(info['Name'],text,version)
    args.output.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='sf-windows-build-')as temp:
        temp=Path(temp);stage=temp/'stage';stage.mkdir();runtime=stage/'runtime';runtime.mkdir()
        with tarfile.open(args.python_tar)as t:
            for item in t.getmembers():
                if not item.name.startswith('python/'):continue
                relative=Path(item.name).relative_to('python')
                target=(runtime/relative).resolve();assert target.is_relative_to(runtime.resolve())
                if item.isdir():target.mkdir(parents=True,exist_ok=True)
                elif item.isfile():target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(item).read())
                else:raise ValueError('Unexpected runtime archive entry: '+item.name)
        site=runtime/'Lib/site-packages';site.mkdir(parents=True,exist_ok=True)
        for wheel in wheels:
            with ZipFile(wheel)as z:
                for entry in z.infolist():
                    if entry.is_dir():continue
                    relative=Path(entry.filename)
                    # Wheel .data files must be placed at their installation scheme locations.
                    data_index=next((i for i,p in enumerate(relative.parts)if p.endswith('.data')),None)
                    base=site
                    if data_index is not None:
                        scheme=relative.parts[data_index+1];relative=Path(*relative.parts[data_index+2:])
                        base={'purelib':site,'platlib':site,'scripts':runtime/'Scripts','data':runtime,'headers':runtime/'Include'}.get(scheme)
                        if base is None:raise ValueError('Unsupported wheel scheme '+scheme)
                    target=(base/relative).resolve();assert target.is_relative_to(runtime.resolve())
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(entry))
        app=stage/'app';app.mkdir()
        shutil.copytree(ROOT/'local_engine',app/'local_engine',ignore=shutil.ignore_patterns('__pycache__','*.pyc','check_*.py'))
        shutil.copytree(ROOT/'dist/web-demo',app/'dist/web-demo',ignore=shutil.ignore_patterns('downloads'))
        for name in ['windows_bootstrap.py','paths.py','provision.py','uninstall.ps1','components.ps1']:
            shutil.copy2(HERE/name,app/name)
        shutil.copytree(args.resources,stage/'resources',ignore=shutil.ignore_patterns('tools','.cache'))
        shutil.copytree(args.resources/'tools',stage/'tools')
        for name in ['prompt-pipeline.md','prompt-repository-review.md']:
            (app/'docs').mkdir(exist_ok=True);shutil.copy2(ROOT/'docs'/name,app/'docs'/name)
        inventory={'version':VERSION,'python_source':'https://github.com/astral-sh/python-build-standalone/releases/tag/20261026','python_sha256':PYTHON_SHA,'wheels':[{'file':p.name,'sha256':digest(p)}for p in wheels],'distributions':distributions,'models_included':['Whisper base'],'ffmpeg_included':True,'windows_runtime_test':'see separate Windows check report; cross-build is not runtime verification'}
        (stage/'BUNDLED-COMPONENTS.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
        (stage/'DOC-TRUOC.txt').write_text('SceneForge Windows x64\nMo SceneForge.exe. Giu cua so dong lenh khi dung; dong de dung app.\nPython va thu vien co ban da kem san. Khong can cai Python rieng.\nTai khoan AI, model Whisper/VieNeu, FFmpeg/ffprobe va engine Flow khong kem san.\nStart Menu > SceneForge - Cai Whisper: tai thu vien CPU va model (~150 MB), can mang.\nDu lieu cua ban o thu muc nguoi dung .sceneforge-local; cai lai khong xoa du lieu.\nKho kich ban v5 chua duoc trien khai.\n',encoding='utf-8')
        compiler=[args.zig_python,'-m','ziglang','cc','-target','x86_64-windows-gnu','-O2','-municode']
        buildenv={**os.environ,'ZIG_GLOBAL_CACHE_DIR':str(ROOT.parent/'windows-build-cache'),'ZIG_LOCAL_CACHE_DIR':str(temp/'zig-cache')}
        subprocess.run([*compiler,str(HERE/'launcher.c'),'-o',str(stage/'SceneForge.exe')],check=True,env=buildenv)
        pe(stage/'SceneForge.exe');pe(runtime/'python.exe')
        for kind,script_name in [('Uninstall','uninstall.ps1'),('Tools','components.ps1')]:
            task_script="& ([scriptblock]::Create([IO.File]::ReadAllText((Join-Path $env:SF_TASK_ROOT 'app/"+script_name+"'))))"
            task_encoded=base64.b64encode(task_script.encode('utf-16-le')).decode()
            (temp/'task_config.h').write_text('#define TASK_COMMAND L"'+task_encoded+'"\n')
            subprocess.run([*compiler,'-I',str(temp),str(HERE/'tasks.c'),'-o',str(stage/('SceneForge-'+kind+'.exe'))],check=True,env=buildenv)
        # Preserve the exact PowerShell sources with the deliverable for review/rebuild.
        shutil.copytree(HERE,stage/'installer-source',ignore=shutil.ignore_patterns('__pycache__'))
        payload=args.output/'SceneForge-Windows-payload.zip'
        with ZipFile(payload,'w',ZIP_DEFLATED,compresslevel=9)as z:
            for p in sorted(stage.rglob('*')):
                if p.is_file():z.write(p,p.relative_to(stage).as_posix())
        with ZipFile(payload)as z:assert z.testzip()is None
        script=(HERE/'install.ps1').read_text().replace('@VERSION@',VERSION).replace('@HASH@',digest(payload)).replace('@SIZE@',str(payload.stat().st_size)).replace('@EXPANDED@',str(sum(p.stat().st_size for p in stage.rglob('*')if p.is_file())))
        compressed=base64.b64encode(gzip.compress(script.encode('utf-8'))).decode()
        bootstrap="$m=New-Object IO.MemoryStream(,[Convert]::FromBase64String('"+compressed+"'));$g=New-Object IO.Compression.GZipStream($m,[IO.Compression.CompressionMode]::Decompress);$r=New-Object IO.StreamReader($g,[Text.Encoding]::UTF8);& ([scriptblock]::Create($r.ReadToEnd()))"
        encoded=base64.b64encode(bootstrap.encode('utf-16-le')).decode();assert len(encoded)<28000
        (temp/'installer_config.h').write_text('#define INSTALL_COMMAND L"'+encoded+'"\n')
        setup=temp/'setup.exe';subprocess.run([*compiler,'-I',str(temp),str(HERE/'setup.c'),'-o',str(setup)],check=True,env=buildenv);pe(setup)
        installer=args.output/'SceneForge-Setup-Windows-x64-v2.exe'
        with installer.open('wb')as out:
            out.write(setup.read_bytes())
            with payload.open('rb')as f:shutil.copyfileobj(f,out)
        pe(installer)
        report={'version':VERSION,'file':installer.name,'bytes':installer.stat().st_size,'sha256':digest(installer),'payload_bytes':payload.stat().st_size,'payload_sha256':digest(payload),'native_stub_bytes':setup.stat().st_size,'python_sha256':PYTHON_SHA,'windows_dependencies_audited':distributions,'cross_build_verified':True,'windows_runtime_verified':False}
        (args.output/'build-report.json').write_text(json.dumps(report,indent=2));installer.with_suffix('.exe.sha256').write_text(report['sha256']+'  '+installer.name+'\n')
        # Full offline dependencies/models are published as a Release asset, not a Git blob.
        print(json.dumps(report,indent=2))

if __name__=='__main__':main()
