﻿param([Parameter(Mandatory=$true)][string]$InstallerPath,[Parameter(Mandatory=$true)][string]$Version)
$ErrorActionPreference='Stop'
$testRoot=Join-Path $env:RUNNER_TEMP ('SceneForge full '+[char]0x1EC7)
[void][IO.Directory]::CreateDirectory($testRoot)
$drive='S:';if(Test-Path 'S:\'){$drive='T:'};subst $drive $testRoot
$prefix=$drive+'\'
$installRoot=Join-Path $prefix 'Ứng dụng SceneForge';$dataRoot=Join-Path $prefix 'Dự án của tôi';$cacheRoot=Join-Path $prefix 'Cache riêng'
$env:SCENEFORGE_NO_BROWSER='1';$env:SCENEFORGE_INSTALL_TEST='1'
$old=Join-Path $env:LOCALAPPDATA ('sceneforge-old-check-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($old);[IO.File]::WriteAllText((Join-Path $old 'keep.txt'),'OLD DATA MUST STAY');$env:SCENEFORGE_LOCAL_DATA=$old
$report=@{passed=$false;installer_sha256=(Get-FileHash -LiteralPath $InstallerPath -Algorithm SHA256).Hash.ToLower();version=$Version;checks=@();old_data=$old;install_root=$installRoot;data_root=$dataRoot;cache_root=$cacheRoot}
$installer=$null;$launcher=$null
function Native($path,$wait=900000,$directory=$testRoot){$p=Start-Process -FilePath $path -WorkingDirectory $directory -PassThru -RedirectStandardOutput (Join-Path $testRoot ('native-'+[guid]::NewGuid().ToString('N')+'.log'));$null=$p.Handle;if(!$p.WaitForExit($wait)){taskkill /PID $p.Id /T /F|Out-Null;throw 'Native process timeout'};if($null -ne $p.ExitCode -and $p.ExitCode -ne 0){throw "Native process exit $($p.ExitCode)"};return $p}
try {
 # Cancel before any files are written.
 $plan=Join-Path $testRoot 'cancel.json';@{install_root=(Join-Path $prefix 'Cancel');data_directory=(Join-Path $prefix 'CancelData');cache_directory=(Join-Path $prefix 'CancelCache');cancel=$true}|ConvertTo-Json|Set-Content $plan -Encoding UTF8;$env:SCENEFORGE_INSTALL_PLAN=$plan
 $null=Native $InstallerPath;if(Test-Path (Join-Path $prefix 'Cancel')){throw 'Cancel created installation files'};$report.checks+='cancel closes before extraction'
 # Actual folder chooser form is shown; use UI Automation to enter a different drive.
 Remove-Item Env:\SCENEFORGE_INSTALL_PLAN
 Add-Type -AssemblyName UIAutomationClient;Add-Type -AssemblyName UIAutomationTypes
 Add-Type 'using System;using System.Runtime.InteropServices;public class ClickButton{[DllImport("user32.dll")]public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);}'
 $installer=Start-Process -FilePath $InstallerPath -PassThru;$null=$installer.Handle;$dialog=$null
 $edits=$null
 for($i=0;$i -lt 60;$i++){
  Start-Sleep -Milliseconds 500
  $dialog=[Windows.Automation.AutomationElement]::RootElement.FindFirst([Windows.Automation.TreeScope]::Children,(New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::NameProperty,'Cài đặt SceneForge')))
  if($dialog){$edits=$dialog.FindAll([Windows.Automation.TreeScope]::Descendants,(New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::ControlTypeProperty,[Windows.Automation.ControlType]::Edit)));if($edits.Count -eq 3){break}}
 }
 if(!$dialog){throw 'Folder selection dialog was not shown'}
 if(!$edits -or $edits.Count -ne 3){$children=$dialog.FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition);$details=@($children|ForEach-Object {$_.Current.ControlType.ProgrammaticName+': '+$_.Current.Name});throw ('Folder dialog controls not ready: '+($details -join ' | '))}
 $edits=@($edits|Sort-Object {$_.Current.BoundingRectangle.Top})
 foreach($pair in @(@(0,$installRoot),@(1,$dataRoot),@(2,$cacheRoot))){$value=$edits[[int]$pair[0]].GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern);$value.SetValue([string]$pair[1])}
 $button=$dialog.FindFirst([Windows.Automation.TreeScope]::Descendants,(New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::NameProperty,'Cài đặt')))
 if(!$button){throw 'Install button missing'};[void][ClickButton]::PostMessage([IntPtr]$button.Current.NativeWindowHandle,0xF5,[IntPtr]::Zero,[IntPtr]::Zero)
 if(!$installer.WaitForExit(900000)){throw 'Installer preparation timeout'}
 if($null -ne $installer.ExitCode -and $installer.ExitCode -ne 0){throw "Installer failed $($installer.ExitCode)"}
 $release=Join-Path (Join-Path $installRoot 'releases') $Version
 $cfg=Get-Content (Join-Path $release 'install-settings.json') -Raw|ConvertFrom-Json
 if($cfg.data_directory -ne $dataRoot -or $cfg.cache_directory -ne $cacheRoot){throw 'Folder choices were not saved'}
 if((Get-Content (Join-Path $dataRoot 'setup-status.json') -Raw|ConvertFrom-Json).phase -ne 'ready'){throw 'Components were not fully prepared'}
 $registration=Get-Content (Join-Path $release 'registration.json') -Raw|ConvertFrom-Json
 if((Get-ItemProperty $registration.registry_key).InstallLocation -ne $installRoot){throw 'Windows uninstall registry entry missing'}
 $report.checks+='visible folder dialog; actual UI choices on another drive, Unicode/spaces; data/cache persisted; local tools and SDKs prepared; Windows uninstall entry'
 $exe=Join-Path $release 'SceneForge.exe';$python=Join-Path $release 'runtime\python.exe'
 $launcher=Start-Process -FilePath $exe -PassThru -RedirectStandardOutput (Join-Path $testRoot 'app.log') -RedirectStandardError (Join-Path $testRoot 'app-error.log');$null=$launcher.Handle
 $base=$null
 for($i=0;$i -lt 100;$i++){Start-Sleep -Seconds 1;$instance=Join-Path $dataRoot 'instance.json';if(Test-Path $instance){$port=(Get-Content $instance -Raw|ConvertFrom-Json).port;try{$url="http://127.0.0.1:$port";if((Invoke-RestMethod "$url/local-api/health").service -eq 'sceneforge-local'){$base=$url;break}}catch{}};if($launcher.HasExited){break}}
 if(!$base){throw ('App not ready: '+(Get-Content (Join-Path $testRoot 'app-error.log') -Raw))}
 # SAPI generates a real, local spoken fixture. No paid/cloud voice service.
 $wav=Join-Path $cacheRoot 'speech.wav';$speaker=New-Object -ComObject SAPI.SpVoice;$stream=New-Object -ComObject SAPI.SpFileStream;$stream.Open($wav,3);$speaker.AudioOutputStream=$stream;[void]$speaker.Speak('This is a SceneForge test. We are checking speech recognition and video export.');$stream.Close()
 $uiReport=Join-Path $testRoot 'installed-check.json'
 $ErrorActionPreference='Continue';$output=& $python -E -s -X utf8 "$PSScriptRoot\check_installed.py" (Join-Path $release 'app') $base $wav $uiReport 2>&1|Out-String;$code=$LASTEXITCODE;$ErrorActionPreference='Stop'
 if($code -ne 0){throw ('Installed application test failed: '+$output)};$report.application=Get-Content $uiReport -Raw|ConvertFrom-Json
 $report.checks+='real Windows browser opens both canvases; Whisper transcribes real speech with words/timestamps; installed backend exports and saves H264/AAC; no online generation'
 $again=Native $exe 20000;$report.checks+='second launch reuses current instance'
 taskkill /PID $launcher.Id /T /F|Out-Null;$launcher=$null
 # Repeat the installer with the same folder choices; project/export files must remain.
 $plan=Join-Path $testRoot 'repeat.json';@{install_root=$installRoot;data_directory=$dataRoot;cache_directory=$cacheRoot;voice=$false}|ConvertTo-Json|Set-Content $plan -Encoding UTF8;$env:SCENEFORGE_INSTALL_PLAN=$plan
 $null=Native $InstallerPath
 if(!(Test-Path (Join-Path $dataRoot 'windows-export-check.mp4'))){throw 'Reinstall lost saved video'}
 $report.checks+='reinstall preserves selected project data and exported video'
 Remove-Item Env:\SCENEFORGE_INSTALL_PLAN
 $env:SCENEFORGE_UNINSTALL_TEST='1';$env:SCENEFORGE_UNINSTALL_RESULT=Join-Path $testRoot 'uninstall-result.json'
 $null=Native (Join-Path $release 'SceneForge-Uninstall.exe') 60000 $release
 for($i=0;$i -lt 300;$i++){if(Test-Path $env:SCENEFORGE_UNINSTALL_RESULT){break};Start-Sleep -Milliseconds 300}
 $removed=Get-Content $env:SCENEFORGE_UNINSTALL_RESULT -Raw|ConvertFrom-Json;if(!$removed.passed){throw $removed.error}
 if(Test-Path $release){throw 'Application release was not removed'}
 if(!(Test-Path (Join-Path $dataRoot 'windows-export-check.mp4'))-or(Test-Path $registration.registry_key)){throw 'Uninstall lost data or kept its Windows entry'}
 if((Get-Content (Join-Path $old 'keep.txt')) -ne 'OLD DATA MUST STAY'){throw 'Old data was touched'}
 $report.checks+='native uninstall removes app and Windows registration, preserves project/export/model data and old installation data'
 $report.passed=$true
}catch{$report.error="$_";$report.error_line=$_.InvocationInfo.ScriptLineNumber;throw}
finally{if($launcher -and !$launcher.HasExited){taskkill /PID $launcher.Id /T /F|Out-Null};if($installer -and !$installer.HasExited){taskkill /PID $installer.Id /T /F|Out-Null};$report|ConvertTo-Json -Depth 12|Set-Content -LiteralPath 'full-windows-check-report.json' -Encoding UTF8;subst $drive /D}
