"""Installed application's explicit data/cache paths, configured before importing backend."""
import json,os,tempfile
from pathlib import Path

def configure(app):
    settings=Path(app).parent/'install-settings.json'
    if not settings.is_file():return None
    data=json.loads(settings.read_text(encoding='utf-8-sig'))
    for key in ('data_directory','cache_directory','temp_directory'):
        path=Path(data[key])
        if not path.is_absolute()or path==Path(path.anchor):raise RuntimeError('Invalid installation path: '+key)
        path.mkdir(parents=True,exist_ok=True)
    root,cache,temporary=(Path(data[k])for k in ('data_directory','cache_directory','temp_directory'))
    os.environ['SCENEFORGE_LOCAL_DATA']=str(root)
    variables={'PIP_CACHE_DIR':cache/'pip','HF_HOME':cache/'huggingface','HF_HUB_CACHE':cache/'huggingface/hub','HUGGINGFACE_HUB_CACHE':cache/'huggingface/hub','TRANSFORMERS_CACHE':cache/'huggingface/transformers','TORCH_HOME':cache/'torch','XDG_CACHE_HOME':cache,'PLAYWRIGHT_BROWSERS_PATH':cache/'browsers','TEMP':temporary,'TMP':temporary,'TMPDIR':temporary}
    for key,path in variables.items():os.environ[key]=str(path)
    tempfile.tempdir=str(temporary)
    tools=Path(app).parent/'tools'
    os.environ['PATH']=str(tools)+os.pathsep+os.environ.get('PATH','')
    return data
