﻿$ErrorActionPreference='Stop'
$script:stage='initializing';$installRoot='D:\SF-registration-check';$version='2026.10.28.2'
$destination=Join-Path $installRoot ('releases\'+$version)
[void][IO.Directory]::CreateDirectory($destination)
foreach($name in @('SceneForge.exe','SceneForge-Uninstall.exe','SceneForge-Tools.exe')){Copy-Item -LiteralPath (Join-Path $env:WINDIR 'System32\cmd.exe') -Destination (Join-Path $destination $name) -Force}
$source=Get-Content -LiteralPath "$PSScriptRoot\install.ps1" -Raw -Encoding UTF8
$a=$source.IndexOf("        `$exe=Join-Path `$destination 'SceneForge.exe';")
$b=$source.IndexOf("        Progress 'Cài đặt và kiểm tra hoàn tất.'",$a)
if($a -lt 0 -or $b -lt 0){throw 'Registration block not found'}
$report=@{passed=$false;phase='Windows registration probe'}
try{& ([scriptblock]::Create($source.Substring($a,$b-$a)));$report.passed=$true}
catch{$report.stage=$script:stage;$report.error=$_.Exception.ToString();$report.source_line=$_.InvocationInfo.Line;$report.stack=$_.ScriptStackTrace;$report|ConvertTo-Json -Depth 6|Set-Content full-windows-check-report.json -Encoding UTF8;throw}
finally{
 $report|ConvertTo-Json -Depth 6|Set-Content registration-probe.json -Encoding UTF8
 $ws=New-Object -ComObject WScript.Shell
 $menu=Join-Path ([Environment]::GetFolderPath('Programs')) 'SceneForge'
 $links=@();if(Test-Path $menu){$links+=Get-ChildItem $menu -Filter '*.lnk'|ForEach-Object {$_.FullName}}
 $desktop=[Environment]::GetFolderPath('Desktop');if($desktop){$links+=Join-Path $desktop 'SceneForge.lnk'}
 foreach($link in $links){if(Test-Path $link){if($ws.CreateShortcut($link).TargetPath.StartsWith($installRoot,[StringComparison]::OrdinalIgnoreCase)){Remove-Item $link -Force}}}
 Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SceneForge-*' -ErrorAction SilentlyContinue|Where-Object {$_.InstallLocation -eq $installRoot}|ForEach-Object {Remove-Item $_.PSPath -Force -Recurse}
 Remove-Item $installRoot -Force -Recurse
}
