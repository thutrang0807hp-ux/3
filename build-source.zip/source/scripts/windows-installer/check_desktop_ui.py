"""Exercise the installed native window through WebView2 CDP, including the real source button."""
from pathlib import Path
import json,os,sys,time,subprocess,urllib.request
app=Path(sys.argv[1]);data=Path(sys.argv[2]);port=int(sys.argv[3]);wave=Path(sys.argv[4]);output=Path(sys.argv[5])
sys.path.insert(0,str(app));os.chdir(app)
from paths import configure
configure(app)
from playwright.sync_api import sync_playwright
video=data/'desktop-voice-test.mp4'
subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=180x320:r=12','-i',str(wave),'-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest','-y',str(video)],check=True,creationflags=0x08000000)
state=json.loads((data/'desktop-state.json').read_text(encoding='utf-8-sig'));assert state['phase']=='ready'and not state['console']
report={'native_window':True,'browser_container':'WebView2','app_version':state['app_version'],'requests':[],'checks':[]}
with sync_playwright()as pw:
 browser=pw.chromium.connect_over_cdp('http://127.0.0.1:'+str(port));context=browser.contexts[0]
 deadline=time.monotonic()+60;p=None
 while time.monotonic()<deadline:
  p=next((p for p in context.pages if p.url.startswith(state['url'])),None)
  if p:break
  time.sleep(.2)
 assert p,'Native WebView2 application page missing'
 errors=[];cloud=[];uploads=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 def request(r):
  if r.method=='POST'and'/analysis/local/upload'in r.url:uploads.append(r.url)
  if r.method=='POST'and any(s in r.url for s in ['/gemini-chat/jobs','/flow/jobs','/muse/jobs','/ai/analyze']):cloud.append(r.url)
 p.on('request',request)
 p.wait_for_function('appBootReady&&SceneForgeStorage.state.active',timeout=60000)
 p.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();if(document.querySelector('#shellDialog').open)document.querySelector('#shellDialog').close();const r={id:'desktop-reference',name:'Desktop real button',mode:'reference',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis')}")
 frame=p.locator('#workflowFrame').element_handle().content_frame();frame.wait_for_function('!!window.SFPromptPipeline')
 frame.locator('#sourceFile').set_input_files(str(video))
 frame.wait_for_function('!!project.source&&!project.scenes.length')
 def click_source_and_check(label):
  before=len(uploads)
  # Invoke the actual DOM button and its registered click handler, never the pipeline API.
  frame.locator('#node-source [data-action="analyze"]').evaluate('(button)=>button.click()')
  frame.wait_for_function('!g6PipelineActive&&(!!project.analysis.local||!!project.analysis.pipeline6?.error)',timeout=300000)
  result=frame.evaluate('({steps:project.analysis.pipeline6,local:project.analysis.local,script:project.script,scenes:project.scenes.length})')
  assert not result['steps'].get('error'),result['steps']
  assert len(uploads)>before,(label,'Source button never submitted local CPU job')
  assert 'transcribe=true'in uploads[-1]and'ocr=true'in uploads[-1],uploads[-1]
  measured=result['local']['result'];assert measured['speech']['state']=='transcribed'and result['script'],measured['speech']
  assert any(row.get('words')for row in result['script']),'No actual Whisper word timestamps'
  assert measured['ocr_state']=='sampled'and measured['provider_requests']==0
  assert all(result['steps']['steps'][key]=='done'for key in ['cuts','speech','ocr','camera','quality']),result['steps']
  assert not frame.locator('#node-analysis').inner_text().find('Chưa có bản chép lời')>=0
  report['checks'].append(label);return result
 result=click_source_and_check('fresh video: source button runs real Whisper, OCR, camera and quality measurements')
 report['transcript']=[r['original']for r in result['script']]
 # Exact old screenshot state: scenes exist, while local measurements and speech are absent.
 frame.evaluate('async()=>{delete project.analysis.local;delete project.analysis.semantic;delete project.analysis.pipeline6;project.script=[];await storeProject();render()}')
 click_source_and_check('existing cut-only project: same source button completes missing local measurements')
 # A completed measurement without speech must not permanently block later transcription.
 frame.evaluate("async()=>{project.analysis.local.result.speech={state:'not_requested',audio_present:true};project.script=[];await storeProject();render()}")
 click_source_and_check('partial older CPU result: missing speech is filled instead of skipped')
 before=len(uploads);frame.locator('#node-source [data-action="analyze"]').evaluate('(button)=>button.click()');frame.wait_for_function('!g6PipelineActive')
 assert len(uploads)==before,'Completed CPU result was sent again unnecessarily'
 report['checks'].append('repeat click reuses complete measurements; no duplicate CPU job or paid generation')
 api=context.request;headers={'X-SceneForge-Local':'1','Content-Type':'video/mp4'}
 response=api.post(state['url']+'local-api/export/mp4?fps=30&normalize=false&room_id=desktop-reference',data=video.read_bytes(),headers=headers,timeout=60000);assert response.ok,response.text();rid=response.json()['id'];deadline=time.monotonic()+120
 while time.monotonic()<deadline:
  status=api.get(state['url']+'local-api/export/jobs/'+rid).json()
  if status['state']in ['done','error','cancelled']:break
  time.sleep(.25)
 assert status['state']=='done',status
 rendered=api.get(state['url']+'local-api/export/jobs/'+rid+'/file');assert rendered.ok
 (data/'desktop-export.mp4').write_bytes(rendered.body());report['checks'].append('real MP4 export remains working after small update')
 p.evaluate("async()=>{const r={id:'desktop-photos',name:'Desktop photos',mode:'photos',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis')}")
 f=p.locator('#workflowFrame').element_handle().content_frame();f.wait_for_function('loaded&&!!window.SFPhotoPromptPipeline');report['checks'].append('photo workflow opens in the same native app')
 assert not errors,errors;assert not cloud,cloud
 report['requests']=uploads;report['online_generation_requests']=cloud;report['page_errors']=errors
 # Leave window lifecycle to its owning native process; disconnecting CDP does not close it.
 browser.close()
output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('PASS native WebView2, real source-node button, missing-step recovery, actual ASR/OCR and MP4')
