"""Build-machine resource fetch, pinned repository sources; no accounts or generation."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,urllib.request,zipfile

REPOS={'gemini':('https://github.com/HanaokaYuzu/Gemini-API.git','1ad0d4a93e505e77c79769d78ef2997641f973c8'),'flow':('https://github.com/TheSmallHanCat/flow2api.git','1bcb9275d154c330d29cac3ba836a13393ff49c7'),'voice':('https://github.com/pnnbao97/VieNeu-TTS.git','04044e1b8f822f946bafb2c88b716459f4164152')}
def run(*args):subprocess.run([str(x)for x in args],check=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--core-wheels',type=Path,required=True);args=ap.parse_args();root=args.output;root.mkdir(parents=True,exist_ok=True);manifest={}
 run(sys.executable,'-m','pip','download','--dest',args.core_wheels,'--only-binary=:all:','-r','local_engine/requirements.txt','-r','local_engine/requirements-cpu.txt','colorama','tzdata')
 from faster_whisper.utils import download_model
 download_model('base',output_dir=str(root/'whisper'))
 for name,(url,rev)in REPOS.items():
  checkout=root/'sources'/name
  if not checkout.exists():run('git','clone','--quiet',url,checkout);run('git','-C',checkout,'checkout','--detach',rev)
  actual=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip();assert actual==rev
  wheels=root/'wheels'/name;wheels.mkdir(parents=True,exist_ok=True)
  if name=='gemini':run(sys.executable,'-m','pip','wheel','--wheel-dir',wheels,checkout)
  elif name=='flow':run(sys.executable,'-m','pip','wheel','--wheel-dir',wheels,'-r',checkout/'requirements.txt')
  rows=[]
  for p in checkout.rglob('*'):
   if p.is_file()and'.git'not in p.relative_to(checkout).parts:rows.append({'path':p.relative_to(checkout).as_posix(),'sha256':digest(p)})
  (checkout/'.sceneforge-source.json').write_text(json.dumps({'revision':rev,'repository':url,'files':rows},indent=2),encoding='utf-8')
  shutil.rmtree(checkout/'.git',onerror=lambda f,p,e:(os.chmod(p,0o700),f(p)));manifest[name]={'repository':url,'revision':rev}
 url='https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip';archive=root/'ffmpeg-download.zip'
 urllib.request.urlretrieve(url,archive)
 tools=root/'tools';tools.mkdir(exist_ok=True);licenses=root/'licenses/ffmpeg';licenses.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(archive)as z:
  for entry in z.infolist():
   leaf=Path(entry.filename).name
   if leaf in ('ffmpeg.exe','ffprobe.exe'):(tools/leaf).write_bytes(z.read(entry))
   elif any(x in leaf.lower()for x in ['license','copying','readme']):
    if not entry.is_dir():(licenses/leaf).write_bytes(z.read(entry))
 manifest['ffmpeg']={'url':url,'sha256':digest(archive),'source':'https://github.com/BtbN/FFmpeg-Builds','license':'GPL; standalone executables; upstream licenses and source/build references included'}
 (licenses/'SOURCE.txt').write_text('FFmpeg binaries: '+url+'\nBuild recipes and dependency source revisions: https://github.com/BtbN/FFmpeg-Builds\nFFmpeg upstream: https://github.com/FFmpeg/FFmpeg\nFull SceneForge source supplied separately on the download page.\n')
 archive.unlink()
 manifest['whisper']={'source':'Systran/faster-whisper-base','files':{p.name:{'bytes':p.stat().st_size,'sha256':digest(p)}for p in(root/'whisper').iterdir()if p.is_file()}}
 (root/'resource-manifest.json').write_text(json.dumps(manifest,indent=2));print('Resources ready',json.dumps(manifest,indent=2))
if __name__=='__main__':main()
