#ifndef UNICODE
#define UNICODE
#endif
#include <windows.h>
#include <wchar.h>
#include <stdio.h>
#include "task_config.h"
int wmain(void){
 wchar_t root[32768],shell[32768],cmd[32768];if(!GetModuleFileNameW(NULL,root,32768))return 1;
 wchar_t *slash=wcsrchr(root,L'\\');if(!slash)return 1;*slash=0;SetEnvironmentVariableW(L"SF_TASK_ROOT",root);
 if(!GetEnvironmentVariableW(L"SystemRoot",shell,32700))return 1;wcscat(shell,L"\\System32\\WindowsPowerShell\\v1.0\\powershell.exe");
 if(swprintf(cmd,32768,L"\"%ls\" -STA -NoLogo -NoProfile -NonInteractive -EncodedCommand %ls",shell,TASK_COMMAND)<0)return 1;
 STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);
 // PowerShell owns the GUI; the native launcher exits so uninstall can remove its files.
 if(!CreateProcessW(shell,cmd,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi))return 1;
 CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return 0;
}
