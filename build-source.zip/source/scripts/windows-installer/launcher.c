#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <stdio.h>
#include <wchar.h>

/* Console remains open while the local server runs. Closing it stops the app. */
int wmain(int argc, wchar_t **argv) {
    wchar_t root[32768], runtime[32768], app[32768], cmd[32768];
    DWORD length=GetModuleFileNameW(NULL,root,32768);
    if(!length||length>=32768)return 1;
    wchar_t *slash=wcsrchr(root,L'\\');if(!slash)return 1;*slash=0;
    if(swprintf(runtime,32768,L"%ls\\runtime\\python.exe",root)<0||
       swprintf(app,32768,L"%ls\\app",root)<0)return 1;
    if(GetFileAttributesW(runtime)==INVALID_FILE_ATTRIBUTES){
        MessageBoxW(NULL,L"Missing bundled runtime. Reinstall SceneForge.",L"SceneForge",MB_ICONERROR);return 1;
    }
    const wchar_t *option=(argc==2&&wcscmp(argv[1],L"--setup-whisper")==0)?L" --setup-whisper":L"";
    if(swprintf(cmd,32768,L"\"%ls\" -E -s -X utf8 \"%ls\\windows_bootstrap.py\"%ls",runtime,app,option)<0)return 1;
    SetConsoleOutputCP(CP_UTF8);SetConsoleCP(CP_UTF8);
    printf("SceneForge - local Windows app\nKeep this window open while using SceneForge.\nClose this window to stop.\n\n");
    STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);
    if(!CreateProcessW(runtime,cmd,NULL,NULL,TRUE,CREATE_SUSPENDED,NULL,app,&si,&pi)){
        printf("Cannot start bundled Python. Windows error: %lu\n",GetLastError());getchar();return 1;
    }
    HANDLE job=CreateJobObjectW(NULL,NULL);
    if(job){JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits={0};limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;SetInformationJobObject(job,JobObjectExtendedLimitInformation,&limits,sizeof(limits));AssignProcessToJobObject(job,pi.hProcess);}
    ResumeThread(pi.hThread);
    WaitForSingleObject(pi.hProcess,INFINITE);DWORD code=1;GetExitCodeProcess(pi.hProcess,&code);
    CloseHandle(pi.hProcess);CloseHandle(pi.hThread);if(job)CloseHandle(job);
    if(code){printf("\nSceneForge stopped with error %lu. Save the message above. Press Enter to close.\n",code);getchar();}
    return (int)code;
}
