﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$root=$env:SF_TASK_ROOT;$cfg=Get-Content -LiteralPath (Join-Path $root 'install-settings.json') -Raw|ConvertFrom-Json
$form=New-Object Windows.Forms.Form;$form.Text='SceneForge — Công cụ và sửa cài đặt';$form.Size=New-Object Drawing.Size(700,470);$form.StartPosition='CenterScreen';$form.Font=New-Object Drawing.Font('Segoe UI',10)
$label=New-Object Windows.Forms.Label;$label.Text="Dữ liệu: $($cfg.data_directory)`r`nCache: $($cfg.cache_directory)";$label.SetBounds(20,18,640,60);$form.Controls.Add($label)
$log=New-Object Windows.Forms.TextBox;$log.Multiline=$true;$log.ReadOnly=$true;$log.ScrollBars='Vertical';$log.SetBounds(20,175,640,225);$form.Controls.Add($log)
$script:child=$null
function RunTask($component){
 if($script:child -and !$script:child.HasExited){return}
 $instance=Join-Path $cfg.data_directory 'instance.json'
 if(Test-Path -LiteralPath $instance){$running=Get-Content $instance -Raw|ConvertFrom-Json;if(Get-Process -Id $running.pid -ErrorAction SilentlyContinue){[void][Windows.Forms.MessageBox]::Show('Đóng SceneForge trước khi sửa/cài công cụ để không ảnh hưởng việc đang chạy.');return}}
 $log.Text='Đang chuẩn bị '+$component+'…';$si=New-Object Diagnostics.ProcessStartInfo;$si.FileName=Join-Path $root 'runtime\python.exe';$si.Arguments='-E -s -X utf8 "'+(Join-Path $root 'app\provision.py')+'" --components '+$component;$si.WorkingDirectory=Join-Path $root 'app';$si.UseShellExecute=$false;$si.CreateNoWindow=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
 $script:child=New-Object Diagnostics.Process;$script:child.StartInfo=$si;[void]$script:child.Start();$stdout=$script:child.StandardOutput.ReadToEndAsync();$stderr=$script:child.StandardError.ReadToEndAsync()
 while(!$script:child.WaitForExit(150)){[Windows.Forms.Application]::DoEvents()}
 $text=$stdout.Result+"`r`n"+$stderr.Result;$path=Join-Path $cfg.data_directory 'component-log.txt';[IO.File]::WriteAllText($path,$text,(New-Object Text.UTF8Encoding($false)))
 $log.Text=$(if($script:child.ExitCode -eq 0){'Đã chuẩn bị và kiểm tra xong.'}else{'Chưa cài xong. Không đánh dấu sẵn sàng.'})+"`r`nNhật ký: $path`r`n"+$text;$script:child.Dispose();$script:child=$null
}
$items=@(@('Kiểm tra / sửa công cụ video','core'),@('Chuẩn bị Gemini Chat','gemini'),@('Chuẩn bị Flow','flow'),@('Giọng AI VieNeu — tải thêm','voice'))
for($i=0;$i -lt $items.Count;$i++){$b=New-Object Windows.Forms.Button;$b.Text=$items[$i][0];$b.Tag=$items[$i][1];$b.SetBounds((20+($i%2)*325),(90+[int][Math]::Floor($i/2)*38),315,32);$b.Add_Click({RunTask $this.Tag});$form.Controls.Add($b)}
$open=New-Object Windows.Forms.Button;$open.Text='Mở dữ liệu';$open.SetBounds(20,405,130,30);$open.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+$cfg.data_directory+'"')});$form.Controls.Add($open)
$update=New-Object Windows.Forms.Button;$update.Text='Kiểm tra cập nhật';$update.SetBounds(460,405,200,30);$update.Add_Click({Start-Process 'https://thutrang0807hp-ux.github.io/3/download-code.html'});$form.Controls.Add($update)
$form.Add_FormClosing({if($script:child -and !$script:child.HasExited){& taskkill /PID $script:child.Id /T /F|Out-Null}})
if($env:SCENEFORGE_COMPONENT_TEST -eq '1'){RunTask 'core'}else{[void]$form.ShowDialog()}
