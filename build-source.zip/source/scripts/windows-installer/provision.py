"""Prepare bundled local tools and reviewed SDKs. Never log in or generate online media."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from paths import configure

APP=Path(__file__).resolve().parent
ROOT=APP.parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--components',default='core,gemini,flow');args=ap.parse_args()
    cfg=configure(APP)
    if not cfg:raise RuntimeError('Installation settings missing')
    sys.path.insert(0,str(APP));os.chdir(APP)
    data=Path(cfg['data_directory']);resources=ROOT/'resources';components=args.components.split(',');results={}
    statefile=data/'setup-status.json'
    def state(phase,error=None):
        record={'phase':phase,'results':results,'error':error,'updated_at':time.time()};temp=statefile.with_suffix('.tmp');temp.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(statefile);print(phase,flush=True)
    def ready_environment(target):
        environment=target/'venv'
        if not environment.exists():return
        python=environment/'Scripts/python.exe'
        test=subprocess.run([str(python),'-c','import sys;print(sys.version)'],capture_output=True)if python.is_file()else None
        if test is None or test.returncode:
            marker=target/'installation.json'
            if not marker.is_file():raise RuntimeError('Unknown incomplete SDK folder; kept untouched: '+str(target))
            # Only a verified app-created SDK environment is disposable; models/accounts/source stay.
            meta=json.loads(marker.read_text(encoding='utf-8'))
            if not meta.get('dependencies_checked'):raise RuntimeError('SDK ownership not verified: '+str(target))
            shutil.rmtree(environment)
    try:
        if 'core'in components:
            state('Checking video tools and speech recognition')
            for name in ['ffmpeg','ffprobe']:
                if not shutil.which(name):raise RuntimeError(name+' was not bundled correctly')
                subprocess.run([name,'-version'],check=True,stdout=subprocess.DEVNULL)
            from local_engine.cpu_analysis import capabilities
            caps=capabilities(data)
            for key in ['ffmpeg','opencv','scenedetect','ocr','whisper']:
                if not caps[key]:raise RuntimeError('Local component missing: '+key)
            from local_engine.prepare_whisper import prepare,verify_model
            target=data/'models/faster-whisper'
            if (target/'model.bin').is_file():verify_model(target)
            else:prepare(target,source=resources/'whisper')
            results['core']='ready';state('Local video tools and Whisper are ready')
        for name,folder in [('gemini','gemini-web'),('flow','flow2api'),('voice','vieneu')]:
            if name not in components:continue
            state('Preparing '+name+' tools')
            target=data/'engines'/folder;target.mkdir(parents=True,exist_ok=True)
            if not(target/'source').exists():shutil.copytree(resources/'sources'/name,target/'source')
            ready_environment(target)
            wheels=resources/'wheels'/name
            if name=='voice':
                # Voice is explicitly optional; may download models after the user selects it.
                os.environ.pop('SCENEFORGE_OFFLINE_WHEELS',None)
            else:os.environ['SCENEFORGE_OFFLINE_WHEELS']=str(wheels)
            if name=='flow':
                from local_engine.setup_flow import main as setup
                previous=sys.argv;sys.argv=['setup_flow','--directory',str(target),'--source',str(resources/'sources'/name),'--connect']
                try:setup()
                finally:sys.argv=previous
            else:
                from local_engine.setup_optional_repos import prepare
                prepare(name,target,source=str(resources/'sources'/name))
                if name=='voice':
                    from local_engine.prepare_voice import prepare as prepare_voice
                    prepare_voice(target)
            results[name]='ready';state(name+' tools are ready; sign in with your own account in the app')
        state('ready')
    except BaseException as e:
        state('incomplete',str(e));raise

if __name__=='__main__':main()
