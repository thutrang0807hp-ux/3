#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <stdio.h>
#include <wchar.h>
#include "installer_config.h"

/* The SHA-256 checked ZIP payload is appended after this native executable. */
int wmain(void){
    wchar_t own[32768],shell[32768],command[32768];
    if(!GetModuleFileNameW(NULL,own,32768))return 1;
    DWORD n=GetEnvironmentVariableW(L"SystemRoot",shell,32768);
    if(!n||n>=32700)return 1;
    wcscat(shell,L"\\System32\\WindowsPowerShell\\v1.0\\powershell.exe");
    SetEnvironmentVariableW(L"SF_INSTALL_FILE",own);
    if(swprintf(command,32768,L"\"%ls\" -STA -NoLogo -NoProfile -NonInteractive -EncodedCommand %ls",shell,INSTALL_COMMAND)<0)return 1;
    printf("Installing SceneForge for this Windows user...\nNo administrator access or separate Python installation needed.\n");
    STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);
    if(!CreateProcessW(shell,command,NULL,NULL,TRUE,0,NULL,NULL,&si,&pi)){
        printf("Cannot start Windows PowerShell. Error %lu\n",GetLastError());getchar();return 1;
    }
    WaitForSingleObject(pi.hProcess,INFINITE);DWORD code=1;GetExitCodeProcess(pi.hProcess,&code);
    CloseHandle(pi.hThread);CloseHandle(pi.hProcess);
    if(code){printf("\nInstallation did not finish. Save the error above. Press Enter to close.\n");getchar();}
    return(int)code;
}
