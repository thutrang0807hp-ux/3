"""Real installed Windows app: UI, CPU ASR and a saved H264/AAC export; no online AI."""
import base64,json,os,subprocess,sys,time
from pathlib import Path
app=Path(sys.argv[1]);sys.path.insert(0,str(app));os.chdir(app)
from paths import configure
cfg=configure(app);data=Path(cfg['data_directory'])
from playwright.sync_api import sync_playwright
candidates=[Path(os.environ.get(k,''))/r for k in ['PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA']for r in ['Google/Chrome/Application/chrome.exe','Microsoft/Edge/Application/msedge.exe']]
exe=next(p for p in candidates if p.is_file())
speech=Path(sys.argv[3]);video=Path(cfg['temp_directory'])/'sample-speech.mp4'
subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=180x320:r=12','-i',str(speech),'-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest','-y',str(video)],check=True)
duration=float(json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-of','json',str(video)]))['format']['duration'])
report={'data_directory':str(data),'cache_directory':cfg['cache_directory'],'environment':{k:os.environ.get(k)for k in ['TEMP','PIP_CACHE_DIR','HF_HOME','PLAYWRIGHT_BROWSERS_PATH']}}
with sync_playwright()as pw:
 b=pw.chromium.launch(executable_path=str(exe),headless=True);p=b.new_page(viewport={'width':1500,'height':1000});errors=[];generation=[]
 p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda r:generation.append(r.url)if r.method=='POST'and any(x in r.url for x in ['/flow/jobs','/muse/jobs','/gemini-chat/jobs','/web-images/jobs'])else None)
 p.goto(sys.argv[2]);p.wait_for_function('appBootReady&&SceneForgeStorage.state.active',timeout=60000)
 p.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close()}")
 for mode in ['reference','photos']:
  p.evaluate("async mode=>{const r={id:'installed-'+mode,name:'Installed test',mode,stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis')}",mode)
  f=p.locator('#workflowFrame').element_handle().content_frame();f.wait_for_function('!!window.SFPromptPipeline'if mode=='reference'else'loaded&&!!window.SFPhotoPromptPipeline');f.wait_for_function('!!SceneForgeWorkflow.workspaceAutoPlan?.()')
  assert len(f.evaluate('SceneForgeWorkflow.workspaceAutoPlan().scopes'))==3
 api=p.context.request;base=sys.argv[2];headers={'X-SceneForge-Local':'1'}
 def get(path):
  r=api.get(base+path);assert r.ok,(path,r.status,r.text());return r.json()
 caps=get('/local-api/analysis/local/capabilities');assert all(caps[k]for k in ['available','ffmpeg','opencv','scenedetect','ocr','whisper','whisper_model']),caps;report['capabilities']=caps
 sdk=get('/local-api/gemini-chat/status');assert sdk['installed'];report['gemini_sdk']=sdk['installed']
 assert(data/'engines/flow2api/installation.json').is_file()
 # Verify the real owned engine actually started, beyond source/venv marker checks.
 from local_engine.vault import Vault
 import httpx
 connection=Vault(data).secret('flow-engine');assert connection
 deadline=time.monotonic()+120;engine_error=None
 while time.monotonic()<deadline:
  try:
   response=httpx.get(connection['url']+'/sceneforge/accounts',headers={'Authorization':'Bearer '+connection['key']},timeout=3)
   response.raise_for_status();inventory=response.json()
   assert inventory['protocol']=='sceneforge-account-pin-v1' and inventory['single_attempt']
   report['flow_engine']={'started':True,'protocol':inventory['protocol'],'single_attempt':True};break
  except Exception as e:engine_error=str(e);time.sleep(1)
 else:
  log=data/'flow-startup.log'
  raise AssertionError('Installed Flow engine did not become ready: '+str(engine_error)+' | '+(log.read_text(encoding='utf-8',errors='replace')[-8000:]if log.is_file()else 'no log'))
 r=api.post(base+'/local-api/analysis/local/jobs',data={'video_data':base64.b64encode(video.read_bytes()).decode(),'mime_type':'video/mp4','duration':duration,'transcribe':True,'language':'en','ocr':False},headers=headers,timeout=60000);assert r.ok,r.text();jobid=r.json()['id']
 deadline=time.monotonic()+240
 while True:
  job=get('/local-api/analysis/local/jobs/'+jobid)
  if job['state']in ['done','error','cancelled']:break
  assert time.monotonic()<deadline;time.sleep(.5)
 assert job['state']=='done',job
 result=job['result'];assert result['speech']['state']=='transcribed'and result['transcript']and any(r['words']for r in result['transcript']),result['speech'];assert result['provider_requests']==0
 report['transcription']=[{'start':r['start'],'end':r['end'],'text':r['original']}for r in result['transcript']]
 r=api.post(base+'/local-api/export/mp4?fps=30&normalize=false&duration='+str(duration)+'&room_id=installed-photos',data=video.read_bytes(),headers={**headers,'Content-Type':'video/mp4'},timeout=60000);assert r.ok,r.text();rid=r.json()['id'];deadline=time.monotonic()+120
 while True:
  status=get('/local-api/export/jobs/'+rid)
  if status['state']in ['done','error','cancelled']:break
  assert time.monotonic()<deadline;time.sleep(.25)
 assert status['state']=='done',status
 result=api.get(base+'/local-api/export/jobs/'+rid+'/file');assert result.ok
 output=data/'windows-export-check.mp4';output.write_bytes(result.body());meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(output)]));assert any(s.get('codec_name')=='h264'for s in meta['streams'])and any(s.get('codec_name')=='aac'for s in meta['streams'])
 report['export']={'bytes':output.stat().st_size,'duration':meta['format']['duration'],'codec':'H264/AAC','saved_to_selected_data_directory':True}
 assert not errors,errors;assert not generation,generation
 report['page_errors']=errors;report['online_generation_requests']=generation;b.close()
Path(sys.argv[4]).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('PASS installed UI, offline CPU speech, saved H264 export and selected data/cache paths')
