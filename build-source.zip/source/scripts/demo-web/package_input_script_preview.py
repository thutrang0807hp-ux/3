"""Standalone real UI, isolated sample data; no remote generation."""
from pathlib import Path
import json
r=Path(__file__).resolve().parents[2];s=(r/'artifacts/SceneForge-MoPhong-AnhThanhVideo.html').read_text().replace('sceneforge-photo-post-preview-20261027','sceneforge-input-script-preview-20261028')
seed=r'''(async()=>{
 if(!draft.inputScriptPreviewSeeded){const refs=structuredClone(draft.refs);draft=newDraft();draft.refs=refs;draft.beats=[];draft.voice={mode:'native'};draft.inputScriptPreviewSeeded=true;const s=SFPhotoScript.state();s.raw='[Cảnh 1 – cầm sản phẩm]\nMình giới thiệu sản phẩm dưới ánh sáng tự nhiên.\n\n[Cảnh 2 – cận cảnh]\nĐây là bao bì và màu sắc nhìn gần.\n\n[Cảnh 3]\nBạn xem thêm thông tin sản phẩm nhé.';await SFPhotoScript.apply();}
 render();photoToolbarFocus('refs');view.z=.9;view.x=35;view.y=35;applyView();await save();
})()'''
boot="<script>(()=>{const t=setInterval(()=>{const w=document.querySelector('#workflowFrame')?.contentWindow;if(!w?.SFPhotoScript||!w.eval('loaded && !!draft.previewPostSeeded'))return;clearInterval(t);w.eval("+json.dumps(seed)+").catch(e=>console.error(e));},100);})();</script>"
s=s.replace('</body>',boot+'</body>');out=r/'artifacts/SceneForge-MoPhong-AnhDauVao-KichBan.html';out.write_text(s);print(out,out.stat().st_size)
