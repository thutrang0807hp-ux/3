"""Patch the recovered published bundle; do not rebuild missing unbundled design assets."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[2];dist=root/'dist/web-demo'
css=(root/'scripts/app-shell/notification-center.css').read_text();js=(root/'scripts/app-shell/notification-center.js').read_text()
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=dist/name;s=p.read_text();s=re.sub(r'<style id="notification-center-css">[\s\S]*?</style>','',s);s=re.sub(r'<script id="notification-center-js">[\s\S]*?</script>','',s)
 s=s.replace('</head>','<style id="notification-center-css">'+css+'</style></head>',1).replace('</body>','<script id="notification-center-js">'+js+'</script></body>',1);p.write_text(s)
print('Patched compact notification module into 4 recovered published bundles')
