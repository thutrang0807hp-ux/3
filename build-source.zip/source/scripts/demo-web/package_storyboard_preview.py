"""Isolated UI fixtures for storyboard modes. No remote generation or real model claims."""
from pathlib import Path
import json
r=Path(__file__).resolve().parents[2];source=r/'artifacts/SceneForge-MoPhong-AnhThanhVideo.html';s=source.read_text().replace('sceneforge-photo-post-preview-20261027','sceneforge-storyboard-preview-20261028')
seed=r'''(async()=>{
 const model='offline-preview-portrait';const originalEngine=bridge.engine.bind(bridge);bridge.engine=async(path,...args)=>path==='flow/status'?{configured:false,installed:false,models:[model],model_details:[{id:model,sceneforge_inputs:{transport:'ordered_images',first_image:'start',second_image:'end'}}],selection:{available:false}}:originalEngine(path,...args);
 photoTools().flowModel=model;
 if(!draft.storyboardPreviewSeeded){
  draft.voice={mode:'native'};draft.storyboardPlan={mode:'frames',slots:{},description:'',usedOverall:null};
  const list=SFStoryboard.slots();for(const row of list.slice(0,3))row.s.selected=true;if(list[1])list[1].s.mode='pair';
  for(let n=0;n<Math.min(2,list.length);n++){const r=list[n],src=r.b.clips?.[0]?.poster||draft.refs?.product?.images?.[0]?.image;let file;
   if(src)file=await(await fetch(src)).blob();else{const c=document.createElement('canvas');c.width=360;c.height=640;const g=c.getContext('2d');g.fillStyle=n?'#8771a2':'#bd8d79';g.fillRect(0,0,360,640);g.fillStyle='#f3e8d9';g.font='24px sans-serif';g.fillText('Ảnh minh họa '+(n+1),60,330);file=await new Promise(ok=>c.toBlob(ok,'image/png'));}
   await SFStoryboard.importImage(r.id,'start',new File([file],'Anh-minh-hoa.png',{type:file.type}));if(n===1)await SFStoryboard.importImage(r.id,'end',new File([file],'Anh-cuoi-minh-hoa.png',{type:file.type}));
  }
  draft.storyboardPreviewSeeded=true;await save();
 }
 const before=render;render=function(...args){const result=before(...args),n=document.querySelector('[data-node=storyboard] .body');if(n&&!n.querySelector('.sbPreviewNote'))n.insertAdjacentHTML('afterbegin','<p class="sbWarn sbPreviewNote">Mô phỏng · ảnh có sẵn, khả năng đầu/cuối minh họa; không kết nối tài khoản hoặc gọi AI.</p>');return result;};
 await SFStoryboard.refresh();render();view.z=.95;photoToolbarFocus('storyboard');
})()'''
boot="<script>(()=>{const t=setInterval(()=>{const w=document.querySelector('#workflowFrame')?.contentWindow;if(!w?.SFStoryboard||!w.eval('loaded && !!draft.previewPostSeeded'))return;clearInterval(t);document.querySelector('#shellDialog')?.close();w.eval("+json.dumps(seed)+").catch(e=>console.error(e));},100);})();</script>"
s=s.replace('</body>',boot+'</body>');out=r/'artifacts/SceneForge-MoPhong-Storyboard.html';out.write_text(s);out.chmod(0o644);print(out,out.stat().st_size)
