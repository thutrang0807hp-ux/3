from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parents[2];dist=root/'dist/web-demo'
def patch(p,key,js,css):
 s=p.read_text();s=re.sub('<style id="'+key+'-css">[\\s\\S]*?</style>','',s);s=re.sub('<script id="'+key+'-js">[\\s\\S]*?</script>','',s);s=s.replace('</head>','<style id="'+key+'-css">'+css+'</style></head>',1).replace('</body>','<script id="'+key+'-js">'+js+'</script></body>',1);p.write_text(s)
js=(root/'scripts/shared/workspace-frame.js').read_text();css=(root/'scripts/shared/workspace-frame.css').read_text()
for name in ['workflow.html','photos.html']:patch(dist/name,'workspace-frame',js,css)
wh=hashlib.sha256((dist/'workflow.html').read_bytes()).hexdigest()[:12];ph=hashlib.sha256((dist/'photos.html').read_bytes()).hexdigest()[:12]
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=dist/name;patch(p,'workspace-shell',(root/'scripts/app-shell/workspace-shell.js').read_text(),(root/'scripts/app-shell/workspace-shell.css').read_text());s=p.read_text();s=re.sub(r'workflow\.html\?v=[0-9a-f]+','workflow.html?v='+wh,s);s=re.sub(r'photos\.html\?v=[0-9a-f]+','photos.html?v='+ph,s);p.write_text(s)
print('Patched host and both iframe layouts; cache keys',wh,ph)
