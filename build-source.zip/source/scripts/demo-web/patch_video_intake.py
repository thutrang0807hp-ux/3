from pathlib import Path
import re
r=Path(__file__).resolve().parents[2]
js=(r/'scripts/app-shell/video-intake.js').read_text();css=(r/'scripts/app-shell/video-intake.css').read_text()
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=r/'dist/web-demo'/name;s=p.read_text().replace('allowAutoGemini:options.allowGemini===true}', 'allowAutoGemini:options.allowGemini===true,analysisDeferred:options.deferAnalysis===true}')
 for kind in ['css','js']:s=re.sub(r'<'+('style' if kind=='css' else 'script')+r' id="video-intake-'+kind+r'">[\s\S]*?</'+('style' if kind=='css' else 'script')+'>','',s)
 s=s.replace('</head>','<style id="video-intake-css">'+css+'</style></head>',1).replace('</body>','<script id="video-intake-js">'+js+'</script></body>',1);p.write_text(s)
print('Patched shared source intake into four shell pages')
