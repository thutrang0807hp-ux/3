from pathlib import Path
import re
r=Path(__file__).resolve().parents[2]
js=(r/'scripts/app-shell/recipe-workspace.js').read_text();css=(r/'scripts/app-shell/recipe-workspace.css').read_text()
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=r/'dist/web-demo'/name;s=p.read_text();s=re.sub(r'<style id="recipe-workspace-css">[\s\S]*?</style>','',s);s=re.sub(r'<script id="recipe-workspace-js">[\s\S]*?</script>','',s);s=s.replace('</head>','<style id="recipe-workspace-css">'+css+'</style></head>',1).replace('</body>','<script id="recipe-workspace-js">'+js+'</script></body>',1);p.write_text(s)
print('Patched shared recipe workspace in four shell bundles')
