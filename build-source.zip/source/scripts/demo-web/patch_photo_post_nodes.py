from pathlib import Path
import re,hashlib
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo';p=d/'photos.html';s=p.read_text();s=s.replace('</head>','<style id="photo-post-design-css">'+(r/'scripts/photo-studio/post-design.css').read_text()+'</style></head>',1).replace('</body>','<script id="photo-post-design-js">'+(r/'scripts/photo-studio/post-design.js').read_text()+'</script></body>',1);p.write_text(s)
h=hashlib.sha256(p.read_bytes()).hexdigest()[:12]
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=d/name;s=p.read_text();s=re.sub(r'photos\.html\?v=[0-9a-f]+','photos.html?v='+h,s);p.write_text(s)
print('Applied photo voice/caption/music and handoff design cache keys')
