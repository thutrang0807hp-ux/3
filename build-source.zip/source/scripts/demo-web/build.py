"""Build the current recovered release; legacy builder retained for reference."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name("rebuild_current.py")), run_name="__main__")
