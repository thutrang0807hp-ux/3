from pathlib import Path
import re,hashlib
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo';p=d/'workflow.html';s=p.read_text();s=s.replace('</head>','<style id="media-node-design-css">'+(r/'scripts/workflow/media-nodes.css').read_text()+'</style></head>',1).replace('</body>','<script id="media-node-design-js">'+(r/'scripts/workflow/media-nodes.js').read_text()+'</script></body>',1);p.write_text(s)
h=hashlib.sha256(p.read_bytes()).hexdigest()[:12]
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=d/name;s=p.read_text();s=re.sub(r'workflow\.html\?v=[0-9a-f]+','workflow.html?v='+h,s);p.write_text(s)
print('Applied compact reference frames and video nodes, two-column inspectors')
