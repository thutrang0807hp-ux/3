from pathlib import Path
import re,hashlib
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo'
p=d/'workflow.html';s=p.read_text();js=(r/'scripts/shared/prompt-contract.js').read_text()+'\n'+(r/'scripts/workflow/automatic-analysis.js').read_text()+'\n'+(r/'scripts/workflow/prompt-pipeline.js').read_text();s=s.replace('</body>','<script id="prompt-pipeline">'+js+'</script></body>',1);p.write_text(s)
h=hashlib.sha256(p.read_bytes()).hexdigest()[:12]
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=d/name;p.write_text(re.sub(r'workflow\.html\?v=[0-9a-f]+','workflow.html?v='+h,p.read_text()))
print('Applied reference prompt contract and bounded automatic frame-to-video progression')
