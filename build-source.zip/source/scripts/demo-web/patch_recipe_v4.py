from pathlib import Path
import re
r=Path(__file__).resolve().parents[2];js=(r/'scripts/app-shell/recipe-v4.js').read_text();css=(r/'scripts/app-shell/recipe-v4.css').read_text()
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=r/'dist/web-demo'/name;s=p.read_text()
 for tag,kind in [('style','css'),('script','js'),('script','text')]:s=re.sub(r'<'+tag+' id="recipe-v4-'+kind+r'">[\s\S]*?</'+tag+'>','',s)
 start=s.find('const SFRecipes = (() => {');end=s.find('\n})();',start)
 if start<0 or end<0:raise ValueError('Shared recipes module missing in '+name)
 s=s[:start]+(r/'scripts/shared/recipes.js').read_text().rstrip()+s[end+len('\n})();'):]
 helper=''if 'const SFScript='in s else '<script id="recipe-v4-text">'+(r/'scripts/shared/script-text.js').read_text()+'</script>'
 s=s.replace('</head>','<style id="recipe-v4-css">'+css+'</style></head>',1).replace('</body>',helper+'<script id="recipe-v4-js">'+js+'</script></body>',1);p.write_text(s)
print('Patched V4 script/formula workspace into four shells')
