from pathlib import Path
import re,hashlib
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo';p=d/'photos.html';s=p.read_text();s=s.replace('</head>','<style id="storyboard-modes-css">'+(r/'scripts/photo-studio/storyboard-modes.css').read_text()+'</style></head>',1).replace('</body>','<script id="storyboard-modes-js">'+(r/'scripts/photo-studio/storyboard-modes.js').read_text()+'</script></body>',1);p.write_text(s)
h=hashlib.sha256(p.read_bytes()).hexdigest()[:12]
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=d/name;p.write_text(re.sub(r'photos\.html\?v=[0-9a-f]+','photos.html?v='+h,p.read_text()))
print('Applied optional overview and explicit per-clip storyboard frame inputs')
