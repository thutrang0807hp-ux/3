from pathlib import Path
import re
r=Path(__file__).resolve().parents[2]
js=(r/'scripts/app-shell/batch-image-workspace.js').read_text();css=(r/'scripts/app-shell/batch-image-workspace.css').read_text()
for n in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=r/'dist/web-demo'/n;s=p.read_text();s=re.sub(r'<style id="batch-image-workspace-css">[\s\S]*?</style>','',s);s=re.sub(r'<script id="batch-image-workspace-js">[\s\S]*?</script>','',s);s=s.replace('</head>','<style id="batch-image-workspace-css">'+css+'</style></head>',1).replace('</body>','<script id="batch-image-workspace-js">'+js+'</script></body>',1);p.write_text(s)
print('Patched image-only batch workspace in four shell bundles')
