from pathlib import Path
import re,hashlib
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo'
p=d/'workflow.html';s=p.read_text();s=s.replace('</head>','<style id="reference-node-design">'+(r/'scripts/workflow/node-redesign.css').read_text()+'</style></head>',1).replace('</body>','<script id="reference-node-design-js">'+(r/'scripts/workflow/node-redesign.js').read_text()+'</script></body>',1);p.write_text(s)
h=hashlib.sha256(p.read_bytes()).hexdigest()[:12]
for n in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=d/n;s=p.read_text();s=re.sub(r'<script(?: id="reference-design-bridge")?>if\(window\.SceneForgeApp\?\.recipes\)SceneForgeApp\.recipes\.referenceStatus=[\s\S]*?</script>','',s);s=re.sub(r'workflow\.html\?v=[0-9a-f]+','workflow.html?v='+h,s)
 s=s.replace('</body>','<script id="reference-design-bridge">if(window.SceneForgeApp?.recipes)SceneForgeApp.recipes.referenceStatus=async roomId=>{const lib=await recipeLibrary();return {roomId,...lib.sources?.[roomId]};};if(window.SceneForgeApp)SceneForgeApp.recentPeople=async roomId=>{const found=[],seen=new Set();for(const room of rooms.filter(r=>r.id!==roomId&&!r.trashedAt).slice(-20).reverse()){const w=await workflowRecord(room.id);for(const image of w?.refs?.person?.images||[]){if(found.length>=6)break;if(!image.image||seen.has(image.image))continue;seen.add(image.image);found.push({image:image.image,name:image.name||room.name});}}return found;};</script></body>',1);p.write_text(s)
print('Built reference node design v2: analysis, scenes, references, handoff')
