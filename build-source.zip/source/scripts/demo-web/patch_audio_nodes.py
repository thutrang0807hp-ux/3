from pathlib import Path
import re,hashlib
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo';js=(r/'scripts/shared/audio-nodes.js').read_text();css=(r/'scripts/shared/audio-nodes.css').read_text()
for name in ['workflow.html','photos.html']:
 p=d/name;s=p.read_text()
 for tag,kind in [('script','js'),('style','css')]:s=re.sub(r'<'+tag+' id="audio-nodes-'+kind+r'">[\s\S]*?</'+tag+'>','',s)
 s=s.replace('</head>','<style id="audio-nodes-css">'+css+'</style></head>',1).replace('</body>','<script id="audio-nodes-js">'+js+'</script></body>',1);p.write_text(s)
wh=hashlib.sha256((d/'workflow.html').read_bytes()).hexdigest()[:12];ph=hashlib.sha256((d/'photos.html').read_bytes()).hexdigest()[:12]
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=d/name;s=p.read_text();s=re.sub(r'workflow\.html\?v=[0-9a-f]+','workflow.html?v='+wh,s);s=re.sub(r'photos\.html\?v=[0-9a-f]+','photos.html?v='+ph,s);p.write_text(s)
print('Patched shared voice/music/caption nodes and refreshed both iframe cache keys')
