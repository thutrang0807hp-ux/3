from pathlib import Path
import re
r=Path(__file__).resolve().parents[2];js=(r/'scripts/app-shell/image-concurrency-settings.js').read_text();css=(r/'scripts/app-shell/image-concurrency-settings.css').read_text()
for name in ['index.html','studio.html','storage-demo.html','batch-design-demo.html']:
 p=r/'dist/web-demo'/name;s=p.read_text();s=re.sub(r'<style id="image-concurrency-settings-css">[\s\S]*?</style>','',s);s=re.sub(r'<script id="image-concurrency-settings-js">[\s\S]*?</script>','',s);s=s.replace('</head>','<style id="image-concurrency-settings-css">'+css+'</style></head>',1).replace('</body>','<script id="image-concurrency-settings-js">'+js+'</script></body>',1);p.write_text(s)
print('Patched per-account image settings into four shell bundles')
