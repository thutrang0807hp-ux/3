"""Focused offline view of the real photo merge node/dialog; no provider requests."""
from pathlib import Path
import json
r=Path(__file__).resolve().parents[2];p=r/'artifacts/SceneForge-MoPhong-AnhThanhVideo.html'
s=p.read_text().replace('sceneforge-photo-post-preview-20261027','sceneforge-merge-preview-20261028')
seed="(async()=>{if(!draft.mergePreviewSeeded){draft.voice={mode:'native'};photoProduction().captions=false;photoProduction().musicMode='off';draft.mergePreviewSeeded=true;await save();render();}photoToolbarFocus('handoff');await SFMergeView.open();})()"
boot="<script>(()=>{const t=setInterval(()=>{const w=document.querySelector('#workflowFrame')?.contentWindow;if(!w?.SFMergeView||!w.eval('loaded && !!draft.previewPostSeeded'))return;clearInterval(t);document.querySelector('#shellDialog')?.close();w.eval("+json.dumps(seed)+").catch(e=>console.error(e));},100);})();</script>"
s=s.replace('</body>',boot+'</body>')
out=r/'artifacts/SceneForge-MoPhong-GhepXuat.html';out.write_text(s);out.chmod(0o644);print(out,out.stat().st_size)
