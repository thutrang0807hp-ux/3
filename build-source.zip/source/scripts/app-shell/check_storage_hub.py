from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1100});errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append(r.url));page.goto(f'http://127.0.0.1:{s.server_port}/?demo=1');page.wait_for_function('rooms.length===7');d=page.evaluate('''async()=>{const a=rooms[0],b=rooms[1];jobs=[];a.archived=true;a.archivedAt=Date.now();b.homeTrashedAt=Date.now();b.trashedAt=Date.now();await io('rooms','readwrite',a.id,a);await io('rooms','readwrite',b.id,b);await io('files','readwrite',a.id+':export',new Blob(['KEEP_EXPORT']));await io('files','readwrite',b.id+':source',new Blob(['KEEP_SOURCE']));render();return {a:a.id,b:b.id,p:a.productId};}''')
  page.locator('#archiveProduct').click();expect(page.locator('#storageHub')).to_be_visible();expect(page.locator('#homeTrash')).to_be_hidden();expect(page.locator('[data-hub-row="room:'+d['a']+'"]').first).to_be_visible();expect(page.locator('#storageHub')).to_contain_text('Lưu trữ giữ nguyên tư liệu');assert not page.locator('#archiveView').is_visible()
  page.screenshot(path=str(root/'artifacts/storage-hub-archive.png'),full_page=True)
  # Filter preserves focus while typing and changes rows.
  page.locator('#hubSearch').fill('NONEXISTENT_X');expect(page.locator('.hubRow')).to_have_count(0);page.locator('#hubSearch').fill('');page.locator('[data-hub-pick="room:'+d['a']+'"]').check();expect(page.locator('.hubSelection')).to_contain_text('Đã chọn 1');page.locator('#hubRestoreSelected').click();page.wait_for_function('(id)=>!roomFor(id).archived',arg=d['a']);assert page.evaluate('async id=>(await io("files","readonly",id+":export")).size',d['a'])==11
  page.locator('[data-hub-tab=trash]').click();expect(page.locator('[data-hub-row="room:'+d['b']+'"]')).to_be_visible();expect(page.locator('#storageHub')).to_contain_text('Giữ đến khi bạn xóa hẳn');page.locator('[data-hub-action="room:'+d['b']+'"]').click();expect(page.locator('#storageHub')).to_be_visible();assert page.evaluate('async id=>(await io("files","readonly",id+":source")).size',d['b'])==11
  page.screenshot(path=str(root/'artifacts/storage-hub-trash.png'),full_page=True)
  page.locator('[data-hub-restore="room:'+d['b']+'"]').click();page.wait_for_function('(id)=>!roomFor(id).trashedAt',arg=d['b']);assert page.evaluate('async id=>(await io("files","readonly",id+":source")).size',d['b'])==11
  # Product restore does not resurrect a separately trashed child.
  page.evaluate('''async d=>{const p=productFor(d.p),a=roomFor(d.a),b=roomFor(d.b);p.archived=true;p.trashedAt=Date.now();a.trashedAt=Date.now();a.trashProductId=p.id;b.trashedAt=Date.now();b.trashProductId=p.id;b.homeTrashedAt=Date.now();await io('products','readwrite',p.id,p);await io('rooms','readwrite',a.id,a);await io('rooms','readwrite',b.id,b);render();}''',d)
  page.locator('[data-hub-restore="product:'+d['p']+'"]').click();page.wait_for_function('(id)=>!productFor(id).trashedAt',arg=d['p']);assert page.evaluate('(d)=>!roomFor(d.a).trashedAt&&!!roomFor(d.b).trashedAt',d)
  page.locator('[data-hub-restore="room:'+d['b']+'"]').click();page.wait_for_function('(id)=>!roomFor(id).trashedAt',arg=d['b']);page.reload();page.wait_for_function('rooms.length===7');page.locator('#archiveProduct').click();expect(page.locator('#storageHub')).to_be_visible()
  page.locator('#homeCosts').click();expect(page.locator('#costMonitor')).to_be_visible();expect(page.locator('#storageHub')).to_be_hidden();page.locator('#monitorBack').click();expect(page.locator('#storageHub')).to_be_visible()
  page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(root/'artifacts/storage-hub-mobile.png'),full_page=True);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.locator('#hubBack').click();expect(page.locator('#storageHub')).to_be_hidden();page.locator('#homeMobileProduct').click();expect(page.locator('#homeMobileArchive')).to_contain_text('Lưu trữ & Thùng rác');expect(page.locator('#homeMobileTrash')).to_have_count(0);page.locator('#homeMobileArchive').click();expect(page.locator('#storageHub')).to_be_visible();expect(page.locator('#shellDialog')).not_to_be_visible();assert not errors,errors;assert not any('/local-api/'in c for c in calls),calls
  print('PASS storage hub real IndexedDB restore/product cascade, files preserved, no fake fee/size/expiry, filter selection, managed deletion blocked on web, reload, costs navigation, desktop/mobile and single library entry; zero API calls in demo');b.close()
finally:s.shutdown()
