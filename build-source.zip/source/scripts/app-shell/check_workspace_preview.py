from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
root=Path('/workspace/3/artifacts')
class Q(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Q,directory=str(root)));threading.Thread(target=srv.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url) if r.url.startswith('http') else None)
  page.goto(f'http://127.0.0.1:{srv.server_port}/SceneForge-MoPhong-HaiLuong.html')
  page.wait_for_function('appBootReady&&currentView==="analysis"&&document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.workspaceChrome?.().ready',timeout=45000)
  expect(page.locator('#workspaceSourcePill')).to_be_visible();page.frame_locator('#workflowFrame').locator('[data-ws-tool=map]').click()
  page.locator('[data-workflow-mode=photos]').click();page.wait_for_function('currentRoom?.mode==="photos"&&document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.workspaceChrome?.().ready',timeout=30000)
  expect(page.frame_locator('#workflowFrame').locator('#photoNext')).to_be_visible();page.locator('#workspaceSourcePill').click();expect(page.locator('#workspaceSources')).to_be_visible();page.locator('#workspaceCloseSources').click()
  assert not errors,errors
  assert len(requests)==1,requests
  print('PASS single HTML: auto-open reference, embedded iframe ready, map, photo mode, next action/source popup, zero extra HTTP/API requests; no JS errors.')
  browser.close()
finally:srv.shutdown()
