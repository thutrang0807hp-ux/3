"""Photo post nodes: real browser, media, storage and editor; zero provider jobs."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import subprocess,tempfile,socket,time,os,urllib.request,base64
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-photo-post-')as temp:
 video=Path(temp)/'clip.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=180x320:rate=12:duration=8','-c:v','libx264','-pix_fmt','yuv420p',str(video)],check=True)
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':str(Path(temp)/'data')},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=browser.new_page(viewport={'width':1600,'height':1050});errors=[];jobs=[]
   p.on('pageerror',lambda e:errors.append(e.stack));p.on('request',lambda req:jobs.append(req.url)if req.method=='POST'and any(x in req.url for x in ['/flow/jobs','/muse/jobs','/gemini-chat/jobs','/ai/'])else None)
   p.goto(base);p.wait_for_function('appBootReady&&SceneForgeStorage.state.active');p.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const row={id:'photo-post-test',name:'Kiểm node hậu kỳ',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(row);await persistRoom(row);await openRoom(row.id,'analysis')}''')
   wf=p.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoTransferDraft==="function"')
   wf.evaluate('''async data=>{const file=new File([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],'clip.mp4',{type:'video/mp4'}),key=room.id+':clip';await bridge.putFile(key,file);draft.voice={mode:'native'};draft.beats=Array.from({length:3},(_,i)=>({id:'p'+i,name:'Cảnh '+(i+1),type:'wide',seconds:4,text:'Lời '+i,clips:[]}));draft.beats[1].clips=[{id:'mid-v1',part:'a',key,duration:8,version:1},{id:'mid-v2',part:'a',key,duration:8,version:2}];draft.post={...photoProduction(),captions:true,cues:[{start:0,end:3,text:'Đã sửa riêng',manual:true}],cueSignature:'stale',musicMode:'off'};draft.voice={mode:'file',key:'missing-voice-file',duration:20,name:'Giọng riêng'};draft.handoff={include:{voice:false,music:false,captions:false}};await save();render();}''',base64.b64encode(video.read_bytes()).decode())
   assert wf.locator('[data-node=voice] [data-an=voice]').count()==4
   assert wf.locator('[data-node=captions] .anStyles button').count()==4
   assert wf.locator('[data-node=handoff] .ppToggle').count()==3
   assert wf.evaluate('photoDraftCounts().ready')==1
   snap=wf.evaluate('async()=>{const s=await photoBuildDraftPayload();return{audio:s.payload.audio.length,captions:s.payload.captions.length,volume:s.payload.clipVolume,total:s.total}}');assert snap=={'audio':0,'captions':0,'volume':0,'total':12}
   assert wf.evaluate("draft.voice.key==='missing-voice-file'&&draft.post.cueSignature==='stale'&&draft.post.cues[0].manual")
   wf.evaluate('async()=>{window.testTransferSnapshot=await photoBuildDraftPayload()}');assert wf.evaluate('testTransferSnapshot.payload.clips.some(c=>c.missing)')
   # Flags are part of preview snapshot: no transfer of a revision the user has not seen.
   wf.evaluate('photoHandoffSettings().include.captions=true');reason=wf.evaluate('async()=>{try{await photoTransferDraft(testTransferSnapshot);return null}catch(e){return e.message}}');assert 'đã đổi' in reason
   assert p.evaluate('currentView')=='analysis'
   wf.evaluate('async()=>{photoHandoffSettings().include.captions=false;await photoTransferDraft(await photoBuildDraftPayload())}')
   p.wait_for_function('currentView==="editor"');wf.wait_for_function('!!photoHandoffSettings().transferred',timeout=45000)
   ed=p.locator('#standaloneEditorDemo').element_handle().content_frame();ed.wait_for_function('SceneForgeEditor.getState().items.length===3')
   st=ed.evaluate('SceneForgeEditor.getState()');items=st['items'];assert len([i for i in items if i['kind']=='video'])==1
   assert [(i['start'],i['duration'])for i in items if i['kind']=='video']==[(4,4)]
   assert max(i['start']+i['duration']for i in items)==12 and len([i for i in items if i.get('workflowPlaceholder')])==2
   assert wf.evaluate('draft.beats[1].clips.length')==2
   ed.locator('#prop-x').evaluate("el=>{el.value='23';el.dispatchEvent(new Event('change',{bubbles:true}))}");ed.locator('#prop-scale').evaluate("el=>{el.value='130';el.dispatchEvent(new Event('change',{bubbles:true}))}")
   p.evaluate('async()=>{await showView("analysis")}');p.on('dialog',lambda d:d.accept())
   wf.evaluate('''async()=>{const b=draft.beats[1];b.clips.push({...b.clips.at(-1),id:'mid-v3',version:3});await save();render();}''');wf.evaluate('async()=>photoTransferDraft(await photoBuildDraftPayload(),true)')
   wf.wait_for_function('photoHandoffSettings().transferred.manifest.includes("mid-v3")',timeout=45000)
   st=ed.evaluate('SceneForgeEditor.getState()');item=next(i for i in st['items']if i['kind']=='video');asset=next(a for a in st['assets']if a['id']==item['assetId'])
   assert asset['workflowKey']=='mid-v3' and item['x']==23 and item['scale']==1.3 and item['start']==4 and item['duration']==4
   assert len(st['items'])==3 and wf.evaluate('draft.beats[1].clips.length')==3
   # Tự ghép only imports library assets; keeps existing timeline.
   p.evaluate('async()=>{await showView("analysis")}');wf.evaluate('''async()=>{draft.placement='library';window.lastTransferAt=photoHandoffSettings().transferred.at;await save();render();}''');wf.evaluate('async()=>photoTransferDraft(await photoBuildDraftPayload())');wf.wait_for_function('photoHandoffSettings().transferred.at>lastTransferAt',timeout=45000)
   st2=ed.evaluate('SceneForgeEditor.getState()');assert st2['items']==st['items']
   p.evaluate('async()=>{await showView("analysis")}');wf.evaluate('()=>{view.z=.9;photoToolbarFocus("handoff")}');wf.locator('#photoViewport').screenshot(path=str(r/'artifacts/photo-post-design.png'))
   # First Tự ghép import may place selected subtitles while leaving video clips only in the library.
   wf.evaluate('''async()=>{draft.post.cues=[{start:0,end:2,text:'Phụ đề thư viện',manual:true}];draft.post.cueSignature=photoCueSignature();draft.post.audioChanged=false;delete draft.post.audioCueSignature;draft.post.captions=true;photoHandoffSettings().include.captions=true;await save();}''')
   p.evaluate('''async()=>{await flushFrames();const old=roomFor('photo-post-test'),row={...structuredClone(old),id:'photo-library-fresh',name:'Tự ghép mới',editorInitialized:false,stage:'review'};delete row.photoDraft.handoff.transferred;rooms.push(row);await persistRoom(row);await openRoom(row.id,'analysis')}''')
   wf=p.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoTransferDraft==="function"');wf.evaluate('async()=>photoTransferDraft(await photoBuildDraftPayload())');wf.wait_for_function('!!photoHandoffSettings().transferred',timeout=45000)
   ed=p.locator('#standaloneEditorDemo').element_handle().content_frame();ed.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.kind==="text")')
   fresh=ed.evaluate('SceneForgeEditor.getState()');assert not any(i['kind']=='video'for i in fresh['items']);assert any(i['kind']=='text'and i['text']=='Phụ đề thư viện'for i in fresh['items'])
   assert not errors,errors;assert not jobs,jobs
   print('PASS photo shared voice/caption UI; source-safe include switches; stale-preview guard; real sparse 12s editor timeline; no cleanup on partial/library transfer; replacement preserves manual transform and gaps; library append preserves timeline; zero provider generation.')
   browser.close()
 finally:proc.terminate();proc.wait(timeout=15)
