from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
r=Path('/workspace/3')
class Q(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Q,directory=str(r/'dist/web-demo')));threading.Thread(target=srv.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();page.goto(f'http://127.0.0.1:{srv.server_port}/?demo=1');page.wait_for_function('appBootReady')
  before=page.evaluate('JSON.stringify({rooms,jobs,batch:batchState})');page.evaluate("fail(Error('Đợi công việc và đóng phòng đang mở trước khi dọn lượt.'))");expect(page.locator('#homeError')).to_be_visible();page.get_by_role('button',name='Đóng thông báo lỗi').click();expect(page.locator('#homeError')).to_be_hidden();assert page.evaluate('JSON.stringify({rooms,jobs,batch:batchState})')==before
  page.evaluate("fail(Error('<script>danger</script>'))");expect(page.locator('#homeError')).to_contain_text('<script>danger</script>');assert page.locator('#homeError script').count()==0;expect(page.locator('#dismissHomeError')).to_be_visible();b.close();print('PASS dismiss hides/clears only error; rooms/jobs/batch unchanged; subsequent errors visible and HTML escaped. Cleanup guard unchanged.')
finally:srv.shutdown()
