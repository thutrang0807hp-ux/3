"""Actual batch UI, intercepted ChatGPT results: multiple originals, no extra sends."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,io,zipfile,json
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-batch-groups-')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  raws=[]
  for color in ['red','green','blue','yellow']:
   b=io.BytesIO();Image.new('RGB',(256,256),color).save(b,format='PNG');raws.append(b.getvalue())
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});posts=[];errors=[];records={};page.on('pageerror',lambda e:errors.append(str(e)))
   def route(r):
    req=r.request;path=req.url.split('/local-api/web-images/')[1]
    if path.endswith('/status'):return r.fulfill(json={'configured':True,'installed':True,'selection':{'available':True,'mode':'selected','token':'fixture-choice','account_id':'A','account_name':'Fixture A'},'accounts':[]})
    if req.method=='POST':
     body=req.post_data_json;posts.append(body);rid=body['request_id'];records[rid]={'request_id':rid,'state':'done','conversation_url':'https://chatgpt.com/c/fixture','result':{'model':'fixture-image','account_id':'A','images':[{'file':rid+str(i)+'.png'}for i in range(4)]}};return r.fulfill(json={'request_id':rid,'state':'submitted'})
    if path.startswith('files/'):
     index=int(req.url.split('index=')[1]);return r.fulfill(body=raws[index],content_type='image/png')
    return r.fulfill(json=records[path.split('/')[-1]])
   page.route('**/local-api/web-images/**',route);page.goto(base+'/#batch');page.wait_for_function('!!SceneForgeApp.batch.getState()');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}''')
   page.locator('#batchEngine').select_option('chatgpt');page.locator('#batchPrompts').fill('Một ảnh sản phẩm');page.locator('#batchEnqueue').click();page.locator('#batchRun').click();page.locator('#batchConfirmSend').click();page.wait_for_function('batchState.jobs.length===1&&batchState.jobs[0].status==="done"')
   assert len(posts)==1;assert page.evaluate('batchState.jobs[0].resultImages.length')==4;page.locator('[data-batch-select]').click();expect(page.locator('[data-batch-output]')).to_have_count(4);expect(page.get_by_role('link',name='Mở hội thoại để kiểm tra kết quả ↗')).to_have_attribute('href','https://chatgpt.com/c/fixture')
   page.locator('[data-batch-output][data-index="2"]').click();assert page.evaluate('batchState.jobs[0].selectedImage')==2
   with page.expect_download()as download:page.locator('[data-batch-download]').click()
   assert Path(download.value.path()).read_bytes()==raws[2]
   page.locator('#shellDialog').evaluate('(d)=>d.close()')
   with page.expect_download()as download:page.locator('[data-batch-group-download]').click()
   with zipfile.ZipFile(download.value.path())as z:
    images=[z.read(n)for n in z.namelist()if n.endswith('.png')];assert images==raws
   page.reload();page.wait_for_function('batchState?.jobs[0]?.selectedImage===2');assert page.evaluate('batchState.jobs[0].resultImages.length')==4
   page.locator('[data-batch-select]').click();page.locator('[data-batch-recover]').click();page.wait_for_function('batchState.jobs[0].status==="done"');assert len(posts)==1;assert page.evaluate('batchState.jobs[0].versions.length')==4
   page.locator('#shellDialog').evaluate('(d)=>d.close()');page.locator('[data-batch-regenerate]').click();assert page.evaluate('batchState.jobs.length')==2;assert page.evaluate('batchState.jobs[1].resultImages===undefined&&batchState.jobs[1].requestId===undefined');page.locator('#batchRun').click();expect(page.locator('#batchConfirmSend')).to_have_text('Gửi 1 yêu cầu');page.locator('#batchConfirmNo').click();assert len(posts)==1
   assert not errors,errors;page.screenshot(path=str(root/'artifacts/chat-reliability-batch.png'),full_page=True);browser.close()
  print('PASS one submitted prompt -> four saved originals in one result, select third/single download, ZIP has all four, reload preserves selection, recovery deduplicates, regenerate queues ONE fresh job with no old result payload; safe conversation link. Provider fixture, no AI calls.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
