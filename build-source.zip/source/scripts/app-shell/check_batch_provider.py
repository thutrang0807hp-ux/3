"""Browser provider bridge with mocked service responses, never a paid request."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,json,io
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-batch-api-',dir='/tmp')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  image=io.BytesIO();Image.new('RGB',(90,160),'#bd5275').save(image,format='PNG');raw=image.getvalue();ref=Path(temp)/'reference.png';ref.write_bytes(raw)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];posts=[];states={};page.on('pageerror',lambda e:errors.append(str(e)))
   def route(r):
    request=r.request;path=request.url.split('/local-api/batch/images')[1]
    if path=='/models':return r.fulfill(json={'configured':True,'models':['gemini-fixture-image']})
    if request.method=='POST':
     payload=request.post_data_json;posts.append(payload);states[payload['request_id']]=True;return r.fulfill(json={'request_id':payload['request_id'],'state':'submitted'})
    if path.endswith('/file'):return r.fulfill(body=raw,content_type='image/png')
    return r.fulfill(json={'state':'done','result':{'model':'gemini-fixture-image','origin':'gemini','cost':None}})
   page.route('**/local-api/batch/images**',route)
   page.goto(base+'/#batch');page.wait_for_function('!!SceneForgeApp.batch.getState()');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}''');page.locator('#batchReferenceFiles').set_input_files(ref);expect(page.locator('[data-batch-ref]')).to_have_count(1)
   page.locator('#batchEngine').select_option('gemini');page.locator('#batchCheckModels').click();expect(page.locator('#batchImageModel')).to_have_value('gemini-fixture-image');assert not posts
   page.locator('#batchPrompts').fill('Cận cảnh sản phẩm\nGóc nghiêng');page.locator('#batchEnqueue').click();page.wait_for_function('batchState.jobs.length===2');page.locator('[data-image-resume]').click();expect(page.locator('#batchConfirmSend')).to_be_visible();assert not posts;page.locator('#batchConfirmNo').click();assert not posts
   page.locator('[data-image-resume]').click();page.evaluate('()=>{window.batchSavedFlush=SceneForgeStorage.flush;SceneForgeStorage.flush=async()=>{throw Error("CHECKPOINT_TEST_BLOCKED");};}');page.locator('#batchConfirmSend').click();expect(page.locator('#batchConfirmError')).to_contain_text('CHECKPOINT_TEST_BLOCKED');assert not posts;assert page.evaluate('batchState.paused&&batchState.jobs.every(j=>!j.confirmedSend)');page.evaluate('()=>{SceneForgeStorage.flush=window.batchSavedFlush;}');page.locator('#batchConfirmSend').click();page.wait_for_function('batchState.jobs.every(j=>j.status==="done")',timeout=15000);assert page.evaluate('batchState.jobs.every(j=>j.requestId==="batch-image-"+j.id)');snapshot=page.evaluate('SceneForgeStorage.api("snapshot")');saved=next(r['value']for r in snapshot['records']if r['key']=='batch-studio-v1');assert all(j.get('requestId')=='batch-image-'+j['id']for j in saved['jobs']);assert len(posts)==2;assert all(x['confirm_send']is True and len(x['references'])==1 for x in posts);assert page.evaluate('batchState.jobs.every(j=>j.origin==="gemini"&&j.versions.length===1)');page.locator('[data-batch-select]').first.click();expect(page.locator('[data-batch-save-image]')).to_be_visible();expect(page.locator('[data-batch-send-workflow]')).to_be_visible();page.locator('[data-batch-recover]').click();page.wait_for_timeout(300);assert len(posts)==2;assert page.evaluate('batchState.jobs[0].versions.length')==1
   page.locator('#shellDialog').evaluate('(d)=>d.close()');page.evaluate('''async()=>{batchState.jobs[0].status='running';await batchPersist();await SceneForgeStorage.flush();}''');page.reload();page.wait_for_function('batchState?.jobs[0].status==="interrupted"');assert len(posts)==2;page.locator('[data-batch-select]').first.click();page.locator('[data-batch-recover]').click();page.wait_for_function('batchState.jobs[0].status==="done"');assert len(posts)==2;assert page.evaluate('batchState.jobs[0].versions.length')==1
   assert not errors,errors;browser.close();print('PASS local browser bridge: no send before confirmation, cancel confirmation sends zero, references/model/real-origin retained, download recovery does not resubmit, interrupted reload recovers without new generation. API fixtures only.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
