"""Actual local app/SQLite/FFmpeg; fixture TTS bytes, no online AI."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import os,socket,subprocess,tempfile,time,urllib.request,json,io,wave,math,array
r=Path(__file__).resolve().parents[2]
def audio(seconds):
 out=io.BytesIO();data=array.array('h',(int(6000*math.sin(2*math.pi*330*i/24000))for i in range(int(seconds*24000))))
 with wave.open(out,'wb')as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(24000);f.writeframes(data.tobytes())
 return out.getvalue()
with tempfile.TemporaryDirectory(prefix='sf-audio-nodes-')as tmp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 log=open(Path(tmp)/'server.log','w');proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp},stdout=log,stderr=log);base=f'http://127.0.0.1:{port}/'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=b.new_context(accept_downloads=True,viewport={'width':1600,'height':1050});page=ctx.new_page();errors=[];cloud=[]
   page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:cloud.append(q.url)if q.method=='POST'and any(x in q.url for x in ['/ai/','/flow/jobs','/muse/jobs','/gemini-chat/jobs','/web-images/jobs'])else None)
   page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active');page.evaluate(r'''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();await putRecipe({id:'audio-test',kind:'script',name:'Kiểm âm thanh',body:'[Cảnh 1]\nLời đầu tiên.\n\n[Cảnh 2]\nLời tiếp theo.',beats:[],source:'manual'});await g6OpenRecipes();kv.selected='audio-test';await kvDraw();}''')
   page.locator('[data-v4=use-script]').click();page.locator('[data-choose-product]').first.click();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SFAudioNodes?.getState().mode==="native"');f=page.frame_locator('#workflowFrame')
   expect(f.locator('[data-node=voice] [data-an=voice]')).to_have_count(4);f.locator('[data-node=voice] [data-an=voice][data-id=ai]').click();expect(f.locator('[data-node=voice]')).to_contain_text('Chưa có giọng AI');assert f.locator('[data-an=generate]').count()==0
   page.route('**/local-api/tts/status',lambda route:route.fulfill(json={'model_ready':True,'voices':[{'id':'voice-real-id','label':'Giọng đã cài'}]}))
   f.locator('body').evaluate('()=>SFAudioNodes.refresh()');expect(f.locator('[data-an=preset]')).to_have_text('Giọng đã cài')
   tts=[]
   def synth(route):
    data=route.request.post_data_json;tts.append(data);n=len(data['beats']);route.fulfill(json={'url':'/fixture-voice.wav','duration':2,'request_id':'tts-fixture','segments':[{'id':row['id'],'start':i*2/n,'end':(i+1)*2/n}for i,row in enumerate(data['beats'])]})
   page.route('**/local-api/tts',synth);page.route('**/fixture-voice.wav',lambda route:route.fulfill(content_type='audio/wav',body=audio(2)))
   f.locator('[data-an=generate]').click();expect(f.locator('[data-an=play-voice]')).to_be_visible(timeout=20000);assert len(tts)==1 and tts[0]['voice']=='voice-real-id'
   f.locator('[data-an-field=speed]').fill('1.25');f.locator('[data-an-field=speed]').dispatch_event('change');expect(f.locator('[data-an=tempo]')).to_be_visible();f.locator('[data-an=tempo]').click();f.locator('body').evaluate('()=>new Promise(resolve=>{const t=setInterval(()=>{if(!SFAudioNodes.getState().busy){clearInterval(t);resolve();}},40);})');assert abs(f.locator('body').evaluate('()=>draft.voice.duration')-1.6)<.1
   f.locator('[data-an-field=captions]').check();f.locator('[data-node=captions] details>summary').click();f.locator('[data-an=caption-audio]').click();expect(f.locator('#anApplySpeech')).to_be_visible();f.locator('#anApplySpeech').click();expect(f.locator('[data-node=captions]')).to_contain_text('mốc VieNeu thật')
   f.locator('[data-an=caption-style][data-id=yellowbox]').click();f.locator('[data-an=caption-y][data-id="20"]').first.click()
   f.locator('[data-an=caption-edit]').click();f.locator('[data-an-cue="0"][data-field=text]').fill('Câu đã sửa tay.');f.locator('#anSaveCues').click();expect(f.locator('[data-node=captions]')).to_contain_text('đã sửa')
   page.once('dialog',lambda d:d.dismiss());f.locator('[data-node=captions] details>summary').click();f.locator('[data-an=caption-reset]').click();assert f.locator('body').evaluate('()=>draft.post.cues[0].text')=='Câu đã sửa tay.'
   with page.expect_download()as pending:f.locator('[data-node=captions] details>summary').click();f.locator('[data-an=caption-srt]').click()
   assert 'Câu đã sửa tay.'in Path(pending.value.path()).read_text()
   f.locator('[data-an=music-mode][data-id=selected]').click();f.locator('#photoMusicFiles').set_input_files([{'name':'Bài A.wav','mimeType':'audio/wav','buffer':audio(2)},{'name':'Bài B.wav','mimeType':'audio/wav','buffer':audio(3)}]);f.locator('body').evaluate('()=>new Promise(resolve=>{const t=setInterval(()=>{if(draft.post.music.length===2){clearInterval(t);resolve();}},40);})')
   f.locator('[data-an=music-mode][data-id=random]').click();choice=f.locator('body').evaluate('()=>photoProductionState().musicChoice');f.locator('body').evaluate('()=>render()');assert f.locator('body').evaluate('()=>photoProductionState().musicChoice')==choice
   f.locator('[data-an=music-random]').click();assert f.locator('body').evaluate('()=>photoProductionState().musicChoice')!=choice
   f.locator('[data-an-field=musicDuck]').check();f.locator('body').evaluate('()=>new Promise(resolve=>{const t=setInterval(()=>{if(!SFAudioNodes.getState().busy){clearInterval(t);resolve();}},40);})')
   payload=f.locator('body').evaluate('async()=>{const r=await photoBuildDraftPayload();return{audio:r.payload.audio.map(a=>({role:a.role,key:a.key,name:a.name,bytes:a.file.size})),style:r.payload.captionStyle,y:r.payload.captionOptions.textY,mute:r.payload.muteClipSound}}');assert len(payload['audio'])==2 and payload['style']=='yellowbox'and payload['y']==20 and payload['mute'],payload
   music=next(a for a in payload['audio']if a['role']=='music');assert 'hạ theo giọng'in music['name']and music['bytes']>100000,payload
   f.locator('#anVoiceFile').set_input_files({'name':'Giọng nhập.wav','mimeType':'audio/wav','buffer':audio(1)});expect(f.locator('[data-node=captions]')).to_contain_text('cần rà lại',timeout=15000);assert f.locator('body').evaluate('()=>draft.post.cues[0].text')=='Câu đã sửa tay.'
   assert not cloud,cloud;assert not errors,errors;page.screenshot(path=str(r/'artifacts/audio-nodes-photo.png'),full_page=True)
   # Open a reference room through the actual host integration and test the same controls.
   page.evaluate(r'''async()=>{await flushFrames();const p=products.find(p=>!p.trashedAt);const room={id:uid(),name:'Mẫu kiểm audio',productId:p.id,mode:'reference',stage:'review',refs:clone(p.refs),createdAt:Date.now(),sceneStates:[]};rooms.push(room);await persistRoom(room);await openRoom(room.id,'analysis');}''');page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SFAudioNodes?.getState().mode==="native"');f=page.frame_locator('#workflowFrame');expect(f.locator('#node-voice-over [data-an=voice]')).to_have_count(4)
   f.locator('[data-an=voice][data-id=file]').click();f.locator('#anVoiceFile').set_input_files({'name':'Giọng mẫu.wav','mimeType':'audio/wav','buffer':audio(1)});expect(f.locator('[data-an=play-voice]')).to_be_visible();f.locator('[data-an=voice][data-id=none]').click();assert f.locator('body').evaluate('()=>voiceOverDraft().mode')=='muted'
   assert not cloud,cloud;assert not errors,errors;b.close();print('PASS both audio-node UIs on real local app: four sources, honest missing model, fixture TTS/preset, real FFmpeg tempo/duck payload, actual TTS caption times, manual edit protected + SRT download, stable random song, imported voice marks cues stale without deleting them, mute mode, no image/video generation.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill()
