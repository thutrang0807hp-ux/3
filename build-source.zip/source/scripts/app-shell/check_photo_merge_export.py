"""Photo post nodes: real browser, media, storage and editor; zero provider jobs."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import subprocess,tempfile,socket,time,os,urllib.request,base64
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-photo-post-')as temp:
 video=Path(temp)/'clip.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=180x320:rate=12:duration=8','-c:v','libx264','-pix_fmt','yuv420p',str(video)],check=True)
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':str(Path(temp)/'data')},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=browser.new_page(viewport={'width':1600,'height':1050});errors=[];jobs=[]
   p.on('pageerror',lambda e:errors.append(e.stack));p.on('request',lambda req:jobs.append(req.url)if req.method=='POST'and any(x in req.url for x in ['/flow/jobs','/muse/jobs','/gemini-chat/jobs','/ai/'])else None)
   p.goto(base);p.wait_for_function('appBootReady&&SceneForgeStorage.state.active');p.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const row={id:'photo-post-test',name:'Kiểm node hậu kỳ',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(row);await persistRoom(row);await openRoom(row.id,'analysis')}''')
   wf=p.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoTransferDraft==="function"')
   wf.evaluate('''async data=>{const file=new File([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],'clip.mp4',{type:'video/mp4'}),key=room.id+':clip';await bridge.putFile(key,file);draft.voice={mode:'native'};draft.beats=Array.from({length:12},(_,i)=>({id:'m'+i,name:'Cảnh '+(i+1),type:'wide',seconds:1,text:'Lời '+i,clips:[{id:'clip'+i,part:'a',key,duration:8,version:1}]}));draft.post={...photoProduction(),captions:false,musicMode:'off'};draft.handoff={include:{voice:true,music:false,captions:false}};await save();render();fit();}''',base64.b64encode(video.read_bytes()).decode())
   wf.wait_for_function('!!window.SFMergeView')
   assert wf.locator('[data-node=director]').count()==0
   assert wf.locator('[data-node=handoff]').count()==1
   assert wf.locator('[data-node=handoff] .mxTile').count()==7
   expect(wf.locator('.mxMore')).to_contain_text('+5')
   wf.locator('.mxMore').evaluate('b=>b.click()');wf.locator('#mergeDialog').wait_for(state='visible');expect(wf.locator('#mergeDialog .mxTile')).to_have_count(12)
   wf.locator('#mergeDialog .mxPlayerControls button').click();wf.wait_for_function('SFMergeView.getSession().time>.2')
   wf.locator('#mergeDialog [data-mx=close]').click();expect(wf.locator('#mergeDialog')).to_be_hidden();assert wf.locator('#mxMiniPlayer video').count()==1;assert wf.evaluate('SFMergeView.getSession().playing') is False
   before=wf.evaluate('JSON.stringify(draft.beats.map(b=>b.id))');wf.evaluate('async()=>SFMergeView.reorder(SFMergeView.rows().map(r=>r.id).reverse())');assert wf.evaluate('JSON.stringify(draft.beats.map(b=>b.id))')==before
   snap=wf.evaluate('async()=>{const s=await photoBuildDraftPayload();return{first:s.payload.clips[0].sceneId,last:s.payload.clips.at(-1).sceneId,total:s.total}}');assert snap=={'first':'m11','last':'m0','total':12}
   wf.locator('.mxMore').evaluate('b=>b.click()');wf.locator('#mergeDialog').wait_for(state='visible');wf.locator('#mergeDialog .mxTileMenu').first.click();wf.locator('#mxSlotMenu [data-mx=hide]').click();wf.wait_for_function('draft.mergeView.hidden.length===1');assert wf.evaluate('async()=>(await photoBuildDraftPayload()).total')==11
   wf.locator('#mergeDialog [data-mx=restore]').click();wf.wait_for_function('draft.mergeView.hidden.length===0');wf.locator('#mergeDialog [data-mx=close]').click()
   # Source missing is explicit and blocks export; users may deliberately hide that slot.
   wf.evaluate('''async()=>{draft.beats[0].clips=[];await save();render();}''');assert wf.locator('[data-node=handoff] [data-mx=export]').is_disabled()
   # Keep a two-second final draft. Missing m0 is excluded explicitly; no old media is deleted.
   wf.evaluate('''async()=>{draft.mergeView.hidden=SFMergeView.rows().filter(r=>!['m1:a','m2:a'].includes(r.id)).map(r=>r.id);await save();render();}''')
   wf.locator('[data-node=handoff] [data-mx=expand]').evaluate('b=>b.click()');wf.locator('#mergeDialog').wait_for(state='visible')
   # Add a real voice file whose per-second pitch proves reordered source intervals.
   import wave,math,struct
   audio=Path(temp)/'voice.wav'
   with wave.open(str(audio),'wb') as wav:
    wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(16000);wav.writeframes(b''.join(struct.pack('<h',int(6000*math.sin(2*math.pi*(200+50*(i//16000))*i/16000)))for i in range(12*16000)))
   wf.locator('#mergeDialog [data-mx=close]').click()
   wf.evaluate('''async data=>{const file=new File([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],'voice.wav',{type:'audio/wav'});await bridge.putFile('merge-voice',file);draft.voice={mode:'file',key:'merge-voice',name:'Giọng kiểm',duration:12};draft.post.captions=true;draft.post.cues=[{start:2.1,end:2.8,text:'Đoạn ba',manual:true}];draft.post.cueSignature=photoCueSignature();draft.post.audioChanged=false;delete draft.post.audioCueSignature;draft.handoff.include.captions=true;await save();render();}''',base64.b64encode(audio.read_bytes()).decode())
   mix=wf.evaluate('async()=>{const s=await photoBuildDraftPayload();return {audio:s.payload.audio.map(a=>[a.start,a.sourceIn,a.duration]),cues:s.payload.captions.map(c=>[c.start,c.end,c.text])}}');assert mix['audio']==[[0,2,1],[1,1,1]];assert abs(mix['cues'][0][0]-.1)<.001 and abs(mix['cues'][0][1]-.8)<.001
   wf.evaluate('async()=>SFMergeView.open()')
   oldclips=wf.evaluate('draft.beats[1].clips.length');p.on('dialog',lambda d:d.dismiss())
   with p.expect_download(timeout=120000) as dl:
    wf.locator('#mergeDialog [data-mx=export]').click()
   download=dl.value;target=Path(temp)/'merged.mp4';download.save_as(target)
   info=__import__('json').loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(target)]));stream=next(x for x in info['streams']if x['codec_type']=='video');assert(stream['width'],stream['height'],stream['codec_name'])==(1080,1920,'h264');assert abs(float(info['format']['duration'])-2)<.15
   samples=subprocess.check_output(['ffmpeg','-v','error','-i',str(target),'-vn','-ar','16000','-ac','1','-f','s16le','-']);values=struct.unpack('<'+'h'*(len(samples)//2),samples)
   for start,wanted in [(0.2,300),(1.2,250)]:
    chunk=values[int(start*16000):int((start+.5)*16000)];freq=sum(1 for a,b in zip(chunk,chunk[1:])if a<0<=b)*2;assert abs(freq-wanted)<8,(freq,wanted)
   assert wf.evaluate('draft.beats[1].clips.length')==oldclips
   p.wait_for_function('rooms.find(r=>r.id==="photo-post-test").stage==="exported"')
   assert wf.locator('#mergeDialog [data-mx=download]').count()==1
   wf.locator('#mergeDialog').screenshot(path=str(r/'artifacts/photo-merge-expanded.png'))
   # Editor import receives the same source intervals, durations and caption timing.
   wf.locator('#mergeDialog [data-mx=editor]').click();p.wait_for_function('currentView==="editor"');ed=p.locator('#standaloneEditorDemo').element_handle().content_frame();ed.wait_for_function('SceneForgeEditor.getState().items.filter(i=>i.kind==="audio").length===2');audio_items=ed.evaluate('SceneForgeEditor.getState().items.filter(i=>i.kind==="audio").map(i=>[i.start,i.mediaIn,i.duration])');assert audio_items==[[0,2,1],[1,1,1]],audio_items
   assert not errors,errors;assert not jobs,jobs
   print('PASS one merge node, two-row +5 view, shared expanded player and close, reorder preserves authored beats, explicit hide/restore and missing block, voice source intervals and captions follow reorder, decoded exported pitches 300Hz/250Hz match preview snapshot; real FFmpeg 1080x1920 H264 MP4 2s saved to room, no cleanup before successful save, no provider jobs')
   browser.close()
 finally:
  proc.terminate();proc.wait(timeout=10)
