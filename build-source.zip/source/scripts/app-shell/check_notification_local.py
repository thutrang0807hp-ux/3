"""Notification read/delete persists to the real library; navigation only is spied."""
from pathlib import Path
import os,socket,subprocess,sys,tempfile,time,urllib.request
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
checkpoint_js='''async()=>{for(let i=0;i<8;i++){try{return await SceneForgeStorage.flush();}catch(e){if(!e.message.includes('Dữ liệu đang thay đổi')||i===7)throw e;await new Promise(r=>setTimeout(r,100));}}}'''
with tempfile.TemporaryDirectory(prefix='sf-notice-local-')as tmp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=b.new_context();page=ctx.new_page();page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active');d=page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();$('#shellDialog').close();const p=products[0],r={id:uid(),productId:p.id,name:'Local notice fixture',stage:'editing',mode:'photos',refs:clone(p.refs),pendingFrames:3,updatedAt:Date.now()-1000},n={id:uid(),roomId:r.id,roomIds:[r.id],text:'Local notice fixture · 3 khung chờ duyệt',kind:'frames',level:'attention',read:false,count:1,at:Date.now()};rooms.push(r);notifications.unshift(n);await io('rooms','readwrite',r.id,r);await io('notifications','readwrite',n.id,n);await io('files','readwrite',r.id+':source',new Blob(['KEEP_SOURCE_BYTES']));openRoom=async()=>{};renderNotifications();return {room:r.id,notice:n.id};}''');page.evaluate(checkpoint_js);page.locator('#openNotifications').click();page.locator('[data-notice-open="'+d['notice']+'"]').click();page.wait_for_function('(id)=>notifications.find(n=>n.id===id).read',arg=d['notice']);page.evaluate(checkpoint_js);snap=page.evaluate('SceneForgeStorage.api("snapshot")');assert next(row['value']for row in snap['records']if row['store']=='notifications'and row['key']==d['notice'])['read'];ctx.close();ctx=b.new_context();page=ctx.new_page();page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active');assert page.evaluate('(id)=>notifications.find(n=>n.id===id).read',d['notice']);page.locator('#openNotifications').click();page.locator('[data-notice-delete="'+d['notice']+'"]').click();page.wait_for_function('(id)=>!notifications.some(n=>n.id===id)',arg=d['notice']);page.evaluate(checkpoint_js);snap=page.evaluate('SceneForgeStorage.api("snapshot")');assert not any(row['store']=='notifications'and row['key']==d['notice']for row in snap['records']);assert any(row['store']=='rooms'and row['key']==d['room']for row in snap['records']);assert page.evaluate('async id=>(await io("files","readonly",id+":source")).size',d['room'])==17;print('PASS real SQLite: read via row persists across fresh browser profile, deleting seen notice persists, project/source bytes remain intact; no provider generation.');ctx.close();b.close()
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
