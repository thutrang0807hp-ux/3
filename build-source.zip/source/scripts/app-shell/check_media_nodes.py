"""Real Chromium, local storage and media; deterministic provider transport only."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from PIL import Image,ImageDraw
import subprocess,socket,tempfile,time,urllib.request,os,io,base64
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-media-nodes-')as temp:
 image=Image.new('RGB',(1080,1920),'#d2baa0');draw=ImageDraw.Draw(image)
 for x in range(0,1080,40):draw.line((x,0,1080-x,1920),fill='#102840',width=3)
 buf=io.BytesIO();image.save(buf,format='PNG');png=buf.getvalue();video=Path(temp)/'clip.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=180x320:rate=12:duration=8','-c:v','libx264','-pix_fmt','yuv420p',str(video)],check=True)
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':str(Path(temp)/'data')},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=browser.new_page(viewport={'width':1600,'height':1050});errors=[];posts=[];jobs={}
   p.on('pageerror',lambda e:errors.append(str(e)));p.on('dialog',lambda d:d.accept())
   status={'account_binding':True,'models':['fixture-portrait'],'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'one-account'}}
   for service in ['flow','gemini-chat','muse']:
    p.route('**/local-api/'+service+'/status',lambda route:route.fulfill(json=status))
    def send(route):
     data=route.request.post_data_json;posts.append(data);jobs[data['request_id']]={'state':'done','result':{'mime_type':'image/png'if data['kind']=='image'else'video/mp4','account_id':'Fixture'}};route.fulfill(json={'state':'submitted'})
    p.route('**/local-api/'+service+'/jobs',send)
    p.route('**/local-api/'+service+'/jobs/*',lambda route:route.fulfill(json=jobs.get(route.request.url.rsplit('/',1)[-1],{'state':'unknown'})))
    p.route('**/local-api/'+service+'/files/*',lambda route:route.fulfill(body=png if '/gemini-chat/'in route.request.url else video.read_bytes(),content_type='image/png'if'/gemini-chat/'in route.request.url else'video/mp4'))
   p.goto(base);p.goto(base+'workflow.html?room=media-node-test');p.wait_for_function('!!window.SceneForgeWorkflow&&!!window.SFMediaNodes')
   p.evaluate('''async data=>{project=blankProject();project.id='media-node-test';project.source={asset:'demo',duration:36,poster:data.image};project.scenes=[sceneRecord(0,4,0,[data.image]),sceneRecord(4,8,1,[data.image]),sceneRecord(8,20,2,[data.image]),...Array.from({length:4},(_,i)=>sceneRecord(20+i*4,24+i*4,3+i,[data.image]))];for(const s of project.scenes){s.approvedFrame='source';s.hasPerson=false;s.refsUsed=[];s.promptFrame.en='Reference composition';}const blob=await(await fetch(data.image)).blob();await addFrame(new File([blob],'original.png',{type:'image/png'}),project.scenes[0].id);project.refs.person.images=[{id:'person-test',name:'Người mẫu (A)',image:data.image}];project.scenes[0].refsUsed=['person'];const b=new File([Uint8Array.from(atob(data.video),c=>c.charCodeAt(0))],'video.mp4',{type:'video/mp4'});assets.set('fixture-video',b);const s=project.scenes[2];s.clipPlan={start:s.start,end:s.end,parts:structuredClone(clipParts(s))};const part=clipParts(s)[1];s.clips=[{id:'part-b',part:part.id,asset:'fixture-video',duration:8,version:1,prompt:makePrompt(s,part),frameId:'source',reviewDecision:{status:'accepted'}}];s.receivedClipIds=['part-b'];project.cloudJobs=[{id:'old-failed',provider:'flow',kind:'video',sceneId:s.id,part:clipParts(s)[0].id,state:'failed',error:'Nguồn trả lỗi tạo'},{id:'unknown-last',provider:'flow',kind:'video',sceneId:project.scenes[6].id,part:'a',state:'unknown',error:'Chưa rõ kết quả'}];await storeProject();render();}''',{'image':'data:image/png;base64,'+base64.b64encode(png).decode(),'video':base64.b64encode(video.read_bytes()).decode()})
   assert p.locator('#node-videos .mnGrid.compact').count()==1
   assert p.locator('#node-videos .mnSceneGroup.split').count()==1
   assert p.locator('#node-frames .g6Counts,#node-videos [data-clip-planning]').count()==0
   p.locator('[data-mn=filter][data-id=review]').evaluate('b=>b.click()');assert p.locator('#node-videos .mnTile.mn-approved').count()==0
   p.evaluate("SFMediaNodes.open('frame',project.scenes[0].id)")
   assert p.locator('.mniLayout').count()==1 and p.locator('#modal [data-frame-model]').count()==0
   p.locator('#mnCompare').fill('70');assert p.locator('.mniCompare').evaluate('n=>n.style.getPropertyValue("--split")')=='70%'
   prompt='Người mẫu (A) giữ bố cục. Chỉ đổi sản phẩm theo ảnh tham chiếu. Không thêm vật khác.'
   p.locator('#mnCompare').focus();p.keyboard.down('Space');assert p.locator('.mniCompare').evaluate('e=>e.classList.contains("originalOnly")');p.keyboard.up('Space')
   p.locator('#mnPrompt').fill(prompt);assert p.locator('#mnPaint mark').count()>0;assert p.evaluate('project.scenes[0].framePromptOverride')==prompt
   p.locator('[data-mn=regenerate]').click();p.locator('#directPrepare').click();p.locator('#directSend').wait_for();assert not posts
   p.locator('#directSend').click();p.wait_for_function('project.cloudJobs.at(-1).state==="submitted"');assert len(posts)==1 and posts[0]['prompt']==prompt and posts[0]['kind']=='image'
   p.evaluate('directRecover()');p.wait_for_function('project.scenes[0].frames.length===2')
   p.evaluate("SFMediaNodes.open('frame',project.scenes[0].id)");p.locator('.mniMore summary').click();p.locator('[data-mn=check]').click();p.wait_for_function('!!project.scenes[0].frames.at(-1).quality||!!document.querySelector(".mniError")',timeout=45000);print('FRAME CHECK',p.locator('.mniError').all_text_contents(),flush=True)
   if p.evaluate('!!project.scenes[0].frames.at(-1).quality'):
    assert p.evaluate('project.scenes[0].frames.at(-1).quality.width')==1080
   else:
    assert 'OpenCV' in p.locator('.mniError').inner_text()
    assert '1080×1920' in p.locator('.mniTags').inner_text()
   assert 'Mặt: chưa kiểm' in p.locator('.mniTags').inner_text()
   # Explicit manual acceptance preserves measured warnings and only accepts the current image.
   p.evaluate("project.scenes[0].localWarnings=['Bạn đánh dấu cần rà khuôn mặt'];project.scenes[0].localReviewKey='manual-face';SFMediaNodes.open('frame',project.scenes[0].id)")
   p.locator('[data-mn=approve]').click();p.wait_for_function('frameApproved(project.scenes[0])')
   # Retrying one failed split part must not re-send its already approved sibling.
   p.locator('[data-action=close-modal]').first.click()
   p.locator('#node-videos [data-mn=retry-all]').evaluate('b=>b.click()');p.locator('#directPrepare').click();p.locator('#directSend').wait_for();assert len(posts)==1
   assert p.locator('#directSend').inner_text().startswith('Gửi 1 ')
   p.locator('#directSend').click();p.wait_for_function('project.cloudJobs.at(-1).state==="submitted"');assert len(posts)==2
   p.evaluate('directRecover()');p.wait_for_function('project.scenes[2].clips.length===2')
   assert p.evaluate('project.scenes[2].clips[0].id')=='part-b'
   p.evaluate("SFMediaNodes.open('clip',project.scenes[2].id,'a')")
   changed='One slow camera push. Preserve the exact product and background.'
   p.locator('#mnPrompt').fill(changed);p.locator('[data-mn=regenerate]').click();p.locator('#directPrepare').click();p.locator('#directSend').wait_for();assert len(posts)==2
   p.locator('#directSend').click();p.wait_for_function('project.cloudJobs.at(-1).state==="submitted"');assert len(posts)==3 and posts[-1]['prompt']==changed
   p.evaluate('directRecover()');p.wait_for_function('project.scenes[2].clips.length===3')
   p.evaluate("SFMediaNodes.open('clip',project.scenes[2].id,'a')");p.locator('[data-mn=speed]').click();assert p.locator('#mnVideo').evaluate('v=>v.playbackRate')==.5
   p.locator('[data-mn=loop]').click();assert p.locator('#mnVideo').evaluate('v=>v.loop')
   assert p.evaluate("SFMediaNodes.status(project.scenes[2],'clip','b').bucket")=='approved'
   p.locator('.mniVersions summary').click();p.locator('.mniVersions [data-mn=version]').first.click();assert p.locator('#mnPrompt').get_attribute('readonly')is not None
   assert p.locator('[data-mn=approve]').count()==0
   p.screenshot(path=str(r/'artifacts/media-nodes-inspector.png'))
   p.locator('[data-action=close-modal]').first.click();p.screenshot(path=str(r/'artifacts/media-nodes-grid.png'))
   assert not errors,errors
   print('PASS compact reference grids, grouped split parts, review filter, comparison, direct prompt edits sent verbatim, real frame dimensions, explicit manual approval, exact-slot retry preserves sibling, unknown receipt excluded from re-send, native playback, read-only history, provider transport fixtures only.')
   browser.close()
 finally:proc.terminate();proc.wait(timeout=15)
