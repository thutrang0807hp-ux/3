"""Real SQLite persistence across browser profiles; no provider generation."""
from pathlib import Path
import os,socket,subprocess,tempfile,time,urllib.request
from playwright.sync_api import sync_playwright,expect
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-recipe-library-')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);base=f'http://127.0.0.1:{port}/'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=browser.new_context();page=ctx.new_page();errors=[];sent=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:sent.append(q.url)if q.method=='POST'and any(x in q.url for x in ['/flow/jobs','/gemini-chat/jobs','/web-images/jobs','/batch/images','/ai/analyze'])else None);page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();if(document.querySelector('#shellDialog').open)document.querySelector('#shellDialog').close();await g6OpenRecipes();}''');page.locator('.kvAdd summary').click();page.locator('[data-v4="new-formula"]').click();page.locator('#g6RecipeName').fill('Kịch bản lưu trên máy');page.locator('#kvEditTopic').select_option('review');page.locator('[data-kr-purpose="0"]').fill('Lời kịch bản được giữ qua profile mới.');page.locator('#g6SaveRecipe').click();page.wait_for_function('recipeCache.items.some(r=>r.name==="Kịch bản lưu trên máy")');rid=page.evaluate('recipeCache.items.find(r=>r.name==="Kịch bản lưu trên máy").id');page.evaluate('batchImageFlush()');ctx.close()
   ctx=browser.new_context();page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base+'#recipes');page.wait_for_function('(id)=>appBootReady&&recipeCache?.items.some(r=>r.id===id)',arg=rid);assert page.evaluate('(id)=>recipeCache.items.find(r=>r.id===id).beats[0].purpose',rid)=='Lời kịch bản được giữ qua profile mới.';page.evaluate('async id=>{await krTrashRecipes([id]);await batchImageFlush();}',rid);ctx.close()
   ctx=browser.new_context();page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base+'#recipes');page.wait_for_function('(id)=>appBootReady&&recipeCache?.trash.some(r=>r.id===id)',arg=rid);page.locator('#kvGroups [data-kr=trash]').click();expect(page.locator('[data-hub-row="recipe:'+rid+'"]')).to_be_visible();page.locator('[data-hub-restore="recipe:'+rid+'"]').click();page.wait_for_function('(id)=>recipeCache.items.some(r=>r.id===id)',arg=rid);page.evaluate('batchImageFlush()');snap=page.evaluate('SceneForgeStorage.api("snapshot")');assert any(row['key']=='recipe-library'for row in snap['records']);assert not sent,sent;assert not errors,errors;browser.close();print('PASS actual SQLite formula purpose/metadata, fresh-profile reload, trash persisted across another profile, shared-hub restore and committed snapshot; no provider generation.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill()
