"""Browser integration of home/library/frame intake, real IndexedDB and CPU-only source reuse."""
from pathlib import Path
import os,socket,subprocess,tempfile,time,urllib.request,json
from playwright.sync_api import sync_playwright,expect
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-video-intake-browser-')as tmp:
 sample=Path(tmp)/'landscape.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=green:s=160x90:d=1','-c:v','libx264','-pix_fmt','yuv420p',str(sample)],check=True)
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':str(Path(tmp)/'data')},stdout=subprocess.DEVNULL,stderr=open(Path(tmp)/'server.log','w'));base=f'http://127.0.0.1:{port}/'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1366,'height':900});errors=[];cloud=[]
   page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda req:cloud.append(req.url)if req.method=='POST'and any(x in req.url for x in ['/ai/','/flow/jobs','/muse/jobs','/gemini-chat/jobs','/web-images/jobs'])else None)
   page.goto(base);page.wait_for_function('appBootReady&&!!window.SceneForgeApp?.videoIntake')
   page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}''')
   page.locator('#newVideo').click();page.locator('#createReference').click();expect(page.locator('#viURL')).to_be_visible();expect(page.locator('#viExisting')).to_be_visible()
   page.locator('#viCancel').click();page.evaluate('g6OpenRecipes()');page.locator('.kvAdd summary').click();page.locator('[data-kv="import"]').click();expect(page.locator('#dialogTitle')).to_have_text('Lấy kịch bản từ video')
   before=page.evaluate('rooms.length');page.locator('#viFile').set_input_files(str(sample))
   expect(page.locator('#dialogTitle')).to_have_text('Khung sườn đã lưu',timeout=45000)
   assert page.evaluate('rooms.length')==before+1
   rid=page.evaluate('rooms[rooms.length-1].id');assert page.evaluate('(id)=>roomFor(id).intakePurpose',rid)=='recipe'
   assert page.evaluate('async id=>{const w=await workflowRecord(id);return w.scenes.length>0&&!w.scenes.some(s=>s.frames.length||s.clips.length)}',rid)
   assert not cloud,cloud
   ai=[]
   def recipe_fixture(route):
    ai.append(route.request.post_data_json)
    route.fulfill(status=200,json={'name':'Khung AI thử nghiệm','industry':'Chung','videoType':'Show sản phẩm','tips':'Chỉ ảnh đại diện','beats':[{'name':'Giới thiệu','role':'solution','type':'wide','start':0,'end':1,'purpose':'Giới thiệu bố cục','example':''}]})
   page.route('**/local-api/ai/recipe-evidence',recipe_fixture);page.on('dialog',lambda d:d.accept())
   page.locator('#viUnderstand').click();expect(page.locator('#viStatus')).to_contain_text('Đã cập nhật',timeout=20000)
   assert len(ai)==1 and ai[0]['ai_source']=='gemini_chat' and ai[0]['room_id']==rid and ai[0]['pictures'] and ai[0]['expected_store_id']
   assert page.evaluate('async id=>(await recipeLibrary()).items.find(x=>x.sourceRoomId===id).intakeAI',rid)
   page.locator('#viOpenSaved').click();expect(page.locator('.kvShell')).to_be_visible()
   # Import from the recipe menu reuses the same room/analysis and adds no source copy.
   page.locator('.kvAdd summary').click();page.locator('[data-kv="import"]').click();page.locator('#viExisting').select_option(rid);page.locator('#viReuse').click();expect(page.locator('#dialogTitle')).to_have_text('Khung sườn đã lưu',timeout=15000);assert page.evaluate('rooms.length')==before+1
   page.locator('#viOpenSaved').click();page.evaluate('(id)=>openRoom(id,"analysis")',rid)
   page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getReadiness()')
   page.frame_locator('#workflowFrame').locator('[data-action="upload"]').first.click();expect(page.locator('#viURL')).to_be_visible()
   page.locator('#viURL').fill('http://127.0.0.1/internal.mp4');page.locator('#viDownload').click();expect(page.locator('#viStatus')).to_contain_text('công khai')
   page.screenshot(path=str(r/'artifacts/video-intake.png'),full_page=True)
   assert len(cloud)==1 and cloud[0].endswith('/ai/recipe-evidence'),cloud;assert not errors,errors
   browser.close();print('PASS real browser home + recipe + hosted workflow use shared intake; landscape file -> CPU cuts -> recipe saved; existing room reused without extra source; one explicitly confirmed Gemini evidence request (response fixture), no image/video generation; private URL rejected; no page errors.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill()
