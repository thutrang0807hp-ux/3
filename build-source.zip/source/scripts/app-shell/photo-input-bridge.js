/* Room reference imports are copies. Library writes merge; they never replace. */
Object.assign(SceneForgeApp.photoBridge,{
 flushScriptState:async()=>v4Flush(),
 listScriptLibrary:async()=>{const lib=await recipeLibrary();return lib.items.filter(r=>r.status!=='retired').map(r=>{const votes=Object.values(lib.feedback||{}).filter(v=>v.formula===r.id);return{...clone(r),up:votes.filter(v=>v.vote===1).length,down:votes.filter(v=>v.vote===-1).length};});},
 readProductRefs:async id=>{const p=productFor(id);if(!p)throw Error('Sản phẩm không còn tồn tại.');return clone(p.refs||{});},
 mergeProductRefs:async(id,refs)=>{
  const p=productFor(id);if(!p)throw Error('Sản phẩm không còn tồn tại.');
  const next=clone(p.refs||{});let added=0;
  for(const k of ['product','person','background']){
   next[k]??={images:[],description:''};next[k].images??=[];
   if(k==='person'){next[k].people??=[];for(const person of refs[k]?.people||[])if(!next[k].people.some(x=>x.id===person.id))next[k].people.push(clone(person));}
   for(const image of refs[k]?.images||[]){
    if(next[k].images.some(x=>(x.hash&&image.hash&&x.hash===image.hash)||(x.key&&x.key===image.key)||(x.image&&x.image===image.image)))continue;
    next[k].images.push(clone(image));added++;
   }
  }
  await io('products','readwrite',p.id,{...p,refs:next});p.refs=next;render();return{added};
 },
 recordScriptUse:async(id,roomId,snapshot)=>{
  const lib=await recipeLibrary(),r=lib.items.find(r=>r.id===id),v=roomFor(roomId);
  if(!r||!v)throw Error('Kịch bản hoặc phòng không còn tồn tại.');
  lib.usage??={};lib.usage[roomId+':'+id]={roomId,formula:id,at:Date.now(),sourceSnapshot:clone(snapshot)};await saveRecipeLibrary();
 }
});
