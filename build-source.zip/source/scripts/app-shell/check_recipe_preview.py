from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
r=Path(__file__).resolve().parents[2]
class Q(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Q,directory=str(r/'artifacts')));threading.Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:requests.append(q.url)if q.url.startswith('http')else None);page.goto(f'http://127.0.0.1:{s.server_port}/SceneForge-MoPhong-KhoKichBan.html');page.wait_for_function('appBootReady&&g6RecipeOpen&&recipeCache?.items.length>0');expect(page.locator('#krResize')).to_be_visible();page.locator('.kvAdd summary').click();page.locator('#g6NewRecipe').click();page.locator('#g6RecipeName').fill('Bản mô phỏng kiểm được');page.locator('#g6SaveRecipe').click();page.wait_for_function('recipeCache.items.some(r=>r.name==="Bản mô phỏng kiểm được")');assert not errors,errors;assert len(requests)==1,requests;b.close();print('PASS standalone recipe HTML opens library, edits/saves through real renderer; zero extra HTTP/API requests or JS errors.')
finally:s.shutdown()
