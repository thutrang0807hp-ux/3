"""Read real local journal into the popover; no provider login or generation."""
import os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-activity-')as tmp:
 w=Path(tmp);(w/'fixture_app.py').write_text('''import time\nfrom local_engine import server as s\nwith s.LIBRARY.db()as db:\n db.execute("INSERT INTO generation_job(id,provider,room_id,kind,state,inputs,created) VALUES(?, ?, ?, ?, ?, ?, ?)",('activity-read-fixture','flow','missing-room','video','submitted','[]',time.time()))\napp=s.app\n''')
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','--app-dir',str(w),'fixture_app:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':str(w/'data'),'PYTHONPATH':str(root)},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page();errors=[];posts=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:posts.append(r.url)if r.method=='POST'and any(s in r.url for s in ['/flow/jobs','/gemini-chat/jobs','/web-images/jobs','/batch/images'])else None);page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();$('#shellDialog').close();}''');page.locator('#openQueue').click();expect(page.locator('[data-activity-source=flow_video]')).to_be_visible();expect(page.locator('[data-activity-reconcile="missing-room"]')).to_be_visible();assert page.locator('#queueDrawer progress').count()==0;page.locator('#openQueue').click();expect(page.locator('#queueDrawer')).to_be_hidden();assert not posts,posts;assert not errors,errors;b.close()
  print('PASS actual SQLite generation journal read into Flow lane; missing-room job remains available for reconciliation; unknown progress omitted; toggle closes; no generation POST or page errors.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
