"""Real UI -> real local routes/vault, no account login or generation."""
from pathlib import Path
import os,socket,subprocess,tempfile,time,urllib.request
from playwright.sync_api import sync_playwright,expect
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-image-cap-ui-')as tmp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);base=f'http://127.0.0.1:{port}/'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=b.new_context();page=ctx.new_page();errors=[];generated=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:generated.append(q.url)if q.method=='POST'and any(x in q.url for x in ['/flow/jobs','/gemini-chat/jobs','/web-images/jobs','/batch/images'])else None);page.goto(base+'#batch');page.wait_for_function('appBootReady&&batchOpen');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();if(document.querySelector('#shellDialog').open)document.querySelector('#shellDialog').close();}''');page.locator('[data-image-parallel]').click();page.locator('#batchConcurrency').select_option('3')
   for source,limit in [('gemini_chat',3),('flow',2),('grok',3),('chatgpt',2),('meta',3)]:
    page.locator('#batchEngine').select_option(source);expect(page.locator('#batchPerAccount')).to_be_enabled();page.locator('#batchPerAccount').select_option(str(limit));page.locator('#batchApplyImageSlots').click();expect(page.locator('#batchPerAccountNote')).to_contain_text('đã lưu '+str(limit));expect(page.locator('#batchConcurrency')).to_have_value('3')
   page.locator('#batchEngine').select_option('gemini_chat');expect(page.locator('#batchPerAccount')).to_have_value('3');page.locator('#batchPerAccount').scroll_into_view_if_needed();page.screenshot(path=str(r/'artifacts/image-concurrency-settings.png'),full_page=True);assert page.evaluate('async()=>{const r=await fetch("/local-api/flow/status");const s=await r.json();return s.image_per_account===2&&s.per_account===1;}')
   ctx.close();ctx=b.new_context();page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base+'#batch');page.wait_for_function('appBootReady&&batchOpen');page.locator('[data-image-parallel]').click();page.locator('#batchEngine').select_option('gemini_chat');expect(page.locator('#batchPerAccount')).to_have_value('3');expect(page.locator('#batchConcurrency')).to_have_value('3');assert not generated,generated;assert not errors,errors;b.close();print('PASS real UI saves image cap for Gemini Chat/Flow/Grok/ChatGPT/Meta via local API/vault, app limit unchanged, source switch + new profile restore, Flow video cap preserved, no generation requests.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill()
