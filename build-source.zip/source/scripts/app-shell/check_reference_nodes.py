"""Real Chromium/media/IndexedDB. No provider generation; tests edit preservation and handoff."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import subprocess,socket,tempfile,time,urllib.request,os
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-reference-nodes-')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 log=open(Path(temp)/'server.log','w');proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp},stdout=log,stderr=log)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1600,'height':1050});p=ctx.new_page();errors=[];posts=[]
   p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda req:posts.append(req.url)if req.method=='POST'and any(x in req.url for x in ['/flow/jobs','/muse/jobs','/gemini-chat/jobs','/ai/analyze-frames'])else None)
   p.goto(base+'?demo=1');p.wait_for_function('appBootReady&&rooms.length>0',timeout=60000);p.evaluate('''async()=>{document.querySelector('#shellDialog')?.close();await openRoom(rooms.find(r=>r.mode!=='photos').id,'analysis')}''');p.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SFReferenceNodes',timeout=30000)
   f=p.frame_locator('#workflowFrame');w=p.locator('#workflowFrame');ev=lambda s,*args:w.evaluate('(el,args)=>el.contentWindow.eval(args)',s) if not args else None
   ev('''(async()=>{const rid=project.id;project=demoProject();project.id=rid;project.demo=false;const data=await(await fetch(SAMPLE.video)).blob();assets.set('clip-fixture',new File([data],'clip.mp4',{type:'video/mp4'}));for(const s of project.scenes){s.frames=[];s.approvedFrame='source';s.clips=[{id:'clip-'+s.id,asset:'clip-fixture',part:'a',version:1,duration:12,name:'Clip thật'}];s.chosen={a:s.clips[0].id};s.refsUsed=[];}project.refs.person.people=[{id:'p1',name:'Người 1',description:''},{id:'p2',name:'Người 2',description:''}];project.scenes[0].refsUsed=['person'];project.scenes[0].referencePeople=['p1'];project.scenes[1].refsUsed=['person'];project.scenes[1].referencePeople=['p2'];project.scenes[1].hasPerson=true;project.merge.captions=false;project.merge.musicMode='off';window.fixtureIds=project.scenes.map(s=>s.id);await storeProject();render();})()''')
   for node in ['node-analysis','node-scenes','node-references','node-merge']:assert f.locator('#'+node+'.ndNode').count()==1
   ev('''(async()=>{const img=await(await fetch(SAMPLE.frames[0])).blob();await SFReferenceNodes.addRefs([new File([img],'person.png',{type:img.type})],'person:p2');if(!project.scenes[0].chosen.a||!project.scenes[2].chosen.a||Object.keys(project.scenes[1].chosen).length)throw Error('Unrelated scenes invalidated');if(sceneReference(project.scenes[0],'person').images.length!==0||sceneReference(project.scenes[1],'person').images.length!==1)throw Error('Wrong person sent');})()''')
   # Changing cuts is atomic; untouched scenes retain IDs, media, approvals, and clip choices.
   p.on('dialog',lambda d:d.accept())
   ev('''SFReferenceNodes.repartition([0,2,4,8,12]).then(()=>{if(project.scenes.length!==4||project.scenes[2].id!==fixtureIds[1]||project.scenes[3].id!==fixtureIds[2]||!project.scenes[3].chosen.a)throw Error('Lost unaffected scene');if(!project.sceneLayoutHistory[0].scenes[0].clips.length)throw Error('Lost history media');})''')
   ev('''(async()=>{const h=project.sceneLayoutHistory[0];project.scenes=structuredClone(h.scenes);project.analysis=structuredClone(h.analysis);project.merge=structuredClone(h.merge);project.merge.order=project.scenes.map(s=>s.id);project.scenes[0].clips=[];project.scenes[0].chosen={};project.scenes[1].approvedFrame='source';delete project.scenes[1].frameInputsChanged;project.scenes[1].chosen={a:project.scenes[1].clips[0].id};project.scenes[2].clips=[];project.scenes[2].chosen={};project.merge.ndInclude={voice:false,music:false,captions:false};await storeProject();render();})()''')
   p.screenshot(path=str(r/'artifacts/reference-nodes-workflow.png'))
   # One clip in the middle; head/tail gaps must keep the full 12-second timeline.
   f.locator('[data-nd=handoff]').evaluate('el=>el.click()');p.wait_for_function('currentView==="editor"&&document.querySelector("#workflowFrame").contentWindow.eval("!!project.merge.ndTransferred")',timeout=45000);ed=p.frame_locator('#standaloneEditorDemo')
   p.wait_for_function('document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor',timeout=30000)
   report=p.evaluate('''async()=>{await document.querySelector('#standaloneEditorDemo').contentWindow.SceneForgeEditor.flushRoom();return readEditorDraft(currentRoom.id)}''');items=report['payload']['items'];videos=[i for i in items if i['kind']=='video'];print('HANDOFF ITEMS',[(i['kind'],i['start'],i['duration'],i.get('name'))for i in items],flush=True);assert len(videos)==1 and videos[0]['start']==4
   assert max(i['start']+i['duration']for i in items)==12 and len([i for i in items if i.get('workflowPlaceholder')])==2
   assert videos[0]['volume']==0 and not any(i['kind']=='text'for i in items)
   # Actual manual inspector changes, then exact-slot replacement must preserve those edits.
   ed.locator('#prop-x').evaluate("el=>{el.value='17';el.dispatchEvent(new Event('change',{bubbles:true}))}")
   ed.locator('#prop-scale').evaluate("el=>{el.value='120';el.dispatchEvent(new Event('change',{bubbles:true}))}")
   p.evaluate("async()=>{await document.querySelector('#standaloneEditorDemo').contentWindow.SceneForgeEditor.flushRoom();await showView('analysis')}")
   w=p.locator('#workflowFrame');ev('''(async()=>{const s=project.scenes[1];s.clips.push({...s.clips[0],id:'replacement-real',version:2});s.chosen.a='replacement-real';await storeProject();render();})()''')
   f.locator('[data-nd=replace-slots]').evaluate('el=>el.click()')
   p.wait_for_function('document.querySelector("#workflowFrame").contentWindow.eval("project.merge.ndTransferred.signature").includes("replacement-real")',timeout=45000)
   report=p.evaluate("async()=>{await document.querySelector('#standaloneEditorDemo').contentWindow.SceneForgeEditor.flushRoom();return readEditorDraft(currentRoom.id)}")
   item=next(i for i in report['payload']['items']if i['kind']=='video');asset=next(a for a in report['payload']['assets']if a['id']==item['assetId'])
   print('REPLACED',asset.get('workflowKey'),{k:item.get(k)for k in ['x','scale','start','duration']},flush=True)
   assert asset['workflowKey']=='replacement-real' and item['x']==17 and item['scale']==1.2 and item['start']==4 and item['duration']==4
   assert len(report['payload']['items'])==3
   p.screenshot(path=str(r/'artifacts/reference-nodes.png'))
   assert not errors,errors;assert not posts,posts
   print('PASS reference node UI, actual person-image filtering, no unrelated invalidation, atomic repartition retaining old media and untouched scenes, sparse real editor handoff with head/tail gaps and disabled audio/captions, replacement preserves actual manual position/scale/duration and gap items, zero provider generation.')
   b.close()
 finally:proc.terminate();proc.wait(timeout=15);log.close()
