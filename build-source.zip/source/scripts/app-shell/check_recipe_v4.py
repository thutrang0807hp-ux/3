"""Real browser + SQLite: paste-first scripts and immutable photo-room handoff."""
from pathlib import Path
import os,socket,subprocess,tempfile,time,urllib.request
from playwright.sync_api import sync_playwright,expect
r=Path(__file__).resolve().parents[2]
text='[Cảnh 1 – cận mặt]\nMình review cây son này 🙂.\n\n[Cảnh 2 – cầm son]\nMình dùng [sản phẩm] theo hướng dẫn.\n\n[Cảnh 3]\nXem thêm thông tin trong giỏ hàng nhé!'
with tempfile.TemporaryDirectory(prefix='sf-recipe-v4-')as tmp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 log=open(Path(tmp)/'server.log','w');proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp},stdout=log,stderr=log);base=f'http://127.0.0.1:{port}/'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1500,'height':1000});page=ctx.new_page();errors=[];cloud=[]
   page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:cloud.append(q.url)if q.method=='POST'and any(s in q.url for s in ['/ai/','/flow/jobs','/muse/jobs','/gemini-chat/jobs','/web-images/jobs'])else None)
   page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active');page.evaluate('async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector("#shellDialog").close();await g6OpenRecipes();}')
   page.locator('.kvAdd summary').click();page.locator('#g6NewRecipe').click();expect(page.locator('#v4Body')).to_be_visible();assert page.locator('#g6RecipeBeats').count()==0
   page.locator('#v4Body').fill(text);page.locator('#v4Save').click();page.wait_for_function('(body)=>recipeCache.items.some(r=>r.kind==="script"&&r.body===body)',arg=text);expect(page.locator('.v4Detail')).to_be_visible(timeout=15000)
   rid=page.evaluate('(body)=>recipeCache.items.find(r=>r.body===body).id',text);record=page.evaluate('(id)=>recipeCache.items.find(r=>r.id===id)',rid);assert record['name']=='Mình review cây son này 🙂.'and record['beats']==[]and record['body']==text,record
   assert record['topicSuggestedId']=='review'and not record.get('topicId'),record
   # No required split or AI call before producing the room plan.
   page.locator('[data-v4="use-script"]').click();page.locator('[data-choose-product]').first.click();page.wait_for_function('(id)=>rooms.some(r=>r.photoDraft?.sourceScriptId===id)',arg=rid)
   room=page.evaluate('(id)=>rooms.find(r=>r.photoDraft?.sourceScriptId===id)',rid);roomid=room['id'];draft=room['photoDraft'];assert draft['sourceScriptBody']==text and draft['recipeSnapshot']['body']==text
   assert len(draft['beats'])==3 and 'Cảnh 1'not in draft['beats'][0]['text']and 'cận mặt'in draft['beats'][0]['purpose']and '[sản phẩm]'in draft['beats'][1]['text'],draft
   page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgePhotos?.getReadiness?.()||document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getReadiness?.()',timeout=15000)
   page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().voice?.mode==="native"')
   frame=page.frame_locator('#workflowFrame');assert 'cận mặt'in frame.locator('body').evaluate('()=>photoOverallImagePrompt()');assert 'cận mặt'in frame.locator('body').evaluate('()=>photoWritingPrompt(draft.beats)')
   step=frame.locator('body').evaluate('()=>{const before=structuredClone(draft);try{draft.idea="";draft.refs={product:{images:[{id:"fixture"}]}};for(const b of draft.beats){b.text="";b.visualPrompt="";b.purpose="Cảnh cận sản phẩm";b.authoredDirections=true;}return photoToolbarStep().key;}finally{draft=before;}}');assert step=='storyboard',step
   page.evaluate('g6OpenRecipes()');page.evaluate('async id=>{kv.selected=id;kv.tab="body";await kvDraw();}',rid)
   page.locator('[data-v4="split-local"]').click();expect(page.locator('#v4ApplyParts')).to_be_visible();page.locator('#v4ApplyParts').click();page.wait_for_function('(id)=>recipeCache.items.find(r=>r.id===id).scriptParts?.length===3',arg=rid)
   assert page.evaluate('(id)=>{const r=recipeCache.items.find(r=>r.id===id);return r.scriptParts.map(p=>r.body.slice(p.start,p.end)).join("")===r.body}',rid)
   page.locator('[data-v4="extract"]').click();page.wait_for_function('(id)=>recipeCache.items.some(r=>r.kind==="formula"&&r.sourceScriptId===id)',arg=rid)
   formula=page.evaluate('(id)=>recipeCache.items.find(r=>r.sourceScriptId===id)',rid);assert not formula.get('body')and not formula.get('scriptBody')and all(not x['example']and not x['purpose']for x in formula['beats']),formula
   page.locator('[data-v4-kind="script"]').click();assert page.locator('[data-kv-card="'+formula['id']+'"]').count()==0
   page.locator('#g6RecipeList [data-g6-recipe="'+rid+'"]').click();page.locator('[data-v4="edit-script"]').click();newtext=text+'\n\nĐoạn bổ sung.';page.locator('#v4Body').fill(newtext);page.locator('#v4Save').click();page.wait_for_function('(id)=>recipeCache.items.find(r=>r.id===id).body.endsWith("Đoạn bổ sung.")',arg=rid);expect(page.locator('.v4Detail')).to_be_visible(timeout=15000)
   assert page.evaluate('(id)=>rooms.find(r=>r.id===id).photoDraft.sourceScriptBody',roomid)==text
   assert page.evaluate('(id)=>rooms.find(r=>r.id===id).recipeSnapshot.body',roomid)==text
   page.screenshot(path=str(r/'artifacts/recipe-v4-detail.png'),full_page=True)
   page.evaluate('v4Flush()');ctx.close();ctx=b.new_context();page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:cloud.append(q.url)if q.method=='POST'and any(s in q.url for s in ['/ai/','/flow/jobs','/muse/jobs','/gemini-chat/jobs','/web-images/jobs'])else None);page.goto(base+'#recipes');page.wait_for_function('(id)=>appBootReady&&recipeCache?.items.some(r=>r.id===id)',arg=rid)
   assert page.evaluate('(id)=>recipeCache.items.find(r=>r.id===id).body',rid)==newtext
   assert page.evaluate('(id)=>rooms.find(r=>r.id===id).recipeSnapshot.body',roomid)==text
   # Draft survives switching cards and can be resumed from the menu.
   page.locator('.kvAdd summary').click();page.locator('#g6NewRecipe').click();page.locator('#v4Name').fill('Bản nháp chưa lưu');page.locator('#v4Body').fill('Lời nháp riêng, chưa gọi AI.');page.locator('[data-v4="close-editor"]').click();page.locator('.kvAdd summary').click();page.locator('#g6NewRecipe').click();expect(page.locator('#v4Body')).to_have_value('Lời nháp riêng, chưa gọi AI.');page.locator('#v4Save').click();expect(page.locator('.v4Detail')).to_be_visible(timeout=15000)
   page.locator('#g6RecipeList [data-g6-recipe="'+rid+'"]').click();calls=[]
   def split_fixture(route):
    data=route.request.post_data_json;calls.append(data);route.fulfill(status=200,json={'parts':[{'first':'U1','last':data['units'][-1]['id'],'name':'Nhịp AI minh họa','role':'neutral','type':'wide'}],'original_preserved':True})
   page.route('**/local-api/ai/script-library',split_fixture);page.on('dialog',lambda d:d.accept());page.locator('[data-v4="split-ai"]').click();expect(page.locator('#v4ApplyParts')).to_be_visible(timeout=20000);page.locator('#v4ApplyParts').click();page.wait_for_function('(id)=>recipeCache.items.find(r=>r.id===id).scriptParts?.length===1',arg=rid)
   assert len(calls)==1 and calls[0]['ai_source']=='gemini_chat' and calls[0]['body']==newtext and ''.join(u['text']for u in calls[0]['units'])==newtext
   assert page.evaluate('(id)=>recipeCache.items.find(r=>r.id===id).body',rid)==newtext
   page.locator('[data-v4="split-ai"]').click();expect(page.locator('#v4ApplyParts')).to_be_visible(timeout=20000);assert len(calls)==1;page.locator('#v4SplitCancel').click()
   page.evaluate('async id=>{await krTrashRecipes([id]);await v4Flush();}',rid);assert page.evaluate('(id)=>recipeCache.trash.find(r=>r.id===id).body',rid)==newtext
   assert len(cloud)==1 and cloud[0].endswith('/ai/script-library'),cloud;assert not errors,errors;b.close();print('PASS V4 real browser/SQLite: paste without beats or AI, exact original + emoji, local topic suggestion only, direct photo-room plan excludes stage directions from speech, placeholders retained, local lossless splitting, word-free linked formula, kind filter, edits preserve used snapshots, new browser profile restore, draft resume, explicitly confirmed AI split via response fixture + cache, trash keeps full script.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill()
