"""Actual UI math/filter/CSV/settings navigation, demo is isolated and sends no API requests."""
from pathlib import Path
from functools import partial
import http.server,threading,csv,io
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1100});errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url));page.goto(f'http://127.0.0.1:{s.server_port}/?demo=1');page.wait_for_function('rooms.length===7');bank=page.evaluate('products[0].sceneBank.length');assert bank==8 and page.locator('[data-product-tab=bank]').count()==0;assert page.locator('.showcaseBanner').count()==0
  page.locator('#homeCosts').click();expect(page.locator('#costMonitor')).to_be_visible();assert not page.locator('#shellDialog').is_visible();expect(page.locator('.monitorStats article').nth(0).locator('b')).to_have_text('360');expect(page.locator('.monitorStats article').nth(1).locator('b')).to_have_text('80 cr');expect(page.locator('.monitorStats article').nth(4).locator('b')).to_have_text('0 đ');expect(page.locator('[data-monitor-day]')).to_have_count(7)
  page.locator('#monitorChartToggle').click();expect(page.locator('.monitorPrimary table tbody tr')).to_have_count(7);assert sum(float(x.replace('.','').replace(',','.'))for x in page.locator('.monitorPrimary table tbody tr td:last-child').all_text_contents())==360
  page.locator('[data-monitor-period="30"]').click();expect(page.locator('.monitorPrimary table tbody tr')).to_have_count(30);page.locator('[data-monitor-period="7"]').click();page.locator('#monitorChartToggle').click();page.locator('[data-monitor-day]').first.click();expect(page.locator('#monitorDayDetail')).to_contain_text('cr')
  pid=page.evaluate('monitorData.products[0].id');page.locator('#monitorProduct').select_option(pid);assert page.evaluate('monitorFiltered().every(r=>r.product_id===monitorProduct)');page.locator('#monitorProduct').select_option('all');page.locator('#monitorSource').select_option('flow');page.locator('#monitorOutcome').select_option('regenerated');expect(page.locator('.monitorJournal tbody tr')).to_have_count(5)
  with page.expect_download()as d:page.locator('#monitorCsv').click()
  exported=list(csv.reader(io.StringIO(Path(d.value.path()).read_text(encoding='utf-8-sig'))));assert len(exported)==6 and all(r[-1]=='Có'for r in exported[1:]);assert sum(float(r[7])for r in exported[1:])==80
  # Unclassified/unknown costs stay unknown; separate currencies never merge into fake totals.
  page.evaluate('''()=>{monitorData={at:Date.now()/1000,rows:[{id:'X',at:Date.now()/1000-1,source:'flow',kind:'=1+1',room_name:'@evil',room_id:'R',product_id:'P',state:'unknown',is_regeneration:true,cost:null,cost_unit:null}],products:[{id:'P',name:'Fixture'}],exports:[],balances:[]};monitorSource='all';monitorOutcome='all';monitorPaint();}''');expect(page.locator('.monitorStats article').first.locator('b')).to_have_text('Chưa có dữ liệu');expect(page.locator('.monitorRepeat')).to_contain_text('Chưa xác minh');expect(page.locator('.monitorJournal tbody')).to_contain_text('Chưa xác minh')
  with page.expect_download()as d:page.locator('#monitorCsv').click()
  escaped=list(csv.reader(io.StringIO(Path(d.value.path()).read_text(encoding='utf-8-sig'))));assert escaped[1][2]=="'=1+1"and escaped[1][3]=="'@evil"
  page.locator('#monitorRefresh').click();page.wait_for_function('monitorData?.demo===true');page.locator('[data-g6-rename]').first.click();page.wait_for_function('!monitorOpen');expect(page.locator('#board')).to_be_visible()
  page.locator('#openStorage').click();expect(page.locator('[data-g5-tab=overview]')).to_have_class('active');expect(page.locator('.settingsReadyRow')).to_have_count(8);expect(page.locator('#shellDialog>header>.uiDemoBadge')).to_be_visible();assert page.locator('.g5Connection').count()==0
  page.locator('[data-settings-go=ai]').click();expect(page.locator('#aiRouteSource')).to_have_value('gemini_chat');expect(page.locator('#openGchatAccounts')).to_be_visible();expect(page.locator('.settingsAdvanced')).not_to_have_attribute('open','');page.locator('#openGchatAccounts').click();expect(page.locator('#settingsAccounts')).to_be_visible();page.locator('[data-g5-tab=engines]').click();expect(page.locator('.settingsEngineRow')).to_have_count(6);page.locator('[data-settings-engine="flow2api"]').click();expect(page.locator('#dialogBody')).to_contain_text('install-flow.bat');page.locator('#settingsGuideBack').click();expect(page.locator('[data-g5-tab=engines]')).to_have_class('active')
  page.locator('[data-g5-tab=storage]').click();expect(page.locator('#settingsMinimumGB')).to_be_disabled();expect(page.locator('#settingsStorageAdvanced')).not_to_have_attribute('open','');assert page.locator('[data-g5-setting=lowSpaceGB]').count()==0
  page.screenshot(path=str(root/'artifacts/settings-storage-final.png'),full_page=True)
  for width,height in [(1366,768),(390,844)]:
   page.set_viewport_size({'width':width,'height':height});assert page.locator('#shellDialog').evaluate('(n)=>n.scrollWidth<=n.clientWidth+1');page.locator('[data-g5-tab=ai]').click();expect(page.locator('#openGchatAccounts')).to_be_visible();page.locator('#closeDialog').click();page.locator('#homeCosts'if width>620 else'#homeMobileProduct').click()
   if width<=620:page.locator('#homeMobileCosts').click()
   expect(page.locator('#costMonitor')).to_be_visible();assert not page.locator('#shellDialog').is_visible();assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.screenshot(path=str(root/f'artifacts/monitor-final-{width}.png'),full_page=True);page.locator('#monitorBack').click();page.locator('#openStorage').click()
  assert page.evaluate('products[0].sceneBank.length')==bank;assert not [u for u in requests if'/local-api/'in u],requests;assert not errors,errors;b.close()
 print('PASS monitor page demo math 360/80, periods/product/source/outcome filters, chart/table parity, actual CSV plus formula escaping, unknown fees preserved, sidebar/mobile navigation, overview/AI/accounts/engine guides/storage settings, no overflow, removed bank tab keeps eight stored clips; zero API/provider requests in demo.')
finally:s.shutdown()
