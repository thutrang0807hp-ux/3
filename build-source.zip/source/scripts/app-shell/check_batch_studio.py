"""Interactive batch simulation: bounded concurrency, pause, dependency and persistence."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
import tempfile,subprocess
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory(dir='/tmp')as tmp,sync_playwright()as p:
  tmp=Path(tmp);ref=tmp/'Tham chiếu.png';Image.new('RGB',(100,150),'#e85c75').save(ref)
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000},accept_downloads=True);errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append(r.url));page.goto(f'http://127.0.0.1:{server.server_port}/?demo=1#batch');page.wait_for_function('rooms.length===7&&!!SceneForgeApp.batch.getState()');expect(page.locator('#batchStudio')).to_be_visible();expect(page.locator('#batchEngine')).to_have_value('Mô phỏng trên máy')
  old=page.evaluate('({refs:structuredClone(products[0].refs),roomRefs:rooms.map(r=>structuredClone(r.refs))})')
  page.locator('#batchReferenceFiles').set_input_files(ref);expect(page.locator('[data-batch-ref]')).to_have_count(1)
  page.locator('[data-batch-quick]').click();page.wait_for_function('batchState.jobs.length===6');page.wait_for_function('batchWorkers.size===3');assert page.evaluate('batchState.jobs.filter(j=>j.status==="running").length')==3
  page.screenshot(path='/tmp/sceneforge-batch-running.png');page.locator('#batchPause').click();page.wait_for_function('batchWorkers.size===0',timeout=20000);assert page.evaluate('batchState.jobs.filter(j=>j.status==="done").length')==3;assert page.evaluate('batchState.jobs.filter(j=>j.status==="waiting").length')==3
  page.locator('#batchRun').click();page.wait_for_function('batchState.jobs.filter(j=>j.status==="done").length===6',timeout=20000)
  first=page.evaluate('batchState.jobs[0].id');page.locator('[data-batch-select="'+first+'"]').click();expect(page.locator('.batchModalPreview img')).to_be_visible()
  page.screenshot(path='/tmp/sceneforge-batch-completed.png')
  with page.expect_download()as output:page.locator('.batchModalPreview [data-batch-download]').click()
  dest=tmp/'mock.png';output.value.save_as(dest);assert dest.read_bytes().startswith(b'\x89PNG\r\n\x1a\n');assert page.evaluate('batchState.jobs[0].origin')=='simulation'
  page.locator('#shellDialog').evaluate('(d)=>d.close()')
  # A later chained group cannot occupy three workers at once; cancelled parent blocks descendants.
  page.locator('#batchPrompts').fill('Cảnh nối 1\nCảnh nối 2\nCảnh nối 3');page.locator('#batchPrompts').dispatch_event('input');page.locator('.batchAdvanced').evaluate('(d)=>d.open=true');page.locator('#batchChain').check();page.locator('#batchEnqueue').click();page.wait_for_function('batchState.jobs.length===9');page.locator('#batchRun').click();page.wait_for_function('batchWorkers.size===1');parent=page.evaluate('batchState.jobs[6].id');assert page.evaluate('batchState.jobs[7].status')=='waiting';page.locator('[data-batch-cancel="'+parent+'"]').click();page.wait_for_function('batchWorkers.size===0&&batchState.jobs[8].status==="blocked"');assert page.evaluate('batchState.jobs[7].status')=='blocked'
  # Import a genuine image; saving adds to the master library only, preserving existing room snapshots.
  page.locator('[data-batch-select="'+first+'"]').click();
  page.evaluate('(id)=>batchImportTarget=id',first);page.locator('#batchResultFiles').set_input_files(ref);page.wait_for_function('batchState.jobs[0].origin==="imported"');page.locator('.batchModalPreview [data-batch-save-image]').click();page.wait_for_function('products[0].refs.product.images.length===2');assert page.evaluate('rooms.map(r=>r.refs)')==old['roomRefs'];assert page.evaluate('products[0].refs.product.images[0]')==old['refs']['product']['images'][0]
  # Real local video is retained as a separate version and can join the shared scene bank.
  video=tmp/'Video thật.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=240x426:r=30:d=1','-c:v','libx264','-pix_fmt','yuv420p','-y',str(video)],check=True)
  page.evaluate('(id)=>batchImportTarget=id',first);page.locator('#batchResultFiles').set_input_files(video);page.wait_for_function('batchState.jobs[0].resultType==="video/mp4"');page.locator('.batchModalPreview [data-batch-save-video]').click();page.wait_for_function('products[0].sceneBank.length===9');assert page.evaluate('batchState.jobs[0].versions.length')==3
  page.locator('#shellDialog').evaluate('(d)=>d.close()')
  original_product=page.evaluate('batchState.jobs[0].productId');other=page.evaluate('products[1].id');page.locator('#batchProduct').select_option(other);page.wait_for_function('(id)=>prefs.product===id',arg=other);assert page.evaluate('batchState.jobs[0].productId')==original_product;page.locator('#batchProduct').select_option(original_product);expect(page.locator('#batchProduct')).to_have_value(original_product)
  # Reload does not silently restart interrupted simulations.
  page.locator('#batchChain').uncheck();page.locator('#batchPrompts').fill('Tiếp 1\nTiếp 2');page.locator('#batchPrompts').dispatch_event('input');page.locator('#batchEnqueue').click();page.wait_for_function('batchState.jobs.length===11');page.locator('#batchRun').click();page.wait_for_function('batchWorkers.size===2');page.reload();page.wait_for_function('batchState?.jobs.length===11');assert page.evaluate('batchState.paused&&batchWorkers.size===0');assert page.evaluate('batchState.jobs.filter(j=>j.status==="interrupted").length')==2
  page.screenshot(path='/tmp/sceneforge-batch-preview.png');page.locator('#batchHome').click();expect(page.locator('#board')).to_be_visible();assert page.locator('.stageColumn').count()==4;page.locator('#openBatchStudio').click();expect(page.locator('#batchStudio')).to_be_visible();assert page.evaluate('batchState.jobs.length')==11;page.locator('#g6OpenRecipes').click();expect(page.locator('#g6Recipes')).to_be_visible();expect(page.locator('#batchStudio')).not_to_be_visible();page.locator('#openBatchStudio').click();expect(page.locator('#batchStudio')).to_be_visible();page.locator('#batchHome').click();page.locator('#archiveProduct').click();expect(page.locator('#archiveView')).to_be_visible();page.locator('#openBatchStudio').click();expect(page.locator('#batchStudio')).to_be_visible()
  page.set_viewport_size({'width':1000,'height':800});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.set_viewport_size({'width':760,'height':900});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  assert not [u for u in calls if '/local-api/'in u],calls;assert not errors,errors;page.evaluate('''async()=>{const bad=structuredClone(batchState);bad.jobs[0].id='bad\"><img src=x onerror=window.batchInjected=1>';await io('prefs','readwrite',batchStoreKey,bad);}''');page.reload();expect(page.locator('#homeError')).to_contain_text('không hợp lệ');assert page.evaluate('window.batchInjected===undefined');assert page.evaluate('''async()=>String((await io('prefs','readonly',batchStoreKey)).jobs[0].id).startsWith('bad')''');browser.close();print('PASS 3 concurrent simulations; pause drains running only; dependency/cancel propagation; real PNG download; reference/image/video import and immutable versions; master library preserves room refs; interrupted reload stays paused; board navigation/responsive fit; zero provider/API calls in demo.')
finally:server.shutdown()
