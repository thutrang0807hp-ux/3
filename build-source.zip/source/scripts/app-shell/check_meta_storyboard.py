"""Real app browser, provider receipt/PNG fixtures. No online generation or accounts."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import tempfile,subprocess,socket,time,os,urllib.request,io,base64
from PIL import Image
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-meta-storyboard-')as tmp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page(viewport={'width':1600,'height':1050});errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.goto(base);p.wait_for_function('appBootReady&&SceneForgeStorage.state.active')
   p.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const row={id:'meta-storyboard-test',name:'Meta storyboard',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(row);await persistRoom(row);await openRoom(row.id,'analysis');window.openedAccount=null;accountScreen=async source=>{openedAccount=source;};SceneForgeApp.accounts.open=async source=>{openedAccount=source;};}''')
   f=p.locator('#workflowFrame').element_handle().content_frame();f.wait_for_function('loaded&&!!window.SFStoryboard');posts=[];records={};token=['meta-A'];available=[False];pngs=[]
   for color in ['red','blue']:
    out=io.BytesIO();Image.new('RGB',(180,320),color).save(out,format='PNG');pngs.append(out.getvalue())
   def route(req):
    path=req.request.url.split('/local-api/')[1]
    if path.endswith('/status'):
     meta=path=='web-images/meta/status';data={'configured':available[0]if meta else True,'installed':True,'account_binding':True,'models':[],'selection':{'available':available[0]if meta else True,'account_name':'Meta Fixture'if meta else'Gemini Fixture','token':token[0]if meta else'gemini-A','mode':'selected'}}
    elif path.endswith('/jobs'):
     body=req.request.post_data_json;posts.append((path,body));records[body['request_id']]={'state':'submitted','store_id':'fixture'};return req.fulfill(json={'state':'submitted','store_id':'fixture'})
    elif '/jobs/'in path:data=records.get(path.rsplit('/',1)[-1],{'state':'unknown','store_id':'fixture'})
    elif '/files/'in path:return req.fulfill(body=pngs[1 if 'index=1'in path else 0],content_type='image/png')
    else:return req.continue_()
    req.fulfill(json=data)
   p.route('**/local-api/web-images/**',route);p.route('**/local-api/gemini-chat/**',route);p.route('**/local-api/flow/**',route)
   # Source choice is staged until Done. Its account action opens Meta, not Muse/Gemini.
   f.evaluate('async()=>photoToolbarRefresh(true)');p.locator('#workspaceSourcePill').click();p.locator('[data-source-value=meta]').click();expect(p.locator('[data-workspace-connect=meta]')).to_be_visible();assert f.evaluate('photoTools().creative')=='gemini'
   p.locator('[data-workspace-connect=meta]').click();p.wait_for_function('openedAccount==="meta"');assert not posts
   p.locator('#workspaceSourcePill').click();p.locator('[data-source-value=meta]').click();p.locator('#workspaceSourceDone').click();f.wait_for_function('photoTools().creative==="meta"');expect(p.locator('#workspaceSourcePill')).to_contain_text('Meta AI')
   available[0]=True;f.evaluate('async()=>photoToolbarRefresh(true)')
   f.evaluate('''async data=>{const file=new File([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],'identity.png',{type:'image/png'});await bridge.putFile('identity',file);draft.refs={product:{images:[{id:'identity',key:'identity',image:'data:image/png;base64,'+data}],description:'Product'}};draft.voice={mode:'native'};draft.beats=[{id:'scene-one',name:'Một cảnh',type:'wide',seconds:4,text:'Lời nguyên văn',clips:[]}];delete draft.scriptInput;draft.storyboardPlan={mode:'frames',slots:{},description:'',usedOverall:null};draft.geminiJobs=[];draft.storyboardImages=[];delete draft.storyboardImage;render();await save();}''',base64.b64encode(pngs[0]).decode())
   f.locator('[data-sb-select="scene-one:a"]').check();f.evaluate('async()=>SFStoryboard.create()');assert not posts
   # Changing account selection after preflight causes no submission.
   token[0]='meta-B';f.locator('#sbSendConfirm').click();expect(f.locator('#sbSendError')).to_contain_text('đổi');assert not posts;f.locator('#closePhotoDialog').click()
   f.evaluate('async()=>SFStoryboard.create()');f.locator('#sbSendConfirm').click();f.wait_for_function('draft.geminiJobs.length===1&&draft.geminiJobs[0].state==="submitted"&&!SFStoryboard.isBusy()');path,body=posts[0];assert path=='web-images/jobs' and body['source']=='meta' and body['scene_id']=='scene-one' and body['request_id'].startswith('webimage-');assert base64.b64decode(body['references'][0]['data'])==pngs[0]
   rid=body['request_id'];count=len(posts);f.evaluate('async()=>{try{await SFStoryboard.create()}catch{}}');assert len(posts)==count
   # Receive the original provider even after changing the selected source. Both returned files survive as versions.
   records[rid]={'state':'done','store_id':'fixture','result':{'account_id':'meta-account','images':[{'mime_type':'image/png'},{'mime_type':'image/png'}]}}
   f.evaluate('photoTools().creative="gemini"');f.evaluate('async()=>SFStoryboard.recover()');assert f.evaluate('draft.storyboardPlan.slots["scene-one:a"].images.start.length')==2
   ids=f.evaluate('draft.storyboardPlan.slots["scene-one:a"].images.start.map(i=>({requestId:i.requestId,origin:i.origin,resultIndex:i.resultIndex}))');assert all(i['origin']=='meta'and i['requestId']==rid for i in ids);assert [i['resultIndex']for i in ids]==[0,1]
   f.evaluate('async()=>SFStoryboard.recover()');assert f.evaluate('draft.storyboardPlan.slots["scene-one:a"].images.start.length')==2 and len(posts)==count
   # Whole overview uses Meta and keeps both alternatives; it never rewrites dialogue.
   f.evaluate('photoTools().creative="meta"');f.evaluate('async()=>photoGchatSubmit("image",photoOverallImagePrompt(),"image")');expect(f.locator('#photoDialogTitle')).to_contain_text('Meta AI');assert len(posts)==count;f.locator('#photoSendChat').click();f.wait_for_function('draft.geminiJobs.length===2&&draft.geminiJobs[1].state==="submitted"');rid2=posts[-1][1]['request_id'];assert posts[-1][1]['aspect']=='16:9';records[rid2]={'state':'done','store_id':'fixture','result':{'account_id':'meta-account','images':[{'mime_type':'image/png'},{'mime_type':'image/png'}]}}
   f.evaluate('async()=>photoReceiveGemini()');assert f.evaluate('draft.storyboardImages.length')==2;f.evaluate('async()=>photoReceiveGemini()');assert f.evaluate('draft.storyboardImages.length')==2
   assert f.evaluate('draft.beats[0].text')=='Lời nguyên văn'
   # Prompt writing remains explicitly Gemini; selecting Meta for images cannot change the text route.
   f.evaluate('async()=>photoGchatSubmit("text","Return JSON only","writing")');expect(f.locator('#photoDialogTitle')).to_contain_text('Gemini Chat');f.locator('#photoSendChat').click();f.wait_for_function('draft.geminiJobs.length===3&&draft.geminiJobs[2].state==="submitted"');assert posts[-1][0]=='gemini-chat/jobs'and posts[-1][1]['kind']=='text'
   assert not errors,errors;b.close();print('PASS Meta source/account button staging and shared session, stale account token no-send, exact scene/reference image jobs, original-provider recovery after source switch, multiple image alternatives/idempotent import, Meta overview and preserved dialogue, explicit Gemini text route, no unknown/duplicate replay; provider fixtures only')
 finally:proc.terminate();proc.wait(timeout=10)
