"""Regression for hidden controls and accidental concurrency reset. Real concurrent local PNG tasks."""
from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
r=Path(__file__).resolve().parents[2]
class Q(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Q,directory=str(r/'dist/web-demo')));threading.Thread(target=srv.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1000});errors=[];posts=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:posts.append(q.url)if q.method=='POST'and'/local-api/'in q.url else None);page.goto(f'http://127.0.0.1:{srv.server_port}/?demo=1');page.wait_for_function('appBootReady');page.locator('#openBatchStudio').click();page.locator('[data-image-parallel]').click()
  for selector in ['#batchConcurrency','#batchCopies','#batchGroupSize','#batchGroupGap','#batchPromptGap','#batchChain']:expect(page.locator(selector)).to_be_visible()
  page.locator('#batchConcurrency').select_option('3');page.wait_for_function('batchState.concurrency===3');page.locator('#batchEngine').select_option('grok');expect(page.locator('#batchConcurrency')).to_have_value('3');assert page.evaluate('batchState.concurrency')==3;page.locator('#batchEngine').select_option('simulation') if page.locator('#batchEngine option[value=simulation]').count() else page.locator('#batchEngine').select_option(index=0)
  page.locator('#batchPrompts').fill('1. Cận cảnh son\n2. Son trên bàn\n3. Son ánh sáng mềm\n4. Son cạnh cửa sổ\n5. Son góc nghiêng\n6. Son bao bì');page.locator('#batchEnqueue').click();page.wait_for_function('batchLatest().length===6');page.locator('[data-image-resume]').click();page.wait_for_function('batchWorkers.size===3&&batchLatest().filter(j=>j.status==="running").length===3');page.screenshot(path=str(r/'artifacts/batch-parallel-controls.png'),full_page=True);assert page.evaluate('batchLatest().filter(j=>j.status==="waiting").length')==3;page.wait_for_function('batchLatest().every(j=>j.status==="done")',timeout=25000);assert page.evaluate('(()=>{const js=batchLatest().slice(0,3);return Math.max(...js.map(j=>j.startedAt))<Math.min(...js.map(j=>j.finishedAt));})()')
  # A new lot can intentionally depend on the previous image; this is sequential by design.
  page.locator('#batchNewLot').click();page.locator('#batchChain').check();page.locator('#batchPrompts').fill('Ảnh nối 1\nẢnh nối 2');page.locator('#batchEnqueue').click();page.wait_for_function('batchLatest().length===2');expect(page.locator('#batchConcurrencyNote')).to_contain_text('phải chờ nhau');page.locator('[data-image-resume]').click();page.wait_for_function('batchWorkers.size===1');assert page.evaluate('batchLatest().filter(j=>j.status==="running").length')==1;page.wait_for_function('batchLatest().every(j=>j.status==="done")',timeout=20000);assert page.evaluate('batchLatest()[1].startedAt>=batchLatest()[0].finishedAt')
  page.reload();page.wait_for_function('appBootReady');page.locator('#openBatchStudio').click();page.locator('[data-image-parallel]').click();expect(page.locator('#batchConcurrency')).to_have_value('3');assert not errors,errors;assert not posts,posts;b.close();print('PASS advanced controls visible, direct settings link, concurrency 3 survives source switch/reload, six real local PNG tasks overlap in groups of three, explicit image chaining stays sequential; zero AI/API posts. Does not certify same-account online concurrency.')
finally:srv.shutdown()
