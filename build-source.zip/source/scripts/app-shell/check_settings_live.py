"""Actual local settings/vault/storage. Only remote model discovery is replaced by a fixture."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,json,zipfile
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-settings-live-')as tmp:
 work=Path(tmp);(work/'fixture_app.py').write_text('''from local_engine import server as s,ai_providers
from fastapi import HTTPException
import os,time
from pathlib import Path
models=s.DATA/'models';models.mkdir(exist_ok=True);(models/'fixture-weight.bin').write_bytes(b'MODEL_FIXTURE')
p=s.LIBRARY.root/'cache/thu-vien-fixture.zip';p.write_bytes(b'KEEP_CACHE');os.utime(p,(time.time()-7200,time.time()-7200))
async def discover(v,provider,client=None):
 if 'BAD' in v.secret(provider):raise HTTPException(401,'Key mới bị từ chối · fixture')
 result={'ok':True,'provider':provider,'model':'fixture-flash-lite','note':'Key kiểm được model fixture-flash-lite, chưa xác minh quota.'}
 v.set_secret(provider+'-models',{'main':'fixture-flash-lite','simple':'fixture-flash-lite'});v.set_secret(provider+'-check',result);return result
ai_providers.discover=discover
app=s.app
''')
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','--app-dir',str(work),'fixture_app:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':str(work/'data'),'PYTHONPATH':str(root)},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(150):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1500,'height':1000});errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append((r.method,r.url)));page.goto(base);page.wait_for_function('!!SceneForgeApp&&appBootReady&&SceneForgeStorage.state.managed&&SceneForgeStorage.state.active');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}''');page.locator('#openStorage').click();expect(page.locator('[data-g5-tab=overview]')).to_have_class('active');assert page.locator('#shellDialog .uiDemoBadge').count()==0
   page.locator('[data-g5-tab=ai]').click();page.locator('#aiRouteSource').select_option('gemini_api');expect(page.locator('#settingsGeminiKey')).to_be_visible();page.locator('#settingsGeminiKey').fill('GOOD_PRIVATE_BROWSER_FIXTURE_KEY');page.locator('#settingsCheckSaveKey').click();expect(page.locator('#settingsKeyResult')).to_contain_text('fixture-flash-lite');expect(page.locator('#settingsGeminiKey')).to_have_value('');page.wait_for_function('g5Status.gemini_configured')
   page.locator('#settingsGeminiKey').fill('BAD_PRIVATE_BROWSER_FIXTURE_KEY');page.locator('#settingsCheckSaveKey').click();expect(page.locator('#settingsKeyResult')).to_contain_text('bị từ chối');expect(page.locator('#settingsGeminiKey')).to_have_value('');page.locator('[data-g5-tab=overview]').click();page.locator('[data-g5-tab=ai]').click();expect(page.locator('#settingsKeyResult')).to_contain_text('fixture-flash-lite');assert not any('/settings/secret'in url for _,url in requests),'unified operation must use verify-save, not save invalid key first'
   page.screenshot(path=str(root/'artifacts/settings-api-live.png'),full_page=True)
   page.locator('[data-g5-tab=storage]').click();page.wait_for_function('settingsStorageData?.complete===true');assert page.evaluate('settingsStorageData.categories.models')==len(b'MODEL_FIXTURE');expect(page.locator('#settingsSaveMinimum')).to_be_enabled();page.locator('#settingsMinimumGB').fill('5');page.locator('#settingsSaveMinimum').click();page.wait_for_function('settingsStorageData?.limits?.minimum_free_mb===5120');assert page.evaluate('SceneForgeStorage.api("storage-limits")')['minimum_free_mb']==5120
   page.route('**/local-api/library/open-root',lambda r:r.fulfill(json={'path':'fixture-local-root'}));page.locator('#settingsOpenRoot').click();page.wait_for_timeout(100);assert any('/library/open-root'in url and method=='POST'for method,url in requests)
   page.on('dialog',lambda d:d.dismiss());page.locator('#settingsClearCache').click();page.wait_for_timeout(150);assert (work/'data/SceneForge/cache/thu-vien-fixture.zip').read_bytes()==b'KEEP_CACHE';assert not any('/library/cache'in url and method=='POST'for method,url in requests)
   page.locator('#settingsBackupReview').click();assert page.locator('#settingsStorageAdvanced').evaluate('(n)=>n.open');expect(page.locator('#libraryBackupName')).to_be_visible()
   with page.expect_download()as download:page.locator('#settingsLibraryZip').click()
   with zipfile.ZipFile(download.value.path())as z:assert z.testzip()is None and not any('vault.key'in n or'vault.sqlite'in n for n in z.namelist())
   page.locator('#closeDialog').click();page.locator('#homeCosts').click();expect(page.locator('#costMonitor')).to_be_visible();expect(page.locator('.monitorStats article').first.locator('b')).to_have_text('Chưa có dữ liệu');assert page.locator('#costMonitor .uiDemoBadge').count()==0
   generation=[url for method,url in requests if method=='POST'and any(x in url for x in ['/flow/jobs','/muse/jobs','/gemini-chat/jobs','/web-images/jobs','/ai/script','/tts'])];assert not generation,generation;assert not errors,errors;b.close()
  print('PASS local settings default overview, Chat/API source persists, one verify-save action with fixture discovery, bad key preserves old model/credential evidence, key fields cleared, actual model/storage byte measurement, actual admission threshold save, guarded cache cancel, open-root UI binding, backup controls, real library ZIP without vault, empty real monitor unknown fees; zero generation requests.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
