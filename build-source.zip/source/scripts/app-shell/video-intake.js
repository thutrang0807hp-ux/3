/* One source importer, three entry points. CPU-only preparation never submits generation. */
(()=>{
let serial=0,running=false,downloadId=null;
const q=s=>document.querySelector(s), message=t=>{const n=q('#viStatus');if(n)n.textContent=t;};
async function checkpoint(){
 if(!window.SceneForgeStorage?.managed)return;
 for(let n=0;n<10;n++){
  if(!SceneForgeStorage.state.active)throw Error('Kho trên ổ đang bị khóa. Nguồn vẫn giữ trong trình duyệt; chưa bỏ file tải tạm.');
  try{await SceneForgeStorage.flush();if(!SceneForgeStorage.state.dirty)return;}catch(e){if(!/Dữ liệu đang thay đổi/.test(e.message))throw e;}
  await new Promise(r=>setTimeout(r,350));
 }
 throw Error('Dữ liệu chưa ổn định để lưu xuống ổ. Nguồn vẫn giữ; mở lại bộ nhập để dùng tiếp.');
}
const available=()=>rooms.filter(r=>r.mode!=='photos'&&!r.trashedAt&&!productFor(r.productId)?.trashedAt);
const existingBy=meta=>available().find(r=>meta.url_key&&r.sourceURLKey===meta.url_key||meta.sha256&&r.sourceSHA256===meta.sha256);
async function open(purpose='video'){
 if(running){toast('Đang nhập hoặc phân tích video; chờ xong trước khi mở lượt khác.');return;}
 const token=++serial,active=g6ActiveProducts();
 modal(purpose==='recipe'?'Lấy kịch bản từ video':'Nhập video mẫu',`<div id="videoIntake"><p>${purpose==='recipe'?'Chỉ phân tích và lưu khung sườn. Không tạo ảnh hay clip.':'Nhập nguồn vào một phòng riêng, giữ nguyên các dự án đang có.'}</p><label class="field">Sản phẩm<select id="viProduct">${active.map(p=>`<option value="${esc(p.id)}" ${p.id===prefs.product?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label><section><b>Chọn file trên máy</b><input id="viFile" type="file" accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov,.m4v"><small>Tối đa 500 MB · 10 phút. Chỉ xử lý trên máy khi nhập.</small></section><section><b>Dán link video công khai</b><div class="viRow"><input id="viURL" type="url" placeholder="https://…" aria-label="Link video"><button id="viDownload">Tải và nhập</button></div><small>Link file MP4/WebM hoặc trang được hỗ trợ. Không dùng cookie đăng nhập; nguồn không tải được thì nhập file.</small></section><section><b>Dùng video đã nhập</b><div class="viRow"><select id="viExisting" aria-label="Video đã nhập"><option value="">Chọn video…</option>${available().map(r=>`<option value="${esc(r.id)}">${esc(productFor(r.productId)?.name||'')} · ${esc(r.name)}</option>`).join('')}</select><button id="viReuse">Dùng lại</button></div><small>Dùng đúng phòng gốc và phân tích đã có, không chép thêm một video.</small></section><div id="viDownloads"></div><p id="viStatus" role="status">Chưa gửi video hoặc dữ liệu tới AI.</p></div>`, '<button id="viCancel">Đóng</button>');
 const dialog=q('#shellDialog');dialog.classList.add('videoIntakeDialog');dialog.addEventListener('close',()=>dialog.classList.remove('videoIntakeDialog'),{once:true});
 q('#viCancel').onclick=async()=>{if(running){message('Đang lưu/phân tích, có thể đóng bảng; dữ liệu vẫn được giữ.');}dialog.close();};
 const guard=fn=>async()=>{if(running)return;running=true;for(const b of dialog.querySelectorAll('#videoIntake button'))b.disabled=true;try{await fn();}catch(e){message(e.message);}finally{running=false;downloadId=null;for(const b of dialog.querySelectorAll('#videoIntake button'))b.disabled=false;}};
 const consume=async(file,meta={})=>{
  const p=productFor(q('#viProduct')?.value);if(!p)throw Error('Tạo hoặc chọn sản phẩm trước khi nhập video.');
  let r=existingBy(meta);
  if(!r&&!meta.sha256){const same=available().find(r=>r.sourceName===file.name&&r.sourceSize===file.size&&r.sourceModified===file.lastModified);if(same&&confirm('File có cùng tên, kích thước và ngày sửa với '+same.name+'. Dùng phòng đã nhập thay vì lưu thêm?'))r=same;}
  if(!r){
   const info=await videoInfo(file);message('Đang lưu nguồn vào thư viện…');
   [r]=await importVideos([file],p,{deferAnalysis:true,allowGemini:false});if(!r)throw Error('Không nhập được video.');
   Object.assign(r,info,{sourceURLKey:meta.url_key||null,sourceSHA256:meta.sha256||null,sourceModified:file.lastModified,intakePurpose:purpose});await persistRoom(r);
   if(window.SceneForgeStorage?.managed){if(!SceneForgeStorage.state.active)throw Error('Nguồn đã giữ trong trình duyệt. Kho trên ổ đang bị khóa; chưa bỏ bản tải tạm.');await checkpoint();}
  }
  await checkpoint();
  if(meta.id){await engineRequest('video-import/jobs/'+meta.id+'/release',{});downloadId=null;}
  await finish(r,purpose);
 };
 q('#viFile').onchange=guard(async()=>{const f=q('#viFile').files[0];if(f)await consume(f);});
 q('#viReuse').onclick=guard(async()=>{const r=roomFor(q('#viExisting').value);if(!r||!available().includes(r))throw Error('Chọn video đang còn trong thư viện.');await finish(r,purpose);});
 const receive=async j=>{
  downloadId=j.id;
  while(!['done','error','cancelled'].includes(j.state)){
   message(j.phase+' · '+(j.bytes/1024**2).toFixed(1)+' MB');await new Promise(r=>setTimeout(r,1000));j=await engineRequest('video-import/jobs/'+j.id);
  }
  if(j.state!=='done')throw Error(j.error||'Đã bỏ lượt tải.');
  const old=existingBy(j);if(old){await checkpoint();await engineRequest('video-import/jobs/'+j.id+'/release',{});return finish(old,purpose);}
  const res=await fetch('/local-api/video-import/jobs/'+j.id+'/file');if(!res.ok)throw Error('Không nhận được file tải. Mở lại bộ nhập để nhận lại.');
  await consume(new File([await res.blob()],j.name,{type:j.mime,lastModified:0}),j);
 };
 q('#viDownload').onclick=guard(async()=>{
  const url=q('#viURL').value.trim();let normalized;try{const u=new URL(url);u.hash='';normalized=u.href;}catch{throw Error('Dán link video hợp lệ.');}
  const key=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(normalized)))].map(v=>v.toString(16).padStart(2,'0')).join('');
  const old=existingBy({url_key:key});if(old)return finish(old,purpose);
  message('Đang đọc link…');await receive(await engineRequest('video-import/jobs',{url:normalized}));
 });
 if(['127.0.0.1','localhost'].includes(location.hostname)&&new URLSearchParams(location.search).get('demo')!=='1'){
  try{const data=await engineRequest('video-import/jobs');if(token!==serial)return;const rows=data.jobs||[];q('#viDownloads').innerHTML=rows.length?'<b>Lượt tải chưa lưu</b>'+rows.map(j=>`<div class="viRow"><span>${esc(j.phase)} · ${(j.bytes/1024**2).toFixed(1)} MB</span><button data-vi-resume="${j.id}">Nhận lại</button><button data-vi-release="${j.id}">Bỏ</button></div>`).join(''):'';
   for(const b of dialog.querySelectorAll('[data-vi-resume]'))b.onclick=guard(()=>receive(rows.find(j=>j.id===b.dataset.viResume)));
   for(const b of dialog.querySelectorAll('[data-vi-release]'))b.onclick=guard(async()=>{await engineRequest('video-import/jobs/'+b.dataset.viRelease+'/release',{});b.closest('.viRow').remove();message('Đã bỏ file tải tạm.');});
  }catch(e){message(e.message);}
 }
}
async function localAnalysis(r){
 if(activeWorkers.has(r.id))throw Error('Video này đang phân tích. Chờ lượt hiện tại xong rồi dùng lại.');
 await flushFrames();let w=await workflowRecord(r.id);if(w?.scenes?.length)return w;
 if(w?.analysis?.aiRequest)throw Error('Phòng có lượt AI cần đối soát. Mở phòng để kiểm tra trước; chưa gửi lại.');
 if(!await io('files','readonly',r.id+':source'))throw Error('Nguồn đã được dọn. Chọn lại file để phân tích.');
 if(activeWorkers.size>=2)throw Error('Máy đang phân tích hai phòng. Nguồn đã lưu; chọn Dùng lại khi có chỗ.');
 const frame=makeFrame('analysis',r,true);activeWorkers.set(r.id,frame);r.analysisDeferred=true;await persistRoom(r);
 try{message('Máy đang cắt cảnh, chép lời nếu có model và đọc chữ. Không gọi AI…');const api=await waitAPI(frame,'SceneForgeWorkflow');await api.openRoom(await roomPayload(r));await api.runAnalysisPipeline({allowGemini:false});await api.flushRoom();w=await workflowRecord(r.id);if(!w?.scenes?.length)throw Error('Chưa có cảnh; mở phòng để kiểm tra nguồn.');r.stage='review';r.analysisProgress=clone(w.analysis.pipeline6);r.analysisDeferred=!!r.analysisProgress.paused;await persistRoom(r);return w;
 }finally{activeWorkers.delete(r.id);frame.remove();}
}
async function finish(r,purpose){
 if(purpose!=='recipe'){q('#shellDialog').close();if(r.stage==='new'&&!r.error){r.analysisDeferred=false;r.allowAutoGemini=false;await persistRoom(r);scheduleAnalysis();toast('Đã xếp phân tích trên máy. Gemini chỉ gửi khi bạn chọn.');}else await openRoom(r.id,'analysis');return;}
 const w=await localAnalysis(r);await extractReferenceRecipe(r.id);
 for(let n=0;n<100&&recipeWork.has(r.id);n++)await new Promise(resolve=>setTimeout(resolve,50));
 if(window.SceneForgeStorage?.managed)await checkpoint();
 const lib=await recipeLibrary(),saved=lib.items.find(x=>x.id===r.referenceRecipeId);
 if(!saved)throw Error('Chưa lưu được khung sườn; nguồn và cảnh vẫn giữ trong phòng.');
 modal('Khung sườn đã lưu',`<div id="videoIntake"><p><b>${esc(saved.name)}</b></p><p>${w.scenes.length} cảnh · ${w.script?.length||0} câu có mốc.</p><p>${w.analysis?.semantic?.recipe?'Đã dùng kịch bản AI được áp dụng trong phòng.':'Hiện là khung theo mốc cảnh. Chưa hiểu đầy đủ nội dung, vai trò từng nhịp hoặc chuyển động.'}</p><p>Muốn AI rút cấu trúc: gửi lời/OCR và tối đa 8 ảnh đại diện qua nguồn Gemini đang chọn. Không gửi nguyên video; không tạo ảnh hay clip.</p><p id="viStatus" role="status"></p></div>`, '<button id="viOpenSaved">Mở trong Kho</button><button id="viUnderstand" class="primary">AI rút kịch bản · dùng hạn mức</button>');
 q('#viOpenSaved').onclick=async()=>{q('#shellDialog').close();await g6OpenRecipes();kv.selected=saved.id;await kvDraw();};
 if(w.analysis?.semantic?.recipe||saved.intakeAI)q('#viUnderstand').hidden=true;
 q('#viUnderstand').onclick=async()=>{
  const button=q('#viUnderstand');if(button.disabled)return;button.disabled=true;
  try{
   let req=r.recipeIntakeRequest;
   if(!req){
    const status=await engineRequest('ai/recipe-evidence/status');
    if(!confirm('Gửi ảnh đại diện và bản chữ tới '+(status.ai_source==='gemini_chat'?'Gemini Chat':'Gemini API (có thể tính phí)')+' theo Cài đặt? Không tạo ảnh/clip.'))return;
    const scenes=w.scenes.slice(0,100).map((s,i)=>({code:'S'+(i+1),start:s.start,end:s.end,ocr:(s.cpu?.ocr||[]).map(x=>x.text).slice(0,20),description:s.description||''}));
    const sampled=w.scenes.filter((s,i)=>i===Math.round((w.scenes.length-1)*Math.round(i*7/Math.max(1,w.scenes.length-1))/7)).slice(0,8);
    const pictures=[];for(const s of sampled){const image=(s.cpu?.evidence_frames||s.thumbs||[])[0];if(typeof image==='string'&&image.startsWith('data:image/'))pictures.push({code:'S'+(w.scenes.indexOf(s)+1),image});}
    const body={request_id:crypto.randomUUID(),ai_source:status.ai_source,room_id:r.id,duration:w.source?.duration||r.duration,scenes,lines:(w.script||[]).slice(0,200).map(l=>({start:l.start,end:l.end,text:l.original||''})),pictures};
    req=r.recipeIntakeRequest={body,store_id:status.store_id,state:'prepared'};await persistRoom(r);if(window.SceneForgeStorage?.managed)await checkpoint();
   }
   const recipeBefore=JSON.stringify((await recipeLibrary()).items.find(x=>x.id===saved.id));
   const recover=req.state!=='prepared';req.state='submitted';await persistRoom(r);message('Đang nhận kịch bản. Lượt đã gửi giữ nguyên mã, không tự tạo lượt mới.');
   const raw=await engineRequest('ai/recipe-evidence',{...req.body,expected_store_id:req.store_id,recovery:recover});
   const currentRecipe=(await recipeLibrary()).items.find(x=>x.id===saved.id);
   if(r.trashedAt||!currentRecipe||JSON.stringify(currentRecipe)!==recipeBefore){req.pendingRecipe=raw;req.state='review';await persistRoom(r);throw Error('Công thức đã đổi hoặc bị xóa trong lúc chờ. Đã giữ kết quả AI riêng, không ghi đè.');}
   await putRecipe({...raw,id:saved.id,source:'reference',sourceRoomId:r.id,sourceName:r.name,sourcePoster:r.poster,createdAt:saved.createdAt,metrics:saved.metrics||{},intakeAI:true,userEdited:true});
   req.state='received';delete req.body.pictures;await persistRoom(r);if(window.SceneForgeStorage?.managed)await checkpoint();message('Đã cập nhật khung sườn trong Kho. Không tạo ảnh/clip.');button.hidden=true;
  }catch(e){message(e.message+' · Nguồn và khung đã lưu vẫn còn.');button.textContent='Nhận lại lượt đã gửi';}finally{button.disabled=false;}
 };
}
// Capture before the old API-only recipe file picker and home reference action.
document.addEventListener('click',e=>{
 const target=e.target.closest('#createReference,[data-kv="import"],#g6VideoRecipe');if(!target)return;
 e.preventDefault();e.stopImmediatePropagation();open(target.id==='createReference'?'video':'recipe').catch(fail);
},true);
window.SceneForgeApp.videoIntake={open};
})();
