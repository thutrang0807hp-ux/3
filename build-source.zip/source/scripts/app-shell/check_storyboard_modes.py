"""Photo post nodes: real browser, media, storage and editor; zero provider jobs."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import subprocess,tempfile,socket,time,os,urllib.request,base64
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-photo-post-')as temp:
 video=Path(temp)/'clip.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=180x320:rate=12:duration=8','-c:v','libx264','-pix_fmt','yuv420p',str(video)],check=True)
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':str(Path(temp)/'data')},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=browser.new_page(viewport={'width':1600,'height':1050});errors=[];jobs=[]
   p.on('pageerror',lambda e:errors.append(e.stack));p.on('request',lambda req:jobs.append(req.url)if req.method=='POST'and any(x in req.url for x in ['/flow/jobs','/muse/jobs','/gemini-chat/jobs','/ai/'])else None)
   p.goto(base);p.wait_for_function('appBootReady&&SceneForgeStorage.state.active');p.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const row={id:'photo-post-test',name:'Kiểm node hậu kỳ',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(row);await persistRoom(row);await openRoom(row.id,'analysis')}''')
   wf=p.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoTransferDraft==="function"')
   from PIL import Image
   import io,json
   def png(color):
    out=io.BytesIO();Image.new('RGB',(180,320),color).save(out,format='PNG');return out.getvalue()
   start,end,new_start=png('red'),png('blue'),png('green');posts=[];records={};caps=[False];token=['choice-A']
   def provider_route(route):
    path=route.request.url.split('/local-api/')[1]
    if path.endswith('/status'):
     data={'configured':True,'installed':True,'account_binding':True,'models':['fixture-portrait'],'model_details':[{'id':'fixture-portrait',**({'sceneforge_inputs':{'transport':'ordered_images','first_image':'start','second_image':'end'}}if caps[0]else{})}],'selection':{'available':True,'token':token[0],'mode':'selected','account_name':'Fixture A'}}
    elif path.endswith('/jobs'):
     data=route.request.post_data_json;posts.append((path,data));records[data['request_id']]={'state':'submitted'};return route.fulfill(json={'state':'submitted'})
    elif '/jobs/'in path:data=records.get(path.rsplit('/',1)[-1],{'state':'unknown'})
    elif '/files/'in path:return route.fulfill(body=end,content_type='image/png')
    else:return route.continue_()
    route.fulfill(json=data)
   p.route('**/local-api/gemini-chat/**',provider_route);p.route('**/local-api/flow/**',provider_route)
   wf.evaluate('''async()=>{draft.voice={mode:'native'};draft.storyboardImages=[];delete draft.storyboardImage;draft.providers={creative:'gemini',video:'flow',flowModel:'fixture-portrait'};draft.beats=[0,1].map(i=>({id:'sb'+i,name:'Cảnh '+(i+1),type:'wide',seconds:4,text:'Lời cảnh '+i,visualPrompt:'Product on table',motionPrompt:'Slow camera push',manualDirections:true,clips:[]}));draft.post={...photoProduction(),captions:false,musicMode:'off'};await save();render();fit();}''')
   wf.evaluate('''async data=>{const f=new File([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],'identity.png',{type:'image/png'});await bridge.putFile('sb-identity',f);draft.refs={product:{images:[{id:'identity',key:'sb-identity',image:'data:image/png;base64,'+data}],description:'Product reference'}};await save();render();}''',base64.b64encode(start).decode())
   wf.wait_for_function('!!window.SFStoryboard');wf.locator('[data-sb=mode][data-mode=frames]').evaluate('b=>b.click()');wf.wait_for_function('draft.storyboardPlan.mode==="frames"')
   wf.locator('[data-sb-select="sb0:a"]').check();expect(wf.locator('[data-slot="sb0:a"][data-mode=pair]')).to_be_disabled()
   caps[0]=True;wf.evaluate('async()=>SFStoryboard.refresh()');expect(wf.locator('[data-slot="sb0:a"][data-mode=pair]')).to_be_enabled()
   wf.locator('[data-sb-select="sb0:a"]').check();wf.locator('[data-sb-select="sb1:a"]').check();wf.locator('[data-slot="sb0:a"][data-mode=pair]').click()
   def imported(slot,edge,data):return wf.evaluate('''async r=>SFStoryboard.importImage(r.slot,r.edge,new File([Uint8Array.from(atob(r.data),c=>c.charCodeAt(0))],r.edge+'.png',{type:'image/png'}))''',{'slot':slot,'edge':edge,'data':base64.b64encode(data).decode()})
   first=imported('sb0:a','start',start);last=imported('sb0:a','end',end)
   # Only ready selected scene is applied; incomplete scene remains unbound and gets skipped.
   p.on('dialog',lambda d:d.accept());wf.evaluate('async()=>SFStoryboard.apply()');assert wf.evaluate('draft.storyboardPlan.slots["sb0:a"].applied.end')==last['id'];assert wf.evaluate('draft.storyboardPlan.slots["sb1:a"].applied') is None
   refs=wf.evaluate('async()=>photoStoryboardVideoReferences(draft.beats[0],photoParts(draft.beats[0])[0],await bridge.engine("flow/status"),photoTools().flowModel)');assert base64.b64decode(refs[0]['data'])==start and base64.b64decode(refs[1]['data'])==end
   writing=wf.evaluate('async()=>photoWritingReferences(draft.beats)');assert any(base64.b64decode(r['data'])==end for r in writing)
   # Optional overview: all-authored prompts get local receipts without sending AI.
   wf.evaluate('async()=>photoPrepareStoryboard()');assert wf.evaluate('photoPromptsCurrent()') is True
   wf.evaluate('async()=>photoRunClips()');wf.locator('#photoConfirmFlow').click();wf.wait_for_function('draft.flowJobs.length===1&&draft.flowJobs[0].state==="submitted"');video_post=[body for path,body in posts if path=='flow/jobs'][0];assert video_post['scene_id']=='sb0' and video_post['part']=='a';assert video_post['frame_inputs']['start_id']==first['id'] and video_post['frame_inputs']['end_id']==last['id'];assert base64.b64decode(video_post['references'][0]['data'])==start and base64.b64decode(video_post['references'][1]['data'])==end
   assert wf.evaluate('draft.beats.every(b=>b.clips.length===0)')
   # No silent downgrade when switching to an unknown model contract.
   caps[0]=False;wf.evaluate('async()=>SFStoryboard.refresh()');reason=wf.evaluate('async()=>photoStoryboardVideoInputs(draft.beats[0],photoParts(draft.beats[0])[0],await bridge.engine("flow/status"),photoTools().flowModel).error');assert 'không hỗ trợ' in reason
   caps[0]=True;wf.evaluate('async()=>SFStoryboard.refresh()')
   # New start version makes previous end stale; neither selection nor generation silently replaces applied version.
   newer=imported('sb0:a','start',new_start);assert wf.evaluate('draft.storyboardPlan.slots["sb0:a"].applied.start')==first['id'];reason=wf.evaluate('async()=>photoStoryboardVideoInputs(draft.beats[0],photoParts(draft.beats[0])[0],await bridge.engine("flow/status"),photoTools().flowModel).error');assert reason is None  # applied old pair remains explicitly in use
   wf.evaluate('SFStoryboard.inspect("sb0:a","end")');expect(wf.locator('.sbInspect .sbWarn')).to_contain_text('cặp ảnh trước');wf.locator('#closePhotoDialog').click()
   rejected=wf.evaluate('async()=>{try{await SFStoryboard.apply();return null}catch(e){return e.message}}');assert rejected
   # Restore exact compatible pair; edit another scene only affects that scene's image validity.
   wf.evaluate('(id)=>draft.storyboardPlan.slots["sb0:a"].chosen.start=id',first['id']);before=wf.evaluate('photoSceneSignature(draft.beats[0],photoParts(draft.beats[0])[0])');wf.evaluate('draft.beats[1].text="Nội dung mới của riêng cảnh 2"');assert wf.evaluate('photoSceneSignature(draft.beats[0],photoParts(draft.beats[0])[0])')==before
   # Explicit batch image submission, recovery, and no replay of unknown job.
   wf.evaluate('async()=>SFStoryboard.create({slot:"sb1:a",edge:"start"})');wf.locator('#sbSendConfirm').click();wf.wait_for_function('draft.geminiJobs.some(j=>j.productionRole==="storyboard-keyframe"&&j.state==="submitted")&&!SFStoryboard.isBusy()');jobid=wf.evaluate('draft.geminiJobs.find(j=>j.productionRole==="storyboard-keyframe").id');image_count=len([1 for path,_ in posts if path=='gemini-chat/jobs']);wf.evaluate('async()=>{try{await SFStoryboard.create({slot:"sb1:a",edge:"start"})}catch{}}');assert len([1 for path,_ in posts if path=='gemini-chat/jobs'])==image_count
   records[jobid]={'state':'done','result':{'mime_type':'image/png','account_id':'fixture'}};wf.evaluate('async()=>SFStoryboard.recover()');assert wf.evaluate('draft.storyboardPlan.slots["sb1:a"].images.start.length')==1,wf.evaluate('draft.geminiJobs.filter(j=>j.productionRole==="storyboard-keyframe").map(j=>({state:j.state,error:j.error,stale:j.stale}))');assert wf.evaluate('draft.storyboardImages.length')==0
   # Mode switching retains both separate stores and does not copy keyframes into overview.
   wf.locator('[data-sb=mode][data-mode=overall]').evaluate('b=>b.click()');wf.wait_for_function('draft.storyboardPlan.mode==="overall"');wf.locator('[data-sb=mode][data-mode=frames]').evaluate('b=>b.click()');wf.wait_for_function('draft.storyboardPlan.mode==="frames"');assert wf.evaluate('draft.storyboardPlan.slots["sb0:a"].images.start.length')==2
   wf.evaluate('photoToolbarFocus("storyboard")');wf.locator('#photoViewport').screenshot(path=str(r/'artifacts/storyboard-modes.png'))
   assert not errors,errors
   print('PASS one storyboard node/two preserved modes, per-model end capability lock, actual PNG start/end order in video preflight, durable exact scene/part/frame ids, partial apply skips missing, no-overview manual prompt path, compatible pair versions, scene-local staleness, own image jobs/recovery without replay or overview pollution; fixture services only')
   browser.close()
 finally:
  proc.terminate();proc.wait(timeout=10)
