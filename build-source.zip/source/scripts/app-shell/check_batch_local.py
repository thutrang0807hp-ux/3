"""Batch results use the real library checkpoint and restore into a new browser profile."""
import os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-batch-library-',dir='/tmp')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp},stdout=subprocess.PIPE,stderr=subprocess.PIPE);base=f'http://127.0.0.1:{port}/#batch'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base.split('/#')[0]+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);context=browser.new_context();page=context.new_page();calls=[];errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append((r.method,r.url)));page.goto(base);expect(page.locator('#batchStudio')).to_be_visible();page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();if(document.querySelector('#shellDialog').open)document.querySelector('#shellDialog').close();}''');page.locator('#batchPrompts').fill('Cảnh lưu 1\nCảnh lưu 2');page.locator('#batchPrompts').dispatch_event('input');page.locator('#batchEnqueue').click();page.wait_for_function('batchState.jobs.length===2');page.locator('[data-image-resume]').click();page.wait_for_function('batchState.jobs.every(j=>j.status==="done")',timeout=20000);page.evaluate('batchImageFlush()');snapshot=page.evaluate('SceneForgeStorage.api("snapshot")');assert any(r['key']=='batch-studio-v1'for r in snapshot['records']);assert page.evaluate('SceneForgeStorage.api("status")')['assets']>=2
   context.close();context=browser.new_context();page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);page.wait_for_function('batchState?.jobs.length===2&&batchState.jobs.every(j=>j.status==="done")');assert page.evaluate('batchState.paused&&batchWorkers.size===0');assert page.evaluate('''async()=>{const file=await io('files','readonly',batchState.jobs[0].resultKey);return file instanceof Blob&&file.type==='image/png'&&file.size>1000;}''')
   # Batch trash and restoration persist in the actual SQLite library, not just this profile.
   saved=page.evaluate('batchState.jobs.map(j=>({id:j.id,key:j.resultKey}))');page.evaluate('async id=>{await batchImageRemove([id],false);await batchImageFlush();}',saved[0]['id']);context.close();context=browser.new_context();page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);page.wait_for_function('(id)=>batchState?.jobs.some(j=>j.id===id&&j.trashedAt)',arg=saved[0]['id']);page.evaluate('hubOpen("trash")');expect(page.locator('[data-hub-row="batch:'+saved[0]['id']+'"]')).to_be_visible();page.locator('[data-hub-restore="batch:'+saved[0]['id']+'"]').click();page.wait_for_function('(id)=>!batchState.jobs.find(j=>j.id===id).trashedAt',arg=saved[0]['id']);page.evaluate('batchImageFlush()');assert page.evaluate('async k=>!!await io("files","readonly",k)',saved[0]['key'])
   assert not [u for method,u in calls if method!='GET'and('/local-api/ai/'in u or '/local-api/export/'in u)],calls;assert not errors,errors;browser.close();print('PASS real SQLite batch metadata + PNG asset checkpoint; fresh browser profiles restore jobs/files plus batch trash and restore; no automatic restart/provider submission.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
