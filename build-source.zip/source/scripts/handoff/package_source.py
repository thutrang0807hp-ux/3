"""Package the editable application and assets; verify every member and a clean rebuild.
Inputs are an earlier full snapshot (asset fallback), current workspace, and optional design uploads.
No runtime environments, accounts, model weights, installer executables or nested app backups.
"""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse,hashlib,json,tempfile,subprocess

ROOT=Path(__file__).resolve().parents[2]
PAGES=['index.html','studio.html','workflow.html','photos.html','native/index.html','storage-demo.html','batch-design-demo.html']
EXCLUDE={'.git','.venv','venv','node_modules','__pycache__','.sceneforge-local','downloads'}

def acceptable(name):
    p=Path(name)
    return not p.is_absolute() and '..'not in p.parts and not(EXCLUDE & set(p.parts)) and p.suffix not in {'.pyc','.pyo'} and p.name not in {'.DS_Store','MANIFEST-SHA256.json','.env'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--attachments',type=Path)
    ap.add_argument('--windows-release',type=Path)
    args=ap.parse_args()
    files={}
    with ZipFile(args.base)as z:
        for n in z.namelist():
            if n.endswith('/'):continue
            relative=n.split('/',1)[1]
            if acceptable(relative):files[relative]=z.read(n)
    # Current editable code is authoritative; the old snapshot fills assets only.
    for folder in ['scripts','local_engine','docs','design','dist']:
        for p in (ROOT/folder).rglob('*'):
            if p.is_file()and acceptable(p.relative_to(ROOT).as_posix()):files[p.relative_to(ROOT).as_posix()]=p.read_bytes()
    files['docs/history/README-before-handoff.md']=(ROOT/'README.md').read_bytes()
    for legacy in ['BAT-DAU-TU-DAY.md','VE-BAN-SAO-LUU-NAY.txt']:
        if legacy in files:files['docs/history/'+legacy]=files.pop(legacy)
    for filename in ['README.md','BAT-DAU-TU-DAY.md','NGU-CANH-BAN-GIAO.md']:
        files[filename]=(ROOT/'scripts/handoff'/filename).read_bytes()
    logs=['prompt-pipeline-browser.log','photo-prompt-pipeline-browser.log','prompt-photo-production.log','prompt-storyboard-modes.log','prompt-meta-storyboard.log','prompt-photo-clips.log','prompt-workspace-automation.log','prompt-photo-merge.log','prompt-photo-input.log','prompt-focused-preview.log','prompt-meta-preview.log']
    for name in logs:
        body=(ROOT/'artifacts'/name).read_bytes();assert b'PASS'in body and b'Traceback'not in body,name
        files['docs/checks/'+name]=body
    win=ROOT/'artifacts/windows/windows-check-report-final.json'
    report=json.loads(win.read_text(encoding='utf-8-sig'));assert report['passed']
    files['docs/checks/windows-check-report.json']=win.read_bytes()
    files['docs/windows-check-report.json']=win.read_bytes()
    files['docs/checks/windows-build-report.json']=(ROOT/'artifacts/windows/build-report.json').read_bytes()
    if args.windows_release:files['releases/windows-release.json']=args.windows_release.read_bytes()
    supplied=[]
    if args.attachments:
        for p in sorted(args.attachments.rglob('*')):
            if not p.is_file()or p.name not in {'DAC_TA_NODE.md','DAC_TA_NODE_KICH_BAN.md','SceneForge_KhoKichBan_v4.zip','SceneForge_KhoKichBan_v5.zip'}:continue
            data=p.read_bytes();h=hashlib.sha256(data).hexdigest();name='design/original-uploads/'+h[:12]+'/'+p.name
            if name in files:continue
            files[name]=data;supplied.append({'path':name,'sha256':h,'status':'pending; user paused v5'if'_v5.zip'in p.name else'design reference; compare implemented code'})
    files['design/original-uploads/INDEX.json']=json.dumps(supplied,ensure_ascii=False,indent=2).encode()
    # Old model notes describe a past verification environment, not bundled weights.
    old='docs/whisper-model-integration.md'
    if old in files:files[old]=('> Bàn giao 28/10/2026: gói code này không có model Whisper. Nội dung dưới đây ghi lại thử nghiệm lịch sử; kiểm capabilities trên máy đích và cài model riêng.\n\n').encode()+files[old]
    manifest={'snapshot':datetime.now(ZoneInfo('Asia/Bangkok')).isoformat(),'kind':'editable source handoff','pending_features':['Kho kich ban v5 - explicitly paused'],'excluded':['model weights','Python/Node environments','personal accounts/cookies/keys','user project data','installer EXE (download link supplied separately)'],'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(files.items())]}
    files['MANIFEST-SHA256.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    temporary=args.output.with_suffix('.tmp')
    with ZipFile(temporary,'w',ZIP_DEFLATED,compresslevel=9)as z:
        for n,b in sorted(files.items()):z.writestr('SceneForge-Code-DayDu/'+n,b)
    temporary.replace(args.output);args.output.chmod(0o644)
    with ZipFile(args.output)as z:
        assert z.testzip()is None
        for row in manifest['files']:
            data=z.read('SceneForge-Code-DayDu/'+row['path']);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
        with tempfile.TemporaryDirectory(prefix='sf-code-handoff-')as tmp:
            z.extractall(tmp);project=Path(tmp)/'SceneForge-Code-DayDu'
            subprocess.run(['python','scripts/demo-web/build.py'],cwd=project,check=True,capture_output=True)
            for name in PAGES:assert(project/'dist/web-demo'/name).read_bytes()==(ROOT/'dist/web-demo'/name).read_bytes(),name
            for p in project.rglob('*.py'):
                if any(part in EXCLUDE for part in p.parts):continue
                compile(p.read_bytes(),str(p),'exec')
    sha=hashlib.sha256(args.output.read_bytes()).hexdigest();args.output.with_suffix('.zip.sha256').write_text(sha+'  '+args.output.name+'\n')
    result={'file':args.output.name,'bytes':args.output.stat().st_size,'sha256':sha,'files':len(files),'verification':['ZIP CRC','every member length and SHA-256','clean extracted rebuild of seven production pages','Python source compilation'],'windows_installer_sha256':report['installer_sha256'],'windows_runtime_check_passed':True,'pending_v5_preserved':any('_v5.zip'in n for n in files)}
    args.output.with_suffix('.report.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
