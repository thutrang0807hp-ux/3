/* Same source/timing guards as the reviewed analysis path; initial automatic-run consent owns adoption. */
window.applyAutomaticAnalysis=async function(pending){
 if(project.id!==pending.id||project.source?.asset!==pending.sourceAsset||analysisEditSignature()!==pending.editSignature)throw Error('Dữ liệu đã đổi khi phân tích; cần rà kết quả.');
 const data=pending.result;if(data.partial||data.can_apply!==true||data.warnings?.length||data.scenes.length!==project.scenes.length)throw Error('Kết quả phân tích chưa đầy đủ; cần rà trước khi tiếp tục.');
 if(!data.scenes.every(s=>s.visual?.en&&s.motion?.en&&s.promptFrame?.en?.trim()))throw Error('Thiếu chỉ dẫn cảnh. Không chạy bằng prompt mẫu.');
 importAnalysis(data);for(let i=0;i<project.scenes.length;i++)for(const k of ['hasPerson','faceTalking','hasProduct','competitorLogo'])if(typeof data.scenes[i][k]==='boolean')project.scenes[i][k]=data.scenes[i][k];
 delete project.analysis.pendingAI;project.analysis.semantic={provider:data.provider||'Gemini',at:Date.now(),status:'review',speech:data.contract?'Lời cục bộ':'Lời do AI nhận',recipe:data.recipe||null};
 if(data.contract){project.analysis.workflowVersion=3;project.analysis.frameQualityRequired=true;}if(typeof cpuCrossCheck==='function'){cpuCrossCheck();cpuUseOriginalFrames();}project.demo=false;await storeProject();render();
};
