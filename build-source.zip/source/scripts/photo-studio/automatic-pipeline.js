/* Initial Run consent advances existing guarded send/recovery routines; never exports. */
(()=>{
let running=false,stopped=false,owner=null,tools=null,accounts=new Map();
const sleep=()=>new Promise(ok=>setTimeout(ok,1000));
function ensure(){if(stopped||room.id!==owner||JSON.stringify(photoTools())!==tools)throw Error('Đã tạm dừng; giữ các lượt đã gửi để nhận lại.');}
async function phase(text){ensure();draft.automaticRun.phase=text;await save();render();}
async function source(path){ensure();const s=await bridge.engine(path);if(!s.configured||!s.selection?.available||s.installed===false)throw Error('Nguồn chưa sẵn sàng: '+path);const old=accounts.get(path);if(old&&old!==s.selection.token)throw Error('Tài khoản đã đổi; dừng gửi mới.');accounts.set(path,s.selection.token);return s;}
const jobs=()=>[...(draft.geminiJobs||[]),...(draft.flowJobs||[])];
async function receive(){ensure();await photoWorkflowReceive();ensure();}
async function settle(){
 // Read existing jobs before considering any new send. Unknown/error never triggers replay.
 for(;;){await receive();const pending=jobs().filter(j=>SFProviderReceipts.pendingStates.includes(j.state)&&!j.stale);if(!pending.length)return;const bad=pending.find(j=>!['prepared','preparing','submitted','queued','running','downloading','done'].includes(j.state)||j.error);if(bad)throw Error(bad.error||'Lượt '+bad.id+' chưa rõ kết quả. Không gửi lại.');await sleep();}
}
function priorFailure(){const latest=new Map();for(const j of jobs())latest.set([j.provider||j.imageSource||'gemini',j.productionRole||j.role||j.kind,j.beatId||'',j.slot||'',j.part||'',j.edge||''].join(':'),j);const bad=[...latest.values()].find(j=>j.stale||['failed','invalid','unknown','missing','not_submitted'].includes(j.state));if(bad)throw Error(bad.error||'Có lượt cũ cần kiểm tra; chưa tự tạo lại.');}
async function storyboard(){
 const plan=draft.storyboardPlan??={mode:'overall',slots:{}};
 if(plan.mode==='frames'){
  await SFStoryboard.refresh();let sum=SFStoryboard.summary();if(!sum.selected.length)throw Error('Chọn cảnh cần ảnh trong Storyboard trước.');
  while(sum.ready<sum.total){ensure();priorFailure();await source(photoImageStatusPath());await SFStoryboard.createAutomatically(null,{guard:ensure});await settle();sum=SFStoryboard.summary();if(sum.failed)throw Error('Ảnh cảnh lỗi; giữ các ảnh đã xong.');}
  await SFStoryboard.apply();
 }else if(!plan.skipOverall){
  const oldJob=draft.geminiJobs?.find(j=>j.id===photoOverall()?.requestId),overviewInput=SFStoryboard.overallInput();if(!photoOverall()||oldJob?.overviewInput&&oldJob.overviewInput!==overviewInput){await source(photoImageStatusPath());await photoGchatSubmit('image',photoOverallImagePrompt(),'image',{automatic:true,guard:ensure,overviewInput});await settle();if(!photoOverall())throw Error('Chưa nhận được storyboard tổng.');}
  // A source change invalidates an existing overall; do not silently endorse it.
  const job=draft.geminiJobs?.find(j=>j.id===photoOverall()?.requestId);if(job?.stale)throw Error('Storyboard thuộc dữ liệu cũ; kiểm tra trước khi dùng.');
 }
}
async function run(scope){
 if(running)throw Error('Đang chạy.');if(!['analysis','frames','clips'].includes(scope))throw Error('Phạm vi không hợp lệ.');running=true;stopped=false;owner=room.id;tools=JSON.stringify(photoTools());accounts=new Map();draft.automaticRun={scope,state:'running',phase:'Chuẩn bị',startedAt:Date.now()};
 try{
  await SFPhotoScript.apply();if(!draft.beats.length)throw Error('Dán kịch bản trước.');if(scope==='analysis')return{message:'Đã giữ kịch bản và chia cảnh trên máy.'};
  photoRequireProduct();if(draft.beats.length>30)throw Error('Tối đa 30 cảnh cho một lượt tự động.');await phase('Nhận các lượt đã gửi');await settle();priorFailure();if(!photoPromptsCurrent())await source('gemini-chat/status');if(scope==='clips'&&photoDraftCounts().ready<photoDraftCounts().total){const status=await source((photoTools().video==='muse'?'muse':'flow')+'/status');if(photoTools().video==='flow'&&(!status.account_binding||!status.models?.includes(photoTools().flowModel)))throw Error('Chọn model và tài khoản Flow hợp lệ trước.');}
  await phase('Chuẩn bị storyboard theo chế độ đã chọn');await storyboard();ensure();
  if(!photoPromptsCurrent()){await phase('Gemini viết prompt từ kịch bản và ảnh đang dùng');await source('gemini-chat/status');await photoPrepareStoryboard({automatic:true,guard:ensure});await settle();if(!photoPromptsCurrent())throw Error('Prompt chưa khớp đầu vào hoặc có sửa tay cần giữ.');}
  if(scope==='frames')return{message:'Đã chuẩn bị ảnh và prompt. Dừng trước tạo clip.'};
  let counts=photoDraftCounts();while(counts.ready<counts.total){await phase('Tạo clip · '+counts.ready+'/'+counts.total);priorFailure();await source((photoTools().video==='muse'?'muse':'flow')+'/status');await photoRunClips(null,{automatic:true,guard:ensure});await settle();const next=photoDraftCounts();if(next.ready<=counts.ready)throw Error('Clip cần rà hoặc chưa đủ điều kiện nối; không tự gửi lại.');counts=next;}
  return{message:'Đã nhận đủ clip. Xem cả bản ghép trước khi xuất.'};
 }catch(e){draft.automaticRun.state=stopped?'paused':'attention';draft.automaticRun.error=e.message;throw e;}finally{if(draft.automaticRun.state==='running')draft.automaticRun.state='done';running=false;await save();render();}
}
const oldScript=scriptNode;scriptNode=function(){const html=oldScript();return draft.automaticRun?html.replace('<section class="body">','<section class="body"><p class="productionStatus">Tự động: '+esc(draft.automaticRun.phase)+(draft.automaticRun.error?' · '+esc(draft.automaticRun.error):'')+'</p>'):html;};
document.addEventListener('input',e=>{if(running&&e.target.matches('textarea,input:not([type=range]),select'))stopped=true;},true);
const api=SceneForgeWorkflow,flush=api.flushRoom;api.pausePromptAutomatic=()=>{stopped=true;};api.flushRoom=async(...args)=>{if(running)throw Error('Tạm dừng tự động trước khi đổi phòng.');return flush(...args);};
window.SFPhotoPromptPipeline={run,isRunning:()=>running,pause:()=>{stopped=true;}};
})();
