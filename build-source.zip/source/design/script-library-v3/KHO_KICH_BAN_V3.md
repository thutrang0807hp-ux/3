# SceneForge · Kho kịch bản · bản sửa (chốt 24/10/2026)

> Sửa **bản đang code** của tab Kịch bản. Ảnh: `kho-kich-ban-v3.png` (ảnh to là màn hình chính; dưới là bên phải khi chưa chọn gì và hộp Ghi kết quả). Số trong ảnh là ví dụ.
> Luật: không nút giả, không bịa số. Số đơn / lượt xem chỉ lấy từ chỗ người dùng ghi, không tự đoán.

## 1. Bố cục 3 cột
`[Cột nhóm] [Danh sách công thức] [Chi tiết]`

## 2. Cột nhóm (trái)
- **⭐ Đã đạt** ở trên cùng, rồi **Tất cả**.
- **📥 Chờ xếp nhóm** (nổi màu vàng, có số):
  - Khung sườn tự lưu từ video mẫu vào đây trước, **không đổ thẳng vào kho**.
  - AI gợi ý sẵn nhóm, người dùng bấm 1 lần để xếp. Có thể xếp nhiều cái cùng lúc.
- **CHỦ ĐỀ** (＋ thêm, nháy đúp để đổi tên, kéo để đổi thứ tự). Ví dụ: Hỏi → giải đáp vấn đề · Review · Trước / sau · Show sản phẩm không lời · Unbox.
- **THEO SẢN PHẨM**: chấm màu + tên. Một công thức thuộc **1 chủ đề** và có thể gắn **nhiều sản phẩm**.
- **🗑 Thùng rác** ở đáy, khôi phục được. Tự xóa hẳn sau 30 ngày.

## 3. Danh sách công thức (giữa)
- Đầu cột: ô tìm (tìm theo tên và theo câu mẫu) · Sắp xếp (Hiệu quả ▾ / Mới dùng / Tên) · **＋ Thêm ▾** (Tự gõ / Từ video bạn chọn).
- **Công thức ✓ Đạt luôn ở trên** (mục "ĐÃ ĐẠT · luôn ở trên"), rồi tới "ĐANG THỬ · MỚI".
- **Thẻ công thức:**
  - Nhãn trạng thái: ✓ Đạt / ● Đang thử / Mới / Bỏ.
  - Tên.
  - Nhãn chủ đề.
  - **Tỉ lệ ra đơn** (ví dụ 4/9), số lần dùng, lần dùng cuối, ⭐ điểm AI.
  - Dải màu nhịp.
- **Rê chuột lên thẻ** thì hiện nút ngay trên thẻ: **✓ Đánh dấu đạt · ⧉ Nhân bản · 🗑 Xóa** (vào Thùng rác).
- **Trạng thái:**
  - Đạt: người dùng bấm.
  - Đang thử: đã dùng ít nhất 1 lần nhưng chưa đạt.
  - Mới: chưa dùng.
  - Bỏ: người dùng bấm, ẩn khỏi gợi ý.

## 4. Chi tiết (phải)
### 4.1 Khi chưa chọn gì: tổng quan (không để trống)
- 4 con số: số công thức · đạt · đang thử · chờ xếp nhóm.
- 🏆 **Ra đơn nhiều nhất**: top 3, kèm tỉ lệ.
- ✍️ **Chờ bạn ghi kết quả**: những lần dùng chưa ghi, mỗi dòng có nút ＋ Ghi.
- 📥 **Chờ xếp nhóm**: nút Xếp ngay.

### 4.2 Khi chọn 1 công thức: chế độ xem
- **Đầu:**
  - Nhãn trạng thái, chủ đề, ngành.
  - Tên to.
  - Thời lượng · số nhịp · nguồn.
  - Nút **Dùng công thức này · ✎ Sửa · ⧉ Nhân bản · 🗑 Xóa**.
- **4 con số:** lần ra đơn (x/y) · lần dùng · tổng đơn (người dùng ghi) · ⭐ AI chấm.
- **Tab:** Nhịp · **Lịch sử dùng** · Ghi chú.
  - **Nhịp:** dải thẻ nhịp có màu (tên + số giây). Bấm vào nhịp thì hiện mục đích, kiểu cảnh, góc máy, câu mẫu.
  - **Lịch sử dùng:** mỗi lần dùng 1 dòng: ngày · video (bấm để mở phòng) · sản phẩm · kết quả người dùng ghi · 👍 Ra đơn / 👎 Không ăn thua · Sửa. Lần chưa ghi thì tô nền vàng nhạt, có nút **＋ Ghi kết quả**.
- **✎ Sửa** mới mở ô nhập (thay cho form dài đang có). Ô nhập chia theo từng nhịp, gập / mở được.

### 4.3 Hộp "Ghi kết quả" (10 giây là xong)
- Video (tự điền) · Kết quả: **👍 Ra đơn / 😐 Tạm / 👎 Không ăn thua** · Số đơn (tùy chọn) · Lượt xem (tùy chọn) · Ghi chú.
- Chỉ bấm 👍/👎 cũng được. Nút Để sau / Lưu.
- Hộp này cũng mở từ thẻ **Đã xuất** ở trang chủ và từ thông báo nhắc (vài ngày sau khi xuất).

## 5. Điểm và sắp xếp "Hiệu quả"
- Thứ tự ưu tiên: **kết quả người dùng ghi (👍/👎, số đơn)** > chỉ số tự nhập (lượt thích, CTR) > ⭐ điểm AI.
- Điểm AI do Gemini chấm theo tiêu chí: 3 giây đầu giữ người xem, lợi ích rõ, có kêu gọi mua, độ dài hợp lý. Chỉ dùng để lọc khi chưa có kết quả thật.

## 6. Dữ liệu (thêm vào SQLite, xem `SceneForge_LuuTru.md`)
- `formula`: thêm `status`, `topic_id`, `product_ids[]`, `ai_score`, `deleted_at`.
- `topic`: id, tên, thứ tự.
- `formula_use`: id, formula_id, room_id, ngày, kết quả (up / mid / down / null), số đơn, lượt xem, ghi chú.

## 7. Ý tưởng học từ đâu
Cách các công cụ quản lý prompt (ví dụ Langfuse) làm: **nhãn trạng thái · lịch sử từng lần dùng · chấm điểm theo kết quả thật**. Chỉ học ý, không cài repo.
- https://langfuse.com/docs/prompt-management/features/prompt-version-control
