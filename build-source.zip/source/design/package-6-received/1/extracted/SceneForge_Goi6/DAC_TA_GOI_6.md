# SceneForge · Gói 6 · Trang chủ (sửa) · Video mới · Video chưa phân tích · Tab Tạo video gộp 1 màn (22/10/2026)

> Làm theo **bản đang code**, sửa những chỗ chưa ổn. Ảnh trong `anh-thiet-ke/`. Tên, số trong ảnh là **ví dụ**.
> Gói này **ghi đè** những chỗ khác nhau ở gói 4 mục 2, gói 1 và gói 5 mục 7 (ô Ảnh khung, ô Video Veo).
> Luật chung giữ nguyên: không nút giả, không bịa số, không lưu key dạng chữ thường.

## 1. Trang chủ (ảnh 01)
### 1.1 Tùy chỉnh sản phẩm
- Rê chuột lên một sản phẩm thì hiện nút **⋯**. Menu gồm:
  - Đổi tên
  - Đổi màu (6 màu)
  - Thêm ảnh vào bộ ảnh
  - Gộp vào sản phẩm khác…
  - Lưu trữ sản phẩm (ẩn khỏi danh sách, không xóa gì)
  - Xóa sản phẩm…
- **Nháy đúp tên** để đổi tên ngay tại chỗ. Enter để lưu, Esc để hủy. **Kéo ⋮⋮** để đổi thứ tự.
- **Hộp Xóa sản phẩm:**
  - Hiện trước sẽ mất gì: số video / phòng, bộ ảnh, clip bộ cảnh, dung lượng (đo thật).
  - Hai lựa chọn: **Chuyển video sang sản phẩm khác** (mặc định), hoặc **Xóa hết**. Xóa hết thì đưa vào Thùng rác của máy, khôi phục được trong 30 ngày.
  - **Video đã xuất trong `7-xuat/` luôn được giữ lại.**
  - Có nút phụ "Lưu trữ thay vì xóa".
- Cạnh tên sản phẩm: nhãn vàng là số việc cần bạn. Không có việc gì thì hiện số video.

### 1.2 Thả nhiều video (ví dụ 5 video)
- Tạo ngay **5 phòng**, tên tự đánh số nối tiếp (Son · mẫu 7…11). Mỗi phòng một thư mục (gói 3, mục 3).
- Cột *Đang chuẩn bị* gom thành **nhóm "🆕 5 video vừa thả"**. Mỗi dòng ghi trạng thái thật:
  - Đang phân tích · bước…
  - Xếp hàng · thứ n
  - **Phân tích tối đa 2 video cùng lúc.**
- **Thông báo nhỏ** góc phải: "Đã nhận 5 video → 5 phòng trong Son". Tự ẩn sau vài giây.
- **Thả khi đang ở "Tất cả":** hiện bảng chọn sản phẩm cho tất cả hoặc từng video. Có AI gợi ý theo tên file và hình đầu video, kèm nút ＋ Sản phẩm mới. **Thả khi đang ở trong 1 sản phẩm thì không hỏi.**
- Dải gạch dưới đáy trang: "Thả 1 hay nhiều video vào đây · mỗi video thành 1 phòng trong <sản phẩm>".

### 1.3 Kho kịch bản ở đâu
- Thêm mục **📚 Kịch bản** cố định trên thanh trái. Bấm vào là mở kho **toàn màn hình**: xem, tìm, sửa, xóa công thức của mọi sản phẩm.
- Ô **Công thức** trong tab Từ ảnh vẫn mở **cùng kho đó**, dạng bảng nổi để chọn.
- Kho tự có công thức mới mỗi khi một video mẫu phân tích xong. 👍 Ra đơn / 👎 Không ăn thua trên thẻ đã xuất được tính vào kho.

### 1.4 Sửa lỗi trong bản đang code
- Các dòng **"Flow · trạng thái minh họa"** và **"Chờ dò cảnh cục bộ"** đang là chữ tạm. Phải đổi thành **trạng thái thật** (đang làm gì, thứ mấy), không để chữ minh họa.

## 2. Hộp "＋ Video mới" (ảnh 02)
- Vẫn **2 lựa chọn**: Từ video mẫu · Từ ảnh sản phẩm.
- Dòng đầu: **"Video mới trong <sản phẩm> · đổi ▾"**. Ở "Tất cả" thì dòng này thành "Chọn sản phẩm ▾".
- Mô tả theo tình huống, bỏ chữ kỹ thuật ở dòng chính:
  - "Có video đối thủ → làm lại với người và sản phẩm của bạn"
  - "Chưa có video mẫu → làm từ ảnh + công thức trong Kho kịch bản"
- **Chip nhỏ:** "chọn được nhiều file", "tốn credit Flow khi tạo clip" / "dùng bộ ảnh của <sp>", "tốn lượt Muse".
- Bấm "Từ video mẫu" là **mở hộp chọn file ngay** (chọn nhiều), không có bước giữa.
- Dòng nhắc "Hoặc kéo thả video thẳng vào trang". Phím tắt V / A.
- **Chưa kết nối Flow:** không khóa nút. Hiện "⚠ Chưa kết nối Flow · Kết nối · vẫn phân tích được".

## 3. Video đã thả nhưng chưa phân tích xong (ảnh 03)
Mỗi dòng video có **dải 4 bước**: Cắt cảnh · Chép lời · Đọc chữ · Gemini. Màu: xanh lá xong · xanh dương đang chạy · vàng chờ bạn · xám chưa tới.

| # | Tình huống | Hiện gì | Nút |
|---|---|---|---|
| 1 | Vừa thả | Tự phân tích luôn | ⏸ Để sau |
| 2 | Đợi tới lượt | Xếp hàng · thứ n | ⏸ Để sau |
| 3 | Người dùng bấm ⏸ | Chưa phân tích · bạn để sau | ▶ Phân tích |
| 4 | Chưa có key / key lỗi | Bước trên máy vẫn xong, chỉ chờ bước Gemini | Thêm key |
| 5 | Tắt app khi đang chạy | Mở lại thì tự chạy tiếp từ bước dở. Bước đã xong giữ nguyên | — |

- Phân tích không tốn credit nên **được tự chạy lại** sau khi mở app. Việc Flow / Veo thì **không** tự chạy lại (giữ luật cũ).
- **Mở phòng lúc đang phân tích:** Video tham khảo xem được ngay, ô Phân tích hiện tiến độ, các ô sau **mờ** và ghi "Chờ phân tích xong".

## 4. Tab Tạo video · gộp 1 màn (ảnh 04, 05)
### 4.1 Bố cục, đọc từ trái sang phải
1. **Video tham khảo** (🔒 chỉ lưu trên máy) → **Phân tích**
   - 5 bước làm trên máy, gắn nhãn "máy": cắt cảnh, chép lời, đọc chữ, chuyển động máy quay, báo cảnh mờ.
   - 1 bước Gemini.
   - Chỗ lệch giữa Gemini và máy thì báo vàng.
   - "✓ Đã lưu công thức vào Kho kịch bản".
2. Dưới Phân tích là **Kịch bản → Giọng đọc**.
3. **Các cảnh**: ảnh nhỏ, mốc giây, có người / không người, nhãn "mờ". Nhiều cảnh thì cuộn. Dưới là **Ảnh tham chiếu**.
4. **Ảnh khung** → **Video Veo** → **Sang Dựng** (ghép sẵn / tự ghép, chữ & nhạc).
- **Thanh trên:**
  - Dòng 1: Phòng ▾, Tạo video / Dựng, Hàng chờ.
  - Dòng 2: Từ video mẫu / Từ ảnh, thanh 4 chặng ghi rõ chặng đang ở, ví dụ "Duyệt khung · 8 chờ · 2 lỗi".
- **Thanh dưới:** số cảnh · số clip · Credit Flow đã xác minh · tài khoản · ước tính credit, kèm nút **"✓ Duyệt hết khung đạt & tạo clip"**.
- Bản đồ nhỏ, zoom ở góc phải dưới.

### 4.2 Ô Ảnh khung và Video Veo khi nhiều cảnh
- **Lưới ảnh nhỏ 9:16** (6 cột) thay cho danh sách dài. Mỗi ảnh có chấm trạng thái:
  - ✓ xanh lá: đạt
  - ! vàng: cần xem (nhãn mờ, khung mờ…)
  - ✕ đỏ: lỗi, ghi lý do ngắn
  - ● xanh dương: đang tạo
  - …: xếp hàng
- **Có lỗi thì cả viền ô chuyển đỏ** + dải "✕ n khung lỗi · Xem lỗi" ở đầu ô. Ảnh lỗi có viền đỏ riêng.
- Dòng đếm: đạt · cần xem · lỗi · đang tạo. **Lọc:** Tất cả / Lỗi / Cần xem / Chờ duyệt.
- **Làm hàng loạt:**
  - Ảnh khung: **"✓ Duyệt hết n khung đạt"** và **"↻ Tạo lại n khung lỗi"**.
  - Video Veo: **"✓ Nhận hết n clip đạt"** và **"↻ Tạo lại n clip lỗi · x credit"**. Tạo lại clip **có hỏi trước** vì tốn credit.
  - Khung / clip **lỗi** và **cần xem** **không bị duyệt theo**.
- Ô Video Veo ghi thêm: "Logo Veo tự bỏ khi tải về · ⤓ Nhập clip làm sẵn trên Flow".

### 4.3 Bấm vào 1 ảnh / clip thì phóng to (ảnh 05)
- Mở to **ngay trên tab**, nền sơ đồ tối lại.
- **Ảnh khung:**
  - **Khung gốc cạnh khung mới**.
  - Chọn bản 1 / 2.
  - "Máy tự kiểm": đủ nét · đã nâng 2K · nhãn đọc được.
  - Prompt khung (✎ Sửa).
  - Nút **Duyệt (Enter)**, **Tạo lại (R)**, Tạo lại bằng Pro.
- **Video Veo:** phát clip to, cùng các nút tương tự.
- **← →** để sang cảnh khác. **Esc** hoặc bấm ra ngoài để đóng.
- Dải ảnh nhỏ dưới cùng, màu viền là trạng thái của từng cảnh.

## Bảng ảnh
| Ảnh | Nội dung |
|---|---|
| 01-trang-chu-san-pham-tha-nhieu-video.png | Trang chủ: menu ⋯ sản phẩm, đổi tên tại chỗ, thả 5 video, mục 📚 Kịch bản; dưới: bảng thả khi ở Tất cả, hộp Xóa sản phẩm, Kho kịch bản ở đâu |
| 02-hop-video-moi.png | Hộp Video mới bản sửa, kèm trạng thái chưa kết nối Flow |
| 03-video-chua-phan-tich.png | 5 tình huống chưa phân tích + mở phòng lúc đang phân tích |
| 04-tab-tao-video-day-du.png | **Tab Tạo video đầy đủ trong 1 màn** (ảnh chính để code) |
| 05-tab-tao-video-phong-to.png | Bấm vào 1 ảnh khung thì phóng to |
