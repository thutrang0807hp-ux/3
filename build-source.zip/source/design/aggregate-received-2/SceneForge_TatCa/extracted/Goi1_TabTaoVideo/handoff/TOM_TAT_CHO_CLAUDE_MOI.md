# Tóm tắt dự án SceneForge cho Claude mới

Hãy đọc kỹ phần 1 và phần 2 trước. Người dùng bực vì các lượt trước hay **hiểu sai ý** và **đưa quá nhiều lựa chọn**.

## 1. Cách làm việc với người dùng (quan trọng nhất)

- Người dùng nói tiếng Việt, gõ bằng giọng nói nên câu thường lủng củng, sai chính tả. Hãy đoán ý, đọc cả đoạn rồi mới trả lời, và nói lại ý mình hiểu bằng một câu để họ sửa.
- Họ **mệt vì quá nhiều thứ phải quan tâm**. Hãy **tự quyết** và đưa **một đề nghị rõ ràng** kèm lý do ngắn. Đừng liệt kê nhiều phương án rồi bắt họ chọn. Mỗi lượt hỏi tối đa 1 đến 2 câu.
- **Không tự chạy hay sửa mã khi họ còn đang bàn.** Họ nói "chốt" thì mới làm. Họ đã bực khi mình làm trước.
- **Rất để ý chi phí.** Không gọi API trả phí khi chưa được phép. Nêu rõ chi phí ước tính. Không bịa con số mình không biết.
- **Nói thật những gì chưa làm hoặc chưa kiểm tra.** Họ không muốn bản "mô phỏng ảo", họ cần phần mềm chạy thật. Họ ghét nút giả.
- Chỉ làm video **dọc 9:16**.
- Giải thích bằng từ đơn giản, ví dụ cụ thể. Tránh thuật ngữ kỹ thuật (đừng nói "hai lượt", "token", "keyframe" nếu không cần).

## 2. Mục đích sản phẩm (ý bạn hay hiểu sai)

Người dùng làm video quảng cáo, giới thiệu sản phẩm bằng tiếng Việt (kiểu TikTok). Họ muốn **lấy video của đối thủ hoặc khách hàng (30 đến 60 giây) làm mẫu rồi làm ra video mới theo đúng cấu trúc đó**, nhưng **đổi được** và **giữ được** từng thứ:

| Thứ | Ví dụ |
|---|---|
| Đổi người | nam → nữ |
| Đổi sản phẩm | sản phẩm của họ (ví dụ bình xịt GLYTWIN) |
| Đổi bối cảnh | phòng khách → bếp |
| Đổi giọng nói | giọng nữ miền Nam |
| Giữ khung hình, góc máy | tùy họ chọn |
| Giữ ánh sáng | tùy họ chọn |
| Giữ nhịp và thứ tự cảnh | tùy họ chọn |

Ý định là một **bảng Giữ / Đổi** chọn một lần cho cả video. Phần mềm dựa vào đó viết lại prompt cho từng cảnh, họ sửa riêng từng cảnh nếu cần.

Quy trình mong muốn:
1. Tải video mẫu lên. Mỗi video là **một dự án** (như một file). Bấm vào thì mở không gian riêng, trong đó có toàn bộ các bước, tự lưu, nhìn là biết đang ở bước nào.
2. Máy tự chia thành cảnh (theo chỗ chuyển cảnh), họ chỉnh tay được.
3. AI xem từng cảnh và ghi lại: ai làm gì, ở đâu, quay kiểu gì, ánh sáng, lời thoại.
4. Họ chọn Giữ/Đổi, phần mềm viết prompt **Visual** và **Motion & Script** cho từng cảnh. Prompt phải chi tiết (định danh nhân vật, sản phẩm, kích thước tương đối, bố cục, máy quay, ánh sáng, trạng thái đầu và cuối). Mẫu chuẩn: `references/prompt-example-user.txt`.
5. Tạo clip AI từng cảnh (Veo), tự ghép đúng thứ tự, họ sửa tay trong trình dựng của chính phần mềm. Họ **không muốn** tải từng clip xuống rồi sang CapCut ghép.

Họ muốn **tiết kiệm**: dùng mã mở, chỉ trả tiền API. Họ từng nhắc OpenAI, Veo và "Muse của Meta" (chưa biết có API không).

## 3. Quyết định đã chốt

- **Làm xong hẳn phần phân tích video trước, rồi mới sang phần dựng.** Làm từng phần, không tìm một phần mềm nguyên vẹn để gắn vào.
- Phân tích theo ảnh tĩnh (rẻ): AI chỉ nhìn các ảnh chụp lại từ video, không xem video liên tục và không nghe tiếng. Chia cảnh **theo chỗ chuyển cảnh**, không chia theo từng 5 giây. Cảnh ngắn nên **gộp** cho đủ khoảng 5 đến 8 giây, vì một clip Veo khoảng 8 giây làm được nhiều cảnh cắt nhanh. Cảnh quá dài thì chia nhỏ.
- Chi phí phân tích rất nhỏ so với tạo clip Veo, nên **không nên tiết kiệm ở phần phân tích**.
- **Phần dựng video** (làm sau): giữ giao diện kiểu Concat/CapCut. Chỉ cần cơ bản nhưng **mượt, không khựng**.
  - **Giữ:** tách, cắt mép, nhân đôi, xóa, chèn clip, lấp khoảng trống, hít mốc, hoàn tác, thêm track, kéo clip lên xuống tạo track mới, chuyển cảnh (giữ cách hiện tại, họ rất ưng), chữ và phụ đề, thanh âm lượng mini, tốc độ, vùng an toàn, **hộp Xếp clip nối tiếp**, chế độ Chèn, lưu/mở dự án, xuất video.
  - **Ẩn (không xóa mã):** nút Mốc, Nhãn dán, Hiệu ứng, Bộ lọc, Mẫu, nút giả "Thử quy trình", chụp khung PNG, Đặt lại mẫu, bảng "Tính năng".
  - Không cần tự cắt clip Veo về đúng độ dài cảnh: ghép được thì cứ ghép.
  - Lỗi lớn nhất họ thấy: **timeline khựng khi kéo clip lên xuống giữa các track.** Chưa đo nguyên nhân. Kế hoạch: đo độ giật trước, rồi quyết tối ưu hay viết lại riêng phần timeline.

## 4. Bố cục màn hình Phân tích đang đề xuất (chờ họ xác nhận)

Họ gửi ảnh một công cụ khác dạng sơ đồ nối ô (ô chữ → ô Ảnh → nhiều ô Video → ô Ghép video, mô hình ghi "Muse", "Seedance 2.5"). Đề nghị: **lấy ý tưởng nhưng sắp thẳng hàng, mỗi cảnh một hàng**, không làm sơ đồ nối dây tự do (rối khi có 12 đến 24 ô):

```
Cảnh 1:  [Gốc] → [Prompt] → [Ảnh khung] → [Clip] ─┐
Cảnh 2:  [Gốc] → [Prompt] → [Ảnh khung] → [Clip] ─┼→ [Ghép video]
Cảnh 3:  [Gốc] → [Prompt] → [Ảnh khung] → [Clip] ─┘
```

Ý hay cần học: **một ảnh chung nuôi nhiều clip** để giữ nhất quán nhân vật và sản phẩm. Mỗi ô hiện trạng thái và tiến độ. Phía trên có thanh các bước (Phân tích → Tạo clip → Dựng) và trạng thái đã lưu. Mỗi cảnh hiện ảnh đầu, giữa, cuối.

## 5. Việc kế tiếp đề xuất (chờ họ nói "chốt")

1. Mỗi video là một dự án, thanh các bước, tự lưu.
2. Tách cảnh miễn phí, tự gộp cảnh ngắn, họ kéo chỉnh mốc cảnh bằng tay.
3. Phân tích bằng AI không còn giới hạn cứng: mặc định hiện lỗi nếu video hơn khoảng 8 cảnh, và phần viết prompt bị cắt ở khoảng 12.000 token. Làm hai lượt ở bên trong: một lượt ghi lại nhân vật, sản phẩm, bối cảnh; một lượt viết prompt theo nhóm cảnh. Hiện chi phí trước và sau khi chạy.
4. Bảng Giữ / Đổi và sửa prompt từng cảnh.
5. Chạy thử với một video ngắn thật (chỉ phần phân tích, chi phí vài cent đến vài chục cent) để họ đánh giá chất lượng.

## 6. Câu hỏi còn mở với họ

- Ảnh sơ đồ nối ô họ gửi chụp từ ứng dụng nào? "Muse" có API công khai không? (Chưa xác nhận được.)
- Họ muốn sơ đồ nối ô tự do hay thẳng hàng?
- Họ cần giọng nói đồng nhất giữa các cảnh hay chỉ cần tạm. Veo có thể tạo tiếng nói từ prompt nhưng giọng có thể khác nhau giữa clip. Mình chưa kiểm tra.
- Chữ "nút đẩy video" họ nhắc là nút nào (chưa rõ).

## 7. Tình trạng mã (đã làm ở các lượt trước)

Gói mã: `SceneForge-ChayThat.zip`. Giải nén, vào `source/`, chạy `start.bat` (Windows) hoặc `sh start.sh`, mở `http://127.0.0.1:8000/studio/`. Cần Python 3.11+ và FFmpeg. Đọc thêm: `source/docs/live-pipeline.md`, `DAN_CHO_AI_MOI.md`, `TRANG_THAI_KY_THUAT.md`, `BAT_DAU.md`.

**Đã làm và đã kiểm tra bằng trình duyệt thật (AI giả cục bộ, không tốn tiền):** tải video → tự tách cảnh bằng FFmpeg → phân tích AI (OpenAI, Gemini, Claude, API tương thích OpenAI) → sửa và viết lại prompt → hàng đợi Veo hoặc dùng đoạn gốc làm clip tạm → ghép vào trình dựng đúng thứ tự có chuyển cảnh, hoàn tác một lần. 25 test backend qua, `scripts/demo-web/check_live.py` qua.

**Bản mô phỏng chạy trong trình duyệt** (không cần máy chủ, AI và Veo giả lập, có gán nhãn): https://claude.ai/artifact/2YCVGzgB3YRvbP4DgaCSK8 (riêng tư). Mã ở `source/scripts/demo-web/sim.js`, `build_sim.py`.

**Chưa làm hoặc chưa kiểm chứng:**
- **Chưa thử với key trả phí thật** của bất kỳ nhà cung cấp nào. Chất lượng prompt thật và clip Veo thật chưa biết.
- Muse/Meta chưa tích hợp (không có API xác định).
- Veo hiện chỉ gửi prompt chữ. Chưa dùng ảnh khung đầu hoặc ảnh tham chiếu, nên nhân vật và sản phẩm sẽ không nhất quán giữa các cảnh. Đây là điểm yếu lớn nhất.
- Xuất video trong editor là MediaRecorder của trình duyệt (WebM, tối đa 2 phút, MP4 không chắc). Cần xuất MP4 bằng FFmpeg.
- Dự án dựng chưa lưu bền, mở lại phải chọn lại tư liệu.
- Chưa có phụ đề tự động, chưa phân tích âm thanh hay lời thoại.
- `check_audio_core.py` treo ở bước chờ tải file xuất trong Chromium headless. Bản gốc chưa sửa cũng treo y hệt, nên phần đo âm lượng khi xuất chưa xác nhận lại.
- Gói chưa thử trên Windows.
- Các nghiên cứu GitHub: không có dự án nào làm trọn cả chuỗi. Gần nhất: OpenMontage (AGPL, nhận video mẫu, không có timeline), veo-video-pipeline (MIT, dùng khung cuối clip trước làm ảnh cho clip sau, rất đáng học), FlowKit (không chính thức, rủi ro, không khuyên dùng). Đừng chép mã AGPL.

## 8. Lưu ý kỹ thuật khi sửa tiếp

- Mã trình dựng web dồn thành các dòng rất dài và chồng nhiều lớp bổ sung, khó sửa. Chạy lại các script kiểm tra sau mỗi thay đổi (`scripts/native-preview/check_*.py`, `scripts/demo-web/check_integrated.py`, `check_live.py`).
- Backend: `source/app.py`, `ai_providers.py`, `pipeline.py`, `prompt_workflow.py`, `video_analysis.py`. Giao diện chạy thật: `source/scripts/demo-web/live.js` được chèn vào `source/preview.html` lúc build (`python scripts/demo-web/build.py`).
- Không chép mã Concat (AGPL) vào sản phẩm. Giữ nguyên các tệp LICENSE bên thứ ba.
- Không lưu key vào mã hay vào cuộc trò chuyện.
