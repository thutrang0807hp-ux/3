# SceneForge: Đặc tả tab "Tạo video" (bản chốt 20/10/2026)

File này để người hoặc AI khác **code tiếp mà không cần đọc lại cuộc trò chuyện thiết kế**. Đọc theo thứ tự từ trên xuống. Ảnh thiết kế nằm trong thư mục `anh-thiet-ke/`.

> Nếu có file `TOM_TAT_CHO_CLAUDE_MOI.md` (bản tóm tắt dự án cũ), đọc phần 1, 2 và 7 của file đó để biết tình trạng mã hiện có. File này **thay thế** phần 4 và 5 của bản cũ (bố cục màn Phân tích và việc kế tiếp).

---

## 0. Cách làm việc với người dùng (bắt buộc đọc)

- Người dùng nói tiếng Việt, gõ bằng giọng nói nên câu hay lủng củng. Đọc cả đoạn, đoán ý, rồi **nói lại ý mình hiểu trong một câu** để họ sửa.
- Họ **mệt vì có quá nhiều lựa chọn**. Hãy tự quyết và đưa **một đề nghị rõ ràng** kèm lý do ngắn. Mỗi lượt hỏi tối đa 1 đến 2 câu.
- **Không tự chạy hay sửa mã khi họ còn đang bàn.** Họ nói "chốt" hoặc "làm đi" thì mới làm.
- **Rất để ý chi phí.** Không gọi dịch vụ trả phí khi chưa được phép. Không bịa con số.
- **Nói thật những gì chưa làm hoặc chưa kiểm tra.** Họ ghét nút giả và bản "mô phỏng ảo".
- Giải thích bằng lời đơn giản, có ví dụ. Khi họ không hiểu, **vẽ ảnh tĩnh khổ to** (PNG), đừng viết thêm chữ.
- Chỉ làm video **dọc 9:16**.

---

## 1. Mục đích

Người dùng làm video bán hàng tiếng Việt kiểu TikTok (KOC cầm sản phẩm giới thiệu). Họ lấy **video của đối thủ** (30 đến 60 giây, có thể **tiếng nước ngoài**) làm mẫu, rồi làm ra **video mới cùng cấu trúc và thời lượng**, nhưng đổi **người, trang phục, sản phẩm, bối cảnh (tùy chọn), lời thoại và giọng**.

Ví dụ xuyên suốt tài liệu: sản phẩm là **bình xịt bếp GLYTWIN**, giọng **nữ miền Nam**.

---

## 2. Những quyết định đã chốt

| # | Quyết định | Lý do ngắn |
|---|---|---|
| 1 | Giao diện kiểu **sơ đồ nối ô** (node canvas, nền tối, dây cong), giống ảnh tham khảo người dùng gửi. Không làm kiểu bảng hay danh sách. | Người dùng chê kiểu bảng là xấu và khó hiểu. |
| 2 | Chỉ 2 bước lớn: **Tạo video → Dựng**. Tab Tạo video gồm cả phân tích, khung, clip và ghép. | Bớt rối. |
| 3 | Tạo clip bằng **Veo trong Google Flow, dùng credit của gói Flow Pro**. **Không** dùng API trả tiền. | Người dùng không muốn tốn thêm tiền API. |
| 4 | Phần mềm **tự điều khiển web Flow chạy ngầm** (tự đăng nhập, dán prompt và ảnh, tải clip về). Người dùng đã chấp nhận rủi ro bị khóa tài khoản. **Thử trên tài khoản phụ trước.** | Credit Flow không dùng được qua API. |
| 5 | Cách đổi người hoặc đồ vật: **khung gốc + ảnh tham chiếu → khung mới (ảnh) → người dùng duyệt → Veo biến khung thành clip**. | Rẻ hơn sửa thẳng video (Omni sửa video tốn 40 credit một lần). Có bước duyệt ảnh trước khi tốn credit video. |
| 6 | Mô hình mặc định **Veo 3.1 Lite** (rẻ). Từng cảnh đổi được sang Veo Fast. Omni chỉ dùng khi bắt buộc phải giữ động tác y hệt. | Tiết kiệm credit. |
| 7 | **Lời thoại do AI viết sẵn** (dịch và viết lại cho sản phẩm), người dùng chỉ sửa nếu muốn. | Người dùng không muốn gõ từ đầu. |
| 8 | **Một giọng đọc chung** cho cả video, đặt đúng mốc giây của lời gốc. Cảnh thấy mặt người nói thì Veo tạo hình **mấp máy miệng theo đúng câu đó**, còn tiếng lấy từ giọng đọc chung. | Thoại thường vắt qua chỗ chuyển cảnh. Một bài đọc liền mạch thì không bị khựng, giọng đều. |
| 9 | **Chia lời theo mốc giây, không theo cảnh.** Video mới giữ đúng thời lượng từng cảnh như video mẫu. | Không phải tạo thêm clip chỉ vì thoại dài. |
| 10 | **Số clip tính theo độ dài cảnh**: cảnh dài hơn 8 giây thì tách thành nhiều clip (cắt ở chỗ ngắt câu gần nhất), không tách vì thoại. | Veo mỗi lần chỉ làm khoảng 8 giây. |
| 11 | **Prompt mô tả viết bằng tiếng Anh, lời thoại để tiếng Việt** trong ngoặc kép. Giao diện cho xem và sửa bằng tiếng Việt, tự đổi sang tiếng Anh khi gửi Veo. | Veo hiểu mô tả tiếng Anh tốt hơn. |
| 12 | **Quy tắc nối dây: nối ô nào thì đổi thứ đó, không nối thì giữ như video gốc.** | Thay cho bảng Giữ/Đổi cũ, người dùng thấy bảng đó rối. |
| 13 | Prompt **phải chi tiết** (xem mục 6). Trên ô chỉ hiện bản tóm 2 dòng, bản đầy đủ nằm ở bảng bên phải. | Người dùng chê prompt đơn giản quá. |

---

## 3. Quy trình người dùng thấy

Xem ảnh `04-quy-trinh-va-chi-phi.png` và `03-cach-thay-nguoi-1-canh.png`.

1. **Thả video đối thủ** rồi bấm **Phân tích**.
2. Phần mềm tự chạy: chia cảnh, chép lời, dịch, viết lời mới, viết prompt chi tiết.
3. **Thả ảnh tham chiếu** (người, trang phục, sản phẩm, bối cảnh nếu muốn đổi), xem hoặc sửa lời mới, chọn giọng.
4. Phần mềm **làm khung mới** cho từng cảnh. Người dùng **Duyệt** hoặc **Tạo lại** khung.
5. Bấm **Duyệt hết & chạy**. Hiện hộp hỏi lại kèm số credit, đồng ý thì Flow chạy ngầm **lần lượt từng clip**.
6. Clip nào lỗi thì **Tạo lại riêng clip đó**, bản cũ vẫn giữ.
7. **Ghép**: nối clip theo thứ tự, lồng giọng đọc và nhạc nền, rồi **mở sang bước Dựng** (trình dựng đã có sẵn trong mã).

Người dùng chỉ làm 3 việc: thả video, thả ảnh, duyệt khung. Còn lại phần mềm tự chạy.

---

## 4. Bố cục màn hình

Xem ảnh `01-tab-tao-video-toan-canh.png`.

- **Thanh trên cùng:** tên phần mềm, các tab (Dự án, Tạo video, Dựng), **"Flow Pro · còn [số] credit"**, nút Huỷ và Bản mới.
- **Dòng thứ hai:** tên dự án, trạng thái "đã lưu" (tự lưu), và **thanh tiến độ 4 bước**: Phân tích → Duyệt khung (n chờ) → Tạo clip (x/y) → Ghép và giọng.
- **Nền vẽ:** nền tối có chấm, thu phóng và kéo được, có thanh công cụ dọc bên trái, có bản đồ thu nhỏ ở góc dưới. Các ô **xếp sẵn tự động theo cột**, người dùng không phải tự nối dây (dây chỉ để nhìn luồng).
- **Bảng chi tiết bên phải:** mở ra khi bấm vào một cảnh.
- **Thanh dưới giữa:** "Ước tính X credit Flow cho N cảnh + làm khung" và nút **Duyệt hết & chạy**.

Thứ tự cột từ trái sang phải:

| Cột | Ô |
|---|---|
| 1 | Video đối thủ · Phân tích · Kịch bản → Giọng đọc |
| 2 | Các cảnh · Ảnh tham chiếu (Người / Trang phục / Sản phẩm / Bối cảnh, mỗi loại một ô riêng) |
| 3 | Ảnh khung · Cảnh n (một ô cho mỗi cảnh) |
| 4 | Video Veo · Cảnh n (một ô cho mỗi cảnh) |
| 5 | Ghép video |

Màu dây: **tím** là chữ/cảnh, **xanh lá** là ảnh, **tím đậm** là video, **vàng nét đứt** là giọng đọc. Nút chạy là hình tròn màu vàng chanh `#D4F53C`.

---

## 5. Từng ô: vào, ra, trạng thái, nút

### 5.1 Video đối thủ
- **Vào:** người dùng kéo thả file video (mp4, mov…), hoặc bấm để chọn.
- **Hiện:** ảnh xem trước, tên file, thời lượng, khổ hình, có hay không có lời thoại.
- **Nút:** Phân tích ▶.
- **Ra:** dây sang ô Phân tích.

### 5.2 Phân tích
Hiện từng bước kèm dấu ✓, ●, ○:
1. **Cắt ở chỗ chuyển cảnh**, ví dụ "tìm được 11 đoạn cắt". Làm miễn phí bằng FFmpeg (đã có trong mã).
2. **Gộp đoạn ngắn cho đủ khoảng 8 giây**, ví dụ "11 đoạn → 6 cảnh". Cảnh dài hơn 8 giây thì đánh dấu sẽ tách clip.
3. **Xem hình từng cảnh**: chụp ảnh đầu, giữa, cuối mỗi cảnh, và mỗi đoạn cắt được gộp phải có ít nhất 1 ảnh.
4. **Nghe lời gốc, chép ra chữ có mốc giây** (cần chép lời từ âm thanh, phần này mã cũ chưa có).
5. **Viết prompt chi tiết từng cảnh** (mục 6).
6. **Đánh dấu logo hoặc chữ của đối thủ** còn trong hình.
- Dùng Gemini, chi phí gần như bằng 0. Nút ↻ để phân tích lại.
- **Ra:** dữ liệu cho ô Các cảnh và ô Kịch bản.

### 5.3 Các cảnh
- Danh sách cảnh: ảnh nhỏ, "Cảnh n · 0:06–0:13", mô tả ngắn. Cảnh đang mở chi tiết thì viền vàng chanh.
- **Bấm vào một cảnh thì mở bảng chi tiết bên phải.**
- Nút "↻ chia lại": kéo chỉnh mốc cảnh bằng tay.
- Video dài thì danh sách cuộn được ("Cảnh 5, 6 ở dưới").

### 5.4 Ảnh tham chiếu (4 ô riêng)
- **Người:** 1 đến 3 ảnh (mặt, nửa người, toàn thân), nút + để thêm, một dòng mô tả.
- **Trang phục:** ảnh bộ đồ hoặc dòng mô tả.
- **Sản phẩm:** 2 đến 3 ảnh (mặt trước có nhãn, mặt bên), một dòng mô tả.
- **Bối cảnh:** để trống nghĩa là giữ như video gốc (ô mờ đi, không nối dây).
- **Mỗi ô chỉ nối dây tới những cảnh cần dùng.** Phần mềm tự quyết dựa trên phân tích, ví dụ cảnh không có người thì không nối ô Người. Người dùng bỏ nối được.
- Ví dụ: muốn giữ người cũ, chỉ đổi quần áo thì chỉ nối ô Trang phục.
- **Nhắc khi thiếu ảnh:** nếu video mẫu có cảnh quay toàn thân mà chỉ có ảnh mặt, báo "Nên thêm ảnh toàn thân để giữ đúng quần áo".

### 5.5 Ảnh khung · Cảnh n
- **Vào:** khung gốc của cảnh (ảnh đầu) cộng các ảnh tham chiếu được nối.
- **Làm:** tạo **ảnh mới** giữ tư thế, bố cục, bối cảnh của khung gốc, thay người, trang phục, sản phẩm theo ảnh tham chiếu.
- **Hiện:** ảnh khung mới, "Prompt khung" (sửa được, nút ✎), trạng thái.
- **Trạng thái:** Đang tạo… / ● Chờ bạn duyệt / ✓ Đã duyệt.
- **Nút:** ↻ Tạo lại, ✓ Duyệt.
- Không đổi gì cả thì bỏ qua bước này, lấy luôn khung gốc.
- **Chưa biết:** sửa ảnh trong Flow tốn bao nhiêu credit, và dùng công cụ nào (có thể là công cụ tạo ảnh trong Flow). Phải kiểm tra.

### 5.6 Video Veo · Cảnh n
- **Vào:** khung đã duyệt.
- **Hiện:** khung xem clip hoặc trạng thái ("Đang tạo… 37s", "Đang xếp hàng", "Xong · bản 2"), **prompt video bản tóm 2 dòng** (bấm "mở đầy đủ" thì ra bảng bên phải), và dòng **"＋ Thêm yêu cầu riêng cho cảnh này…"** (ví dụ "Ánh sáng vàng ấm buổi tối", sẽ được thêm vào prompt).
- **Chọn:** mô hình (Veo Lite ▾ / Fast / Omni), 9:16, 8s, ⚙.
- **Nút:** ▶ tạo, ■ dừng, ↻ Tạo lại. **Giữ mọi bản cũ** (Bản 1, 2…), chọn bản nào thì bản đó được đem ghép.
- **Cảnh dài hơn 8 giây** thì có nhiều clip (2a, 2b…) dùng cùng khung, cùng tư thế.

### 5.7 Cảnh đã xong thì thu gọn
Khi khung đã duyệt và clip đã xong, hai ô của cảnh đó thu thành **một dòng**: "Cảnh 1 ✓ Khung đã duyệt ✓ Clip bản 2/2 · Veo Lite · 10 credit", kèm nút Xem, Tạo lại, Mở ra.

### 5.8 Kịch bản → Giọng đọc
Xem ảnh `02-o-kich-ban-giong-doc.png` (bảng đầy đủ). Trên nền vẽ chỉ hiện bản gọn, bấm "mở bảng ↗" thì ra bảng đầy đủ.

- **Bảng 4 cột:** Mốc giây | Lời gốc | Dịch sát | **Lời mới** (chỉ sửa ở cột này).
- **Lời mới do AI viết sẵn.** Nút **"AI viết lại cả bài"** cho phép dặn thêm một dòng, ví dụ "nhấn mạnh giá rẻ".
- **Công tắc:** "Chỉ dịch, giữ y ý gốc" / "Viết lại cho sản phẩm của tôi".
- **Mỗi câu có thanh đo** "đọc ~3.4s / chỗ 4s": xanh là vừa, đỏ là dài quá mốc, kèm nút **✨ Rút gọn**.
- **Câu thấy mặt người nói** có nhãn tím "thấy mặt nói → Veo mấp máy theo câu này". Câu đó được đưa vào prompt video của cảnh tương ứng.
- **Giọng:** chọn giọng (Nữ miền Nam ▾), cảm xúc (Vui, hào hứng ▾), tốc độ (1.1× ▾). Nút **▶ Nghe thử cả bài**.
- **Dưới cùng:** thanh giọng đọc đặt chồng lên thanh cảnh, nhìn là thấy câu nào nằm ở cảnh nào.
- **Ra:** dây vàng sang ô Ghép (lồng giọng), và lời câu thấy mặt vào prompt các cảnh.
- **Đồng bộ:** sửa lời ở đây hay trong bảng prompt cũng là **cùng một dữ liệu**.
- **Đo giây thật:** đọc thử bằng giọng đã chọn rồi đo, không đếm chữ.

### 5.9 Ghép video
- **Vào:** các clip đã chọn (theo thứ tự cảnh) và giọng đọc.
- **Chọn:** thứ tự, 9:16, **♪ Giọng đọc: từ Kịch bản**, **Nhạc nền ▾** (tự nhỏ đi khi có giọng).
- **Làm:** ghép bằng FFmpeg ở máy người dùng, lồng giọng đúng mốc giây. Clip nào ngắn hoặc dài hơn mốc cảnh thì cắt hoặc giữ khung cuối cho khớp thời lượng gốc.
- **Ra:** mở sang bước Dựng (trình dựng đã có trong mã).

### 5.10 Bảng chi tiết bên phải (khi bấm một cảnh)
- **Tiêu đề:** "Cảnh 4 · 0:20–0:28", mô tả ngắn, nút ✕.
- **Mục con:** Prompt video | Prompt khung | Lời thoại | Các bản đã tạo.
- **Công tắc:** Tiếng Việt / English (gửi Veo).
- **Các ô prompt:** mục 6. Bấm vào ô nào thì sửa ô đó.
- **Dòng** "＋ Thêm yêu cầu riêng cho cảnh này…".
- **Nút:** ✨ AI viết lại, Lưu.

---

## 6. Mẫu prompt chi tiết (mỗi cảnh)

**Chưa có file mẫu chuẩn của người dùng** (`references/prompt-example-user.txt` nằm trong gói mã cũ). Khi code, **mở file đó ra và làm khớp theo**. Tạm thời dùng khung sau.

**VISUAL**
- Nhân vật: tuổi, dáng, tóc, da, trang phục (ghi rõ lấy theo ảnh Người và ảnh Trang phục nào).
- Sản phẩm: màu, nhãn, vòi; **nhãn luôn quay về máy, chữ rõ** (ghi lấy theo ảnh Sản phẩm nào).
- Kích thước tương đối: ví dụ "bình cao bằng cẳng tay, chiếm khoảng 1/5 chiều cao khung".
- Bố cục: 9:16, cỡ cảnh, vị trí mặt và sản phẩm trong khung.
- Bối cảnh: giữ như gốc, hoặc theo ảnh Bối cảnh.
- Ánh sáng.

**MOTION & SCRIPT**
- Máy quay: cầm tay hay đứng yên, đẩy vào hay lùi ra.
- Trạng thái đầu.
- Hành động.
- Trạng thái cuối.
- Lời thoại: **tiếng Việt, trong ngoặc kép**, ghi "speaks in Vietnamese, Southern accent". Lấy từ Kịch bản.
- Thời lượng: 8 giây, 9:16, không chữ trên hình.

Ví dụ khi gửi Veo:
> *Visual:* Vietnamese woman, about 30, shoulder-length black hair, white T-shirt, green apron (ref: Person 1–3, Outfit 1)… GLYTWIN spray bottle, teal body, white label facing camera…
> *Motion:* Handheld, slight shake, slow 10% push-in. She raises the bottle next to her cheek and says in Vietnamese, Southern accent: **"Xịt GLYTWIN là sạch bóng liền, bấm giỏ hàng góc trái nha!"**

---

## 7. Mô hình dữ liệu gợi ý (mỗi video là một dự án, tự lưu)

```
Project { id, name, sourceVideo, createdAt, steps: {analysis, frames, clips, merge} }
Scene   { index, start, end, cutIds[], thumbs{first,mid,last}, description,
          hasPerson, faceTalking, competitorLogo, refsUsed[],
          promptFrame, promptVideo{visual{...}, motion{...}}, extraRequest,
          frames[{version, image, status}], approvedFrame,
          clips[{part:'a'|'b', version, file, model, credits, status}], chosenClip }
RefSet  { person[], outfit[], product[], background[] (ảnh + mô tả) }
ScriptLine { start, end, original, translation, newText, sceneIds[], faceTalking, measuredSec }
Voice   { name, emotion, speed, audioFile }
Merge   { order[], musicFile, musicVolume, output }
```

---

## 8. Chi phí (để hiện trên giao diện)

Bảng credit Flow theo hai trang tổng hợp, cập nhật 10/10/2026. **Google có thể đổi bất cứ lúc nào, phải đọc lại từ Flow thật.**

| Loại | Credit mỗi lần (gói thường) |
|---|---|
| Veo 3.1 Lite (4, 6 hoặc 8 giây) | 10 |
| Veo 3.1 Fast | 20 |
| Veo 3.1 Quality | 100 |
| Omni sửa video có sẵn | 40 |
| Omni tạo mới 720p | 7 đến 15 |

- Gói **Pro**: 1.000 credit mỗi tháng, cộng 50 credit mỗi ngày (không cộng dồn), tức khoảng 2.500 một tháng nếu ngày nào cũng dùng.
- **Video 45 giây khoảng 6 cảnh, Veo Lite, mỗi cảnh làm lại 1 lần: khoảng 120 credit**, cộng tiền làm khung (chưa rõ). Tức khoảng 20 video mỗi tháng với gói Pro, quy ra khoảng $1 một video.
- Giao diện phải: hiện **số credit còn lại** (đọc từ Flow), **ước tính trước khi chạy**, **hỏi lại trước khi chạy hàng loạt**, chạy **lần lượt và có nghỉ** giữa các clip.
- Phân tích (Gemini) và giọng đọc: rất nhỏ, ưu tiên dùng gói miễn phí. **Chưa kiểm tra.**

Nguồn: magichour.ai/blog/google-flow, felloai.com/google-flow.

---

## 9. Chưa kiểm tra, phải thử trước khi code nhiều

Theo thứ tự ưu tiên:
1. **Thử tay trong Flow** với một đoạn 8 giây có người nói: ghép người vào khung có giữ đúng mặt không; Veo Lite từ khung ra clip có đẹp không; nhãn GLYTWIN có bị méo chữ không; mỗi việc trừ bao nhiêu credit.
2. **Sửa ảnh (làm khung) trong Flow** bằng công cụ gì, tốn bao nhiêu credit.
3. **Khớp miệng:** Veo tạo cảnh nói câu tiếng Việt, rồi thay tiếng bằng giọng đọc chung, nhìn có ổn không.
4. **Giọng đọc tiếng Việt miền Nam** (dự kiến dùng giọng đọc AI của Google): nghe có tự nhiên không, giá bao nhiêu.
5. **Tự điều khiển Flow chạy ngầm:** Flow có cho đưa ảnh khung vào kèm prompt dễ không, có hay đòi xác minh không. Làm trên tài khoản phụ.
6. Tài khoản Pro của người dùng **có Omni không**.

Nếu mục 1 cho kết quả tệ thì **giữ nguyên giao diện**, chỉ đổi cách làm bên trong ô Ảnh khung hoặc Video.

---

## 10. Thứ tự làm đề nghị

1. Dự án và tự lưu; ô Video đối thủ.
2. Phân tích: cắt cảnh (đã có), gộp cho đủ 8 giây, chép lời có mốc giây, dịch, viết lời mới, prompt chi tiết. Bỏ giới hạn cứng khoảng 8 cảnh của mã cũ.
3. Nền vẽ dạng node và tự xếp ô; ô Các cảnh, Ảnh tham chiếu; bảng chi tiết bên phải.
4. Ô Kịch bản → Giọng đọc (đọc thử, đo giây, rút gọn).
5. Kết nối Flow: đăng nhập một lần, chạy ngầm, hàng đợi lần lượt, đọc số credit, tải clip về. **Giữ đường dự phòng:** nút "Chép prompt" để dán tay, và chỗ "Thả clip tải tay vào" để phần mềm tự xếp.
6. Ảnh khung, duyệt khung; Video Veo, tạo lại, giữ bản cũ.
7. Ghép bằng FFmpeg, lồng giọng và nhạc, mở sang Dựng.

Sau mỗi bước, chạy lại các script kiểm tra có sẵn trong mã cũ.

---

## 11. Những điều không làm

- Không dùng API Veo trả tiền (trừ khi người dùng đổi ý).
- Không đưa tài khoản Google cho bên thứ ba. Đăng nhập chỉ lưu trên máy người dùng.
- Không chép mã AGPL (OpenMontage, Concat). Không dùng FlowKit.
- Không làm kiểu giao diện bảng hay danh sách thay cho node canvas.
- Không thêm nút giả.

---

## 12. Phân tích dùng gì và tốn bao nhiêu (giải thích đơn giản)

Phần phân tích chỉ dùng 2 thứ:

| Việc | Công cụ | Tốn |
|---|---|---|
| Cắt cảnh, chụp ảnh từng cảnh, tách tiếng | **FFmpeg**, chạy trên máy người dùng | 0đ |
| Xem từng cảnh (ai, làm gì, góc máy, ánh sáng) | **Gemini Flash** (Google) | rất ít |
| Nghe lời gốc, chép ra chữ có mốc giây | **Gemini Flash** | rất ít |
| Dịch, viết lời mới, viết prompt chi tiết | **Gemini Flash** | rất ít |

- Ước tính cho video mẫu 45 giây: **vài cent, khoảng 1.000 đến 2.000đ** một lần phân tích. Tính theo giá Gemini Flash đọc được tháng 10/2026 (khoảng $0.30 đến $0.75 cho 1 triệu token vào, $2.50 đến $3.75 cho 1 triệu token ra), và theo tài liệu Google: video khoảng 260 token/giây, âm thanh khoảng 32 token/giây. **Chưa chạy thật**, phần mềm phải hiện số thật sau mỗi lần chạy.
- **Có gói miễn phí** của Google AI Studio, có giới hạn số lần mỗi ngày. Đổi lại, Google được dùng dữ liệu gửi lên để huấn luyện. Nên cho người dùng chọn: dùng miễn phí hoặc dùng key trả phí.
- Khoản tốn nhất của cả quy trình **không nằm ở phân tích**, mà ở **credit Flow** dùng cho làm khung và tạo clip (mục 8).

---

## 13. Phần còn bỏ ngỏ (chưa chốt trong buổi này)

**a) Trình dựng (bước Dựng)**
- Người dùng tự đánh giá đã xong **khoảng 70%**, còn nhiều **lỗi lẻ tẻ khó chịu**. Không cần giống y CapCut, chỉ cần **đủ chức năng chính và mượt**.
- Danh sách chức năng giữ và ẩn: xem `TOM_TAT_CHO_CLAUDE_MOI.md`, mục 3.
- Lỗi đã biết: timeline **khựng khi kéo clip giữa các track** (chưa đo nguyên nhân); xuất video bằng ghi màn hình trình duyệt (WebM, tối đa 2 phút) nên **phải chuyển sang FFmpeg ra MP4**; dự án dựng **chưa lưu bền**.
- Mã trình dựng **dồn thành dòng rất dài, chồng nhiều lớp sửa**. Đây có thể là gốc của các lỗi lẻ tẻ.
- **Việc cần làm trước tiên:** đọc mã, chạy thử, đo chỗ khựng, lập bảng từng chức năng (chạy tốt / lỗi / thiếu), rồi quyết **vá hay viết lại riêng phần lõi timeline** (kéo, cắt, xếp track, phát). Chưa ai làm bước đánh giá này.

**b) Luồng tài khoản để phần mềm tự chạy Flow**
Chưa bàn. Cần chốt với người dùng:
- Đăng nhập Flow một lần thì lưu ở đâu (chỉ trên máy người dùng), bao lâu phải đăng nhập lại.
- Có cho nhiều tài khoản (chính và phụ) không; hết credit thì **tự chuyển tài khoản** hay **dừng lại và báo**.
- Màn hình xem credit từng tài khoản và hàng đợi đang chạy.
- Khi Google đòi xác minh thì làm gì; tốc độ chạy và thời gian nghỉ giữa các clip.

---

## 14. Ảnh thiết kế trong gói

| File | Nội dung |
|---|---|
| `anh-thiet-ke/01-tab-tao-video-toan-canh.png` | **Bản chốt** toàn màn hình tab Tạo video |
| `anh-thiet-ke/02-o-kich-ban-giong-doc.png` | Bảng đầy đủ của ô Kịch bản → Giọng đọc |
| `anh-thiet-ke/03-cach-thay-nguoi-1-canh.png` | Giải thích cách thay người trong một cảnh |
| `anh-thiet-ke/04-quy-trinh-va-chi-phi.png` | Quy trình 6 bước và vòng làm lại |

Chữ và số trong ảnh (lời thoại, prompt, credit) là **ví dụ minh họa**, không phải dữ liệu thật. Riêng trong ảnh 04, ô ① ghi "phần mềm tự chia thành các đoạn khoảng 8 giây"; hãy hiểu theo mục 5.2: chia ở chỗ chuyển cảnh trước, rồi mới gộp hoặc tách cho vừa 8 giây.
