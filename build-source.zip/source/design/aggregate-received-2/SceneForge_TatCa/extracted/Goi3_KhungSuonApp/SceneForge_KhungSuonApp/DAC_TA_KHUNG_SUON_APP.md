# SceneForge · Khung sườn app · Đặc tả đã chốt (21/10/2026)

> Gói thứ 3, đi cùng 2 gói trước:
> - `SceneForge_DacTa_TabTaoVideo.zip`: sơ đồ node tab Tạo video.
> - `SceneForge_DacTa_TabDung.zip`: trình dựng.
>
> Gói này mô tả **phần bao quanh** hai tab đó: trang chủ, sản phẩm, phòng làm việc, thư mục, hàng chờ chung, và ô "Sang Dựng".
> Ảnh thiết kế nằm trong `anh-thiet-ke/`.
> Chữ, số, tên video, credit trong ảnh đều là **ví dụ**.

## Quy tắc chung (bắt buộc)
- Chỉ video dọc 9:16. Không dùng API trả phí khi chưa được phép. Không bịa con số. **Không nút giả.**
- Không lưu key hay mật khẩu vào mã. Đăng nhập Google chỉ nằm trên máy người dùng.
- Không chép mã AGPL (Concat, OpenMontage). Không dùng FlowKit.

---

## 1. Các chỗ trong app

| Chỗ | Trạng thái |
|---|---|
| Trang chủ (Bàn sản xuất + cột Sản phẩm) | ✅ chốt (mục 2) |
| Phòng: Tạo video (sơ đồ node, gồm cả phân tích) | ✅ chốt (gói Tab Tạo video) + ô Sang Dựng (mục 6) |
| Phòng: Dựng | ✅ chốt (gói Tab Dựng) |
| Hàng chờ chung (ngăn kéo trượt ra) | ⏳ luật đã chốt (mục 5), giao diện đầy đủ chưa vẽ |
| Cài đặt + Tài khoản Flow | ❌ chưa bàn |
| Màn chào lần đầu (chọn thư mục, đăng nhập Flow, nhập key Gemini) | ❌ chưa bàn |
| Thông báo (chuông) | ❌ chưa bàn, đã có icon và số đếm trên thanh trái |

**Đã bỏ, không làm:**
- Trang nhật ký lỗi riêng: chỗ nào lỗi thì có nút "Sao chép chi tiết lỗi" ngay tại chỗ đó.
- Bảng phím tắt riêng: tooltip đã hiện phím tắt.
- Khung "Đang diễn ra" kiểu dòng thời gian: thay bằng tổng quan trên từng sản phẩm (mục 2.2).

**Thanh dọc bên trái (luôn hiện):**
- Logo.
- Trang chủ · Tạo video · Dựng. Hai mục sau mở **phòng đang mở gần nhất**. Chưa mở phòng nào thì hai mục này mờ.
- Cột đo credit Flow: số còn lại, đọc thật từ Flow. Bấm vào thì mở hàng chờ.
- Chuông thông báo, có số đếm.
- Cài đặt.

---

## 2. Trang chủ
*Ảnh: `01-trang-chu.png` (bình thường), `02-trang-chu-nhieu-video.png` (khoảng 20 video)*

### 2.1 Bố cục
`[thanh dọc] [cột Sản phẩm] [Bàn sản xuất của sản phẩm đang chọn]`

### 2.2 Cột Sản phẩm
- Dòng đầu là "Tất cả" kèm tổng số video.
- Sau đó là các sản phẩm: Son, Nước hoa ô tô, GLYTWIN…
- Mỗi dòng sản phẩm có:
  - Chấm màu đại diện (lấy từ bộ ảnh), tên, số video.
  - **Chấm vàng** nếu đang có video chờ duyệt.
  - **Thanh màu nhỏ chia theo chặng** (độ dài mỗi đoạn = số video ở chặng đó).
  - **Một dòng tóm tắt**, ví dụ "**3 chờ duyệt** · 2 đang tạo", "**1 cảnh lỗi** · 3 xong", "4 xong · không có việc". Chữ chờ duyệt màu vàng, chữ lỗi màu đỏ.
- Nút ＋ tạo sản phẩm mới.
- Dưới cùng là mục **Lưu trữ**: video đã xuất quá 7 ngày tự vào đây, vẫn mở lại được.

### 2.3 Sản phẩm là gì
**1 sản phẩm = 1 ngăn chứa video + 1 bộ ảnh tham chiếu + 1 thư mục trên máy.**
- **Bộ ảnh** gồm người, trang phục, sản phẩm, bối cảnh (nếu có). Sửa bộ ảnh ngay tại sản phẩm.
- Thả video mẫu vào khi đang mở ngăn nào thì video **tự vào ngăn đó** và **tự dùng bộ ảnh của sản phẩm đó**. Không hỏi lại.
- Thả video khi đang ở "Tất cả" thì hỏi đúng 1 câu: vào sản phẩm nào (hoặc tạo mới).
- Ảnh tham chiếu được **chép** vào phòng, sửa riêng trong từng phòng được, không làm đổi bộ gốc.

### 2.4 Bàn sản xuất
- **Đầu trang:**
  - Dòng nhỏ "Bàn sản xuất", rồi tên sản phẩm to.
  - Dòng tóm tắt, ví dụ "24 video (18 đang làm, 6 đã xuất) · 3 chờ bạn duyệt · 8 mới thêm · Flow đang chạy 1 clip, 2 xếp hàng".
  - Ô tìm (trong sản phẩm đang chọn).
  - Nút **＋ Video mới** (màu chanh).
- **6 cột theo chặng.** Video tự chuyển cột, người dùng không kéo:
  1. **Mới thêm**: vừa thả vào, chờ tới lượt phân tích ("Chờ phân tích · thứ 1").
  2. **Phân tích**: đang chạy, ghi bước ("Chép lời gốc · bước 4/6").
  3. **Chờ bạn duyệt**: khung đã làm xong, cần duyệt. Thẻ viền vàng, nút vàng "Duyệt n khung".
  4. **Đang tạo clip**: đang chạy hoặc xếp hàng trên Flow. Có nhãn "Flow đang chạy". Cảnh lỗi thì hiện nút "Tạo lại cảnh n".
  5. **Đang dựng**: đã sang tab Dựng, chưa xuất. Nút "Mở Dựng".
  6. **Đã xuất**: 2 nút (mục 2.6).
- **Đầu cột:** số to + tên chặng + chấm màu.
- **Màu:**
  - Tím: phân tích.
  - Vàng: chờ bạn.
  - Xanh dương: đang tạo.
  - Trắng: đang dựng.
  - Xanh lá: xong.
  - Đỏ: lỗi.
  - Xám: chưa tới lượt.
  - **Chỉ màu vàng và đỏ được nổi bật**, vì đó là việc cần người dùng.

### 2.5 Thẻ video
- **Ảnh bìa** là khung hình đầu của video mới (khi chưa có thì lấy video mẫu), có chữ móc câu như bìa TikTok.
- Tên, thời gian, và **dải ô màu: mỗi ô là 1 cảnh** (xong / chờ duyệt / đang tạo / lỗi / chưa tới lượt).
- **Bấm thẻ là mở đúng chỗ đang dở:** chờ duyệt thì mở Tạo video, đang dựng thì mở Dựng.
- **Chuột phải:** Mở, Đổi tên, Mở thư mục, Chuyển sang sản phẩm khác, Xóa.

### 2.6 Hai nút của video đã xuất (phải ghi rõ chữ nhỏ bên dưới)
| Nút | Giữ lại | Làm lại | Tốn credit |
|---|---|---|---|
| **Sửa tiếp** | Mọi thứ | Mở tab Dựng, chỉnh, xuất lại | Không |
| **Dùng lại mẫu** | Phân tích, cách chia cảnh, kịch bản của video mẫu | Tạo **phòng mới**, chọn bộ ảnh khác, làm lại khung và clip | Có |

Không có nút "làm lại tất cả từ đầu". Muốn vậy thì thả lại video mẫu như video mới.

### 2.7 Luật thu gọn khi nhiều video
*Ảnh: `02-trang-chu-nhieu-video.png`*
1. Mỗi cột chỉ **video đầu tiên** hiện thẻ to. Video đầu là video cần chú ý nhất: đang chạy, hoặc chờ duyệt lâu nhất.
2. Các video còn lại thu thành **dòng gọn**: ảnh nhỏ, tên, dải màu, và 1 dòng việc cần làm ("Duyệt 4 khung →", "Tạo lại cảnh 2 →").
3. Cột **Mới thêm** gộp thành 1 chồng "8 video · chờ phân tích". Bấm ▾ để mở ra.
4. Cột **Đã xuất** hiện 2 video mới nhất, kèm dòng "+4 video nữa trong 7 ngày".
5. Cột dài quá màn hình thì **cuộn riêng trong cột**, đầu cột đứng yên.

---

## 3. Phòng làm việc
*Ảnh: `03-phong-lam-viec.png`*

**1 video mẫu = 1 phòng làm việc = 1 thư mục.**
- Thả 1 hoặc nhiều video là app tự tạo phòng, tự tạo thư mục, tự xếp vào hàng phân tích. **Không có bước tải lên nào khác.**
- Bấm vào phòng thì phân tích đã có sẵn.
- Ô Ghép và tab Dựng lấy tài nguyên ngay trong thư mục của phòng.
- Các phòng tách biệt hoàn toàn:
  - Mỗi phòng có `du-an.json` riêng, gồm cảnh, lời, prompt, trạng thái, timeline dựng, và tự lưu.
  - Đổi phòng rồi quay lại thì mọi thứ vẫn nguyên chỗ đang dở.
- Thanh trên của tab Tạo video và tab Dựng luôn ghi **"Phòng: <tên> ▾"** để không nhầm, bấm ▾ để đổi phòng.

> Lưu ý về ảnh 03: bước ② "Chọn bộ sản phẩm" trong ảnh đã được thay bằng mục 2.3. Thả vào ngăn sản phẩm nào thì tự dùng bộ ảnh của sản phẩm đó, chỉ hỏi khi đang ở "Tất cả".

### Thư mục tự tạo
```
SceneForge/                         ← thư mục gốc, chọn 1 lần (Màn chào / Cài đặt)
├─ Dung-chung/                      ← logo, nhạc quen
├─ Son/                             ← 1 sản phẩm
│  ├─ bo-anh/                       ← bộ ảnh tham chiếu của sản phẩm
│  ├─ Son-kem-li-mau-6/             ← 1 phòng
│  │  ├─ du-an.json                 ← "bộ não", tự lưu
│  │  ├─ 1-video-mau/               ← BẢN SAO video mẫu (xóa bản gốc ngoài máy vẫn không sao)
│  │  ├─ 2-phan-tich/               ← ảnh từng cảnh, lời gốc, bản dịch
│  │  ├─ 3-anh-tham-chieu/          ← chép từ bo-anh/, sửa riêng được
│  │  ├─ 4-khung/                   ← canh-01-ban-1.png… (giữ mọi bản)
│  │  ├─ 5-clip/                    ← canh-01-ban-1.mp4… (giữ mọi bản)
│  │  ├─ 6-giong-doc/
│  │  └─ 7-xuat/                    ← MP4 cuối
│  └─ …phòng khác…
├─ Nuoc-hoa-o-to/ …
└─ Luu-tru/                         ← hoặc đánh dấu lưu trữ trong du-an.json, không cần chuyển file
```
- Tên thư mục bỏ dấu, thay khoảng trắng bằng gạch ngang. Trùng tên thì thêm `-2`.
- Ghi file theo kiểu **an toàn**: ghi ra file tạm rồi mới đổi tên, để tắt app đột ngột không làm hỏng `du-an.json`.

---

## 4. Chạy nhiều video cùng lúc: 3 làn

| Làn | Việc | Chạy song song | Ghi chú |
|---|---|---|---|
| Phân tích | FFmpeg cắt cảnh + Gemini chép lời, viết prompt | **Tối đa 2 phòng** (đề xuất, PHẢI THỬ giới hạn Gemini rồi mới chốt) | Video khác nằm ở cột Mới thêm, ghi thứ tự |
| Flow | Tạo khung, tạo clip | **1 hàng chờ chung cho mọi phòng**, chạy lần lượt, có nghỉ | Tránh bị Google nghi là bot |
| Xuất | FFmpeg ra MP4 | 1 video mỗi lần, chạy nền | Đang xuất vẫn dựng phòng khác được |

**Mỗi việc gắn mã phòng + số cảnh + số bản.** Tải về là ghi đúng vào thư mục phòng đó, không bao giờ lẫn.

---

## 5. Luật hàng chờ Flow
1. Bấm "Duyệt hết & chạy" hoặc ▶ trên từng ô thì app **thả việc vào hàng chờ**, không chạy ngay.
   - Ô hiện lần lượt: "Đang xếp hàng · thứ n" → "Đang tạo… 37s" → "Xong".
2. Ô clip của 1 cảnh **chỉ vào hàng chờ khi khung của cảnh đó đã duyệt**. Chưa duyệt thì ghi "Chờ duyệt khung".
3. **Việc làm khung được chạy trước việc tạo clip**, để người dùng duyệt khung trong lúc clip phòng khác đang chạy.
4. Việc vào trước chạy trước. Trong 1 phòng thì chạy theo thứ tự cảnh 1, 2, 3…
5. Nút **Ưu tiên** đẩy cả 1 phòng lên đầu. **Kéo** để đổi thứ tự từng việc.
6. **Hủy** việc chưa chạy thì không mất credit.
7. **Tạm dừng cả hàng chờ:** việc đang chạy làm nốt rồi mới dừng.
8. Việc lỗi thì đánh dấu đỏ và **không tự chạy lại**, vì chạy lại là tốn credit.
9. Trước khi thả việc vào, hiện **tổng credit cả hàng chờ cần dùng**. Không đủ thì báo ngay.
10. Xem hàng chờ ở **ngăn kéo trượt từ bên phải**, mở được ở mọi tab: bấm cột credit trên thanh trái.
    - Bên trong: credit còn lại, việc đang chạy, việc xếp hàng nhóm theo phòng, các nút trên.
    - Bản nháp giao diện: `05-hang-cho-ban-nhap.png`.

---

## 6. Ô "Sang Dựng" (thay cho ô "Ghép")
*Ảnh: `04-o-sang-dung.png`*
- Ô cuối của sơ đồ tab Tạo video. Nhận: các clip đã chọn, các bản phụ, giọng đọc, nhạc của phòng.
- **2 lựa chọn:**
  - **Ghép sẵn cho tôi:** như cũ. Clip xếp đúng thứ tự cảnh, giọng và nhạc đúng mốc.
  - **Để tôi tự ghép:** timeline trống, mọi thứ nằm trong Kho, xếp theo cảnh. Có 2 ô tích:
    - "Đặt sẵn giọng đọc đúng mốc": **bật mặc định**, giọng làm "xương sống" để canh.
    - "Đặt sẵn nhạc nền": tắt mặc định.
- Nút **Mở trong Dựng**.
- **Luật không đè:**
  - Đã sang Dựng và chỉnh tay rồi mà tạo lại 1 cảnh, thì bản mới chỉ hiện trong Kho với nhãn **"bản mới"** và nút **"Thay vào timeline"**.
  - App **không tự thay** timeline.
- Đổi ý từ "tự ghép" sang "ghép sẵn" thì app **hỏi lại** trước khi thay timeline.

---

## 7. Phong cách giao diện (áp cho mọi tab)
- **Nền tối xám than:** `#101216`. Mặt thẻ `#171A20` / `#1E222A`. Đường kẻ `#23272F`.
- **Chữ:** chính `#F1F2F4`, phụ `#8A909B`, mờ `#5C626D`.
- **Màu nhấn chanh `#D4F53C`:** chỉ dùng cho nút chính và mục đang chọn.
- **Màu trạng thái:**
  - Vàng `#F5B544`: chờ người dùng.
  - Xanh dương `#3CC8E0`: đang chạy.
  - Đỏ `#F0645A`: lỗi.
  - Xanh lá `#5CD18B`: xong.
  - Tím `#A98BF5`: phân tích.
- **Font:** Inter / Inter Display (đủ dấu tiếng Việt). Có thể thay bằng Be Vietnam Pro.
- **Nguyên tắc:** ít viền, nhiều khoảng thở. Ảnh bìa là chính. Một màn hình chỉ 1–2 thứ được tô màu nổi.

---

## 8. Phải thử thật trước khi chốt số
- Giới hạn Gemini miễn phí: bao nhiêu lần mỗi phút. Kết quả quyết định số phòng phân tích song song.
- Flow chịu bao nhiêu việc liền nhau trước khi đòi xác minh, và nghỉ bao lâu giữa các việc là đủ.
- Đọc số credit từ web Flow có ổn định không.

---

## Bảng ảnh (`anh-thiet-ke/`)
| Ảnh | Nội dung |
|---|---|
| 01-trang-chu.png | Trang chủ: cột Sản phẩm có tổng quan, 6 cột chặng, 2 nút của video đã xuất |
| 02-trang-chu-nhieu-video.png | Khoảng 20 video: luật thu gọn |
| 03-phong-lam-viec.png | Thả nhiều video, mỗi video 1 phòng, cây thư mục, 3 làn chạy |
| 04-o-sang-dung.png | Ô Sang Dựng và tab Dựng ở chế độ tự ghép |
| 05-hang-cho-ban-nhap.png | Bản nháp hàng chờ và credit (chỉ lấy phần nội dung ở góc dưới trái, phong cách theo mục 7) |
