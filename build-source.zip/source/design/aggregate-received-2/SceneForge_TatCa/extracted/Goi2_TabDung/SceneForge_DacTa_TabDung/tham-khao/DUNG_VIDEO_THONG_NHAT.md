# SceneForge – Phần Dựng video: bản thống nhất chức năng

Tài liệu này dành cho người (hoặc AI) sẽ làm tiếp phần **Dựng video** của SceneForge. Phần phân tích video làm ở nơi khác.

## 0. Đọc trước: cách làm việc với chủ dự án

- Chủ dự án nói tiếng Việt, gõ bằng giọng nói nên câu hay lủng củng. Đoán ý, rồi nhắc lại ý mình hiểu trong một câu để họ sửa.
- **Viết đơn giản, không thuật ngữ kỹ thuật.** Khi báo cáo, dùng bảng: có gì, thiếu gì, giữ gì, bỏ gì, sửa gì.
- Họ mệt vì quá nhiều lựa chọn. **Tự quyết, đưa một đề nghị rõ ràng.** Hỏi tối đa 1 đến 2 câu mỗi lượt.
- **Không sửa hay chạy gì khi họ còn đang bàn.** Họ nói "chốt" mới làm.
- Nói thật cái gì chưa kiểm tra. Họ ghét nút giả và bản "mô phỏng ảo".
- Chỉ làm video **dọc 9:16**.
- **Giao diện hiện tại họ không chê, đừng đổi** (bố cục tối kiểu CapCut/Concat).
- Ưu tiên số một của họ: **kéo clip trên timeline phải mượt như CapCut.** Theo họ, đây chiếm 70 đến 80% cảm xúc khi dùng.

## 1. Trình dựng là gì

- Trình dựng chạy **trong trình duyệt**, là tab "Dựng video" của ứng dụng web SceneForge.
- Nhiệm vụ: nhận clip AI từng cảnh, ghép đúng thứ tự, cho chỉnh tay cơ bản, rồi xuất video.
- Chủ dự án **không cần CapCut đầy đủ**. Họ cần **cơ bản nhưng mượt, không lỗi**.
- Đây là mã tự viết, chỉ bắt chước bố cục của Concat. Concat thật là ứng dụng máy tính (Rust), không chạy trong trình duyệt, và có giấy phép AGPL. **Không chép mã Concat.**

Cột "Hiện trạng" dưới đây theo kết quả kiểm tra tự động. "Có" nghĩa là kiểm tra tự động chạy qua; dùng tay vẫn có thể gặp lỗi chưa bị bắt.

## 2. Timeline

| Chức năng | Làm gì | Hiện trạng | Quyết định | Có cần không |
|---|---|---|---|---|
| Kéo clip sang trái phải | Đổi vị trí clip | Có, nhưng **giật** | **Giữ, sửa cho mượt (việc số 1)** | Rất cần, dùng liên tục |
| Kéo clip lên xuống track khác | Chuyển clip sang hàng khác | Có, nhưng **giật** | **Giữ, sửa cho mượt** | Rất cần |
| Thả vào khe giữa hai hàng tạo hàng mới | Tạo track mới khi kéo | Có | Giữ | Cần |
| Chế độ Chèn | Thả vào giữa thì đẩy clip sau, không đè | Có | Giữ, làm mặc định | Rất cần |
| Chế độ Ghi đè, Đổi chỗ, Lớp riêng | Các cách thả khác | Có | Giữ | Thỉnh thoảng cần |
| Hít mốc | Clip tự dính vào mép clip khác | Có | Giữ | Rất cần |
| Tách tại vạch (Ctrl+B) | Cắt clip làm hai | Có | Giữ | Rất cần |
| Kéo mép clip | Cắt ngắn hoặc kéo dài clip | Có | Giữ | Rất cần |
| Xóa clip | Xóa, có tùy chọn tự lấp chỗ trống | Có | Giữ | Rất cần |
| Xóa khoảng trống | Dồn các clip sát nhau | Có | Giữ | Cần |
| Nhân đôi | Sao một clip | Có | Giữ | Cần |
| Chọn nhiều, quét vùng chọn, kéo nhóm | Thao tác nhiều clip cùng lúc | Có | Giữ | Cần |
| Hoàn tác, làm lại | Quay lại bước trước | Có | Giữ | Rất cần |
| Esc hủy khi đang kéo | Trả clip về chỗ cũ | Có | Giữ | Cần |
| Tự cuộn khi kéo sát mép | Timeline tự chạy theo | Có | Giữ | Cần |
| Phóng to, thu nhỏ, Vừa khung | Nhìn rộng hoặc chi tiết | Có | Giữ | Rất cần |
| Thêm track | Thêm hàng video, chữ, âm thanh | Có | Giữ | Cần |
| Nút trên đầu mỗi track | Khóa, ẩn, tắt tiếng, chỉ phát track này, lên xuống, xóa track rỗng | Có | Giữ | Cần |
| Chuyển cảnh giữa hai clip | Dấu +, kéo mép đổi thời lượng, bảng chi tiết, hòa hai hình thật | Có | **Giữ nguyên, không đụng (chủ dự án rất ưng)** | Cần |
| Tách tiếng khỏi hình, liên kết, bỏ liên kết | Âm thanh đi cùng hình | Có | Giữ | Cần |
| Xếp clip nối tiếp | Hộp đổi thứ tự cảnh | Có | Giữ | Cần |
| Cắt điểm nối | Kéo chỗ nối: clip trước dài ra, clip sau ngắn lại | Có | **Ẩn** | Ít dùng với clip AI |
| Chọn chiều cao track | Hàng to hoặc nhỏ | Có | **Ẩn** | Không cần |
| Đánh dấu mốc | Cắm cờ trên timeline | Có | **Ẩn** | Không cần |

## 3. Các phần khác

| Chức năng | Làm gì | Hiện trạng | Quyết định | Có cần không |
|---|---|---|---|---|
| Nhập tư liệu (video, nhạc, ảnh) | Thêm tệp vào kho | Có | Giữ | Rất cần |
| Nhận clip từ phần phân tích | Clip AI tự vào timeline đúng thứ tự | Có | Giữ | Rất cần |
| Phát, dừng, tua, từng khung, toàn màn hình | Xem lại bản dựng | Có | Giữ | Rất cần |
| Phát liền mạch qua chỗ cắt | Không đứng hình khi đổi clip | **Chưa chắc**, chưa kiểm tra kỹ | **Cải thiện** | Rất cần |
| Vùng an toàn | Biết chỗ bị nút TikTok che | Có | Giữ | Cần |
| Cách lấp khung 9:16 | Giữ đủ khung hoặc lấp đầy | Có | Giữ | Cần |
| Vị trí, kích thước, xoay, lật, độ mờ | Chỉnh hình của clip | Có | Giữ | Cần |
| Tốc độ clip | Nhanh, chậm | Có | Giữ | Cần |
| Màu cơ bản (sáng, tương phản, bão hòa) | Chỉnh màu nhẹ | Có | Giữ | Thỉnh thoảng |
| Đóng băng khung hình | Dừng hình một lúc | **Chưa chắc có** | **Chủ dự án chưa quyết** | Thỉnh thoảng |
| Thêm chữ, kiểu chữ dựng sẵn | Chữ trên video | Có | Giữ | Rất cần |
| Phụ đề nhập SRT/VTT, xuất SRT/ASS | Phụ đề có sẵn | Có | Giữ | Cần |
| Phụ đề tự động từ giọng nói | Máy tự nghe và ghi chữ | **Chưa có** | Làm sau | Cần nhưng không gấp |
| Thanh âm lượng mini | To nhỏ (0 đến 2.000%), tắt tiếng, mờ vào/ra, tốc độ | Có | Giữ | Rất cần |
| Lưu và mở dự án | Lưu bản dựng | Có, nhưng **mở lại phải chọn lại tệp** | **Cải thiện: tự lưu, mở lại còn nguyên cả clip** | Rất cần |
| Xuất video | Ra file thành phẩm | Có, nhưng **chỉ WebM, ghi theo thời gian thực, tối đa 2 phút** | **Cải thiện: xuất MP4 ổn định, có tiến độ, hủy được** | Rất cần |
| Đổi kiểu bố cục (Mặc định, Khung xem, Timeline) | Phóng to vùng cần làm | Có | Giữ | Cần |
| Hiệu ứng, Bộ lọc, Mẫu, Nhãn dán | Trang trí | Có | **Ẩn** | Không cần |
| Chuyển động theo thời gian (keyframe) | Clip tự phóng to, trượt dần | Có | **Ẩn** | Không cần lúc này |
| Tỉ lệ khung khác 9:16 | Ngang, vuông | Có | **Ẩn** | Không cần |
| Chụp khung PNG | Lưu một ảnh | Có | **Ẩn** | Không cần |
| Nút "Phạm vi Đã có/Còn thiếu", "Tính năng", "Thử quy trình", "Đặt lại mẫu", "Thao tác nhanh", Đổi vị trí bảng | Nút giới thiệu và nút thử | Có | **Ẩn** | Không cần, là nút demo |

"Ẩn" nghĩa là bỏ khỏi màn hình nhưng **không xóa mã**, để bật lại được.

## 4. Tóm gọn

**Ẩn:** đánh dấu mốc, cắt điểm nối, chiều cao track, hiệu ứng, bộ lọc, mẫu, nhãn dán, keyframe, tỉ lệ khung khác 9:16, chụp PNG, các nút demo.

**Cải thiện, theo thứ tự:**
1. Kéo clip trên timeline mượt, cả ngang lẫn lên xuống.
2. Phát liền mạch qua chỗ cắt.
3. Tự lưu dự án, mở lại còn nguyên cả clip.
4. Xuất MP4 ổn định, không giới hạn 2 phút.

**Thêm sau:** phụ đề tự động. Đóng băng khung hình nếu chủ dự án muốn.

**Giữ nguyên:** mọi thứ còn lại, đặc biệt là chuyển cảnh.

## 5. Vì sao kéo clip bị giật, và hướng sửa

**Phỏng đoán (đọc mã, chưa đo):** mỗi lần chuột nhích, trình dựng sao chép cả danh sách clip, tính lại vị trí tất cả, đặt lại từng khối trên timeline và vẽ lại khung xem trước. Việc đó lặp vài chục lần mỗi giây nên bị giật. Các hàm liên quan: `planSingleMove`, `planGroupMove`, `paintDragPlan` trong `scripts/demo-lite/timeline_modes.js`, gọi `updateStage` mỗi lần.

**Hướng sửa:**
1. **Đo trước bằng số** (bài kiểm tra tự động kéo clip qua lại và lên xuống, ghi thời gian mỗi khung) để biết đúng chỗ tốn.
2. Khi đang kéo **chỉ di chuyển khối đang cầm**, mọi thứ khác đứng yên. Tính sẵn các mốc hít một lần lúc bắt đầu kéo. Khung xem trước tạm dừng.
3. **Chỉ khi thả tay mới tính lại toàn bộ** và ghi bước hoàn tác.
4. Ảnh đại diện clip làm sẵn một lần. Clip lớn có bản nhẹ để timeline không nặng.
5. **Đo lại.** Mục tiêu: khoảng 60 khung hình/giây, không khựng, với 20 clip trên 3 track. Rồi để chủ dự án thử tay.
6. Nếu vẫn chưa mượt thì mới viết lại riêng phần kéo của timeline. **Không đổi giao diện, không đổi chức năng**, không làm hỏng chuyển cảnh.

## 6. Thông tin kỹ thuật

- Gói mã: `SceneForge-ChayThat.zip`. Giải nén, vào `source/`, chạy `start.bat` (Windows) hoặc `sh start.sh`, mở `http://127.0.0.1:8000/studio/`. Cần Python 3.11+ và FFmpeg.
- Build trình dựng: `cd source && python scripts/demo-web/build.py` → `dist/web-demo/native/index.html` (một tệp tự chứa). Script ghép: `scripts/native-preview/build_full_editor.py`.
- Mã trình dựng: bản gốc `scripts/demo-lite/app.js` (khoảng 900 dòng). Chồng lên trên là `enhancements.js`, `timeline_modes.js`, `interface.js`, `workstation.js`, `studio_panels.js` (trong `scripts/demo-lite/`) và `editor-integration.js`, `timeline-interactions.js`, `editing-controls.js`, `pipeline-bridge.js`, `editor-integration.css` (trong `scripts/native-preview/`). Tất cả ghép chung vào một khối khi build. Nhiều dòng rất dài, sửa chỗ này dễ hỏng chỗ khác. Chạy lại kiểm tra sau mỗi thay đổi.
- Kiểm tra tự động (cần Playwright, Chromium, FFmpeg; script gắn cứng `/usr/bin/chromium`): `scripts/native-preview/check_assembly_links.py`, `check_timeline_interactions.py`, `check_transition_details.py`, `check_full_workspace.py`, `check_audio_core.py`; `scripts/demo-web/check_integrated.py`, `check_live.py`. `check_audio_core.py` treo ở bước chờ tải file xuất trong Chromium headless, kể cả trên bản gốc chưa sửa.
- Trang cũ, đừng sửa nhầm: `single-video.html`, `native/reference.html`, thư mục `editor/` (OpenVideo), `editor-demo.html`, `concat-demo.html`.
- Tài liệu thêm: `source/docs/editor-feature-audit.md`, `source/docs/concat-reference-review.md`, `TRANG_THAI_KY_THUAT.md`.
- Bản mô phỏng chạy trong trình duyệt (riêng tư): https://claude.ai/artifact/2YCVGzgB3YRvbP4DgaCSK8
