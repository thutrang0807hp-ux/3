# SceneForge · Tab DỰNG · Đặc tả đã chốt

> Gói này dành cho người code. Đọc theo thứ tự: mục 0 (4 lỗi phải sửa trước) → các mục 1–11 → mục 12 (bài tự thử).
> Mỗi mục có ảnh thiết kế đi kèm trong thư mục `anh-thiet-ke/` (xem bảng ở cuối).
> File `tham-khao/DUNG_VIDEO_THONG_NHAT.md` là bản ghi chú gốc của chủ dự án, có vị trí code hiện tại (app.js, timeline_modes.js, check_*.py).

## Quy tắc chung (bắt buộc)
- Chỉ khung dọc 9:16.
- Tab Dựng **không gọi API trả phí**. Mọi thứ chạy trên máy (FFmpeg, 0đ).
- **Không nút giả.** Nút nào có trên giao diện thì phải chạy thật. Chưa làm được thì ẩn đi.
- **Không chép mã Concat** (giấy phép AGPL). Chỉ tham khảo ý tưởng.
- Không lưu key hay mật khẩu vào mã.
- Không bịa con số. Số MB, thời gian còn lại… phải do máy tính ra.

---

## 0. Bốn lỗi phải sửa TRƯỚC KHI thêm tính năng mới
1. **Kéo clip mượt** (ngang và dọc). Đo trước khi sửa. Nghi vấn: `planSingleMove` / `planGroupMove` /
   `paintDragPlan` trong `scripts/demo-lite/timeline_modes.js` gọi `updateStage` quá nhiều.
2. **Phát liền mạch** qua chỗ cắt và chuyển cảnh, không đứng hình.
3. **Tự lưu**: mở lại dự án thì clip còn nguyên.
4. **Xuất MP4 ổn định** bằng FFmpeg, tiếng đúng, giống y lúc xem.

## 1. Thanh công cụ timeline
*Ảnh: thanh-cong-cu-timeline-v2.png*
- Thanh mỏng, chỉ icon. Rê chuột hiện tên và phím tắt.
- **Bên trái:** Hoàn tác, Làm lại, Tách (Ctrl+B), Xóa, Nhân đôi, Thay clip, Xóa khoảng trống.
  - **Thay clip** giữ nguyên các chỉnh sửa. Clip mới dài hơn thì cắt bớt, ngắn hơn thì giữ khung cuối.
- **Bên phải:** Chế độ thả (chỉ có Chèn [mặc định] và Ghi đè), Hít mốc, Xếp clip nối tiếp, Thêm track, Zoom, Vừa khung.
- Phím tắt bị tắt khi đang gõ chữ.
- **Để sau:** Q/W cắt trái/phải, Đóng băng khung.
- **Ẩn:** marker, ripple edit, chỉnh chiều cao track, Đổi chỗ / Lớp riêng.

## 2. Bên trong timeline
*Ảnh: ben-trong-timeline-v2.png*
- **Giữ:** kéo, cắt mép, vạch hít, chọn nhiều / quét chọn / kéo nhóm, Esc trả clip về chỗ cũ (chỗ cũ hiện nét đứt), tự cuộn khi kéo sát mép.
- Kéo clip lên trên thì tạo **hàng mới tạm**. Kéo về thì hàng đó biến mất. Hàng trống tự xóa.
- Chuyển cảnh trên timeline giữ như hiện tại.
- **Đầu hàng:** rộng hơn, có vạch màu (Phụ đề cam, Video xanh dương, Giọng tím, Nhạc xanh ngọc), nút khóa / ẩn / tắt tiếng, đồng hồ âm lượng nhỏ. **Ẩn:** solo, đổi thứ tự hàng.
- Clip video hiện **ảnh khung hình thật**. Clip AI có nhãn "Cảnh 3 · bản 1".
- **Chuột phải:** Thay clip, Mở cảnh này bên tab Tạo video, Tách tiếng, Nhân đôi, Xóa.
- **Sóng âm:** chỗ quá to tô vàng.
- **Đồng hồ âm lượng tổng:** xanh / vàng / đỏ "RÈ", thang dB, vạch đỉnh.
- **Chuột:** lăn = cuộn ngang. Ctrl+lăn = zoom quanh con trỏ. Shift+lăn = cuộn dọc.
- Kéo vạch phát thì hình đổi ngay. Hình, giọng và nhạc luôn khớp.

## 3. Âm thanh
*Ảnh: bang-am-thanh-capcut.png, tab-dung-am-thanh.png*
- Bảng kiểu CapCut: có tab, mục có ô tích, nút ↺, thanh trượt kèm ô số.
- **Clip nhạc:** Âm lượng (dB), Rõ dần, Mờ dần, **Tự nhỏ khi có giọng nói** (dựa vào mốc giờ của giọng đọc, chạy trên máy), Tốc độ (luôn giữ cao độ, không có nút tắt).
- **Clip giọng đọc:** như clip nhạc, thêm tab Giọng nói gồm câu đọc, "Đọc lại câu này", "Nghe", chọn giọng.
  - Giọng dùng VieNeu-TTS (Apache 2.0, chạy trên máy). **PHẢI THỬ THẬT.**
- **Clip video:** tiếng gốc (clip Veo mặc định tắt tiếng), Rõ dần / Mờ dần, Tách tiếng ra hàng riêng.
- Xuất thì **tự cân âm lượng** cả video.
- **Để sau:** tách giọng khỏi nhạc, nhân bản giọng (chỉ giọng của mình hoặc người đã đồng ý).
- **Bỏ:** làm sạch giọng, đánh dấu nhịp, kho tiếng động, cảnh báo bản quyền.

## 4. Khung xem
*Ảnh: khung-xem-video.png*
- Space phát / dừng. ← / → lùi / tới 1 khung. Có đồng hồ giờ và nút toàn màn hình.
- **Mượt / Nét:** Mượt là bản xem nhẹ cho máy yếu. Xuất luôn dùng bản nét.
- **Lấp khung:** Giữ đủ khung / Lấp đầy.
- **"Xem như TikTok":** hiện tim, bình luận, chú thích, thanh dưới. Vùng bị che tô đỏ mờ. Lớp này **KHÔNG BAO GIỜ** đi vào file xuất.
- Kéo chữ, ảnh ngay trên khung xem, có vạch giữa. Chữ nằm trong vùng bị che thì viền đỏ.
- Bấm vào khung xem thì chọn clip tương ứng trên timeline.
- **Ẩn:** chụp PNG, khung khác 9:16.

## 5. Bảng chỉnh hình
*Ảnh: bang-chinh-hinh.png*
- **Cơ bản:** kích thước, vị trí X/Y, xoay, lật ngang / dọc, căn nhanh, độ trong, đặt lại.
- **Màu:** sáng, tương phản, bão hòa, nhiệt độ màu, nút "Áp màu cho tất cả clip".
- **Che logo:** làm mờ hoặc làm vỡ hạt một vùng, chỉnh độ mạnh, được nhiều vùng.
- **Tốc độ.**
- **Để sau:**
  - Phóng to chậm: 1 nút, gồm phóng to / thu nhỏ và mức, không keyframe, gỡ được.
  - Cắt khung, tô nền, độ nét, tự khớp màu.
- **Không làm:** mask, xóa phông, chế độ hòa trộn, chống rung, AI làm nét, làm đẹp.

## 6. Chuyển cảnh
- **Loại:** Cắt thẳng (mặc định), Hòa tan, Mờ qua đen / trắng, Lướt nhanh, Trượt 4 hướng, Phóng to / Thu nhỏ, Lóe sáng trắng.
- **Chỉnh:** độ dài (mặc định khoảng 0,3 giây), Áp cho tất cả, rê chuột để xem trước.
- **Luật:** chuyển cảnh **KHÔNG** được làm đổi tổng thời lượng, để giọng đọc không bị lệch.

## 7. Chữ và phụ đề
*Ảnh: chu-va-phu-de.png*
- **Kiểu chữ:** nội dung, font, cỡ, màu, đậm / nghiêng, căn lề, viền (màu và độ dày), bóng, nền chữ.
  - Font có dấu ✓ "Đủ dấu tiếng Việt". **PHẢI KIỂM TRA THẬT.**
- **Mẫu chữ bán hàng:** bộ kiểu chọn sẵn, chữ tĩnh, gồm Giá tiền, Giá gạch – giá mới, Giảm %, Mua ngay, Freeship, Flash sale, Chỉ còn 10 suất, Bấm giỏ hàng.
- **Phụ đề:**
  - Lấy từ node Kịch bản, tự cập nhật khi sửa kịch bản.
  - Một kiểu chữ cho cả video.
  - Tự xuống dòng, 1 hoặc tối đa 2 dòng.
  - Nhập / xuất SRT.
- **Để sau:**
  - Hiệu ứng chữ xuất hiện: 2–3 kiểu đơn giản, dạng 1 nút, không keyframe.
  - Phụ đề karaoke, tìm và thay chữ.
- **Không làm:** chữ nghệ thuật, chữ cong, chữ lặp.

## 8. Kho tư liệu
*Ảnh: kho-tu-lieu.png*
- **2 ngăn:**
  - "Dự án này": riêng từng video.
  - "📌 Dùng chung": logo, nhạc quen… mở dự án nào cũng thấy. Chỉ lưu đường dẫn file trên máy.
- Clip từ tab Tạo video **tự vào kho**, xếp theo cảnh. Bản cũ không dùng thì hiện mờ, vẫn giữ lại.
- **Nhập:** nút "+ Nhập", kéo thả file hoặc **cả thư mục**.
- **Tìm và lọc:**
  - Lọc: Tất cả / Video / Ảnh / Âm thanh.
  - Tìm theo tên.
  - Sắp xếp: mới nhất / tên / thời lượng.
- **Thẻ:**
  - Có ảnh thu nhỏ và thời lượng. Rê chuột để xem nhanh, di chuột qua lại để tua.
  - Dấu ✓ nghĩa là đã dùng trong timeline.
  - File gốc mất hoặc đổi chỗ: khung đỏ "Mất file" và nút "Tìm lại".
  - Video nặng thì máy tự tạo bản xem nhẹ, có % tiến độ.
- **Chuột phải:** Thêm vào timeline ở vạch phát, Ghim vào Dùng chung, Đổi tên, Mở thư mục chứa, Xóa khỏi kho.
- "Xóa những thứ chưa dùng" chỉ xóa khỏi kho, **không xóa file trên máy**.
- **Kéo thẻ xuống timeline:** video vào hàng Video, nhạc vào hàng Nhạc, giọng vào hàng Giọng.
- **Để sau:** thư mục con.
- **Không làm:** kho nhạc / video trên mạng.

## 9. Xuất video
*Ảnh: xuat-video-v3.png*
- Hộp kiểu CapCut: tên mục bên trái, ô chọn bên phải.
- **Tên file** và **Lưu vào** (nhớ chỗ lưu lần trước).
- **Video:**
  - Độ phân giải: **1080p** (1080×1920, để đăng TikTok, mặc định) hoặc **720p** (720×1280, để gửi Zalo).
  - Tốc độ khung hình: 30 fps mặc định, hoặc 60.
  - Định dạng: MP4, cố định.
  - Clip gốc chỉ 720p thì hiện dòng vàng báo trước.
- **Âm thanh:** ô "Tự cân âm lượng cả video".
- **Phụ đề:** ô "Xuất kèm file .srt".
- **Chân hộp:** thời lượng và dung lượng ước tính (máy tính theo độ dài và độ phân giải).
- **Kiểm tra trước khi xuất:**
  - Không tốn tiền, không gọi API, không cần mạng. Dùng dữ liệu có sẵn trong app.
  - Kiểm tra: mất file, chữ nằm trong vùng TikTok che, tiếng rè, khoảng đen trống.
  - Bấm vào dòng lỗi thì nhảy tới chỗ đó trên timeline.
  - Có lỗi thì nút chính là "Sửa lỗi trước", nút phụ là "Vẫn xuất". Không có lỗi thì chỉ có nút "Xuất".
- **Đang xuất:** thanh %, thời gian còn lại, nút Hủy xuất. Xuất chạy nền, vẫn dùng app được.
- **Xuất xong:** nút Mở thư mục và Xem lại.
- **Xử lý lỗi:**
  - Luôn ghi ra file tạm, xong hẳn mới đổi thành file thật, để **không bao giờ có file hỏng**.
  - Kiểm tra ổ đĩa đủ chỗ **trước** khi chạy.
  - Card đồ họa lỗi thì tự thử lại 1 lần bằng cách xuất thường (CPU).
  - Trùng tên file: hỏi Ghi đè hay Lưu thành tên_2.
  - Bấm Hủy thì xóa file tạm.
  - Tắt app hoặc mất điện: lần mở sau tự dọn file tạm. Dự án đã tự lưu nên không mất gì.
  - Báo lỗi bằng tiếng Việt dễ hiểu, kèm nút Thử lại và Sao chép chi tiết lỗi.
- **Để sau:** chọn ảnh bìa, chỉ xuất 1 đoạn.
- **Không làm:** tự đăng TikTok, 4K, GIF, khung khác 9:16.

## 10. Bố cục màn hình
*Ảnh: bo-cuc-dung.png, tuy-chinh-bo-cuc.png*
- **Thanh trên:**
  - Tab Tạo video / Dựng.
  - Tên dự án và "✓ Đã lưu". Lỗi lưu thì hiện chữ đỏ "Chưa lưu được".
  - Nút ▦ Bố cục và nút Xuất ở góc phải.
- **Bố cục mặc định:**
  - Kho bên trái, có các tab Tư liệu / Chữ / Chuyển cảnh / Phụ đề.
  - Khung xem ở giữa.
  - Bảng chỉnh bên phải, tự đổi theo thứ đang chọn. Không chọn gì thì hiện thông tin dự án.
  - Thanh công cụ và timeline ở dưới. Đồng hồ âm lượng tổng bên phải timeline.
- **Nút ▦ Bố cục:**
  - 4 kiểu chọn sẵn, có hình minh họa: Mặc định / Khung xem bên trái / Khung xem bên phải / Khung xem cao hết (khung xem chạy dọc hết chiều cao).
  - Không cho kéo thả khung xem tự do.
- **Đổi cỡ các vùng:**
  - Kéo đường chia giữa các vùng để nới hay thu. App nhớ cỡ cho lần sau.
  - Mỗi vùng có cỡ tối thiểu.
  - Nút ‹ gập Kho, nút › mở lại đúng cỡ cũ.
  - Nút "Đặt lại cỡ các vùng".
- Chạy được trên laptop 1366×768: gập Kho là đủ chỗ.
- **YÊU CẦU MƯỢT** khi kéo đường chia hoặc đổi kiểu bố cục:
  - Cập nhật theo từng khung hình màn hình (requestAnimationFrame), không cập nhật dồn dập.
  - Khung xem chỉ co giãn hình, **KHÔNG tải lại video**.
  - Timeline không tính lại sóng âm và ảnh khung hình khi đổi cỡ, mà dùng bản đã lưu sẵn.
  - Đang phát video mà kéo hay đổi bố cục thì vẫn phát tiếp, không giật, không dừng.
  - Đổi kiểu bố cục là đổi ngay, không tải lại dự án, không mất gì.

## 11. Liên kết với tab Tạo video
- Clip vào hàng Video, giọng vào hàng Giọng đọc, nhạc vào hàng Nhạc, đúng mốc giờ.
- Tạo lại cảnh thì clip mới thay đúng chỗ clip cũ trên timeline.
- Phụ đề lấy từ node Kịch bản. Hai tab dùng chung một dự án.

## 12. Bài tự thử (bắt buộc trước khi coi là xong)
1. Kéo 1 clip, rồi kéo cả nhóm clip qua lại 30 giây: không giật.
2. Phát qua mọi chỗ cắt và chuyển cảnh: không đứng hình, giọng khớp miệng.
3. Tắt app giữa chừng rồi mở lại: mọi thứ còn nguyên.
4. Xuất MP4 rồi so với lúc xem: giống y (hình, chữ, chuyển cảnh, tiếng).
5. Lăn chuột, Ctrl+lăn, kéo vạch phát trên video 45 giây: mượt.
6. Kéo đường chia và đổi 4 kiểu bố cục trong lúc đang phát: không giật, không dừng.

**Phải thử thật, chưa ai đo:** VieNeu-TTS đọc tiếng Việt có hay không · font có đủ dấu tiếng Việt không.

---

## Bảng ảnh thiết kế (`anh-thiet-ke/`)
| Ảnh | Mục |
|---|---|
| thanh-cong-cu-timeline-v2.png | 1. Thanh công cụ |
| ben-trong-timeline-v2.png | 2. Bên trong timeline |
| bang-am-thanh-capcut.png | 3. Bảng âm thanh (3 loại clip) |
| tab-dung-am-thanh.png | 3. Bảng âm thanh khi đặt trong tab Dựng |
| khung-xem-video.png | 4. Khung xem |
| bang-chinh-hinh.png | 5. Bảng chỉnh hình |
| chu-va-phu-de.png | 7. Chữ và phụ đề |
| kho-tu-lieu.png | 8. Kho tư liệu |
| xuat-video-v3.png | 9. Xuất video |
| bo-cuc-dung.png | 10. Bố cục toàn màn hình |
| tuy-chinh-bo-cuc.png | 10. Đổi kiểu bố cục và kéo nới vùng |

Ảnh chỉ là mô phỏng tĩnh để thấy bố cục và chữ. Màu sắc và cỡ chữ có thể chỉnh cho đẹp hơn, nhưng **không được thêm hay bớt tính năng** so với file này.
