# SceneForge · Gói 4 · Trang chủ (bản gọn) · Tài khoản · Hàng chờ 2 làn · Tab Từ ảnh → video · Kho kịch bản (chốt 21/10/2026)

> Đi cùng các gói trước:
> - Gói 1: Tab Tạo video (từ video mẫu).
> - Gói 2: Tab Dựng.
> - Gói 3: Khung sườn app.
>
> **Gói này THAY THẾ** các mục của gói 3: 2.4 (Bàn sản xuất 6 cột), 2.2 (cột Sản phẩm có thanh màu) và thanh dọc có cột đo credit.
> Phần còn lại của gói 3 (sản phẩm = ngăn + bộ ảnh + thư mục, phòng làm việc, cây thư mục, luật hàng chờ, ô Sang Dựng, phong cách giao diện) **giữ nguyên**.
>
> Ảnh trong `anh-thiet-ke/`. Chữ, số, tên tài khoản trong ảnh đều là **ví dụ**.

## Quy tắc chung (nhắc lại)
- Chỉ video dọc 9:16. Không bịa con số. **Không nút giả.**
- Không lưu key hay mật khẩu vào mã. Cookie và key lưu trên máy **phải mã hóa**.
- Không chép mã AGPL (Concat, OpenMontage). Không dùng FlowKit.
- **Không dùng dịch vụ giải captcha thuê.**

---

## 1. Hai cách làm video
| Cách | Dùng khi | Động cơ | Tiếng |
|---|---|---|---|
| 🎬 **Từ video mẫu** (gói 1) | Clone video đối thủ | Flow · Veo (flow2api) | Giọng đọc chung + Veo mấp máy miệng ở cảnh thấy mặt |
| 🖼 **Từ ảnh + ý tưởng** (mục 5) | Video show đồ vật, không thoại | Meta · Muse (muse2api) | Giọng đọc riêng (voice-over) hoặc không lời |

Nút **＋ Video mới ▾** mở ra 2 lựa chọn trên (ảnh `02-trang-chu-nut-video-moi.png`). Kéo thả video vào trang thì mặc định là **Từ video mẫu**.

---

## 2. Trang chủ · bản gọn
*Ảnh: `01-trang-chu.png`*

### 2.1 Bố cục
`[thanh dọc] [cột Sản phẩm] [khu sản phẩm đang chọn]`

### 2.2 Thanh dọc (luôn hiện)
- Logo.
- Trang chủ · Tạo video · Dựng.
- **Nút Hàng chờ** (số việc đang chạy, ví dụ "2 đang chạy"). Bấm vào thì mở ngăn kéo hàng chờ (mục 4).
- Chuông thông báo (có số đếm).
- Cài đặt.
- **Bỏ cột đo credit trên thanh dọc.** Credit xem ở Hàng chờ, tab Chi phí và màn Tài khoản.

### 2.3 Cột Sản phẩm
- "Tất cả" kèm tổng số việc cần bạn (● 4 cần bạn).
- Mỗi sản phẩm: chấm màu đại diện, tên, rồi **một trong hai**:
  - Nhãn vàng số việc cần bạn (● 2), hoặc nhãn lỗi (● 1 lỗi).
  - Nếu không có việc gì: số video.
- Nút ＋ tạo sản phẩm.
- Dưới cùng là **Lưu trữ**.
- **Không** còn thanh màu chặng hay dòng tóm tắt trong cột này.

### 2.4 Khu sản phẩm
- **Đầu khu:** dòng nhỏ "Sản phẩm", tên sản phẩm to, ô tìm, nút **＋ Video mới ▾**.
- **Tab trong sản phẩm:** **Video · Bộ ảnh · Bộ cảnh · Chi phí**.
  - Bộ ảnh: người, trang phục, sản phẩm, bối cảnh.
  - Bộ cảnh: clip theo 8 kiểu cảnh (mục 5.2).
  - Chi phí: credit của sản phẩm này.
- **Bên phải dòng tab:**
  - Bộ lọc **Tất cả / 🎬 Video mẫu / 🖼 Từ ảnh**.
  - Cách xem **Bảng / Danh sách**.

### 2.5 Tab Video · Bảng 4 cột (dùng chung cho cả 2 cách làm)
| Cột (thứ tự trái → phải) | Gồm |
|---|---|
| 🟡 **Cần bạn** | Duyệt khung, duyệt kịch bản, thiếu kiểu cảnh, clip lỗi, **đã ghép xong chờ bạn dựng và xuất** |
| 🔵 **Máy đang chạy** | Đang tạo trên Flow hoặc Meta. Nhãn ghi rõ "Flow đang chạy" hoặc "Meta đang chạy" |
| 🟣 **Đang chuẩn bị** | Mới thả vào, đang phân tích, AI đang viết kịch bản |
| 🟢 **Đã xuất** | 2 nút: **Sửa tiếp** (không tốn credit) · **Dùng lại mẫu** (làm khung và clip mới) |

- **Thẻ:**
  - Ảnh bìa có chữ móc câu.
  - Tên video.
  - Dòng nhỏ **🎬 mẫu** hoặc **🖼 ảnh**, kèm thời gian.
  - Dải ô màu theo từng cảnh.
  - 1 dòng việc hoặc trạng thái.
  - Nút việc chính nếu có.
- Video tự chuyển cột. Bấm thẻ là mở đúng chỗ đang dở.
- **Khi nhiều video:** vẫn áp luật thu gọn ở gói 3, mục 2.7 (thẻ to chỉ cho video đầu mỗi cột, còn lại là dòng gọn, cột cuộn riêng).
- **Chế độ Danh sách:** mỗi video 1 dòng, cột gồm Tên · Cách làm · Trạng thái · Việc cần làm · Cập nhật. Sắp xếp được.

### 2.6 Dọn cho nhẹ / Xóa dự án
- **Chuột phải thẻ → "Dọn cho nhẹ".**
  - **Xóa:** bản sao video mẫu, các bản clip không chọn, bản xem nhẹ, file tạm.
  - **Giữ:** phân tích, ảnh đầu mỗi cảnh, kịch bản, prompt, timeline, clip đang chọn, MP4 đã xuất, công thức trong kho.
  - App hiện số MB sẽ dọn trước khi bấm.
  - Dọn xong vẫn **Sửa tiếp** và **Dùng lại mẫu** được. Không xem lại được video mẫu, không phân tích lại được.
- Trong Lưu trữ có nút **"Dọn tất cả cho nhẹ"**. Có ô tùy chọn **"Tự dọn khi vào Lưu trữ"** (mặc định **tắt**).
- **"Xóa dự án"** xóa hết, phải hỏi lại. Công thức trong kho vẫn còn.

---

## 3. Cài đặt → Tài khoản
*Ảnh: `03-tai-khoan-flow.png` (bản đầy đủ nhất), `04-tai-khoan-meta.png`*

### 3.1 Bố cục
- **2 thẻ:** **Flow · Veo** | **Meta AI · Muse**. Hai thẻ có cùng bố cục.
- **Góc trên phải:** "Động cơ: flow2api (hoặc muse2api) · chạy trên máy · xoay vòng: BẬT/TẮT · giải captcha thuê: TẮT".
- **Dòng sức khỏe tổng:** số tài khoản · đang dùng · đang nghỉ · đòi xác minh · hết credit/lượt · bị khóa · sắp hết phiên trong 1 giờ. Bên phải dòng này:
  - "🔒 Cookie mã hóa trên máy".
  - "Động cơ có bản mới [Cập nhật]".
- **Luồng kết nối** (sơ đồ sống):
  - Dịch vụ ở giữa, tài khoản xung quanh, màu theo trạng thái.
  - Hiện số credit hoặc quota trên từng tài khoản.
  - **Chỉ tài khoản đang gửi có đường sáng nét đứt.**
- **Yêu cầu gần đây:** 20 việc gần nhất.
  - Mỗi việc ghi: loại (Ảnh làm khung / Video từ ảnh / Veo 3.1 Lite / Fast…), đoạn prompt, tài khoản, kết quả, **số credit đã trừ**, thời gian chạy, thuộc video nào.
  - Nút Xóa nhật ký, Làm mới.
- **Bảng tài khoản**, các cột:
  - Ưu tiên (kéo ⋮⋮), Tài khoản, Trạng thái, Hiệu lực phiên.
  - Credit/Quota (thanh màu chanh / vàng / đỏ, kèm giờ đọc).
  - Thành công, Thất bại, Dùng lần cuối, Ghi chú.
  - Bật (công tắc), Thao tác.
- **Trạng thái:**
  - Đang dùng · Sẵn sàng · Hết credit/lượt · Phiên hết hạn · **Đòi xác minh** · **Đang nghỉ** · Đã tắt · Bị khóa.
- **Thao tác:**
  - **Dùng tài khoản này** · **Đăng nhập lại** · **Mở để xác minh** (mở cửa sổ trình duyệt để người dùng tự làm) · **Kiểm tra**.
  - Nút ⋯: Đổi tên · Đăng xuất · Gỡ khỏi app.
- **Nút "＋ Kết nối tài khoản":** mở cửa sổ trình duyệt riêng để người dùng tự đăng nhập. App không thấy mật khẩu.
- **Bảng Chi phí credit:**
  - Credit theo ngày (7 hoặc 30 ngày).
  - Theo sản phẩm: tổng, số video, trung bình mỗi video.
  - Tỉ lệ làm khung so với làm clip.
  - **Tính từ nhật ký thật của app.**

### 3.2 Luật tài khoản
1. Mỗi lúc chỉ **1 tài khoản đang dùng** cho mỗi dịch vụ.
2. Công tắc **"Tự chuyển tài khoản khi hết credit/lượt"**: **mặc định TẮT**, có dòng cảnh báo "dễ bị khóa cả loạt".
   - **Tắt:** hết thì dừng làn đó, **kêu chuông + báo** (cả thông báo của máy tính). Người dùng bấm "Dùng tài khoản này".
   - **Bật:** tự chuyển sang tài khoản **đang Bật** kế tiếp theo **thứ tự Ưu tiên**. Mỗi lần chuyển ghi nhật ký và báo.
3. **Bị đòi xác minh thì luôn dừng hẳn** làn đó, dù xoay vòng đang bật. Không giải captcha thuê.
4. **Một video giữ một tài khoản từ đầu đến cuối** (trừ khi tài khoản đó hết, lúc đó mới đổi).
5. **3 lỗi liên tiếp → "Đang nghỉ"** một lúc → tự kiểm tra nhẹ 1 lần → ổn thì dùng lại, không ổn thì báo.
6. **Kiểm tra phiên khi mở app và trước mỗi đợt chạy.** Gia hạn phiên **chỉ khi sắp hết hạn**. Không gọi định kỳ 30 phút.
7. **Đọc mã lỗi:** 401 là đăng nhập lại. 403 là chưa chắc hết phiên. 429, lỗi máy chủ, quá giờ thì giữ trạng thái cũ.
8. **Mất kết nối khi đang tạo: chỉ hỏi lại trạng thái, KHÔNG gửi lại lệnh tạo** (tránh mất credit 2 lần).
9. **Tắt app giữa chừng:** việc dở đánh dấu "chưa xong", không tự chạy lại.
10. Credit/quota đọc **riêng từng tài khoản**, kèm giờ đọc. Đọc lỗi thì giữ số cũ và ghi rõ.

---

## 4. Hàng chờ · 2 làn chạy song song
- **Làn Flow · Veo:** việc của cách làm 🎬 (làm khung, tạo clip).
- **Làn Meta · Muse:** việc của cách làm 🖼 (Bộ cảnh, khung trước).
- Hai làn chạy **song song**. **Mỗi làn chạy lần lượt từng việc**, có nghỉ.
- Luật hàng chờ (gói 3, mục 5) áp cho **từng làn**: khung trước clip, Ưu tiên, kéo đổi thứ tự, Hủy việc chưa chạy không mất credit, Tạm dừng, việc lỗi không tự chạy lại.
- **Ngăn kéo Hàng chờ:** mỗi làn ghi tài khoản đang dùng và credit hoặc quota còn lại, danh sách việc, nút **Tạm dừng cả 2 làn**.
- Ảnh tham khảo: `05-hang-cho-2-lan.png` (chỉ lấy phần ngăn kéo bên phải; phần Tài khoản bên trái là bản cũ, đã thay bằng mục 3).

---

## 5. Tab Từ ảnh + ý tưởng → video (Muse)
*Ảnh: `06-tab-tu-anh-dao-dien.png` (bản chốt), `07-clip-muse-trang-thai-loi.png` (cách hiện lỗi từng clip)*

**Bỏ kiểu "mỗi câu kịch bản tạo 1 clip".** Làm sẵn **Bộ cảnh** cho sản phẩm, rồi **Đạo diễn AI** đọc kịch bản và chọn clip để ghép.

```
Ảnh SP + bối cảnh ──► Bộ cảnh sản phẩm (Muse, làm 1 lần, dùng lại) ──┐
                                                                    ├─► Đạo diễn AI ghép ──► Sang Dựng
Công thức ──► Kịch bản ──► Giọng đọc ───────────────────────────────┘
```

### 5.1 Ảnh đầu vào
- Sản phẩm (chính), bối cảnh, người (tùy chọn, ví dụ chỉ bàn tay).
- Tự lấy từ Bộ ảnh của ngăn sản phẩm.

### 5.2 Bộ cảnh sản phẩm
- **8 kiểu cảnh**, mỗi kiểu có **prompt mẫu sẵn** (máy quay, ánh sáng, chuyển động):
  - 🔍 Cận cảnh xoay
  - 🏷 Chi tiết
  - 🚗 Trong bối cảnh dùng
  - ✋ Tay thao tác (không lộ mặt)
  - 😣 Vấn đề
  - ✨ Kết quả
  - 🌇 Toàn cảnh
  - 🛒 Kêu gọi mua (chừa chỗ trống cho chữ giá)
- Prompt luôn kèm **"no talking, mouth closed"**, không chữ trên hình, 9:16.
- **Lưu trong ngăn sản phẩm, dùng lại cho mọi video** của sản phẩm đó (tab Bộ cảnh ở trang chủ).
- Mỗi ô ghi số clip đã có, đang tạo, hay chưa có. Có nút **＋ Tạo thêm**. Chạy qua làn Meta.
- ⚠️ **Muse lấy ảnh đưa vào làm KHUNG ĐẦU của video** (theo README muse2api).
  - Kiểu cảnh nào **đổi bối cảnh** so với ảnh gốc (ví dụ chai nền trắng → trong xe) thì **tự làm khung trước** bằng chức năng sửa ảnh theo ảnh mẫu, rồi mới làm video.
  - Mỗi kiểu cảnh có tùy chọn "＋ khung trước" để bật hoặc tắt tay.
- **Xử lý lỗi từng clip** (ảnh 07):
  - **Lỗi kỹ thuật:** tự thử lại 1 lần, rồi mới báo đỏ kèm nút Tạo lại.
  - **Meta từ chối nội dung:** không tự thử, hiện lý do, nút "Sửa prompt rồi tạo lại".
  - **Hết lượt hoặc xác minh:** theo mục 3.2.
  - **Tạo lại:** giữ bản cũ, có ô "muốn sửa gì?", có tùy chọn **"Tạo 2 bản cùng lúc"**.
  - Một clip lỗi thì các clip khác vẫn chạy.

### 5.3 Kịch bản
- **2 cách:**
  - ✍️ Tự viết hoặc dán vào.
  - 🤖 AI viết theo **công thức** từ vài ý chính (mặc định).
- Kịch bản chia **nhịp**. Mỗi nhịp có tên (Hỏi / Giải pháp / Lợi ích / Dùng thử / Mua), số giây, lời đọc và **nhãn kiểu cảnh** (để đạo diễn biết lấy clip nào).
- **Công thức** lấy từ **Kho kịch bản** (mục 7, chưa chốt).

### 5.4 Giọng đọc · 3 nguồn
- **Tạo bằng AI** (mặc định): VieNeu-TTS v3, chạy trên máy, 0đ, có mốc giây từng câu.
- **Thả file có sẵn** (mp3 / wav / m4a):
  - App tự nghe chỗ ngắt hơi để chia nhịp (0đ).
  - Các nhịp **tự co giãn theo giọng của người dùng**.
  - Nút "Chép lời thành phụ đề" (Gemini, rất ít tiền), không bắt buộc.
- **Không lời:** chỉ nhạc + chữ.
- Cài đặt có sẵn lựa chọn **VieNeu V4 (trả phí, cần key)** làm dự phòng. Theo bảng giá vieneu.io người dùng chụp: khoảng 965đ / 1.000 ký tự, tức vài trăm đồng mỗi video.

### 5.5 Đạo diễn AI ghép
- **Đầu vào:** kịch bản (nhịp + nhãn kiểu cảnh) + mốc giây của giọng đọc + danh sách clip trong Bộ cảnh (đã gắn kiểu cảnh lúc tạo).
- **Làm:**
  - Mỗi nhịp chọn clip hợp nhất, cắt cho khớp giọng.
  - **Không lặp một clip 2 lần liền nhau.**
  - Nhịp dài thì ghép 2 clip cùng kiểu.
- **Chỉ đọc chữ** (Gemini), không xem video, nên tốn rất ít. Hiện số tiền thật sau mỗi lần chạy.
- **Thiếu kiểu cảnh:**
  - Báo đỏ, kèm 2 nút "Tạo bổ sung" (gửi làn Meta) và "Dùng tạm [cảnh khác]".
  - **Không tự tạo khi chưa hỏi.**
- Nút **"Ghép kiểu khác"**: ra phương án khác từ cùng Bộ cảnh.
- Hiện timeline xem trước: thanh clip theo nhịp và sóng giọng đọc bên dưới.

### 5.6 Sang Dựng
- Chọn "Dùng bản đạo diễn ghép" hoặc "Để tôi tự ghép".
- Tiếng gốc clip Muse **tắt sẵn**.
- Luật không đè timeline như gói 3, mục 6.

### 5.7 Thanh dưới
- Ví dụ: "Bộ cảnh có sẵn **11 clip** · cần tạo thêm **1 kiểu** · giọng 0đ · đạo diễn ghép rất ít tiền".
- Nút **Tạo phần thiếu & ghép**.

---

## 6. Repo dùng làm động cơ

### A. DÙNG MÃ (chạy ngầm trên máy, app gọi qua 127.0.0.1)
1. **flow2api**: https://github.com/TheSmallHanCat/flow2api (MIT)
   - Dùng cho: Flow / Veo 3.1 Lite / Fast, video từ ảnh, khung đầu + cuối, tối đa 3 ảnh tham chiếu, nâng 1080p, đọc credit, `/api/tokens`.
   - **PHẢI chỉnh:**
     - Đổi admin/admin và API key mẫu `han1234`.
     - Chỉ nghe 127.0.0.1. Không mở `/metrics` ra ngoài.
     - Captcha: chế độ **personal**. KHÔNG YesCaptcha / CapMonster / EzCaptcha / CapSolver.
     - Chỉ nạp **1 tài khoản đang dùng**, app tự đổi.
     - Cache timeout khác 0.
2. **muse2api (repo GỐC)**: https://github.com/czg86389-hub/muse2api (MIT, bản 1.6.1, 13/10/2026)
   - Dùng cho: tạo ảnh, sửa ảnh theo ảnh mẫu (khung trước), video từ ảnh (9:16, 5/6/8/10 giây), đọc quota.
   - **PHẢI chỉnh:**
     - `MUSE2API_CONCURRENCY=1`.
     - Chỉ nạp 1 tài khoản đang dùng.
     - Heartbeat **không** chạy định kỳ, chỉ gia hạn khi sắp hết hạn (xem mã để sửa).
     - Dùng task bất đồng bộ + `Idempotency-Key`.
3. **VieNeu-TTS**: https://github.com/pnnbao97/VieNeu-TTS (Apache 2.0, v3 Turbo, chạy CPU được).

### B. CHỈ HỌC Ý
4. **gpt-load**: https://github.com/tbphp/gpt-load (MIT). Lấy ý: mã hóa thông tin đăng nhập, nghỉ và tự phục hồi, ưu tiên, giữ 1 tài khoản cho 1 video, bảng chi phí.
5. **Gemini-API**: https://github.com/HanaokaYuzu/Gemini-API (README không ghi giấy phép → chưa chép mã).
   - Ý **để sau**: chạy phần Phân tích bằng tài khoản Google AI Pro thay key Gemini.
   - Dự phòng cùng loại: https://github.com/shenmintao/Gemini-FastAPI

### C. KHÔNG DÙNG
- Các bản sao (fork) của muse2api / flow2api có mô tả y hệt bản gốc. Chúng giữ cookie tài khoản, nên chỉ dùng repo gốc và **đọc mã trước khi chạy**.
- Dịch vụ giải captcha thuê.
- Concat, OpenMontage (AGPL). FlowKit.

### Tham khảo cách tổ chức giao diện (chỉ học ý)
- Plane (quản lý công việc mã nguồn mở): nhiều cách xem (Bảng / Danh sách), nhóm theo trạng thái, lọc, chia tab trong mỗi dự án.
- MoneyPrinterTurbo: giữ màn chính đơn giản, cấu hình để riêng một chỗ.

---

## 7. Kho kịch bản · ĐÃ CHỐT (bản nhẹ)
*Ảnh: `08-kho-kich-ban.png`*

### 7.1 Vai trò
- **Chỉ tab Từ ảnh dùng kho.** Tab Từ video mẫu lấy lời từ chính video mẫu.
- **Một kho chung cho mọi sản phẩm**, lọc theo ngành.
- **Công thức** = tên + ngành + kiểu video + thời lượng + các **nhịp**. Mỗi nhịp gồm: tên, giây bắt đầu–kết thúc, mục đích, kiểu cảnh gợi ý, câu ví dụ **đã viết lại**. Kèm "mẹo của công thức".
- **Không lưu nguyên lời của video gốc.**

### 7.2 Nguồn vào kho
1. **Tự động:** mọi video mẫu đã phân tích ở tab Từ video mẫu **tự sinh công thức**, nhãn "🎬 từ video mẫu".
   - Chỉ tốn 1 lần Gemini đọc chữ (ước tính vài trăm đồng, chưa đo thật).
   - Xóa được từng công thức không muốn giữ.
2. **＋ Thêm → Từ video bạn chọn:** người dùng chọn file, app phân tích rồi lưu khung sườn. Nhãn "✋ bạn thêm". Phải phân tích từ đầu, ước tính 1.000–2.000đ mỗi video.
3. **＋ Thêm → Tự gõ:** nhập nhịp, số giây, câu ví dụ.
- **KHÔNG làm** Hộp thu (thư mục theo dõi). **KHÔNG làm** extension tự quét mạng xã hội.

### 7.3 Giao diện (bảng nổi, mở khi bấm ô Công thức trên sơ đồ tab Từ ảnh, đóng ✕ là về sơ đồ)
- **Đầu bảng:**
  - Ô tìm.
  - Lọc ngành (Tất cả / Đồ xe / Mỹ phẩm / Đồ bếp…).
  - Lọc nguồn (Mọi nguồn / 🎬 Từ video mẫu / ✋ Bạn thêm).
  - Nút **＋ Thêm ▾**.
- **Bên trái, danh sách 2 nhóm:**
  - **⭐ Hợp với [sản phẩm]:** AI chọn 2–3 công thức theo ngành, ý chính và số 👍.
  - **Tất cả:** nhiều 👍 trước.
  - Mỗi dòng: tên + nhãn ngành · một dòng số liệu (thời lượng · số nhịp · đã dùng mấy lần · 👍 · 👎) + nhãn nguồn · **dải màu nhịp**. Mỗi màu là một loại nhịp, dài ngắn theo số giây.
  - Không có ảnh nhỏ.
- **Bên phải, chi tiết:**
  - Tên, nhãn, thời lượng.
  - Video nguồn (ảnh nhỏ + tên phòng + số lần dùng + 👍/👎).
  - Dải nhịp lớn có thang giây.
  - Từng nhịp: giây, mục đích, kiểu cảnh gợi ý, câu ví dụ.
  - Mẹo.
  - Nút **Đổi tên · Xóa · Dùng công thức này**.
- **Bảng màu nhịp:**
  - Hỏi / Vấn đề: đỏ
  - Giải pháp: xanh dương
  - Lợi ích: tím
  - Dùng thử: cam
  - Bằng chứng: vàng
  - Chốt: chanh

### 7.4 Cách dùng
- **Bấm "Dùng công thức này":** đóng kho, AI viết kịch bản theo khung đó vào ô Kịch bản (lời mới cho sản phẩm hiện tại).
- **Không mở kho:** AI tự dùng công thức đứng đầu nhóm "⭐ Hợp với…". Ô Kịch bản có ô thả xuống để đổi.
- **👍 Ra đơn / 👎 Không ăn thua:** 2 nút trên thẻ video ở cột **Đã xuất** (trang chủ). Không bắt buộc. Điểm được cộng cho công thức mà video đó đã dùng.

### 7.5 Để đợt sau (chưa làm)
- Ngăn "câu mở đầu hay", "câu chốt hay".
- Nhập số liệu chi tiết (lượt xem, số đơn).
- Extension "Gửi vào SceneForge" bấm tay 1 nút.

---

## 8. Phải thử thật trước khi code nhiều
- flow2api / muse2api: tắt được tự xoay vòng và gia hạn định kỳ không. Đọc được credit / quota ổn định không.
- Muse:
  - Watermark (người dùng xem rồi, chưa thấy).
  - 9:16 và thời lượng thật.
  - Số lượt mỗi ngày.
  - Ảnh nền trắng + mô tả "trong xe" ra kết quả gì.
  - Sửa ảnh theo ảnh mẫu có giữ đúng nhãn sản phẩm không.
- Flow: video từ 3 ảnh tham chiếu có giữ đúng mặt và nhãn không. Nâng 1080p tốn bao nhiêu credit.
- VieNeu v3: giọng miền Nam có tự nhiên không, máy người dùng chạy nhanh hay chậm.
- Nghỉ bao lâu giữa các việc, và bao nhiêu việc mỗi giờ là an toàn cho mỗi dịch vụ.

---

## Bảng ảnh (`anh-thiet-ke/`)
| Ảnh | Nội dung |
|---|---|
| 01-trang-chu.png | **Trang chủ bản gọn (chốt)**: 4 cột, tab trong sản phẩm, lọc, Bảng/Danh sách |
| 02-trang-chu-nut-video-moi.png | Chỉ lấy **hộp mở của nút Video mới** (2 cách làm). Phần còn lại của ảnh là bản cũ |
| 03-tai-khoan-flow.png | **Tài khoản bản đầy đủ (chốt)**: sức khỏe tổng, luồng kết nối, nhật ký, bảng ưu tiên, chi phí |
| 04-tai-khoan-meta.png | Thẻ Meta: bố cục giống 03, động cơ muse2api. Thêm công tắc xoay vòng và dòng sức khỏe như 03 |
| 05-hang-cho-2-lan.png | Ngăn kéo hàng chờ 2 làn (phần bên phải) |
| 06-tab-tu-anh-dao-dien.png | **Tab Từ ảnh → video (chốt)**: Bộ cảnh + Kịch bản + Giọng + Đạo diễn AI ghép |
| 08-kho-kich-ban.png | **Kho kịch bản (chốt)**: danh sách 2 nhóm, lọc ngành và nguồn, nút ＋ Thêm, chi tiết công thức |
| 07-clip-muse-trang-thai-loi.png | Cách hiện trạng thái lỗi, tạo lại, nhiều bản cho clip Muse (áp cho từng ô trong Bộ cảnh). Ô Khung riêng trong ảnh này đã bỏ |
