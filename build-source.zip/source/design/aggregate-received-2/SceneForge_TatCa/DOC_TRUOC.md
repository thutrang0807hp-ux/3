# SceneForge · Đọc trước

## Gói nào ghi đè gói nào
- Gói 4 thay gói 3 ở mục 2.2, mục 2.4 và đồng hồ trên thanh trái.
- Gói 5, ảnh 02, thay ảnh tab Tạo video trong gói 1. Chức năng gói 1 giữ nguyên.
- Gói ra sau được ưu tiên hơn gói ra trước.

## Thứ tự làm đề xuất
1. **Thử thật** theo `SceneForge_BangThuThat.xlsx`, làm các dòng 🔴 trước. Dòng nào không đạt thì đổi theo cột "Không đạt thì".
2. **Khung app và động cơ:** thanh trái, phòng, thư mục lưu, flow2api / muse2api / VieNeu / FFmpeg, trang Tài khoản (gói 3, 4, 5).
3. **Tab Tạo video** (gói 1 + gói 5 mục 7).
4. **Tab Dựng và Xuất** (gói 2).
5. **Trang chủ, Từ ảnh, Kho kịch bản** (gói 4).
6. **Cài đặt, Thông báo, Màn chào** (gói 5).

## Luật chung
- Không nút giả.
- Không bịa số.
- Không lưu key, cookie ở dạng chữ thường.
- Không chép mã AGPL.
- Đăng nhập Google chỉ nằm trên máy người dùng.
