# SceneForge · Gói 5 · Cài đặt · Thông báo · Màn chào lần đầu (chốt 21/10/2026)

> Đi cùng gói 1–4. Phong cách giao diện như gói 3, mục 7 (nền tối, màu nhấn chanh `#D4F53C`, vàng là "cần bạn").
> Ảnh: `anh-thiet-ke/01-cai-dat-thong-bao-man-chao.png`, `anh-thiet-ke/02-tab-tao-video-ban-gop.png`. Key, số liệu, tên trong ảnh là **ví dụ**.
> Người dùng **giao toàn quyền kỹ thuật** phần này cho người code, miễn giữ đúng các luật bên dưới.

## Quy tắc chung (nhắc lại)
- Không lưu key, mật khẩu, cookie dạng chữ thường. **Phải mã hóa** (mục 5).
- **Không nút giả.** Chưa làm được thì ẩn đi.
- **Không bịa con số.** Chi phí, dung lượng, credit đều đọc hoặc đo thật.

---

## 1. Cài đặt: menu trái
`Tài khoản · Phân tích (AI) · Giọng đọc · Thư mục lưu · Xuất video · Thông báo · Động cơ`
- Mục nào có vấn đề thì hiện **số vàng** cạnh tên (ví dụ Động cơ có bản mới, key hết hạn).
- **Tài khoản:** đã chốt ở gói 4, mục 3.

### 1.1 Phân tích (AI)
- **Nguồn AI** (chọn 1):
  - **Key Gemini · gói miễn phí** (mặc định). Ghi rõ: có giới hạn số lần, **Google được dùng dữ liệu gửi lên để huấn luyện**.
  - **Key Gemini · trả phí.** Ghi rõ: không dùng dữ liệu để huấn luyện, tính tiền theo lượng dùng.
  - **Tài khoản Google AI Pro:** hiện mờ, nhãn "để sau" (gói 4, mục 6.B.5).
- **Ô key:** che bớt ký tự, biểu tượng 🔒 (đã mã hóa). Nút **Kiểm tra key**, kết quả "✓ Key dùng được · giờ kiểm tra" hoặc báo lỗi rõ ràng. Có link "Cách lấy key Gemini miễn phí".
- **Chi phí đo thật tháng này:** số lần gọi AI · số tiền (0đ nếu gói miễn phí) · số lần chạm giới hạn (app tự chờ rồi chạy tiếp).
  - Dùng key trả phí thì hiện tiền thật theo từng lần phân tích, từng video.
  - **Lấy từ nhật ký gọi AI của app, không ước đoán.**
- **Chạm giới hạn gói miễn phí:** app **tự chờ rồi chạy tiếp**. Không báo lỗi trừ khi chờ quá lâu.

### 1.2 Giọng đọc
- **Nguồn:**
  - **VieNeu-TTS v3 chạy trên máy** (mặc định, 0đ).
  - **VieNeu V4 trả phí** (cần key, theo bảng giá vieneu.io người dùng chụp: khoảng 965đ / 1.000 ký tự).
- **Giọng mặc định:** danh sách giọng, lọc theo vùng Bắc / Trung / Nam. Mặc định một giọng **nữ miền Nam**.
- **Tốc độ mặc định:** 0.8× – 1.3×.
- Ô thử: gõ câu, bấm **▶ Nghe thử**.
- **Nhân bản giọng:** để sau (chỉ giọng của mình hoặc người đã đồng ý).

### 1.3 Thư mục lưu
- **Thư mục gốc** và nút Đổi.
- **Dung lượng đang dùng:** tổng và theo từng sản phẩm. Đo thật bằng cách quét thư mục.
- Nút **Dọn tất cả cho nhẹ** (luật dọn ở gói 4, mục 2.6). Hiện số MB sẽ dọn trước khi bấm.
- Nút **Chuyển sang ổ khác:**
  - App chép hết dự án sang chỗ mới, kiểm tra đủ file rồi mới xóa chỗ cũ, có thanh %.
  - Không đủ chỗ trống thì báo **trước** khi bắt đầu.
- Cảnh báo vàng khi ổ đĩa còn ít chỗ. Ngưỡng báo do người code đặt, có thể chỉnh.

### 1.4 Xuất video (giá trị mặc định cho hộp Xuất đã chốt ở gói 2)
- **Tự bỏ logo Veo: bật** (xem mục 7.3).
- Độ phân giải mặc định: **1080p** / 720p.
- Khung hình / giây: **30** / 60.
- Tự cân âm lượng: **bật**.
- Kèm phụ đề .srt: **tắt**.
- Nơi lưu file xuất: **trong thư mục phòng** (`7-xuat/`, mặc định), hoặc một thư mục chung do người dùng chọn.

### 1.5 Thông báo
- Bật / tắt từng loại (mục 2).
- **Âm thanh:** bật / tắt, chọn 1 trong vài tiếng có sẵn, nghe thử.
- **Thông báo của máy tính:** bật / tắt (chỉ áp cho nhóm Cần bạn và Xuất xong).

### 1.6 Động cơ
- **Danh sách:** flow2api · muse2api · VieNeu-TTS · FFmpeg. Mỗi dòng: chấm màu, trạng thái (đang chạy / sẵn sàng / lỗi / có bản mới), phiên bản.
- **Nút:**
  - **Cập nhật** từng động cơ (giữ nguyên tài khoản và dữ liệu).
  - **Khởi động lại tất cả.**
  - **📋 Sao chép chi tiết lỗi:** gom nhật ký lỗi gần nhất của app và các động cơ thành 1 đoạn để dán gửi người code. **Tự xóa key và cookie khỏi đoạn này trước khi chép.**

---

## 2. Thông báo (chuông)
### 2.1 Ba mức
| Mức | Khi nào | Báo kiểu gì |
|---|---|---|
| 🟡 **Cần bạn** | Khung chờ duyệt · thiếu kiểu cảnh · clip lỗi · hết credit/lượt · đòi xác minh · đạo diễn ghép xong chờ dựng | Chuông + **tiếng kêu** + **thông báo của máy tính** (kể cả khi thu nhỏ app hay tab ở chế độ nền) |
| 🟢 **Xong việc** | Phân tích xong · Bộ cảnh xong · **xuất video xong** | Chuông + **thông báo nhỏ góc màn hình** (tự ẩn), **không kêu**. Riêng xuất xong có thêm thông báo của máy tính |
| ⚪ **Thông tin** | Đã tự chuyển tài khoản · động cơ có bản mới · chạm giới hạn AI (đã tự chờ) | Chỉ nằm trong chuông |

### 2.2 Luật
- **Gom nhóm:** cùng loại trong vài phút thì gộp 1 dòng, ví dụ "5 khung chờ duyệt ở 2 video", kèm tên video và số lượng.
- **Mỗi dòng có nút làm ngay:** Duyệt · Chuyển tài khoản · Mở để xác minh · Mở thư mục · Xem lỗi. **Bấm dòng là nhảy đúng chỗ.**
- Lọc **Tất cả / Cần bạn / Xong việc**. Nút **Đánh dấu đã xem hết**.
- **Số trên chuông** = số thông báo **Cần bạn** chưa xem.
- **Giữ 30 ngày** gần nhất.

---

## 3. Màn chào lần đầu (chỉ hiện lần đầu mở app, hoặc khi chưa có thư mục lưu)
- **Bên trái:** lời chào + danh sách 5 bước. **Bên phải:** nội dung bước hiện tại, nút Quay lại / Tiếp tục / **Bỏ qua** (trừ bước 1).

| Bước | Nội dung | Bắt buộc |
|---|---|---|
| 1 | **Chọn thư mục lưu.** Gợi ý ổ còn trống nhiều nhất | ✅ |
| 2 | **Kiểm tra máy** (app tự làm, hiện ✓ từng món): FFmpeg · tải mô hình VieNeu lần đầu (thanh %) · cài và khởi động flow2api, muse2api (đổi mật khẩu mặc định, chỉ nghe trên máy này) · dung lượng ổ đĩa | Tự chạy |
| 3 | **Key Gemini:** dán key, Kiểm tra, link hướng dẫn | Bỏ qua được |
| 4 | **Kết nối Flow / Meta:** nút mở cửa sổ đăng nhập (giống Cài đặt → Tài khoản) | Bỏ qua được |
| 5 | **Sản phẩm đầu tiên:** gõ tên, thả vài ảnh sản phẩm → vào trang chủ | Bỏ qua được |

- **Bỏ qua bước nào** thì app hiện **lời nhắc ngay tại chỗ cần dùng**, ví dụ ở ô Video Veo: "⚠ Chưa kết nối Flow · Kết nối ngay". **Không chặn** các phần khác.
- **Bước 2 có món lỗi:** hiện lý do + nút **Thử lại** + **📋 Sao chép chi tiết lỗi**. Lỗi động cơ không chặn dùng app (chỉ chặn phần cần động cơ đó).

---

## 4. Lưu ý kỹ thuật cho người code
- App hiện tại: **Python làm nền** (`source/app.py`), **giao diện mở trên trình duyệt** tại `http://127.0.0.1:8000/studio/`.
- **flow2api / muse2api:** README khuyên chạy bằng Docker. Trên Windows, **ưu tiên chạy thẳng bằng Python** (cả hai đều có cách chạy này) để người dùng **không phải cài Docker**. Chỉ dùng Docker khi không còn cách khác.
- Động cơ do app **tự khởi động khi mở app** và **tự tắt khi thoát app**. Kiểm tra sức khỏe qua địa chỉ có sẵn (flow2api có `/health`).

## 5. Thư viện gợi ý (nhỏ, phổ biến · kiểm tra lại giấy phép và phiên bản khi cài)
| Việc | Dùng | Giấy phép (theo hiểu biết, cần kiểm lại) |
|---|---|---|
| Mã hóa key, cookie | **keyring** (cất khóa chính vào kho mật khẩu Windows) + **cryptography** (mã hóa file cookie) | MIT · Apache 2.0 / BSD |
| Thông báo có tiếng | **Notification API của trình duyệt** + file âm thanh ngắn | Có sẵn |
| Thông báo khi trình duyệt đã đóng | **desktop-notifier** (Python) | MIT |
| Lưu cài đặt | File JSON, vị trí lấy bằng **platformdirs** | MIT |
| Kiểm tra ổ đĩa, FFmpeg | `shutil.disk_usage`, `shutil.which` | Có sẵn trong Python |
| Tải mô hình giọng có thanh % | **huggingface_hub** | Apache 2.0 |
| Chạy, dừng, kiểm tra động cơ | `subprocess` + gọi thử `/health` | Có sẵn |
| Thông báo nhỏ góc màn hình, màn chào | Tự viết bằng giao diện hiện có | Không cần thư viện |

## 6. Phải thử thật
- flow2api / muse2api chạy thẳng bằng Python trên Windows có ổn không, có cần quyền quản trị không.
- Notification API của trình duyệt có kêu và hiện được khi tab ở chế độ nền hoặc trình duyệt bị thu nhỏ không.
- Dung lượng và thời gian tải mô hình VieNeu v3 lần đầu.

---

## 7. Tab Tạo video · bản gộp (chốt 21/10/2026)
Ảnh `02-tab-tao-video-ban-gop.png`. **Thay ảnh tab Tạo video trong gói 1** (chức năng gói 1 giữ nguyên). Ảnh gộp 3 thứ: giao diện mới, các điểm hay của giao diện cũ trong app, và các phần chốt sau gói 1.

### 7.1 Lấy lại từ giao diện cũ
- **Video tham khảo:** kéo thả hoặc chọn file (MP4, MOV, WebM, dọc 9:16). Có dòng "🔒 Chỉ lưu trên máy này" và nút Xem / Thay.
- **Phân tích:** 6 bước, mỗi bước có 1 dòng giải thích nhỏ:
  - Cắt ở chỗ chuyển cảnh
  - Gộp đoạn ngắn, clip ≤ 8s, giữ trọn câu thoại
  - Khung đầu · giữa · cuối, đổi được từng cảnh
  - Chép lời có mốc giây (SRT/VTT, nhận cả giọng nói, nhập được)
  - Prompt chi tiết từng cảnh
  - Rà logo / chữ trong hình
- **Ảnh tham chiếu:** Người · Trang phục · Sản phẩm · Bối cảnh. Có thêm ô **mô tả bằng chữ**.
- **Video Veo:** nút **⤓ Nhập clip làm sẵn trên Flow**. Người dùng thả clip tự tạo trên web Flow vào đúng cảnh, app giữ nhiều bản để chọn.
- **Sang Dựng:**
  - "n/6 cảnh có clip · giữ mọi bản đã nhập".
  - Ghép sẵn = clip đúng thứ tự cảnh, giữ tiếng từ Flow.
  - Tự ghép = clip nằm trong Kho, chưa đặt lên hàng video.
  - **Clip tạo lại chỉ thêm vào Kho, không tự thay hàng video đã chỉnh.**
- **Bảng nối ô:** bản đồ nhỏ, zoom (− 100% + ⤢), dòng nhắc "Kéo tiêu đề để nhấc ô · Space + kéo nền". Mỗi ô có cổng nối theo loại dữ liệu như bản cũ.
- **Thanh dưới:** trạng thái Credit Flow (đã xác minh / chưa xác minh) + ước tính + nút **Duyệt hết & chạy**.

### 7.2 Chữ & nhạc (trong ô Sang Dựng)
- **Phụ đề:** mặc định **tự lấy từ lời đọc**, dùng mốc giây có sẵn. Chọn kiểu chữ theo mẫu chữ của tab Dựng (gói 2).
- **Nhạc nền:** chọn từ Kho tư liệu hoặc nhập file.
- **Vặn nhỏ nhạc khi có giọng:** mặc định bật.
- Các lựa chọn này chỉ là điểm bắt đầu. Sửa từng chữ, kéo đoạn nhạc thì làm trong tab Dựng.

### 7.3 Tự bỏ logo Veo
- **Không có nút trên giao diện.** App tự bỏ logo nhìn thấy được **ngay khi tải clip về, trước upscale 1080p và trước khi Dựng**. Cách tính ngược chỉ chuẩn khi hình chưa bị đổi kích thước hay nén lại.
- **Bản gốc** lưu ngầm trong thư mục phòng. Dựng dùng bản đã bỏ logo.
- **Chỉ hiện khi lỗi:** 1 dòng vàng "⚠ Chưa bỏ được logo Veo" + nút **Thử lại** trên đúng clip đó. App dùng tạm bản gốc và không chặn các bước khác.
- **Tắt / bật:** Cài đặt → Xuất video (mục 1.4).
- **Thông báo Xuất xong** (góc phải dưới, sau đó nằm trong 🔔) có 1 dòng nhắc: "Khi đăng TikTok nhớ tick *Nội dung do AI tạo*".
- Chỉ bỏ được logo nhìn thấy. **Dấu ẩn SynthID vẫn còn.**

| Việc | Dùng | Giấy phép |
|---|---|---|
| Bỏ logo Veo | **gwmr** (Python, `pip install gwmr`, cần FFmpeg): https://pypi.org/project/gwmr/ | MIT |
| Dự phòng | **VeoWatermarkRemover / GeminiWatermarkTool** (allenk, C++): https://github.com/allenk/GeminiWatermarkTool | MIT, giữ thông báo bản quyền |

**Phải thử thật:**
- gwmr còn mới (các bản đều ra ngày 25/07/2026). Thử với clip tải từ Flow, cả 720p lẫn 1080p, và kiểu logo cũ / mới.
- Đo thời gian chạy một clip 8s.
