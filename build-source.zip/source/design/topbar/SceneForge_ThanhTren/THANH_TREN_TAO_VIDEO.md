# SceneForge · Thanh trên tab Tạo video · 2 dòng (chốt 22/10/2026)

> Sửa phần thanh trên của **bản đang code** (đang có 4 dòng). Ảnh: `thanh-tren-tao-video.png`. Bản cũ để ở trên cùng của ảnh để so. Số trong ảnh là ví dụ.
> Luật chung: không nút giả, không bịa số. Credit đọc thật từ tài khoản.

- **Thanh trên: chỉ 2 dòng** (ảnh `thanh-tren-tao-video.png`).
  - **Dòng 1, đang ở đâu:**
    - ← · "Phòng <tên> ▾" (tên phòng chỉ hiện 1 lần) · ✓ Đã lưu · nút gạt **Tạo video / Dựng**.
    - Bên phải: viên **Flow · <số> credit** và viên **Gemini** (chấm xanh = ổn) · ⏳ Hàng chờ · **?** (Cách dùng).
  - **Dòng 2, đang làm tới đâu:**
    - 🎬 Từ video mẫu (🖼 Từ ảnh **[B2]**, ẩn ở MVP) · **thanh 4 chặng**: ✓ Phân tích › Duyệt khung · n chờ › Tạo clip · x/y › Sang Dựng. Chặng cần bạn tô vàng.
    - Bên phải: "Dự kiến ~x credit" · **Chi tiết ▾**. Bấm thì mở bảng nhỏ: tài khoản, credit còn lại + giờ đọc (đọc lại), dự kiến clip, ảnh khung, đã tiêu trong phòng, chi phí phân tích, link tới bảng chi phí đầy đủ và Tài khoản.
  - **Chưa kết nối / chưa có key:** viên chuyển vàng, ví dụ "Flow chưa kết nối · Kết nối", "Chưa có key AI · Thêm". Dự kiến ghi "cần kết nối Flow".
  - **Bỏ khỏi bản đang code:**
    - Dòng tên dự án lặp lại.
    - Các chữ "Flow: chưa biết", "AI phân tích: chưa biết", "Chưa kết nối · chưa xác minh", "Dự kiến: chưa đủ giá".
    - Nút "Xem lỗi mẫu".
    - 3 nút Hạn mức / Dự kiến / Danh sách chi tiết (đã gộp vào Chi tiết ▾).
    - "Ghép video" (đã đổi thành "Sang Dựng").
