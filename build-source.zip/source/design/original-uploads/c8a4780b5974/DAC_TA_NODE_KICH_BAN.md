# SceneForge · Node Kịch bản (tab Từ ảnh & ý tưởng)

Ảnh: `anh/01-node-kich-ban-5-trang-thai.png`

Bản này **thay node "Kịch bản · 5 nhịp" cũ**. Node cũ có ô chọn công thức, tab Tự viết / AI theo công thức, 5 ô "Bấm để viết lời cho nhịp này" và 7 nút. Tất cả đều bỏ.

## 0 · Nguyên tắc

- Kịch bản là **1 ô chữ thường**. Cảnh được chia theo **dòng trống**, chạy trên máy, không gọi AI.
- Không ép khuôn 5 nhịp. Công thức là tùy chọn.
- Dù lời đến từ đâu (dán, lấy từ Kho hay AI viết), kết quả cuối cùng là **cùng một ô chữ**.
- AI chỉ chạy khi người dùng bấm nút **✦ Viết**. Nút AI màu tím và ghi "gọi AI".
- Mỗi trạng thái chỉ có 1 nút chính màu lime. Không có nút giả.

## 1 · Trạng thái A · Trống

- Ô chữ lớn, placeholder "Dán hoặc gõ kịch bản… · Dòng trống = sang cảnh mới". Gõ tay trực tiếp được.
- **📋 Dán kịch bản** (nút chính, lime): đọc chữ trong clipboard rồi đổ vào ô.
  - Clipboard trống hoặc không đọc được: báo nhẹ "Chưa có chữ để dán · bấm vào ô rồi Ctrl+V". Không hiện lỗi đỏ.
- **📖 Lấy từ Kho** (nút phụ): mở trạng thái B.
- **✦ AI viết** (nút phụ, tím): mở trạng thái C.
- Góc phải tiêu đề ghi "trống".

## 2 · Trạng thái B · Lấy từ Kho

Mở **ngay trong node**, không bật cửa sổ. Tiêu đề đổi thành "📖 Kho ✕". Bấm ✕ thì quay lại trạng thái A.

- Ô **🔍 Tìm trong Kho…**: tìm theo tên và lời.
- Nút gạt **Hợp sản phẩm này / Tất cả**. Mặc định là "Hợp sản phẩm này", lấy sản phẩm từ node Ảnh đầu vào.
- Danh sách: mục ⭐ đã đạt xếp lên đầu. Mỗi dòng ghi tên và "N cảnh · đã đạt".
  - Có cả công thức (◇). Chọn công thức thì chuyển sang trạng thái C, ô "Theo công thức" điền sẵn công thức đó, vì công thức không có lời.
- Bấm 1 dòng: dòng sáng viền cyan, và dưới danh sách hiện 1 câu xem trước lời (in nghiêng).
- **Dùng kịch bản này** (nút chính): **chép** lời vào ô rồi chuyển sang trạng thái E.
  - Sửa trong node **không làm đổi** bản gốc trong Kho.
  - Node nhớ id của kịch bản nguồn để ghi "Lịch sử dùng" bên Kho.

## 3 · Trạng thái C · AI viết

Mở ngay trong node. Tiêu đề đổi thành "✦ AI viết ✕".

| Trường | Cách hoạt động |
|---|---|
| Sản phẩm | Tự lấy từ node Ảnh đầu vào, ghi "✓ từ Ảnh đầu vào". Chưa có sản phẩm thì hiện ô chọn từ danh sách Sản phẩm |
| Ý chính | 1 dòng là đủ, ví dụ "son lì cả ngày, giá rẻ, chốt giỏ hàng" |
| Độ dài | Nút gạt Ngắn / Vừa / Dài, mặc định là Vừa |
| Theo công thức | Mặc định "Không". Chọn công thức thì AI giữ đúng số nhịp và thời lượng của công thức |

- Dòng ghi chú: "Gọi Gemini · nguồn trong Cài đặt · chỉ chạy khi bấm".
- Nút **✦ Viết** (tím) là nút chính ở trạng thái này.
- Bản viết AI đầy đủ (đối tượng, văn phong, 3 bản để so, chọn giọng…) nằm ở **Kho kịch bản**, không đưa vào node.

## 4 · Trạng thái D · AI đang viết

- Tiêu đề ghi "đang viết…" màu tím.
- Chữ hiện dần vào ô, đã chia dòng trống theo cảnh. Phần chưa có chữ hiện thanh xám.
- **■ Dừng**: giữ phần đã viết, chuyển sang E.
- Không có nút lime ở trạng thái này.
- Lỗi mạng hoặc hết hạn mức: giữ phần đã có, báo 1 dòng và có nút "Thử lại".

## 5 · Trạng thái E · Xong

Trạng thái này giống nhau dù lời đến từ dán, Kho hay AI.

- Tiêu đề ghi "**N cảnh**" màu xanh.
- Ô chữ sửa trực tiếp được. Mỗi dòng trống hiện thành **vạch gạch mờ** kèm nhãn "Cảnh 2", "Cảnh 3"… ở bên phải.
- Dưới ô:
  - Bên trái: "~13s · ước lượng". Đây là ước tính từ số chữ, ghi rõ là ước lượng.
  - Bên phải: 3 lối tắt **✦ Viết lại · 📖 Kho · 📋 Dán lại**. "Dán lại" và "Kho" hỏi trước nếu ô đang có chữ: "Thay lời hiện tại?".
- Nút: **Lưu vào Kho** (phụ) · **Tạo storyboard** (chính, lime) · **⋯**
  - "Lưu vào Kho" đi theo luồng "Dán kịch bản" của Kho v4: lưu nguyên văn, không gọi AI, tự đoán chủ đề trên máy.
  - "Tạo storyboard" truyền danh sách cảnh sang node Storyboard.
- Menu **⋯**: ◇ Áp 1 công thức (tùy chọn) · 🗑 Xóa lời.

## 6 · Chia cảnh (trên máy)

- Tách theo **1 hoặc nhiều dòng trống liên tiếp**. Bỏ khoảng trắng thừa ở đầu và cuối mỗi cảnh.
- Dòng dạng `[Cảnh …]` hoặc `Cảnh 2:` ở đầu đoạn thì coi là nhãn, không đưa vào lời đọc.
- Cảnh rỗng thì bỏ.
- Chia lại mỗi khi chữ thay đổi (debounce khoảng 300 ms).

## 7 · Dữ liệu (gợi ý)

```
node_script
  text            -- nguyên văn trong ô
  scenes_json     -- [{index, text}] tách từ text, tính lại khi sửa
  source          -- 'paste' | 'kho' | 'ai' | 'typed'
  kho_item_id     -- nếu lấy từ Kho
  formula_id      -- nếu áp công thức
  ai_params_json  -- {product_id, idea, length} nếu AI viết
  updated_at
```

## 8 · Kiểm thử nhanh

| # | Làm | Mong đợi |
|---|---|---|
| N1 | Copy 3 đoạn cách nhau 1 dòng trống, bấm 📋 Dán | Ô có chữ, tiêu đề ghi "3 cảnh", có 2 vạch Cảnh 2 / Cảnh 3. Không có lệnh gọi mạng |
| N2 | Clipboard trống, bấm 📋 Dán | Báo nhẹ, không lỗi đỏ, vẫn ở trạng thái A |
| N3 | Lấy từ Kho → chọn ⭐ → Dùng kịch bản này → sửa 1 chữ | Node đổi. Bản trong Kho giữ nguyên |
| N4 | Ở Kho chọn 1 công thức ◇ | Chuyển sang AI viết, ô công thức điền sẵn. Chưa gọi AI |
| N5 | AI viết → bấm ■ Dừng giữa chừng | Giữ phần đã viết, sang trạng thái E |
| N6 | Ô đang có chữ, bấm 📋 Dán lại | Hỏi "Thay lời hiện tại?" trước khi thay |
| N7 | Gõ tay, xóa hết chữ | Quay về trạng thái A |
| N8 | Rút mạng, dán và lưu vào Kho | Vẫn chạy được, không cần mạng |

## Chưa xác minh — coder kiểm tra

| Mục | Ghi chú |
|---|---|
| Đọc clipboard | Cần kiểm trình duyệt có cho phép đọc clipboard ở `http://127.0.0.1:8000` không, và có bật hỏi quyền không. Nếu không đọc được thì giữ cách bấm vào ô rồi Ctrl+V |
| "~13s" | Ước lượng theo số chữ. Tốc độ đọc thật cần đo với giọng VieNeu |
| AI viết qua Gemini | Chưa kiểm viết chữ có tốn lượt hay không, nên không ghi "miễn phí" |
| Chữ trong ảnh (tên kịch bản, số cảnh, giá) | Đều là ví dụ minh họa |
