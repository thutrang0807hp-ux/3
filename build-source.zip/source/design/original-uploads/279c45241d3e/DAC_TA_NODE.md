# SceneForge · Thiết kế lại các node (tab Tạo video · Từ video mẫu) — bản 2

Gói này chỉ đổi **giao diện bên trong từng node**. Không đổi vị trí node, dây nối hay luồng dữ liệu.
Ảnh nằm trong thư mục `anh/`, đánh số theo thứ tự luồng chạy. Bản 2 này thay toàn bộ gói Node trước đó.

## Quy tắc chung cho mọi node

- **Node cao theo nội dung.**
  - Danh sách ngắn thì không có thanh cuộn bên trong.
  - Lưới nhiều mục (ví dụ hơn 3 hàng clip) thì cuộn trong khung lưới, node vẫn giữ chiều cao cố định.
- **Chế độ chọn dùng nút gạt (segmented), không dùng ô chọn ▾.**
- **Mỗi lúc chỉ có 1 nút chính màu xanh chanh**, đổi theo trạng thái. Nút ghi số thật, ví dụ "Duyệt 3 khung xong".
- **Không có nút giả.** Nút nào không làm gì được thì ẩn đi. Không hiện "Duyệt 0…", "0 lỗi · tạo lại".
- **Tóm tắt trạng thái ghi bằng chữ ở góc phải tiêu đề**, ví dụ "1 xong · 1 đang tạo · 1 lỗi". Loại nào bằng 0 thì không ghi.
- **Màu trạng thái:**

  | Trạng thái | Màu |
  |---|---|
  | Xong, chờ duyệt | Xanh lá `#5CD18B` |
  | Đã duyệt | Xanh chanh `#D4F53C` |
  | Đang tạo | Vàng `#F5B544` |
  | Lỗi | Đỏ `#F0645A` |
  | Chờ | Xám |

- **Bấm vào 1 mục bên trong node** (khung hoặc clip) thì mở màn chi tiết dạng 2 cột: **hình hoặc video bên trái, prompt bên phải**. Màn này **không có cài đặt**.
- **Chữ hướng dẫn tối đa 1 câu ngắn.**
- Nền node `#15181D`, viền `#2A2F38`. Nhãn mục dùng chữ hoa nhỏ màu `#3CC8E0`.

---

## 01 · Phân tích — `01-node-phan-tich.png`

**4 trạng thái:** Chưa chạy · Đang chạy · Xong · Có bước lỗi.

**Các bước chia 2 nhóm:**
- **1 · Đọc video trên máy (miễn phí):** Cắt cảnh · Chép lời + mốc giây · Đọc chữ/logo · Chuyển động máy quay · Cảnh mờ/rung.
- **2 · Hiểu & viết (cần AI).**

**Mỗi bước là 1 dòng:** icon trạng thái · tên bước · nhãn `💻 máy` hoặc `✦ Gemini` · kết quả ngắn.

**Nguồn AI:** nút gạt `Gemini API · Gemini Chat · Ollama`.

**Nút chính theo trạng thái:**
- Chưa chạy → `▶ Phân tích video`
- Đang chạy → `⏸ Tạm dừng`
- Xong → `🔍 Xem chi tiết` + `↻ Phân tích lại ▾`

**Menu ↻ gồm 4 mục:**
- Phân tích lại tất cả
- Chỉ chạy lại bước 2
- Nhập kết quả AI
- Chuẩn bị cho Gemini Chat

**Bước lỗi:** dòng đỏ, kèm hộp ghi rõ thiếu gì và nút sửa (Tải model / Nhập .srt / Bỏ qua). Các bước khác giữ nguyên kết quả.

**Khi xong:** hiện dòng `✓ Đã lưu khung sườn vào Kho kịch bản · xem ›`.

## 02 · Các cảnh — `02-node-cac-canh.png`

- **Thanh thời gian màu** ở trên cùng. Mỗi đoạn là 1 cảnh, độ dài theo thời lượng thật. Cảnh dài hơn 8 giây có viền vàng.
- **Mỗi cảnh hiện:** ảnh 9:16 kèm số giây · mô tả ngắn · nhãn (người nói / sản phẩm / có chữ…). Trong lúc phân tích thì hiện `đang đọc cảnh…`.
- **Cảnh dài hơn 8 giây:**
  - Nếu chỉ có 1 cảnh: hiện hộp vàng kèm nút `✂ Chia N đoạn` / `Tự chọn chỗ cắt`.
  - Nếu có nhiều cảnh: ghi `→ sẽ chia a · b khi tạo clip`.
- **Menu `↻ Chia lại ▾`:** Tự chia lại · Độ nhạy Ít/Vừa/Nhiều · Cắt bằng tay · Gộp 2 cảnh. Trước khi chia lại phải hỏi người dùng, vì ảnh khung và clip cũ sẽ chuyển vào Thùng rác.

## 03 · Ảnh tham chiếu — `03-node-anh-tham-chieu.png`

**Không có nút Thay / Giữ gốc.** Thả ảnh là xong:
- Ô có ảnh tự chuyển sang `sẽ thay` (viền xanh chanh). Ô trống thì `giữ gốc`.
- 4 ô: **Người** (to nhất, nằm đầu vì gần như lần nào cũng thêm) · Áo · Sản phẩm · Bối cảnh.
- Kéo thả ảnh thẳng vào ô, thả nhiều file cùng lúc được.

**Nhiều ảnh trong 1 ô:**
- Ảnh xếp thành 1 hàng, có `＋` ở cuối hàng.
- Khi quá số ảnh hiện được thì hiện ô `+N`.
- Footer có `Xem tất cả ›` để mở toàn bộ ảnh.

**Người:**
- Nhiều ảnh của cùng 1 người (các góc khác nhau) giúp giữ mặt giống nhau giữa các cảnh.
- 1 ảnh gắn `★ mặt chuẩn`.
- Nút `＋ Thêm người` tạo "Người 1", "Người 2"…, mỗi người một hàng ảnh riêng.

**Người hay dùng:**
- Hiện ảnh người đã dùng ở các video trước. Bấm 1 lần là thêm vào.
- Lưu trong thư viện chung (kho ảnh theo nội dung, xem SceneForge_LuuTru).

**Mô tả:** 1 dòng, không bắt buộc. Bấm vào ảnh để đổi, xóa, hoặc đặt ★.

**Chân node:** `Dùng cho N cảnh` + `Đổi riêng từng cảnh ›` (mở sang Ảnh khung).

## 04 · Ảnh khung — `04a-anh-khung-node.png`, `04b-anh-khung-bam-1-khung.png`

### Node (04a)
- **Bỏ:** thanh tiến độ màu, các chip đếm, tab "Lỗi 0 / Chờ duyệt", nút giả. Tóm tắt dời lên góc tiêu đề.
- **Mỗi khung có 5 trạng thái.** Mỗi trạng thái gồm nhãn ở góc, viền cùng màu, và một dòng chữ bên dưới:

  | Trạng thái | Hiển thị |
  |---|---|
  | Chờ | `Chờ · thứ N` (vị trí trong hàng chờ) |
  | Đang tạo | Vòng % trên ảnh + bước đang làm (chọn hình / ghép / kiểm) |
  | Xong | Ảnh mới, ảnh gốc nhỏ ở góc, chữ "chờ duyệt" |
  | Lỗi | Lý do ghi trên ảnh + nút `↻ Tạo lại` ngay dưới |
  | Đã duyệt | Viền xanh chanh |

- **Nút ở đáy:** `✓ Duyệt N khung xong` + `↻ Tạo lại N lỗi`. Mỗi nút chỉ hiện khi N lớn hơn 0.
- **Lỗi kết nối** (ví dụ Flow mất kết nối): nút chính là `↻ Thử lại N khung lỗi`, kèm nút `Kết nối Flow`.
- **Nhiều cảnh:** ô nhỏ lại, trạng thái chỉ còn chấm màu ở góc.
- **Chân node:**
  - Chất lượng `Lite / Pro`, mặc định Lite. Pro ghi "giá chưa rõ".
  - Công tắc `Xóa logo`, mặc định bật. Logo xóa sau khi tạo ảnh, trước khi làm nét. Nếu không xóa được thì khung báo `! Chưa xóa được logo`.

### Bấm 1 khung (04b)
- **Trái:**
  - Kéo ⇆ để so ảnh gốc với ảnh mới.
  - Nút `Bản 1 · Bản 2`, chỉ hiện khi có từ 2 bản trở lên.
  - Giữ phím Space để xem ảnh gốc.
- **Phải:**
  - Trạng thái và lý do lỗi.
  - **Prompt khung hiện sẵn, sửa trực tiếp được.** Tên ảnh tham chiếu trong prompt tô xanh chanh.
  - Khi khung lỗi, app thêm 1 câu sửa lỗi trong hộp tím, người dùng bấm "bỏ" được.
  - Ảnh tham chiếu đang dùng (chỉ xem, đổi ở node Ảnh tham chiếu).
  - 1 hàng nhãn kết quả kiểm: 1080×1920 · nét · nhãn · mặt · đã xóa logo.
- **Nút ở đáy:**
  - Khung lỗi → `↻ Tạo lại với prompt này` · `✓ Vẫn duyệt` · `⋯`
  - Khung xong → `✓ Duyệt · Enter` · `↻ Tạo lại` · `⋯`
- `‹ ›` để chuyển cảnh, `←` để về danh sách.
- **Không có** Lite/Pro, chip ghép hay công tắc logo trong màn này.

## 05 · Video Veo — `05a-video-veo-node.png`, `05b-video-veo-nhieu-clip.png`, `05c-video-veo-bam-1-clip.png`

### Node (05a)
- **Cùng kiểu với node Ảnh khung.**
- **Bỏ:** chip, tab, nút giả, và **nút "Chia clip"**. Cảnh dài hơn 8 giây tự chia thành a · b.
- **Mỗi clip:**
  - Nhãn trạng thái, viền màu, nút ▶ và thời lượng.
  - Cảnh chưa duyệt khung thì hiện `⏸ Chờ duyệt khung` và không cho tạo clip.
- **Nút ghi luôn số credit**, ví dụ `▶ Tạo 2 clip · ~20 credit`, `↻ Tạo lại · 10`.
- **Chân node:**
  - Chất lượng `Lite · 10 / Fast · 20 / Quality · 100`.
  - Công tắc `Xóa logo`.

### Nhiều clip (05b)
- Ô nhỏ 6–8 cột, trạng thái là chấm màu (✓ ◐ ! · ⏸).
- **Clip a · b của cùng 1 cảnh dính liền nhau** trên nền xám.
- Rê chuột lên ô thì hiện tên cảnh và lý do lỗi.
- **Thanh tiến độ mảnh**, chỉ hiện khi có nhiều clip: `7 / 16 có kết quả · đã dùng 70 · còn lại ước ~90 credit`.
- **Nút gạt `Tất cả / Cần xem`:** Cần xem chỉ hiện clip đã xong và clip lỗi.

### Bấm 1 clip (05c)
Màn này **chỉ có clip và prompt**. Không có công cụ hay cài đặt nào khác.
- **Trái:**
  - Video có nút phát/tạm dừng, thanh tua, chậm 0.5×, lặp.
  - Đoạn lỗi tô đỏ trên thanh thời gian.
  - Nút gạt `Bản 1 · Bản 2 · Video mẫu`.
- **Phải:**
  - Tên cảnh và thời lượng. `‹ ›` để chuyển clip, `✕` để đóng.
  - 1 dòng lý do lỗi + `Xem ›` (nhảy tới chỗ lỗi).
  - **Prompt chữ to, sửa trực tiếp được.**
    - Tên người và sản phẩm tô xanh chanh.
    - Câu app tự thêm để sửa lỗi có gạch chân tím. Bấm vào câu đó để bỏ.
  - `↺ Về prompt gốc` (đề xuất, nếu dễ làm) · `⧉ Chép`.
- **Nút ở đáy:** `Vẫn duyệt` · `Tạo lại · 10 credit`. Khi clip đã xong thì nút chính là `Duyệt`.

## 06 · Giọng đọc — `06-node-giong-doc.png`

- **Nút gạt:** `Tiếng clip · Giọng AI · Thả file · Không lời`.
  - Tiếng clip là mặc định. Chọn Tiếng clip hoặc Không lời thì node chỉ còn 2 dòng.
- **Giọng AI (VieNeu, chạy trên máy):**
  - Thẻ giọng có ▶ để nghe thử. Có thêm thẻ `＋ Giọng của bạn`.
  - Tốc độ chỉnh bằng thanh kéo.
  - Lời đọc lấy từ kịch bản. Mỗi dòng có ▶ và ✓/⏳.
  - Hiện chữ `trên máy, không gọi API`.
  - Chân node: `Tiếng gốc của clip sẽ tắt`.
- **Chưa cài VieNeu:** hiện hộp `Tải giọng AI`. Trong lúc tải vẫn làm việc khác được.
- **Thả file:** thẻ file có hình sóng âm, so độ dài file với độ dài video.

## 07 · Nhạc nền — `07-node-nhac-nen.png`

- **Nút gạt:** `Tắt · Chọn bài · Tự chọn`.
  - Tắt thì node chỉ còn 1 dòng.
  - Chưa có bài thì hiện ô kéo thả + `Chọn thư mục nhạc · Thêm bài`.
- **Chọn bài:**
  - Thẻ bài đang dùng có nút phát và hình sóng âm.
  - Thư viện dạng danh sách, mỗi bài có ▶ để nghe thử.
- **Tự chọn:** chọn nguồn, hiện bài đã chọn lần này, có nút `🔀 Đổi bài khác`.
- **Âm lượng** chỉnh bằng thanh kéo.
- **"Nhỏ lại khi có giọng nói":** đề xuất, coder xác nhận làm được không.
- **Chân node:** `✂ Chỉnh đoạn ở Dựng ›`.

## 08 · Phụ đề — `08-node-phu-de.png`

- **Công tắc** `Thêm phụ đề khi ghép`. Tắt thì node chỉ còn 1 dòng.
- **Xem trước trên khung 9:16** bằng hình cảnh thật.
- **Kiểu chữ:** 4 ô mẫu (Trắng viền đen · Vàng nền đen · Hộp mờ · TikTok to).
- **Cỡ chữ:** thanh kéo.
- **Vị trí:**
  - Nút `⬆ Trên · ↕ Giữa · ⬇ Dưới`.
  - Thanh kéo để nhích lên/xuống.
  - Bấm trực tiếp lên khung xem trước cũng đổi được.
- **Nội dung:** hiện 2 dòng đầu kèm mốc giây. Dòng đã sửa tay tô vàng.
- **Menu ⋯:**
  - Lấy lại từ kịch bản. Phải hỏi trước khi ghi đè lên dòng đã sửa.
  - Tạo từ giọng đọc *(đề xuất)*.
  - Xuất .srt *(đề xuất)*.

## 09 · Sang Dựng — `09-node-sang-dung.png`

- **Dải clip nhỏ** theo thứ tự cảnh: ✓ là đã có, ⏳ là đang chờ.
- **2 thẻ chọn cách ghép:** `⚡ Ghép sẵn` · `✋ Tự ghép`.
- **Đem theo:** 3 công tắc **Giọng đọc · Nhạc nền · Phụ đề**, mỗi công tắc ghi rõ đang dùng gì.
- **Nút chính:**
  - Còn thiếu clip → `Mở Dựng · ghép 1/3 ›` kèm cảnh báo.
  - Đủ clip → `Mở trong Dựng ›`.
- **Có bản clip mới sau khi đã chỉnh timeline:** hỏi `Thay vào timeline / Để sau`. **Không tự thay.**

---

## Chưa xác minh — coder kiểm tra

| Mục | Ghi chú |
|---|---|
| Credit Veo 10 / 20 / 100 | Lấy từ lần tìm hiểu trước. Các số ước tính trong ảnh (~20, 70, ~90) chỉ là ví dụ |
| Giá Pro (ảnh khung) | Chưa rõ. Nano Banana 2 Lite không tính phí theo trang trợ giúp của Google |
| Ảnh khung tạo bằng Gemini Chat hay Flow | App hiện dùng Gemini Chat. Chưa rõ Gemini Chat có chọn Lite/Pro như Flow không |
| "Nhỏ lại khi có giọng nói", "Tạo từ giọng đọc", "Xuất .srt", "Về prompt gốc" | Đề xuất |
| Tên giọng VieNeu | Chỉ là chữ giữ chỗ |
| Tự nhận lỗi "mặt đổi ở 0:05" | Cần kiểm tra máy có phát hiện được không. Nếu không thì chỉ hiện lỗi chung |
| Số liệu trong ảnh | Đều là ví dụ minh họa |
