# SceneForge · Thiết kế lại các node (tab Tạo video · Từ video mẫu)

Gói này chỉ đổi **giao diện bên trong từng node**. Không đổi vị trí node, dây nối hay luồng dữ liệu.
Các ảnh nằm trong thư mục `anh/`. Thứ tự ảnh đi theo luồng xử lý.

## Quy tắc chung cho mọi node

- **Node cao theo nội dung, không có thanh cuộn bên trong.** Nội dung dài (danh sách cảnh, thư viện nhạc) thì chỉ hiện vài dòng đầu kèm "+ N nữa".
- **Chế độ chọn bằng nút gạt (segmented), không dùng ô chọn ▾.** Mỗi lúc chỉ có **1 nút chính** màu xanh chanh, và nút này đổi theo trạng thái của node.
- **Node tắt hoặc chưa dùng thì co lại còn 1–2 dòng.**
- **Góc phải tiêu đề luôn có 1 chữ trạng thái ngắn có màu.** Xanh lá = xong/bật, vàng = đang chạy hoặc cần chú ý, đỏ = lỗi, xám = chưa chạy/tắt.
- **Không có nút giả.** Nút không làm gì được thì ẩn đi, không để xám. Không hiện số 0 vô nghĩa như "Duyệt 0 khung".
- **Chữ hướng dẫn tối đa 1 câu ngắn.** Bỏ các đoạn chú thích 3 dòng ở đáy node.
- **Nhãn mục** dùng chữ hoa nhỏ màu xanh ngọc `#3CC8E0`.
- **Màu dùng theo design tokens hiện có:**
  - Nền node: `#15181D`
  - Viền: `#2A2F38`
  - Xanh chanh: `#D4F53C`
  - Vàng: `#F5B544`
  - Đỏ: `#F0645A`
  - Xanh lá: `#5CD18B`
  - Tím: `#A98BF5`

---

## 01 · Phân tích — `01-node-phan-tich.png`

Node có 4 trạng thái: **Chưa chạy · Đang chạy · Xong · Có bước lỗi**.

**Các bước chia thành 2 nhóm:**
- **1 · Đọc video trên máy** (miễn phí), gồm 5 bước: Cắt cảnh · Chép lời + mốc giây · Đọc chữ/logo · Chuyển động máy quay · Cảnh mờ/rung.
- **2 · Hiểu & viết** (cần AI): Hiểu cảnh · viết prompt · dịch.

**Mỗi bước hiện thành 1 dòng:** icon trạng thái (○ ◐ ✓ !) · tên bước · nhãn `💻 máy` hoặc `✦ Gemini` · kết quả ngắn (ví dụ "3 cảnh", "6 câu", "đẩy vào", "không có").

**Bỏ:**
- Các chữ "Chưa đo", "Cần model / SRT", "Chờ phân tích".
- 6 nút rời ở đáy node.

**Chọn nguồn AI cho bước 2:** nút gạt `Gemini API · Gemini Chat · Ollama`. Nút này chỉ hiện khi node chưa chạy.

**Nút chính theo trạng thái:**
- Chưa chạy → `▶ Phân tích video`
- Đang chạy → `⏸ Tạm dừng`
- Xong → `🔍 Xem chi tiết` + `↻ Phân tích lại ▾`

**Menu `↻ Phân tích lại ▾` có 4 mục:**
- Phân tích lại tất cả
- Chỉ chạy lại bước 2 (giữ kết quả trên máy)
- Nhập kết quả AI
- Chuẩn bị cho Gemini Chat

**Khi có bước lỗi:** dòng của bước đó tô đỏ. Ngay dưới hiện một hộp ghi thiếu gì và cách sửa, ví dụ `⬇ Tải model · ⬆ Nhập .srt · Bỏ qua`. Các bước khác vẫn giữ kết quả.

**Khi xong:** hiện dòng `✓ Đã lưu khung sườn vào Kho kịch bản · xem ›`.

## 02 · Các cảnh — `02-node-cac-canh.png`

**Trên cùng là thanh thời gian màu.** Mỗi đoạn trên thanh là 1 cảnh, dài ngắn đúng theo thời lượng thật. Cảnh dài hơn 8 giây thì đoạn đó có viền vàng.

**Mỗi cảnh hiện thành 1 dòng:**
- Ảnh dọc 9:16 kèm số giây ở góc ảnh.
- Tên cảnh và mốc thời gian.
- Mô tả ngắn.
- Nhãn: người nói / sản phẩm / có chữ / cận cảnh / chuyển động.

Bỏ các chữ "chưa có mô tả hình ả…" và "Chưa xác định chủ thể". Khi đang phân tích thì hiện `đang đọc cảnh…`.

**Cảnh dài hơn 8 giây** (Veo chỉ làm được clip tối đa 8 giây):
- Nếu chỉ có 1 cảnh: hiện hộp vàng `⚠ Dài hơn 8s · Veo cần ≤ 8s/clip`, kèm 2 nút `✂ Chia N đoạn` và `Tự chọn chỗ cắt`.
- Nếu có nhiều cảnh: dòng của cảnh dài ghi `12s → sẽ chia a · b khi tạo clip`.

**Menu `↻ Chia lại ▾` có 4 mục:**
- Tự chia lại
- Độ nhạy: Ít / Vừa / Nhiều cảnh
- Tự cắt bằng tay
- Gộp 2 cảnh liền nhau

Cuối menu có cảnh báo: chia lại thì ảnh khung và clip của cảnh cũ sẽ vào Thùng rác. App hỏi lại trước khi làm.

**Cảnh đang được chọn** có viền xanh chanh.

## 03 · Ảnh tham chiếu — `03-node-anh-tham-chieu.png`

**4 nhóm xếp dọc:** Người · Trang phục · Sản phẩm · Bối cảnh.
- Mỗi nhóm có nút gạt **Thay / Giữ gốc**, đồng bộ với các chip "Thay bằng" ở Ảnh khung.
- Nhóm đang **Giữ gốc** thì co lại còn 1 dòng.
- Nhóm đang **Thay** thì hiện:
  - Các ảnh nhỏ và một ô `＋`.
  - Một dòng mô tả `"…" · sửa`. Chưa có mô tả thì hiện chữ mờ `✎ thêm mô tả (không bắt buộc)`.

**Bỏ:** lưới 2×2 ô trống và 4 ô chữ to có góc kéo.

**Ảnh người có nhãn `★ mặt chuẩn`.** Ảnh này dùng để giữ cùng một khuôn mặt ở mọi cảnh.

**Ảnh sản phẩm ghi nguồn,** ví dụ `từ Bộ ảnh Son`.

**Bấm `＋` mở menu nguồn ảnh:**
- Tải từ máy (hoặc kéo thả)
- Từ Bộ ảnh sản phẩm
- Từ ảnh đã ghim ở Tạo ảnh hàng loạt
- Dán (Ctrl+V)

**Chân node:** `Dùng cho N cảnh` + `Đổi riêng từng cảnh ở Ảnh khung ›`.

## 04 · Ảnh khung — `04-anh-khung-toi-uu.png` + `05-ngan-phai-anh-khung.png`

**Node trên canvas:**
- Chỉ có 1 hàng lọc có số: `Tất cả · Đạt · Cần xem`. Mục nào bằng 0 thì ẩn. Khi chưa tạo khung thì ẩn cả hàng lọc.
- **Bỏ:**
  - Hàng chip "0 đạt · 0 cần xem · 0 lỗi · 0 đang tạo".
  - Tab "Lỗi 0 / Chờ duyệt".
  - Nút "Duyệt hết 0 khung đạt" và "0 lỗi · tạo lại".
- Khung chưa tạo thì hiện ảnh cắt từ cảnh, làm mờ, có nhãn `hình cắt`.
- Khung đã tạo thì hiện ảnh mới. Góc dưới có ảnh gốc nhỏ để so.
- Khung lỗi thì viền đỏ, lý do ghi ngay trên ảnh.
- **Nút theo trạng thái:**
  - Chưa tạo → `▶ Tạo N khung · miễn phí`
  - Đã có khung → `✓ Duyệt N khung đạt` + `↻ Tạo lại N`

**Bấm vào node** thì mở ngăn bên phải (cùng kiểu với ngăn "Cảnh" hiện có), có 3 tab:
- **Khung:** thanh tiến độ, bộ lọc, danh sách từng cảnh dạng gốc → mới kèm trạng thái. Rê chuột vào một dòng thì hiện `✓` và `↻`. Đáy ngăn có `Duyệt khung đạt` + `Tạo lại khung lỗi`.
- **Bấm 1 dòng** thì xem chi tiết ngay trong ngăn:
  - Nút `←` quay lại, `‹ ›` để đổi cảnh.
  - Thanh kéo ⇆ để so ảnh gốc với ảnh mới.
  - Chọn bản 1 / 2.
  - Kết quả máy tự kiểm.
  - Chip ghép riêng cho cảnh này.
  - Đáy: `✓ Duyệt · Enter` · `↻ Tạo lại` · `⋯`.
- **Thiết lập** (áp dụng cho cả node):
  - Ảnh tham chiếu dùng chung.
  - Cách chọn hình gốc (tự chọn hình rõ mặt nhất).
  - Lite / làm nét 2K.
  - Chữ nhãn tự đọc.
  - Prompt chung (gập lại được).
  - Có thay đổi thì đáy mới hiện `Lưu & tạo lại N`.
- **Các bản cũ:** danh sách các bản đã tạo trước đó.

**Màn sửa lớn ("xem như video")** thay cho 3 hộp thoại cũ: Sửa khung, Kiểm ảnh khung, AI trực tiếp.
- Máy tự kiểm sau khi tạo khung. Kết quả hiện ở cột phải.
- Nguồn ảnh chuyển vào Cài đặt. Màn này chỉ hiện 1 dòng `Nguồn ảnh: theo Cài đặt · đổi`.
- Pro chỉ có trong menu `⋯ → Tạo lại bằng Pro`, kèm ghi chú **giá chưa rõ**.

## 05 · Video Veo — `06-video-veo-node-ngan.png`

**Node trên canvas** làm giống Ảnh khung:
- 1 hàng lọc có số.
- **Nút chính ghi luôn số credit**, ví dụ `▶ Tạo 2 clip · ~20 credit` hoặc `↻ Tạo lại 1 · 10`.
- Ảnh clip có ▶ và thời lượng, để không lẫn với ảnh khung.
- Cảnh chưa duyệt khung thì hiện `⏸ chờ duyệt khung` và không cho tạo clip.
- **Bỏ nút "Chia clip".** Cảnh dài hơn 8 giây tự chia thành a · b.

**Ngăn bên phải** có 3 tab:
- **Clip:** khung → clip, trạng thái, % đang tạo, credit đã dùng.
- **Bấm 1 dòng** thì xem clip ngay trong ngăn:
  - Chỗ lỗi được đánh dấu đỏ trên thanh thời gian, có nút "nhảy tới".
  - Nút `⧉ Chạy cạnh video mẫu` để so 2 video cùng lúc.
  - Kết quả máy tự kiểm.
  - Nút Tạo lại ghi số credit.
- **Thiết lập:**
  - Chất lượng: Lite / Fast / Quality (10 / 20 / 100 credit)
  - Tự chia cảnh dài
  - Độ dài tối đa: 4 · 6 · 8 giây
  - Khung đầu + khung cuối
  - Âm thanh: tắt tiếng và lồng giọng ở Dựng, hoặc để Veo tự nói
  - Đáy ngăn ghi ước tính credit kèm chữ **"chưa xác minh"**

Logo Veo vẫn tự xóa phía sau. Chỉ hiện thông báo khi bước xóa logo bị lỗi.

## 06 · Giọng đọc — `07-node-giong-doc.png`

**Nút gạt 4 nguồn:** `Tiếng clip · Giọng AI · Thả file · Không lời`. Thay cho ô chọn "Giọng riêng · VieNeu / file nhập ▾".

**Tiếng clip** (mặc định) và **Không lời:** node chỉ còn 2 dòng.

**Giọng AI (VieNeu, chạy trên máy):**
- Thẻ giọng có nút ▶ nghe thử. Có thêm ô `＋ Giọng của bạn` (từ 1 file mẫu).
- Tốc độ chỉnh bằng thanh kéo.
- Lời đọc lấy từ kịch bản. Mỗi dòng có ▶ và dấu ✓/⏳.
- Thanh tiến độ ghi `trên máy, không gọi API`.
- Chân node báo `Tiếng gốc của clip sẽ tắt`.

**Giọng AI khi chưa cài:** hiện một hộp hướng dẫn kèm nút `Tải giọng AI`. Trong lúc tải vẫn làm việc khác được.

**Thả file:**
- Thẻ file có hình sóng âm và nút xóa ✕.
- So độ dài file với video, ví dụ "vừa khít" hoặc "dài hơn 3s".

Tên các giọng trong ảnh chỉ là chữ giữ chỗ. Coder điền theo các giọng VieNeu thật đang có.

## 07 · Nhạc nền — `08-node-nhac-nen.png`

**Nút gạt:** `Tắt · Chọn bài · Tự chọn`. Thay cho ô "Chế độ ▾".

**Tắt:** node chỉ còn 1 dòng `Video không có nhạc nền · ＋ Thêm nhạc`.

**Chưa có bài:** hiện ô kéo thả file (mp3 · m4a · wav), kèm 2 nút `Chọn thư mục nhạc · Thêm bài`.

**Chọn bài:**
- Thẻ bài đang dùng có nút phát và hình sóng nhạc.
- Thư viện dự án là danh sách. Mỗi bài có ▶ nghe thử, bấm vào là chọn.
- Bỏ ô chọn "Chọn bài ▾" và nút riêng "Nghe thử bài đang chọn".

**Tự chọn:**
- Chọn nguồn: thư viện dự án hoặc 1 thư mục.
- Hiện bài lần này app chọn được, kèm nút `🔀 Đổi bài khác`.

**Âm lượng chỉnh bằng thanh kéo,** không còn ô gõ số.

**Công tắc "Nhỏ lại khi có giọng nói"** là **đề xuất**. Coder xác nhận làm được không.

**Chân node:** `✂ Chỉnh đoạn ở Dựng ›` + `tự vừa N s video`.

## 08 · Phụ đề — `09-node-phu-de.png`

**Công tắc "Thêm phụ đề khi ghép".** Tắt thì node chỉ còn dòng này.

**Xem trước trên khung 9:16** bằng hình cảnh thật. Bấm thẳng lên khung (vùng Trên / Giữa / Dưới) để đổi vị trí.

**Kiểu chữ:** 4 ô mẫu nhìn thấy được ngay: Trắng viền đen · Vàng nền đen · Hộp mờ · TikTok to.

**Cỡ chữ:** thanh kéo.

**Vị trí:**
- Nút gạt `⬆ Trên · ↕ Giữa · ⬇ Dưới`.
- Thanh kéo nhích lên/xuống để chỉnh cho chuẩn, ví dụ tránh che sản phẩm.

**Nội dung:**
- Hiện 2 dòng đầu kèm mốc giây.
- Dòng bạn đã sửa tay thì tô vàng, ghi "đã sửa".
- Chân node có `✎ Sửa chữ & mốc giây ở Dựng ›`.

**Menu `⋯`:**
- Lấy lại từ kịch bản. Hỏi lại trước, vì sẽ ghi đè các dòng đã sửa.
- Tạo từ giọng đọc *(đề xuất)*.
- Xuất .srt *(đề xuất)*.

## 09 · Sang Dựng — `10-node-sang-dung.png`

**Dải clip nhỏ** theo thứ tự cảnh: ✓ là có clip, ⏳ là đang chờ. Thay cho dòng "0/1 cảnh có clip".

**Hai thẻ cách ghép đặt cạnh nhau:** `⚡ Ghép sẵn` · `✋ Tự ghép`.

**Đem theo sang Dựng** gồm 3 công tắc. Mỗi công tắc ghi luôn đang dùng gì, lấy từ các node kia:
- Giọng đọc
- Nhạc nền
- **Phụ đề** (bản cũ chưa có công tắc này)

**Nút chính:**
- Còn thiếu clip → `Mở Dựng · ghép 1/3 ›` (nút viền), kèm cảnh báo vàng là chỗ thiếu sẽ để trống.
- Đủ clip → `Mở trong Dựng ›` (xanh chanh).

**Có clip mới sau khi đã chỉnh timeline:** hiện hộp `🆕 Cảnh N có bản mới`, hỏi `Thay vào timeline / Để sau`. App **không tự thay**.

---

## Chưa xác minh, coder cần kiểm tra

| Mục | Ghi chú |
|---|---|
| Credit Veo 10 / 20 / 100 | Số liệu lấy từ tìm hiểu trước đây. Các con số trong ảnh (~20, 40 credit) chỉ là ví dụ |
| "Nhỏ lại khi có giọng nói" (Nhạc nền) | Đề xuất. Cần FFmpeg sidechain hoặc cách tương đương |
| "Tạo từ giọng đọc", "Xuất .srt" (Phụ đề) | Đề xuất |
| Tên giọng VieNeu, "Giọng của bạn từ file mẫu" | Chữ giữ chỗ. Điền theo khả năng thật của VieNeu |
| Ollama trong nút gạt nguồn AI | Chỉ hiện khi máy có Ollama |
| Số liệu trong ảnh (giờ, số câu, 12:30…) | Chỉ là ví dụ minh họa |
