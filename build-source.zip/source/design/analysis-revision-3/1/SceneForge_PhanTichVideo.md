# SceneForge · Quy trình phân tích video → ảnh khung → clip (chốt 22/10/2026)

> Gom toàn bộ phần trao đổi về **phân tích video**. Đi cùng gói 5, mục 8 và 9 (ghi cùng nội dung).
> **Nguyên tắc:** việc **đo được** thì làm trên máy, dùng repo nhẹ chạy CPU, không cần PyTorch hay card đồ họa. AI chỉ làm phần **hiểu và viết**. **Chỉ clip Veo tốn credit.**
> Giao diện giữ như ảnh `02-tab-tao-video-ban-gop.png` (gói 5), chỉ thêm vài dòng nhỏ ghi trong tài liệu này.

---

## 1. Quy trình 14 bước
| # | Việc | Dùng | Chạy ở đâu | Tốn |
|---|---|---|---|---|
| 1 | Thả video mẫu, lưu vào thư mục phòng | App | Máy | 0đ |
| 2 | Cắt cảnh, chia cảnh ≤ 8s | **PySceneDetect** (BSD-3) | Máy | 0đ |
| 3 | Khung gốc đầu · giữa · cuối, ảnh nhỏ | **FFmpeg** | Máy | 0đ |
| 4 | Chép lời có mốc giây tới từng chữ | **faster-whisper** (MIT, kiểm lại) + bộ lọc giọng **Silero** có sẵn trong nó (mục 2.2) | Máy | 0đ |
| 5 | Đọc chữ / logo dạng chữ trên hình | **RapidOCR** (Apache 2.0) | Máy | 0đ |
| 6 | Đo chuyển động máy quay; báo cảnh mờ / rung / tối; nhãn "Có người" | **OpenCV** (Apache 2.0), cách đo ở mục 2.1 | Máy | 0đ |
| 7 | Hiểu cảnh, viết prompt khung và prompt video, dịch lời | **Gemini** (mặc định) / OpenAI (dự phòng), AI chỉ trả mã số (mục 2.3) | Mạng | 0đ với key Gemini miễn phí |
| 8 | Tạo ảnh khung | **Flow · Nano Banana 2 Lite** qua flow2api | Mạng | Miễn phí (Google ghi "không mất phí") |
| 9 | Nâng khung lên 2K, kiểm nhãn và độ nét | Flow + RapidOCR + OpenCV | Mạng + máy | 2K: 0 credit (theo useapi.net, phải thử) |
| 10 | **Người duyệt khung** | App | Máy | 0đ |
| 11 | Tạo clip | **Flow · Veo 3.1 Lite** qua flow2api | Mạng | **~10 credit / clip** |
| 12 | Bỏ logo Veo | **gwmr** (MIT) | Máy | 0đ |
| 13 | Giọng đọc | **VieNeu-TTS v3** | Máy | 0đ |
| 14 | Dựng, phụ đề, nhạc, xuất | **FFmpeg** | Máy | 0đ |

## 2. Phân tích (bước 2–7)
- Máy cắt cảnh và ghi mốc giây. **Không để AI đoán mốc giây.**
- Chép lời trên máy. AI chỉ dịch và viết lại.
- Đọc chữ trên máy, nên bước "Rà logo / chữ" có số liệu thật.
- **Chuyển động máy quay** (lia, zoom, đứng yên) đo trên máy theo mục 2.1, rồi **tự điền vào prompt Veo**. Ô Phân tích thêm 1 dòng bước "Chuyển động máy quay".
- Cảnh mờ / rung / tối: **chỉ tô vàng cảnh báo**, không tự bỏ.
- **Tự so:** kết quả AI với số đo trên máy (số cảnh, lời lệch mốc giây, chữ). Chỗ lệch thì tô vàng cho người xem, **không tự chạy tiếp**.
- Gửi AI **khung ảnh + lời + chữ đã đo**, không gửi nguyên video. Như vậy ít token hơn và đổi được sang OpenAI.

### 2.1 Đo chuyển động máy quay, không lẫn người đi lại (chốt 22/10)
- Lý do: đo cả khung hình thì người đi ngang trước máy đứng yên cũng bị tính là "lia". Phải tách chuyển động **của máy** ra khỏi chuyển động **của người**.
- Cách làm (chỉ OpenCV, chạy CPU, 0đ):
  1. Mỗi cảnh lấy khoảng 6 khung / giây, thu nhỏ còn 480px, đổi sang ảnh xám.
  2. Tìm vài trăm điểm góc trên khung (`goodFeaturesToTrack`), theo dõi chúng sang khung sau (`calcOpticalFlowPyrLK`).
  3. Tìm một phép dịch + phóng + xoay chung cho **số đông** điểm (`estimateAffinePartial2D` kiểu RANSAC). Điểm đi lệch số đông là người, tay, vật đang cử động, nên bỏ.
  4. Cộng dồn qua cả cảnh ra: lia ngang, lia dọc, zoom, xoay, và độ rung.
- Nhãn ghi ra (đúng chữ này để điền vào prompt Veo): *zoom vào / zoom ra · lia trái / lia phải (nhanh) · máy đi lên / đi xuống · cầm tay, hơi rung · máy đứng yên*. Ghép được nhiều nhãn, ví dụ "zoom vào + cầm tay".
- Cảnh có ít điểm để theo (tường trơn, hình đồ họa, chữ chạy kín khung) thì ghi **"không đo chắc"**, tô vàng và **không** tự điền vào prompt.
- Ngưỡng để ra từng nhãn: **chưa có số**, đặt bằng bài thử D9.
- Ô Phân tích: dòng bước "Chuyển động máy quay". Mỗi cảnh hiện nhãn, sửa được bằng ✎.

### 2.2 Lọc lời Whisper tự bịa (chốt 22/10)
- Lý do: video TikTok hay có nhạc nền. Lúc chỉ có nhạc, Whisper hay bịa câu ("hãy đăng ký kênh", "cảm ơn các bạn đã xem"), lặp một chữ nhiều lần, hoặc ra một dãy số.
- Lớp 1: bật bộ lọc giọng có sẵn của faster-whisper (`vad_filter=True`, dùng Silero). Đoạn không có tiếng người thì không chép. Không cài thêm gì.
- Lớp 2: mỗi câu chấm 1 trong 3 nhãn **Thật / Mảnh vụn / Nghi bịa**. Nghi bịa khi có 1 trong các dấu hiệu:
  - một chữ lặp từ 3 lần liền trở lên;
  - câu chỉ toàn số;
  - giống danh sách câu bịa hay gặp (tiếng Việt, tiếng Anh, tiếng Trung; danh sách để trong 1 file, thêm câu được);
  - Whisper tự báo không chắc (`no_speech_prob` cao, `avg_logprob` thấp; ngưỡng đặt bằng bài thử D10).
- Câu Nghi bịa: **tô vàng, không tự xóa**. Không đưa vào bản dịch, phụ đề, prompt, trừ khi người dùng bấm "Giữ câu này".
- Mảnh vụn (1–2 chữ lẻ): giữ, ghi mờ.

### 2.3 AI chỉ trả mã số, app tự ráp lời và mốc giây (chốt 22/10)
- Lý do: thực hiện luật "Không để AI đoán mốc giây". AI không chép lại lời gốc nên cũng không chép sai được.
- Trước khi gửi, app đặt mã: cảnh `C01, C02…`, câu lời `L001, L002…`. Gửi AI một bảng ngắn, mỗi câu 1 dòng, ví dụ: `L003 · C02 · 4,2–6,8s · <lời gốc>`. Ảnh khung gửi kèm, ghi mã cảnh.
- AI trả JSON **chỉ dùng mã**, ví dụ: `{"canh": "C02", "loi": ["L003", "L004"], "mo_ta": "...", "prompt_khung": "...", "prompt_video": "..."}`. Bản dịch trả dạng `{"L003": "<bản dịch>"}`.
- AI **không được** trả mốc giây hay chép lại lời gốc. App lấy lời và mốc giây từ số đo trên máy.
- AI trả mã không có (ví dụ `L099` trong khi chỉ có 40 câu), hoặc bỏ sót câu: tô vàng "AI trả mã lạ / bỏ sót câu", **không tự chạy tiếp** (theo luật Tự so).

## 3. Các cảnh
- Mốc giây, ảnh nhỏ, khung gốc: PySceneDetect + FFmpeg.
- "Có người / Không có người": bộ dò mặt có sẵn trong OpenCV.
- Câu mô tả ngắn: AI viết luôn trong bước Phân tích, không gọi thêm lần nào.

## 4. Ảnh khung
### 4.1 Prompt khung: app tự viết, người dùng chỉ nối và chạy
- Theo trang trợ giúp Flow, mọi cách tạo / sửa ảnh đều cần **câu mô tả**. Ảnh người và ảnh sản phẩm là ảnh tham chiếu gửi kèm.
- Prompt khung tự ghép từ 2 phần:
  - **Câu mẫu cố định:** "Giữ bố cục, tư thế, kích thước và bảng màu của khung gốc. Chỉ thay những thành phần có ảnh tham chiếu được nối…".
  - **Chi tiết cảnh** do bước Phân tích viết.
- Sửa được bằng nút ✎.

### 4.2 Mô hình
- **Mặc định Nano Banana 2 Lite**: Google ghi là mô hình mặc định không mất phí, nhanh hơn Pro khoảng 2 lần (theo useapi.net).
- **Cảnh cận sản phẩm / nhãn quan trọng:** app gợi ý chuyển sang **Pro**. Giá Pro trên trang Google chưa ghi, phải thử.
- Ô Ảnh khung có chọn mô hình cho từng cảnh: *Lite (mặc định) / Pro*.
- Khung không tốn tiền nên mỗi cảnh **tạo sẵn 2 bản** để chọn.

### 4.3 Chất lượng: khung chỉ được sang Veo khi đủ 3 điều kiện
1. **Nhãn đọc được:** RapidOCR đọc nhãn trên khung và so với tên sản phẩm. Không khớp thì tô vàng "nhãn có thể bị méo".
2. **Đủ nét:** OpenCV đo độ nét. Mờ thì tô vàng "khung hơi mờ", kèm 2 nút *Nâng 2K* / *Tạo lại bằng Pro*. Khung mờ không cho duyệt nhanh.
3. **Đã lên 2K:** luôn nâng 2K trước khi gửi Veo. Flow trả 2K dạng JPEG (theo useapi.net), **giữ nguyên file, không nén thêm**.
- Veo lấy ảnh khung làm **đúng khung hình đầu** của clip, nên khung xấu thì clip xấu.

### 4.4 Làm trên máy để đỡ chờ
- **Cảnh không có người, không có sản phẩm:** tự dùng khung gốc, không gửi tạo lại. Ghi "Dùng khung gốc · tự động".
- **Che logo / chữ đối thủ trên khung gốc:** RapidOCR + OpenCV inpaint. Ghi "Đã che logo · trên máy".
- ⏳ **Dán ảnh sản phẩm đã tách nền** (rembg, kiểm lại giấy phép) cho cảnh chỉ có sản phẩm. Phải thử thật, dán giả thì bỏ.
- ❌ Ghép người / sản phẩm bằng Flux / Qwen-Image-Edit trên máy: cần card 12–24GB, không làm.

## 5. Nguồn AI và key: "dán key là chạy"
| Nguồn (Cài đặt → Phân tích) | Ghi chú |
|---|---|
| **Key Gemini miễn phí** (mặc định) | 0đ, có giới hạn số lần / phút. Google được dùng dữ liệu gửi lên để cải thiện sản phẩm |
| Key Gemini trả phí | Dùng Flash-Lite cho dịch / việc đơn giản, Flash cho viết prompt. App đo tiền thật |
| 🆕 **Key OpenAI** (dự phòng) | Không có gói miễn phí, tốn tiền thật. Chạy được vì chỉ gửi ảnh + chữ |

- **Bỏ ô chọn mô hình.** Ô key chỉ có dán + **Kiểm tra**. App gọi danh sách mô hình (models.list) bằng key đó rồi **tự chọn** Flash / Flash-Lite mới nhất còn dùng được. Kết quả: "✓ Key dùng được · đang dùng <tên mô hình>".
- **429 / hết lượt:** tự chờ rồi gọi lại, tăng dần thời gian chờ. Không báo lỗi trừ khi chờ quá lâu.
- **404 / model not found:** tự chọn lại mô hình.
- **Gemini lỗi mà không phải do hết lượt:** app **hỏi** có chuyển sang OpenAI không. **Không tự chuyển** vì tốn tiền.
- **Báo lỗi ghi rõ dịch vụ nào lỗi** (Gemini / OpenAI / Flow / Telegram…) + mã lỗi + lời giải thích tiếng Việt + nút **Sao chép chi tiết lỗi** (tự xóa key). Không gộp thành "API từ chối yêu cầu".
- Key mã hóa (keyring + cryptography). Không lưu dạng chữ thường.

## 6. Bảng giá tham khảo (app phải đọc / đo thật, không ghi cứng)
**Flow** (gói Pro):

| Việc | Credit |
|---|---|
| Ảnh Nano Banana 2 Lite | 0 (trang Google) |
| Nano Banana 2.1 / Pro | chưa rõ |
| Nâng ảnh 2K | 0 (useapi.net) |
| Nâng ảnh 4K | 50, chỉ Ultra (saascrmreview) |
| Veo 3.1 Lite / Fast / Quality | 10 / 20 / 100 mỗi clip (felloai, saascrmreview) |
| Nâng video 1080p | 0 |

**Gemini API** (trang chính thức, 21/10/2026, giá cho 1 triệu token):

| Mô hình | Gửi lên | Nhận về |
|---|---|---|
| 3.1 Flash-Lite | $0,25 | $1,50 |
| 3.8 Flash | $0,75 | $3,75 |

3.8 Flash tăng gấp đôi từ 01/01/2027.

## 7. Không dùng / để sau
- ❌ YOLO của Ultralytics (AGPL).
- ⏳ TransNetV2, WhisperX, CLIP (tự kiểm sau Veo), SAM, Qwen-VL qua Ollama, Flux trên máy, Wan 2.2. Đều cần PyTorch hoặc card đồ họa.
- ⚠ flow2api / muse2api là nối tài khoản web, có rủi ro bị khóa. Đã giảm bằng: không tự xoay vòng, hàng chờ chậm, dự phòng "Nhập clip làm sẵn trên Flow".

## 8. Thử thật trước (đã thêm vào `SceneForge_BangThuThat.xlsx`)
- 🔴 **D8** Key Gemini miễn phí phân tích được 1 video mẫu. Thử tay trên Google AI Studio trước, 0đ.
- 🔴 **D6** PySceneDetect cắt khớp video TikTok cắt nhanh.
- 🟠 **D5** faster-whisper chép tiếng Trung.
- 🟠 **A4** Khung bằng Lite có giữ nhãn rõ không. Chọn Pro có trừ credit không.
- 🟠 **A10** Nâng ảnh 2K có trừ credit không, mất bao lâu.
- 🟡 **D7** Che logo trên khung gốc có sạch không.
- 🔴 **D9** Nhãn chuyển động máy quay đúng không, nhất là cảnh người đi qua trước máy đứng yên (mục 2.1).
- 🟠 **D10** Lọc lời bịa: bắt được câu bịa ở video chỉ có nhạc, không tô nhầm câu thật (mục 2.2).
- 🟠 **D11** Gemini miễn phí có trả đúng mã cảnh / mã câu, không chép lời, không bịa mốc giây (mục 2.3).

## Nguồn
- Google Flow · models: https://support.google.com/flow/answer/16352836?hl=en
- Google Flow · tạo / sửa ảnh: https://support.google.com/flow/answer/16729550?hl=en
- Gemini API pricing: https://ai.google.dev/gemini-api/docs/pricing
- useapi.net · so sánh Nano Banana: https://useapi.net/docs/articles/google-flow-nano-banana-compare
- useapi.net · upscale 2K/4K: https://useapi.net/docs/api-google-flow-v1/post-google-flow-images-upscale
- felloai · credit Flow: https://felloai.com/google-flow/
- saascrmreview · giá Flow: https://saascrmreview.com/google-flow-pricing/
- PySceneDetect: https://www.scenedetect.com · RapidVideOCR: https://github.com/SWHL/RapidVideOCR
