# SceneForge · Đặc tả tổng hợp (bản duy nhất · 22/10/2026)

> **File này thay thế toàn bộ gói 1–6** và file `SceneForge_PhanTichVideo.md`. Chỗ nào gói cũ nói khác thì **làm theo file này**. Người code chỉ cần đọc file này, cộng ảnh trong `anh/` và bảng thử `SceneForge_BangThuThat.xlsx`.
>
> **Ký hiệu phạm vi:**
> - **[MVP]** làm ở bản đầu tiên.
> - **[B2]** làm ở bản 2, sau khi MVP chạy ổn.
> - **[Sau]** để dành, chưa làm.
> - **[Không]** không bao giờ làm.
>
> Chữ, số, tên trong ảnh đều là **ví dụ**.

---

## 0. Đọc trước

### 0.1 Luật chung (bắt buộc)
1. Chỉ video **dọc 9:16**.
2. **Không nút giả.** Nút nào hiện ra thì phải chạy thật. Chưa làm được thì ẩn đi.
3. **Không bịa con số.** Credit, tiền, dung lượng, thời gian đều phải đọc hoặc đo thật. Ước tính thì ghi rõ là ước tính.
4. **Không lưu key, mật khẩu, cookie dạng chữ thường.** Dùng keyring (kho mật khẩu của Windows) + cryptography để mã hóa.
5. Không gọi dịch vụ trả phí khi người dùng chưa cho phép.
6. Đăng nhập Google / Meta chỉ nằm trên máy người dùng. Không đưa cho bên thứ ba.
7. **Không chép mã AGPL** (Concat, OpenMontage, YOLO của Ultralytics). Không dùng FlowKit. Không dùng dịch vụ giải captcha thuê.
8. **Báo lỗi luôn ghi rõ dịch vụ nào lỗi** (Gemini / Flow / Meta / FFmpeg…) + mã lỗi + lời giải thích tiếng Việt dễ hiểu + nút **Sao chép chi tiết lỗi**. Nút này tự xóa key và cookie trước khi chép. Không gộp chung thành "API từ chối yêu cầu".
9. Ghi file kiểu **an toàn**: ghi ra file tạm rồi mới đổi tên, để tắt app đột ngột không làm hỏng dữ liệu.

### 0.2 Cách làm việc với người dùng
- Người dùng nói tiếng Việt, hay gõ bằng giọng nói. Đọc cả đoạn, đoán ý, nói lại ý mình hiểu trong 1 câu.
- Đưa **1 đề xuất rõ ràng**, mỗi lượt hỏi tối đa 1–2 câu. Khi họ không hiểu thì **vẽ ảnh tĩnh**, đừng viết thêm chữ.
- **Không tự chạy hay sửa mã khi họ còn đang bàn.** Họ nói "chốt" thì mới làm.
- Nói thật cái gì chưa làm hoặc chưa kiểm tra. Họ thích giao diện đẹp kiểu CapCut, ghét kiểu bảng biểu khô.

### 0.3 Mã hiện có
- Nền Python: `source/app.py`. Giao diện chạy trong trình duyệt tại `http://127.0.0.1:8000/studio/`. Cần FFmpeg.
- Tình trạng mã cũ: xem `tham-khao/TOM_TAT_CHO_CLAUDE_MOI.md` (mục 1, 2, 7).
- Vị trí mã trình dựng: xem `tham-khao/DUNG_VIDEO_THONG_NHAT.md`.
- Trang chủ và tab Tạo video **đã có bản đang code**. Ảnh trong `anh/` là bản sửa của những bản đó.

---

## 1. Phần mềm làm gì

Người dùng bán hàng trên TikTok Việt Nam. Họ lấy **video bán hàng của đối thủ** (30–60 giây, có thể nói tiếng nước ngoài) làm mẫu, rồi làm ra **video mới cùng cấu trúc và thời lượng**. Video mới đổi người, trang phục, sản phẩm, bối cảnh (tùy chọn), lời thoại (viết lại, không chép) và giọng.

**Người dùng chỉ làm 3 việc: thả video → duyệt khung → bấm xuất.** Phần còn lại máy làm.

| Cách làm | Phạm vi | Dùng khi | Động cơ |
|---|---|---|---|
| 🎬 **Từ video mẫu** | **[MVP]** | Có video đối thủ | Flow · Veo (qua flow2api) |
| 🖼 **Từ ảnh sản phẩm** | **[B2]** | Chưa có video mẫu, video show đồ vật | Meta · Muse (qua muse2api) |

---

## 2. Phạm vi bản đầu (MVP)

**Mục tiêu MVP:** chạy trọn một video **Từ video mẫu**: thả video → phân tích → ảnh khung → clip Veo → dựng → xuất MP4.

| Phần | MVP | Bản 2 | Để sau |
|---|---|---|---|
| Khung app, sản phẩm, phòng, thư mục | ✅ | | |
| Trang chủ 4 cột, tùy chỉnh sản phẩm, thả nhiều video | ✅ | Lọc Video mẫu / Từ ảnh, tab Bộ cảnh | Chế độ Danh sách |
| Tab Tạo video · Từ video mẫu | ✅ đầy đủ | | Omni |
| Phân tích: phần chạy trên máy + Gemini | ✅ | Key OpenAI dự phòng | |
| Hàng chờ | ✅ làn Flow | Làn Meta | |
| Tài khoản | ✅ Flow | Meta | Tài khoản Google AI Pro cho Phân tích |
| Tab Dựng | ✅ 4 lỗi + chức năng chính | | Các mục "để sau" ở mục 8 |
| Giọng đọc VieNeu v3 | ✅ | VieNeu V4 trả phí | Nhân bản giọng |
| Tự bỏ logo Veo | ✅ | | |
| Cài đặt, Thông báo, Màn chào | ✅ (bỏ phần Meta) | | |
| Tab Từ ảnh, Bộ cảnh, Đạo diễn AI | | ✅ | |
| Kho kịch bản | Chỉ **lưu dữ liệu** công thức tự động | ✅ giao diện + mục 📚 trên thanh trái | Ngăn câu mở đầu / câu chốt hay |
| Lịch sử phòng 🕘, Ctrl+Z trên sơ đồ | | ✅ | |
| Xuất phòng thành .zip (sao lưu) | | ✅ | |

---

## 3. Khung app

### 3.1 Bố cục chung
`[thanh dọc trái] [nội dung]`

**Thanh dọc (luôn hiện):**
- Logo.
- Trang chủ · Tạo video · Dựng. Hai mục sau mở **phòng gần nhất**. Chưa mở phòng nào thì mờ.
- 📚 Kịch bản **[B2]**.
- Phía dưới: ⏳ Hàng chờ (số việc đang chạy) · 🔔 Thông báo (số việc cần bạn) · ⚙ Cài đặt.
- **Không** có cột đo credit trên thanh dọc. Credit xem ở Hàng chờ, tab Chi phí, Tài khoản.

### 3.2 Sản phẩm
**1 sản phẩm = 1 ngăn chứa video + 1 bộ ảnh tham chiếu + 1 thư mục trên máy.**
- Bộ ảnh gồm người, trang phục, sản phẩm, bối cảnh (tùy chọn).
- Ảnh tham chiếu được **chép** vào từng phòng, sửa riêng trong phòng được, không đổi bộ gốc.

### 3.3 Phòng làm việc
**1 video mẫu = 1 phòng = 1 thư mục.**
- Thả 1 hay nhiều video là tự tạo phòng, tự tạo thư mục, tự xếp vào hàng phân tích. Không có bước tải lên nào khác.
- Mỗi phòng có `du-an.json` riêng (cảnh, lời, prompt, trạng thái, timeline dựng), tự lưu liên tục.
- Thanh trên của tab Tạo video và tab Dựng luôn ghi **"Phòng: <tên> ▾"**.

### 3.4 Thư mục
```
SceneForge/                     ← chọn 1 lần ở Màn chào, đổi được ở Cài đặt
├─ Dung-chung/                  ← logo, nhạc dùng chung
├─ Son/                         ← 1 sản phẩm
│  ├─ bo-anh/
│  ├─ Son-mau-7/                ← 1 phòng
│  │  ├─ du-an.json
│  │  ├─ 1-video-mau/           ← bản sao video mẫu
│  │  ├─ 2-phan-tich/           ← khung gốc, lời gốc, bản dịch, kết quả đo
│  │  ├─ 3-anh-tham-chieu/
│  │  ├─ 4-khung/               ← canh-01-ban-1.jpg… giữ mọi bản
│  │  ├─ 5-clip/                ← canh-01-ban-1.mp4 (đã bỏ logo) + canh-01-ban-1.goc.mp4
│  │  ├─ 6-giong-doc/
│  │  └─ 7-xuat/                ← MP4 cuối
└─ (lưu trữ = cờ trong du-an.json, không chuyển file)
```
- Tên thư mục bỏ dấu, thay khoảng trắng bằng gạch ngang. Trùng tên thì thêm `-2`.

### 3.5 Phong cách giao diện
- Nền `#101216`. Mặt thẻ `#171A20` / `#1E222A`. Đường kẻ `#23272F`.
- Chữ chính `#F1F2F4`, chữ phụ `#8A909B`, chữ mờ `#5C626D`.
- Màu nhấn chanh `#D4F53C`: chỉ dùng cho nút chính và mục đang chọn.
- Màu trạng thái:
  - Vàng `#F5B544`: cần bạn.
  - Xanh dương `#3CC8E0`: đang chạy.
  - Đỏ `#F0645A`: lỗi.
  - Xanh lá `#5CD18B`: xong.
  - Tím `#A98BF5`: phân tích.
- Font Inter / Inter Display hoặc Be Vietnam Pro, phải đủ dấu tiếng Việt.
- Ít viền, nhiều khoảng thở, ảnh bìa là chính. Một màn hình chỉ 1–2 thứ được tô nổi.

---

## 4. Trang chủ  ·  ảnh `anh/01`, `anh/02`, `anh/03`

### 4.1 Cột Sản phẩm
- Dòng đầu: "Tất cả" kèm "● n cần bạn".
- Mỗi sản phẩm hiện: chấm màu, tên, rồi **nhãn vàng số việc cần bạn** (hoặc nhãn đỏ lỗi). Không có việc gì thì hiện số video.
- Nút ＋ tạo sản phẩm. Dưới cùng là **Lưu trữ** (video đã xuất quá 7 ngày tự vào đây, vẫn mở được).
- **Tùy chỉnh:** rê chuột vào sản phẩm thì hiện **⋯**. Menu gồm:
  - Đổi tên
  - Đổi màu
  - Thêm ảnh vào bộ ảnh
  - Gộp vào sản phẩm khác…
  - Lưu trữ sản phẩm (chỉ ẩn, không xóa)
  - Xóa sản phẩm…
- **Nháy đúp tên** để đổi tên tại chỗ. **Kéo ⋮⋮** để đổi thứ tự.
- **Xóa sản phẩm:**
  - Báo trước sẽ mất gì: số video, bộ ảnh, dung lượng đo thật.
  - Hai lựa chọn: chuyển video sang sản phẩm khác (mặc định), hoặc xóa hết vào Thùng rác của máy (khôi phục được 30 ngày).
  - **File trong `7-xuat/` luôn được giữ.**
  - Có nút phụ "Lưu trữ thay vì xóa".

### 4.2 Khu sản phẩm
- **Đầu khu:** chữ nhỏ "Sản phẩm", tên to, ô tìm, nút **＋ Video mới ▾**.
- **Tab:** Video · Bộ ảnh · Chi phí. Tab Bộ cảnh **[B2]**.
- **Tab Video, bảng 4 cột** (video tự chuyển cột):

| Cột | Gồm |
|---|---|
| 🟡 **Cần bạn** | Duyệt khung, clip lỗi, thiếu key, đã ghép xong chờ dựng / xuất |
| 🔵 **Máy đang chạy** | Đang tạo trên Flow. Nhãn "● Flow đang chạy" |
| 🟣 **Đang chuẩn bị** | Mới thả, đang phân tích, xếp hàng phân tích, để sau |
| 🟢 **Đã xuất** | 2 nút: **Sửa tiếp** (không tốn credit) · **Dùng lại mẫu** (phòng mới, tốn credit khi tạo) |

- **Thẻ video:**
  - Ảnh bìa có chữ móc câu, tên video, "▸ mẫu · ngày".
  - Dải màu, mỗi ô là một cảnh.
  - 1 dòng **trạng thái thật** (ví dụ "Flow · clip 3/6 · cảnh 4 đang tạo"). **Không để chữ minh họa** kiểu "Flow · trạng thái minh họa" hay "Chờ dò cảnh cục bộ".
  - Nút việc chính.
  - Bấm thẻ là mở đúng chỗ đang dở.
- **Khi có nhiều video:**
  - Mỗi cột chỉ video đầu tiên hiện thẻ to, các video còn lại thu thành dòng gọn.
  - Cột dài thì cuộn riêng.
  - Cột Đã xuất hiện 2 video mới nhất kèm dòng "+n video nữa".
- **Chuột phải thẻ:**
  - Mở · Đổi tên · Mở thư mục · Chuyển sang sản phẩm khác.
  - **Dọn cho nhẹ:** xóa bản sao video mẫu, clip không chọn, file tạm. Giữ phân tích, kịch bản, prompt, timeline, clip đang chọn, MP4. Hiện trước số MB sẽ dọn.
  - **Xóa dự án** (phải hỏi lại).
- 👍 Ra đơn / 👎 Không ăn thua trên thẻ Đã xuất: **[MVP]** lưu điểm, **[B2]** hiện trong Kho kịch bản.

### 4.3 Thả nhiều video (ví dụ 5 video)
- Tạo ngay 5 phòng, tên đánh số nối tiếp (Son · mẫu 7…11).
- Cột Đang chuẩn bị gom thành **nhóm "🆕 5 video vừa thả"**.
- **Thông báo nhỏ:** "Đã nhận 5 video → 5 phòng trong Son".
- **Thả khi đang ở "Tất cả":** hiện bảng chọn sản phẩm (cho tất cả hoặc từng video), có AI gợi ý theo tên file, kèm nút ＋ Sản phẩm mới. **Thả khi đang ở trong 1 sản phẩm thì không hỏi.**

### 4.4 Video chưa phân tích xong  ·  ảnh `anh/03`
Mỗi dòng có dải 4 bước: Cắt cảnh · Chép lời · Đọc chữ · Gemini.

| Tình huống | Hiện gì | Nút |
|---|---|---|
| Vừa thả | Tự phân tích (tối đa **2 video cùng lúc**) | ⏸ Để sau |
| Đợi lượt | Xếp hàng · thứ n | ⏸ Để sau |
| Người dùng bấm ⏸ | Chưa phân tích · bạn để sau | ▶ Phân tích |
| Chưa có key / key lỗi | Phần chạy trên máy vẫn xong, chỉ chờ bước Gemini | Thêm key |
| Tắt app khi đang chạy | Mở lại thì **tự chạy tiếp từ bước dở** (phân tích không tốn credit) | — |

- Mở phòng lúc đang phân tích: video xem được ngay, các ô sau mờ và ghi "Chờ phân tích xong".

### 4.5 Hộp "＋ Video mới"  ·  ảnh `anh/02`
- Dòng đầu: "Video mới trong <sản phẩm> · đổi ▾".
- **Từ video mẫu:** "Có video đối thủ → làm lại với người và sản phẩm của bạn". Chip: chọn được nhiều file · tốn credit Flow khi tạo clip. Bấm vào là **mở hộp chọn file ngay**.
- **Từ ảnh sản phẩm [B2]:** ở MVP thì **ẩn**, không hiện nút giả.
- Dòng nhắc "Hoặc kéo thả video thẳng vào trang". Phím tắt V.
- **Chưa kết nối Flow:** không khóa nút. Hiện "⚠ Chưa kết nối Flow · Kết nối · vẫn phân tích được".

---

## 5. Tab Tạo video · Từ video mẫu  ·  ảnh `anh/04` (ảnh chính), `anh/05`

### 5.1 Quy trình 14 bước
| # | Việc | Dùng | Chạy ở đâu | Tốn |
|---|---|---|---|---|
| 1 | Thả video, chép vào phòng | App | Máy | 0đ |
| 2 | Cắt cảnh, gộp / tách cho mỗi clip ≤ 8s | **PySceneDetect** | Máy | 0đ |
| 3 | Khung gốc đầu · giữa · cuối | **FFmpeg** | Máy | 0đ |
| 4 | Chép lời có mốc giây | **faster-whisper** | Máy | 0đ |
| 5 | Đọc chữ / logo trên hình | **RapidOCR** | Máy | 0đ |
| 6 | Chuyển động máy quay, báo cảnh mờ / rung / tối, nhãn có người | **OpenCV** | Máy | 0đ |
| 7 | Hiểu cảnh, viết prompt, dịch và viết lại lời | **Gemini** | Mạng | 0đ với key miễn phí |
| 8 | Tạo ảnh khung | **Flow · Nano Banana 2 Lite** | Mạng | miễn phí (Google ghi "không mất phí") |
| 9 | Nâng khung lên 2K + máy tự kiểm | Flow + RapidOCR + OpenCV | Mạng + máy | 2K: 0 credit (nguồn bên thứ ba, phải thử) |
| 10 | **Người duyệt khung** | App | Máy | — |
| 11 | Tạo clip | **Flow · Veo 3.1 Lite** | Mạng | **~10 credit / clip** |
| 12 | Bỏ logo Veo | **gwmr** | Máy | 0đ |
| 13 | Giọng đọc | **VieNeu-TTS v3** | Máy | 0đ |
| 14 | Dựng, phụ đề, nhạc, xuất | **FFmpeg** | Máy | 0đ |

**Nguyên tắc:** việc **đo được** thì để máy làm. AI chỉ làm phần **hiểu và viết**. Gửi lên AI chỉ **khung ảnh + lời + chữ đã đo**, không gửi nguyên video.

### 5.2 Bố cục màn hình
- **Thanh trên, dòng 1:** ← · "Phòng: <tên> ▾" · Tạo video / Dựng · ⏳ Hàng chờ.
- **Thanh trên, dòng 2:** 🎬 Từ video mẫu (🖼 Từ ảnh **[B2]**, ẩn ở MVP) · **thanh 4 chặng** ghi rõ chặng đang ở, ví dụ "Duyệt khung · 8 chờ · 2 lỗi" · ✓ Đã lưu.
- **Nền sơ đồ:** nền tối có chấm. Các ô **tự xếp theo cột**, người dùng không phải tự nối dây (dây chỉ để thấy luồng). Kéo tiêu đề để nhấc ô, Space + kéo để di nền. Có bản đồ nhỏ và zoom ở góc phải dưới.
- **Thanh dưới:** số cảnh · số clip · Credit Flow đã xác minh / chưa xác minh · tài khoản · ước tính credit, kèm nút **"✓ Duyệt hết khung đạt & tạo clip"**. Bấm thì hỏi lại kèm số credit.
- **Màu dây:** tím = chữ / cảnh, xanh lá = ảnh, xanh dương = video, tím nét đứt = giọng đọc.

| Cột | Ô |
|---|---|
| 1 | Video tham khảo · Phân tích · Kịch bản → Giọng đọc |
| 2 | Các cảnh · Ảnh tham chiếu |
| 3 | Ảnh khung (lưới) |
| 4 | Video Veo (lưới) |
| 5 | Sang Dựng |

### 5.3 Video tham khảo
- Kéo thả hoặc chọn file (MP4, MOV, WebM, dọc 9:16).
- Hiện ảnh xem trước, tên, thời lượng, có lời hay không, ngôn ngữ, nút ▶ Xem · Thay.
- Dòng "🔒 Chỉ lưu trên máy này".

### 5.4 Phân tích
- **Các bước, mỗi bước có nhãn "máy" hoặc "Gemini" và dòng giải thích nhỏ:**
  1. Cắt ở chỗ chuyển cảnh
  2. Gộp đoạn ngắn · clip ≤ 8s · giữ trọn câu thoại
  3. Khung đầu · giữa · cuối (đổi được từng cảnh)
  4. Chép lời có mốc giây (SRT/VTT, nhập được file)
  5. Đọc chữ / logo trên hình
  6. Chuyển động máy quay
  7. Báo cảnh mờ / rung
  8. Hiểu cảnh · viết prompt · dịch (Gemini)
- **Tự so:**
  - So kết quả Gemini với số máy đo (số cảnh, lời lệch mốc giây, chữ). Chỗ lệch thì **báo vàng**, ví dụ "Gemini nói 14 cảnh, máy cắt 13 · Xem".
  - Không tự chạy tiếp qua chỗ lệch.
- **Chi phí đo thật** (0đ nếu dùng key miễn phí). Nút ↻ chạy lại.
- Xong thì **tự lưu công thức** của video vào dữ liệu Kho kịch bản (chỉ lưu khung sườn và câu đã viết lại, **không lưu nguyên lời gốc**).
- Cảnh dài hơn 8 giây thì tách thành nhiều clip (2a, 2b), cắt ở chỗ ngắt câu gần nhất.

### 5.5 Kịch bản → Giọng đọc  ·  ảnh `anh/06`
- Trên sơ đồ chỉ hiện bản gọn. Bấm "mở bảng ↗" thì ra bảng đầy đủ.
- **Bảng 4 cột:** Mốc giây | Lời gốc | Dịch sát | **Lời mới** (chỉ sửa ở cột này).
- Lời mới do AI viết sẵn. Có nút "AI viết lại cả bài" kèm 1 dòng dặn thêm. Công tắc "Chỉ dịch, giữ ý gốc" / "Viết lại cho sản phẩm của tôi".
- **Chia lời theo mốc giây, không theo cảnh.** Video mới giữ đúng thời lượng từng cảnh.
- **Thanh đo mỗi câu:** "đọc ~3.4s / chỗ 4s". Xanh là vừa, đỏ là dài quá, kèm nút ✨ Rút gọn. Đo bằng cách đọc thử thật, không đếm chữ.
- Câu thấy mặt người nói có nhãn tím "thấy mặt nói". Câu đó được đưa vào prompt video để Veo mấp máy miệng.
- **Một giọng đọc chung** cho cả video, đặt đúng mốc giây.
- **Giọng:**
  - Chọn giọng (mặc định nữ miền Nam), tốc độ 0.8–1.3×, ▶ Nghe cả bài.
  - **Thả file giọng có sẵn** (mp3 / wav / m4a) thay cho giọng AI.
  - Không lời.
- ⚠ Nên có nhắc khi lời mới giống lời gốc quá nhiều (TikTok hạ video không gốc).

### 5.6 Các cảnh và Ảnh tham chiếu
- **Các cảnh:**
  - Mỗi cảnh có ảnh nhỏ, "Cảnh n · 0:08–0:12", mô tả ngắn (Gemini), nhãn có người / không người (OpenCV), nhãn "mờ".
  - Nhiều cảnh thì cuộn. Có nút ↻ Chia lại (kéo chỉnh mốc tay).
  - Bấm vào một cảnh thì mở bảng chi tiết bên phải.
- **Ảnh tham chiếu (Người / Trang phục / Sản phẩm / Bối cảnh):**
  - Tự lấy từ bộ ảnh của sản phẩm. Mỗi loại có ô mô tả bằng chữ.
  - Bối cảnh để trống thì giữ như gốc.
  - **Nối ô nào thì đổi thứ đó, không nối thì giữ như video gốc.** App tự nối theo kết quả phân tích, người dùng bỏ nối được.
  - Thiếu ảnh thì nhắc, ví dụ "Nên thêm ảnh toàn thân".
  - **Dùng chung một bộ ảnh người cho mọi cảnh** để mặt giữ giống nhau.

### 5.7 Ảnh khung (lưới)
- **Prompt khung app tự viết:**
  - Câu mẫu: *"Giữ bố cục, tư thế, kích thước và bảng màu của khung gốc. Chỉ thay những thành phần có ảnh tham chiếu được nối…"*
  - Cộng thêm chi tiết của cảnh. Sửa được bằng ✎.
- **Mô hình:**
  - Mặc định **Nano Banana 2 Lite**.
  - Cảnh cận sản phẩm / nhãn quan trọng thì gợi ý **Pro**.
  - Mỗi cảnh tạo sẵn **2 bản**.
- **Làm trên máy để đỡ chờ:**
  - Cảnh **không người, không sản phẩm** thì tự dùng khung gốc ("Dùng khung gốc · tự động").
  - **Che logo / chữ đối thủ** trên khung gốc bằng RapidOCR + OpenCV ("Đã che logo · trên máy").
  - **[Sau]** Dán ảnh sản phẩm đã tách nền (rembg).
- **Khung chỉ sang Veo khi đủ 3 điều kiện:**
  1. Nhãn đọc được (RapidOCR so với tên sản phẩm).
  2. Đủ nét (OpenCV).
  3. Đã nâng 2K.
  - Giữ nguyên file Flow trả về, **không nén thêm**.
  - Thiếu điều kiện nào thì đánh dấu "! cần xem".
- **Giao diện ô:**
  - **Lưới ảnh nhỏ 9:16** (6 cột), không làm danh sách dài.
  - Chấm trạng thái: ✓ đạt · ! cần xem · ✕ lỗi (kèm lý do ngắn) · ● đang tạo · … xếp hàng.
  - **Có lỗi thì cả viền ô đỏ** + dải "✕ n khung lỗi · Xem lỗi". Ảnh lỗi có viền đỏ riêng.
  - Dòng đếm: đạt · cần xem · lỗi · đang tạo. **Lọc:** Tất cả / Lỗi / Cần xem / Chờ duyệt.
  - **"✓ Duyệt hết n khung đạt"** và **"↻ Tạo lại n khung lỗi"**, mỗi nút bấm 1 lần là xong. Khung lỗi và khung cần xem **không bị duyệt theo**.
- Ô clip của một cảnh chỉ vào hàng chờ khi khung cảnh đó đã duyệt.

### 5.8 Video Veo (lưới)
- Giao diện giống ô Ảnh khung: lưới clip có nút ▶, viền đỏ khi lỗi, lọc, **"✓ Nhận hết n clip đạt"**, **"↻ Tạo lại n clip lỗi · x credit"**. Tạo lại clip **luôn hỏi trước** vì tốn credit.
- **Mô hình:** mặc định **Veo 3.1 Lite**, từng cảnh đổi được sang Fast. Omni **[Sau]**.
- **Cách tạo clip:**
  - Mặc định: từ khung đã duyệt.
  - **[Sau]** Thử nghiệm "Từ 3 ảnh tham chiếu, bỏ bước khung" (chỉ bật khi thử thật đạt).
- **Giữ mọi bản**, chọn bản nào thì bản đó sang Dựng.
- Dòng "＋ Thêm yêu cầu riêng cho cảnh…" (thêm vào prompt).
- **Nút "⤓ Nhập clip làm sẵn trên Flow"** (đường dự phòng khi flow2api hỏng): thả clip tự tạo trên web Flow vào đúng cảnh. **Bắt buộc có ở MVP.**
- **Tự bỏ logo Veo:**
  - App tự chạy ngay khi tải clip về, **trước khi nâng 1080p**. Không có nút trên giao diện.
  - Bản gốc lưu ngầm (`.goc.mp4`).
  - Lỗi thì dòng vàng "⚠ Chưa bỏ được logo Veo · Thử lại", dùng tạm bản gốc, không chặn các bước khác.
  - Tắt / bật ở Cài đặt → Xuất video.
  - Chỉ bỏ được logo nhìn thấy, **dấu ẩn SynthID vẫn còn**.

### 5.9 Phóng to (bấm vào 1 ảnh khung hoặc clip)  ·  ảnh `anh/05`
- Mở to **ngay trên tab**, nền sơ đồ tối lại.
- **Khung gốc đặt cạnh khung mới**. Chọn bản 1 / 2. Phần "Máy tự kiểm": đủ nét · đã 2K · nhãn đọc được. Prompt khung có ✎ Sửa.
- **Nút:**
  - **Duyệt (Enter)** · **Tạo lại (R)** · Tạo lại bằng Pro.
  - **← →** sang cảnh khác.
  - **Esc** hoặc bấm ra ngoài để đóng.
- Dải ảnh nhỏ dưới cùng, màu viền là trạng thái từng cảnh.
- Clip thì phát to, có các nút tương tự.

### 5.10 Bảng chi tiết bên phải (bấm 1 cảnh trong ô Các cảnh)
- Tiêu đề "Cảnh 4 · 0:20–0:28", mô tả, nút ✕.
- **Tab:** Prompt video · Prompt khung · Lời thoại · Các bản.
- Công tắc Tiếng Việt / English (gửi Veo).
- Nút ✨ AI viết lại · Lưu.

### 5.11 Sang Dựng
- Ghi "n/13 cảnh có clip · giữ mọi bản đã nhập".
- **Ghép sẵn cho tôi** (mặc định): clip đúng thứ tự cảnh, giọng và nhạc đúng mốc.
- **Để tôi tự ghép:** timeline trống, mọi thứ nằm trong Kho, xếp theo cảnh. "Đặt sẵn giọng đọc đúng mốc" bật sẵn.
- **Chữ & nhạc:**
  - Phụ đề tự lấy từ lời đọc.
  - Kiểu chữ chọn theo mẫu.
  - Nhạc nền từ kho hoặc nhập file.
  - Vặn nhỏ nhạc khi có giọng (bật).
- Nút **Mở trong Dựng**, mở được khi đủ clip.
- **Luật không đè:** đã chỉnh tay trong Dựng mà tạo lại một cảnh thì bản mới **chỉ vào Kho** với nhãn "bản mới" và nút "Thay vào timeline". App **không tự thay** timeline.

### 5.12 Mẫu prompt video (mỗi cảnh)
- **Phần mô tả viết tiếng Anh, lời thoại để tiếng Việt** trong ngoặc kép. Giao diện cho xem và sửa bằng tiếng Việt, tự đổi khi gửi Veo.
- Nếu có file mẫu của người dùng `references/prompt-example-user.txt` trong mã cũ thì làm khớp theo file đó.

**VISUAL:**
- Nhân vật (ghi rõ lấy theo ảnh Người / Trang phục nào).
- Sản phẩm: nhãn **luôn quay ra camera, chữ rõ**.
- Kích thước tương đối, bố cục 9:16, bối cảnh, ánh sáng.

**MOTION & SCRIPT:**
- Máy quay: lấy từ **bước đo chuyển động** (lia, zoom, cầm tay…).
- Trạng thái đầu → hành động → trạng thái cuối.
- Lời: *speaks in Vietnamese, Southern accent: "…"*.
- 8s, 9:16, không chữ trên hình.

### 5.13 Mô hình dữ liệu gợi ý
```
Project   { id, name, productId, sourceVideo, createdAt, archived, steps{analysis, frames, clips, edit} }
Scene     { index, start, end, cutIds[], thumbs{first,mid,last}, description, hasPerson, faceTalking,
            blurry, cameraMotion, ocrText[], competitorLogo[], refsUsed[],
            promptFrame, promptVideo{visual, motion}, extraRequest,
            frames[{version, file, model, checks{sharp, upscaled2k, labelReadable}, status}], approvedFrame,
            clips[{part, version, file, fileOriginal, model, credits, watermarkRemoved, status}], chosenClip }
RefSet    { person[], outfit[], product[], background[] }   (ảnh + mô tả)
ScriptLine{ start, end, original, translation, newText, sceneIds[], faceTalking, measuredSec }
Voice     { source: ai|file|none, name, speed, audioFile, lineTimings[] }
Job       { id, projectId, sceneIndex, version, type: frame|clip|upscale, lane, account, status, credits, error{service, code, message} }
Formula   { id, name, industry, duration, beats[{name, start, end, purpose, shotType, example}], sourceProjectId, uses, up, down }
```

---

## 6. Hàng chờ và tài khoản

### 6.1 Ba làn chạy
| Làn | Việc | Song song |
|---|---|---|
| Phân tích | Phần chạy trên máy + Gemini | **Tối đa 2 video** (chốt sau khi thử giới hạn Gemini) |
| Flow | Làm khung, nâng 2K, tạo clip | **1 hàng chờ chung cho mọi phòng**, chạy lần lượt, có nghỉ |
| Xuất | FFmpeg ra MP4 | 1 video mỗi lần, chạy nền |
| Meta **[B2]** | Bộ cảnh, khung trước | Song song với làn Flow |

Mỗi việc gắn **mã phòng + số cảnh + số bản**, tải về ghi đúng thư mục phòng.

### 6.2 Luật hàng chờ Flow
1. Bấm Duyệt / chạy thì **thả việc vào hàng chờ**, không chạy ngay. Ô hiện lần lượt "Xếp hàng · thứ n" → "Đang tạo… 37s" → "Xong".
2. Việc làm khung chạy trước việc tạo clip.
3. Vào trước chạy trước. Trong 1 phòng thì theo thứ tự cảnh.
4. Nút **Ưu tiên** cả phòng. Kéo để đổi thứ tự.
5. **Hủy** việc chưa chạy thì không mất credit.
6. **Tạm dừng:** việc đang chạy làm nốt rồi mới dừng.
7. Việc lỗi đánh dấu đỏ, **không tự chạy lại**.
8. Trước khi thả việc, hiện **tổng credit cần dùng**. Không đủ thì báo ngay.
9. **Ngăn kéo Hàng chờ** trượt từ bên phải, mở được ở mọi tab (nút ⏳ trên thanh trái).
   - Bên trong: tài khoản đang dùng, credit còn lại kèm giờ đọc, việc đang chạy, việc xếp hàng nhóm theo phòng.
   - Ảnh `anh/12`.

### 6.3 Tài khoản (Cài đặt → Tài khoản)  ·  ảnh `anh/10`
- **Bố cục:**
  - Dòng sức khỏe tổng.
  - Luồng kết nối (dịch vụ ở giữa, tài khoản xung quanh).
  - 20 yêu cầu gần đây, mỗi yêu cầu ghi số credit đã trừ.
  - Bảng tài khoản: ưu tiên ⋮⋮, trạng thái, phiên, credit, thành công / thất bại, bật / tắt, thao tác.
  - Bảng chi phí theo ngày và theo sản phẩm, tính từ nhật ký thật.
- **Trạng thái:** Đang dùng · Sẵn sàng · Hết credit · Phiên hết hạn · Đòi xác minh · Đang nghỉ · Đã tắt · Bị khóa.
- **Thao tác:** Dùng tài khoản này · Đăng nhập lại · Mở để xác minh · Kiểm tra · ⋯ (Đổi tên / Đăng xuất / Gỡ).
- **＋ Kết nối tài khoản:** mở cửa sổ trình duyệt riêng để người dùng tự đăng nhập. App không thấy mật khẩu.
- **Luật:**
  1. Mỗi lúc chỉ **1 tài khoản đang dùng** cho mỗi dịch vụ.
  2. **"Tự chuyển tài khoản khi hết credit": mặc định TẮT** (có cảnh báo "dễ bị khóa cả loạt").
     - Tắt: hết credit thì dừng làn, kêu chuông và báo.
     - Bật: chuyển theo thứ tự Ưu tiên, ghi nhật ký.
  3. **Bị đòi xác minh thì luôn dừng hẳn**, người dùng tự xác minh.
  4. Một video giữ một tài khoản từ đầu đến cuối.
  5. **3 lỗi liên tiếp** thì chuyển "Đang nghỉ", rồi tự kiểm tra nhẹ 1 lần.
  6. Kiểm tra phiên **khi mở app và trước mỗi đợt chạy**. Chỉ gia hạn khi sắp hết hạn, **không gọi định kỳ**.
  7. **Mã lỗi:**
     - 401: đăng nhập lại.
     - 403: chưa chắc hết phiên.
     - 429 / 5xx / quá giờ: giữ trạng thái cũ.
  8. **Mất kết nối khi đang tạo thì chỉ hỏi lại trạng thái, KHÔNG gửi lại lệnh tạo** (tránh mất credit 2 lần).
  9. Tắt app giữa chừng: việc Flow dở đánh dấu "chưa xong", **không tự chạy lại**.
  10. Credit đọc riêng từng tài khoản, kèm giờ đọc. Đọc lỗi thì giữ số cũ và ghi rõ.
- ⚠ flow2api là nối tài khoản web, **có rủi ro bị khóa**. Giảm bằng: không xoay vòng, chạy chậm có nghỉ, đường dự phòng nhập clip tay (5.8).

---

## 7. Cài đặt · Thông báo · Màn chào  ·  ảnh `anh/07`, `anh/08`

### 7.1 Cài đặt (menu trái)
`Tài khoản · Phân tích (AI) · Giọng đọc · Thư mục lưu · Xuất video · Thông báo · Động cơ`. Mục có vấn đề thì hiện số vàng.

- **Phân tích (AI):**
  - Nguồn: **Key Gemini miễn phí** (mặc định; ghi rõ Google được dùng dữ liệu) / Key Gemini trả phí / Key OpenAI **[B2]**, dự phòng (không có gói miễn phí).
  - **"Dán key là chạy":** chỉ có ô dán key + **Kiểm tra**. **Không có ô chọn mô hình.** App gọi danh sách mô hình (models.list) rồi tự chọn Flash / Flash-Lite mới nhất. Kết quả hiện "✓ Key dùng được · đang dùng <tên>".
  - 429: tự chờ rồi gọi lại. 404 mô hình: tự chọn lại. Lỗi khác: báo rõ, **[B2]** hỏi có chuyển sang OpenAI không (không tự chuyển).
  - Chi phí tháng này **đo thật** từ nhật ký gọi AI.
- **Giọng đọc:**
  - VieNeu v3 trên máy (mặc định, 0đ). VieNeu V4 trả phí **[B2]**.
  - Lọc Bắc / Trung / Nam, ▶ nghe từng giọng, tốc độ, ô gõ thử.
- **Thư mục lưu:**
  - Thư mục gốc + Đổi.
  - Dung lượng tổng và theo sản phẩm (**quét thật**).
  - Dọn tất cả cho nhẹ (hiện trước số MB).
  - Chuyển sang ổ khác: chép xong, kiểm tra xong mới xóa chỗ cũ. Báo trước nếu thiếu chỗ.
  - Cảnh báo khi ổ sắp đầy.
- **Xuất video** (mặc định cho hộp Xuất):
  - 1080p / 720p.
  - 30 / 60 fps.
  - Tự cân âm lượng: bật.
  - Kèm .srt: tắt.
  - **Tự bỏ logo Veo: bật.**
  - Nơi lưu: thư mục phòng `7-xuat/` hoặc một thư mục chung.
  - Đổi gì cũng tự lưu.
- **Thông báo:** bật / tắt từng loại, âm thanh, thông báo của máy tính.
- **Động cơ:**
  - Danh sách flow2api · VieNeu · FFmpeg · gwmr (muse2api **[B2]**): trạng thái, phiên bản.
  - Nút Cập nhật, Khởi động lại tất cả, 📋 Sao chép chi tiết lỗi.

### 7.2 Thông báo (chuông)
| Mức | Khi nào | Báo kiểu gì |
|---|---|---|
| 🟡 Cần bạn | Khung chờ duyệt · clip lỗi · hết credit · đòi xác minh · đã ghép xong chờ dựng | Chuông + tiếng kêu + thông báo của máy tính |
| 🟢 Xong việc | Phân tích xong · **xuất xong** (kèm dòng nhắc tick nhãn "Nội dung do AI tạo" khi đăng TikTok) | Ô nhỏ góc phải dưới, tự ẩn, không kêu |
| ⚪ Thông tin | Đã tự chuyển tài khoản · động cơ có bản mới · chạm giới hạn AI (đã tự chờ) | Chỉ nằm trong chuông |

- Cùng loại trong vài phút thì **gom 1 dòng** ("5 khung chờ duyệt ở 2 video").
- Mỗi dòng có nút làm ngay, **bấm dòng là nhảy đúng chỗ**.
- Lọc Tất cả / Cần bạn / Xong việc. Số trên chuông là số việc **Cần bạn** chưa xem. Giữ 30 ngày.

### 7.3 Màn chào lần đầu
| Bước | Nội dung | Bắt buộc |
|---|---|---|
| 1 | Chọn thư mục lưu (gợi ý ổ trống nhiều nhất) | ✅ |
| 2 | Kiểm tra máy, hiện ✓ từng món: FFmpeg · tải mô hình VieNeu (thanh %) · cài + khởi động flow2api (đổi mật khẩu mặc định, chỉ nghe 127.0.0.1) · dung lượng ổ | Tự chạy |
| 3 | Dán key Gemini + Kiểm tra | Bỏ qua được |
| 4 | Kết nối Flow | Bỏ qua được |
| 5 | Sản phẩm đầu tiên | Bỏ qua được |

- Bỏ qua bước nào thì app nhắc **ngay tại chỗ cần dùng**, không chặn phần khác.
- Bước 2 có món lỗi thì hiện lý do + Thử lại + Sao chép chi tiết lỗi.

---

## 8. Tab Dựng  ·  ảnh `anh/13` đến `anh/23`

### 8.0 Bốn lỗi phải sửa TRƯỚC khi thêm tính năng mới [MVP]
1. Kéo clip mượt (đo trước khi sửa; nghi `planSingleMove` / `planGroupMove` / `paintDragPlan` trong `scripts/demo-lite/timeline_modes.js` gọi `updateStage` quá nhiều).
2. Phát liền mạch qua chỗ cắt và chuyển cảnh.
3. Tự lưu: mở lại dự án thì còn nguyên.
4. **Xuất MP4 bằng FFmpeg** (bỏ cách ghi màn hình WebM), giống y lúc xem.

> Mã trình dựng hiện dồn thành dòng rất dài, chồng nhiều lớp sửa. **Việc đầu tiên:** đọc mã, chạy thử, lập bảng từng chức năng (chạy tốt / lỗi / thiếu), rồi mới quyết **vá hay viết lại riêng phần lõi timeline**.

### 8.1 Thanh công cụ timeline [MVP]
- Chỉ icon, rê chuột hiện tên và phím tắt.
- **Trái:** Hoàn tác, Làm lại, Tách (Ctrl+B), Xóa, Nhân đôi, Thay clip (giữ chỉnh sửa), Xóa khoảng trống.
- **Phải:** Chèn / Ghi đè, Hít mốc, Xếp nối tiếp, Thêm track, Zoom, Vừa khung.
- **[Sau]:** Q/W cắt trái / phải, đóng băng khung.
- **[Không]:** marker, ripple, chỉnh cao track.

### 8.2 Bên trong timeline [MVP]
- Kéo, cắt mép, vạch hít, chọn nhiều, kéo nhóm. Esc trả clip về chỗ cũ. Tự cuộn khi kéo sát mép.
- Kéo lên trên thì tạo hàng tạm. Hàng trống tự xóa.
- **Đầu hàng:** có vạch màu (Phụ đề cam, Video xanh dương, Giọng tím, Nhạc xanh ngọc), khóa / ẩn / tắt tiếng.
- **Clip:**
  - Clip hiện ảnh khung thật. Clip AI có nhãn "Cảnh 3 · bản 1".
  - Chuột phải: Thay clip · Mở cảnh này bên Tạo video · Tách tiếng · Nhân đôi · Xóa.
  - Sóng âm, chỗ quá to tô vàng.
- Đồng hồ âm lượng tổng.
- **Chuột:** lăn = cuộn ngang, Ctrl+lăn = zoom, Shift+lăn = cuộn dọc.

### 8.3 Âm thanh [MVP]
- Bảng kiểu CapCut.
- **Nhạc:** dB, rõ dần / mờ dần, tự nhỏ khi có giọng, tốc độ (giữ cao độ).
- **Giọng:** như nhạc, thêm tab đọc lại câu / chọn giọng.
- **Video:** tiếng gốc (clip Veo **tắt sẵn**), tách tiếng.
- Xuất thì tự cân âm lượng.
- **[Sau]:** tách giọng khỏi nhạc, nhân bản giọng.

### 8.4 Khung xem [MVP]
- Space phát / dừng. ← → từng khung. Toàn màn hình. Mượt / Nét. Giữ đủ khung / Lấp đầy.
- **"Xem như TikTok":** tô đỏ vùng bị che. Lớp này **không bao giờ** vào file xuất.
- Kéo chữ, ảnh ngay trên khung xem, có vạch giữa. Chữ trong vùng bị che thì viền đỏ.

### 8.5 Bảng chỉnh hình [MVP]
- Kích thước, vị trí, xoay, lật, độ trong.
- Màu: sáng, tương phản, bão hòa, nhiệt độ, nút áp cho tất cả.
- **Che logo** (làm mờ / vỡ hạt một vùng).
- Tốc độ.
- **[Sau]:** phóng to chậm, cắt khung, tự khớp màu.
- **[Không]:** mask, xóa phông, chống rung, làm đẹp.

### 8.6 Chuyển cảnh [MVP]
- Cắt thẳng (mặc định), Hòa tan, Mờ qua đen / trắng, Lướt, Trượt, Phóng, Lóe sáng. Mặc định ~0,3s, có nút Áp cho tất cả.
- **Chuyển cảnh không được làm đổi tổng thời lượng** (để giọng không lệch).

### 8.7 Chữ và phụ đề [MVP]
- **Kiểu chữ:** font (✓ đủ dấu tiếng Việt), cỡ, màu, viền, bóng, nền.
- **Mẫu chữ bán hàng (tĩnh):** Giá · Giá gạch – giá mới · Giảm % · Mua ngay · Freeship · Flash sale · Chỉ còn 10 suất · Bấm giỏ hàng.
- **Phụ đề:**
  - Lấy từ Kịch bản, tự cập nhật khi sửa.
  - Một kiểu cho cả video, 1–2 dòng.
  - Nhập / xuất SRT.
- **[Sau]:** hiệu ứng chữ xuất hiện, karaoke.

### 8.8 Kho tư liệu [MVP]
- 2 ngăn: "Dự án này" và "📌 Dùng chung" (chỉ lưu đường dẫn file).
- Clip từ Tạo video tự vào kho, xếp theo cảnh. Bản cũ hiện mờ.
- Nhập file hoặc cả thư mục. Lọc, tìm, sắp xếp.
- **Thẻ:**
  - Rê để xem nhanh. Dấu ✓ là đã dùng.
  - Mất file thì khung đỏ + nút Tìm lại.
  - Video nặng thì tạo bản xem nhẹ (có %).
- Kéo thẻ xuống timeline thì vào đúng hàng.

### 8.9 Xuất video [MVP]
- **Hộp kiểu CapCut:** tên file, lưu vào, 1080p (mặc định) / 720p, 30 / 60 fps, MP4, tự cân âm lượng, kèm .srt.
- Dung lượng ước tính do máy tính. Clip gốc chỉ 720p thì báo trước.
- **Kiểm tra trước khi xuất** (0đ, không cần mạng): mất file · chữ trong vùng TikTok che · tiếng rè · khoảng đen. Bấm dòng lỗi thì nhảy tới chỗ đó.
- **Đang xuất:** %, thời gian còn lại, Hủy. Chạy nền.
- **An toàn:**
  - Ghi ra file tạm. Kiểm tra ổ trước khi chạy.
  - Card đồ họa lỗi thì thử lại bằng CPU.
  - Trùng tên thì hỏi.
  - Mất điện thì lần mở sau tự dọn file tạm.
- **[Không]:** tự đăng TikTok, 4K, GIF, khung khác 9:16.

### 8.10 Bố cục tab Dựng [MVP]
- Kho trái · khung xem giữa · bảng chỉnh phải · timeline dưới.
- **Nút ▦ Bố cục:** 4 kiểu (Mặc định / Khung xem trái / phải / cao hết).
- Kéo đường chia, app nhớ cỡ. Gập Kho được.
- Chạy được trên laptop 1366×768.
- **Mượt:**
  - Cập nhật theo requestAnimationFrame.
  - Không tải lại video khi đổi cỡ.
  - Đang phát vẫn phát tiếp.

### 8.11 Bài tự thử của Dựng
1. Kéo 1 clip rồi kéo nhóm clip 30 giây: không giật.
2. Phát qua mọi chỗ cắt: không đứng hình.
3. Tắt app giữa chừng, mở lại: còn nguyên.
4. Xuất MP4, so với lúc xem: giống y.
5. Lăn chuột, Ctrl+lăn, kéo vạch phát trên video 45s: mượt.
6. Đổi bố cục trong lúc phát: không giật.

---

## 9. Bản 2 · Tab Từ ảnh và Kho kịch bản  ·  ảnh `anh/24`, `anh/25`

### 9.1 Tab Từ ảnh sản phẩm [B2]
- **Không** làm kiểu "mỗi câu tạo 1 clip". Làm **Bộ cảnh** cho sản phẩm (Muse, làm 1 lần, dùng lại), rồi **Đạo diễn AI** đọc kịch bản và chọn clip để ghép.
- **8 kiểu cảnh**, mỗi kiểu có prompt mẫu:
  - Cận cảnh xoay · Chi tiết · Trong bối cảnh dùng · Tay thao tác
  - Vấn đề · Kết quả · Toàn cảnh · Kêu gọi mua
  - Prompt luôn kèm "no talking, mouth closed".
- **Muse lấy ảnh làm khung đầu.** Cảnh đổi bối cảnh thì tự làm "khung trước" (sửa ảnh) rồi mới ra video.
- **Lỗi clip:**
  - Lỗi kỹ thuật thì tự thử lại 1 lần.
  - Bị từ chối nội dung thì không thử lại, có nút "Sửa prompt rồi tạo lại".
  - Tạo lại thì giữ bản cũ.
- **Kịch bản** chia nhịp, mỗi nhịp có nhãn kiểu cảnh. **Giọng:** AI / thả file / không lời.
- **Đạo diễn AI** chỉ đọc chữ (rất ít tiền). Không lặp clip liền nhau. Thiếu kiểu cảnh thì báo, **không tự tạo khi chưa hỏi**.
- Tài khoản Meta, làn Meta, muse2api: giống Flow (mục 6). `MUSE2API_CONCURRENCY=1`, heartbeat không chạy định kỳ.

### 9.2 Kho kịch bản [B2 giao diện · MVP lưu dữ liệu]
- **Mở từ:** mục **📚 Kịch bản** trên thanh trái (toàn màn hình), và ô Công thức trong tab Từ ảnh (bảng nổi).
- **Công thức** = tên + ngành + thời lượng + các nhịp (tên, giây, mục đích, kiểu cảnh, câu ví dụ đã viết lại) + mẹo. **Không lưu nguyên lời gốc.**
- **Nguồn:**
  - Tự động từ mọi video mẫu đã phân tích.
  - ＋ Từ video bạn chọn.
  - ＋ Tự gõ.
- **Danh sách** 2 nhóm "⭐ Hợp với <sp>" / "Tất cả". Mỗi dòng có dải màu nhịp.
- **Chi tiết:** Đổi tên · Xóa · Dùng công thức này. Điểm 👍 / 👎 lấy từ thẻ Đã xuất.
- **[Không]:** hộp thu thư mục, extension quét mạng xã hội.

---

## 10. Động cơ và thư viện

| Việc | Dùng | Giấy phép | Phạm vi |
|---|---|---|---|
| Flow / Veo / ảnh / 2K / credit | **flow2api** https://github.com/TheSmallHanCat/flow2api | MIT | MVP |
| Meta / Muse | **muse2api (repo gốc)** https://github.com/czg86389-hub/muse2api | MIT | B2 |
| Giọng đọc | **VieNeu-TTS v3** https://github.com/pnnbao97/VieNeu-TTS | Apache 2.0 | MVP |
| Cắt cảnh | **PySceneDetect** https://www.scenedetect.com | BSD-3 | MVP |
| Chép lời | **faster-whisper** | MIT (kiểm lại) | MVP |
| Đọc chữ | **RapidOCR / RapidVideOCR** https://github.com/SWHL/RapidVideOCR | Apache 2.0 | MVP |
| Chuyển động, độ nét, mặt, che logo | **OpenCV** | Apache 2.0 | MVP |
| Bỏ logo Veo | **gwmr** https://pypi.org/project/gwmr/ (dự phòng: VeoWatermarkRemover / GeminiWatermarkTool, allenk) | MIT | MVP |
| Mã hóa key / cookie | keyring + cryptography | MIT / Apache-BSD | MVP |
| Thông báo khi đã đóng trình duyệt | desktop-notifier | MIT | MVP |
| Lưu cài đặt | JSON + platformdirs | MIT | MVP |
| Tải mô hình có % | huggingface_hub | Apache 2.0 | MVP |
| Tách nền sản phẩm | rembg (kiểm lại giấy phép) | — | Sau |

- **flow2api phải chỉnh:**
  - Đổi admin/admin và key mẫu `han1234`.
  - Chỉ nghe 127.0.0.1, không mở `/metrics` ra ngoài.
  - Captcha chế độ **personal**.
  - Chỉ nạp 1 tài khoản đang dùng.
- **Chạy động cơ:**
  - Trên Windows **ưu tiên chạy thẳng bằng Python**, không bắt cài Docker.
  - App tự bật động cơ khi mở, tự tắt khi thoát, kiểm tra bằng `/health`.
- **Chỉ học ý, không chép mã:** gpt-load (mã hóa, nghỉ – phục hồi, ưu tiên, bảng chi phí).
- **[Không]:** fork của flow2api / muse2api, dịch vụ captcha thuê, YOLO Ultralytics (AGPL), TransNetV2 / WhisperX / CLIP / SAM / Flux / Wan ở bản đầu (nặng, cần PyTorch hoặc card đồ họa).

---

## 11. Chi phí (app phải đọc / đo thật, không ghi cứng)

**Flow, gói Pro** (theo trang Google + trang tổng hợp, 10/2026):

| Việc | Credit |
|---|---|
| Ảnh Nano Banana 2 Lite | 0 (Google: "không mất phí") |
| Nano Banana 2.1 / Pro | chưa rõ, phải đo |
| Nâng ảnh 2K | 0 (useapi.net) |
| Veo 3.1 Lite / Fast / Quality | 10 / 20 / 100 mỗi clip |
| Nâng video 1080p | 0 |

**Gemini API** (trang chính thức, 21/10/2026, cho 1 triệu token):

| Mô hình | Gửi lên | Nhận về |
|---|---|---|
| 3.1 Flash-Lite | $0,25 | $1,50 |
| 3.8 Flash | $0,75 | $3,75 |

3.8 Flash **tăng gấp đôi từ 01/01/2027**. Key miễn phí: 0đ, có giới hạn.

- Ví dụ: video 6 cảnh, Veo Lite, không tạo lại thì khoảng **60 credit**. Mỗi lần tạo lại clip cộng thêm 10.
- Giao diện phải: hiện credit còn lại, **ước tính trước khi chạy**, **hỏi lại trước khi chạy hàng loạt**.

**Nguồn:**
- https://support.google.com/flow/answer/16352836
- https://support.google.com/flow/answer/16729550
- https://ai.google.dev/gemini-api/docs/pricing
- https://useapi.net/docs/articles/google-flow-nano-banana-compare
- https://useapi.net/docs/api-google-flow-v1/post-google-flow-images-upscale
- https://felloai.com/google-flow/
- https://saascrmreview.com/google-flow-pricing/

---

## 12. Thử thật TRƯỚC khi code (bảng `SceneForge_BangThuThat.xlsx`, 27 dòng)

**Làm đúng thứ tự này. Dòng nào không đạt thì đổi theo cột "Không đạt thì" trong bảng.**
1. 🔴 **D8** Key Gemini miễn phí phân tích được 1 video (thử tay trên Google AI Studio, 0đ).
2. 🔴 **A3** flow2api chạy trên máy: đăng nhập, tạo 1 clip, đọc credit. **Không đạt thì MVP dựa vào "Nhập clip làm sẵn trên Flow".**
3. 🔴 **A1** Ghép người vào khung có giữ mặt và nhãn không. Thêm: **tạo 5 cảnh liền, mặt có giữ giống nhau không**.
4. 🔴 **C1** VieNeu v3 giọng miền Nam. 🔴 **C2** gwmr bỏ logo. 🔴 **D6** PySceneDetect với video TikTok cắt nhanh.
5. 🟠 Còn lại: A4 (Lite / Pro), A10 (2K), A5 (khớp miệng), A7 (giới hạn Flow), D1 (giới hạn Gemini), D2 (chạy không cần Docker), D5 (faster-whisper tiếng Trung)…

---

## 13. Thứ tự code MVP
1. **Thử thật** mục 12 (bước 1–4).
2. **Khung app:** thanh dọc, sản phẩm, phòng, thư mục, `du-an.json` tự lưu an toàn, phong cách giao diện.
3. **Cài đặt cốt lõi + Màn chào:** thư mục, key Gemini "dán là chạy", bật / tắt động cơ, mã hóa.
4. **Trang chủ:** 4 cột, tùy chỉnh sản phẩm, thả nhiều video, trạng thái thật.
5. **Phân tích:** phần chạy trên máy (PySceneDetect, FFmpeg, faster-whisper, RapidOCR, OpenCV) + Gemini + tự so. Bỏ giới hạn cứng ~8 cảnh của mã cũ.
6. **Sơ đồ tab Tạo video:** các ô, Kịch bản → Giọng đọc (VieNeu, đo giây), bảng chi tiết.
7. **Flow:** tài khoản, hàng chờ, ảnh khung (lưới, duyệt hàng loạt, phóng to, tự kiểm, 2K), Video Veo (lưới, nhận hàng loạt, bỏ logo), **nhập clip tay**.
8. **Tab Dựng:** 4 lỗi → đánh giá mã → vá hoặc viết lại lõi timeline → các mục [MVP] ở mục 8.
9. **Thông báo + Xuất + kiểm tra trước khi xuất.**
10. **Bài tự thử:** mục 8.11 + chạy trọn 1 video từ đầu tới MP4.

---

## 14. Những điều không làm
- Không dùng API Veo trả tiền (trừ khi người dùng đổi ý).
- Không làm giao diện kiểu bảng / danh sách thay cho sơ đồ nối ô ở tab Tạo video.
- Không trang Lịch sử chung, không trang nhật ký lỗi riêng, không bảng phím tắt riêng.
- Không tự đăng TikTok. Không 4K, GIF, khung khác 9:16.
- Không tự chạy lại việc Flow lỗi. Không tự chuyển sang dịch vụ tốn tiền khi chưa hỏi.

---

## 15. Bảng ảnh (`anh/`): chỉ những ảnh này là ảnh chuẩn
| Ảnh | Mục | Ghi chú |
|---|---|---|
| 01-trang-chu.png | 4 | Menu ⋯ sản phẩm, thả 5 video, bảng thả ở "Tất cả", hộp xóa. Mục 📚 Kịch bản trên thanh trái là [B2] |
| 02-hop-video-moi.png | 4.5 | Lựa chọn "Từ ảnh" ẩn ở MVP |
| 03-video-chua-phan-tich.png | 4.4 | |
| 04-tab-tao-video.png | 5 | **Ảnh chính** của tab Tạo video |
| 05-tab-tao-video-phong-to.png | 5.9 | |
| 06-bang-kich-ban-giong-doc.png | 5.5 | Bảng đầy đủ của ô Kịch bản (bản cũ màu, nội dung vẫn đúng) |
| 07-cai-dat-thong-bao-man-chao.png | 7 | |
| 08-cai-dat-giong-thu-muc-xuat.png | 7.1 | |
| 09-quy-trinh-cach-thay-nguoi.png | 5 | Giải thích cách thay người trong 1 cảnh (bản cũ màu) |
| 10-tai-khoan-flow.png | 6.3 | |
| 11-tai-khoan-meta.png | 9.1 | [B2] |
| 12-hang-cho.png | 6.2 | Chỉ lấy ngăn kéo bên phải |
| 13-dung-… → 23-dung-… | 8 | Tab Dựng: thanh công cụ, timeline, âm thanh, khung xem, chỉnh hình, chữ, kho, xuất, bố cục |
| 24-tab-tu-anh.png, 25-clip-muse-loi.png | 9.1 | [B2] |
| 26-kho-kich-ban.png | 9.2 | [B2] |

**Ảnh cũ không dùng nữa:**
- Trang chủ 6 cột.
- Tab Tạo video bản gói 1 (từng ô khung riêng, ô "Ghép").
- Trang chủ bản gói 4.
- Ảnh bỏ logo Veo bản đầy đủ (đã thay bằng bản gọn, không nút).
