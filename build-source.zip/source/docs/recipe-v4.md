# Kho kịch bản v4 — triển khai

Dựa trên đặc tả và bốn ảnh của `SceneForge_KhoKichBan_v4.zip`. Bố cục ba cột dùng khung hiện có, giữ thanh kéo đổi độ rộng, xếp nhóm, kết quả thực tế, lịch sử dùng và thùng rác chung.

- **Thêm → Dán kịch bản**: một ô lớn, tên có thể bỏ trống; chỉ nút Lưu, không gọi AI. Lưu tối đa 120.000 ký tự nguyên văn, không yêu cầu nhịp. Tên tự lấy dòng có lời đầu tiên, bỏ ghi chú cảnh. Sản phẩm là tùy chọn, nhận theo cụm từ trọn vẹn, bỏ chọn được. Có bản nháp trên máy và menu tiếp bản nháp.
- **Kịch bản / Công thức** là hai loại dữ liệu thật trong cùng kho, lọc riêng và tìm được trong lời. Dữ liệu cũ được phân loại khi nâng lên v4; lời đã lưu trước đây được giữ. Bản thùng rác cũng được giữ lời.
- **Mở kịch bản**: Lời, Dùng ở đâu, Chi tiết; sửa lời bằng ô lớn. Dùng cho video mới tạo bản chụp riêng trong phòng ảnh/ý tưởng. Không sửa theo khi bản trong Kho thay đổi hoặc bị xóa.
- **Dùng bản chưa chia nhịp**: app lập kế hoạch từ đoạn/dòng cảnh trên máy, không gọi AI. Lời và ghi chú cảnh tách riêng: ghi chú như `[Cảnh 1 – cận mặt]` đi vào yêu cầu storyboard và prompt cảnh, không đọc thành thoại. Placeholder trong câu như `[sản phẩm]` được giữ, không tự bịa nội dung thay thế. Lời gốc đầy đủ có trong snapshot; tiếng clip là mặc định (`native`). Chưa có ảnh/clip hoặc việc AI nào được gửi chỉ vì dùng kịch bản.
- **Tự chia**: theo dòng trống/dòng cảnh, hiển thị bản xem lại, có vai trò trung tính và cho đổi vai trò. Thời lượng theo số chữ chỉ là ước lượng, không phải mốc giọng thật.
- **Nhờ AI chia**: Gemini theo nguồn trong Cài đặt. Phải xác nhận trước gửi. AI chỉ nhóm mã các đoạn nguồn và gán vai trò/kiểu cảnh; app tự lấy chữ từ nguồn gốc. Kiểm tra đủ mã, đúng thứ tự, không trùng/thiếu, hỗ trợ Unicode/emoji. Xem lại rồi áp dụng; bản gốc không bị thay.
- **Rút công thức**: cần nhịp trước, cho chọn chia trên máy hoặc AI, không tự gọi AI. Tạo bản riêng có liên kết về kịch bản gốc; không chép lời hoặc ghi chú cảnh cụ thể vào công thức mới. Editor công thức tập trung cấu trúc; dữ liệu ví dụ cũ giữ tương thích.
- **Gợi ý chủ đề**: từ khóa chạy trên máy, không tự xếp nhóm. Khi hòa điểm/không khớp thì để chờ xếp nhóm. Không suy "không lời" chỉ từ số chữ ít. Có nhận từng mục/nhận tất cả gợi ý đang lọc. Chỉnh từ khóa trong Cài đặt → Kho kịch bản hoặc nút ở Tổng quan. AI gợi ý riêng, tối đa 8 mục/lượt, chỉ bấm mới gửi.

## An toàn công việc và hạn mức

Bản nháp, nguồn nguyên văn, nhịp tùy chọn và snapshot video tách nhau. Sửa lời xóa nhịp cũ của **bản trong Kho** để tránh lệch offsets; không tác động dự án đã dùng. Không cắt bớt kịch bản dài để vừa giới hạn video: vẫn lưu toàn bộ, báo rõ khi kế hoạch vượt 60 nhịp/10 phút.

Lượt AI giữ input, mã yêu cầu, nguồn và mã kho trước gửi. Nhận lại dùng cùng lượt, chỉ đọc; kết quả đã có được dùng lại. Đổi nguồn/kho, kết quả sai mã hoặc không rõ trạng thái thì chặn thay vì gửi lượt mới. Không tự chuyển từ Chat sang API trả tiền, không gen ảnh/video trong các thao tác Kho. AI chưa được thử bằng tài khoản online thật trong đợt này.

## Kiểm chứng

- `node scripts/shared/check_script_text.cjs`: nguồn nguyên vẹn, CRLF/emoji, lời/chỉ dẫn, placeholder, tên sản phẩm, tài liệu dài.
- `python scripts/app-shell/check_recipe_v4.py`: Chromium + local API/SQLite, dán/lưu, mở phòng thật và kiểm prompt ảnh/video có chỉ dẫn, snapshot riêng, chia trên máy, công thức không lời, bộ lọc, bản nháp, profile mới, thùng rác. AI trên UI dùng response fixture.
- `python -m local_engine.check_script_library`: HTTP thật → adapter Gemini Chat/ledger và SDK fixture; tài khoản được ghim, kiểm mã nhịp, không fallback trả tiền, nhận lại không gửi lại, chặn kho/nguồn khác.
- Các kiểm hồi quy công thức, SQLite, video intake và hợp đồng API cũ được giữ/điều chỉnh cho nút Công thức trống.

Chưa kiểm Windows hoặc gen online. Gói mô phỏng dùng cùng giao diện runtime nhưng chặn truy cập dịch vụ; không phải bản chứng nhận tạo ảnh/video thật.
