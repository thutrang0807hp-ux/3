# Nhập video dùng chung

Trang chủ → Video mới → Từ video mẫu; nút nhập nguồn trong phòng Video mẫu; Kho kịch bản → Thêm → Từ video: cả ba mở một bộ nhập.

- File: MP4/MOV/WebM/M4V, tối đa 500 MB, thời lượng không quá 10 phút. Cho phép video ngang để phân tích; không tự cắt thành video dọc.
- Link: file MP4/WebM/MOV/M4V công khai hoặc trang YouTube/TikTok/Instagram/Facebook/Douyin mà yt-dlp đọc được. Không dùng phiên/cookie đăng nhập, không hỗ trợ DRM, playlist hoặc luồng chỉ có HLS/DASH/âm thanh tách riêng. Chọn luồng có cả hình và tiếng không quá 1080p; nguồn có thể chỉ cung cấp độ phân giải thấp hơn. Nếu không tải được, nhập file từ máy. Không hứa hỗ trợ mọi link.
- Video đã nhập: dùng phòng nguồn và dữ liệu hiện có, không chép thêm nguồn sang sản phẩm khác. Danh sách ghi rõ sản phẩm gốc.

## Video mẫu

Lưu nguồn trước, xếp phân tích CPU bằng luồng hiện có. Gemini không tự gửi khi nhập. Ảnh/clip chỉ chạy qua các bước đang có và tài khoản đã cấu hình.

## Kho kịch bản

Lưu nguồn, dùng lại cảnh đã phân tích; nếu chưa có cảnh thì chạy phân tích trên máy. Không gọi tạo ảnh/clip. Lưu khung mốc cảnh vào Kho và ghi rõ đây chưa phải kết quả hiểu ngữ nghĩa. Không cần điền từng nhịp thủ công.

Nút “AI rút kịch bản” là tùy chọn, phải xác nhận một lần trước gửi. Dùng đúng nguồn Gemini trong Cài đặt (mặc định Chat), không tự chuyển sang API trả tiền. Gửi bản chữ/OCR, các mốc cảnh và tối đa 8 ảnh đại diện, không gửi nguyên video. Ảnh lấy mẫu không chứng minh hành động giữa các khung; lời không có Whisper/model/SRT thì không tự bịa. Mã yêu cầu, nguồn và mã kho được giữ trước gửi; nhận lại dùng cùng nội dung và chế độ chỉ đọc, không tự gửi một lượt mới. Kết quả cập nhật công thức cũ, không tạo thêm một bản mỗi lần nhận.

Đã có semantic recipe được áp dụng thì dùng lại. Công thức đã xóa hoặc người dùng sửa không bị ghi đè bởi bộ rút khung tự động. Khung cũ vẫn giữ nếu AI lỗi.

## Dung lượng và lỗi

Nguồn tải là file tạm. Chỉ bỏ nó sau khi nguồn đã vào IndexedDB và, khi dùng kho quản lý trên ổ, checkpoint được xác nhận ổn định. Tải xong nhưng chưa lưu có thể “Nhận lại” hoặc “Bỏ” trong bộ nhập. Tối đa hai lượt tải đang hoạt động; mỗi lượt tối đa 500 MB, 10 phút chờ tải. Tệp tạm hết hạn sau một giờ khi hệ thống nhập được truy cập lại; lần mở lại động cơ dọn các lượt bị ngắt. Đây không phải lịch xóa dự án hoặc thùng rác.

Link đã nhập được tìm bằng URL key và SHA-256 của file tải. File cục bộ trùng tên/kích thước/ngày sửa chỉ được gợi ý dùng lại, cần người dùng xác nhận; không coi đó là chứng minh hai nội dung giống nhau. Sửa query URL có thể cần tải lại trước khi nhận ra SHA trùng.

Địa chỉ mạng nội bộ, credentials trong URL và chuyển hướng nội bộ bị chặn. Tải trực tiếp pin TCP tới IP công khai đã kiểm, không dùng proxy môi trường. ffprobe chỉ đọc MP4/WebM đã kiểm chữ ký đầu tệp, không đọc playlist qua mạng. yt-dlp chỉ đọc metadata của các nền tảng đã cho phép; dữ liệu media được app tải có giới hạn. Không tự cài model AI.

## Kiểm chứng

`python -m local_engine.check_video_import`: kiểm API, chữ ký media, ffprobe thật, URL nội bộ/chuyển hướng, kích thước, hủy/dọn, dùng lại lượt tải và recovery Gemini chỉ đọc (executor giả lập).

`python scripts/app-shell/check_video_intake.py`: Chromium thật + app local + kho SQLite/IndexedDB, nhập video ngang, phân tích CPU, lưu Kho, dùng lại không nhân bản, nút nhập từ phòng và không có POST gen.

`python -m local_engine.check_gemini_chat_routes`: regression adapter Chat bằng SDK fixture, không gọi API trả tiền.

Chưa kiểm bằng tài khoản online thật, chưa kiểm Windows. Không truy cập được DNS ngoài trong môi trường kiểm hiện tại nên chưa xác minh tải thật từ các nền tảng công khai. yt-dlp đã kiểm phiên bản trong thư mục phụ thuộc thử nghiệm; bản cài trên PC tải thư viện bằng requirements.txt, không kèm tài khoản/model.
