# Ba node Giọng đọc, Nhạc nền, Phụ đề

Áp dụng cho cả Video mẫu và Từ ảnh & ý tưởng. Nội dung node được thay trong khung hiện có; không thêm node hay thay luồng gen. Node co theo nội dung, danh sách chỉ hiện vài dòng đầu; phần dài mở qua bảng riêng. Trạng thái ngắn có màu; không hiển thị giọng/preset giả.

## Giọng đọc

Bốn nguồn: Tiếng clip (mặc định), Giọng AI, Thả file, Không lời. Không lời tắt toàn bộ tiếng clip và giọng riêng, vẫn giữ nhạc nếu bật; không hứa bỏ riêng giọng nhưng giữ SFX của cùng một bản mix. Giọng riêng mặc định tắt tiếng clip, có chọn giữ hoặc hạ còn 15%, kèm nhắc rằng thoại cũ cũng còn.

VieNeu: đọc danh sách preset thật từ `/tts/status`; nghe mẫu là một yêu cầu tạo mẫu trên máy, được lưu lại để nghe lại. Lời từ kịch bản, bỏ ghi chú cảnh theo luồng trước đó. Backend hiện tạo cả batch rồi trả các mốc thật, vì vậy UI không bịa tiến độ 2/6 trong lúc SDK chưa trả kết quả. Khi xong có nghe theo từng dòng có mốc thật. Không cung cấp nút nhân bản giọng vì backend chưa có khả năng này.

Chưa có model: hiện Hướng dẫn cài VieNeu, mở quy trình cài hiện có (`install-voice.bat`) và nút Kiểm tra lại. Không âm thầm chạy trình cài hoặc tải model khi mở node. Chưa có trình tải model nền trực tiếp trong node.

File nhập: đọc metadata thật, giữ nguồn gốc, nghe/waveform khi giải mã được, so tổng độ dài với video. Tốc độ dùng FFmpeg `atempo` trên file gốc; không gọi lại TTS, không đổi mốc cảnh/clip. Mốc giọng được chia theo tỉ lệ tốc độ thật. Giọng dài hơn video phải canh hoặc xác nhận giữ thời lượng (phần dư không vào video).

Đổi lời/preset không âm thầm đổi file đang nghe. Muốn dùng bản cũ thì xác nhận; lời đã được tạo giọng được giữ riêng để phụ đề không lấy nhầm lời mới. File nhập không kế thừa mốc TTS của giọng trước. Dừng nghe thử khi rời phòng.

## Nhạc nền

Tắt / Chọn bài / Tự chọn. Import một hoặc nhiều file/thư mục qua luồng hiện có, kho chuẩn dùng hash nên cùng nội dung không chép nhiều bản vật lý trong kho. Có nghe thử, waveform từ dữ liệu âm thanh khi trình duyệt giải mã được; không vẽ sóng giả khi không đọc được.

Tự chọn chốt bài và lưu; render/nghe/ghép lại không bốc bài mới. Đổi bài khác là hành động riêng và được đưa vào chữ ký bản ghép xem thử.

Âm lượng là thanh kéo. Hạ nhạc dùng FFmpeg sidechain trên giọng riêng thật; với tiếng clip hỗn hợp, nhãn là “Nhỏ lại theo tiếng clip” vì chưa tách thoại khỏi SFX/nhạc gốc. Chưa có nguồn tiếng thì không giả vờ hạ nhạc. File nhạc đã xử lý được dùng chung cho bản ghép xem thử và bàn giao sang Dựng; nghe riêng bài nhạc gốc không có lớp giọng để minh họa ducking.

Cache hiệu ứng tái sử dụng theo hash và tham số. Cache cũ của cùng nguồn/loại được bỏ tham chiếu khi không còn được chọn; file nguồn, giọng người dùng và các bản đã vào Dựng không bị xóa theo cache. File kho vật lý vẫn đi qua cơ chế lưu trữ/lease/dọn hiện có.

## Phụ đề

Bật/tắt, hình khung thật hoặc ảnh tham chiếu (khi chưa có khung), vị trí Trên/Giữa/Dưới + thanh kéo, bốn kiểu chữ có hỗ trợ trong editor: Trắng viền đen, Vàng nền đen, Hộp nền tối, TikTok to. Hiển thị vài dòng đầu, đánh dấu vàng phần sửa riêng.

Nguồn: kịch bản là mốc ước lượng; VieNeu có thể lấy trực tiếp lời và mốc của lần tạo thật; file giọng/tiếng clip lấy qua Whisper local. Không tự dịch, không gửi Gemini khi thiếu Whisper. Kết quả nghe được cần rà và bấm áp dụng. Nếu nguồn/clip/giọng đổi trong lúc chép thì không áp bản cũ.

Sửa chữ/mốc bằng bảng riêng ngay trong workspace, không sửa kịch bản gốc. Lấy lại từ kịch bản hỏi trước khi ghi đè bản riêng. Đổi giọng/tốc độ/clip báo cần rà mốc nhưng giữ nội dung đã sửa; không tự gen lại clip. Có xuất SRT (nội dung + mốc, không chứa kiểu chữ/vị trí). Handoff đưa kiểu chữ và vị trí thật sang editor; bản timeline đã chỉnh vẫn do cơ chế xác nhận nhập hiện có quản lý.

## Kiểm chứng

- `python -m local_engine.check_audio_effects`: FFmpeg thật, đo giảm RMS khi có guide, loop/trim đúng thời lượng, tempo đúng thời lượng, cache, storage, đường dẫn/thông số/phiên không hợp lệ.
- `python scripts/app-shell/check_audio_nodes.py`: Chromium + API/SQLite/FFmpeg thật cho hai luồng. TTS dùng response/WAV fixture, không gọi model thật hoặc AI online. Kiểm bốn nguồn, missing-model, preset, mốc TTS, tốc độ, SRT tải thật, sửa tay được giữ, bài ngẫu nhiên cố định, payload nhạc đã duck và chế độ tắt tiếng.
- Hồi quy `check_reference_voice_ui`, `check_photo_story_production`, `check_storage_voice_api`: giữ đường prompt → ảnh/clip → Dựng và lifecycle giọng cũ.

Chưa kiểm bằng model VieNeu/Whisper thực hoặc Windows trong đợt này. Không coi dữ liệu fixture là bằng chứng giọng thật/chép lời thật đã hoạt động trên PC người dùng.
