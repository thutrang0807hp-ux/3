# Hậu kỳ tab Từ ảnh & ý tưởng

Giọng đọc / Nhạc nền / Phụ đề dùng cùng các node thật của `scripts/shared/audio-nodes.js` với Video mẫu. Không tạo một bộ node giả khác. Bốn nguồn giọng, preset thật, nghe thử, tốc độ, sóng âm; nhạc chọn/tự chọn cố định; phụ đề có xem trước, kiểu chữ/vị trí, bản sửa riêng và SRT. Những giới hạn model/nhân bản giọng trong `audio-nodes.md` giữ nguyên.

Node Sang Dựng mới có dải clip đúng phần, Ghép sẵn/Tự ghép, ba công tắc mang Giọng/Nhạc/Phụ đề, trạng thái đã nhập và bản mới. Công tắc chỉ tác động gói bàn giao, không xóa hoặc thay thiết lập nguồn; nằm trong chữ ký bản xem thử nên đổi lựa chọn sau khi xem sẽ chặn dùng bản xem cũ. Tắt mang giọng tắt cả tiếng clip, không hứa tách thoại khỏi SFX.

Vẫn xem cả bản ghép rồi chốt một lần. Giữ node Bản ghép xem thử; không thêm bước duyệt từng clip. Bản đủ vẫn dùng giao dịch chốt/dọn cũ, có kiểm snapshot. Bản thiếu có đường mở Dựng riêng: giữ đúng start và totalDuration, chỗ thiếu thành ô đen “Thiếu clip” của editor chung. Tự ghép đưa clip vào Kho; nếu chưa có timeline thì có thể đặt giọng/nhạc/phụ đề được chọn. Bản thiếu/Tự ghép không chốt/dọn các clip bỏ.

Clip mới: không tự thay timeline. Nút thay đúng đoạn có xác nhận, dùng bộ thay nguồn theo scene/part của editor chung, giữ start, duration, mediaIn, transform, hiệu ứng, track âm thanh và chữ. Không lấy clip đã stale; giới hạn đủ thời lượng nguồn vẫn được editor kiểm. Để sau giữ nguyên timeline. Thông báo đã sang Dựng chỉ ghi sau ACK thành công; ACK đóng bản xem và giải phóng video/âm thanh. Hủy xác nhận thay toàn timeline trả phản hồi cho node để không kẹt trạng thái chờ.

Sửa một lỗi có sẵn: render photo cũ tải file giọng để gắn vào phần tử `voicePreview` dù phần tử đó đã được thay bằng node mới; khi tệp mất sẽ ném promise rejection mỗi lần render. Giờ chỉ đọc khi phần tử đó còn tồn tại và có bắt lỗi. Không tự xóa key giọng của người dùng.

## Kiểm

- `scripts/app-shell/check_photo_post_design.py`: Chromium/IndexedDB/API/FFmpeg media thật. Không gọi provider gen. Kiểm node chung, ba công tắc không đổi nguồn; bản xem đã đổi bị chặn; ghép thiếu đầu/cuối đủ 12s; không dọn clip khi mở bản thiếu/Tự ghép; đổi nguồn clip giữ X/scale/start/duration; Tự ghép giữ timeline cũ, còn timeline mới nhận lớp phụ đề được chọn.
- `local_engine.check_photo_story_production`: hồi quy storyboard → prompt → clip → chốt toàn bộ → Dựng, provider transport fixture.
- `scripts/app-shell/check_audio_nodes.py`: giọng/nhạc/phụ đề hai luồng, TTS fixture, xử lý FFmpeg thật.
- `scripts/app-shell/check_reference_nodes.py`: luồng Video mẫu vẫn bàn giao, giữ mốc và chỉnh tay.

Chưa kiểm model TTS/Whisper thật, tài khoản AI online thật hoặc Windows. Preview offline dùng clip minh họa có sẵn, không giả là video AI vừa gen.
