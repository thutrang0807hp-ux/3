# Bốn node Video mẫu · thiết kế v2

Phạm vi: Phân tích, Các cảnh, Ảnh tham chiếu, Sang Dựng. Không thay ảnh khung / gallery Veo trong đợt này. Không thay node bên Từ ảnh & ý tưởng. Tái sử dụng động cơ CPU, API phân tích, lịch sử job và editor đang có; không phát sinh gọi gen ảnh/video khi chỉnh các node.

## Phân tích

Hai nhóm đọc video trên máy và hiểu/viết AI. Hiển thị số đo/trạng thái thật; camera là ước lượng từ các khung mẫu, không khẳng định hiểu hành động. Nút dừng nói rõ dừng sau bước hiện tại, không giả vờ động cơ có pause/resume tại mọi thời điểm. Có nhập SRT hoặc chọn chỉ phân tích hình khi thiếu Whisper. Các số đo khác được giữ. AI có kết quả phải rà và áp dụng.

Nguồn chọn tại node là ý định của phòng, phải khớp nguồn đang kết nối trong Cài đặt vì backend hiện chỉ có một tuyến Gemini API/Chat hoạt động. Không tự đổi cấu hình chung và không gửi nhầm nguồn. Có nút mở cài đặt. Ollama mở luồng mô tả cảnh có sẵn, ghi rõ chưa làm đầy đủ prompt/dịch như Gemini. Bước AI có xác nhận gửi, không tự gửi lại lượt chưa rõ. Dòng đã lưu Kho chỉ xuất hiện sau trạng thái lưu thật; không tạo thêm công thức mỗi lần render.

## Các cảnh

Thanh màu theo thời lượng nguồn, thumbnail + mốc + mô tả/nhãn quan sát. Cảnh dài giữ nguyên, liệt kê các phần do bộ chia clip hiện có tạo ra. Không đồng nhất chia cảnh với chia clip gen, không hard-code số clip.

Menu dò CPU với ngưỡng ít/vừa/nhiều, cắt tay theo giây, gộp với cảnh kế. Dò CPU vẫn có màn rà kết quả. Chỉnh mốc tay là giao dịch: kiểm tính liên tục, xác nhận, trích khung cho cảnh đổi, sau cùng mới áp. Cảnh có cùng đầu/cuối giữ ID, prompt, frames, clips và lựa chọn. Bản cũ lưu lịch sử đầy đủ, không đưa vào Thùng rác hoặc xóa bytes. Khôi phục được. Không đổi cấu trúc khi còn job tạo clip chưa đối soát. CPU và dò trình duyệt cũng giữ hàng cảnh trùng mốc và lịch sử.

## Ảnh tham chiếu

Một node 4 vai trò, kéo thả nhiều ảnh; Người 1/2… tách nhóm. Chọn mặt chuẩn, đổi/bỏ ảnh, xem tất cả, mô tả. Ảnh người dùng ở dự án trước lấy từ thư viện dự án có sẵn; không lấy khuôn mặt từ Internet.

Đổi riêng từng cảnh chọn nhóm/người và từng ảnh. Bộ tạo prompt, danh sách file gửi và chữ ký job sử dụng đúng ảnh của cảnh, không toàn bộ nhóm người. Người 2 không làm cảnh Người 1 mất lựa chọn. Cảnh bỏ một vai trò bằng tay không bị tự nối lại khi thêm ảnh nhóm đó. 24 ảnh/nhóm là giới hạn kho nhập, không phải số ảnh gửi: giới hạn 8 ảnh/yêu cầu (kể cả khung nguồn) vẫn được kiểm trước khi gửi. Không tự cắt bỏ ảnh tham chiếu hoặc tự gửi quá giới hạn. Đổi ảnh chỉ đánh dấu lại cảnh bị tác động, không xóa frame/clip cũ và không tự gen.

## Sang Dựng

Dải các phần clip theo thứ tự. Chỉ đưa bản có tệp và đủ điều kiện theo khung/prompt/mốc hiện tại; bản cũ cần rà không được xem như clip hợp lệ. Ghép sẵn / Tự ghép, ba công tắc đem Giọng/Nhạc/Phụ đề riêng với cài đặt node nguồn.

Ghép thiếu: ít nhất 1 clip thật, clip giữ đúng start. Khoảng thiếu dùng ô ảnh đen tên “Thiếu clip” trong timeline để giữ thời lượng cả khi thiếu ở đầu/cuối; không giả là clip đã gen. Tắt đem giọng thì tắt cả tiếng clip vì chưa có tách giọng/SFX. Công tắc giọng không sửa giọng đã lưu.

Kết quả mới không tự chèn timeline. Sau xác nhận, chỉ thay asset của item cùng scene/part (kể cả ô thiếu), giữ start, duration, mediaIn, speed, transform, hiệu ứng, âm thanh/phụ đề và các item khác. Nếu bản mới không đủ dài cho phần đang dùng thì từ chối, không thay một phần rồi lỗi. Các bản vẫn nằm trong Kho. Ghi “Đã sang Dựng” chỉ sau ACK thành công. “Để sau” giữ lựa chọn hiện tại.

## Kiểm chứng

- `python scripts/app-shell/check_reference_nodes.py`: Chromium + app local/IndexedDB/video thật. Lọc ảnh đúng người, không vô hiệu cảnh không liên quan; chia cảnh giữ bản cũ; bản ghép thiếu đầu/cuối đủ 12 giây; công tắc tiếng/phụ đề; chỉnh X/scale qua inspector rồi thay clip giữ nguyên các chỉnh sửa. Không gọi provider gen.
- `python -m local_engine.check_reference_voice_ui`: hồi quy lời/Whisper fixture, prompt → frame approval → video prompt, handoff giọng và nhạc.
- `python scripts/app-shell/check_audio_nodes.py`: hai luồng audio/caption không gãy.
- `python -m local_engine.check_reference_fixes`: hồi quy journal/giữ dung lượng/idempotency.

Chưa gen bằng tài khoản online thật; chưa chạy Windows; không coi fixture là kiểm chứng model thật. Thiết kế v2 còn có các node Ảnh khung/Veo khác, không nằm trong phạm vi lần sửa bốn node này.
