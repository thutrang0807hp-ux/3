# SceneForge 2026.10.29.3 — proxy-frame read failure

The user still reported the exact legacy error “Không đọc được khung proxy.” after the previous update. Their screenshot confirms a paused CPU analysis, but does not establish whether the machine was running the updated worker or which OpenCV seek failed. Do not claim that the previous clamp proved all Windows readers reliable.

This revision removes OpenCV random seeking from the CPU measurement reader altogether. Proxy metadata comes from FFprobe. Original proxy frames are decoded sequentially by bundled FFmpeg as BGR24; OpenCV still computes vision measurements on the decoded pixels. Backward requests restart the owned decoder; repeated requests reuse only the last frame. Memory stays bounded to a few frame buffers, not a whole video. Decoder processes are terminated on rewind, close and errors. Out-of-range tail requests clamp to the metadata frame range. An undecodable interior frame raises a specific FFmpeg v3 frame-index/count error instead of silently substituting a different picture. PySceneDetect retains its existing sequential cut pass.

The main source-node Analyze button explicitly resumes an existing paused same-ID CPU job, including one retained from before this update. It does not loop automatic retries within a run. Completed pre-v3 measurements are refreshed; a paused job is not discarded merely because an older completed result also exists. Original source media, completed checkpoints, speech models, accounts and timeline remain.

Checks: actual user-provided 48-second source through the real application DOM button returns six scenes at 8,16,24,32,40 seconds; injected exact legacy read error pauses after one committed scene and resumes with the same job/source; old checkpoint bytes and timestamp remain unchanged; UI repeat Analyze resumes without a second upload even with older measurements present. The user video itself is not included in the public source archive. See docs/checks/proxy-reader-*.json and *.log.

The updater also retains the earlier standalone-window and Google-login changes. Real Google account authentication and online generation remain unverified.
