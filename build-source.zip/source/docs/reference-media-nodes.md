# Ảnh khung và Video Veo · giao diện gọn

Chỉ áp dụng **Từ video mẫu** (`workflow.html`). Không thêm hai node này vào **Từ ảnh & ý tưởng**, không đổi cách chốt cả bản ghép bên ảnh.

## Lưới

Bỏ chip đếm/tab dư và nút Chia clip ở node Video Veo. Tóm tắt số thật trên tiêu đề, không ghi loại có số 0. Trạng thái tách Xong/chờ duyệt, Đã duyệt, Cần xem, Lỗi tạo, Chưa rõ, Đang tạo, Chờ và Chờ khung. Chỉ hiện % khi job có số tiến độ thật; vị trí chờ không bịa.

Clip a/b của cùng cảnh nằm trong cùng nhóm. Nhiều ô nhỏ lại, giới hạn khoảng 3 hàng rồi cuộn lưới; nút đáy không cuộn theo. Cần xem chứa bản mới chưa duyệt/cảnh báo/lỗi/chưa rõ, không chứa bản đã duyệt. Phần chưa rõ hoặc JSON/file chưa đối soát không có nút gửi lại trực tiếp.

Nút duyệt chỉ đếm các bản xong chưa duyệt; tạo lại chỉ gửi đúng slot lỗi. Một phần lỗi không gửi lại phần đã đạt cùng cảnh. Khi có nhiều nguồn cũ thì chọn từng nhóm, không tự đổi nguồn. Việc gửi vẫn qua màn rà tài khoản/số yêu cầu rồi nút Gửi, giữ journal và snapshot guards trước đó.

## Chi tiết

Hai cột: hình/video trái, prompt phải; không có Lite/Pro hay công tắc xử lý logo trong màn này. Ảnh có thanh kéo so nguồn/kết quả và giữ Space xem gốc (không chiếm Space khi đang gõ prompt). Video dùng điều khiển thật, tốc độ 0.5×/1×, lặp. Mốc trên tiêu đề là đúng phần clip, không lấy cả cảnh dài.

Prompt là **chuỗi thực sự gửi đi**, sửa trực tiếp, chép nguyên nội dung. Không chỉ sửa một bản tóm tắt rồi gửi prompt khác. Tô tên tham chiếu bằng lớp hiển thị đã escape phía dưới textarea; không nhận HTML người dùng. Prompt ảnh/video sửa ở cảnh/phần nào chỉ thay override của cảnh/phần đó. Clip hiện có không bị xóa; nội dung đổi cần bản khớp mới hoặc rà lại khung. Chữ chưa chia theo ranh giới clip vẫn phải xử lý, không dùng prompt override để bỏ safeguard lời.

Mặc định bản mới nhất. Các bản trước thu gọn, chỉ xem, không âm thầm đổi ứng viên/duyệt bản khác. Có điều hướng giữa các ô và xem video mẫu. Bản cũ hiển thị prompt đã ghi trong receipt nếu có. Enter duyệt ở ngoài ô soạn thảo; Space nhập chữ bình thường trong prompt.

Gợi ý sửa chỉ là quy tắc từ cảnh báo đã có, không gọi AI. Có nút Thêm vào prompt / Bỏ câu đã thêm. Không tự chèn, không tự gen, không tự nhận “mặt đổi lúc 0:05”.

## Kiểm và duyệt

Kích thước từ metadata tệp thật; nét/nhãn chỉ hiện số đo khi có báo cáo. Mặt/logo chưa kiểm thì ghi chưa kiểm, không tích xanh. Có Kiểm ảnh trên máy trong menu; nếu thiếu OpenCV thì báo rõ, không biến lỗi kiểm thành Đạt. Duyệt hàng loạt giữ kiểm chất lượng, không tự bỏ cảnh báo. “Vẫn duyệt” là xác nhận thủ công có dấu vết gắn frame ID/hash, prompt, ảnh tham chiếu và nhãn; số đo vẫn giữ nguyên. Không cho duyệt lượt đang tạo, lỗi gửi/không có kết quả hay lượt cần đối soát. Clip khác mốc/prompt/khung hoặc thiếu thời lượng không được bỏ qua bằng nút Vẫn duyệt.

Duyệt dùng giao dịch approval/cleanup hiện có. Chỉ thao tác duyệt mới dọn bản cũ theo lifecycle; mở/chuyển bản/xem không dọn. Duyệt khung nguồn không giả có một phiên bản vừa gen.

## Model, giá và logo

Engine ảnh hiện dùng Gemini Chat và chưa có lựa chọn Lite/Pro được adapter xác minh, vì vậy không dựng nút Lite/Pro giả. Không có bộ tự xóa logo ảnh đã xác minh; không có công tắc giả cho ảnh. Video đọc danh sách model dọc thật từ Flow; lựa chọn chỉ áp dụng lượt gửi mới, không làm mất clip cũ. Chưa xác minh giá thì ghi rõ; số tự nhập được gọi là ước tính, không gắn cứng 10/20/100 và không tính “đã trừ” từ số yêu cầu.

Công tắc logo **clip** dùng bộ xử lý bản sao hiện có, lưu lựa chọn theo phòng; không hứa xóa được mọi logo. Không đổi thiết lập của tab ảnh tĩnh.

## Kiểm chứng

- `python scripts/app-shell/check_media_nodes.py`: Chromium, API local/SQLite, PNG 1080×1920/video thật; provider transport fixture. Kiểm nhóm phần, bộ lọc, so ảnh/Space, prompt gửi đúng chuỗi, thêm/giữ bản mới, duyệt thủ công, retry một phần giữ phần kia, không gửi lại lượt chưa rõ, playback và lịch sử chỉ xem. Runner hiện thiếu OpenCV; đã kiểm nhánh báo thiếu và metadata file thật, **chưa chạy phép đo nét/OCR thật** trong test này.
- `python -m local_engine.check_direct_workflow`: hồi quy receipt đúng cảnh/part/tài khoản, WebP, không tự duyệt hay gửi lặp, đổi tài khoản bị chặn.
- `python scripts/app-shell/check_reference_nodes.py`: chia cảnh, ảnh tham chiếu, ghép thiếu, thay clip giữ chỉnh timeline không gãy.

Chưa gen bằng tài khoản online thật hoặc chạy Windows. Không coi file fixture là bằng chứng chất lượng mô hình AI.
