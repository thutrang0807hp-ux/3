# SceneForge 2026.10.29.4 — ordinary-browser session connection

Problem: Google rejects sign-in windows opened by the application's automation/debugging flow, while the user can sign in normally in their personal browser. Default Gemini Chat and Flow connection now uses an explicitly invoked Manifest V3 extension in that ordinary browser. No proxy, new login window, CAPTCHA handling, automation flags, default API-key fallback or automated extension installation is added.

## User flow

The update includes scripts/browser-extension/ with manifest.json and the popup, plus a source-only ZIP. In Settings → Accounts → Gemini Chat or Flow → Connect, the app shows first-install instructions and the installed extension-folder path. User loads that folder through chrome://extensions or edge://extensions once. The app can open only its own extension folder on an explicit click.

User signs into Gemini/Flow normally in that browser, issues a pairing code in SceneForge, opens the extension popup, enters that eight-digit code and clicks Connect. The extension reads only the cookie URLs corresponding to the service bound to the app's code and sends them to 127.0.0.1 at the app's displayed port. It does not read passwords, access personal profile files, execute content scripts, run in background or persist cookies. Session checking is routed through the existing provider adapter; account identity and encrypted vault remain unchanged. Receipt of a session is not proof of content generation/quota.

## Boundary

App-side setup, issue, status and cancel require the existing HttpOnly app session and local-action header. Only /local-api/browser-bridge/claim and /complete bypass that cookie requirement; they require a loopback Host, exact fixed extension Origin, protocol header, a valid user-issued code, short expiry and single-use submission capability. External web pages and the extension cannot use this boundary to call other local APIs. Codes are kept only in memory, expire after three minutes and are cancelled when the user closes an unsubmitted dialog. Rate limiting bounds invalid attempts. Incoming bodies are bounded even without Content-Length. Cookie domains are validated against the source before invoking the adapter.

The extension has cookie permissions for Google root/Gemini/Google Labs and network access only to loopback in its connection code. No remote server receives session data from the extension. Provider verification is the existing explicitly requested service check. Cookies are neither sent back in status responses nor logged. SDK errors are replaced with a generic non-secret message. New connections do not overwrite prior verified credentials if their check fails.

## Build and verification

python scripts/build_browser_extension.py generates a deterministic ZIP; build_patch.py installs the folder and ZIP alongside the bridge backend and rebuilt frontend. Normal Chrome/Edge needs one-time user installation; this is not a Chrome Web Store release.

check_browser_bridge_api exercises the actual authenticated app routes and encrypted vault using a fixture SDK. check_browser_bridge loads the real unpacked extension into a test-only Chrome profile with synthetic cookies and exercises real chrome.cookies permission, real extension fetch/Origin, application pairing and cancellation UI, scoped Flow transfer, one-use/expiry/replay/body-size guards and absence of secret values in status/logs. It never signs into or generates against a real Google account. A separate Chrome for Testing is used on CI because the development environment's managed Chromium blocks all unpacked extensions. It is test infrastructure only and is not included in the customer updater.

Real account sign-in happens entirely in the user's existing browser. Real Google session verification and actual image/video generation still require a user-account trial; passing synthetic-cookie transport tests must not be described as verified production generation.
