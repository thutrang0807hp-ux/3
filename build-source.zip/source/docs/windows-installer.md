# SceneForge · bộ cài Windows x64 v2

Bộ cài `SceneForge-Setup-Windows-x64-v2.exe` (2026.10.28.2) hiện bảng chọn ba thư mục trước khi giải nén: phần mềm, dữ liệu/dự án/model và cache/tệp tạm. Có thể chọn ổ khác nhau. Không yêu cầu Python hệ thống hoặc quyền quản trị; thư mục được chọn phải ghi được. Payload và thư mục giải nén tạm nằm tại thư mục phần mềm đã chọn, không giải nén toàn bộ vào C:\Temp.

Nếu tìm thấy thư viện cũ, bộ cài đề xuất giữ thư viện đó. Chọn thư mục dữ liệu mới tạo một thư viện riêng, không tự chuyển hoặc xóa thư viện cũ. Khi nâng cấp/cài lại, bộ cài đọc lại lựa chọn trước và không ghi đè một thư mục phiên bản khác checksum.

## Thành phần

Gói đầy đủ có Python 3.12.16 Windows x64, core/CPU dependencies, FFmpeg/ffprobe, Whisper base và nguồn SDK được ghim revision cùng các wheel Gemini/Flow. Bộ cài chuẩn bị Gemini và Flow mặc định rồi chạy kiểm tra trước khi tạo shortcut và báo hoàn tất. Không đăng nhập, không gửi yêu cầu tạo ảnh/video trong quá trình cài. Khi mở ứng dụng, người dùng đăng nhập tài khoản của mình. Cần Chrome hoặc Edge đã cài cho cửa sổ tài khoản.

VieNeu là tùy chọn tải thêm: chọn lúc cài hoặc mở `SceneForge-Tools.exe` sau này; cần mạng, dung lượng/model riêng. Không xem tùy chọn này là đã có sẵn trong bộ cài mặc định. Công cụ sửa/cài thêm không yêu cầu người dùng gõ lệnh. Nút cập nhật mở trang tải chính thức, không phải cập nhật âm thầm.

Giao diện chạy trên trình duyệt, server chỉ loopback. Giữ cửa sổ console SceneForge khi dùng; đóng cửa sổ sẽ dừng tiến trình ứng dụng và engine con do app quản lý. Khởi động bình thường không cài pip hoặc tải model. `install-settings.json` trong thư mục phiên bản quyết định nơi lưu; biến môi trường cache/temp của tiến trình cũng theo lựa chọn đó.

## Gỡ và dữ liệu

Gỡ qua Windows Settings → Apps, shortcut Gỡ SceneForge, hoặc `SceneForge-Uninstall.exe`. Mặc định giữ dự án, tài khoản, model và cache. Tùy chọn xóa dữ liệu cần xác nhận riêng và chỉ bật nếu thư mục do lần cài này tạo. Không tự xóa thư viện đã tồn tại trước. Chỉ xóa các phiên bản có marker sở hữu đúng thư mục cài, shortcut/registry đúng app. Có thể cài lại và chọn thư mục dữ liệu đã giữ.

## Dựng và kiểm

Nguồn nằm trong `scripts/windows-installer/`. Trên Windows Python 3.12, cài core/CPU requirements, `ziglang`, `packaging`; chạy `fetch_resources.py --output build-resources --core-wheels build-wheels`, tải CPython archive đúng SHA trong `build.py`, rồi:

```sh
python scripts/windows-installer/build.py --python-tar python.tar.gz --wheels build-wheels --resources build-resources --zig-python PYTHON_CO_ZIGLANG
```

`BUNDLED-COMPONENTS.json` ghi hash Python/wheels, resources manifest ghi nguồn/hash model, FFmpeg và revision SDK. Giữ giấy phép đi kèm, nguồn SDK đầy đủ và liên kết nguồn/build FFmpeg. Chưa có chữ ký Authenticode.

`build-report.json` chỉ xác nhận dựng/kiểm dependency/CRC/PE. Kiểm Windows thật dùng `check_full_windows.ps1`: điều khiển bảng chọn thư mục thật trên ổ khác với đường dẫn Unicode/khoảng trắng; chuẩn bị SDK; chạy Chrome và hai canvas; chép lời tiếng nói thật với Whisper; xuất MP4 H264/AAC; mở lại; cài lại; gỡ giữ dữ liệu. Các kiểm SDK dùng fixture, không chứng nhận chất lượng tạo ảnh/video qua tài khoản online. Kết quả phát hành phải kèm báo cáo Windows đạt, không dùng báo cáo v1 để xác nhận v2.

Kho kịch bản v5 vẫn tạm hoãn.
