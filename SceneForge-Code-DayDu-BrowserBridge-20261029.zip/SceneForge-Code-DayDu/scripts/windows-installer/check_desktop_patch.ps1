﻿param([string]$Installer,[string]$Patch)
$ErrorActionPreference='Stop'
$base='D:\SF-desktop-'+[guid]::NewGuid().ToString('N').Substring(0,8)+'-ệ'
[void][IO.Directory]::CreateDirectory($base)
$install=Join-Path $base 'Ứng dụng';$data=Join-Path $base 'Dự án';$cache=Join-Path $base 'Cache';$release=Join-Path $install 'releases\2026.10.28.2'
$env:SCENEFORGE_NO_BROWSER='1'
$report=@{passed=$false;baseline='2026.10.28.2';data=$data;install=$release;checks=@()};$app=$null;$oldApp=$null
function RunNative($exe,$limit=600000){$p=Start-Process -FilePath $exe -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $base ([guid]::NewGuid().ToString('N')+'.log')) -RedirectStandardError (Join-Path $base ([guid]::NewGuid().ToString('N')+'.err'));$null=$p.Handle;if(!$p.WaitForExit($limit)){taskkill /PID $p.Id /T /F|Out-Null;throw 'Process timeout'};if($null-ne $p.ExitCode-and$p.ExitCode-ne 0){throw ('Process failed: '+$p.ExitCode)};return $p}
try{
 $env:SCENEFORGE_INSTALL_TEST='1';$plan=Join-Path $base 'install.json';@{install_root=$install;data_directory=$data;cache_directory=$cache;voice=$false}|ConvertTo-Json|Set-Content $plan -Encoding UTF8;$env:SCENEFORGE_INSTALL_PLAN=$plan
 $null=RunNative $Installer;Remove-Item Env:\SCENEFORGE_INSTALL_PLAN
 $model=Join-Path $data 'models\faster-whisper\model.bin';$modelHash=(Get-FileHash $model).Hash
 $sentinel=Join-Path $data 'project-keep.txt';'USER PROJECT MUST STAY'|Set-Content $sentinel
 $oldApp=Start-Process (Join-Path $release 'SceneForge.exe') -WindowStyle Hidden -PassThru;$null=$oldApp.Handle
 for($i=0;$i-lt60;$i++){if(Test-Path (Join-Path $data 'instance.json')){break};Start-Sleep -Milliseconds 250}
 $env:SCENEFORGE_UPDATE_TEST='1';$env:SCENEFORGE_UPDATE_TARGET=$release;$env:SCENEFORGE_UPDATE_RESULT=Join-Path $base 'update-result.json'
 $null=RunNative $Patch
 if(!$oldApp.HasExited){throw 'Updater did not stop the old application before replacement'};$oldApp=$null
 $report.checks+='update closes the running v2 app safely before replacing application files'
 $updated=Get-Content $env:SCENEFORGE_UPDATE_RESULT -Raw -Encoding UTF8|ConvertFrom-Json;if(!$updated.passed){throw $updated.error}
 if((Get-FileHash $model).Hash-ne$modelHash-or(Get-Content $sentinel)-ne'USER PROJECT MUST STAY'){throw 'Update changed model or user project'}
 $report.checks+='small native updater applies to v2 without reinstalling Python/models; project sentinel and model hash preserved'
 $python=Join-Path $release 'runtime\python.exe'
 $runtime=Join-Path $release 'MicrosoftEdgeWebview2Setup.exe'
 $check=Start-Process (Join-Path $release 'SceneForge.exe') -ArgumentList '--check-runtime' -PassThru -Wait
 if($check.ExitCode-ne 0){$setup=Start-Process $runtime -ArgumentList '/silent /install' -PassThru -Wait;if($setup.ExitCode-ne 0){throw 'WebView2 runtime installation failed'}}
 $env:SCENEFORGE_DESKTOP_TEST_PORT='9821';$env:SCENEFORGE_NO_BROWSER='1'
 $app=Start-Process (Join-Path $release 'SceneForge.exe') -PassThru;$null=$app.Handle
 $state=$null
 for($i=0;$i-lt150;$i++){Start-Sleep -Seconds 1;$file=Join-Path $data 'desktop-state.json';if(Test-Path $file){try{$state=Get-Content $file -Raw -Encoding UTF8|ConvertFrom-Json;if($state.phase-eq'ready'){break};if($state.phase-eq'error'){throw ('Native app startup error: '+(Get-Content (Join-Path $data 'desktop-startup.log') -Raw -Encoding UTF8))}}catch{if($_.Exception.Message-like'Native app startup error:*'){throw}}};if($app.HasExited){throw 'Native host exited unexpectedly'}}
 if(!$state-or$state.phase-ne'ready'){throw ('Native host not ready: '+(Get-Content (Join-Path $data 'desktop-startup.log') -Raw -Encoding UTF8 -ErrorAction SilentlyContinue))}
 $report.checks+='native WinForms/WebView2 window starts the backend without external browser/console'
 $backend=[int]$state.backend_pid
 $wav=Join-Path $data 'speech.wav';$speaker=New-Object -ComObject SAPI.SpVoice;$stream=New-Object -ComObject SAPI.SpFileStream;$stream.Open($wav,3);$speaker.AudioOutputStream=$stream;[void]$speaker.Speak('This is a SceneForge test. We are checking speech recognition and video export.');$stream.Close()
 $ui=Join-Path $base 'desktop-ui.json';$ErrorActionPreference='Continue';$text=& $python -E -s -X utf8 "$PSScriptRoot\check_desktop_ui.py" (Join-Path $release 'app') $data 9821 $wav $ui 2>&1|Out-String;$code=$LASTEXITCODE;$ErrorActionPreference='Stop'
 if($code-ne 0){throw ('Native UI check failed: '+$text)};$report.ui=Get-Content $ui -Raw -Encoding UTF8|ConvertFrom-Json
 # Run the real extension using bundled Chromium and the installed bridge module.
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot '..\..\local_engine\check_browser_bridge.py') -Destination (Join-Path $release 'app\local_engine\check_browser_bridge.py')
 $env:PLAYWRIGHT_BROWSERS_PATH=Join-Path $cache 'browsers'
 Push-Location (Join-Path $release 'app')
 $ErrorActionPreference='Continue'
 try{$bridgeText=& $python -E -s -X utf8 -m local_engine.check_browser_bridge 2>&1|Out-String;$bridgeCode=$LASTEXITCODE}finally{$ErrorActionPreference='Stop';Pop-Location}
 if($bridgeCode-ne 0){throw ('Extension connection check failed: '+$bridgeText)}
 $report.extension=$bridgeText
 $report.checks+='real unpacked extension transfers synthetic browser session to installed app; encrypted vault and origin/expiry/replay guards; no real account or generation'
 $second=Start-Process (Join-Path $release 'SceneForge.exe') -PassThru -Wait;if($second.ExitCode-ne 0){throw 'Second desktop launch failed'};$report.checks+='second launch focuses the existing app'
 [void]$app.CloseMainWindow();if(!$app.WaitForExit(20000)){throw 'Closing native window did not close app'};$app=$null
 for($i=0;$i-lt50;$i++){if(!(Get-Process -Id $backend -ErrorAction SilentlyContinue)){break};Start-Sleep -Milliseconds 200}
 if(Get-Process -Id $backend -ErrorAction SilentlyContinue){throw 'Backend kept running after window closed'}
 $report.checks+='closing native window stops owned backend and worker processes'
 $registration=Get-Content (Join-Path $release 'registration.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $env:SCENEFORGE_UNINSTALL_TEST='1';$env:SCENEFORGE_UNINSTALL_RESULT=Join-Path $base 'uninstall.json';$null=RunNative (Join-Path $release 'SceneForge-Uninstall.exe') 60000
 for($i=0;$i-lt100;$i++){if(Test-Path $env:SCENEFORGE_UNINSTALL_RESULT){break};Start-Sleep -Milliseconds 300}
 if(Test-Path $release){throw 'Uninstall did not remove patched application'}
 if(!(Test-Path $sentinel)-or!(Test-Path (Join-Path $data 'desktop-export.mp4'))-or(Test-Path $registration.registry_key)){throw 'Uninstall lost project/export or left its Windows entry'}
 $report.checks+='uninstall after small patch keeps projects, exported MP4 and models'
 $report.passed=$true
}catch{$report.error=$_.Exception.Message;$report.line=$_.InvocationInfo.ScriptLineNumber;throw}
finally{if($oldApp-and!$oldApp.HasExited){taskkill /PID $oldApp.Id /T /F|Out-Null};if($app-and!$app.HasExited){taskkill /PID $app.Id /T /F|Out-Null};$report|ConvertTo-Json -Depth 14|Set-Content desktop-patch-check.json -Encoding UTF8}
