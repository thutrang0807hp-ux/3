SceneForge — Kết nối phiên trình duyệt

Cài một lần trên Chrome hoặc Edge đang đăng nhập tài khoản của bạn:
1. Chrome: mở chrome://extensions — Edge: mở edge://extensions.
2. Bật Chế độ nhà phát triển (Developer mode).
3. Bấm Tải tiện ích đã giải nén (Load unpacked).
4. Chọn thư mục có manifest.json này. Nếu tải ZIP thì giải nén trước.
5. Có thể ghim tiện ích SceneForge vào thanh công cụ.

Kết nối:
1. Đăng nhập Gemini/Flow trong trình duyệt bình thường này.
2. Trong SceneForge → Tài khoản → nguồn muốn nối → Kết nối → Tạo mã.
3. Bấm tiện ích SceneForge, nhập mã 8 số. Giữ cổng 8840 hoặc nhập cổng app ghi cạnh mã.
4. Bấm Kết nối, quay lại app xem kết quả kiểm tra phiên.

Không cần proxy. Không nhập mật khẩu vào SceneForge. Tiện ích chỉ đọc cookie
của nguồn được ghép đôi khi bạn bấm nút, và chỉ gửi về 127.0.0.1 trên máy.
Không có mã chạy nền, content script, máy chủ bên ngoài hoặc chức năng tự đọc
phiên định kỳ. Không lưu cookie vào storage của tiện ích.

App phải đang mở. Mã dùng một lần, hết hạn sau 3 phút. Nếu đóng app hoặc mã
đã dùng/hết hạn, kiểm tra mục Tài khoản trong app rồi tạo mã khác khi cần.

Nhận/kiểm tra phiên không chứng minh được quota hay tạo ảnh/video thành công.
Cần thử tạo thật bằng tài khoản của bạn sau khi kết nối. Tiện ích này chưa phát
hành trên cửa hàng Chrome; việc nạp thư mục lần đầu cần bạn thao tác.
