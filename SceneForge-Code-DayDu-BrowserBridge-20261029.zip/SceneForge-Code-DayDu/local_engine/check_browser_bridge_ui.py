"""Pairing dialog survives queued close events; closing explicitly revokes its code."""
import os
from pathlib import Path
import re
import socket
import tempfile
from threading import Thread
import time
import urllib.request
import uvicorn
from playwright.sync_api import sync_playwright,expect


def main():
    with tempfile.TemporaryDirectory(prefix='sf-bridge-ui-')as data:
        os.environ['SCENEFORGE_LOCAL_DATA']=data
        from . import server
        async def runner(body):raise AssertionError('No session transferred in UI-only test')
        server.GEMINI_CHAT.runner=runner
        with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        host=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'))
        thread=Thread(target=host.run,daemon=True);thread.start();base='http://127.0.0.1:'+str(port)
        try:
            for _ in range(100):
                try:urllib.request.urlopen(base+'/local-api/health',timeout=.3);break
                except OSError:time.sleep(.1)
            with sync_playwright()as pw:
                browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active')
                page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close()}")
                for source in ['gemini_chat','flow','gemini_chat']:
                    page.evaluate('(source)=>accountScreen(source)',source)
                    page.locator('#connectAccount').click();page.locator('#bridgeCreate').click()
                    expect(page.locator('#bridgeCode')).to_have_value(re.compile(r'^\d{8}$'),timeout=10000)
                    code=page.locator('#bridgeCode').input_value();pair=next(p for p in server.BROWSER_BRIDGE.pairs.values()if p['code']==code)
                    assert pair['state']=='issued'and pair['service']==source,pair
                    page.locator('#bridgeBack').click()
                    for _ in range(50):
                        if pair['state']=='cancelled':break
                        time.sleep(.05)
                    assert pair['state']=='cancelled'
                assert not errors,errors
                browser.close()
            print('PASS actual app Gemini/Flow pairing dialogs issue usable codes despite queued old-dialog close events; back revokes each code; no SDK/provider calls.')
        finally:
            host.should_exit=True;thread.join(timeout=15)
            for handler in list(server.RUNTIME_LOG.handlers):handler.close();server.RUNTIME_LOG.removeHandler(handler)
            server.LIBRARY._root_guard.instance.close()


if __name__=='__main__':main()
