"""User-issued, expiring pairing between the app and its installed extension.

Only the extension's two exchange paths bypass the normal app-cookie boundary.
Each exchange still needs a loopback host, exact extension Origin, protocol
header and a one-use code issued through an authenticated app action.
"""
import asyncio
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import time

from fastapi import HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse

EXCHANGE = {'/local-api/browser-bridge/claim', '/local-api/browser-bridge/complete'}


class BrowserBridge:
    def __init__(self, app, gemini, flow):
        self.gemini, self.flow = gemini, flow
        self.root = Path(__file__).resolve().parents[1]/'scripts/browser-extension'
        manifest = json.loads((self.root/'manifest.json').read_text())
        digest = hashlib.sha256(base64.b64decode(manifest['key'])).hexdigest()[:32]
        self.extension_id = ''.join(chr(ord('a')+int(c,16)) for c in digest)
        self.origin = 'chrome-extension://'+self.extension_id
        self.pairs = {}
        self.tasks = set()
        self.bad_attempts = []
        self.install(app)

    async def extension_request(self, request, call_next):
        from urllib.parse import urlsplit
        try:
            authority = urlsplit('//'+request.headers.get('host',''));host = authority.hostname
            if authority.username or authority.password:host=None
        except ValueError:
            host = None
        origin = request.headers.get('origin')
        if host not in {'127.0.0.1','localhost','testserver'} or origin != self.origin:
            return JSONResponse({'detail':'Nguồn tiện ích không được phép.'},403)
        headers = {'Access-Control-Allow-Origin':self.origin, 'Vary':'Origin',
                   'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff'}
        if request.method == 'OPTIONS':
            requested = {h.strip().lower() for h in request.headers.get('access-control-request-headers','').split(',') if h.strip()}
            if request.headers.get('access-control-request-method') != 'POST' or not requested <= {'content-type','x-sceneforge-bridge'}:
                return JSONResponse({'detail':'Preflight không hợp lệ.'},403,headers=headers)
            headers.update({'Access-Control-Allow-Methods':'POST','Access-Control-Allow-Headers':'Content-Type, X-SceneForge-Bridge','Access-Control-Allow-Private-Network':'true'})
            return JSONResponse({'ok':True},headers=headers)
        if request.method != 'POST' or request.headers.get('x-sceneforge-bridge') != '1':
            return JSONResponse({'detail':'Yêu cầu tiện ích không hợp lệ.'},403,headers=headers)
        # Bound even a chunked request; never trust Content-Length alone.
        body = bytearray()
        async for part in request.stream():
            body.extend(part)
            if len(body)>128*1024:
                return JSONResponse({'detail':'Phiên quá lớn; chưa nhận.'},413,headers=headers)
        request._body = bytes(body)
        # BaseHTTPMiddleware forwards the cached body via Request.wrapped_receive.
        response = await call_next(request)
        for k,v in headers.items():response.headers[k]=v
        return response

    def prune(self):
        now=time.time()
        self.pairs={k:p for k,p in self.pairs.items() if p['state']=='checking' or p['expires_at']+600>now}

    def find_code(self, value):
        now=time.time()
        self.bad_attempts=[t for t in self.bad_attempts if now-t<60]
        if len(self.bad_attempts)>=20:raise HTTPException(429,'Nhập sai nhiều lần; chờ một phút rồi thử lại.')
        if not isinstance(value,str) or not re.fullmatch(r'\d{8}',value):
            self.bad_attempts.append(now);raise HTTPException(400,'Mã gồm 8 chữ số trong SceneForge.')
        for p in self.pairs.values():
            if secrets.compare_digest(p['code'],value):
                if p['expires_at']<now:raise HTTPException(410,'Mã đã hết hạn. Tạo mã mới trong SceneForge.')
                return p
        self.bad_attempts.append(now)
        raise HTTPException(404,'Mã không đúng hoặc app đã khởi động lại. Tạo mã mới trong SceneForge.')

    def public(self,p):
        return {k:p.get(k) for k in ('id','service','name','state','expires_at','message','account_id')}

    async def finish(self,p,cookies):
        try:
            if p['service']=='gemini_chat':
                result=await self.gemini.import_session(p['name'],cookies)
                p['account_id']=result['id']
            else:
                await self.flow.import_session(cookies)
            p.update(state='done',message='Đã nhận phiên vào app. Xem trạng thái trong Tài khoản; chưa chứng nhận tạo nội dung hoặc hạn mức.')
        except asyncio.CancelledError:
            p.update(state='failed',message='App đã dừng lúc kiểm tra phiên. Mở lại mục Tài khoản để kiểm tra kết quả.')
            raise
        except Exception:
            # Provider exceptions may contain session information; do not expose them.
            p.update(state='failed',message='Chưa xác minh được phiên với dịch vụ. Giữ nguyên tài khoản cũ; kiểm tra Gemini/Flow trong trình duyệt rồi kết nối lại.')

    async def close(self):
        for task in list(self.tasks):task.cancel()
        if self.tasks:await asyncio.gather(*self.tasks,return_exceptions=True)
        self.pairs.clear()

    def install(self,app):
        @app.get('/local-api/browser-bridge/setup')
        async def setup():
            return {'extension_id':self.extension_id,'folder':str(self.root), 'download':'/local-api/browser-bridge/extension.zip','protocol':1}

        @app.get('/local-api/browser-bridge/extension.zip')
        async def extension_zip():
            return FileResponse(self.root.parent/'browser-extension-package.zip',filename='SceneForge-Browser-Connect.zip',media_type='application/zip')

        @app.post('/local-api/browser-bridge/open-folder')
        async def folder():
            if os.name!='nt':raise HTTPException(409,'Sao chép đường dẫn tiện ích vào hộp chọn thư mục của trình duyệt.')
            os.startfile(self.root)
            return {'opened':True}

        @app.post('/local-api/browser-bridge/pairs')
        async def issue(body:dict):
            service=body.get('service');name=body.get('name','').strip() if isinstance(body.get('name'),str) else ''
            if service not in {'gemini_chat','flow'} or not 1<=len(name)<=80:raise HTTPException(400,'Chọn nguồn và nhập tên tài khoản 1–80 ký tự.')
            if service=='gemini_chat':self.gemini.require_sdk()
            self.prune()
            if sum(p['state'] in {'issued','claimed','checking'} and p['expires_at']>time.time() for p in self.pairs.values())>=8:
                raise HTTPException(409,'Có nhiều mã đang chờ. Đóng các kết nối cũ hoặc chờ mã hết hạn.')
            code=str(secrets.randbelow(100_000_000)).zfill(8)
            while any(p['code']==code for p in self.pairs.values()):code=str(secrets.randbelow(100_000_000)).zfill(8)
            p={'id':secrets.token_urlsafe(20),'code':code,'service':service,'name':name,'state':'issued','expires_at':time.time()+180,'message':'Nhập mã này trong tiện ích SceneForge ở trình duyệt đang đăng nhập.'}
            self.pairs[p['id']]=p
            return {**self.public(p),'code':code}

        @app.get('/local-api/browser-bridge/pairs/{id}')
        async def status(id:str):
            p=self.pairs.get(id)
            if not p:raise HTTPException(404,'Mã không còn; làm mới mục Tài khoản trước khi tạo mã khác.')
            value=self.public(p)
            if p['state'] in {'issued','claimed'} and p['expires_at']<time.time():value.update(state='expired',message='Mã hết hạn. Tạo mã mới.')
            return value

        @app.post('/local-api/browser-bridge/pairs/{id}/cancel')
        async def cancel(id:str):
            p=self.pairs.get(id)
            if p and p['state'] in {'issued','claimed'}:p.update(state='cancelled',message='Đã hủy mã.');p['code']=''
            return {'ok':True}

        @app.post('/local-api/browser-bridge/claim')
        async def claim(body:dict):
            p=self.find_code(body.get('code'))
            if p['state']!='issued':raise HTTPException(409,'Mã đã dùng. Kiểm tra trạng thái trong app trước khi tạo mã khác.')
            p.update(state='claimed',submission=secrets.token_urlsafe(32))
            return {'service':p['service'],'name':p['name'],'submission':p['submission']}

        @app.post('/local-api/browser-bridge/complete')
        async def complete(body:dict):
            p=self.find_code(body.get('code'))
            if p['state']!='claimed' or not isinstance(body.get('submission'),str) or not secrets.compare_digest(body['submission'],p['submission']):
                raise HTTPException(409,'Mã không còn quyền nhận phiên. Kiểm tra trạng thái trong app.')
            supplied=body.get('cookies')
            allowed={'google.com','gemini.google.com'} if p['service']=='gemini_chat' else {'google.com','labs.google','flow.google.com'}
            if not isinstance(supplied,list) or not 0<len(supplied)<=200:raise HTTPException(400,'Phiên trình duyệt không hợp lệ.')
            cookies=[]
            for c in supplied:
                if not isinstance(c,dict) or str(c.get('domain','')).lstrip('.') not in allowed:raise HTTPException(400,'Phiên có miền ngoài nguồn đã chọn; chưa nhận.')
                if not isinstance(c.get('name'),str) or not isinstance(c.get('value'),str) or not 1<=len(c['name'])<=200 or len(c['value'])>16000:raise HTTPException(400,'Cookie không hợp lệ.')
                cookies.append({k:v for k,v in c.items() if k in {'name','value','domain','path','secure','httpOnly','expires'}})
            if p['service']=='gemini_chat' and not any(c['name']=='__Secure-1PSID' and c['value'] for c in cookies):raise HTTPException(400,'Chưa có phiên Gemini. Đăng nhập Gemini trong chính trình duyệt chứa tiện ích trước.')
            p.update(state='checking',message='Đã nhận phiên · đang kiểm tra với dịch vụ.')
            p.pop('submission',None)
            task=asyncio.create_task(self.finish(p,cookies));self.tasks.add(task);task.add_done_callback(self.tasks.discard)
            return {'accepted':True,'state':'checking','message':'Đã chuyển phiên. Quay lại SceneForge để xem kết quả kiểm tra.'}


def install_browser_bridge(app,gemini,flow):return BrowserBridge(app,gemini,flow)
