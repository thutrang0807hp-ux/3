# SceneForge — bộ cục bộ gói 4

Bộ này chạy giao diện đã build và dịch vụ nhỏ của SceneForge trên **127.0.0.1:8840**. Không chứa tài khoản, key, cookie hay mô hình tải sẵn.

## Windows

Cài Python 3.11+; giải nén cả gói, mở `local_engine/start.bat`. Trình duyệt mở `http://127.0.0.1:8840/`. Nếu mở sớm trước khi máy chủ sẵn sàng, tải lại trang.

## macOS / Linux

```sh
sh local_engine/start.sh
```

Hoặc cài `local_engine/requirements.txt`, rồi chạy `python -m local_engine` tại thư mục gốc. Lệnh chuẩn chỉ bind loopback, không công khai máy chủ.

## Giọng VieNeu v3 tùy chọn

Trong cùng môi trường ảo:

```sh
python -m pip install "vieneu==3.8.3"
```

SDK được đọc theo repo `pnnbao97/VieNeu-TTS`, revision trong `docs/engine-audit/upstream-revisions.json`. Khi bấm Tạo giọng lần đầu, SDK có thể cần tải mô hình của nó. Dùng ONNX/CPU, một lượt mỗi lần. Mỗi nhịp được đọc riêng, lấy thời lượng WAV thật rồi nối để có mốc nhịp. Chưa kiểm chứng giọng miền Nam/tốc độ trên máy của bạn. Không tự dùng VieNeu V4 hoặc dịch vụ trả phí thay thế.

## Gemini tùy chọn

Vào Cài đặt → Giọng đọc & AI, lưu key trên bản localhost. Chỉ khi bạn bấm AI viết kịch bản / AI đạo diễn mới có yêu cầu ra Google. Không tự thử key bằng một lượt trả phí. Một lần gửi, không tự gửi lại khi mất kết nối; phí chưa xác minh được ghi chưa biết, có usage thực khi API trả về. Mô hình mặc định `gemini-2.5-flash`; có thể cấu hình `SCENEFORGE_GEMINI_MODEL` trước khi chạy.

## Tài khoản

Cài trình duyệt cho cửa sổ đăng nhập:

```sh
python -m playwright install chromium
```

Kết nối tài khoản mở cửa sổ riêng để tự đăng nhập/xác minh. App không có trường nhập mật khẩu. Bấm Lưu phiên để mã hóa cookie rồi đóng cửa sổ; tài khoản được ghi **chưa kiểm chứng**, không giả là sẵn sàng. Có thể dùng `SCENEFORGE_BROWSER` trỏ Chrome/Chromium đã cài. Chưa tự chuyển cookie sang engine bên thứ ba.

Cookie và Gemini key mã hóa AES-GCM; khóa nằm trong thư mục dữ liệu riêng quyền 0600 trên Unix. Windows khóa được bọc bằng DPAPI của người dùng. Không có khóa mẫu trong source. Dữ liệu mặc định `~/.sceneforge-local`, có thể đặt `SCENEFORGE_LOCAL_DATA`. Bảo vệ cả tài khoản hệ điều hành và thư mục này; không chia sẻ nó trong ZIP.

## Động cơ tạo clip — CHƯA BẬT

Đã đọc repo gốc và giấy phép:

- flow2api: `TheSmallHanCat/flow2api`, MIT. Cấu hình mẫu còn admin/admin, key mẫu, bind 0.0.0.0, dịch vụ captcha thuê và tự refresh. **Không chạy nguyên trạng.**
- muse2api: `czg86389-hub/muse2api`, MIT. Repo dùng **muse.ai**, chưa xác minh là Meta AI. Mặc định mã hiện tại có bind 0.0.0.0, concurrency 2, lưu cookie JSON, keepalive/renew. Cần sửa và kiểm thử trước khi bật với tài khoản thật.
- VieNeu-TTS: Apache-2.0, SDK tùy chọn nêu trên.

Bộ này **không tự tải/chạy hai engine tạo clip**, chưa có adapter cấp phiên/đọc credit/quota hoặc worker thực thi Flow/Muse. Hàng chờ hai làn lưu chuẩn bị và phụ thuộc khung-trước; không gửi render, không giả tiến độ. Các quy tắc tài khoản/không gửi lại đã có hàm và bài kiểm tra cục bộ, chưa phải chứng nhận engine thật tuân thủ mọi quy tắc đó.

Chưa kiểm chứng giới hạn dịch vụ, watermark, giữ nhãn/mặt, quota ngày, xác minh tài khoản hoặc thời gian nghỉ. Không dùng captcha thuê. Đừng gửi cookie sang dịch vụ khác vì tên "Meta/Muse" trong tài liệu.

## Lưu dữ liệu

Bản Pages và bản localhost có origin khác nhau: bộ nhớ trình duyệt không tự chuyển giữa hai bản. Giữ bản cũ để mở dữ liệu đã có; JSON không nhúng toàn bộ video. Chưa có import trọn cây thư mục sang origin mới. Bản dựng hiện tại vẫn xuất bằng MediaRecorder, chưa có FFmpeg xuất nền.

## Kho kịch bản (gói mới)

Kho được mở từ node Công thức trong luồng Từ ảnh: tự thêm, lọc, đổi tên, xóa, chọn và đánh giá sau khi xuất. Dữ liệu chung nằm trong trình duyệt; không mất khi dọn tệp của phòng. Có snapshot cho các phòng đã dùng.

Có Gemini key cục bộ: rút công thức từ lời có mốc giây, phân tích video MP4/WebM dọc tối đa 18 MB trong kho (có xác nhận sử dụng API), gợi ý công thức và viết lời mới theo khung. Tự rút một lần cho video mẫu có lời đã phân tích; chỉ mới dò hình thì chưa đủ. Không tự gửi lại khi lỗi, không lưu nguyên lời nguồn vào kho. Chưa thử bằng key thật; phí tiền chưa quy đổi khi chưa có bảng giá xác minh.

Thêm `?demo=1` vào địa chỉ để xem dữ liệu mẫu lưu riêng, không kết nối tài khoản hay gọi AI. Bỏ query để quay về dữ liệu làm việc.

## Gói 5

Mở bánh răng → Cài đặt để xem bảy mục mới và màn chào. Đồng hành vẫn nghe ở `127.0.0.1:8840`; không đổi sang cổng mẫu 8000 trong đặc tả. Key, cookie và kết quả kiểm tra lưu qua vault mã hóa đã có.

Cập nhật này thêm node gộp, cài đặt, chuông phân mức và tự xử lý logo trên bản sao clip nhập. Đọc `docs/package5-implementation.md` để phân biệt phần đã chạy với phần chưa nối (engine render, cài model, cân âm/ducking, dời ổ). Không bảo đảm xử lý được mọi logo Veo; không loại SynthID. Tệp SRT tùy chọn xuất cùng video lấy từ phụ đề thật, không tự nhận giọng nói.

## Bản tổng hợp: Gemini trong node và MP4 FFmpeg

Xem `docs/aggregate-implementation.md` và bảng thử riêng. Trong node Phân tích, bấm **AI Gemini · đọc cảnh & lời**, đọc thông tin gửi video tới Google rồi chọn Phân tích. Video tối đa 18 MB; dữ liệu trả về được xem trước trước khi áp dụng. Kết quả đã nhận có thể mở lại sau reload mà không gửi thêm lượt. Chưa dùng key thật để chứng nhận chất lượng/quota/chi phí.

Nếu máy có **FFmpeg và ffprobe trong PATH**, hộp Xuất tự hiện lựa chọn **MP4 bằng FFmpeg** và cân âm lượng. Vẫn dựng hình/hiệu ứng theo thời gian thực bằng trình duyệt trước, sau đó FFmpeg mã hóa H.264/AAC. Giới hạn 2 phút/100 MB; chưa phải dựng nền toàn bộ timeline bằng FFmpeg. Nếu động cơ lỗi, có nút tải bản ghi dự phòng, không đánh dấu MP4 thành công giả. MP4/SRT được giữ theo phòng, bản gốc không bị thay thế.

## Bổ sung CPU từ gói tổng hợp mới

Node Phân tích → **Đo trên máy · CPU** dùng PySceneDetect, FFmpeg, OpenCV; tùy chọn RapidOCR và faster-whisper. Xem `docs/aggregate-2-implementation.md`. Cần Python 3.10–3.12 và FFmpeg/ffprobe. Chạy `local_engine/install-cpu.bat` để cài các thư viện CPU riêng, khởi động lại app; không tải model Whisper trong bước này. Chuẩn bị model tùy chọn bằng `python -m local_engine.prepare_whisper --model base --download` trong môi trường app.

Phân tích không tự tải model/gửi video lên dịch vụ. Kết quả được xem trước, có dừng và khôi phục; cảnh vàng cần rà. OCR chỉ lấy mẫu; OpenCV chỉ ước lượng. Chưa kiểm chứng chép lời bằng model thật, video TikTok/Trung của người dùng hoặc máy Windows. Giá/credit vẫn không đoán từ tài liệu.
