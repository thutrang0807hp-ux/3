@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r local_engine\requirements.txt -r local_engine\requirements-translation.txt
if errorlevel 1 goto failed
if exist models\translate-zh_en-1_9.argosmodel if exist models\translate-en_vi-1_9.argosmodel goto offline
.venv\Scripts\python.exe -m local_engine.prepare_translation --download
if errorlevel 1 goto failed
goto done
:offline
.venv\Scripts\python.exe -m local_engine.prepare_translation --zh-en models\translate-zh_en-1_9.argosmodel --en-vi models\translate-en_vi-1_9.argosmodel
if errorlevel 1 goto failed
:done
echo Local CPU translation models verified. Restart SceneForge.
pause
exit /b 0
:failed
echo Translation setup not complete. No paid service is used. Read the error above.
pause
exit /b 1
