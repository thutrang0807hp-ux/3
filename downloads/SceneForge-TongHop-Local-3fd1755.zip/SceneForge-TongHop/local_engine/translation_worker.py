"""Bounded CPU translation using SentencePiece Argos models; never contacts a hub."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='2'
os.environ['HF_HUB_OFFLINE']='1'
import argparse,gc,json,re
from pathlib import Path

def validate_lines(raw):
 if not isinstance(raw,list) or not 1<=len(raw)<=300:raise ValueError('Dịch từ 1 đến 300 câu mỗi lượt.')
 out=[];seen=set();total=0
 for row in raw:
  if not isinstance(row,dict) or not isinstance(row.get('id'),str) or not 0<len(row['id'])<=160 or row['id'] in seen:raise ValueError('ID câu thiếu hoặc trùng.')
  text=row.get('original')
  if not isinstance(text,str) or not text.strip() or len(text)>3000:raise ValueError('Câu nguồn cần từ 1 đến 3.000 ký tự.')
  total+=len(text);seen.add(row['id']);out.append({'id':row['id'],'original':text})
 if total>30000:raise ValueError('Tối đa 30.000 ký tự mỗi lượt dịch.')
 return out

def load_package(path,pair):
 import ctranslate2,sentencepiece
 path=Path(path);metadata=json.loads((path/'metadata.json').read_text(encoding='utf-8'))
 if (metadata.get('from_code'),metadata.get('to_code'))!=pair:raise ValueError('Gói model sai cặp ngôn ngữ.')
 tokenizer=sentencepiece.SentencePieceProcessor(model_file=str(path/'sentencepiece.model'))
 engine=ctranslate2.Translator(str(path/'model'),device='cpu',compute_type='int8',inter_threads=1,intra_threads=2)
 return engine,tokenizer,metadata.get('target_prefix','')

def translate_pass(texts,path,pair):
 engine,tokenizer,prefix=load_package(path,pair)
 try:
  out=[]
  for text in texts:
   pieces=[]
   for sentence in re.split(r'(?<=[。！？.!?；;\n])',text):
    tokens=tokenizer.encode(sentence,out_type=str)
    for at in range(0,len(tokens),192):
     chunk=tokens[at:at+192]
     result=engine.translate_batch([chunk],target_prefix=[[prefix]] if prefix else None,beam_size=2,max_batch_size=1,max_input_length=0,max_decoding_length=512,replace_unknowns=True)[0]
     translated=result.hypotheses[0]
     if len(translated)>=512:raise ValueError('Câu dịch vượt giới hạn đầu ra; chia câu ngắn hơn.')
     if prefix and translated and translated[0]==prefix:translated=translated[1:]
     decoded=tokenizer.decode_pieces(translated).replace('▁',' ').replace('_',' ').strip()
     if not decoded:raise ValueError('Model trả câu rỗng; giữ bản lời cũ.')
     pieces.append(decoded)
   output=' '.join(pieces).strip()
   if not output or len(output)>12000:raise ValueError('Đầu ra dịch không hợp lệ.')
   out.append(output)
  return out
 finally:
  engine.unload_model();del engine;gc.collect()

def translate(root,lines,source='zh'):
 rows=validate_lines(lines)
 if source not in ('zh','en'):raise ValueError('Hỗ trợ tiếng Trung hoặc tiếng Anh → Việt.')
 texts=[r['original'] for r in rows]
 if source=='zh':texts=translate_pass(texts,Path(root)/'zh-en',('zh','en'))
 translated=translate_pass(texts,Path(root)/'en-vi',('en','vi'))
 return {'provider':'local-argos-ct2','source_language':source,'target_language':'vi','pivot':'en' if source=='zh' else None,'provider_requests':0,'lines':[{'id':r['id'],'original':r['original'],'translation':text} for r,text in zip(rows,translated)]}

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 body=json.loads(args.input.read_text(encoding='utf-8'));result=translate(args.root,body['lines'],body.get('source_language','zh'));args.output.write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
if __name__=='__main__':main()
