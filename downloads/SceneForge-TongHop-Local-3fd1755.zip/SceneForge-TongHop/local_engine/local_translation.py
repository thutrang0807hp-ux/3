"""Local-only translation endpoint; missing models never trigger paid fallback."""
import asyncio,importlib.util,json,sys,tempfile
from pathlib import Path
from fastapi import HTTPException
from .machine_checks import run_command
from .translation_worker import validate_lines

def translation_status(data):
 root=Path(data)/'models/translation';missing=[]
 for pair in ('zh-en','en-vi'):
  for name in ('metadata.json','sentencepiece.model','model/model.bin','model/config.json'):
   if not (root/pair/name).is_file():missing.append(pair+'/'+name)
 installed=all(importlib.util.find_spec(n) is not None for n in ('ctranslate2','sentencepiece'))
 return {'available':installed and not missing,'libraries':installed,'models_present':not missing,'missing':missing,'engine':'Argos models / CTranslate2 CPU int8','route':'zh → en → vi','paid_fallback':False,'note':'Dịch qua tiếng Anh có thể mất sắc thái; cần rà lại. Không tự tải model.'}

def install_local_translation(app,data,lane):
 busy=False
 @app.get('/local-api/translation/local/status')
 async def status():return translation_status(data)
 @app.post('/local-api/translation/local')
 async def run(body:dict):
  nonlocal busy
  try:lines=validate_lines(body.get('lines'))
  except ValueError as error:raise HTTPException(400,str(error))
  source=body.get('source_language','zh')
  if source not in ('zh','en'):raise HTTPException(400,'Chọn tiếng Trung hoặc tiếng Anh làm nguồn.')
  if not translation_status(data)['available']:raise HTTPException(409,'Chưa đủ model dịch local. Chạy install-translation.bat. Không gọi API trả phí thay thế.')
  if busy:raise HTTPException(409,'Đang có lượt dịch local. Chờ lượt hiện tại hoàn tất.')
  busy=True
  try:
   async with lane:
    with tempfile.TemporaryDirectory(prefix='translation-',dir=data) as temporary:
     folder=Path(temporary);input_file=folder/'input.json';output=folder/'output.json'
     input_file.write_text(json.dumps({'lines':lines,'source_language':source},ensure_ascii=False),encoding='utf-8')
     code,_,_=await run_command(sys.executable,'-m','local_engine.translation_worker','--root',str(Path(data)/'models/translation'),'--input',str(input_file),'--output',str(output),timeout=300,tree=True)
     if code or not output.is_file():raise HTTPException(503,'Không chạy được model dịch local. Bản lời cũ được giữ; không gọi dịch vụ khác.')
     result=json.loads(output.read_text(encoding='utf-8'));rows=result.get('lines',[])
     if len(rows)!=len(lines) or any(not isinstance(r,dict) or r.get('id')!=old['id'] or r.get('original')!=old['original'] or not isinstance(r.get('translation'),str) or not 0<len(r['translation'])<=12000 for r,old in zip(rows,lines)):raise HTTPException(502,'Đầu ra dịch sai câu. Không thay bản lời cũ.')
     return result
  finally:busy=False
