"""API and installer safety tests. Fixtures only: no translation model quality claim."""
import os,tempfile,json,zipfile,asyncio
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from fastapi import FastAPI
from .local_translation import install_local_translation
from .work_budget import WorkBudget
from .translation_worker import validate_lines
from .prepare_translation import unpack
lines=[{'id':'a','original':'你好。'},{'id':'b','original':'这是产品。'}]
with tempfile.TemporaryDirectory() as temporary:
 data=Path(temporary);app=FastAPI();install_local_translation(app,data,WorkBudget().lane('translation',20))
 with TestClient(app) as c:
  assert not c.get('/local-api/translation/local/status').json()['available']
  assert c.post('/local-api/translation/local',json={'lines':lines}).status_code==409
  assert c.post('/local-api/translation/local',json={'lines':lines*2}).status_code==400
  async def worker(*args,**kwargs):
   source=Path(args[args.index('--input')+1]);out=Path(args[args.index('--output')+1]);body=json.loads(source.read_text());out.write_text(json.dumps({'provider':'local-argos-ct2','lines':[dict(r,translation='Bản dịch kiểm thử') for r in body['lines']],'provider_requests':0}));return 0,'',''
  with patch('local_engine.local_translation.translation_status',return_value={'available':True}),patch('local_engine.local_translation.run_command',side_effect=worker):
   result=c.post('/local-api/translation/local',json={'lines':lines}).json();assert result['lines'][0]['id']=='a' and result['provider_requests']==0
   assert not list(data.glob('translation-*'))
  async def broken(*args,**kwargs):
   Path(args[args.index('--output')+1]).write_text(json.dumps({'lines':[{'id':'wrong','translation':'x'}]}));return 0,'',''
  with patch('local_engine.local_translation.translation_status',return_value={'available':True}),patch('local_engine.local_translation.run_command',side_effect=broken):assert c.post('/local-api/translation/local',json={'lines':lines}).status_code==502
  assert not list(data.glob('translation-*'))
 archive=data/'bad.argosmodel'
 with zipfile.ZipFile(archive,'w') as z:
  z.writestr('package/metadata.json',json.dumps({'from_code':'zh','to_code':'en'}));z.writestr('package/../escape.txt','bad')
 try:unpack(archive,data/'target','zh-en')
 except ValueError:pass
 else:raise AssertionError('Unsafe archive accepted')
 assert not (data/'escape.txt').exists() and not (data/'target').exists()
 print('PASS missing model blocks without fallback, input IDs, isolated worker output contract, temporary cleanup, unsafe archive rejection. Model/transport fixtures only.')
