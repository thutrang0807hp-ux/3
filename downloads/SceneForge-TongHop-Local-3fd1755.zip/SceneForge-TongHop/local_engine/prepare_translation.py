"""Install fixed Argos zh-en/en-vi packages; no downloads during translation."""
import argparse,hashlib,json,os,tempfile,urllib.request,zipfile
from pathlib import Path,PurePosixPath
from .translation_worker import translate_pass
PAIRS={'zh-en':('zh','en','https://argos-net.com/v1/translate-zh_en-1_9.argosmodel'),'en-vi':('en','vi','https://argos-net.com/v1/translate-en_vi-1_9.argosmodel')}

def unpack(archive_path,target,pair):
 target=Path(target);target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():raise ValueError('Đã có thư mục model, không ghi đè: '+str(target))
 with tempfile.TemporaryDirectory(prefix='translation-install-',dir=target.parent) as temporary:
  staged=Path(temporary)/'package';staged.mkdir();total=0
  with zipfile.ZipFile(archive_path) as z:
   if len(z.namelist())>20000 or len(z.namelist())!=len(set(z.namelist())):raise ValueError('Gói model có danh sách file không hợp lệ.')
   metadata=[n for n in z.namelist() if n.endswith('/metadata.json') or n=='metadata.json']
   if len(metadata)!=1:raise ValueError('Cần đúng một metadata.json trong gói Argos.')
   meta_name=metadata[0];prefix=meta_name[:-len('metadata.json')]
   if z.getinfo(meta_name).file_size>1024**2:raise ValueError('Metadata quá lớn.')
   meta=json.loads(z.read(meta_name));source,to,_=PAIRS[pair]
   if (meta.get('from_code'),meta.get('to_code'))!=(source,to):raise ValueError('Sai cặp ngôn ngữ: '+pair)
   selected=[]
   for info in z.infolist():
    if info.is_dir() or not info.filename.startswith(prefix):continue
    name=info.filename[len(prefix):];path=PurePosixPath(name)
    if '\\' in name or path.is_absolute() or '..' in path.parts:raise ValueError('Đường dẫn ZIP không hợp lệ.')
    if name not in ('metadata.json','sentencepiece.model','LICENSE','LICENSE.txt','README.md') and not (name.startswith('model/') and path.suffix in ('.bin','.json','.txt','.model')):continue
    total+=info.file_size
    if not 0<info.file_size<=512*1024**2 or total>1024**3:raise ValueError('Gói model vượt giới hạn giải nén.')
    selected.append((info,name))
   if not {'metadata.json','sentencepiece.model','model/model.bin','model/config.json'}<={n for _,n in selected}:raise ValueError('Gói không có đủ model SentencePiece/CTranslate2.')
   for info,name in selected:
    out=staged/name;out.parent.mkdir(parents=True,exist_ok=True);count=0
    with z.open(info) as incoming,out.open('xb') as destination:
     while True:
      chunk=incoming.read(1024**2)
      if not chunk:break
      count+=len(chunk)
      if count>info.file_size:raise ValueError('Giải nén vượt kích thước.')
      destination.write(chunk)
  example='你好，欢迎使用。' if source=='zh' else 'Hello, welcome.'
  output=translate_pass([example],staged,(source,to))
  if not output or not output[0].strip() or output[0].strip()==example:raise ValueError('Chưa xác minh được model dịch.')
  (staged/'setup-status.json').write_text(json.dumps({'smoke_verified':True,'pair':pair,'example':output[0],'files':[{'path':n,'bytes':(staged/n).stat().st_size,'sha256':hashlib.sha256((staged/n).read_bytes()).hexdigest()} for _,n in selected]},ensure_ascii=False,indent=2),encoding='utf-8')
  os.replace(staged,target)
 print('Đã nhập và chạy thử model:',pair)

def download(url,path):
 count=0
 with urllib.request.urlopen(url,timeout=60) as response,path.open('xb') as out:
  while True:
   chunk=response.read(1024**2)
   if not chunk:break
   count+=len(chunk)
   if count>600*1024**2:raise ValueError('Gói tải vượt 600 MB.')
   out.write(chunk)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--download',action='store_true');p.add_argument('--zh-en',type=Path);p.add_argument('--en-vi',type=Path);p.add_argument('--directory',type=Path,default=Path(os.environ.get('SCENEFORGE_LOCAL_DATA',str(Path.home()/'.sceneforge-local')))/'models/translation');a=p.parse_args()
 try:
  for pair in PAIRS:
   target=a.directory/pair
   if (target/'setup-status.json').is_file():continue
   source=getattr(a,pair.replace('-','_'))
   if source:unpack(source,target,pair)
   elif a.download:
    with tempfile.TemporaryDirectory(prefix='argos-download-') as folder:
     path=Path(folder)/'model.argosmodel';download(PAIRS[pair][2],path);unpack(path,target,pair)
   else:raise ValueError('Thiếu --'+pair+' hoặc --download.')
  print('Đã sẵn sàng dịch CPU Trung → Anh → Việt. Cần rà chất lượng bản dịch.')
 except Exception as error:raise SystemExit('Chưa cài xong model dịch local: '+str(error))
if __name__=='__main__':main()
