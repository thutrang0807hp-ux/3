@echo off
setlocal
set "FLOWPY=D:\4\Data\engines\flow2api\venv\Scripts\python.exe"
if not exist "%FLOWPY%" (
 echo Khong tim thay Python cua SceneForge tai D:\4.
 pause
 exit /b 1
)
"%FLOWPY%" -I "%~dp0read_flow_ui.py" --data "D:\4\Data"
start "" notepad.exe "%~dp0SceneForge-Flow-UI-v2.txt"
