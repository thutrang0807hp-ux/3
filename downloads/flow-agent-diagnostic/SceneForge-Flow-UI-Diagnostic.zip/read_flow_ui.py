"""Read only control structure from SceneForge's own Flow profile over loopback CDP.
No credential export, prompt values, asset text, generation, or external requests.
"""
import argparse,base64,hashlib,json,os,socket,struct,time
from pathlib import Path
from urllib.request import build_opener,ProxyHandler
from urllib.parse import urlsplit

SCRIPT=r'''(()=>{
const visible=n=>!!(n.getClientRects().length&&getComputedStyle(n).visibility!=='hidden');
const label=n=>{
 const raw=(n.getAttribute('aria-label')||n.innerText||n.getAttribute('title')||'').trim().replace(/\s+/g,' ');
 const known=['Agent','Generate','Create','Create video','Tạo','Tạo video','Send','Gửi','Upload','Upload media','Tải lên','Add to prompt','Frames to Video','Text to Video','Ingredients to Video','Video','Images','Videos','All media','Settings','Agent settings','Save','Always','Never','Confirm','Cancel','Close','Download','Tải xuống','arrow_forward','arrow_upward','send','add','close','tune','settings','more_vert','expand_more','keyboard_arrow_down','attach_file','movie','image','upload','download','9:16','16:9','1:1','8s','6s','4s','720p','1080p'];
 if(known.some(k=>k.toLowerCase()===raw.toLowerCase()))return raw;
 if(raw.length<=70&&/^(?:Veo|Omni|Nano Banana)\s*[0-9 .]*(?:(?:Lite|Fast|Quality|Flash|Pro|Ultra|Relaxed|[0-9]+s|720p|1080p|9:16|16:9|[-·/()])\s*)*$/i.test(raw))return raw;
 return raw?'[other label omitted]':'[no label]';
};
const shape=n=>({tag:n.tagName.toLowerCase(),role:n.getAttribute('role')||'',type:n.getAttribute('type')||'',disabled:!!n.disabled,editable:n.isContentEditable});
const controls=Array.from(document.querySelectorAll('button,[role=button],[role=combobox],[role=menuitem],select')).filter(visible).slice(0,150).map((n,i)=>({index:i,...shape(n),label:label(n),icons:Array.from(n.querySelectorAll('.material-icons,.material-symbols-outlined,[data-icon]')).slice(0,4).map(x=>label(x))}));
const editors=Array.from(document.querySelectorAll('textarea,[contenteditable=true],input:not([type=password]):not([type=hidden])')).filter(visible).slice(0,30).map(n=>({...shape(n),placeholderKind:/what do you want to create|mô tả|prompt/i.test(n.getAttribute('placeholder')||'')?'creation':/search|tìm/i.test(n.getAttribute('placeholder')||'')?'search':'other',nearbyControls:Array.from((n.closest('form')||n.parentElement.parentElement).querySelectorAll('button,[role=button]')).filter(visible).slice(0,12).map(label)}));
const uploads=Array.from(document.querySelectorAll('input[type=file]')).slice(0,10).map(n=>({multiple:!!n.multiple,visible:visible(n),accept:(n.accept||'').replace(/[^a-zA-Z0-9,./* +-]/g,'').slice(0,120)}));
return {version:1,pageKind:/^\/project\//.test(location.pathname)?'project':'other Flow page',controls,editors,uploads};
})()'''

class Cdp:
 def __init__(self,url,port):
  u=urlsplit(url)
  if u.scheme!='ws'or u.hostname!='127.0.0.1'or u.port!=port or not u.path.startswith('/devtools/page/')or u.username or u.password or u.query or u.fragment:raise ValueError('UNEXPECTED_DEBUG_ENDPOINT')
  self.sock=socket.create_connection(('127.0.0.1',port),timeout=10);self.buffer=b''
  key=base64.b64encode(os.urandom(16)).decode()
  self.sock.sendall(('GET '+u.path+' HTTP/1.1\r\nHost: 127.0.0.1:'+str(port)+'\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: '+key+'\r\nSec-WebSocket-Version: 13\r\n\r\n').encode())
  data=b''
  while b'\r\n\r\n'not in data:
   chunk=self.sock.recv(4096)
   if not chunk:raise ValueError('DEBUG_HANDSHAKE_CLOSED')
   data+=chunk
   if len(data)>16384:raise ValueError('DEBUG_HANDSHAKE_TOO_LARGE')
  header,self.buffer=data.split(b'\r\n\r\n',1)
  expected=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).lower()
  if not header.startswith(b'HTTP/1.1 101')or expected not in header.lower():raise ValueError('DEBUG_HANDSHAKE_FAILED')
 def read(self,n):
  while len(self.buffer)<n:
   chunk=self.sock.recv(max(4096,n-len(self.buffer)))
   if not chunk:raise ValueError('DEBUG_CONNECTION_CLOSED')
   self.buffer+=chunk
  value,self.buffer=self.buffer[:n],self.buffer[n:];return value
 def send(self,value,op=1):
  raw=value.encode()if isinstance(value,str)else value;mask=os.urandom(4);length=len(raw)
  head=bytes([128|op,128|length])if length<126 else bytes([128|op,128|126])+struct.pack('!H',length)
  self.sock.sendall(head+mask+bytes(c^mask[i%4]for i,c in enumerate(raw)))
 def receive(self):
  parts=[];total=0
  while True:
   first,second=self.read(2);length=second&127
   if length==126:length=struct.unpack('!H',self.read(2))[0]
   elif length==127:length=struct.unpack('!Q',self.read(8))[0]
   if length>2*1024**2:raise ValueError('DEBUG_FRAME_TOO_LARGE')
   mask=self.read(4)if second&128 else None;raw=self.read(length)
   if mask:raw=bytes(c^mask[i%4]for i,c in enumerate(raw))
   op=first&15
   if op==8:raise ValueError('DEBUG_CONNECTION_CLOSED')
   if op==9:self.send(raw,10);continue
   if op==10:continue
   if op not in (0,1):raise ValueError('UNEXPECTED_DEBUG_FRAME')
   total+=length
   if total>2*1024**2:raise ValueError('DEBUG_MESSAGE_TOO_LARGE')
   parts.append(raw)
   if first&128:return json.loads(b''.join(parts))
 def evaluate(self):
  self.send(json.dumps({'id':1,'method':'Runtime.evaluate','params':{'expression':SCRIPT,'returnByValue':True,'awaitPromise':False}}))
  for _ in range(100):
   result=self.receive()
   if result.get('id')==1:
    if result.get('error')or result.get('result',{}).get('exceptionDetails'):raise ValueError('UI_EVALUATION_FAILED')
    value=result['result']['result'].get('value')
    if not isinstance(value,dict):raise ValueError('UI_RESULT_UNAVAILABLE')
    return value
  raise ValueError('DEBUG_RESPONSE_TIMEOUT')
 def close(self):self.sock.close()

def report(data):
 profile=Path(data)/'browser-profiles/flow-web';port=int((profile/'DevToolsActivePort').read_text().splitlines()[0])
 if not 1<=port<=65535:raise ValueError('INVALID_DEBUG_PORT')
 opener=build_opener(ProxyHandler({}))
 with opener.open('http://127.0.0.1:'+str(port)+'/json/list',timeout=5)as response:
  raw=response.read(1024*1024+1)
  if len(raw)>1024*1024:raise ValueError('DEBUG_TARGET_LIST_TOO_LARGE')
  pages=json.loads(raw)
 selected=[p for p in pages if p.get('type')=='page'and urlsplit(p.get('url','')).scheme=='https'and urlsplit(p.get('url','')).hostname=='flow.google.com']
 if len(selected)!=1:raise ValueError('KEEP_ONE_FLOW_TAB_IN_APP_BROWSER')
 client=Cdp(selected[0]['webSocketDebuggerUrl'],port)
 try:return client.evaluate()
 finally:client.close()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,default=Path(r'D:\4\Data'));parser.add_argument('--output',type=Path,default=Path(__file__).with_name('SceneForge-Flow-UI.txt'));args=parser.parse_args()
 try:result=report(args.data)
 except Exception as error:
  code=str(error)if isinstance(error,ValueError)else'OPEN_FLOW_WEB_LOGIN_IN_SCENEFORGE_AND_KEEP_WINDOW_OPEN'
  result={'error':code if code and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'for c in code)and len(code)<120 else'UI_DIAGNOSTIC_FAILED'}
 args.output.write_text('SceneForge Flow UI diagnostic — READ ONLY\nOnly sanitized control labels/types. No prompt values, cookie/token/account or media contents.\n'+json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8-sig')
 print('Saved:',args.output.name)
