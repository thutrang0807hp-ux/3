"""Read only control structure from SceneForge's own Flow profile over loopback CDP.
No credential export, prompt values, asset text, generation, or external requests.
"""
import argparse,base64,hashlib,json,os,socket,struct,time
from pathlib import Path
from urllib.request import build_opener,ProxyHandler
from urllib.parse import urlsplit
from urllib.error import URLError,HTTPError

SCRIPT=r'''(()=>{
const roots=[],frames=[];const seen=new Set();
function visit(root,kind){if(!root||seen.has(root)||roots.length>=32)return;seen.add(root);roots.push({root,kind});for(const n of root.querySelectorAll('*')){if(n.shadowRoot)visit(n.shadowRoot,'open-shadow');if(n.tagName==='IFRAME'){try{const child=n.contentDocument;let host='other';try{const h=new URL(n.src,location.href).hostname;if(['flow.google.com','labs.google','accounts.google.com','www.google.com','www.gstatic.com'].includes(h))host=h;}catch{}frames.push({readable:!!child,host});if(child)visit(child,'same-origin-frame');}catch{frames.push({readable:false});}}}}
visit(document,'main');
const visible=n=>!!(n.getClientRects().length&&getComputedStyle(n).visibility!=='hidden');
const all=selector=>roots.flatMap(({root,kind})=>Array.from(root.querySelectorAll(selector)).map(n=>({n,kind})));
const known=['Agent settings','Generation settings','Agent','Generate','Create video','Create','Tạo video','Tạo','Send prompt','Submit prompt','Submit','Send','Gửi','Upload media','Upload image','Upload','Tải lên','Add to prompt','Frames to Video','Text to Video','Ingredients to Video','Video','Images','Videos','All media','Settings','Save','Always','Never','Confirm','Cancel','Close','Download','Tải xuống','More options','arrow_forward','arrow_upward','send','add','close','tune','settings','more_vert','expand_more','keyboard_arrow_down','attach_file','movie','image','upload','download','9:16','16:9','1:1','8s','6s','4s','720p','1080p'];
function rawLabel(n){let named='';const ids=(n.getAttribute('aria-labelledby')||'').split(/\s+/).filter(Boolean);for(const id of ids){try{named+=' '+(n.getRootNode().querySelector('#'+CSS.escape(id))?.textContent||'');}catch{}}return String(n.getAttribute('aria-label')||named.trim()||n.innerText||n.getAttribute('title')||n.getAttribute('data-icon')||'').trim().replace(/\s+/g,' ');}
function label(n){const raw=rawLabel(n),lower=raw.toLowerCase();const exact=known.find(k=>k.toLowerCase()===lower);if(exact)return exact;const semantic=known.filter(k=>k.length>=4&&new RegExp('(?:^|[^a-z])'+k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?:$|[^a-z])','i').test(raw)).slice(0,5);const model=raw.match(/\b(?:Veo\s*\d(?:\.\d)?|Omni\s*\d(?:\.\d)?|Nano Banana)(?:\s*(?:Lite|Fast|Quality|Flash|Pro|Ultra|Relaxed|\d(?:\.\d)?))*/i)?.[0];if(model&&model.length<60)semantic.unshift(model);if(semantic.length)return [...new Set(semantic)].join(' | ');return raw?'[other label omitted]':'[no label]';}
const shape=n=>({tag:n.tagName.toLowerCase(),role:n.getAttribute('role')||'',type:n.getAttribute('type')||'',disabled:!!n.disabled,editable:!!n.isContentEditable});
const controls=all('button,[role=button],[role=combobox],[role=menuitem],[role=option],[role=radio],[role=tab],select').filter(({n})=>visible(n)).slice(0,200).map(({n,kind},i)=>({index:i,...shape(n),context:kind,label:label(n),icons:Array.from(n.querySelectorAll('.material-icons,.material-icons-outlined,.material-symbols-outlined,.material-symbols-rounded,[data-icon],svg title')).slice(0,4).map(label)}));
const editors=all('textarea,[contenteditable]:not([contenteditable=false]),[role=textbox],[data-lexical-editor],input:not([type=password]):not([type=hidden]):not([type=file])').filter(({n})=>visible(n)).slice(0,40).map(({n,kind})=>({...shape(n),context:kind,placeholderKind:/what do you want to create|mô tả|prompt/i.test(n.getAttribute('placeholder')||n.getAttribute('data-placeholder')||'')?'creation':/search|tìm/i.test(n.getAttribute('placeholder')||'')?'search':'other',nearbyControls:Array.from((n.closest('form')||n.parentElement?.parentElement||n.getRootNode()).querySelectorAll('button,[role=button]')).filter(visible).slice(0,15).map(label)}));
const uploads=all('input[type=file]').slice(0,15).map(({n,kind})=>({context:kind,multiple:!!n.multiple,visible:visible(n),accept:(n.accept||'').replace(/[^a-zA-Z0-9,./* +-]/g,'').slice(0,120)}));
const safeSegments=new Set(['project','projects','fx','tools','flow','home','create','media','assets','editor','edit','scenes','scene','library']);
const pathShape='/'+location.pathname.split('/').filter(Boolean).map(p=>safeSegments.has(p)?p:':id').join('/');
const creation=editors.some(e=>e.editable||e.tag==='textarea'||e.placeholderKind==='creation');
const hasProjectHint=/project|workspace/i.test(location.hash)||Array.from(new URLSearchParams(location.search).keys()).some(k=>/project|workspace/i.test(k));
return {version:4,hasProjectHint,pageKind:creation?'creation editor visible':location.pathname==='/'?'Flow root page':'no creation editor visible',pathShape,readyState:document.readyState,contexts:roots.map(r=>r.kind),frames:frames.slice(0,20),hasCreationEditor:creation,controls,editors,uploads};
})()
'''

class Cdp:
 def __init__(self,url,port):
  u=urlsplit(url)
  if u.scheme!='ws'or u.hostname!='127.0.0.1'or u.port!=port or not u.path.startswith('/devtools/page/')or u.username or u.password or u.query or u.fragment:raise ValueError('UNEXPECTED_DEBUG_ENDPOINT')
  self.sock=socket.create_connection(('127.0.0.1',port),timeout=10);self.buffer=b''
  key=base64.b64encode(os.urandom(16)).decode()
  self.sock.sendall(('GET '+u.path+' HTTP/1.1\r\nHost: 127.0.0.1:'+str(port)+'\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: '+key+'\r\nSec-WebSocket-Version: 13\r\n\r\n').encode())
  data=b''
  while b'\r\n\r\n'not in data:
   chunk=self.sock.recv(4096)
   if not chunk:raise ValueError('DEBUG_HANDSHAKE_CLOSED')
   data+=chunk
   if len(data)>16384:raise ValueError('DEBUG_HANDSHAKE_TOO_LARGE')
  header,self.buffer=data.split(b'\r\n\r\n',1)
  expected=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).lower()
  if not header.startswith(b'HTTP/1.1 101')or expected not in header.lower():raise ValueError('DEBUG_HANDSHAKE_FAILED')
 def read(self,n):
  while len(self.buffer)<n:
   chunk=self.sock.recv(max(4096,n-len(self.buffer)))
   if not chunk:raise ValueError('DEBUG_CONNECTION_CLOSED')
   self.buffer+=chunk
  value,self.buffer=self.buffer[:n],self.buffer[n:];return value
 def send(self,value,op=1):
  raw=value.encode()if isinstance(value,str)else value;mask=os.urandom(4);length=len(raw)
  head=bytes([128|op,128|length])if length<126 else bytes([128|op,128|126])+struct.pack('!H',length)
  self.sock.sendall(head+mask+bytes(c^mask[i%4]for i,c in enumerate(raw)))
 def receive(self):
  parts=[];total=0
  while True:
   first,second=self.read(2);length=second&127
   if length==126:length=struct.unpack('!H',self.read(2))[0]
   elif length==127:length=struct.unpack('!Q',self.read(8))[0]
   if length>2*1024**2:raise ValueError('DEBUG_FRAME_TOO_LARGE')
   mask=self.read(4)if second&128 else None;raw=self.read(length)
   if mask:raw=bytes(c^mask[i%4]for i,c in enumerate(raw))
   op=first&15
   if op==8:raise ValueError('DEBUG_CONNECTION_CLOSED')
   if op==9:self.send(raw,10);continue
   if op==10:continue
   if op not in (0,1):raise ValueError('UNEXPECTED_DEBUG_FRAME')
   total+=length
   if total>2*1024**2:raise ValueError('DEBUG_MESSAGE_TOO_LARGE')
   parts.append(raw)
   if first&128:return json.loads(b''.join(parts))
 def activate(self,target):
  # Activate only the existing page selected from the app-owned profile.
  self.send(json.dumps({'id':90,'method':'Page.bringToFront','params':{}}))
  for _ in range(100):
   result=self.receive()
   if result.get('id')==90:
    if result.get('error'):return False
    return True
  return False
 def evaluate(self):
  self.send(json.dumps({'id':1,'method':'Runtime.evaluate','params':{'expression':SCRIPT,'returnByValue':True,'awaitPromise':False}}))
  for _ in range(100):
   result=self.receive()
   if result.get('id')==1:
    if result.get('error')or result.get('result',{}).get('exceptionDetails'):raise ValueError('UI_EVALUATION_FAILED')
    value=result['result']['result'].get('value')
    if not isinstance(value,dict):raise ValueError('UI_RESULT_UNAVAILABLE')
    return value
  raise ValueError('DEBUG_RESPONSE_TIMEOUT')
 def close(self):self.sock.close()

def startup_checks(data):
 root=Path(data);profile=root/'browser-profiles/flow-web'
 result={}
 for key,path in [('data_directory_exists',root),('profile_directory_exists',profile),('debug_port_file_exists',profile/'DevToolsActivePort')]:
  try:result[key]=path.exists()
  except OSError:result[key]=None
 try:
  version=json.loads((root.parent/'app-build.json').read_text(encoding='utf-8-sig')).get('version','')
  if isinstance(version,str)and len(version)<40 and all(c in '0123456789.'for c in version):result['app_version']=version
 except (OSError,ValueError,AttributeError):pass
 return result

def report(data,wait_seconds=0,focus=False):
 profile=Path(data)/'browser-profiles/flow-web'
 if not profile.is_dir():raise ValueError('FLOW_PROFILE_DIRECTORY_NOT_FOUND')
 try:rawport=(profile/'DevToolsActivePort').read_text().splitlines()[0]
 except FileNotFoundError:raise ValueError('DEBUG_PORT_FILE_NOT_FOUND')from None
 except PermissionError:raise ValueError('DEBUG_PORT_READ_DENIED')from None
 except (OSError,IndexError):raise ValueError('DEBUG_PORT_READ_FAILED')from None
 try:port=int(rawport)
 except ValueError:raise ValueError('INVALID_DEBUG_PORT')from None
 if not 1<=port<=65535:raise ValueError('INVALID_DEBUG_PORT')
 opener=build_opener(ProxyHandler({}))
 try:
  with opener.open('http://127.0.0.1:'+str(port)+'/json/list',timeout=10)as response:
   raw=response.read(1024*1024+1)
 except HTTPError:raise ValueError('DEBUG_HTTP_REJECTED')from None
 except (TimeoutError,socket.timeout):raise ValueError('DEBUG_HTTP_TIMEOUT')from None
 except URLError as error:
  if isinstance(error.reason,ConnectionRefusedError):raise ValueError('DEBUG_BROWSER_NOT_RUNNING')from None
  if isinstance(error.reason,(TimeoutError,socket.timeout)):raise ValueError('DEBUG_HTTP_TIMEOUT')from None
  raise ValueError('DEBUG_HTTP_CONNECTION_FAILED')from None
 except OSError:raise ValueError('DEBUG_HTTP_CONNECTION_FAILED')from None
 if len(raw)>1024*1024:raise ValueError('DEBUG_TARGET_LIST_TOO_LARGE')
 try:pages=json.loads(raw)
 except ValueError:raise ValueError('DEBUG_TARGET_LIST_INVALID')from None
 if not isinstance(pages,list):raise ValueError('DEBUG_TARGET_LIST_INVALID')
 selected=[p for p in pages if isinstance(p,dict)and p.get('type')=='page'and urlsplit(p.get('url','')).scheme=='https'and urlsplit(p.get('url','')).hostname=='flow.google.com']
 if not selected:raise ValueError('NO_FLOW_TAB_IN_APP_BROWSER')
 if len(selected)!=1:raise ValueError('KEEP_ONE_FLOW_TAB_IN_APP_BROWSER')
 try:client=Cdp(selected[0]['webSocketDebuggerUrl'],port)
 except (TimeoutError,socket.timeout):raise ValueError('DEBUG_WEBSOCKET_TIMEOUT')from None
 except OSError:raise ValueError('DEBUG_WEBSOCKET_CONNECTION_FAILED')from None
 try:
  activated=client.activate(selected[0].get('id'))if focus else False
  deadline=time.monotonic()+max(0,min(wait_seconds,60))
  while True:
   client.sock.settimeout(min(30,max(1,deadline-time.monotonic()))if wait_seconds>0 else 30)
   try:result=client.evaluate()
   except (TimeoutError,socket.timeout):raise ValueError('UI_READ_TIMEOUT')from None
   except OSError:raise ValueError('UI_CONNECTION_LOST')from None
   if result.get('hasCreationEditor')or time.monotonic()>=deadline:
    result['focused_app_flow_tab']=activated
    return result
   time.sleep(1)
 finally:client.close()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,default=Path(r'D:\4\Data'));parser.add_argument('--wait',type=int,default=45);parser.add_argument('--output',type=Path,default=Path(__file__).with_name('SceneForge-Flow-UI-v4.txt'));args=parser.parse_args()
 print('The app Flow tab will be brought to front. Open your project there; wait up to 45 seconds...')
 try:result=report(args.data,args.wait,focus=True)
 except Exception as error:
  code=str(error)if isinstance(error,ValueError)else'UI_DIAGNOSTIC_FAILED'
  result={'error':code if code and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'for c in code)and len(code)<120 else'UI_DIAGNOSTIC_FAILED'}
 result['connection_checks']=startup_checks(args.data)
 args.output.write_text('SceneForge Flow UI diagnostic — READ ONLY\nOnly sanitized control labels/types. No prompt values, cookie/token/account or media contents.\n'+json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8-sig')
 print('Saved:',args.output.name)
