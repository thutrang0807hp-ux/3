@echo off
setlocal
set "SF_LOGIN_DIAG_PY=D:\4\Data\engines\flow2api\venv\Scripts\python.exe"
if exist "%SF_LOGIN_DIAG_PY%" goto run
where py >nul 2>nul
if not errorlevel 1 goto pylauncher
where python >nul 2>nul
if not errorlevel 1 goto python
 echo Khong tim thay Python. Hay gui lai thong bao nay; khong can cai lai app.
pause
exit /b 1
:run
"%SF_LOGIN_DIAG_PY%" -I "%~dp0read_login.py" --data "D:\4\Data"
goto done
:pylauncher
py -3 -I "%~dp0read_login.py" --data "D:\4\Data"
goto done
:python
python -I "%~dp0read_login.py" --data "D:\4\Data"
:done
if errorlevel 1 goto failed
notepad "%~dp0SceneForge-Login-Diagnostic.txt"
exit /b 0
:failed
echo Chua tao duoc bao cao. Chup cua so nay de kiem tra.
pause
