"""Read-only login diagnostics for SceneForge-owned browser profiles.
Only loopback HTTP metadata; no CDP commands, navigation, login or generation.
"""
import argparse,json,os,re,subprocess
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import build_opener,ProxyHandler

PUBLIC_VERSION=re.compile(r'^(Chrome|Chromium|HeadlessChrome|Edg)/[0-9.]{1,60}$')

def page_kind(url):
 try:
  parsed=urlsplit(url)
  if parsed.scheme!='https':return 'other'
  if parsed.hostname=='accounts.google.com':
   return 'google_signin_rejected'if re.match(r'^/(?:v[0-9]+/)?signin/rejected(?:/|$)',parsed.path)else'google_signin_or_verification'
  if parsed.hostname=='flow.google.com':return 'flow_project'if re.match(r'^/project/[^/]+/?$',parsed.path)else'flow_home_or_other'
  if parsed.hostname=='labs.google':return 'labs_flow'if '/tools/flow'in parsed.path else'other'
 except (ValueError,TypeError):pass
 return 'other'

def local_json(port,path):
 opener=build_opener(ProxyHandler({}))
 with opener.open('http://127.0.0.1:'+str(port)+path,timeout=3)as response:
  raw=response.read(1024*1024+1)
 if len(raw)>1024*1024:raise ValueError('METADATA_TOO_LARGE')
 return json.loads(raw)

def profile_report(profile,index):
 result={'profile_index':index,'debug_port_present':False,'runtime_reachable':False}
 portfile=profile/'DevToolsActivePort'
 if not portfile.is_file():return {**result,'code':'PROFILE_PORT_MISSING'}
 result['debug_port_present']=True
 try:
  lines=portfile.read_text().splitlines();port=int(lines[0]);expected=lines[1]
  if not 1<=port<=65535 or not re.fullmatch(r'/devtools/browser/[A-Za-z0-9-]+',expected):raise ValueError()
 except (OSError,IndexError,ValueError):return {**result,'code':'PROFILE_PORT_INVALID'}
 try:
  info=local_json(port,'/json/version');result['runtime_reachable']=True
  websocket=urlsplit(info.get('webSocketDebuggerUrl',''))
  matched=websocket.scheme=='ws'and websocket.hostname in ('127.0.0.1','localhost')and websocket.port==port and websocket.path==expected and not websocket.username and not websocket.password
  result['runtime_matches_profile']=matched
  if not matched:return {**result,'code':'RUNTIME_PROFILE_MISMATCH'}
  version=info.get('Browser','');result['browser_version']=version if isinstance(version,str)and PUBLIC_VERSION.fullmatch(version)else'unknown'
  tabs=local_json(port,'/json/list')
  result['pages']=[page_kind(row.get('url',''))for row in tabs if isinstance(row,dict)and row.get('type')=='page'][:20]
  result['code']='READ_OK'
 except Exception:result['code']='RUNTIME_UNREACHABLE'
 return result

PROCESS_SCRIPT=r'''
$ErrorActionPreference='Stop'
$base=$env:SCENEFORGE_DIAG_PROFILE_ROOT.Replace('/','\')
$rows=@()
Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" | ForEach-Object {
 $cmd=$_.CommandLine
 if($cmd -and $cmd.Replace('/','\').IndexOf($base,[StringComparison]::OrdinalIgnoreCase) -ge 0){
  $version='unknown';$vendor='unknown'
  try{$info=(Get-Item -LiteralPath $_.ExecutablePath).VersionInfo;$version=$info.ProductVersion;if($info.CompanyName -match 'Google'){$vendor='Google'}elseif($info.CompanyName -match 'Microsoft'){$vendor='Microsoft'}}catch{}
  $rows+=@{browser=$_.Name;version=$version;vendor=$vendor;app_profile=$true;loopback_debugging=($cmd -match '--remote-debugging-address=127\.0\.0\.1');automation_flag=($cmd -match '--enable-automation(?:\s|$)')}
 }
}
ConvertTo-Json -InputObject @($rows) -Depth 3 -Compress
'''

def browser_processes(data):
 if os.name!='nt':return {'state':'NOT_WINDOWS','processes':[]}
 try:
  completed=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',PROCESS_SCRIPT],env={**os.environ,'SCENEFORGE_DIAG_PROFILE_ROOT':str(data/'browser-profiles')},capture_output=True,text=True,timeout=15)
  if completed.returncode:return {'state':'PROCESS_METADATA_UNAVAILABLE','processes':[]}
  rows=json.loads(completed.stdout.lstrip('\ufeff'));rows=rows if isinstance(rows,list)else[rows]
  safe=[]
  for row in rows[:16]:
   version=str(row.get('version',''))
   safe.append({'browser':row.get('browser')if row.get('browser')in ('chrome.exe','msedge.exe')else'other','version':version if re.fullmatch(r'[0-9.a-zA-Z +()-]{1,80}',version)else'unknown','vendor':row.get('vendor')if row.get('vendor')in ('Google','Microsoft')else'unknown','app_profile':True,'loopback_debugging':bool(row.get('loopback_debugging')),'automation_flag':bool(row.get('automation_flag'))})
  return {'state':'READ_OK','processes':safe}
 except Exception:return {'state':'PROCESS_METADATA_UNAVAILABLE','processes':[]}

def report(data):
 data=Path(data);base=data/'browser-profiles';profiles=[]
 if(base/'flow-web').is_dir():profiles.append(base/'flow-web')
 accounts=base/'flow-accounts'
 if accounts.is_dir():profiles.extend(sorted([p for p in accounts.iterdir()if p.is_dir()and re.fullmatch(r'[a-f0-9]{24}',p.name)],key=lambda p:p.stat().st_mtime,reverse=True)[:16])
 profiles=[p for p in profiles if p.resolve().is_relative_to(base.resolve())]
 version=None
 try:
  value=json.loads((data.parent/'app-build.json').read_text(encoding='utf-8-sig')).get('version')
  if isinstance(value,str)and re.fullmatch(r'[0-9.]{1,40}',value):version=value
 except Exception:pass
 return {'diagnostic_version':1,'app_version':version,'data_directory_exists':data.is_dir(),'profiles_found':len(profiles),'profiles':[profile_report(p,n)for n,p in enumerate(profiles)],'browser_process_metadata':browser_processes(data),'contains_cookie_values':False,'contains_passwords':False,'contains_prompts':False,'contains_account_names':False,'contains_project_ids':False,'contains_full_urls':False,'login_attempts':0,'generation_requests':0,'browser_changes':False}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--data',default=r'D:\4\Data');args=parser.parse_args()
 output=Path(__file__).resolve().with_name('SceneForge-Login-Diagnostic.txt')
 output.write_text(json.dumps(report(Path(args.data)),ensure_ascii=False,indent=2),encoding='utf-8')
 print('Da tao SceneForge-Login-Diagnostic.txt. Khong dang nhap/tao video hay thay doi trinh duyet.')
if __name__=='__main__':main()
