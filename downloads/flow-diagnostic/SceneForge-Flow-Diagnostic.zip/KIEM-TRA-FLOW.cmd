@echo off
setlocal
set "FLOWPY=D:\4\Data\engines\flow2api\venv\Scripts\python.exe"
if not exist "%FLOWPY%" (
 echo Python cua engine Flow khong ton tai: "%FLOWPY%"
 pause
 exit /b 1
)
"%FLOWPY%" -I "%~dp0read_flow_errors.py" --data "D:\4\Data" --output "%~dp0SceneForge-Flow-Diagnostic.txt"
if errorlevel 1 (
 echo Khong doc duoc du lieu. Chup thong bao nay gui lai.
 pause
 exit /b 1
)
start "" notepad.exe "%~dp0SceneForge-Flow-Diagnostic.txt"
