"""Read only Flow task/request errors. No network, config, account or credential reads."""
import argparse,json,re,sqlite3
from pathlib import Path
from datetime import datetime

def redact(value):
 text=str(value or '')[:6000]
 text=re.sub(r'https?://[^\s\"\x27<>]+','[URL]',text)
 text=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','[EMAIL]',text)
 text=re.sub(r'(?i)\bBearer\s+\S+','Bearer [REDACTED]',text)
 text=re.sub(r'''(?ix)(["']?(?:authorization|cookie|set-cookie|token|access_token|refresh_token|api_key|password|__Secure-[A-Za-z0-9_-]+)["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;}]+)''',r'\1[REDACTED]',text)
 text=re.sub(r'[A-Za-z0-9_+/.=-]{48,}','[LONG_VALUE_REDACTED]',text)
 return text[:1800]

def error_text(body):
 try:obj=json.loads(body or '{}')
 except (ValueError,TypeError):return ''
 if not isinstance(obj,dict)or not obj.get('error'):return ''
 def selected(v,depth=0):
  if depth>4:return ''
  if isinstance(v,str):return redact(v)
  if isinstance(v,dict):return ' | '.join(k+': '+selected(x,depth+1)for k,x in v.items()if k.lower()in ('error','message','detail','code','status','reason','type'))
  if isinstance(v,(int,float)):return str(v)
  return ''
 return selected(obj['error'])

def report(data):
 dbfile=data/'engines/flow2api/source/data/flow.db'
 lines=['SceneForge Flow diagnostic — READ ONLY',datetime.now().astimezone().isoformat(),'No network requests. No configuration, account table, cookies, tokens or prompts collected.','']
 if not dbfile.is_file():return '\n'.join(lines+['FLOW_DATABASE_NOT_FOUND: engines/flow2api/source/data/flow.db'])
 try:
  with sqlite3.connect(dbfile.resolve().as_uri()+'?mode=ro',uri=True,timeout=3)as db:
   db.execute('PRAGMA query_only=ON');db.execute('PRAGMA busy_timeout=3000')
   tables={row[0]for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
   if 'request_logs'in tables:
    lines.append('RECENT ENGINE REQUEST ERRORS:')
    cols={row[1]for row in db.execute('PRAGMA table_info(request_logs)')}
    if {'id','operation','status_code','response_body','created_at'}<=cols:
     status='status_text'if 'status_text'in cols else "''"
     rows=db.execute('SELECT id,operation,status_code,substr(response_body,1,131072),created_at,'+status+' FROM request_logs ORDER BY id DESC LIMIT 40').fetchall();found=0
     for rid,operation,code,body,created,state in rows:
      detail=error_text(body)
      if isinstance(code,int)and code>=400 or detail or str(state).lower()in ('failed','error'):
       found+=1;lines.extend([f'Log #{rid} | {redact(created)} | HTTP {code} | {redact(operation)}', 'State: '+redact(state),'Error: '+(detail or 'No structured error body saved.'),''])
     if not found:lines.append('No error among the most recent '+str(len(rows))+' engine request logs.')
    else:lines.append('Unsupported request_logs schema; no raw records exported.')
   else:lines.append('No request_logs table.')
   if 'tasks'in tables:
    cols={row[1]for row in db.execute('PRAGMA table_info(tasks)')}
    if {'id','status','error_message','model','created_at'}<=cols:
     lines.append('\nRECENT FAILED ENGINE TASKS:')
     rows=db.execute("SELECT id,status,substr(error_message,1,6000),model,created_at FROM tasks WHERE status='failed' OR error_message IS NOT NULL ORDER BY id DESC LIMIT 20").fetchall()
     for rid,status,msg,model,created in rows:lines.extend([f'Task #{rid} | {redact(created)} | {redact(model)} | {redact(status)}','Error: '+redact(msg),''])
     if not rows:lines.append('No failed task rows found.')
   else:lines.append('No tasks table.')
 except (OSError,sqlite3.Error)as exc:lines.append('DATABASE_READ_ERROR: '+redact(exc))
 return '\n'.join(lines)+'\n'

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,default=Path(r'D:\4\Data'));parser.add_argument('--output',type=Path,default=Path(__file__).with_name('SceneForge-Flow-Diagnostic.txt'));args=parser.parse_args()
 args.output.write_text(report(args.data),encoding='utf-8-sig')
 print('Report saved:',args.output)
