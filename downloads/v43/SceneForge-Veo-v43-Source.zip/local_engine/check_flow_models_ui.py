"""Real node/dialog with an initially empty model cache and a fake local catalog."""
import os,socket,tempfile,time,urllib.request
from pathlib import Path
from threading import Thread
import httpx,uvicorn
from playwright.sync_api import sync_playwright,expect


def main():
    with tempfile.TemporaryDirectory()as tmp:
        os.environ['SCENEFORGE_LOCAL_DATA']=tmp
        from . import server
        calls=[]
        async def transport(request):
            calls.append((request.method,request.url.path))
            assert request.method=='GET'and request.url.path=='/v1/models','No generation or extra setup calls allowed'
            return httpx.Response(200,json={'data':[{'id':'veo-3.1-fast-i2v-6s-portrait','description':'Veo Fast I2V portrait'}]})
        server.FLOW_PROVIDER.client_factory=lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport))
        server.VAULT.set_secret('flow-engine',{'url':'http://127.0.0.1:8766','key':'fixture-engine-private','models':[],'account_binding':True,'task_journal':True})
        server.VAULT.put('accounts',{'id':'flow-fixture','service':'flow','engine_id':1,'name':'Flow already connected','state':'ready','enabled':True,'session_verified':True,'active':True})
        server.FLOW_ACCOUNTS.pool.select({'mode':'selected','account_id':'flow-fixture'})
        before=server.FLOW_ACCOUNTS.pool.status()['token']
        with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        host=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'))
        thread=Thread(target=host.run,daemon=True);thread.start();base='http://127.0.0.1:'+str(port)
        try:
            for _ in range(100):
                try:urllib.request.urlopen(base+'/local-api/health',timeout=.3);break
                except OSError:time.sleep(.05)
            with sync_playwright()as pw:
                browser=pw.chromium.launch(executable_path=os.environ.get('SCENEFORGE_BRIDGE_TEST_BROWSER')or'/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active')
                page.goto(base+'/workflow.html');page.wait_for_function('!!window.SceneForgeWorkflow')
                page.evaluate("async()=>{project=blankProject();project.id='models-only';project.source={poster:SAMPLE.frames[0]};project.scenes=[sceneRecord(0,4,0,[SAMPLE.frames[0]])];await directDialog(project.scenes,{source:'flow'});}")
                expect(page.locator('#directFlowModel')).to_have_value('veo-3.1-fast-i2v-6s-portrait')
                expect(page.locator('#directAccountInfo')).to_contain_text('Flow already connected')
                expect(page.locator('#directError')).to_have_text('')
                assert calls==[('GET','/v1/models')],calls
                assert server.FLOW_ACCOUNTS.pool.status()['token']==before
                assert server.FLOW_PROVIDER.config()['account_binding']and server.FLOW_PROVIDER.config()['task_journal']
                assert not errors,errors
                browser.close()
            print('PASS actual video node/dialog auto-loads the initially empty local Flow catalog, shows portrait model and existing account without re-pairing/settings, keeps selection/journal binding, no generation requests.')
        finally:
            host.should_exit=True;thread.join(timeout=10)
            for handler in list(server.RUNTIME_LOG.handlers):handler.close();server.RUNTIME_LOG.removeHandler(handler)
            server.LIBRARY._root_guard.instance.close()

if __name__=='__main__':main()
