"""Carry browser account selection and UA with scoped Flow credentials.

The envelope is stored only where the SDK already stores private cookies. Never
return it in account lists, pairing status, diagnostics or logs. No retries.
"""
from contextvars import ContextVar
from functools import wraps
import inspect
import json
import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

KEY='sceneforge_browser_context'
ACTIVE=ContextVar('sceneforge_flow_browser_context',default=None)


def clean_context(value):
    if not isinstance(value,dict):return {}
    result={}
    ua=value.get('user_agent')
    if isinstance(ua,str) and 1<=len(ua)<=512 and all(32<=ord(c)<127 for c in ua):
        result['user_agent']=ua
    account=value.get('authuser')
    if isinstance(account,str) and re.fullmatch(r'\d{1,3}',account):result['authuser']=account
    return result


def context_of(storage):
    try:value=json.loads(storage) if isinstance(storage,str) else storage
    except (ValueError,TypeError):return {}
    return clean_context(value.get(KEY)) if isinstance(value,dict) else {}


def envelope(storage,context):
    context=clean_context(context)
    if not context:return storage
    try:value=json.loads(storage) if isinstance(storage,str) else storage
    except (ValueError,TypeError):return storage
    if isinstance(value,dict) and isinstance(value.get('cookies'),list):value=value['cookies']
    if not isinstance(value,list):return storage
    return json.dumps({'cookies':value,KEY:context},separators=(',',':'))


def account_url(url,context):
    parsed=urlsplit(url)
    # Never attach account context to unrelated redirects, downloads or captcha.
    if parsed.scheme!='https' or parsed.netloc!='flow.google.com':return url
    index=context.get('authuser')
    if index is None:return url
    query=[(k,v) for k,v in parse_qsl(parsed.query,keep_blank_values=True) if k!='authuser']
    return urlunsplit(parsed._replace(query=urlencode([*query,('authuser',index)])))


def install(engine):
    manager=engine.token_manager;client=getattr(manager,'flow_client',None)or getattr(engine,'flow_client',None)
    if client is None or getattr(client,'_sceneforge_browser_context',False):return
    client._sceneforge_browser_context=True
    # Identity lookup must use the same account as the credit/project requests.
    # Keep the real SDK login parser and scoped jar; only carry request context.
    try:
        from src.services import protocol_login
        base=protocol_login.AsyncSession
        if not getattr(base,'_sceneforge_context_session',False):
            class ContextSession(base):
                _sceneforge_context_session=True
                async def request(self,method,url,**kwargs):
                    context=ACTIVE.get()
                    if context and urlsplit(url).netloc=='flow.google.com':
                        url=account_url(url,context)
                        headers=dict(kwargs.get('headers')or {})
                        if context.get('user_agent'):headers['User-Agent']=context['user_agent']
                        kwargs['headers']=headers
                    return await super().request(method,url,**kwargs)
            protocol_login.AsyncSession=ContextSession
    except ImportError:
        pass  # Unit-test doubles may have no vendor protocol module.
    def wrap(owner,name):
        original=getattr(owner,name,None)
        if not callable(original):return
        signature=inspect.signature(original)
        @wraps(original)
        async def call(*args,**kwargs):
            bound=signature.bind(*args,**kwargs)
            storage=bound.arguments.get('cookie_storage') or bound.arguments.get('google_cookies')
            storage=storage or bound.arguments.get('google_cookies_raw')
            context=context_of(storage) or ACTIVE.get()
            if not context:return await original(*args,**kwargs)
            marker=ACTIVE.set(context)
            fingerprint_var=getattr(client,'_request_fingerprint_ctx',None)
            fingerprint_marker=None
            if fingerprint_var is not None and context.get('user_agent'):
                fingerprint=dict(fingerprint_var.get() or {})
                fingerprint['user_agent']=context['user_agent']
                fingerprint_marker=fingerprint_var.set(fingerprint)
            try:
                if name=='_load_flow_frontend_bootstrap':
                    bound.arguments['page_url']=account_url(bound.arguments['page_url'],context)
                if name=='_make_text_request':
                    url=bound.arguments['url'];bound.arguments['url']=account_url(url,context)
                    if urlsplit(url).netloc=='flow.google.com':
                        headers=dict(bound.arguments.get('headers')or {})
                        if context.get('user_agent'):headers['User-Agent']=context['user_agent']
                        if headers.get('Referer'):headers['Referer']=account_url(headers['Referer'],context)
                        bound.arguments['headers']=headers
                        resolver=getattr(client,'_resolve_runtime_impersonate',None)
                        if resolver:bound.arguments['impersonate']=resolver()
                result=await original(*bound.args,**bound.kwargs)
                if name in ('st_to_at','detect_account_identity') and isinstance(result,dict) and result.get('google_cookies'):
                    result={**result,'google_cookies':envelope(result['google_cookies'],context)}
                return result
            finally:
                if fingerprint_marker is not None:fingerprint_var.reset(fingerprint_marker)
                ACTIVE.reset(marker)
        setattr(owner,name,call)
    for name in ('st_to_at','_call_flow_frontend_rpc','_call_flow_stream_chat','_load_flow_frontend_bootstrap','_make_text_request'):wrap(client,name)
    wrap(manager,'detect_account_identity')
    original=getattr(client,'get_updated_flow_cookies',None)
    if callable(original):
        @wraps(original)
        def updated(storage):return envelope(original(storage),context_of(storage) or ACTIVE.get())
        client.get_updated_flow_cookies=updated
