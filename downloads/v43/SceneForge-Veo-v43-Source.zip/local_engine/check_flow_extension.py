"""Intercepted Chromium fixture; exercises actual DOM adapter + local relay + provider.
This is not a Google Flow compatibility or Windows sign-in test.
"""
import asyncio,base64,hashlib,io,json,tempfile,subprocess,uuid
from pathlib import Path
from types import SimpleNamespace
import httpx
from fastapi import FastAPI
from PIL import Image
from playwright.async_api import async_playwright
from .vault import Vault
from .request_ledger import RequestLedger
from .flow_provider import FlowProvider
from .flow_accounts import FlowAccounts
from .flow_ui_driver import FlowUiDriver,UiFlowFailure
from .flow_extension_driver import FlowExtensionDriver
from .browser_bridge import BrowserBridge

async def main():
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);movie=root/'fixture.mp4'
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=90x160:d=0.4','-c:v','libx264','-pix_fmt','yuv420p','-y',str(movie)],check=True)
  encoded=base64.b64encode(movie.read_bytes()).decode()
  html='''<script>window.WIZ_global_data={oPEP7c:'fixture@invalid'};window.sent=0;</script>
  <button id=agent aria-pressed=true onclick="this.setAttribute('aria-pressed','false');document.querySelector('form').hidden=false">Agent</button>
  <form hidden onsubmit="return false"><button type=button>Veo 3.1 Lite</button><button type=button aria-pressed=true>8s</button><button type=button aria-pressed=true>9:16</button><button type=button aria-pressed=true>x1</button>
  <input type=file accept=image/png><textarea aria-label=Prompt></textarea><button type=button id=generate>Generate</button><div id=preview></div></form><div id=results></div>
  <script>document.querySelector('input').onchange=e=>{const img=new Image();img.src=URL.createObjectURL(e.target.files[0]);document.querySelector('#preview').replaceChildren(img)};
  document.querySelector('#generate').onclick=()=>{window.sent++;if(window.fail){document.querySelector('#results').innerHTML='<div><div>Không thành công</div><p>Chúng tôi nhận thấy có hoạt động bất thường nào đó.</p><button>Retry</button></div>';return;}
  const raw=Uint8Array.from(atob('MP4'),c=>c.charCodeAt(0)),v=document.createElement('video');v.width=90;v.height=160;v.src=URL.createObjectURL(new Blob([raw],{type:'video/mp4'}));document.querySelector('#results').append(v);};</script>'''.replace('MP4',encoded)
  vault=Vault(root);ledger=RequestLedger(root)
  def forbidden():raise AssertionError('Engine/RPC must not be called')
  provider=FlowProvider(vault,root,ledger,forbidden);accounts=FlowAccounts(provider);provider.account_service=accounts
  app=FastAPI();bridge=BrowserBridge(app,SimpleNamespace(vault=vault),accounts)
  driver=FlowExtensionDriver(FlowUiDriver(root,vault),bridge.relay,accounts);provider.web_ui=accounts.web_ui=driver
  ext=(Path(__file__).resolve().parents[1]/'scripts/browser-extension/dom-flow.js').read_text()
  async with async_playwright()as pw:
   browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
   context=await browser.new_context();await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body=html))
   page=await context.new_page();await page.goto('https://flow.google.com/project/fixture')
   # Use isolated execution context, same as chrome.scripting world ISOLATED.
   cdp=await context.new_cdp_session(page)
   frame=(await cdp.send('Page.getFrameTree'))['frameTree']['frame']['id']
   world=(await cdp.send('Page.createIsolatedWorld',{'frameId':frame,'worldName':'extension-test'}))['executionContextId']
   async def js(command):
    expression=ext+'\nsceneForgeDomFlow('+json.dumps(command)+')'
    answer=await cdp.send('Runtime.evaluate',{'expression':expression,'contextId':world,'awaitPromise':True,'returnByValue':True})
    assert 'exceptionDetails'not in answer,answer
    return answer['result']['value']
   async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://testserver')as client:
    pair=(await client.post('/local-api/browser-bridge/pairs',json={'service':'flow','name':'fixture'})).json()
    claim=(await client.post('/local-api/browser-bridge/claim',json={'code':pair['code'],'protocol':4})).json();assert claim['protocol']==4
    link=claim['relay'];auth={'id':link['id'],'key':link['browser_key']}
    await client.post('/local-api/browser-bridge/flow-poll',json={**auth,'hello':True})
    digest=hashlib.sha256(b'fixture@invalid').hexdigest();worker_errors=[]
    async def worker():
     try:
      while True:
       packet=(await client.post('/local-api/browser-bridge/flow-poll',json=auth)).json()
       if not packet.get('job'):continue
       job=packet['job'];req=job['request'];assert req['kind']=='ui'
       if req['action']=='identity':res={'status':200,'email':'fixture@invalid','account_hash':digest}
       else:res=await js(req)
       response=await client.post('/local-api/browser-bridge/flow-result',json={**auth,'job_id':job['id'],'result':res});assert response.status_code==200
     except asyncio.CancelledError:raise
     except Exception as exc:worker_errors.append(exc);raise
    task=asyncio.create_task(worker())
    try:
     response=await client.post('/local-api/browser-bridge/complete',json={'code':pair['code'],'submission':claim['submission'],'protocol':4})
     assert response.status_code==200,response.text
     aid=accounts.pool.status()['account_id'];assert driver.extension_binding(aid)
     assert vault.secret('flow-ui-profile')is None
     image=io.BytesIO();Image.new('RGB',(90,160),'green').save(image,format='PNG')
     refs=[{'mime_type':'image/png','data':base64.b64encode(image.getvalue()).decode()}]
     body={'request_id':'flow-'+str(uuid.uuid4()),'kind':'video','model':provider.status()['models'][0],'prompt':'Cô ấy vẫy tay.','references':refs,'confirm_send':True,'selection_token':accounts.pool.status()['token']}
     reply=await provider.submit(body);rid=body['request_id']
     for _ in range(200):
      entry=provider.lookup(rid)
      if entry['state']in ('done','failed','unknown'):break
      await asyncio.sleep(.1)
     assert entry['state']=='done',entry
     assert (provider.root/entry['result']['file']).read_bytes()==movie.read_bytes()
     assert await page.evaluate('window.sent')==1
     await provider.submit(body);assert await page.evaluate('window.sent')==1
     assert await page.get_by_role('button',name='Agent',exact=True).get_attribute('aria-pressed')=='false'
     # Unknown DOM -> no click, no uncertain lock.
     await page.locator('button',has_text='Veo 3.1 Lite').evaluate('(e)=>e.textContent="Unknown model"')
     try:await driver.generate(aid,body['model'],body['prompt'],refs,root/'flow-preflight.partial',lambda:None)
     except UiFlowFailure as e:assert not e.sent
     else:raise AssertionError('Unknown UI accepted')
     assert await page.evaluate('window.sent')==1
     await page.locator('button',has_text='Unknown model').evaluate('(e)=>e.textContent="Veo 3.1 Lite"')
     await page.evaluate('window.fail=true')
     try:await driver.generate(aid,body['model'],body['prompt'],refs,root/'flow-uncertain.partial',lambda:None)
     except UiFlowFailure:pass
     else:raise AssertionError('Provider denial accepted')
     assert (vault.secret('flow-ui-blocked')or{}).get('request_id')=='flow-uncertain'
     try:await driver.generate(aid,body['model'],body['prompt'],refs,root/'flow-next.partial',lambda:None)
     except UiFlowFailure:pass
     else:raise AssertionError('Blocked queue retried')
     assert await page.evaluate('window.sent')==2
     assert driver.acknowledge('wrong')is False and driver.acknowledge('flow-uncertain')is True
     assert not worker_errors,worker_errors
     print('PASS: protocol4 pairing without cookies; real isolated DOM Agent -> image/prompt -> single submit -> blob/chunks -> ffprobe/hash -> app result; duplicate ID; unknown model before click; denial blocks queue; exact acknowledgement. Fixture only, not live Google.')
    finally:
     task.cancel()
     try:await task
     except asyncio.CancelledError:pass
     await bridge.relay.close();await browser.close()
if __name__=='__main__':asyncio.run(main())
