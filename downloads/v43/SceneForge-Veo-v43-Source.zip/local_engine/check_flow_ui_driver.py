"""Normal UI end-to-end against a fully intercepted fixture, no live Google calls."""
import asyncio,os,tempfile,base64,io,subprocess,uuid,json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from PIL import Image
from playwright.async_api import async_playwright
from .google_login import open_flow_web_login,_FLOW_WEB_PROCESSES
from .flow_ui_driver import FlowUiDriver
from .flow_provider import FlowProvider
from .account_pool import AccountPool
from .vault import Vault
from .request_ledger import RequestLedger
from fastapi import HTTPException
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);movie=root/'fixture.mp4'
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=90x160:d=0.4','-c:v','libx264','-pix_fmt','yuv420p','-y',str(movie)],check=True)
  encoded=base64.b64encode(movie.read_bytes()).decode()
  shim=root/'browser-test';shim.write_text('#!/bin/sh\nexec /usr/bin/chromium --headless=new --no-sandbox --host-resolver-rules="MAP * ~NOTFOUND" "$@"\n');shim.chmod(0o700)
  with patch.dict(os.environ,{'SCENEFORGE_BROWSER':str(shim)}):await open_flow_web_login(root,auto_connect=True)
  portfile=root/'browser-profiles/flow-web/DevToolsActivePort'
  for _ in range(100):
   if portfile.exists():break
   await asyncio.sleep(.1)
  async with async_playwright()as pw:
   browser=await pw.chromium.connect_over_cdp('http://127.0.0.1:'+portfile.read_text().splitlines()[0]);context=browser.contexts[0]
   html='''<html><script>window.WIZ_global_data={oPEP7c:'fixture@invalid'};window.sent=0;window.fail=false;</script><button>Veo 3.1 Lite · 8s · 9:16</button><button>Frames to Video</button><input type=file accept="image/png"><textarea aria-label="Prompt"></textarea><button id=generate>Generate</button><div id=results></div><script>
 document.querySelector('#generate').onclick=()=>{window.sent++;if(window.fail){document.querySelector('#results').innerHTML='<div role=alert>PUBLIC_ERROR_UNUSUAL_ACTIVITY</div>';return;}
 const article=document.createElement('article'),video=document.createElement('video'),button=document.createElement('button');video.width=90;video.height=160;video.src='data:video/mp4;base64,MP4';button.textContent='Download';button.onclick=()=>{const a=document.createElement('a');a.href=video.src;a.download='clip.mp4';a.click();};article.append(video,button);document.querySelector('#results').append(article);};</script></html>'''.replace('MP4',encoded)
   await context.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body=html))
   page=context.pages[0]if context.pages else await context.new_page();await page.goto('https://flow.google.com/project/fixture')
   for extra in list(context.pages):
    if extra!=page:await extra.close()
   vault=Vault(root);ledger=RequestLedger(root);aid='flow-web-fixture'
   vault.put('accounts',{'id':aid,'service':'flow','name':'fixture','login_transport':'web_ui','enabled':True,'session_verified':True,'state':'ready','active':True})
   vault.set_secret('flow-ui-profile',{'account_id':aid,'email':'fixture@invalid'})
   def forbidden():raise AssertionError('Private engine API must not run')
   provider=FlowProvider(vault,root,ledger,forbidden);provider.account_service=SimpleNamespace(pool=AccountPool(vault,'flow'));provider.web_ui=FlowUiDriver(root,vault)
   from .flow_accounts import FlowAccounts
   from .flow_web_login import FlowWebLogin
   accounts=FlowAccounts(provider);accounts.web_ui=provider.web_ui;provider.account_service=accounts
   login=FlowWebLogin(root,accounts)
   await login.import_account([],{},'fixture@invalid')
   aid=login.status()['account_id']
   assert login.status()['state']=='done'and accounts.pool.status()['account_id']==aid
   async def no_extra_window(*args,**kwargs):raise AssertionError('Existing owned Flow window must be reused')
   with patch('local_engine.flow_web_login.open_flow_web_login',new=no_extra_window):
    await login.start();await asyncio.wait_for(login.task,20)
   assert login.status()['state']=='done'and len(context.pages)==1
   assert (await accounts.check(aid))['ok']is True
   assert provider.status()['transport']=='web_ui'and not provider.status()['generation_verified']
   image=io.BytesIO();Image.new('RGB',(90,160),'green').save(image,format='PNG')
   async def send():
    body={'request_id':'flow-'+str(uuid.uuid4()),'kind':'video','model':'veo-3.1-lite-i2v-8s-portrait','prompt':'Cô gái đứng vẫy tay','references':[{'mime_type':'image/png','data':base64.b64encode(image.getvalue()).decode()}],'confirm_send':True,'selection_token':provider.account_service.pool.status()['token'],'room_id':'fixture-room','scene_id':'scene-one'}
    await provider.submit(body)
    task=provider.tasks.get(body['request_id'])
    if task:await asyncio.wait_for(task,30)
    return body,provider.lookup(body['request_id'])
   body,result=await send();assert result['state']=='done',result
   assert result['result']['bytes']==len(movie.read_bytes())and await page.evaluate('window.sent')==1
   assert Path(provider.file(body['request_id']).path).is_file()
   cached=await provider.submit(body);assert cached['state']=='done'
   assert await page.evaluate('window.sent')==1
   assert provider.status()['transport']=='web_ui'
   await page.locator('#generate').evaluate("n=>n.textContent='Unknown control'")
   _,result=await send();assert result['state']=='failed'and await page.evaluate('window.sent')==1,result
   await page.locator('#generate').evaluate("n=>n.textContent='Generate'");await page.evaluate('window.fail=true')
   failed,result=await send();assert result['state']=='unknown'and await page.evaluate('window.sent')==2,result
   reconciled=await provider.reconcile(failed['request_id']);assert reconciled['state']=='unknown'
   assert await page.evaluate('window.sent')==2
   try:await provider.submit(failed)
   except HTTPException as exc:assert exc.status_code==409
   else:raise AssertionError('Unresolved request submitted twice')
   assert await page.evaluate('window.sent')==2
   _,blocked=await send();assert blocked['state']=='failed'and await page.evaluate('window.sent')==2
   assert not provider.web_ui.acknowledge('different-request')
   assert provider.web_ui.acknowledge(failed['request_id'])
   assert not page.is_closed()
   await provider.close();await browser.close()
  for proc in _FLOW_WEB_PROCESSES:
   if proc.poll()is None:proc.terminate()
   await asyncio.to_thread(proc.wait,timeout=10)
  await asyncio.sleep(.5)
 print('PASS real Chromium UI: upload one image + prompt -> one click -> download/decode clip; original profile retained; duplicate ID and unknown retries blocked; unknown UI stops before submit; provider denial stops; no engine/RPC/CAPTCHA calls')
asyncio.run(main())
