"""Actual DOM regression: Unicode names, native button menus and selection proof.
Intercepted fixture only; not a live Google Flow test.
"""
import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright

async def main():
 source=(Path(__file__).resolve().parents[1]/'scripts/browser-extension/dom-flow.js').read_text()
 async with async_playwright()as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context()
  await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html',body='<html><body></body></html>'))
  page=await context.new_page();await page.goto('https://flow.google.com/project/fixture')
  setup='''([name,role,ignored,delay])=>{
   document.body.replaceChildren();window.clicks=0;
   const trigger=document.createElement('button');trigger.textContent='Omni 1.1 Flash';trigger.setAttribute('aria-haspopup','menu');document.body.append(trigger);
   const menu=document.createElement('div');menu.hidden=true;if(role)menu.setAttribute('role','menu');document.body.append(menu);
   for(const title of ['Omni 1.1 Flash',name,'Veo 3.1 - Fast','Veo 3.1 - Quality']){
    const button=document.createElement('button');button.textContent=title;if(role)button.setAttribute('role',role);menu.append(button);
    button.onclick=()=>{window.clicks++;if(ignored)return;trigger.textContent=title;menu.hidden=true;};
   }
   trigger.onclick=()=>setTimeout(()=>{menu.hidden=false;},delay);
   for(const text of ['8s','9:16','x1']){const b=document.createElement('button');b.textContent=text;b.setAttribute('aria-pressed','true');document.body.append(b);}
  }'''
  for index,(name,role)in enumerate([('Veo 3.1 - Lite',''),('Veo 3.1 – Lite','menuitem'),('Veo 3.1 — Lite','option'),('Veo\u00a03.1\u00a0–\u00a0Lite','menuitemradio'),('Veo 3.1 · Lite',''),('Veo 3.1 Lite','')]):
   await page.evaluate(setup,[name,role,False,350])
   answer=await page.evaluate(source+'\nsceneForgeDomFlow('+json.dumps({'action':'prepare','request_id':f'model-{index}'})+')')
   assert answer['code']=='FLOW_UI_IMAGE',(name,answer)
   assert await page.evaluate('window.clicks')==1
   assert await page.locator('button[aria-haspopup]').inner_text()==name
  # A global Settings menu has no models; composer Settings opens the model pane.
  await page.evaluate(setup,['Veo 3.1 – Lite','menuitem',False,0])
  await page.evaluate("""()=>{
   const content=document.createElement('section');while(document.body.firstChild)content.append(document.body.firstChild);content.hidden=true;content.setAttribute('role','dialog');document.body.append(content);
   window.wrongSettingsClicks=0;window.settingsClicks=0;
   const other=document.createElement('button');other.setAttribute('aria-label','Cài đặt');other.setAttribute('aria-haspopup','menu');other.setAttribute('aria-expanded','true');other.onclick=()=>window.wrongSettingsClicks++;document.body.prepend(other);
   const form=document.createElement('form');form.onsubmit=()=>false;const editor=document.createElement('textarea');form.append(editor);document.body.append(form);
   const correct=document.createElement('button');correct.type='button';correct.setAttribute('aria-label','Cài đặt');correct.onclick=()=>{window.settingsClicks++;setTimeout(()=>{content.hidden=false;},450)};form.append(correct);
  }""")
  result=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"composer-settings"})')
  assert result['code']=='FLOW_UI_IMAGE',result
  assert await page.evaluate('window.settingsClicks===1 && window.wrongSettingsClicks===0 && window.clicks===1')
  result=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"settings-expanded"})')
  assert result['code']=='FLOW_UI_IMAGE',result
  assert await page.evaluate('window.settingsClicks')==1
  # If only a global settings button exists, stop instead of opening it.
  await page.set_content('<header><button aria-label="Cài đặt" aria-haspopup="menu" onclick="window.wrongSettingsClicks++"></button></header><form><textarea></textarea></form>')
  await page.evaluate('window.wrongSettingsClicks=0')
  result=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"global-only"})')
  assert result['code']=='FLOW_UI_SETTINGS',result
  assert await page.evaluate('window.wrongSettingsClicks')==0
  # Reported DOM: generic aria-label on Omni trigger inside a Settings menu.
  await page.evaluate(setup,['Veo 3.1 – Lite','menuitem',False,100])
  await page.evaluate("""()=>{
   const outer=document.createElement('section');outer.setAttribute('role','menu');while(document.body.firstChild)outer.append(document.body.firstChild);document.body.append(outer);
   const trigger=outer.querySelector('button[aria-haspopup]');trigger.setAttribute('aria-label','Chọn mô hình video');
   outer.querySelectorAll('[role=menuitem]').forEach(e=>e.setAttribute('aria-label','Chọn mô hình này'));
  }""")
  answer=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"generic-aria-nested-menu"})')
  assert answer['code']=='FLOW_UI_IMAGE',answer
  assert await page.evaluate('window.clicks')==1
  assert await page.locator('button[aria-haspopup]').inner_text()=='Veo 3.1 – Lite'
  # A button click that does not select Lite must not pass verification.
  await page.evaluate(setup,['Veo 3.1 – Lite','menuitem',True,0])
  answer=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"ignored-click"})')
  assert answer['code']=='FLOW_UI_MODEL',answer
  assert await page.locator('button[aria-haspopup]').inner_text()=='Omni 1.1 Flash'
  # No Lite -> never silently choose Fast/Quality.
  await page.evaluate(setup,['Other model','',False,0])
  answer=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"missing-lite"})')
  assert answer['code']=='FLOW_UI_MODEL'and await page.evaluate('window.clicks')==0
  await browser.close()
 print('PASS: 6 Lite label/menu variants including Unicode dash/NBSP and plain button options; delayed menu; composer-scoped Settings despite global popup; already-open pane; global-only refuses; verifies changed trigger; ignored click and absent Lite stop before upload/generation. Fixture only.')
if __name__=='__main__':asyncio.run(main())
