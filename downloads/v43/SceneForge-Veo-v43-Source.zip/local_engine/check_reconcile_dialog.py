"""Real workflow dialog with read-only provider fixtures and failing local save."""
import os,socket,tempfile,time,urllib.request
from threading import Thread
import uvicorn
from playwright.sync_api import sync_playwright,expect

def main():
 with tempfile.TemporaryDirectory()as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  host=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'));thread=Thread(target=host.run,daemon=True);thread.start();base='http://127.0.0.1:'+str(port)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(base+'/local-api/health',timeout=.3);break
    except OSError:time.sleep(.05)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page();calls=[];errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    mode={'state':'unknown','fail':False}
    def handle(route):
     path=route.request.url.split('/local-api/')[1];calls.append((route.request.method,path))
     if path=='flow/status':return route.fulfill(json={'models':[]})
     assert route.request.method=='GET'and path=='flow/jobs/flow-fixture/reconcile',calls
     if mode['fail']:return route.fulfill(status=409,json={'detail':'Không có định danh engine/tài khoản gốc để đối soát. Không tạo lại.'})
     return route.fulfill(json={'state':mode['state'],'reconciliation':mode['state']})
    page.route('**/local-api/flow/**',handle)
    page.goto(base+'/workflow.html');page.wait_for_function('!!window.SFMediaNodes')
    page.evaluate("""async()=>{project=blankProject();project.id='reconcile-dialog';project.cloudJobs=[{id:'flow-fixture',provider:'flow',kind:'video',state:'unknown'}];await storeProject();window.originalSave=storeProject;storeProject=async()=>{throw Error('Dữ liệu đang thay đổi; sẽ lưu lại khi ổn định.');};workflowJobsDialog();}""")
    page.locator('[data-reconcile-job]').click()
    expect(page.locator('#workflowReconcileResult')).to_contain_text('Động cơ trả trạng thái: unknown')
    expect(page.locator('#workflowReconcileSave')).to_contain_text('Dữ liệu đang thay đổi')
    assert page.evaluate('project.cloudJobs[0].state')=='unknown'
    mode['state']='failed';page.locator('#workflowReconcileAgain').click()
    expect(page.locator('#workflowReconcileResult')).to_contain_text('Lượt tại động cơ đã thất bại')
    assert page.evaluate('project.cloudJobs[0].state')=='failed'
    mode['fail']=True;page.locator('#workflowReconcileAgain').click()
    expect(page.locator('#workflowReconcileResult')).to_contain_text('Không có định danh engine/tài khoản gốc')
    mode['fail']=False;mode['state']='done'
    page.evaluate("()=>{directRecover=async()=>{throw Error('Lưu clip đang bận');};}")
    page.locator('#workflowReconcileAgain').click()
    expect(page.locator('#workflowReconcileSave')).to_contain_text('Lưu clip đang bận')
    expect(page.locator('#workflowReconcileResult a')).to_have_attribute('href','/local-api/flow/files/flow-fixture')
    assert page.evaluate('project.cloudJobs[0].state')=='done'
    assert all(method=='GET'for method,path in calls),calls
    assert not errors,errors
    browser.close()
   print('PASS visible reconciliation status despite concurrent-save error; exact engine error shown; completed file remains downloadable after import failure; GET only, no new media requests')
  finally:
   host.should_exit=True;thread.join(timeout=10)
   for h in list(server.RUNTIME_LOG.handlers):h.close();server.RUNTIME_LOG.removeHandler(h)
   server.LIBRARY._root_guard.instance.close()
if __name__=='__main__':main()
