"""Native browser -> broker -> actual pinned FlowClient. No real Google requests."""
import asyncio,json,os,socket,sys,tempfile,threading,time,types
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import parse_qs,urlsplit
import httpx,uvicorn
from fastapi import FastAPI,Request
from playwright.sync_api import sync_playwright,expect
if len(sys.argv)>2:sys.path.append(sys.argv[2])
from .vault import Vault
from .account_pool import AccountPool
from .browser_bridge import BrowserBridge,EXCHANGE
from .flow_native_transport import install,envelope


def main(source):
    if len(sys.argv)>2:sys.path.append(sys.argv[2])
    sys.path.insert(0,str(source))
    for package,folder in [('src',source/'src'),('src.core',source/'src/core'),('src.services',source/'src/services')]:
        module=types.ModuleType(package);module.__path__=[str(folder)];sys.modules[package]=module
    from src.services.flow_client import FlowClient
    with tempfile.TemporaryDirectory()as tmp:
        app=FastAPI();vault=Vault(Path(tmp));loop=asyncio.new_event_loop();calls=[]
        client=FlowClient(proxy_manager=None)
        async def forbidden(*a,**kw):raise AssertionError('Cookie-export HTTP path must not run in native mode')
        client._load_flow_frontend_bootstrap=forbidden;client._make_text_request=forbidden
        manager=SimpleNamespace(flow_client=client);install(SimpleNamespace(token_manager=manager))
        class Flow:
            def __init__(self):self.pool=AccountPool(vault,'flow');self.flow=SimpleNamespace(config=lambda:{'url':'http://fixture','key':'fixture'})
            async def import_session(self,cookies,browser_context=None,browser_route=None):
                self.storage=envelope(json.dumps(cookies),browser_route)
                result=await client.st_to_at(google_cookies=self.storage)
                assert result['user']['email']=='fixture-one@invalid' and result['credits']==42
                project=await client.create_project('', 'Fixture import project',google_cookies=self.storage)
                assert project=='01234567-89ab-cdef-0123-456789abcdef'
                self.storage=result['google_cookies'];aid='flow-engine-1'
                vault.put('accounts',{'id':aid,'service':'flow','engine_id':1,'enabled':True,'state':'unverified','session_verified':False,'active':False,'name':'fixture-one@invalid'})
                return {'imported_account_id':aid}
            async def check(self,aid):
                result=await client.get_credits(google_cookies=self.storage)
                row=self.pool.rows()[0];row.update(state='ready',session_verified=True);vault.put('accounts',row)
                return {'ok':result['credits']==42}
        flow=Flow();gemini=SimpleNamespace(vault=vault,pool=AccountPool(vault,'gemini_chat'))
        bridge=BrowserBridge(app,gemini,flow)
        @app.middleware('http')
        async def boundary(request:Request,next):
            return await bridge.extension_request(request,next)if request.url.path in EXCHANGE else await next(request)
        with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        host=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='error',timeout_graceful_shutdown=2))
        async def serve():await host.serve()
        def run():asyncio.set_event_loop(loop);loop.run_until_complete(serve())
        thread=threading.Thread(target=run,daemon=True);thread.start();base='http://127.0.0.1:'+str(port)
        try:
            with httpx.Client(base_url=base)as api:
                for _ in range(100):
                    try:
                        r=api.get('/local-api/browser-bridge/setup')
                        if r.status_code==200:break
                    except (OSError,httpx.RequestError):pass
                    time.sleep(.05)
                pair=api.post('/local-api/browser-bridge/pairs',json={'service':'flow','name':'Native fixture'}).json()
                with sync_playwright()as pw:
                    context=pw.chromium.launch_persistent_context(str(Path(tmp)/'browser'),executable_path=os.environ['SCENEFORGE_BRIDGE_TEST_BROWSER'],headless=True,args=['--no-sandbox','--disable-extensions-except='+str(bridge.root),'--load-extension='+str(bridge.root)],ignore_default_args=['--disable-extensions'])
                    state={'email':'fixture-one@invalid'}
                    def google(route):
                        request=route.request;url=urlsplit(request.url)
                        if request.method=='GET':
                            wiz={'FdrFJe':'123','SNlM0e':'fixture-private-xsrf','oPEP7c':state['email'],'cfb2h':'boq_labs-ai-sandbox-frontend_fixture'}
                            route.fulfill(status=200,content_type='text/html',body='<html><script>window.WIZ_global_data='+json.dumps(wiz)+';window.grecaptcha={enterprise:{ready:cb=>cb(),execute:async(k,o)=>"fixture-cap-"+o.action}}</script>Native fixture</html>');return
                        assert url.path.startswith('/_/AiSandboxAngularFrontend/data/'),request.url
                        assert 'OSID=fixture-native-cookie'in request.all_headers().get('cookie','')
                        body=parse_qs(request.post_data or '');assert body['at']==['fixture-private-xsrf']
                        rpc=parse_qs(url.query).get('rpcids',['stream'])[0];calls.append(rpc)
                        assert rpc in ('nzlxg','jHPbke','stream'),rpc
                        value='[42]'if rpc=='nzlxg'else '["01234567-89ab-cdef-0123-456789abcdef"]'
                        frames=[["wrb.fr",rpc,value]]
                        route.fulfill(status=200,content_type='application/json',body=")]}'\n123\n"+json.dumps(frames)+'\n')
                    context.route('https://flow.google.com/**',google)
                    context.add_cookies([{'url':'https://flow.google.com/','name':'OSID','value':'fixture-native-cookie','secure':True,'httpOnly':True},{'name':'SID','value':'fixture-root','domain':'.google.com','path':'/','secure':True}])
                    tab=context.new_page();tab.goto('https://flow.google.com/?authuser=1')
                    popup=context.new_page();popup.goto(bridge.origin+'/popup.html');popup.locator('#code').fill(pair['code']);popup.locator('summary').first.click();popup.locator('#port').fill(str(port));popup.locator('#submit').click()
                    expect(popup.locator('#status')).to_have_attribute('data-state','done',timeout=30000)
                    for _ in range(200):
                        popup.wait_for_timeout(50);status=api.get('/local-api/browser-bridge/pairs/'+pair['id']).json()
                        if status['state']in ('done','failed'):break
                    assert status['state']=='done',status
                    assert calls.count('nzlxg')==2 and calls.count('jHPbke')==1,calls
                    assert flow.pool.status()['account_id']=='flow-engine-1'
                    public=json.dumps(status)
                    for private in ('browser_key','engine_key','fixture-private-xsrf','fixture-native-cookie','sceneforge_native_flow'):assert private not in public
                    class DB:
                        async def get_token(self,aid):return SimpleNamespace(google_cookies=flow.storage)if aid==1 else None
                    client.db=DB()
                    for action in ('UPLOAD_IMAGE','IMAGE_GENERATION','VIDEO_GENERATION'):
                        cap=asyncio.run_coroutine_threadsafe(client._get_recaptcha_token('fixture',action=action,token_id=1),loop)
                        for _ in range(200):
                            if cap.done():break
                            popup.wait_for_timeout(50)
                        assert cap.result(timeout=1)==('fixture-cap-'+action,None)
                    # Same native path for streaming; only this intercepted fixture is sent.
                    future=asyncio.run_coroutine_threadsafe(client._call_flow_stream_chat(project_id='01234567-89ab-cdef-0123-456789abcdef',prompt='Fixture only',recaptcha_token='fixture',session_id='fixture',cookie_header='',cookie_storage=flow.storage,timeout=10),loop)
                    for _ in range(300):
                        if future.done():break
                        popup.wait_for_timeout(50)
                    assert future.result(timeout=1)['frames']
                    assert calls[-1]=='stream'
                    # Account change must stop before any Google mutation/read RPC.
                    before=len(calls);state['email']='fixture-other@invalid';tab.reload()
                    future=asyncio.run_coroutine_threadsafe(client.get_credits(google_cookies=flow.storage),loop)
                    for _ in range(300):
                        if future.done():break
                        popup.wait_for_timeout(50)
                    try:future.result(timeout=1)
                    except Exception:pass
                    else:raise AssertionError('Changed native account accepted')
                    assert len(calls)==before
                    context.close()
                print('PASS actual extension worker + MAIN-world native fetch -> loopback broker -> actual pinned FlowClient: authenticated credit/project import, exact selected account, private route persistence, stream transport, account change stops before RPC; no cookie-export HTTP and no real Google calls.')
        finally:
            asyncio.run_coroutine_threadsafe(bridge.close(),loop).result(timeout=10);host.should_exit=True;thread.join(timeout=10);loop.close()

if __name__=='__main__':main(Path(sys.argv[1])if len(sys.argv)>1 else Path('/tmp/sceneforge-flow-pinned'))
