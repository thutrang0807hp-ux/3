"""Stored failure diagnostics are read-only and contain only known error messages."""
import tempfile,uuid
from pathlib import Path
from .gemini_chat import GeminiChat
from .vault import Vault
from .request_ledger import RequestLedger

def main():
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);ledger=RequestLedger(root);calls=[]
  async def runner(body):
   calls.append(body)
   raise AssertionError('Reading a failure dispatched a provider request')
  adapter=GeminiChat(Vault(root/'vault'),root,ledger,runner)
  for code in ['SDK_CONTRACT_MISMATCH','auth','quota','input','CHAT_TURN_UNRESOLVED',None,'PRIVATE_UNKNOWN_CODE']:
   rid='gchat-'+str(uuid.uuid4());ledger.claim(rid,{'test':'failed'});ledger.finish(rid,'failed')
   if code:ledger.set_metadata(rid,{'last_error_code':code})
   row=adapter.lookup(rid)
   assert row['state']=='failed' and row['message'] and row['automatic_retry'] is False
   assert row['code']==(code if code not in (None,'PRIVATE_UNKNOWN_CODE') else 'GEMINI_JOB_FAILED')
   assert 'PRIVATE_UNKNOWN_CODE' not in str(row)
  assert not calls
 print('PASS persisted Gemini failures expose known causes or legacy fallback; unknown metadata not leaked; no provider calls or automatic retries')
if __name__=='__main__':main()
