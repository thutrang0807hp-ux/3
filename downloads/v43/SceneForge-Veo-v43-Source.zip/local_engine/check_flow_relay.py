"""Broker capability, isolation, single-dispatch and cancellation checks."""
import asyncio,tempfile
from pathlib import Path
import httpx
from fastapi import FastAPI
from .vault import Vault
from .flow_browser_relay import BrowserRelay,PREFIX
from .flow_native_transport import clean_route


async def main():
    with tempfile.TemporaryDirectory()as tmp:
        app=FastAPI();relay=BrowserRelay(app,Vault(Path(tmp)))
        browser,engine=relay.issue('http://127.0.0.1:8840'+PREFIX+'execute','chrome-extension://'+'a'*32)
        other,unused=relay.issue(engine['endpoint'],engine['origin'])
        assert clean_route(engine)
        for endpoint in ['http://evil.invalid'+PREFIX+'execute','http://127.0.0.1:8840/private','http://user@127.0.0.1:8840'+PREFIX+'execute','https://127.0.0.1:8840'+PREFIX+'execute']:
            assert clean_route({**engine,'endpoint':endpoint})is None
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://testserver')as c:
            async def post(path,data):return await c.post(PREFIX+path,json=data)
            b={'id':browser['id'],'key':browser['browser_key']};e={'id':engine['id'],'key':engine['key'],'request':{'kind':'rpc','rpc_id':'nzlxg','argument':[]}}
            assert (await post('poll',{**b,'key':'wrong','hello':True})).status_code==403
            assert (await post('poll',{'id':engine['id'],'key':engine['key'],'hello':True})).status_code==403
            assert (await post('execute',{**e,'key':browser['browser_key']})).status_code==403
            assert (await post('execute',e)).status_code==503
            assert (await post('poll',{**b,'hello':True})).status_code==200
            pending=asyncio.create_task(post('execute',e));await asyncio.sleep(0)
            packet=(await post('poll',b)).json()['job'];assert packet['request']==e['request']
            result={'job_id':packet['id'],'result':{'status':200,'text':'fixture'}}
            assert (await post('result',{'id':other['id'],'key':other['browser_key'],**result})).status_code==409
            assert (await post('result',{**b,**result})).status_code==200
            assert (await pending).json()['text']=='fixture'
            assert (await post('result',{**b,**result})).status_code==409
            pending=asyncio.create_task(post('execute',e));await asyncio.sleep(0)
            packet=(await post('poll',b)).json()['job'];pending.cancel()
            try:await pending
            except asyncio.CancelledError:pass
            assert (await post('result',{**b,'job_id':packet['id'],'result':{'status':200}})).status_code==409
            assert not relay.jobs
            assert (await post('disconnect',b)).status_code==200
            assert (await post('execute',e)).status_code==503
            assert (await post('result',{**b,'job_id':{},'result':{}})).status_code==409
        await relay.close()
    print('PASS native Flow broker: separated browser/engine capabilities, route URL/origin validation, offline refuses before send, cross-route result/replay denied, one dispatch, canceled result not reused, disconnect blocks new work. No provider calls.')

if __name__=='__main__':asyncio.run(main())
