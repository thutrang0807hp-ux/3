"""Read-only model diagnostic privacy check using an intercepted Chromium page."""
import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 script=(Path(__file__).resolve().parents[1]/'scripts/browser-extension/ui-report.js').read_text()
 async with async_playwright()as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context()
  html='''<button aria-haspopup=menu>Omni 1.1 Flash</button><div role=menu><button role=menuitem>Veo 3.1 – Lite</button></div><textarea>PRIVATE_PROMPT_ABC</textarea><input type=password value=SECRET_PASSWORD><button>PRIVATE_PROMPT_ABC</button><span>secret-email@invalid</span><script>window.clicked=0;document.addEventListener('click',()=>window.clicked++);</script>'''
  await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body=html))
  page=await context.new_page();await page.goto('https://flow.google.com/project/PRIVATE_PROJECT?token=SECRET_TOKEN')
  await page.evaluate("globalThis.__sceneForgeDomDiagnostic={adapter:'1.6.2',stage:'model_scan',code:'FLOW_UI_MODEL'}")
  report=await page.evaluate(script+'\nsceneForgeFlowUiReport()')
  encoded=json.dumps(report)
  for secret in ('PRIVATE_PROMPT_ABC','SECRET_PASSWORD','secret-email','PRIVATE_PROJECT','SECRET_TOKEN'):assert secret not in encoded
  assert [c['name']for c in report['controls']]==['Omni 1.1 Flash','Veo 3.1 Lite']
  assert report['last_failure']['stage']=='model_scan'and report['editable_count']==1
  assert await page.evaluate('window.clicked')==0
  await browser.close()
 print('PASS read-only UI report: model names/roles and adapter stage; no prompt, input value, account, project URL or token; zero clicks. Fixture only.')
if __name__=='__main__':asyncio.run(main())
