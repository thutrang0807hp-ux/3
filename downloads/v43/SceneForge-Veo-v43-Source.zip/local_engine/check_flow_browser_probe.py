"""Local browser readiness, identity and stale-port checks; no browser launch."""
import asyncio,tempfile,json
from pathlib import Path
from unittest.mock import patch
import httpx
from .flow_browser_probe import probe_flow_browser
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  data=Path(tmp);profile=data/'browser-profiles/flow-web';profile.mkdir(parents=True)
  (profile/'DevToolsActivePort').write_text('6123\n/devtools/browser/expected-instance\n')
  state={'kind':'valid'};requests=[];original=httpx.AsyncClient
  def handler(request):
   requests.append(request.url.path)
   assert str(request.url)=='http://127.0.0.1:6123/json/version'
   if state['kind']=='closed':raise httpx.ConnectError('fixture unreachable',request=request)
   url='ws://127.0.0.1:6123/devtools/browser/expected-instance'
   if state['kind']=='mismatch':url=url.replace('expected-instance','another-instance')
   if state['kind']=='foreign':url=url.replace('127.0.0.1','external.invalid')
   return httpx.Response(200,json={'Browser':'Chrome/156.0.8078.49','webSocketDebuggerUrl':url})
  def client(**kwargs):
   assert kwargs.get('trust_env')is False and kwargs.get('follow_redirects')is False
   return original(transport=httpx.MockTransport(handler),**kwargs)
  with patch('local_engine.flow_browser_probe.httpx.AsyncClient',new=client):
   assert (await probe_flow_browser(data))['ready']
   for kind,code in [('mismatch','FLOW_BROWSER_INSTANCE_MISMATCH'),('foreign','FLOW_BROWSER_INSTANCE_MISMATCH'),('closed','FLOW_BROWSER_ENDPOINT_UNAVAILABLE')]:
    state['kind']=kind;result=await probe_flow_browser(data);assert not result['ready']and result['code']==code,result
  assert requests==['/json/version']*4
  (profile/'DevToolsActivePort').write_text('0\n/devtools/browser/expected-instance\n')
  assert (await probe_flow_browser(data))['code']=='FLOW_BROWSER_PORT_NOT_READY'
 print('PASS readiness: validates stored browser instance, rejects reused port/foreign endpoint/stale listener, explicit unavailable state; only local json/version reads, zero page or login calls.')
if __name__=='__main__':asyncio.run(main())
