"""Tab attribution regression: stale failures must not defeat the selected login."""
import asyncio,sys,tempfile,types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from fastapi import HTTPException
from .flow_web_login import FlowWebLogin,login_attempt_pages

async def main():
 flow=SimpleNamespace(url='https://flow.google.com/project/fixture',evaluate=AsyncMock(side_effect=['fixture@invalid','Fixture UA']))
 stale=SimpleNamespace(url='https://accounts.google.com/v3/signin/rejected?continue=PRIVATE',opener=AsyncMock(return_value=None))
 context=SimpleNamespace(pages=[stale,flow],cookies=AsyncMock())
 browser=SimpleNamespace(contexts=[context],is_connected=lambda:True)
 target,pages=await login_attempt_pages(browser)
 assert target is flow and [p for _,p in pages]==[flow]
 # Keep tracking the selected tab when its own URL redirects to Google rejection.
 flow.url='https://accounts.google.com/v3/signin/rejected'
 selected,pages=await login_attempt_pages(browser,target)
 assert selected is flow and len(pages)==1
 flow.url='https://flow.google.com/project/fixture'
 popup=SimpleNamespace(url='https://accounts.google.com/v3/signin/rejected',opener=AsyncMock(return_value=flow))
 context.pages.append(popup)
 _,pages=await login_attempt_pages(browser,target)
 assert [p for _,p in pages]==[flow,popup]
 context.pages=[flow,SimpleNamespace(url='https://flow.google.com/project/other')]
 try:await login_attempt_pages(browser)
 except HTTPException:pass
 else:raise AssertionError('Ambiguous Flow tabs accepted')
 context.pages=[]
 try:await login_attempt_pages(browser,target)
 except HTTPException:pass
 else:raise AssertionError('Closed target silently replaced')
 # Exercise the actual watcher with the stale rejected tab ordered first.
 context.pages=[stale,flow]
 pw=SimpleNamespace(chromium=SimpleNamespace(connect_over_cdp=AsyncMock(return_value=browser)),stop=AsyncMock())
 module=types.ModuleType('playwright.async_api');module.async_playwright=lambda:SimpleNamespace(start=AsyncMock(return_value=pw))
 with tempfile.TemporaryDirectory() as tmp:
  manager=FlowWebLogin(Path(tmp),SimpleNamespace(web_ui=True))
  async def imported(*args):manager.state={'state':'done'}
  manager.import_account=AsyncMock(side_effect=imported)
  with patch.dict(sys.modules,{'playwright.async_api':module}),patch('local_engine.flow_browser_probe.probe_flow_browser',new=AsyncMock(return_value={'ready':True,'endpoint':'http://127.0.0.1:12345'})):
   await manager.watch()
   assert manager.status()['state']=='done',manager.status()
   manager.import_account.assert_awaited_once();context.cookies.assert_not_awaited()
   # A real rejection in the only selected tab must remain terminal.
   context.pages=[stale];manager.state={'state':'waiting'};manager.import_account.reset_mock()
   await manager.watch()
   assert manager.status()['code']=='GOOGLE_BROWSER_SIGNIN_REJECTED'
   manager.import_account.assert_not_awaited()
 assert 'PRIVATE' not in str(manager.status())
 print('PASS login tabs: old rejection ignored for selected Flow tab; redirects and auth popup tracked; ambiguous/closed tab stopped; actual selected-tab rejection still terminal. No browser or Google calls.')
if __name__=='__main__':asyncio.run(main())
