"""Per-request observations of owned Flow imports; never retain error text in output."""
from contextvars import ContextVar
from functools import wraps
import re

CURRENT=ContextVar('sceneforge_flow_import_trace',default=None)
STAGE_CODES={'bootstrap':'FLOW_BOOTSTRAP_FAILED','auth':'FLOW_AUTH_HANDSHAKE_FAILED',
 'credits':'FLOW_CREDIT_CHECK_FAILED','identity':'FLOW_IDENTITY_LOOKUP_FAILED',
 'project':'FLOW_PROJECT_SETUP_FAILED','storage':'FLOW_ACCOUNT_SAVE_FAILED',
 'lookup':'FLOW_ACCOUNT_LOOKUP_FAILED','refresh':'FLOW_ACCOUNT_REFRESH_FAILED'}


def status_of(exc):
    seen=set();cursor=exc
    for _ in range(8):
        if cursor is None or id(cursor)in seen:break
        seen.add(id(cursor))
        for value in (getattr(cursor,'status_code',None),getattr(getattr(cursor,'response',None),'status_code',None)):
            if type(value)is int and 100<=value<=599:return value
        # Pinned SDK translates HTTP errors into fixed HTTP/code= messages.
        # Extract only a numeric status, never return or persist provider text.
        match=re.search(r'\b(?:HTTP\s+|code=)([1-5]\d{2})\b',str(cursor)[:8192])
        if match:return int(match[1])
        cursor=cursor.__cause__ or cursor.__context__
    return None


def kind_of(exc):
    name=type(exc).__name__.lower()
    if 'timeout'in name:return 'timeout'
    if 'ssl'in name or 'tls'in name:return 'tls'
    if 'connect'in name or 'network'in name:return 'network'
    if isinstance(exc,(TypeError,AttributeError,ImportError)):return 'sdk'
    if status_of(exc):return 'http'
    return 'provider'


class ImportTrace:
    def __init__(self):
        self.failure=None;self._exception=None;self.completed=[];self.duplicate_id=None
        self.cookies=None;self.session_id=None

    def failed(self,stage,exc):
        cursor=exc;seen=set()
        for _ in range(8):
            if cursor is None or id(cursor)in seen:break
            if cursor is self._exception:return
            seen.add(id(cursor));cursor=cursor.__cause__ or cursor.__context__
        self._exception=exc
        self.failure={'stage':stage,'provider_http_status':status_of(exc),'provider_error_kind':kind_of(exc)}

    def public(self):
        return {**(self.failure or {'stage':'import'}),'completed_steps':list(dict.fromkeys(self.completed))[-12:]}


def observe(engine):
    manager=engine.token_manager
    if getattr(manager,'_sceneforge_import_observed',False):return
    manager._sceneforge_import_observed=True
    def hook(owner,name,stage,mode=None):
        original=getattr(owner,name,None)if owner is not None else None
        if not callable(original):return
        @wraps(original)
        async def call(*args,**kwargs):
            trace=CURRENT.get()
            try:result=await original(*args,**kwargs)
            except Exception as exc:
                if trace:trace.failed(stage,exc)
                raise
            if trace:
                trace.completed.append(stage)
                if mode=='lookup' and result is not None:
                    value=getattr(result,'id',None)
                    if type(value)is int and value>0:trace.duplicate_id=value
                if mode in ('auth','identity')and isinstance(result,dict):
                    if isinstance(result.get('google_cookies'),str):trace.cookies=result['google_cookies']
                    if mode=='identity'and isinstance(result.get('st'),str):trace.session_id=result['st']
            return result
        setattr(owner,name,call)
    client=getattr(manager,'flow_client',None)or getattr(engine,'flow_client',None)
    for name,stage,mode in [('st_to_at','auth','auth'),('_load_flow_frontend_bootstrap','bootstrap',None),('get_credits','credits',None),('create_project','project',None)]:hook(client,name,stage,mode)
    hook(manager,'detect_account_identity','identity','identity')
    hook(manager,'update_token','refresh')
    db=getattr(manager,'db',None)
    if db is not manager:
        for name,stage,mode in [('get_token_by_st','lookup','lookup'),('get_token_by_email','lookup','lookup'),('add_token','storage',None),('add_project','storage',None),('update_token','storage',None)]:hook(db,name,stage,mode)
