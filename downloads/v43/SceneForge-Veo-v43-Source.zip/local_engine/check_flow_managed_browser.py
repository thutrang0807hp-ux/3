"""Persistent app-owned browser login and generation, entirely intercepted fixture.
No extension/Flow2API/private RPC/live Google calls.
"""
import asyncio,base64,hashlib,io,os,subprocess,tempfile,uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from PIL import Image
from playwright.async_api import async_playwright,BrowserContext
from .google_login import open_flow_web_login,flow_profile_path,_FLOW_WEB_PROCESSES
from .flow_managed_driver import FlowManagedDriver
from .flow_extension_driver import FlowExtensionDriver
from .flow_web_login import FlowWebLogin
from .flow_provider import FlowProvider
from .flow_accounts import FlowAccounts
from .request_ledger import RequestLedger
from .vault import Vault
from fastapi import HTTPException

async def main():
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);key='a'*24;movie=root/'fixture.mp4'
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=90x160:d=0.4','-c:v','libx264','-pix_fmt','yuv420p','-y',str(movie)],check=True)
  encoded=base64.b64encode(movie.read_bytes()).decode()
  html='''<script>window.WIZ_global_data={oPEP7c:'fixture@invalid'};window.sent=0;</script><form onsubmit="return false">
  <button type=button aria-haspopup=menu>Veo 3.1 Lite</button><button type=button aria-pressed=true>8s</button><button type=button aria-pressed=true>9:16</button><button type=button aria-pressed=true>x1</button>
  <input type=file accept=image/png><textarea aria-label=Prompt></textarea><button type=button id=generate>Generate</button><div id=preview></div></form><div id=results></div>
  <script>document.querySelector('input').onchange=e=>{const image=new Image();image.src=URL.createObjectURL(e.target.files[0]);document.querySelector('#preview').replaceChildren(image)};
  document.querySelector('#generate').onclick=()=>{window.sent++;const v=document.createElement('video');v.width=90;v.height=160;v.src=URL.createObjectURL(new Blob([Uint8Array.from(atob('MP4'),c=>c.charCodeAt(0))],{type:'video/mp4'}));document.querySelector('#results').append(v)};</script>'''.replace('MP4',encoded)
  shim=root/'test-browser';shim.write_text('#!/bin/sh\nexec /usr/bin/chromium --headless=new --no-sandbox --host-resolver-rules="MAP * ~NOTFOUND" "$@"\n');shim.chmod(0o700)
  with patch.dict(os.environ,{'SCENEFORGE_BROWSER':str(shim)}):await open_flow_web_login(root,auto_connect=True,profile_key=key)
  portfile=flow_profile_path(root,key)/'DevToolsActivePort'
  for _ in range(100):
   if portfile.exists():break
   await asyncio.sleep(.1)
  try:
   async with async_playwright()as pw:
    browser=await pw.chromium.connect_over_cdp('http://127.0.0.1:'+portfile.read_text().splitlines()[0]);context=browser.contexts[0]
    await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body=html))
    old_rejected=context.pages[0];await old_rejected.goto('https://accounts.google.com/v3/signin/rejected')
    page=await context.new_page();await page.goto('https://flow.google.com/project/fixture')
    for other in list(context.pages):
     if other!=page and other!=old_rejected:await other.close()
    vault=Vault(root);ledger=RequestLedger(root)
    def forbidden(*args,**kwargs):raise AssertionError('No extension relay or engine calls allowed')
    provider=FlowProvider(vault,root,ledger,forbidden);accounts=FlowAccounts(provider);provider.account_service=accounts
    managed=FlowManagedDriver(root,vault);accounts.web_ui=provider.web_ui=FlowExtensionDriver(managed,SimpleNamespace(request=forbidden),accounts)
    login=FlowWebLogin(root,accounts);login.profile_key=key
    expected_aid='flow-web-'+hashlib.sha256(b'fixture@invalid').hexdigest()[:24]
    revoked=[];accounts.native_relay=SimpleNamespace(revoke=revoked.append)
    vault.set_secret('flow-extension-ui',{'account_id':expected_aid,'route_id':'old-route','email':'fixture@invalid'})
    async def no_cookies(*args,**kwargs):raise AssertionError('No cookie export allowed')
    with patch.object(BrowserContext,'cookies',new=no_cookies):
     await login.import_account([],{},'fixture@invalid')
     aid=login.status()['account_id'];assert login.status()['state']=='done'
     connected_worker=managed.workers[aid]['session']
     assert managed.binding(aid)['profile_key']==key and provider.status()['connection_method']=='managed_browser'
     assert not vault.secret('flow-extension-ui')and not vault.secret('flow-ui-profile')
     assert revoked==['old-route']
     # Restarting login reuses the saved profile and actual open browser.
     async def no_extra_window(*args,**kwargs):raise AssertionError('Must reuse saved profile/browser')
     with patch('local_engine.flow_web_login.open_flow_web_login',new=no_extra_window):
      await login.start();await asyncio.wait_for(login.task,15)
     assert login.status()['state']=='done',login.status()
     await old_rejected.close()
     assert len(context.pages)==1
     # A UI-only account must be ready without a Flow2API key/engine instance.
     from .browser_bridge import BrowserBridge
     bridge=object.__new__(BrowserBridge);bridge.flow=accounts
     bridge.gemini=SimpleNamespace(vault=vault,pool=SimpleNamespace(status=lambda:{'account_id':None,'account_name':None,'available':False,'mode':'selected'}))
     assert bridge.google_status()['services']['flow']['ready'] is True
     # Old route metadata must not override the explicit live UI binding.
     row=next(a for a in accounts.pool.rows() if a['id']==aid)
     vault.put('accounts',{**row,'native_route_id':'stale-route-must-not-be-used'})
     image=io.BytesIO();Image.new('RGB',(90,160),'green').save(image,format='PNG')
     body={'request_id':'flow-'+str(uuid.uuid4()),'kind':'video','model':provider.status()['models'][0],'prompt':'Cô ấy vẫy tay.','references':[{'mime_type':'image/png','data':base64.b64encode(image.getvalue()).decode()}],'confirm_send':True,'selection_token':accounts.pool.status()['token']}
     await provider.submit(body)
     for _ in range(200):
      entry=provider.lookup(body['request_id'])
      if entry['state']in ('done','failed','unknown'):break
      await asyncio.sleep(.1)
     assert entry['state']=='done',entry
     assert managed.workers[aid]['session'] is connected_worker
     assert (provider.root/entry['result']['file']).read_bytes()==movie.read_bytes()
     assert await page.evaluate('window.sent')==1
     await provider.submit(body);assert await page.evaluate('window.sent')==1
     # A fresh request must reuse the connection but not stale DOM result state.
     body={**body,'request_id':'flow-'+str(uuid.uuid4())}
     await provider.submit(body)
     for _ in range(200):
      second=provider.lookup(body['request_id'])
      if second['state'] in ('done','failed','unknown'):break
      await asyncio.sleep(.1)
     assert second['state']=='done',second
     assert managed.workers[aid]['session'] is connected_worker
     assert await page.evaluate('window.sent')==2
     assert (provider.root/second['result']['file']).read_bytes()==movie.read_bytes()
     assert (vault.secret('flow-managed-profiles')or{})[aid].get('project_hash')
     # Other project: refuse before any click, preserve the original binding.
     await page.goto('https://flow.google.com/project/other')
     body={**body,'request_id':'flow-'+str(uuid.uuid4())}
     await provider.submit(body)
     for _ in range(100):
      entry=provider.lookup(body['request_id'])
      if entry['state']in ('done','failed','unknown'):break
      await asyncio.sleep(.1)
     assert entry['state']=='failed'and await page.evaluate('window.sent')==0,entry
     row=next(a for a in accounts.pool.rows() if a['id']==aid);row.pop('native_route_id',None);vault.put('accounts',row)
     # Account changes fail verification, rather than switching silently.
     await page.evaluate("window.WIZ_global_data.oPEP7c='other@invalid'")
     assert (await accounts.check(aid))['ok']is False
     # Google's explicit insecure-browser sign-in response is terminal, not retried.
     await context.route('https://accounts.google.com/**',lambda r:r.fulfill(status=200,content_type='text/html',body='<p>Đăng nhập bị từ chối.</p>'))
     await page.goto('https://accounts.google.com/v3/signin/rejected?continue=fixture')
     await login.start();await asyncio.wait_for(login.task,15)
     assert login.status()['code']=='GOOGLE_BROWSER_SIGNIN_REJECTED',login.status()
     assert len(context.pages)==1
    await provider.close();assert not managed.workers
    assert browser.is_connected(), 'App cleanup must keep the user browser open'
    await browser.close()
   try:flow_profile_path(root,'../escape')
   except HTTPException:pass
   else:raise AssertionError('Unsafe profile path accepted')
   print('PASS managed browser: saved per-account profile; login watcher reuses real browser; no extension/cookie export/engine; one image+prompt -> single submit -> chunks/hash/ffprobe -> app result; duplicate ID; project/account change guarded; explicit Google sign-in denial stops. Intercepted fixture, not live Google or Windows.')
  finally:
   for process in _FLOW_WEB_PROCESSES:
    if process.poll()is None:process.terminate()
if __name__=='__main__':asyncio.run(main())
