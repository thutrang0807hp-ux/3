"""Real Chromium/CDP automatic detection using a fully intercepted Flow fixture."""
import asyncio,os,tempfile,json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from playwright.async_api import async_playwright
from .google_login import open_flow_web_login,_FLOW_WEB_PROCESSES
from .flow_web_login import FlowWebLogin
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  data=Path(tmp);shim=data/'browser-test'
  shim.write_text('#!/bin/sh\nexec /usr/bin/chromium --headless=new --no-sandbox --host-resolver-rules="MAP * ~NOTFOUND" "$@"\n');shim.chmod(0o700)
  with patch.dict(os.environ,{'SCENEFORGE_BROWSER':str(shim)}):await open_flow_web_login(data,auto_connect=True)
  portfile=data/'browser-profiles/flow-web/DevToolsActivePort'
  for _ in range(100):
   if portfile.exists():break
   await asyncio.sleep(.1)
  port=int(portfile.read_text().splitlines()[0])
  async with async_playwright()as pw:
   browser=await pw.chromium.connect_over_cdp('http://127.0.0.1:'+str(port))
   context=browser.contexts[0]
   await context.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body='<html><script type="application/json">'+json.dumps({'oPEP7c':'fixture@invalid'})+'</script></html>'))
   page=await context.new_page();await page.goto('https://flow.google.com/project/fixture?authuser=1')
   await context.add_cookies([{'name':'OSID','value':'fixture-only','domain':'flow.google.com','path':'/','secure':True}])
   accounts=SimpleNamespace(pool=SimpleNamespace(rows=lambda:[]),import_session=AsyncMock(return_value={'imported_account_id':'flow-engine-1'}),check=AsyncMock(return_value={'ok':True}))
   manager=FlowWebLogin(data,accounts)
   await asyncio.wait_for(manager.watch(),20)
   assert manager.status()['state']=='done',manager.status()
   assert accounts.import_session.await_count==1 and accounts.check.await_count==1
   assert portfile.exists(),'Login profile removed'
   await browser.close()
  for proc in _FLOW_WEB_PROCESSES:
   if proc.poll()is None:proc.terminate()
   await asyncio.to_thread(proc.wait,timeout=10)
  print('PASS real Chromium loopback CDP -> intercepted Flow login -> automatic import/check; persistent profile retained; zero Google requests')
asyncio.run(main())
