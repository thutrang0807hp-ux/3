"""Automatic login fixture: detect, import/check once, never generate or expose cookies."""
import asyncio,tempfile,sys,types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from .flow_web_login import FlowWebLogin
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  data=Path(tmp);profile=data/'browser-profiles/flow-web';profile.mkdir(parents=True);(profile/'DevToolsActivePort').write_text('12345\n/devtools/fixture')
  accounts=SimpleNamespace(pool=SimpleNamespace(rows=lambda:[]),import_session=AsyncMock(return_value={'imported_account_id':'flow-engine-7'}),check=AsyncMock(return_value={'ok':True}))
  page=SimpleNamespace(url='https://flow.google.com/project/fixture?authuser=1',evaluate=AsyncMock(side_effect=['user@invalid','Fixture UA']))
  context=SimpleNamespace(pages=[page],cookies=AsyncMock(return_value=[{'name':'OSID','value':'PRIVATE_TEST_COOKIE','domain':'flow.google.com'},{'name':'unrelated','value':'other','domain':'unrelated.invalid'}]))
  browser=SimpleNamespace(contexts=[context]);connect=AsyncMock(return_value=browser)
  pw=SimpleNamespace(chromium=SimpleNamespace(connect_over_cdp=connect),stop=AsyncMock())
  module=types.ModuleType('playwright.async_api');module.async_playwright=lambda:SimpleNamespace(start=AsyncMock(return_value=pw))
  login=FlowWebLogin(data,accounts)
  with patch.dict(sys.modules,{'playwright.async_api':module}),patch('local_engine.flow_browser_probe.probe_flow_browser',new=AsyncMock(return_value={'ready':True,'endpoint':'http://127.0.0.1:12345','code':'FLOW_BROWSER_READY'})):
   await login.watch()
  assert login.status()['state']=='done' and accounts.import_session.await_count==1 and accounts.check.await_count==1
  assert 'PRIVATE_TEST_COOKIE'not in str(login.status())
  cookies=accounts.import_session.call_args.args[0];assert len(cookies)==1
  assert accounts.import_session.call_args.kwargs['browser_context']['authuser']=='1'
  assert connect.call_args.args[0]=='http://127.0.0.1:12345';pw.stop.assert_awaited_once()
  accounts.check=AsyncMock(return_value={'ok':False})
  try:await login.import_account(cookies,{})
  except Exception:pass
  else:raise AssertionError('Unverified account accepted')
  accounts.pool.rows=lambda:[{'name':'user@invalid','id':'flow-engine-7','native_route_id':'keep-existing-route'}]
  accounts.check=AsyncMock(return_value={'ok':True});before=accounts.import_session.await_count
  await login.import_account(cookies,{},'user@invalid');assert accounts.import_session.await_count==before
  async def pending():await asyncio.sleep(60)
  with patch('local_engine.flow_web_login.open_flow_web_login',new=AsyncMock())as opened,patch.object(login,'watch',new=pending):
   await login.start();await login.start();assert opened.await_count==1
   await login.close()
  print('PASS auto detection/import/check, safe status, cookie scoping, existing native route preserved, duplicate start blocked; no generation calls')
asyncio.run(main())
