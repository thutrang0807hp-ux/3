"""Chromium fixture reproducing screenshot: Video/Frames, 16:9+x2 and 8s summary."""
import asyncio,base64,io,json
from pathlib import Path
from PIL import Image
from playwright.async_api import async_playwright
async def main():
 source=(Path(__file__).resolve().parents[1]/'scripts/browser-extension/dom-flow.js').read_text()
 html='''<form onsubmit="return false"><textarea></textarea><input type=file accept=image/png><div id=preview></div><button type=button id=summary aria-label="Cài đặt" aria-haspopup=menu aria-expanded=false>Video · 720p · 8 giây x2</button><button type=button id=generate aria-label="Tạo">➜</button></form>
 <section id=panel role=menu hidden><button aria-selected=true>Video</button><button aria-selected=true>Khung hình</button><button id=landscape aria-checked=true>16:9</button><button id=portrait aria-label="Portrait setting" aria-checked=false>9:16</button><button aria-haspopup=menu aria-label="Model">Veo 3.1 – Lite</button><button id=one aria-label="Number of outputs" aria-checked=false>x1</button><button id=two aria-checked=true>x2</button></section>
 <script>window.sent=0;window.opened=0;
 const s=document.querySelector('#summary'),p=document.querySelector('#panel');s.onclick=()=>{window.opened++;p.hidden=false;s.setAttribute('aria-expanded','true')};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){p.hidden=true;s.setAttribute('aria-expanded','false')}});
 document.querySelector('#portrait').onclick=e=>{if(window.ignoreRatio)return;e.target.setAttribute('aria-checked','true');document.querySelector('#landscape').setAttribute('aria-checked','false')};
 document.querySelector('#one').onclick=e=>{if(window.ignoreQuantity)return;e.target.setAttribute('aria-checked','true');document.querySelector('#two').setAttribute('aria-checked','false');s.textContent=s.textContent.replace('x2','x1')};
 document.querySelector('input').onchange=e=>{const image=new Image();image.src=URL.createObjectURL(e.target.files[0]);document.querySelector('#preview').replaceChildren(image)};
 document.querySelector('#generate').onclick=()=>window.sent++;</script>'''
 image=io.BytesIO();Image.new('RGB',(90,160),'green').save(image,format='PNG')
 request={'action':'prepare','request_id':'screenshot-controls','prompt':'Cô ấy mỉm cười và vẫy tay.','image':{'mime_type':'image/png','data':base64.b64encode(image.getvalue()).decode()}}
 async with async_playwright()as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context();await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body=html))
  page=await context.new_page();await page.goto('https://flow.google.com/project/fixture')
  async def call(req):return await page.evaluate(source+'\nsceneForgeDomFlow('+json.dumps(req)+')')
  result=await call(request);assert result['status']==200,result
  assert await page.locator('#portrait').get_attribute('aria-checked')=='true'
  assert await page.locator('#one').get_attribute('aria-checked')=='true'
  assert await page.locator('textarea').input_value()==request['prompt']
  assert await page.evaluate('window.sent===0 && window.opened===1')
  await call({'action':'submit','request_id':request['request_id']});assert await page.evaluate('window.sent')==1
  # Wrong duration summary must stop even when the desired ratio/quantity exist.
  await page.reload();await page.locator('#summary').evaluate('(e)=>e.textContent=e.textContent.replace("8 giây","6 giây")')
  result=await call({**request,'request_id':'wrong-duration'});assert result['code']=='FLOW_UI_SETTINGS'and await page.evaluate('window.sent')==0
  # Click handlers that do not update selected state must never submit.
  await page.reload();await page.evaluate('window.ignoreQuantity=true')
  result=await call({**request,'request_id':'quantity-ignored'});assert result['code']=='FLOW_UI_SETTINGS'and await page.evaluate('window.sent')==0
  await browser.close()
 print('PASS screenshot-shaped composer: summary 8s; selects 9:16 + x1; one image + actual prompt prepared; no click before submit; 6s and ignored x1 refuse. Intercepted fixture only.')
if __name__=='__main__':asyncio.run(main())
