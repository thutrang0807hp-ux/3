"""Bounded image copies for outbound transport; originals are never overwritten."""
import base64,binascii,io
from PIL import Image,ImageOps
from fastapi import HTTPException

LIMIT=6*1024**2

def prepare_image(value,limit=LIMIT):
    if not isinstance(value,dict)or value.get('mime_type')not in {'image/png','image/jpeg','image/webp'}or not isinstance(value.get('data'),str)or len(value['data'])>32*1024**2:
        raise HTTPException(400,'Ảnh PNG/JPEG/WebP đầu vào tối đa 24 MB để chuẩn bị bản gửi.')
    try:
        raw=base64.b64decode(value['data'],validate=True)
        if len(raw)>24*1024**2:raise ValueError()
        with Image.open(io.BytesIO(raw))as source:
            if source.width*source.height>40_000_000 or Image.MIME.get(source.format)!=value['mime_type']:raise ValueError()
            source.verify()
        if len(raw)<=limit:return dict(value)
        with Image.open(io.BytesIO(raw))as source:
            source.load();image=ImageOps.exif_transpose(source)
            alpha='A'in image.getbands()or 'transparency'in image.info
            image=image.convert('RGBA'if alpha else'RGB')
            for edge in (max(image.size),2560,1920,1280):
                copy=image.copy();copy.thumbnail((edge,edge),Image.Resampling.LANCZOS)
                for quality in (94,88,80):
                    out=io.BytesIO();copy.save(out,format='WEBP'if alpha else'JPEG',quality=quality)
                    if out.tell()<=limit:return {'mime_type':'image/webp'if alpha else'image/jpeg','data':base64.b64encode(out.getvalue()).decode()}
    except (ValueError,binascii.Error,OSError,Image.DecompressionBombError):
        raise HTTPException(400,'Ảnh không đọc được, sai định dạng hoặc vượt giới hạn điểm ảnh.')from None
    raise HTTPException(400,'Không chuẩn bị được bản ảnh gửi dưới 6 MB; bản gốc vẫn được giữ.')


def prepare_images(values):
    if not isinstance(values,list)or len(values)>8:raise HTTPException(400,'Tối đa 8 ảnh tham chiếu.')
    if sum(len(v.get('data',''))if isinstance(v,dict)and isinstance(v.get('data'),str)else 0 for v in values)>64*1024**2:raise HTTPException(400,'Tổng ảnh đầu vào quá lớn để chuẩn bị bản gửi.')
    prepared=[prepare_image(v)for v in values]
    if sum(len(base64.b64decode(v['data']))for v in prepared)>24*1024**2:
        prepared=[prepare_image(v,24*1024**2//len(values))for v in values]
    return prepared
