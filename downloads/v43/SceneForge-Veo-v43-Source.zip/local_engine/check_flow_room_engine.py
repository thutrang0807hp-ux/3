"""Exercise owned account/room middleware and journal together; no Google calls."""
import asyncio,json,sys,tempfile,types,uuid,hashlib
from pathlib import Path
from types import SimpleNamespace
import httpx
from fastapi import FastAPI,Header,HTTPException

async def main():
    names=['src','src.core','src.core.auth','src.core.config','src.services','src.services.generation_handler'];saved={k:sys.modules.get(k)for k in names}
    for k in names:sys.modules[k]=types.ModuleType(k)
    async def auth(authorization:str=Header(default='')):
        if authorization!='Bearer fixture':raise HTTPException(401)
    sys.modules['src.core.auth'].verify_api_key_header=auth
    sys.modules['src.core.auth'].AuthManager=SimpleNamespace(verify_api_key=lambda k:k=='fixture')
    sys.modules['src.core.config'].config=SimpleNamespace(flow_max_retries=1)
    sys.modules['src.services.generation_handler'].MODEL_CONFIG={'text-only':{'video_type':'t2v','type':'video','supports_images':False},'frame-model':{'video_type':'i2v','type':'video','supports_images':True,'max_images':2}}
    try:
        from .flow_account_engine import extend,PIN
        calls=[]
        class Client:
            async def create_project(self,st,title,google_cookies=None):calls.append((st,title));await asyncio.sleep(.01);return 'project-'+str(len(calls))
        class Manager:
            def __init__(self):self.flow_client=Client()
            async def get_active_tokens(self):return [await self.get_token(i)for i in [1,2]]
            async def get_token(self,i):return SimpleNamespace(id=i,email=str(i)+'@invalid',is_active=True,st='fixture-'+str(i),google_cookies='[]')
            async def ensure_project_exists(self,i):raise AssertionError('Legacy project pool used')
        def build(path):
            e=SimpleNamespace(app=FastAPI(),token_manager=Manager())
            @e.app.get('/v1/models')
            async def models():return {'data':[{'id':'text-only'},{'id':'frame-model'}]}
            extend(e,path)
            @e.app.post('/v1/chat/completions')
            async def generate():
                rows=await e.token_manager.get_active_tokens();assert len(rows)==1
                return {'project':await e.token_manager.ensure_project_exists(PIN.get()),'account':rows[0].id}
            return e
        with tempfile.TemporaryDirectory()as tmp:
            path=Path(tmp)/'tasks.sqlite';e=build(path)
            async def submit(client,room='room1',account=1,rid=None,model='frame-model'):
                h={'Authorization':'Bearer fixture','X-SceneForge-Account':str(account),'X-SceneForge-Room':hashlib.sha256(room.encode()).hexdigest(),'X-SceneForge-Request':rid or'flow-'+str(uuid.uuid4())}
                return await client.post('/v1/chat/completions',headers=h,json={'model':model,'messages':[{'role':'user','content':[{'type':'image_url','image_url':{'url':'data:image/png;base64,fixture'}}]}]})
            async with httpx.AsyncClient(transport=httpx.ASGITransport(e.app),base_url='http://fixture')as c:
                catalog=(await c.get('/v1/models')).json()['data']
                assert [m['sceneforge_accepts_images']for m in catalog]==[False,True]
                assert catalog[1]['sceneforge_video_type']=='i2v'
                assert catalog[1]['sceneforge_inputs']['second_image']=='end'
                responses=await asyncio.gather(*(submit(c)for _ in range(5)))
                assert all(r.status_code==200 for r in responses),[r.text for r in responses]
                p=responses[0].json()['project'];assert all(r.json()['project']==p for r in responses)and len(calls)==1
                assert(await submit(c,room='room2')).json()['project']!=p
                assert(await submit(c,account=2)).json()['project']!=p
                rid='flow-'+str(uuid.uuid4());assert(await submit(c,rid=rid)).status_code==200
                assert(await submit(c,room='room2',rid=rid)).status_code==409
                before=len(calls);bad=await submit(c,model='text-only');assert bad.status_code==422 and 'I2V'in bad.text and len(calls)==before
            e=build(path)
            async with httpx.AsyncClient(transport=httpx.ASGITransport(e.app),base_url='http://fixture')as c:
                assert(await submit(c)).json()['project']==p and len(calls)==3
        print('PASS actual owned middleware + durable journal: concurrent clips share one project; restart preserves binding; rooms/accounts separate; cross-room request identity rejected; text-only model blocked before journal or creation. Synthetic provider only; no Google requests.')
    finally:
        for k,v in saved.items():
            if v is None:sys.modules.pop(k,None)
            else:sys.modules[k]=v
if __name__=='__main__':asyncio.run(main())
