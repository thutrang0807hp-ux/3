"""Agent defaults -> Save -> composer -> generation controls; intercepted fixture."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 source=(Path(__file__).resolve().parents[1]/'scripts/browser-extension/dom-flow.js').read_text()
 html='''<section id=defaults role=menu><h2>Agent settings</h2><button aria-checked=false>x1</button><button aria-checked=true>x1</button><button aria-haspopup=menu aria-label="Video model">Veo 3.1 – Lite</button><button id=save>Save</button></section>
 <form id=composer hidden onsubmit="return false"><textarea></textarea><button type=button id=agent aria-pressed=true aria-label="Mode">Agent</button><button type=button id=settings aria-label="Cài đặt"></button></form>
 <section role=dialog id=generation hidden><button aria-haspopup=menu aria-label="Model">Veo 3.1 – Lite</button><button id=duration aria-pressed=true>8s</button><button aria-pressed=true>9:16</button><button aria-pressed=true>x1</button></section>
 <script>window.saved=0;window.opened=0;window.toggled=0;
 document.querySelector('#save').onclick=()=>{window.saved++;if(window.ignoreSave)return;document.querySelector('#defaults').hidden=true;document.querySelector('#composer').hidden=false;};
 document.querySelector('#agent').onclick=e=>{window.toggled++;e.target.setAttribute('aria-pressed','false');};
 document.querySelector('#settings').onclick=()=>{window.opened++;document.querySelector('#generation').hidden=false;};</script>'''
 async with async_playwright()as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context();await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body=html))
  page=await context.new_page();await page.goto('https://flow.google.com/project/fixture')
  result=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"defaults-to-generation"})')
  assert result['code']=='FLOW_UI_IMAGE',result
  assert await page.evaluate('window.saved===1&&window.toggled===1&&window.opened===1')
  await page.reload();await page.evaluate('window.ignoreSave=true')
  result=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"save-ignored"})')
  assert result['code']=='FLOW_UI_SETTINGS'and await page.evaluate('window.opened')==0
  await page.reload();await page.locator('#duration').evaluate('(e)=>e.remove()')
  result=await page.evaluate(source+'\nsceneForgeDomFlow({action:"prepare",request_id:"duration-missing"})')
  assert result['code']=='FLOW_UI_SETTINGS',result
  assert await page.evaluate('window.saved')==1
  await browser.close()
 print('PASS: duplicate x1 in Agent defaults not treated as generation settings; Save -> editor -> Agent OFF -> generation pane; ignored Save and missing duration halt before upload/submit. Fixture only.')
if __name__=='__main__':asyncio.run(main())
