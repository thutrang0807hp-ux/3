"""Read-only error recovery and sanitized engine error persistence, no Google calls."""
import asyncio,tempfile,types,sys,uuid,hashlib,json
from pathlib import Path
from types import SimpleNamespace
from fastapi import FastAPI,Header,HTTPException
from fastapi.responses import JSONResponse
import httpx
from .flow_task_journal import install_journal,safe_failure
from .flow_provider import FlowProvider
from .vault import Vault
from .request_ledger import RequestLedger

async def main():
 names=['src','src.core','src.core.auth'];saved={k:sys.modules.get(k)for k in names}
 for k in names:sys.modules[k]=types.ModuleType(k)
 async def auth(authorization:str=Header(default='')):
  if authorization!='Bearer fixture':raise HTTPException(401)
 sys.modules['src.core.auth'].AuthManager=SimpleNamespace(verify_api_key=lambda k:k=='fixture');sys.modules['src.core.auth'].verify_api_key_header=auth
 try:
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);app=FastAPI();calls=[];mode={'success':False}
   @app.post('/v1/chat/completions')
   async def generate():
    calls.append('generation')
    if mode['success']:return {'url':'http://127.0.0.1:8766/result'}
    return JSONResponse({'error':{'message':'captcha verification required PRIVATE_COOKIE=secret'}},status_code=403)
   journal=install_journal(SimpleNamespace(app=app),root/'engine.sqlite')
   rid='flow-'+str(uuid.uuid4());headers={'Authorization':'Bearer fixture','X-SceneForge-Account':'7','X-SceneForge-Request':rid}
   async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://fixture')as c:
    await c.post('/v1/chat/completions',headers=headers,json={'model':'fixture','messages':[]})
    for _ in range(2):
     row=(await c.get('/sceneforge/tasks/'+rid,headers={'Authorization':'Bearer fixture'})).json()
     assert row['state']=='failed'and row['code']=='CAPTCHA_REQUIRED'and 'secret'not in str(row),row
    assert calls==['generation']
    await c.post('/v1/chat/completions',headers=headers,json={'model':'fixture','messages':[]})
    assert calls==['generation'],'Failed original ID generated twice'
    assert 'PRIVATE_COOKIE'not in journal.read(rid)['response']
    old='flow-'+str(uuid.uuid4());journal.claim(old,7,'legacy');journal.finish(old,'failed')
    row=(await c.get('/sceneforge/tasks/'+old,headers={'Authorization':'Bearer fixture'})).json();assert row['code']=='ENGINE_ERROR_DETAILS_NOT_SAVED'
    journal.trace(old,'error','native_bridge','eb1hJf',200,'PUBLIC_ERROR_UNUSUAL_ACTIVITY')
    row=(await c.get('/sceneforge/tasks/'+old,headers={'Authorization':'Bearer fixture'})).json()
    assert row['code']=='PUBLIC_ERROR_UNUSUAL_ACTIVITY',row
    mode['success']=True;completed='flow-'+str(uuid.uuid4());success_headers={**headers,'X-SceneForge-Request':completed}
    assert (await c.post('/v1/chat/completions',headers=success_headers,json={'model':'fixture','messages':[]})).status_code==200
    result=(await c.get('/sceneforge/tasks/'+completed,headers={'Authorization':'Bearer fixture'})).json();assert result['state']=='done'and result['response']['url']=='http://127.0.0.1:8766/result'
    assert (await c.post('/v1/chat/completions',headers=success_headers,json={'model':'fixture','messages':[]})).status_code==200 and len(calls)==2
   local=root/'local';local.mkdir();vault=Vault(local);ledger=RequestLedger(local);rid='flow-'+str(uuid.uuid4());ledger.claim(rid,{'original':'sent'});ledger.finish(rid,'unknown');requests=[]
   remote={'state':'failed','account_id':7,**safe_failure(403,'captcha PRIVATE_COOKIE=secret')}
   async def transport(request):
    requests.append(request.method);assert request.method=='GET'
    return httpx.Response(200,json=remote)
   provider=FlowProvider(vault,local,ledger,lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)));provider.configure({'url':'http://127.0.0.1:8766','key':'fixture-private-engine-key'})
   cfg=provider.config();ledger.set_metadata(rid,{'engine_id':7,'account_id':'A','engine_instance':hashlib.sha256((cfg['url']+cfg['key']).encode()).hexdigest()})
   result=await provider.reconcile(rid);assert result['reconciliation']=='failed'and result['code']=='CAPTCHA_REQUIRED'and result['state']=='failed'
   assert provider.lookup(rid)['code']=='CAPTCHA_REQUIRED' and provider.lookup(rid)['state']=='failed'
   assert vault.rows('logs')[0]['service']=='flow'and vault.rows('logs')[0]['account_id']=='A'
   remote['account_id']=8
   try:await provider.reconcile(rid)
   except HTTPException as e:assert e.status_code==409
   else:raise AssertionError('Mismatched engine account accepted')
   assert all(m=='GET'for m in requests)
  print('PASS engine failures retain sanitized cause across reads; old missing cause identified; raw credentials never stored; local reconcile/lookup expose cause, correct service/account log, original-account mismatch rejected; no recovery generation')
 finally:
  for k,v in saved.items():
   if v is None:sys.modules.pop(k,None)
   else:sys.modules[k]=v
if __name__=='__main__':asyncio.run(main())
