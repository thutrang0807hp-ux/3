"""Missing browser binding must reject before engine checks or generation."""
import asyncio,tempfile,uuid
from pathlib import Path
from types import SimpleNamespace
from fastapi import HTTPException
from .flow_provider import FlowProvider
from .vault import Vault
from .request_ledger import RequestLedger
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);vault=Vault(root);ledger=RequestLedger(root)
  def forbidden():raise AssertionError('Engine/browser must not be called')
  p=FlowProvider(vault,root,ledger,forbidden)
  p.account_service=SimpleNamespace(pool=SimpleNamespace(status=lambda:{'account_id':'web'},rows=lambda:[{'id':'web','native_route_id':None}]))
  try:await p.submit({'request_id':'flow-'+str(uuid.uuid4()),'confirm_send':True,'kind':'video'})
  except HTTPException as exc:assert exc.status_code==409 and 'không mở cửa sổ'in str(exc.detail)
  else:raise AssertionError('Unbound web session submitted')
  print('PASS unbound web login rejected before engine/preflight/browser launch; no generation request')
asyncio.run(main())
