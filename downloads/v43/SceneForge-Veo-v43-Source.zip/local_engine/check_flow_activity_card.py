"""Unusual-activity tile detection, no alert role, no retries or prompt false positive."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 source=(Path(__file__).resolve().parents[1]/'scripts/browser-extension/dom-flow.js').read_text()
 async with async_playwright()as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context();await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html; charset=utf-8',body='<html><body></body></html>'))
  page=await context.new_page();await page.goto('https://flow.google.com/project/fixture')
  async def command(action):return await page.evaluate(source+'\nsceneForgeDomFlow({action:"'+action+'",request_id:"flow-test"})')
  await page.set_content('<div><div>Không thành công</div><div>Chúng tôi nhận thấy có hoạt động bất thường nào đó. Xin lưu ý rằng các tiện ích trình duyệt sửa đổi trang có thể gây ra vấn đề.</div><button onclick="window.clicked++">Retry</button></div>')
  await page.evaluate('window.clicked=0')
  result=await command('prepare');assert result['code']=='FLOW_UI_VERIFY'and result['uncertain']is False,result
  await page.evaluate("globalThis.__sceneForgeDomJobs.set('flow-test',{page:location.href,sent:true,prepared:true})")
  result=await command('status');assert result['code']=='FLOW_UI_VERIFY'and result['uncertain']is True,result
  assert 'bất thường'not in str(result)and await page.evaluate('window.clicked')==0
  assert (await command('release'))['status']==200
  assert await page.evaluate('globalThis.__sceneForgeDomJobs.size')==0
  # Hidden card or the same text inside an editor must not trigger detection.
  await page.set_content('<div hidden><div>Failed</div><p>Unusual activity</p><button>Retry</button></div><div contenteditable=true><span>Không thành công</span><p>hoạt động bất thường</p><button>Retry</button></div>')
  result=await command('prepare');assert result.get('code')!='FLOW_UI_VERIFY',result
  await browser.close()
 print('PASS unusual-activity card without alert role: preflight stops, post-submit uncertainty preserved, zero Retry clicks, cleanup works, hidden/editor text excluded. Fixture only.')
if __name__=='__main__':asyncio.run(main())
