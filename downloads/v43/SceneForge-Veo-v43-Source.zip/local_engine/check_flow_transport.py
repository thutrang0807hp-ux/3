"""Actual pinned Flow client + curl_cffi over isolated loopback TLS.

No provider/session fixtures are sent to Google. The local server requires RPC
path cookies, account selection, browser UA and XSRF; it returns 401 otherwise.
"""
import asyncio,json,ssl,sys,tempfile,threading,types
from contextlib import contextmanager
from datetime import datetime,timedelta,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import parse_qs,urlsplit
from unittest.mock import patch

from .flow_browser_context import install,envelope,context_of,ACTIVE,account_url,clean_context


async def main(source):
    # Only the test TLS certificate helper comes from the app runtime.
    # The actual curl/SDK dependencies come from the isolated Flow engine.
    if len(sys.argv)>2:sys.path.append(sys.argv[2])
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes,serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    sys.path.insert(0,str(source))
    # Load the real transport modules without unrelated generation/browser services.
    for package,folder in [('src',source/'src'),('src.core',source/'src/core'),('src.services',source/'src/services')]:
        module=types.ModuleType(package);module.__path__=[str(folder)];sys.modules[package]=module
    from curl_cffi import CurlOpt
    from curl_cffi.requests import AsyncSession
    from src.services.flow_client import FlowClient
    events=[]
    class Server(BaseHTTPRequestHandler):
        def log_message(self,*a):pass
        def respond(self,status,body,headers=()):
            data=body.encode();self.send_response(status)
            for k,v in headers:self.send_header(k,v)
            self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        def do_GET(self):
            index=parse_qs(urlsplit(self.path).query).get('authuser',['0'])[0]
            events.append(('get',index,self.headers.get('User-Agent')))
            self.respond(200,'boq_labs-ai-sandbox-frontend_20261007.14_p0 {"FdrFJe":"123","SNlM0e":"xsrf-'+index+'","oPEP7c":"fixture-'+index+'@invalid"}', [('Set-Cookie','OSID=rotated-'+index+'; Path=/; Secure; HttpOnly')])
        def do_POST(self):
            parsed=urlsplit(self.path);index=parse_qs(parsed.query).get('authuser',['0'])[0]
            body=parse_qs(self.rfile.read(int(self.headers.get('Content-Length',0))).decode())
            cookies=self.headers.get('Cookie','');ua=self.headers.get('User-Agent')
            accepted=(index in ('1','2') and 'RPC_ONLY=rpc-'+index in cookies and 'OSID=rotated-'+index in cookies and ua=='SceneForge-Contract-Chrome/'+index and body.get('at')==['xsrf-'+index])
            # Unrelated path credentials must never reach this request.
            assert 'PAGE_ONLY'not in cookies
            events.append(('post',index,accepted))
            payload=[["wrb.fr","nzlxg","[42]"]]if accepted else [["er",None,None,None,None,401]]
            self.respond(200,json.dumps(payload))
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp);key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'flow.google.com')])
        cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=1)).add_extension(x509.SubjectAlternativeName([x509.DNSName('flow.google.com')]),critical=False).add_extension(x509.BasicConstraints(ca=True,path_length=None),critical=True).sign(key,hashes.SHA256()))
        (tmp/'cert.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM));(tmp/'key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        server=ThreadingHTTPServer(('127.0.0.1',0),Server);tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);tls.load_cert_chain(tmp/'cert.pem',tmp/'key.pem');server.socket=tls.wrap_socket(server.socket,server_side=True)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        class LocalSession(AsyncSession):
            def __init__(self,**kw):
                options=kw.setdefault('curl_options',{});options[CurlOpt.RESOLVE]=['flow.google.com:'+str(server.server_port)+':127.0.0.1']
                options[CurlOpt.PROXY]='';kw['verify']=str(tmp/'cert.pem')
                super().__init__(**kw)
            async def request(self,method,url,**kw):
                parsed=urlsplit(url);assert parsed.hostname=='flow.google.com'
                url=parsed._replace(netloc='flow.google.com:'+str(server.server_port)).geturl()
                return await super().request(method,url,**kw)
        session=LocalSession
        def storage(index,include_rpc=True):
            cookies=[{'name':'SID','value':'fixture-'+index,'domain':'.google.com','path':'/','secure':True}, {'name':'OSID','value':'old-'+index,'domain':'flow.google.com','hostOnly':True,'path':'/','secure':True}, {'name':'PAGE_ONLY','value':'page','domain':'flow.google.com','hostOnly':True,'path':'/projects','secure':True}]
            if include_rpc:cookies.append({'name':'RPC_ONLY','value':'rpc-'+index,'domain':'flow.google.com','hostOnly':True,'path':'/_/','secure':True})
            return envelope(json.dumps(cookies),{'user_agent':'SceneForge-Contract-Chrome/'+index,'authuser':index})
        try:
            with patch('src.services.flow_frontend.AsyncSession',session),patch('src.services.flow_client.AsyncSession',session),patch('src.services.protocol_login.AsyncSession',session):
                old=FlowClient(proxy_manager=None)
                try:await old.st_to_at(google_cookies=storage('1'))
                except RuntimeError as exc:assert '401'in str(exc)
                else:raise AssertionError('Old transport unexpectedly authenticated')
                from src.services.protocol_login import protocol_loginer
                class Manager:
                    def __init__(self,client):self.flow_client=client
                    async def detect_account_identity(self,google_cookies,proxy_url=None):
                        result=await protocol_loginer.login(google_cookies)
                        assert result['success'],result
                        return result
                client=FlowClient(proxy_manager=None);manager=Manager(client);install(SimpleNamespace(token_manager=manager))
                try:await client.st_to_at(google_cookies=storage('1',False))
                except RuntimeError as exc:assert '401'in str(exc)
                else:raise AssertionError('Missing RPC cookie was accepted')
                results=await asyncio.gather(*(client.st_to_at(google_cookies=storage(i)) for i in ('1','2')))
                for index,result in zip(('1','2'),results):
                    assert result['credits']==42
                    assert context_of(result['google_cookies'])['authuser']==index
                    assert 'rotated-'+index in result['google_cookies']
                for index,result in zip(('1','2'),results):
                    identity=await manager.detect_account_identity(result['google_cookies'])
                    assert identity['email']=='fixture-'+index+'@invalid',identity
                    assert context_of(identity['google_cookies'])['authuser']==index
                assert ACTIVE.get() is None and client.get_request_fingerprint() is None
                # Same context on the SDK's streaming path; fixture server only.
                count=len(events)
                await client._call_flow_stream_chat(project_id='01234567-89ab-cdef-0123-456789abcdef',prompt='Local test only',recaptcha_token='fixture',session_id='fixture',cookie_header='',cookie_storage=results[0]['google_cookies'],timeout=5)
                assert events[-1]==('post','1',True) and len(events)==count+2,events
                # Restore from persisted credentials on a new engine instance.
                restart=FlowClient(proxy_manager=None);install(SimpleNamespace(token_manager=SimpleNamespace(flow_client=restart)))
                assert (await restart.st_to_at(google_cookies=results[0]['google_cookies']))['credits']==42
        finally:server.shutdown();server.server_close();thread.join(timeout=5)
    assert account_url('https://evil.invalid/?x=1',{'authuser':'2'})=='https://evil.invalid/?x=1'
    assert clean_context({'user_agent':'bad\r\nCookie: private','authuser':'1&x=2'})=={}
    print('PASS actual pinned FlowClient + real curl_cffi over isolated loopback TLS: old transport and missing RPC-path cookie reject 401; preserved browser UA/account + full scoped cookies authenticate; rotation, persisted restart and concurrent account isolation pass. No Google calls; real user session not verified.')

if __name__=='__main__':asyncio.run(main(Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/sceneforge-flow-pinned')))
