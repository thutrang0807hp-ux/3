"""Unreachable debug runtime must not be reported as login waiting/success."""
import asyncio,tempfile,types,sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from .flow_web_login import FlowWebLogin
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  accounts=SimpleNamespace(import_session=AsyncMock(),pool=SimpleNamespace(rows=lambda:[]))
  pw=SimpleNamespace(chromium=SimpleNamespace(connect_over_cdp=AsyncMock()),stop=AsyncMock())
  module=types.ModuleType('playwright.async_api');module.async_playwright=lambda:SimpleNamespace(start=AsyncMock(return_value=pw))
  manager=FlowWebLogin(Path(tmp),accounts);manager.startup_timeout=0
  with patch.dict(sys.modules,{'playwright.async_api':module}),patch('local_engine.flow_browser_probe.probe_flow_browser',new=AsyncMock(return_value={'ready':False,'code':'FLOW_BROWSER_ENDPOINT_UNAVAILABLE'})):
   await manager.watch()
  assert manager.status()['state']=='failed'and manager.status()['code']=='FLOW_BROWSER_ENDPOINT_UNAVAILABLE'
  accounts.import_session.assert_not_awaited();pw.chromium.connect_over_cdp.assert_not_awaited();pw.stop.assert_awaited_once()
 # A reachable HTTP endpoint does not prove Playwright can attach.
 pw.chromium.connect_over_cdp=AsyncMock(side_effect=RuntimeError('private transport detail'))
 pw.stop.reset_mock()
 manager=FlowWebLogin(Path(tmp),accounts);manager.startup_timeout=0
 with patch.dict(sys.modules,{'playwright.async_api':module}),patch('local_engine.flow_browser_probe.probe_flow_browser',new=AsyncMock(return_value={'ready':True,'endpoint':'http://127.0.0.1:12345','code':'FLOW_BROWSER_READY'})):
  await manager.watch()
 assert manager.status()['code']=='FLOW_BROWSER_CDP_CONNECT_FAILED'
 assert 'private transport detail' not in str(manager.status())
 accounts.import_session.assert_not_awaited();pw.stop.assert_awaited_once()
 print('PASS unavailable browser instance: terminal connection failure, no false login success, no import, no page connection or generation.')
if __name__=='__main__':asyncio.run(main())
