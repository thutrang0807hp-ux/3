"""Auto-discover the local model catalog; never submit generation or reset binding."""
import asyncio,tempfile
from pathlib import Path
import httpx
from .vault import Vault
from .request_ledger import RequestLedger
from .flow_provider import FlowProvider


async def main():
    with tempfile.TemporaryDirectory()as tmp:
        root=Path(tmp);vault=Vault(root);calls=[];mode={'fail':False,'swap':False}
        async def transport(request):
            calls.append((request.method,request.url.path))
            assert request.method=='GET'and request.url.path=='/v1/models'
            await asyncio.sleep(.01)
            cfg=vault.secret('flow-engine');cfg.update(account_binding=True,task_journal=True);vault.set_secret('flow-engine',cfg)
            if mode['swap']:
                cfg['key']='NEW_PRIVATE_ENGINE_KEY';vault.set_secret('flow-engine',cfg)
            if mode['fail']:return httpx.Response(503)
            return httpx.Response(200,json={'data':[{'id':'veo-3.1-fast-i2v-6s-portrait','description':'Veo Fast I2V portrait'}]})
        service=FlowProvider(vault,root,RequestLedger(root),lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)))
        service.configure({'url':'http://127.0.0.1:8766','key':'PRIVATE_ENGINE_KEY_12345'})
        results=await asyncio.gather(*(service.ready_status()for _ in range(6)))
        assert len(calls)==1 and all(r['models']==['veo-3.1-fast-i2v-6s-portrait']for r in results)
        assert results[0]['account_binding']and results[0]['task_journal']
        assert len((await service.ready_status())['models'])==1 and len(calls)==1
        service.configure({'url':'http://127.0.0.1:8766','key':'PRIVATE_ENGINE_KEY_12345'});mode['fail']=True
        result=await service.ready_status();assert result['models']==[]and result['models_error']
        assert not any('key'in k for k in result)
        await service.ready_status();assert len(calls)==2,'Failure polling caused repeated catalog reads'
        mode.update(fail=False,swap=True);service.model_discovery_attempt=-1e9
        await service.ready_status()
        assert service.config()['key']=='NEW_PRIVATE_ENGINE_KEY'and service.config()['models']==[]
    print('PASS automatic local model discovery: first node/status read fills models, concurrent reads coalesce, configured account/journal flags preserved, failure shown and throttled, changed engine not overwritten; zero generation requests.')

if __name__=='__main__':asyncio.run(main())
