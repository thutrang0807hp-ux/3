"""Persistent project binding by SceneForge room and verified engine account."""
import asyncio,hashlib,re,sqlite3,os
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

ROOM=ContextVar('sceneforge_flow_room',default=None)

class ProjectBindings:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True);self.locks={}
        with self.db()as db:db.execute('CREATE TABLE IF NOT EXISTS binding(room TEXT,actor TEXT,project TEXT,state TEXT,PRIMARY KEY(room,actor))')
        if os.name!='nt':os.chmod(self.path,0o600)
    @contextmanager
    def db(self):
        db=sqlite3.connect(self.path,timeout=30);db.execute('PRAGMA synchronous=FULL')
        try:
            with db:yield db
        finally:db.close()
    async def ensure(self,room,actor,create):
        async with self.locks.setdefault((room,actor),asyncio.Lock()):
            with self.db()as db:
                db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT project,state FROM binding WHERE room=? AND actor=?',(room,actor)).fetchone()
                if row:
                    if row[1]=='ready':return row[0]
                    raise RuntimeError('Flow project creation unresolved; check existing project before retrying.')
                db.execute('INSERT INTO binding VALUES(?,?,NULL,?)',(room,actor,'creating'))
            try:
                pid=await create()
                if not isinstance(pid,str)or not re.fullmatch(r'[A-Za-z0-9_-]{8,180}',pid):raise ValueError('Invalid Flow project id')
                with self.db()as db:db.execute('UPDATE binding SET project=?,state=? WHERE room=? AND actor=?',(pid,'ready',room,actor))
                return pid
            except BaseException:
                with self.db()as db:db.execute('UPDATE binding SET state=? WHERE room=? AND actor=?',('unknown',room,actor))
                raise

def install(engine,path):
    manager=engine.token_manager;original=getattr(manager,'ensure_project_exists',None)
    if not callable(original):return None
    bindings=ProjectBindings(path)
    async def ensure(token_id):
        room=ROOM.get()
        if not room:return await original(token_id)
        token=await manager.get_token(token_id)
        if token is None or not token.is_active:raise ValueError('Flow account unavailable')
        email=str(token.email or '').strip().casefold()
        if not email:raise ValueError('Verified account identity required for project binding')
        actor=hashlib.sha256((str(token_id)+'\0'+email).encode()).hexdigest()
        async def create():
            return await manager.flow_client.create_project(token.st,'SceneForge '+room[:10],google_cookies=token.google_cookies)
        return await bindings.ensure(room,actor,create)
    manager.ensure_project_exists=ensure
    return bindings
