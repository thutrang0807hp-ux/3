"""Actual settings controls for extension-free login; login endpoint is intercepted."""
import os,socket,tempfile,time,json,urllib.request
from pathlib import Path
from threading import Thread
import uvicorn
from playwright.sync_api import sync_playwright,expect

def main():
 with tempfile.TemporaryDirectory()as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server
  if os.environ.get('SCENEFORGE_TEST_FRONTEND'):
   from fastapi.staticfiles import StaticFiles
   for route in server.app.routes:
    if getattr(route,'name',None)=='frontend':route.app=StaticFiles(directory=os.environ['SCENEFORGE_TEST_FRONTEND'],html=True)
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  host=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'));thread=Thread(target=host.run,daemon=True);thread.start();base='http://127.0.0.1:'+str(port)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(base+'/local-api/health',timeout=.3);break
    except OSError:time.sleep(.05)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();errors=[];posts=[];page.on('pageerror',lambda e:errors.append(str(e)))
    def login(route):
     if route.request.method=='POST':posts.append(route.request.post_data_json)
     route.fulfill(status=200,content_type='application/json',body=json.dumps({'opened':True,'state':'waiting','message':'Đang chờ đăng nhập trong cửa sổ riêng.'}))
    page.route(base+'/local-api/flow/web-login',login)
    page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();await accountScreen('flow')}")
    expect(page.locator('#flowWebLogin')).to_be_visible();page.locator('#connectAccount').click();expect(page.locator('#flowWebStatus')).to_contain_text('Đang chờ')
    expect(page.locator('#shellDialog')).to_contain_text('không cần tiện ích hoặc mã kết nối')
    assert posts==[{'new_profile':False}]
    page.locator('#flowWebClose').click();page.locator('#flowWebNewAccount').click()
    expect(page.locator('#flowWebStatus')).to_be_visible();assert posts==[{'new_profile':False},{'new_profile':True}]
    # Regression: login opened from the workflow's code-pairing dialog.
    page.locator('#flowWebClose').click()
    page.evaluate("()=>connectBrowserSession('flow',{separate:true})")
    page.locator('#bridgeWebLogin').click()
    expect(page.locator('#flowWebStatus')).to_be_visible()
    assert posts==[{'new_profile':False},{'new_profile':True},{'new_profile':False}],posts
    expect(page.locator('#shellDialog')).not_to_contain_text('newProfile is not defined')
    assert not errors,errors;browser.close()
   print('PASS delivered UI: web-login visible without extension; reuse/new-profile buttons send correct requests; login state shown; no browser launched or Google calls in UI fixture.')
  finally:host.should_exit=True;thread.join(timeout=8)
if __name__=='__main__':main()
