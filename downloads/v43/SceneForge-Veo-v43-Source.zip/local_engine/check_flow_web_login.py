"""Persistent manual web login; fixed destination, no account mutation or generation."""
import asyncio,os,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,AsyncMock
import httpx
from .google_login import open_flow_web_login
async def main():
 with tempfile.TemporaryDirectory()as tmp:
  data=Path(tmp);calls=[]
  def spawn(args,**kwargs):calls.append(args);return SimpleNamespace(poll=lambda:0)
  with patch('local_engine.google_login.installed_browser',return_value='fixture-chrome'),patch('local_engine.google_login.subprocess.Popen',spawn):
   await open_flow_web_login(data)
   profile=data/'browser-profiles/flow-web';marker=profile/'fixture-profile';marker.write_text('saved')
   await open_flow_web_login(data)
   assert marker.read_text()=='saved'and calls[0]==calls[1]
   assert calls[0][-1]=='https://flow.google.com/'
   assert not any('debugging'in a or 'proxy'in a or 'disable-blink'in a for a in calls[0])
   os.environ['SCENEFORGE_LOCAL_DATA']=tmp
   from .server import app,VAULT,SESSION
   before=VAULT.rows('accounts')
   from .server import FLOW_WEB_LOGIN
   with patch.object(FLOW_WEB_LOGIN,'watch',new=AsyncMock()):
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://localhost')as c:
     c.cookies.set('sceneforge_session_0',SESSION.secret)
     result=await c.post('/local-api/flow/web-login',headers={'x-sceneforge-local':'1'},json={'url':'https://untrusted.invalid','profile':'untrusted'})
     assert result.status_code==200 and result.json()['opened']is True,result.text
   assert calls[-1][-1]=='https://flow.google.com/'and VAULT.rows('accounts')==before
  with patch('local_engine.google_login.installed_browser',return_value='fixture-chrome'),patch('local_engine.google_login.subprocess.Popen',side_effect=OSError('fixture')):
   try:await open_flow_web_login(data)
   except Exception as e:assert e.status_code==503
   else:raise AssertionError('Missing launch failure')
  print('PASS persistent profile reused; fixed URL/profile; no debugging/proxy args; API leaves accounts unchanged; launch error reported')
asyncio.run(main())
