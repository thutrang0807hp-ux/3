"""Read-only identity scope and workspace binding; no Google traffic or generation."""
import asyncio,json,subprocess
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 source=(Path(__file__).resolve().parents[1]/'scripts/browser-extension/dom-flow.js').read_text()
 async with async_playwright()as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=await browser.new_context();await context.route('**/*',lambda r:r.fulfill(status=200,content_type='text/html',body="<script>window.WIZ_global_data={oPEP7c:'fixture@invalid'}</script>"))
  page=await context.new_page()
  async def identity(path):
   await page.goto('https://flow.google.com'+path);return await page.evaluate(source+'\nsceneForgeFlowIdentity()')
  home=await identity('/?pli=1');first=await identity('/project/private-project-a?authuser=0');same=await identity('/project/private-project-a?pli=1');other=await identity('/project/private-project-b')
  assert home['page_kind']=='home'and home['project_hash']is None
  assert first['project_hash']==same['project_hash']and first['project_hash']!=other['project_hash']
  assert 'private-project-a'not in json.dumps(first)
  async def check(link,value,action):return await page.evaluate(source+'\nsceneForgeFlowWorkspace('+json.dumps(link)+','+json.dumps(value)+','+json.dumps({'action':action})+')')
  assert not (await check({},home,'prepare'))['ok']
  pin=await check({},first,'prepare');assert pin['ok']and pin['pin']==first['project_hash']
  link={'project_hash':pin['pin']}
  assert (await check(link,same,'status'))['ok']
  assert not (await check(link,other,'prepare'))['ok']
  denied=await check(link,other,'status');assert not denied['ok']and denied['uncertain']
  assert (await check(link,home,'release'))['ok']
  assert not (await check({},first,'status'))['ok']
  await browser.close()
 print('PASS workspace binding: home never dispatched; paired project pinned; query changes accepted; project switch refused; post-submit uncertainty preserved; cleanup allowed; no raw project path exported. Fixture only.')
if __name__=='__main__':asyncio.run(main())
