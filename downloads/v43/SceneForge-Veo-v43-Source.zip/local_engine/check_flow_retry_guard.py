"""Script-mode regression: one video submit, preserve rejection, never log secrets."""
import asyncio,sys,tempfile,sqlite3
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent))
import flow_native_transport as native
from local_engine.flow_task_journal import FlowJournal,REQUEST,TRACE_SINK,VIDEO_DISPATCHES
async def main():
 with tempfile.TemporaryDirectory()as d:
  j=FlowJournal(Path(d)/'trace.sqlite');calls=[];retries=[]
  async def rpc(rpc_id,argument,cookie_storage=None,timeout=120):raise AssertionError('Unexpected HTTP path')
  async def auth(st='',google_cookies=None):return {'ok':True}
  async def retry(error,**kwargs):retries.append(error);return True
  def reject(frames,rpc):raise RuntimeError('Flow frontend RPC rejected: code=400 secret-token')
  c=SimpleNamespace(st_to_at=auth,_call_flow_frontend_rpc=rpc,_parse_batchexecute_frames=lambda text:[],_raise_batchexecute_error=reject,_handle_retryable_generation_error=retry)
  native.install(SimpleNamespace(token_manager=SimpleNamespace(flow_client=c)))
  assert await c.st_to_at()=={'ok':True}
  route={'id':'a'*24,'key':'b'*40,'endpoint':'http://127.0.0.1:1234/local-api/browser-bridge/flow-execute','origin':'chrome-extension://'+'a'*32}
  async def call(*args):calls.append(1);return {'status':200,'text':'private raw response'}
  a=REQUEST.set('flow-11111111-1111-1111-1111-111111111111');b=TRACE_SINK.set(j.trace);v=VIDEO_DISPATCHES.set(set())
  with patch.object(native,'call',call):
   try:await c._call_flow_frontend_rpc('eb1hJf',[],cookie_storage=native.envelope({},route))
   except RuntimeError as exc:assert not await c._handle_retryable_generation_error(error=exc)
   else:raise AssertionError('Lost rejection')
   try:await c._call_flow_frontend_rpc('eb1hJf',[],cookie_storage=native.envelope({},route))
   except native.RetryBlocked:pass
   else:raise AssertionError('Repeated submit allowed')
  assert len(calls)==1 and not retries
  assert not await c._handle_retryable_generation_error(error=RuntimeError('PUBLIC_ERROR_UNUSUAL_ACTIVITY'))
  assert await c._handle_retryable_generation_error(error=RuntimeError('unrelated error'))
  rows=sqlite3.connect(j.path).execute('SELECT outcome FROM diagnostic').fetchall()
  assert rows==[('started',),('RPC_CODE_400',),('RETRY_BLOCKED',)],rows
  assert b'secret-token'not in j.path.read_bytes() and b'private raw response'not in j.path.read_bytes()
  VIDEO_DISPATCHES.reset(v);TRACE_SINK.reset(b);REQUEST.reset(a)
  print('PASS script-mode auth; single submit; no retry on RPC rejection/unusual activity; numeric first error; no duplicate unknown or secrets')
asyncio.run(main())
