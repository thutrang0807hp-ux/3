"""Run the actual pinned add_token method with deterministic provider/database dependencies."""
import ast,asyncio,hashlib,json,textwrap,typing,sys
from datetime import datetime,timedelta,timezone
from pathlib import Path
from types import SimpleNamespace
import httpx
from fastapi import FastAPI,Header,HTTPException


async def main(source):
    file=source/'src/services/token_manager.py';tree=ast.parse(file.read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='TokenManager')
    method=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef)and n.name=='add_token')
    ns={**vars(typing),'hashlib':hashlib,'datetime':datetime,'timedelta':timedelta,'timezone':timezone,
        'Token':SimpleNamespace,'Project':SimpleNamespace,
        'debug_logger':SimpleNamespace(log_info=lambda *a:None,log_warning=lambda *a:None)}
    exec(compile(ast.Module(body=[method],type_ignores=[]),str(file),'exec'),ns)
    modules=['src','src.core','src.core.auth','src.core.config'];saved={k:sys.modules.get(k)for k in modules}
    for k in modules:sys.modules[k]=__import__('types').ModuleType(k)
    async def auth(authorization:str=Header(default='')):
        if authorization!='Bearer fixture':raise HTTPException(401)
    sys.modules['src.core.auth'].verify_api_key_header=auth;sys.modules['src.core.config'].config=SimpleNamespace(flow_max_retries=1)
    try:
        from .flow_account_engine import extend
        flags={'fail':set(),'duplicate':False,'duplicate_email':False,'busy':False};calls=[];writes=[]
        row=SimpleNamespace(id=7,email='fixture@invalid',is_active=True)
        class DB:
            async def get_token_by_st(self,st):return row if flags['duplicate']else None
            async def get_token_by_email(self,email):return row if flags['duplicate_email']else None
            async def add_token(self,token):
                if 'storage'in flags['fail']:raise RuntimeError('PRIVATE-DB-CONTENT')
                writes.append('account');return 8
            async def add_project(self,project):writes.append('project');return 81
            async def update_token(self,*a,**kw):writes.append('refresh')
        class Client:
            async def _load_flow_frontend_bootstrap(self):
                calls.append('bootstrap')
                if 'bootstrap'in flags['fail']:raise RuntimeError('HTTP 401 PRIVATE-COOKIE')
                return 'fixture'
            async def st_to_at(self,st,google_cookies=None):
                calls.append('auth');await self._load_flow_frontend_bootstrap()
                if 'auth'in flags['fail']:raise TypeError('PRIVATE-SDK-TEXT')
                await self.get_credits('fixture')
                return {'access_token':'fixture','expires':None,'user':{}if 'identity'in flags['fail']else{'email':'fixture@invalid'},'google_cookies':google_cookies}
            async def get_credits(self,*a,**kw):
                calls.append('credits')
                if 'credits'in flags['fail']:raise RuntimeError('HTTP 403 PRIVATE-RESPONSE')
                return {'credits':100}
            async def create_project(self,*a,**kw):
                calls.append('project')
                if 'project'in flags['fail']:raise RuntimeError('HTTP 403 PRIVATE-PROJECT')
                return 'fixture-project'
        class Manager:
            add_token=ns['add_token']
            def __init__(self):self.db=DB();self.flow_client=Client()
            async def get_active_tokens(self):return [row]
            async def get_token(self,aid):return row if aid==7 else None
            async def update_token(self,*a,**kw):writes.append('existing-refresh')
            async def detect_account_identity(self,*a,**kw):calls.append('identity');raise ValueError('PRIVATE-IDENTITY')
            def _normalize_project_name_base(self,name):return name or 'Fixture'
            def _get_project_pool_size(self):return 1
            def _build_project_name(self,i,base):return base
            def _latest_google_cookies(self,value):return value
            def _normalize_protocol_mode(self,value):return value
            def _normalize_token_proxy_url(self,value):return value or ''
            def _normalize_refresh_interval(self,value):return value
            async def mark_cookie_validated(self,*a,**kw):pass
        class Limits:
            async def get_image_inflight(self,aid):return int(flags['busy'])
            async def get_video_inflight(self,aid):return 0
            async def reset_token(self,*a,**kw):pass
        engine=SimpleNamespace(app=FastAPI(),token_manager=Manager(),concurrency_manager=Limits())
        app=extend(engine);data={'cookies':[{'domain':'.google.com','name':'SID','value':'PRIVATE-ROOT'},{'domain':'flow.google.com','name':'OSID','value':'PRIVATE-FLOW'}]}
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://fixture',headers={'Authorization':'Bearer fixture'})as c:
            for fail,code,status in [('bootstrap','FLOW_BOOTSTRAP_FAILED',401),('auth','FLOW_AUTH_HANDSHAKE_FAILED',None),('credits','FLOW_CREDIT_CHECK_FAILED',403),('project','FLOW_PROJECT_SETUP_FAILED',403),('storage','FLOW_ACCOUNT_SAVE_FAILED',None)]:
                flags['fail']={fail};calls.clear();writes.clear()
                r=await c.post('/sceneforge/accounts',json=data);assert r.status_code==409,r.text
                d=r.json()['detail'];assert d['code']==code,d
                assert d.get('provider_http_status')==status,d
                assert 'PRIVATE'not in r.text and not writes,r.text
                assert 'identity'not in calls,'Failed import was incorrectly retried as duplicate identity'
            flags['fail']={'identity'};calls.clear();writes.clear()
            r=await c.post('/sceneforge/accounts',json=data)
            assert r.status_code==200 and writes==['account','project'],r.text
            flags['fail']={'identity','project'};calls.clear();writes.clear()
            r=await c.post('/sceneforge/accounts',json=data)
            assert r.json()['detail']['code']=='FLOW_PROJECT_SETUP_FAILED',r.text
            flags['fail']=set();flags['duplicate']=True;calls.clear();writes.clear()
            r=await c.post('/sceneforge/accounts',json=data)
            assert r.json()=={'id':7,'existing':True}and writes==['existing-refresh']and calls==[],r.text
            flags['duplicate']=False;flags['duplicate_email']=True;calls.clear();writes.clear()
            r=await c.post('/sceneforge/accounts',json=data)
            assert r.json()=={'id':7,'existing':True}and writes==['existing-refresh']and'identity'not in calls,r.text
            flags['duplicate_email']=False;flags['duplicate']=True
            flags['busy']=True;writes.clear()
            r=await c.post('/sceneforge/accounts',json=data)
            assert r.json()['detail']['code']=='FLOW_ACCOUNT_BUSY'and not writes,r.text
        print('PASS ACTUAL pinned TokenManager.add_token control flow: bootstrap/auth/credits/project/storage failure phases and numeric statuses preserved; no spurious duplicate retry; recovered identity failure may succeed; later project failure replaces recovered error; exact duplicate reuse and busy guard. Provider/database/model dependencies are fixtures; zero Google calls.')
    finally:
        for k,v in saved.items():
            if v is None:sys.modules.pop(k,None)
            else:sys.modules[k]=v


if __name__=='__main__':asyncio.run(main(Path(sys.argv[1])if len(sys.argv)>1 else Path('/tmp/sceneforge-flow-pinned')))
