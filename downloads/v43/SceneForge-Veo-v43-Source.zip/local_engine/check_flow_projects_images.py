"""Project binding restart/concurrency and actual oversized PNG transport copies."""
import asyncio,base64,io,tempfile,random
from pathlib import Path
from PIL import Image
from .flow_projects import ProjectBindings
from .image_transport import prepare_images,LIMIT
from .batch_images import BatchImages

async def main():
    with tempfile.TemporaryDirectory()as tmp:
        path=Path(tmp)/'bindings.sqlite';calls=[]
        async def create():calls.append(len(calls));await asyncio.sleep(.01);return 'project-'+str(len(calls))
        bindings=ProjectBindings(path)
        same=await asyncio.gather(*(bindings.ensure('room-A','account-A',create)for _ in range(12)))
        assert len(set(same))==1 and len(calls)==1
        assert await ProjectBindings(path).ensure('room-A','account-A',create)==same[0]and len(calls)==1
        assert await bindings.ensure('room-B','account-A',create)!=same[0]
        assert await bindings.ensure('room-A','account-B',create)!=same[0]
        async def uncertain():calls.append('uncertain');raise TimeoutError()
        try:await bindings.ensure('room-C','account-A',uncertain)
        except TimeoutError:pass
        count=len(calls)
        try:await bindings.ensure('room-C','account-A',create)
        except RuntimeError:pass
        else:raise AssertionError('Uncertain project creation was repeated')
        assert len(calls)==count
    pixels=random.Random(124).randbytes(1536*2752*3);image=Image.frombytes('RGB',(1536,2752),pixels);out=io.BytesIO();image.save(out,format='PNG');raw=out.getvalue()
    assert len(raw)>LIMIT
    original={'mime_type':'image/png','data':base64.b64encode(raw).decode()};before=original.copy()
    copies=prepare_images([original]);assert original==before
    assert BatchImages.decode_image(copies[0])<=LIMIT
    with Image.open(io.BytesIO(base64.b64decode(copies[0]['data'])))as copy:assert copy.size==(1536,2752)
    assert prepare_images([original])==copies,'Transport encoding must be deterministic for request identity'
    tiny=io.BytesIO();Image.new('RGBA',(12,20),(1,2,3,20)).save(tiny,format='PNG');small={'mime_type':'image/png','data':base64.b64encode(tiny.getvalue()).decode()}
    assert prepare_images([small])==[small]
    print('PASS one Flow project per room/account across concurrency and restart; different rooms/accounts separate; unknown creation never retried. Actual >6MiB 1536x2752 PNG converted below cap, original/dimensions preserved, deterministic request bytes, small transparent PNG unchanged. No Google calls.')

if __name__=='__main__':asyncio.run(main())
