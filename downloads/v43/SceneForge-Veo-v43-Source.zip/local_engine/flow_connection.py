"""Bounded Flow connection diagnostics. Never expose provider messages or cookies."""
import time
from fastapi import HTTPException

MESSAGES={
 'FLOW_BROWSER_UNAVAILABLE':'Chưa liên lạc được với tab Flow đã nối. Giữ Chrome/Edge và tab Flow mở; nếu vừa khởi động lại trình duyệt, tạo mã kết nối mới.',
 'FLOW_BROWSER_ACCOUNT_CHANGED':'Nick trong tab Flow đã đổi. Đã dừng để tránh gửi nhầm tài khoản; kết nối lại đúng nick trước khi chạy.',
 'FLOW_BROWSER_REQUEST_FAILED':'Tab Flow chưa hoàn tất yêu cầu. Kiểm tra Flow trong trình duyệt; chưa chứng nhận tạo nội dung.',
 'FLOW_BROWSER_OUTCOME_UNKNOWN':'Mất phản hồi từ tab Flow sau khi gửi. Chưa rõ kết quả; không tự gửi lại để tránh tốn lượt trùng.',
 'FLOW_SESSION_COOKIE_MISSING':'App chưa nhận được cookie phiên dùng được cho Flow. Xem Thông tin lỗi để kiểm tra phạm vi phiên; mở Flow đã đăng nhập trong đúng trình duyệt có tiện ích rồi tạo mã mới.',
 'FLOW_GOOGLE_COOKIE_MISSING':'Thiếu phiên Google đi kèm Flow. Đăng nhập Flow trong đúng trình duyệt có tiện ích rồi tạo mã mới.',
 'FLOW_ENGINE_NOT_CONFIGURED':'Engine Flow cục bộ chưa được cấu hình. Kiểm tra kết nối engine trong Cài đặt.',
 'FLOW_ENGINE_UNREACHABLE':'Không liên lạc được với engine Flow cục bộ. Kiểm tra engine đang chạy rồi kết nối lại.',
 'FLOW_ENGINE_REJECTED':'Engine Flow nhận yêu cầu nhưng từ chối nhập/kiểm tra phiên. Chưa gửi tạo nội dung.',
 'FLOW_BOOTSTRAP_FAILED':'Engine đã nhận cookie nhưng không đọc được trang làm việc Flow. Chưa gửi tạo nội dung.',
 'FLOW_AUTH_HANDSHAKE_FAILED':'Engine chưa xác minh được phiên với Flow sau khi nhận đủ cookie. Chưa gửi tạo nội dung.',
 'FLOW_CREDIT_CHECK_FAILED':'Engine không đọc được thông tin hạn mức từ Flow. Chưa gửi tạo nội dung.',
 'FLOW_PROJECT_SETUP_FAILED':'Engine chưa hoàn tất khởi tạo dự án Flow để nhập tài khoản. Chưa gửi tạo nội dung.',
 'FLOW_IDENTITY_LOOKUP_FAILED':'Engine chưa đọc được danh tính tài khoản Flow. Chưa chọn tài khoản thay thế.',
 'FLOW_ACCOUNT_SAVE_FAILED':'Engine gặp lỗi lưu tài khoản hoặc dự án. Có thể đã lưu một phần; cần kiểm tra danh sách trước khi nhập lại.',
 'FLOW_ACCOUNT_LOOKUP_FAILED':'Engine chưa đọc được danh sách tài khoản đã lưu.',
 'FLOW_ACCOUNT_REFRESH_FAILED':'Engine chưa cập nhật được phiên của tài khoản Flow đã có.',
 'FLOW_IMPORT_REJECTED':'Engine đã nhận phiên nhưng chưa nhập được tài khoản Flow (xác minh đăng nhập hoặc khởi tạo dự án). Chưa gửi tạo nội dung.',
 'FLOW_ACCOUNT_BUSY':'Tài khoản Flow đang có việc chạy; chưa đổi phiên. Chờ xong rồi kết nối lại.',
 'FLOW_ACCOUNT_NOT_ELIGIBLE':'Không tìm được tài khoản Flow đang bật khớp với phiên vừa nhập. Chưa thay tài khoản cũ.',
 'FLOW_ACCOUNT_ID_MISSING':'Engine chưa trả đúng mã tài khoản vừa nhập. Chưa chọn một tài khoản khác để thay thế.',
 'FLOW_SESSION_CHECK_FAILED':'Đã nhập tài khoản vào engine nhưng chưa kiểm tra được phiên Flow. Tài khoản cũ được giữ để kiểm tra tiếp.',
 'FLOW_AUTH_EXPIRED':'Flow không chấp nhận phiên đăng nhập này. Mở flow.google.com trong đúng trình duyệt, đăng nhập lại rồi tạo mã mới.',
}
GOOGLE_NAMES={'SID','HSID','SSID','APISID','SAPISID','__Secure-1PSID','__Secure-3PSID'}


SAFE_STAGES={'connect','cookies','engine','import','check','bootstrap','auth','credits','identity','project','storage','lookup','refresh'}
def safe_details(value):
    if not isinstance(value,dict):return {}
    result={}
    if isinstance(value.get('stage'),str)and value['stage']in SAFE_STAGES:result['stage']=value['stage']
    if type(value.get('provider_http_status'))is int and 100<=value['provider_http_status']<=599:result['provider_http_status']=value['provider_http_status']
    if isinstance(value.get('provider_error_kind'),str)and value['provider_error_kind']in {'timeout','tls','network','sdk','http','provider'}:result['provider_error_kind']=value['provider_error_kind']
    steps=value.get('completed_steps')
    if isinstance(steps,list):result['completed_steps']=[s for s in steps[:12]if isinstance(s,str)and s in SAFE_STAGES]
    return result


def error(code,stage='connect',**extra):
    code=code if code in MESSAGES else 'FLOW_ENGINE_REJECTED'
    return HTTPException(409,{'code':code,'stage':stage,'message':MESSAGES[code],**safe_details(extra)})


def applies_to_flow(cookie):
    """Cookie scope for https://flow.google.com/projects, matching the pinned engine."""
    if any(cookie.get(k) for k in ('partitionKey','partition_key','partitionKeyOpaque','partition_key_opaque','partitioned')):return False
    value=cookie.get('value')
    if not isinstance(value,str) or not value or ';' in value or any(ord(c)<32 for c in value):return False
    domain=str(cookie.get('domain','')).strip().lower().lstrip('.')
    if not domain:return False
    host='flow.google.com'
    if cookie.get('hostOnly'):
        if domain!=host:return False
    elif domain!=host and not host.endswith('.'+domain):return False
    path=str(cookie.get('path')or'/')
    if not path.startswith('/'):path='/'
    target='/projects'
    if target!=path and not (target.startswith(path) and (path.endswith('/') or target[len(path):].startswith('/'))):return False
    expiry=cookie.get('expirationDate',cookie.get('expires'))
    if expiry not in (None,'',0,-1):
        try:
            if float(expiry)<=time.time():return False
        except (TypeError,ValueError):pass
    return True


def diagnostics(cookies):
    rows=[c for c in cookies if isinstance(c,dict)]if isinstance(cookies,list)else[]
    sessions=[{'name':c.get('name'),'domain':str(c.get('domain',''))[:120],
               'path':str(c.get('path')or'/')[:120],'host_only':bool(c.get('hostOnly')),
               'usable_for_flow':applies_to_flow(c)} for c in rows if c.get('name')in {'OSID','__Secure-OSID'}][:12]
    return {'received_cookie_count':len(rows),'flow_session_scopes':sessions,
            'google_identity_usable':any(c.get('name')in GOOGLE_NAMES and applies_to_flow(c) for c in rows),
            'contains_cookie_values':False}


def validate(cookies):
    rows=[c for c in cookies if isinstance(c,dict) and applies_to_flow(c)] if isinstance(cookies,list)else[]
    if not any(c.get('name')in {'OSID','__Secure-OSID'} for c in rows):
        raise error('FLOW_SESSION_COOKIE_MISSING','cookies')
    if not any(c.get('name')in GOOGLE_NAMES for c in rows):
        raise error('FLOW_GOOGLE_COOKIE_MISSING','cookies')


def public_error(exc):
    detail=exc.detail if isinstance(exc,HTTPException)else None
    if isinstance(detail,dict) and detail.get('code')in MESSAGES:
        code=detail['code']
        return {'code':code,'message':MESSAGES[code],**safe_details(detail)}
    return {'code':'FLOW_ENGINE_REJECTED','message':MESSAGES['FLOW_ENGINE_REJECTED']}
