"""Concurrent login clicks must share one app-owned browser startup."""
import asyncio,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from .flow_web_login import FlowWebLogin

async def main():
 with tempfile.TemporaryDirectory() as tmp:
  manager=FlowWebLogin(Path(tmp),SimpleNamespace())
  started=asyncio.Event();release=asyncio.Event()
  async def probe(*args):
   started.set();await release.wait()
   return {'ready':False,'code':'FLOW_BROWSER_PORT_NOT_READY'}
  async def watch():await asyncio.Event().wait()
  manager.watch=watch
  launch=AsyncMock()
  with patch('local_engine.flow_browser_probe.probe_flow_browser',side_effect=probe),patch('local_engine.flow_web_login.open_flow_web_login',new=launch):
   first=asyncio.create_task(manager.start());await started.wait()
   second=asyncio.create_task(manager.start());release.set()
   results=await asyncio.gather(first,second)
   assert all(result['opened'] for result in results)
   launch.assert_awaited_once()
   try:await manager.start(new_profile=True)
   except Exception as exc:assert exc.status_code==409
   else:raise AssertionError('New profile must not replace a pending login')
   await manager.close()
 print('PASS concurrent startup: one launch, one watcher, pending profile change rejected; no real browser or provider calls.')
if __name__=='__main__':asyncio.run(main())
