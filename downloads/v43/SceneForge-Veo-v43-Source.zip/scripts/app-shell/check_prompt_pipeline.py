"""Actual hosted app, browser/storage/media. Fixture model/account/quality results, no cloud generation."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,subprocess,socket,time,os,urllib.request,io,json,base64,hashlib
from PIL import Image
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-prompt-pipeline-')as tmp:
 video=Path(tmp)/'clip.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:size=180x320:rate=12:duration=8','-c:v','libx264','-pix_fmt','yuv420p',str(video)],check=True);mp4=video.read_bytes();image=io.BytesIO();Image.new('RGB',(180,320),'blue').save(image,format='PNG');png=image.getvalue();encoded=base64.b64encode(png).decode()
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp+'/data'},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page(viewport={'width':1600,'height':1050});errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.goto(base);p.wait_for_function('appBootReady&&SceneForgeStorage.state.active');p.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'prompt-pipeline-test',name:'Prompt pipeline',mode:'reference',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}''');f=p.locator('#workflowFrame').element_handle().content_frame();f.wait_for_function('!!window.SFPromptPipeline');posts=[];jobs={};flags={'unknown':False,'bad_refs':False,'slow':False,'token':'selected-A','switch':False};reads={}
   def route(req):
    path=req.request.url.split('/local-api/')[1]
    if path.endswith('/status'):return req.fulfill(json={'installed':True,'configured':True,'account_binding':True,'models':['fixture-portrait'],'selection':{'available':True,'token':flags['token'],'mode':'selected','account_name':'Fixture'}})
    if path=='analysis/frame-check':
     data=req.request.post_data_json;raw=base64.b64decode(data['image'].split(',')[1]);return req.fulfill(json={'can_quick_approve':True,'sha256':hashlib.sha256(raw).hexdigest(),'expected_label':data['expected_label'],'warnings':[]})
    if path.endswith('/jobs'):
     data=req.request.post_data_json;posts.append((path,data));rid=data['request_id']
     if data['kind']=='text':
      context=json.loads(data['prompt'].split('\nSCENE DATA:\n')[1]);used=[x['code']for x in context['bindings']if x['code'].startswith('R')]
      result={'promptFrame':{'vi':'Giữ bố cục R1, dùng sản phẩm R2','en':'Preserve R1 composition; use the product in R2.'},'used_refs':['R999']if flags['bad_refs']else used,'warnings':[]}
      if context['stage']=='video':result={'visual':{lang:{k:'Based on R1'for k in ['person','product','scale','composition','background','lighting']}for lang in ['vi','en']},'motion':{lang:{k:'Open the cap gently'if k=='action'else'Keep this shot'for k in ['camera','initial','final','action']}for lang in ['vi','en']},'used_refs':used,'warnings':[]}
      jobs[rid]={'state':'unknown'if flags['unknown']else'done','result':{'text':json.dumps(result),'account_id':'fixture'},'store_id':'fixture'}
     else:jobs[rid]={'state':'failed'if flags.get('fail_media')and data['kind']=='image'else'done','result':{'mime_type':'image/png'if data['kind']=='image'else'video/mp4','account_id':'fixture'},'store_id':'fixture'}
     if flags['switch']and data['kind']=='text':flags['token']='selected-B'
     return req.fulfill(json={'state':'submitted','store_id':'fixture'})
    if '/jobs/'in path:
     rid=path.rsplit('/',1)[-1];reads[rid]=reads.get(rid,0)+1
     return req.fulfill(json={'state':'running','store_id':'fixture'}if flags['slow']and reads[rid]==1 else jobs.get(rid,{'state':'unknown','store_id':'fixture'}))
    if '/files/'in path:
     record=jobs[path.rsplit('/',1)[-1]];clip=record['result'].get('mime_type')=='video/mp4';return req.fulfill(body=mp4 if clip else png,content_type='video/mp4'if clip else'image/png')
    req.continue_()
   p.route('**/local-api/gemini-chat/**',route);p.route('**/local-api/flow/**',route);p.route('**/local-api/analysis/frame-check',route)
   f.evaluate('''async data=>{project=blankProject();project.id='prompt-pipeline-test';project.source={asset:'source-fixture',duration:4,name:'Source',poster:'data:image/png;base64,'+data};project.analysis.semantic={provider:'fixture'};project.analysis.frameQualityRequired=true;project.mediaNodes={flowModel:'fixture-portrait'};project.scenes=[0,1].map(i=>({...sceneRecord(i*2,(i+1)*2,i,['data:image/png;base64,'+data]),id:'scene-'+i,refsUsed:['product'],visual:{vi:{product:'OLD BRAND'},en:{product:'OLD BRAND',composition:'Table shot'}},motion:{vi:{action:'Mở nắp'},en:{initial:'Cap closed',action:'Open cap',final:'Cap open'}},promptFrame:{vi:'Mẫu',en:'Template'}}));project.refs.product.images=[{id:'target-product',name:'Replacement',image:'data:image/png;base64,'+data}];project.script=[];const oldAddClip=addClip;addClip=async(...args)=>{await oldAddClip(...args);for(const s of project.scenes)for(const c of s.clips)if(c.localReview)c.localReview.warnings=[];};await storeProject();render();}''',encoded)
   # Initial plan authorization performs all stages without calling an extra modal/button.
   result=f.evaluate('async()=>{const plan=SceneForgeWorkflow.workspaceAutoPlan();return SceneForgeWorkflow.workspaceRunAutomatic("clips",plan.signature)}');assert 'đủ clip'in result['message'],result
   assert len(posts)==8,[(path,d['kind'])for path,d in posts]
   text=[d for path,d in posts if d['kind']=='text'];assert len(text)==4
   for d in text:
    c=json.loads(d['prompt'].split('\nSCENE DATA:\n')[1]);assert c['bindings'][0]['code']=='R1';assert c['bindings'][1]['role']=='product';assert 'product'not in c['observed_geometry'].get('en',{});assert c['neighbors']or c['stage']=='image'
    if c['stage']=='video':assert base64.b64decode(d['references'][0]['data'])==png
   assert f.evaluate('project.scenes.every(s=>s.receivedClipIds?.length===1)');before=len(posts);f.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("clips",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert len(posts)==before
   # Speech-only change keeps image prompts current and only invalidates the affected clip prompt.
   f.evaluate('project.script=[{id:"line1",start:0,end:2,original:"",newText:"New words"}]');assert f.evaluate('SFPromptPipeline.current(project.scenes[0],"image")');assert not f.evaluate('SFPromptPipeline.current(project.scenes[0],"video",clipParts(project.scenes[0])[0])');assert f.evaluate('SFPromptPipeline.current(project.scenes[1],"video",clipParts(project.scenes[1])[0])')
   # Original files/versions and reference scene IDs remain intact.
   assert f.evaluate('project.scenes.every(s=>s.frames.length===1&&s.clips.length===1)')
   # A prompt edited by the user never gets overwritten after source changes.
   f.evaluate('async()=>{project.scenes[0].framePromptOverride="My exact prompt";await SFPromptPipeline.write(project.scenes[0],"image");project.scenes[0].extraRequest="Changed source"}');count=len(posts)
   manual=f.evaluate('async()=>{try{await SFPromptPipeline.write(project.scenes[0],"image");return null}catch(e){return e.message}}');assert manual and len(posts)==count
   assert f.evaluate('project.scenes[0].framePromptOverride')=='My exact prompt'
   f.evaluate('closeModal();delete project.scenes[0].framePromptOverride')
   # A successful response for old input is kept but never applied; repeating only reads it.
   flags['slow']=True
   stale=f.evaluate('async()=>{project.scenes[1].extraRequest="Before";setTimeout(()=>{project.scenes[1].extraRequest="After"},50);try{await SFPromptPipeline.write(project.scenes[1],"image");return null}catch(e){return e.message}}');assert stale
   count=len(posts);f.evaluate('async()=>{try{await SFPromptPipeline.write(project.scenes[1],"image")}catch{}}');assert len(posts)==count and not f.evaluate('SFPromptPipeline.current(project.scenes[1],"image")')
   flags['slow']=False
   # Wrong reference identifiers never become a usable prompt and do not cause replay.
   flags['bad_refs']=True
   malformed=f.evaluate('async()=>{const s=structuredClone(project.scenes[0]);s.id="malformed";s.index=2;project.scenes.push(s);try{await SFPromptPipeline.write(s,"image");return null}catch(e){return e.message}}');assert malformed
   count=len(posts);f.evaluate('async()=>{try{await SFPromptPipeline.write(project.scenes[2],"image")}catch{}}');assert len(posts)==count
   flags['bad_refs']=False
   f.evaluate('workflowJobsDialog()');assert f.locator('[data-review-prompt-job]').count()>=1
   f.evaluate('async()=>{const r=SFPromptPipeline.records().records["malformed:image:"];await SFPromptPipeline.review(r.job.id)}')
   f.locator('#ppCorrectedText').fill(json.dumps({'promptFrame':{'vi':'Giữ R1, dùng R2','en':'Use R1 geometry and R2 product'},'used_refs':['R1','R2'],'warnings':[]}));f.locator('#ppApplyCorrection').click();f.wait_for_function('SFPromptPipeline.current(project.scenes[2],"image")');assert len(posts)==count
   # Unknown writing receipts are read, never resubmitted, even on repeated explicit runs.
   flags['unknown']=True;f.evaluate('project.scenes[0].extraRequest="Another composition"');r1=f.evaluate('async()=>{try{await SFPromptPipeline.write(project.scenes[0],"image");return null}catch(e){return e.message}}');count=len(posts);r2=f.evaluate('async()=>{try{await SFPromptPipeline.write(project.scenes[0],"image");return null}catch(e){return e.message}}');assert r1 and r2 and len(posts)==count
   # Changing the selected account between writing and generation stops before a media POST.
   reset='''async()=>{project.scenes=project.scenes.slice(0,1).map(s=>({...s,frames:[],clips:[],approvedFrame:null,frameSelectionId:null,extraRequest:'Fresh run',chosen:{}}));project.cloudJobs=[];project.script=[];project.promptPipeline={version:1,records:{},run:null};await storeProject();}'''
   f.evaluate(reset);flags['unknown']=False;flags['switch']=True;count=len(posts)
   error=f.evaluate('async()=>{try{await SFPromptPipeline.run("frames");return null}catch(e){return e.message}}');assert error and len(posts)==count+1 and posts[-1][1]['kind']=='text'
   flags['switch']=False;flags['token']='selected-A';flags['slow']=True;f.evaluate(reset);count=len(posts)
   error=f.evaluate('async()=>{setTimeout(()=>SFPromptPipeline.pause(),50);try{await SFPromptPipeline.run("frames");return null}catch(e){return e.message}}');assert error and len(posts)<=count+1 and all(d['kind']=='text'for _,d in posts[count:]) and f.evaluate('project.promptPipeline.run.state')=='paused', (error,len(posts)-count)
   # Automatic adoption uses the real import/timing guards, with a controlled analysis response.
   f.evaluate('''()=>{delete project.analysis.semantic;delete project.analysis.pendingAI;SceneForgeWorkflow.runAnalysisPipeline=async()=>{project.analysis.pendingAI={id:project.id,sourceAsset:project.source.asset,editSignature:analysisEditSignature(),result:{can_apply:true,partial:false,warnings:[],scenes:project.scenes.map(s=>({start:s.start,end:s.end,description:'Analyzed fixture',visual:structuredClone(s.visual),motion:structuredClone(s.motion),promptFrame:{vi:'Khung đã phân tích',en:'Analyzed frame'},hasPerson:false,hasProduct:true,faceTalking:false,competitorLogo:false})),script:[]}};};}''')
   count=len(posts);result=f.evaluate('async()=>SFPromptPipeline.run("analysis")');assert 'phân tích xong'in result['message']and len(posts)==count
   assert f.evaluate('!!project.analysis.semantic&&!project.analysis.pendingAI&&project.scenes[0].description==="Analyzed fixture"')
   # Node retry uses exactly the same replacement-aware writer and ordered files.
   f.evaluate(reset);flags['slow']=False;flags['unknown']=False;count=len(posts)
   f.evaluate('''async data=>{project.scenes=[project.scenes[0]];const s=project.scenes[0];s.refsUsed=['person','outfit','product'];s.visual.en.person='OLD young man wearing brown';s.promptFrame.en='OLD young man with OLD BRAND';project.refs.person.images=[{id:'secondary',name:'Secondary',image:'data:image/png;base64,'+data.secondary},{id:'face',name:'Face',primary:true,image:'data:image/png;base64,'+data.face}];project.refs.outfit.images=[{id:'dress',name:'Dress',image:'data:image/png;base64,'+data.dress}];await storeProject();await directDialog([s],{source:'gemini-chat',regenerate:true});}''', {key:base64.b64encode((lambda buf,color: (Image.new('RGB',(20,30),color).save(buf,format='PNG'),buf.getvalue())[1])(io.BytesIO(),color)).decode() for key,color in [('secondary','red'),('face','green'),('dress','yellow')]})
   f.locator('#directPrepare').click();f.wait_for_selector('#directSend')
   planned=posts[count:];assert len(planned)==1 and planned[0][1]['kind']=='text'
   context=json.loads(planned[0][1]['prompt'].split('\nSCENE DATA:\n')[1])
   assert [r['role']for r in context['bindings']]==['source','person','person','outfit','product']
   assert 'primary identity' in context['bindings'][1]['purpose']
   assert 'person' not in context['observed_geometry']['en']
   f.locator('#directSend').click();f.wait_for_function('project.cloudJobs.length===1&&project.cloudJobs[0].state==="submitted"')
   assert len(posts)==count+2 and posts[-1][1]['kind']=='image'
   sent=posts[-1][1];assert len(sent['references'])==5
   colors=[Image.open(io.BytesIO(base64.b64decode(i['data']))).convert('RGB').getpixel((0,0)) for i in sent['references']]
   assert colors[1:4]==[(0,128,0),(255,0,0),(255,255,0)],colors
   assert [hashlib.sha256(base64.b64decode(i['data'])).hexdigest() for i in sent['references']]==[hashlib.sha256(base64.b64decode(i['data'])).hexdigest() for i in planned[0][1]['references']]
   assert sent['prompt'].startswith('IMAGE EDIT CONTRACT v2') and 'OLD young man' not in sent['prompt']
   assert 'R2 for person identity' in sent['prompt'] and 'R4 for clothing' in sent['prompt'] and 'R5 for the actual replacement product' in sent['prompt']
   f.evaluate('async()=>{await directRecover({silent:true});closeModal();}')
   # The inspector's Retry is the send action: zero preparation/confirmation modals.
   count=len(posts)
   f.evaluate('()=>SFMediaNodes.open("frame",project.scenes[0].id)')
   f.locator('[data-mn="regenerate"]').click()
   f.wait_for_function('project.promptPipeline.run?.scope==="frame-node"&&project.promptPipeline.run.state==="done"')
   assert [d['kind']for _,d in posts[count:]]==['image']
   assert f.locator('#directPrepare,#directSend').count()==0
   assert f.evaluate('project.cloudJobs.at(-1).state==="imported"')
   assert f.locator('.mnResolution').count()==1
   # An explicit failure can be retried with one click; it does not get stuck reading the failed receipt.
   flags['fail_media']=True;count=len(posts)
   f.evaluate('()=>SFMediaNodes.open("frame",project.scenes[0].id)')
   f.locator('[data-mn="regenerate"]').click();f.wait_for_function('project.promptPipeline.run.state==="attention"')
   assert len(posts)==count+1 and f.evaluate('project.cloudJobs.at(-1).state==="failed"')
   failed_id=posts[-1][1]['request_id'];flags['fail_media']=False
   f.wait_for_selector('#node-frames [data-mn=rerun-node]:not([disabled])')
   f.evaluate('()=>SFMediaNodes.open("frame",project.scenes[0].id)')
   f.locator('[data-mn="regenerate"]').click();f.wait_for_function('project.promptPipeline.run.state==="done"')
   assert len(posts)==count+2 and posts[-1][1]['request_id']!=failed_id
   # One header click reruns the node (including its existing result) and returns every image.
   f.evaluate('''async()=>{const a=project.scenes[0];project.scenes.push({...structuredClone(a),id:'batch-second',index:1,frames:[],clips:[],approvedFrame:null,frameSelectionId:null,chosen:{}});await storeProject();render();}''')
   count=len(posts);f.locator('#node-frames [data-mn="rerun-node"]').click()
   f.wait_for_function('project.promptPipeline.run?.state==="done"&&project.promptPipeline.run.completed===2')
   media=[d for _,d in posts[count:]if d['kind']=='image'];assert len(media)==2
   assert {d['scene_id']for d in media}=={'scene-0','batch-second'}
   assert f.evaluate('project.scenes.every(s=>s.frames.length&&s.frames.at(-1).accountId==="fixture")')
   assert f.locator('#directPrepare,#directSend').count()==0
   # Stop is available during a slow in-flight image. It prevents the next scene from being sent.
   flags['slow']=True;count=len(posts)
   with p.expect_request(lambda req:'/gemini-chat/jobs'in req.url and req.method=='POST'and req.post_data_json.get('kind')=='image'):
    f.locator('#node-frames [data-mn="rerun-node"]').click()
   f.locator('#node-frames [data-mn="pause-frames"]').click()
   f.wait_for_function('project.promptPipeline.run.state==="paused"')
   assert len([d for _,d in posts[count:]if d['kind']=='image'])==1
   flags['slow']=False;f.evaluate('async()=>directRecover({silent:true})')
   # A partial node still exposes Create for missing frames alongside Approve.
   f.evaluate('''async()=>{project.scenes[1].frames=[];project.scenes[1].approvedFrame=null;project.scenes[1].frameSelectionId=null;project.cloudJobs=project.cloudJobs.filter(j=>j.sceneId!=='batch-second');await storeProject();render();}''')
   assert f.locator('#node-frames [data-mn="create"]').count()==1
   f.evaluate('()=>{project.scenes=project.scenes.slice(0,1);render();}')
   # Keep manual scene directions while regenerating fresh, immutable role bindings.
   count=len(posts)
   f.evaluate('''async()=>{const s=project.scenes[0];s.framePromptOverride='My manual composition';s.frameManualInput=SFPromptPipeline.snapshot(s,'image');await SFPromptPipeline.prepareImage(s);}''')
   assert len(posts)==count and f.evaluate('project.scenes[0].framePromptOverride')=='My manual composition'
   assert f.evaluate('imageFramePrompt(project.scenes[0]).includes("My manual composition")')
   f.evaluate('project.refs.person.images[0].id="changed-reference"')
   err=f.evaluate('async()=>{try{await SFPromptPipeline.prepareImage(project.scenes[0]);return null}catch(e){return e.message}}')
   assert err and len(posts)==count and f.locator('#ppKeepManual').count()==1
   assert not errors,errors;b.close();print('PASS actual one-click reference pipeline: two scenes, role-bound image prompts -> original generated start frames -> per-part Gemini motion -> actual MP4 import; one-click inspector retry and whole-node rerun, stop before next image, failed-receipt retry, measured resolution display, no extra stage clicks, no duplicate rerun, per-field speech staleness, exact identities/files, neighbor context, stale in-flight response refused, malformed reference IDs refused, manual prompt preserved, unknown receipt read-only, account switch and pause prevent media dispatch; provider/quality fixtures only')
 finally:proc.terminate();proc.wait(timeout=10)
