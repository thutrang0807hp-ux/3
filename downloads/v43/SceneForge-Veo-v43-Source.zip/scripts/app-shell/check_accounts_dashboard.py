from pathlib import Path
from functools import partial
import http.server,threading,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1800,'height':1500});errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url));page.goto(f'http://localhost:{server.server_port}/?demo=1&accounts=flow');expect(page.locator('.acctDashboard')).to_be_visible(timeout=60000);expect(page.locator('[data-account-row]')).to_have_count(5);expect(page.locator('.acctGraphNode.primary')).to_have_count(1);expect(page.locator('.acctRequest')).to_have_count(3);expect(page.locator('#connectAccount')).to_be_disabled();expect(page.locator('#accountDispatchMode')).to_be_disabled();assert page.locator('.acctTopGrid').evaluate('(n)=>getComputedStyle(n).gridTemplateColumns').count('px')==2
  expect(page.locator('#dialogTitle')).to_have_text('Cài đặt');expect(page.locator('[data-g5-tab=accounts]')).to_have_class('active');expect(page.locator('.g5SettingsTitle h2')).to_have_text('Tài khoản')
  frame=page.locator('#shellDialog').bounding_box();title=page.locator('.g5SettingsTitle').bounding_box();menu=page.locator('.g5Settings>nav').bounding_box()
  page.locator('.g5SettingsScroll').evaluate('(n)=>n.scrollTop=500');assert page.locator('.g5SettingsScroll').evaluate('(n)=>n.scrollTop')>0
  assert page.locator('#shellDialog').bounding_box()==frame;assert page.locator('.g5SettingsTitle').bounding_box()==title;assert page.locator('.g5Settings>nav').bounding_box()==menu
  page.locator('.g5SettingsScroll').evaluate('(n)=>n.scrollTop=0')
  page.screenshot(path='/tmp/sceneforge-accounts-desktop.png',full_page=True)
  page.locator('[data-account-range="30"]').click();expect(page.locator('.acctBars>div')).to_have_count(30);page.locator('[data-account-range="7"]').click()
  second=page.locator('[data-account-row]').nth(1).get_attribute('data-account-row');page.locator('[data-account-row]').nth(1).locator('[data-account-move][data-direction="-1"]').click();expect(page.locator('[data-account-row]').first).to_have_attribute('data-account-row',second)
  page.locator('[data-account-row]').first.locator('[data-use-account]').click();expect(page.locator('.acctGraphNode.primary b')).to_have_text('flow.phu1');page.locator('[data-account-row]').first.locator('[data-account-enable]').click();expect(page.locator('.acctGraphNode.primary')).to_have_count(0)
  page.locator('[data-account-row]').first.locator('[data-account-edit]').click();expect(page.locator('.g5Settings>nav')).to_be_visible();expect(page.locator('#dialogTitle')).to_have_text('Cài đặt');page.locator('#accountEditName').fill('Tài khoản mẫu đã đổi');page.locator('#accountEditSave').click();expect(page.locator('[data-account-row]').first).to_contain_text('Tài khoản mẫu đã đổi');page.reload();expect(page.locator('[data-account-row]').first).to_contain_text('Tài khoản mẫu đã đổi');page.locator('[data-account-service="muse"]').click();expect(page.locator('[data-account-row]')).to_have_count(5);expect(page.locator('.acctServiceNote')).to_contain_text('muse.ai');expect(page.locator('.acctRequest').first).to_contain_text('Video')
  page.set_viewport_size({'width':390,'height':844});expect(page.locator('.acctDashboard')).to_be_visible();assert page.locator('#shellDialog').evaluate('(n)=>n.scrollWidth<=n.clientWidth+1');page.screenshot(path='/tmp/sceneforge-accounts-mobile.png',full_page=True)
  page.locator('#closeDialog').click();page.evaluate('SceneForgeApp.settings.open("export")');expect(page.locator('.g5Settings')).to_be_visible();assert 'acctDialog'not in page.locator('#shellDialog').get_attribute('class');page.locator('[data-g5-tab=accounts]').click();expect(page.locator('.acctDashboard')).to_be_visible();expect(page.locator('[data-g5-tab=accounts]')).to_have_class('active');expect(page.locator('#dialogTitle')).to_have_text('Cài đặt')
  assert not [u for u in requests if '/local-api/'in u],requests;assert not errors,errors
  live=b.new_page(viewport={'width':1400,'height':1000});live.route('**/local-api/status',lambda r:r.fulfill(json={'accounts':[],'logs':[],'engines':{},'rotation':{}}));live.route('**/local-api/logs',lambda r:r.fulfill(json=[]));live.goto(f'http://localhost:{server.server_port}/');live.wait_for_function('SceneForgeApp.getState().products.length>0');live.evaluate('SceneForgeApp.accounts.open("flow")');expect(live.locator('.acctDashboard')).to_be_visible();expect(live.locator('[data-account-row]')).to_have_count(0);expect(live.locator('.acctCostEmpty')).to_contain_text('Chưa có chi phí');expect(live.locator('#connectAccount')).to_be_enabled();assert not live.locator('.acctLive').inner_text()=='MINH HỌA';# A late account response must never pull the user out of the tab they chose.
  web_calls=[];web_state={'state':'waiting'}
  def web_login(route):
   if route.request.method=='POST':web_calls.append('POST')
   route.fulfill(json={'opened':True,'message':'Đã mở profile Flow riêng.',**web_state})
  live.route('**/local-api/flow/web-login',web_login)
  live.locator('#flowWebLogin').click();expect(live.locator('#dialogTitle')).to_have_text('Đăng nhập Flow trên web')
  expect(live.locator('#flowWebConnectCode')).to_be_visible();assert web_calls==['POST']
  live.route('**/local-api/browser-bridge/setup',lambda r:r.fulfill(json={'folder':'fixture-extension','download':'/fixture.zip'}))
  live.locator('#flowWebConnectCode').click();expect(live.locator('#bridgeCreate')).to_be_visible()
  expect(live.locator('#bridgeWebLogin')).to_be_visible();live.locator('#bridgeWebLogin').click()
  expect(live.locator('#bridgeNote')).to_contain_text('Đã mở profile Flow riêng');assert web_calls==['POST','POST']
  expect(live.locator('#bridgeCreate')).to_have_text('Tạo mã kết nối')
  live.evaluate('SceneForgeApp.accounts.open("flow")');expect(live.locator('#flowWebLogin')).to_be_visible()
  live.locator('#flowWebLogin').click();expect(live.locator('#flowWebStatus')).to_be_visible()
  web_state['state']='done';expect(live.locator('.acctDashboard')).to_be_visible(timeout=10000)
  assert web_calls==['POST','POST','POST']
  live.route('**/local-api/logs',lambda r:r.fulfill(json=[{'id':'flow-legacy','kind':'Flow','state':'unknown','code':'HTTP_409','at':1},{'id':'flow-modern','service':'flow','kind':'Flow','state':'failed','code':'CAPTCHA_REQUIRED','message':'Flow yêu cầu captcha/xác minh.','at':2},{'id':'muse-hidden','service':'muse','kind':'Muse','state':'failed','at':3}]))
  live.evaluate('SceneForgeApp.accounts.open("flow")');expect(live.locator('.acctRequest')).to_have_count(2)
  expect(live.locator('.acctRequest').nth(0)).to_contain_text('CAPTCHA_REQUIRED')
  expect(live.locator('.acctRequest').nth(1)).to_contain_text('HTTP_409')
  live.route('**/local-api/status',lambda r:r.fulfill(json={'accounts':[],'logs':[],'engines':{},'rotation':{}}))
  live.evaluate('SceneForgeApp.accounts.open("muse");document.querySelector("[data-g5-tab=export]").click()')
  live.wait_for_timeout(350);expect(live.locator('.g5SettingsTitle h2')).to_have_text('Xuất video');expect(live.locator('.acctDashboard')).to_have_count(0)
  assert not errors,errors
  b.close()
 print('PASS dashboard layout, 5 labelled demo accounts, graph selection, logs, 7/30-day chart, priority, enable/name actions, service tabs, mobile overflow and dialog reset; zero account/API requests in demo.')
finally:server.shutdown()
