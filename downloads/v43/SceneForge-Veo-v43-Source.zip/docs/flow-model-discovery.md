# Empty Flow model picker — v13

User reached the video node with an available Flow account but no model options.
Account import/sync did not populate the model cache. The UI only read cached
status, then combined absent model and account binding into an obsolete generic
message asking for a newer engine. Account authentication was not the blocker
shown in those screenshots.

The Flow status endpoint now reads the local engine /v1/models automatically
when configured and uncached. It serializes concurrent reads and throttles failed
attempts for 15 seconds. No Google generation or reconnection is triggered. A
catalog update merges with current configuration, preserves concurrently written
account/journal flags, and refuses to overwrite a different engine connection.

The dialog clears stale errors, waits for model loading before enabling prepare,
keeps the selected model, and reports model discovery separately from missing
account binding. The same status behavior serves reference and photo workflows.
The patch explicitly ships the updated flow_provider.py as well as rebuilt UI.
No extension change, permission change or account reset is necessary.

Windows checks reproduce the actual UI with an initially empty cache and an
already selected account, verify a single local catalog GET populates the model
picker, and verify no generation, account switch or lost binding. Backend checks
cover concurrency, failure cooldown and a connection change during discovery.
The native-browser transport and previous Windows lifecycle checks also pass.

Limit: local catalog availability is not proof that every listed model is usable
by the Google account, and paid generation is not certified. The older broad
check_direct_workflow fixture did not reach its first image review in the current
prompt-writing pipeline; it is not counted as a passed end-to-end generation
check. The targeted empty-model UI test and Windows checks are the validation for
this change.

Apply only the small v13 updater. Keep the existing browser and paired Flow tab
open; extension remains 1.5.0. The next node/status read automatically reads the
catalog. The user can select the model and review the send; no settings/catalog
button or account re-pairing is required.
