# Flow through the paired native browser — v12 / extension 1.5.0

Live evidence from the user: engine credit request returned 401 after v11, while
extension 1.4's same-origin credit RPC inside their signed-in Flow tab returned
FLOW_BROWSER_CREDIT_OK / HTTP200. Copying more cookies did not fix their failure.
The failing engine path must not be described as a verified authentication fix.

The new transport keeps frontend authentication inside the explicitly paired
Flow tab. An MV3 worker receives bounded, capability-authenticated jobs through
the app's loopback broker, executes a fixed local function in the tab's MAIN
world, and returns results to the existing pinned SDK parsers. RPC, StreamChat
and native reCAPTCHA execution have dedicated operations; there are no arbitrary
URL, script or navigation jobs. It uses current page WIZ/XSRF data and browser-
managed credentials instead of replaying exported Flow cookies over curl.

Connection still verifies the signed-in identity and actual credit RPC, creates
SDK projects, checks the imported account, and selects the exact returned engine
ID. No credit/readiness bypass, automatic generation on connect or silent model
change is introduced. Existing shared/separate Gemini/Flow pairing remains.
Gemini continues its previous adapter. Old installed Google cookie credentials
remain supported by the old transport until the user explicitly pairs native
Flow with extension 1.5.

Security and lifecycle:

- Separate random engine/browser capabilities per route, exact extension Origin
  and loopback Host guard, bounded bodies, no route keys in pairing status/logs.
- Route capabilities use the existing private vault. Worker links and identity
  hashes use storage.session; no cookies are stored by the extension.
- A link pins the selected tab ID and signed-in email hash. Changed identity is
  refused before RPC; closed/missing tab disconnects. No auto-selection of a new
  tab/account. Browser restart requires a new pairing code.
- Jobs dispatch once. Late, replayed and cross-route results are refused. Timeout
  after dispatch is unknown, never an automatic duplicate send. Native generation
  still uses the existing SDK's one-attempt/journal behavior.
- Old exported-cookie refresh fallback is disabled for native routes. AT refresh
  verifies through the browser without revalidating stale exported cookie expiry.
- A browser worker alarm/heartbeat keeps the selected route alive while requests
  run. Keep Chrome/Edge and the paired Flow tab open; the popup may close.
- The new extension needs scripting, storage and alarms in addition to cookies.
  No new website host permissions, external captcha service or background cookie
  export is added. Generation only follows an explicit app task.

Validation: existing account-pinning/busy/duplicate tests, app boundary and
pairing tests, broker capability/offline/cancel/replay tests, and real Windows
extension/worker -> broker -> actual pinned FlowClient tests with synthetic Flow
pages. Native tests exercise credit/project import, correct account selection,
stream return, captcha action routing, secret exclusion, and account-change
refusal. Real Google paid generation has not been run; the user's live native
connection still needs confirmation. Fixture success does not guarantee every
Google generation request succeeds.

Install the small v12 patch, reload extension 1.5.0 (replace a separately extracted
extension folder with the new ZIP), accept new permissions if asked. With the
correct Flow tab open, pair once using a fresh code. No EXE baseline/models need
to be re-downloaded. Do not remove the existing Gemini account.
