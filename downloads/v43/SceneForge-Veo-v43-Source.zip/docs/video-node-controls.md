# Video Veo node: shared model and batch Run — v14

A project-level model dropdown is now on the video node, with readable names and
actual variant durations. Common Fast/Quality image-to-video variants and Omni
8s are shown first. Other source-provided portrait variants are in Advanced.
The selected model remains visible even when it is an advanced variant. Nothing
silently selects another model, account or source. Changes affect new requests.

The node header Run N clips button uses the selected model for all eligible slots.
The explicit click authorizes the counted batch; the node displays that creation
may cost credit. It uses the existing durable intent, selection token, scene/part
signature and per-request checks, automatically advances the old prepare/send
UI, and never requires opening each clip. Legacy individual inspector actions
remain available. The operation is guarded against double-clicks and the node
shows preparation errors. Existing result polling receives results as before.

Eligibility is conservative: approved frame, no recorded clip version/file,
Flow source, and either no receipt or confirmed failed/not_submitted receipt.
Queued/running/unknown/missing/invalid/done, abandoned and imported receipts are
not automatic retries. Missing local bytes for an existing clip are not a reason
to pay for another generation. Continuity parts wait for the approved predecessor.
Source/user changes before dispatch still stop the batch; partial sends retain
receipts. No automatic account/model switching or repeat paid sends is added.

A missing video had also been misclassified as a changed-prompt review because
both optional IDs were undefined. Comparing only when an actual clip exists
restores waiting/count behavior. Duplicate clip create/retry bulk buttons are
removed in favor of the single header Run action; frame controls are unchanged.
Displayed estimates use the chosen node model, never an unrelated old scene model.

Validation: real local UI and actual Windows Chromium fixture tests cover the
shared primary and Advanced selectors, selected model persistence, fresh missing
slots, exact two-slot batch dispatch, no required prepare/send modal, existing
version preservation, uncertain/queued/unapproved/abandoned/imported exclusions,
missing bytes, double-click prevention, and uncertain POST error visibility with
no resend. A room switch during model loading blocks dispatch even when scene
IDs could match another project. Provider endpoints are intercepted; no Google generation was sent.
Existing Windows updater/native lifecycle, model discovery and native-browser
transport checks also run. This is not certification of Google model access,
price, generation duration or paid video quality for a particular account.

Install only the small v14 updater; keep extension 1.5 and current account. Select
the model on the Video Veo node once, then click Run N clips on that node. Keep
app/Chrome/Edge and paired Flow tab open while the native browser transport runs.
