# Flow cookie scope correction — 29/10/2026

Patch 2026.10.29.9. Extension stays at 1.2.0: no extension reinstall, reload or new permission is required for users already on that version.

## Confirmed false rejection in v8

After the user confirmed extension 1.2.0 and reported FLOW_SESSION_COOKIE_MISSING, code inspection found an additional app defect. The v8 preflight required the session cookie's domain to be exactly flow.google.com. The actual pinned engine accepts any valid session cookie a browser would send to https://flow.google.com/projects, including a DOMAIN cookie at .google.com. A synthetic root-domain OSID plus SID is accepted by the actual engine validator and rejected by the old app guard; this counterexample was reproduced before editing. It does not reveal or establish the affected user's actual cookie contents.

## Change

Eligibility now respects browser domain, host-only, path, expiry, partition and value validity for the Flow request target. Both host-only Flow sessions and Google DOMAIN sessions may qualify. A host-only google.com cookie does not qualify for flow.google.com; unrelated paths, expired and partitioned cookies still do not pass. Real engine verification is retained; no fabricated success or fallback account selection is added.

On a failed Flow connection, pairing status includes bounded diagnostic metadata: received count, session cookie name/domain/path/host-only flags, applicability to Flow and Google identity applicability. Cookie values and provider exception text are excluded. The connection dialog exposes a collapsible copyable view only when such diagnostics exist. Partial pairing results remain visible rather than immediately dismissing the dialog. Existing paired credentials and independent selections remain unchanged.

## Validation

The installed/pinned vendor's actual validator is compared with app eligibility across root-domain and host-only sessions, both session names, scope paths, expiry, partitioning and identity scope. The actual unpacked extension test covers both cookie placements in real Chromium cookie storage. Real app tests exercise secret-free diagnostics after a rejected transfer, shared/separate connections and source panels in both tabs. All previous native lifecycle, image/chat, source analysis and data-preserving update checks remain in the release gate.

Tests use synthetic sessions and provider I/O. They prove the corrected scope handling and diagnostics, not live account authentication. The user's real connection result must be checked; if it still fails, the safe diagnostic summary can distinguish absent cookie data from an app-side scope rejection without requesting a credential dump.
