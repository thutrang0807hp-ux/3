# Flow connection: missing current-site session — 29/10/2026

Patch 2026.10.29.8; browser extension 1.2.0. Cumulative small update for the existing v2 installation and v1–v7 patches.

## Confirmed defect

The user signs in at `https://flow.google.com/?pli=1`. The pinned Flow engine's actual `browser_cookie_utils.validate_flow_cookie_storage` requires a Flow session (`OSID` or `__Secure-OSID`) and a Google account cookie. The v7 extension queried only Google root and the legacy Labs URL, without permission for flow.google.com. A host-only Flow cookie cannot be returned by those queries. Previous connection tests mocked the Flow importer, so they accepted an incomplete cookie set and missed this contract failure.

## Changes

- Extension adds the narrow `https://flow.google.com/*` host permission and queries the current Flow root and `/projects`, retaining Labs for legacy cookies and Google root for account identity. Existing extension ID/key remain unchanged.
- Host-only and SameSite cookie scope survive transfer. Chrome SameSite values are normalized to the vendor representation. Partitioned cookies are skipped rather than having their scope stripped.
- App and owned engine validate required Flow cookies before account import, refusing the known incomplete transfer without calling the provider. Google-only and Flow-only connections remain scoped; Flow's host-only cookies are not sent to the Gemini SDK.
- A fixed allow-list of connection error codes identifies missing Flow cookies, missing Google identity, local engine availability, import, busy account and session-check errors. App-facing messages are local strings; raw provider exceptions and cookie material are never forwarded. The pairing dialog shows the failure code for troubleshooting.
- Shared/separate account selection, frame-node one-click generation, original image downloads, project image chats and earlier fixes remain.

## Installation

Update the app, reload extension 1.2.0 in chrome://extensions or edge://extensions, and accept Flow site access if requested. An extension loaded from an independent extracted ZIP must be replaced with the new app-provided folder/ZIP. Verify the displayed version is 1.2.0. Open Flow in that same browser/profile, then create a new pairing code. Existing Gemini accounts need not be removed.

## Verification

The revised test imports the ACTUAL cookie validator from the pinned Flow source: it rejects the old Google/Labs-only set and accepts a correctly scoped host-only Flow session plus Google identity. Tests also exercise safe engine error relaying, missing-cookie failure before provider calls, separate/joint account selection and exact duplicate-account refresh.

The Windows release gate now uses a real browser cookie scoped only to flow.google.com. It verifies that Google-root queries cannot return it and that the actual unpacked extension transfers it to Flow, while Gemini never receives it. It also runs the actual installed vendor cookie validator and all prior native application checks. This tests cookie discovery, scope and contract rather than pretending root Google cookies are sufficient.

Provider I/O remains synthetic in automated tests; no real Google authentication, credit check or generation is certified. If further failures remain, the new stage-specific code identifies the next issue without requesting user credentials in chat.
