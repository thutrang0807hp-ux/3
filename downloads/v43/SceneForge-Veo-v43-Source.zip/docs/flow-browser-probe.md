# Flow still returns 401 after v11 — live browser diagnostic

The user repeated a live engine credit-check 401 after updating to v11. Cookie
count increased from 16 to 17, bootstrap completed, credit RPC still failed.
V11's cookie/context corrections therefore did not resolve this user's failure.
Do not describe that patch or its fixture tests as a verified Google auth fix.

No further installer/backend changes are made here. Extension 1.4.0 adds an
explicit read-only check inside the existing Flow tab via Chrome scripting MAIN
world. It uses that tab's browser-managed credentials and bootstrap data, then
calls only the same nzlxg credit RPC. It creates no project/image/video. The
report contains fixed codes, booleans and numeric HTTP/RPC status, never cookies,
tokens, HTML, email or raw provider responses. The probe requires the new
`scripting` permission; host permissions and extension ID are unchanged. There
is no background worker or automatic probe on connection/startup.

Testing uses a real unpacked extension and real Chromium same-origin fetch on
Windows, against fixture Flow pages intercepted by Playwright. Cases cover zero
credit success, RPC401, HTTP403, HTML bootstrap fallback, absent metadata with no
network request, MAIN world visibility, scoped HttpOnly credential sending and
exclusion of fixture secrets from diagnostics. There is no live Google account
available in this workspace. This is a diagnostic tool, not a completed 401 fix.

User action: replace extracted extension files, reload version 1.4.0 and accept
new permission. Open their logged-in Flow tab, open SceneForge extension, expand
Kiểm tra Flow, click Kiểm tra trong tab Flow, then copy report. No app update,
pairing code or reconnection is needed. Preserve existing Gemini selection.

Next investigation depends on the live result:

- Browser CREDIT_OK + engine401: investigate exported-session / backend request
  behavior; consider sustained native browser transport, not bypassing checks.
- Browser RPC_AUTH_REJECTED / HTTP401: investigate the RPC protocol and account
  selection even inside the working browser. Do not assume the account cannot
  use Flow, and do not ask the user to change proxies/accounts on this evidence.
- Metadata missing / response unrecognized: inspect current frontend protocol
  without collecting secrets. Do not mark authenticated based on page loading.
