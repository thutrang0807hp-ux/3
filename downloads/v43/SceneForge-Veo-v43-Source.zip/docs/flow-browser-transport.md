# Flow browser context and RPC cookies — v11

User report: extension transferred 16 cookies, Flow bootstrap completed, but the
credit RPC returned 401. This establishes a failure authenticating the app's RPC,
not exhausted credit. It does not prove which credential or request field Google
rejected. No real user credentials were available to reproduce that response.

Inspected defects corrected:

- Extension URL cookie queries for `/` and `/projects` omitted credentials scoped
  to `/_/`, the actual RPC path. Version 1.3.0 queries permitted Google/Flow domains
  across paths and retains host-only, domain, path, expiry, Secure, HttpOnly and
  SameSite. Unrelated hosts and partitioned cookies stay excluded.
- The imported session previously discarded the originating browser User-Agent
  and explicit `authuser` selection. A validated private envelope now carries
  these through credit/project RPCs, StreamChat, identity lookup and cookie
  rotation. The active Flow tab supplies an explicit numeric authuser; the code
  does not guess an account index if absent. SDK identity lookup uses the same
  selection, preventing default-account names being attached to another account.
- Context is task-local, survives persistence/restart with the private cookie
  storage, and is never put in account lists or connection diagnostics. Existing
  provider fingerprints retain other fields. No cross-host authuser injection.
- Gemini joint imports retain root-path cookies as before; additional Flow RPC
  path cookies must not overwrite its flat cookie dictionary.

The original SDK still validates cookies, reads real credits, verifies identity
where available, creates projects and checks the imported account. No 401 retry,
no bypass, no fake ready/credit state, no generation request during tests.

Validation: `python -m local_engine.check_flow_transport <pinned-source>` runs the
actual pinned FlowClient and actual curl_cffi against an isolated TLS loopback
server with fixture credentials. The old transport receives 401, as does a new
request missing its RPC-path cookie. The corrected transport passes account,
UA, XSRF and scoped-cookie checks; rotated cookies, concurrent accounts, identity
lookup and persisted restart pass. This reproduces the transport omissions, not
Google's private authentication policy. The same wire check also passes with the engine-pinned curl_cffi 0.13.0. The
original Google account still needs live verification. Windows CI also loads the real unpacked extension and checks
RPC-only cookie capture plus UA/authuser transfer, alongside existing checks.

Apply the small v11 updater, then reload extension 1.3.0. If extension was loaded
from a separately extracted ZIP, replace that folder with the new ZIP first.
No additional permissions, background worker or new manual generation buttons.
