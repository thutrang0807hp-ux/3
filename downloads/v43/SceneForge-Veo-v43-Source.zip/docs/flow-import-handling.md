# Flow account import handling and phase diagnostics — 29/10/2026

Patch 2026.10.29.10. Extension remains 1.2.0, unchanged. The user's latest report contains usable host-only OSID and __Secure-OSID plus Google identity, so the connection has passed cookie transport/preflight and now fails during engine account import.

## Confirmed adapter defect

The owned Flow account endpoint caught every ValueError from TokenManager.add_token and retried it as a duplicate-account identity lookup. The vendor uses ValueError for authentication, project setup and duplicate errors alike. This branch could obscure the original failure and perform an unrelated additional identity request.

Only a positively observed exact database lookup match now permits duplicate reuse. The selected row must remain active and have no in-flight work. Its existing concurrency/disabled policy are preserved; failures in authentication, network, project creation or storage are not retried as duplicate identity lookup.

## Per-request phase observations

The owned adapter observes named methods of the installed engine's existing client/manager/database through context-local wrappers. Outside an explicit account-import request, the methods behave as before. Failures preserve the innermost original phase through the vendor's exception translation. A recovered identity failure does not prevent a later successful import; a later unrelated project failure replaces that recovered error.

Allowed phases are bootstrap, authentication, credit read, identity, project setup, local storage, lookup and refresh. Only fixed phase labels, fixed error categories, bounded completed-step labels and a numeric HTTP status can cross the engine/app boundary. Provider text, response bodies, cookies, access tokens and exception tracebacks are not included. The existing safe diagnostic copy view shows the extra fields. Existing selections and model/project data remain; no generation or fallback API call is triggered by these diagnostics.

## Validation

A new checker reads and executes the ACTUAL pinned vendor TokenManager.add_token method without editing its control flow, substituting provider/database/data-model dependencies. It exercises bootstrap 401, authentication SDK failure, credits 403, project creation 403, database-save failure, recovered identity failure, a later project error, exact ST/email duplicate reuse and a busy-account refusal. The original method's exception translation is therefore exercised instead of mocking the entire add_token method. All cases verify no spurious duplicate retry and no private fixture text in public responses.

The release gate runs this checker against the installed pinned source on Windows, together with the existing actual cookie-contract, extension, pairing, SDK/chat, CPU/speech/export and lifecycle checks.

## Practical limit

This fixes a real error-handling defect and exposes the point of rejection. It does NOT establish the user's live provider failure cause or certify their account authentication. A live Google refusal or changed Flow endpoint may still require another provider-specific correction once the phase/status is known. Do not call this a verified successful live Flow connection. No extension reinstall or account change is required by this patch.
