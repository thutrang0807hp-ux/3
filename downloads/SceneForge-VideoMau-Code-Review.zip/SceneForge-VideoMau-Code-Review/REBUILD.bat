@echo off
cd /d "%~dp0"
call npm ci --prefix scripts\watermark-builder
if errorlevel 1 exit /b 1
python scripts\demo-web\build.py
pause
