from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'review/manifest.json').read_text())
for row in manifest['files']:
 path=root/row['path']
 assert path.is_file(),row['path']
 assert path.stat().st_size==row['bytes'],row['path']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS',len(manifest['files']),'files match the review snapshot. No provider requests made.')
