// Recover local results through the existing queue; keep the approved board geometry.
let localRecovery={jobs:[],resources:null,error:''},localRecoveryReading=null;
const localRecoveryAllowed=()=>!isShowcase&&['127.0.0.1','localhost'].includes(location.hostname);
function roomAttention(room){
 if(room.stage==='exported')return null;
 const uncertain=jobs.find(j=>j.roomId===room.id&&['unknown','submitted'].includes(j.status));
 if(uncertain)return {kind:'queue',label:'Chưa rõ kết quả · kiểm tra hàng chờ'};
 if(room.error)return null; // Preserve the existing error dialog and copy-details action.
 const recent=localRecovery.jobs.filter(j=>j.room_id===room.id).sort((a,b)=>(b.at||b.created||0)-(a.at||a.created||0)),active=recent.find(j=>['uploading','queued','running'].includes(j.state));
 if(active)return {kind:'local',label:active.state==='queued'?'Đang xếp lượt trên máy · xem tiến độ':'Máy đang xử lý · xem tiến độ',column:'running'};
 const done=recent.find(j=>j.state==='done'&&j.lane!=='analysis'&&(j.created||0)*1000>(room.exportedAt||0));
 if(done)return {kind:'local',label:'MP4 đã xong · tải lại kết quả',column:'attention'};
 const latest=recent.filter((j,i)=>recent.findIndex(x=>x.lane===j.lane)===i);
 const interrupted=latest.find(j=>j.recovered&&j.state==='error'&&(j.at||j.created||0)*1000>(room.localRecoverySeenAt||0));
 if(interrupted)return {kind:'local',label:'Lượt trên máy bị ngắt · xem chi tiết',column:'attention'};
 if(room.stage==='editing')return {kind:'editor',label:'Mở Dựng & xuất'};
 if(jobs.some(j=>j.roomId===room.id&&j.status==='running'))return null;
 if(Number.isFinite(room.pendingFrames)&&room.pendingFrames>0)return {kind:'frames',label:'Rà '+room.pendingFrames+' khung chưa duyệt',column:'attention'};
 if(room.stage==='generating'&&Number.isFinite(room.sceneCount)&&room.sceneCount>0&&Number.isFinite(room.readyScenes)){
  const missing=Math.max(0,room.sceneCount-room.readyScenes);
  return missing?{kind:'clips',label:'Còn '+missing+' cảnh chưa đủ clip · mở kiểm tra',column:'attention'}:{kind:'editor',label:'Đủ clip · mở Dựng',column:'attention'};
 }
 return null;
}
const recoveryNextBefore=nextAction;nextAction=function(room){return roomAttention(room)?.label||recoveryNextBefore(room);};
const recoveryColumnBefore=roomColumn;roomColumn=function(room){return roomAttention(room)?.column||recoveryColumnBefore(room);};
const recoveryCardBefore=card;card=function(room,compact=false){
 const attention=roomAttention(room),html=recoveryCardBefore(room,compact);if(!attention)return html;
 const t=document.createElement('template');t.innerHTML=html;
 if(compact){const root=t.content.firstElementChild;root.dataset.attentionRoom=room.id;root.setAttribute('aria-label',room.name+' · '+attention.label);}
 else{const bottom=t.content.querySelector('.cardBottom');if(bottom){let button=bottom.querySelector('[data-open-room]');if(!button){button=document.createElement('button');bottom.append(button);}button.textContent=attention.label;button.dataset.attentionRoom=room.id;button.title=attention.label;}}
 return t.innerHTML;
};
async function openRoomAttention(room){
 const a=roomAttention(room);if(!a)return openRoom(room.id);
 if(a.kind==='queue'||a.kind==='local'){showQueue();await refreshLocalJobs();const node=$('#localJobHistory [data-local-room="'+CSS.escape(room.id)+'"]')||$('#queueList [data-job="'+CSS.escape(jobs.find(j=>j.roomId===room.id)?.id||'')+'"]');node?.scrollIntoView({block:'nearest'});return;}
 if(a.kind==='editor')return openRoom(room.id,'editor');
 await openRoom(room.id,'analysis');
 if(room.mode!=='photos')$('#workflowFrame')?.contentWindow?.SceneForgeWorkflow?.focusTopbarStep?.(a.kind==='frames'?1:2);
}
$('#board').addEventListener('click',e=>{const target=e.target.closest('[data-attention-room]');if(!target)return;e.preventDefault();e.stopImmediatePropagation();const r=roomFor(target.dataset.attentionRoom);if(r)openRoomAttention(r).catch(fail);},true);
$('#board').addEventListener('keydown',e=>{if(e.key!=='Enter'||!e.target.matches('article[data-attention-room]'))return;e.preventDefault();e.stopImmediatePropagation();const r=roomFor(e.target.dataset.attentionRoom);if(r)openRoomAttention(r).catch(fail);},true);
const localJobLabel=j=>({analysis:'Phân tích CPU',timeline:'Xuất timeline',finishing:'Chuyển MP4'}[j.lane]||'Tác vụ trên máy');
const localJobPath=j=>j.lane==='analysis'?'analysis/local/jobs/'+encodeURIComponent(j.id):j.lane==='timeline'?'export/timeline/'+encodeURIComponent(j.id):'export/jobs/'+encodeURIComponent(j.id);
function paintLocalJobs(){
 if(!localRecoveryAllowed())return;
 let panel=$('#localJobHistory');if(!panel){panel=document.createElement('section');panel.id='localJobHistory';panel.className='queueLane';$('#queueList').prepend(panel);}
 const states={uploading:'Đang nhận tư liệu',queued:'Đang xếp lượt',running:'Đang xử lý',done:'Đã xong',error:'Cần kiểm tra',cancelled:'Đã dừng'};
 stableHTML(panel,'<header><div><h3>Công việc trên máy</h3><small>Đã lưu trạng thái · việc bị ngắt không tự chạy lại</small></div><button data-local-refresh>Đọc lại</button></header>'+(localRecovery.error?'<p role="status">'+esc(localRecovery.error)+'</p>':'')+(localRecovery.jobs.length?localRecovery.jobs.slice(0,30).map(j=>'<div class="queueTask" data-local-job="'+esc(j.id)+'" data-local-room="'+esc(j.room_id||'')+'"><div><b>'+esc(roomFor(j.room_id)?.name||localJobLabel(j))+'</b><small>'+localJobLabel(j)+' · '+esc(states[j.state]||j.state)+(j.state==='running'?' · '+Math.round(j.progress||0)+'%':'')+'</small><small>'+esc(j.error||j.phase||'')+'</small></div>'+(j.state==='done'&&j.lane!=='analysis'?'<button data-local-download="'+esc(j.id)+'">Tải MP4</button>':'')+(j.room_id&&roomFor(j.room_id)?'<button data-local-open="'+esc(j.id)+'">Mở phòng</button>':'')+(['queued','running'].includes(j.state)?'<button data-local-cancel="'+esc(j.id)+'">Dừng</button>':'')+'</div>').join(''):'<p class="emptyState">Chưa có công việc cục bộ đã lưu.</p>')+'<p class="connectionNote">MP4 ở đây là bản tạm: chuyển bản ghi được giữ tối đa khoảng 1 giờ, bản timeline tối đa 24 giờ từ khi tạo. Tải và lưu vào thư viện để giữ lâu dài.</p>');
}
async function refreshLocalJobs(){
 if(!localRecoveryAllowed())return;if(localRecoveryReading)return localRecoveryReading;
 localRecoveryReading=(async()=>{const before=JSON.stringify(localRecovery.jobs.map(j=>[j.id,j.state,j.room_id]));try{const data=await engineRequest('local-jobs');localRecovery={jobs:data.jobs||[],resources:data.resources,error:''};}catch(e){localRecovery.error=e.message;}paintLocalJobs();if(db&&before!==JSON.stringify(localRecovery.jobs.map(j=>[j.id,j.state,j.room_id])))render();})();
 try{await localRecoveryReading;}finally{localRecoveryReading=null;}
}
const recoveryQueueBefore=renderQueue;renderQueue=function(){recoveryQueueBefore();paintLocalJobs();if(localRecoveryAllowed()){$('#queueDrawer h2').textContent='Hàng chờ & công việc trên máy';$('#queueSummary').textContent=orderedJobs().length+' việc dịch vụ · '+localRecovery.jobs.filter(j=>['uploading','queued','running'].includes(j.state)).length+' việc trên máy đang xử lý';}};
const recoveryRenderBefore=render;render=function(){recoveryRenderBefore();if(!localRecoveryAllowed())return;const active=localRecovery.jobs.filter(j=>['uploading','queued','running'].includes(j.state));const rail=$('#openQueue b');if(rail)rail.textContent=jobs.filter(j=>j.status==='running').length+active.filter(j=>j.state==='running').length;$('#queueCount').textContent=orderedJobs().length+active.length;$('#openQueue').title='Hàng chờ · '+active.length+' việc trên máy đang xử lý';};
const recoveryShowBefore=showQueue;showQueue=function(){recoveryShowBefore();refreshLocalJobs();};$('#openQueue').onclick=$('#queueFromRoom').onclick=showQueue;
$('#queueList').addEventListener('click',async e=>{
 const b=e.target.closest('[data-local-refresh],[data-local-download],[data-local-open],[data-local-cancel]');if(!b)return;b.disabled=true;
 try{
  if(b.hasAttribute('data-local-refresh'))return await refreshLocalJobs();
  const id=b.dataset.localDownload||b.dataset.localOpen||b.dataset.localCancel,j=localRecovery.jobs.find(j=>j.id===id);if(!j)return;
  const room=roomFor(j.room_id);
  if(b.hasAttribute('data-local-open')){if(room){if(j.recovered){room.localRecoverySeenAt=Date.now();await persistRoom(room);}closeQueue();await openRoom(room.id,j.lane==='analysis'?'analysis':'editor');if(j.lane==='analysis')await $('#workflowFrame')?.contentWindow?.SceneForgeWorkflow?.localAnalysis?.resume?.(j.id);}return;}
  if(b.hasAttribute('data-local-cancel')){await engineRequest(localJobPath(j)+'/cancel',{});return await refreshLocalJobs();}
  const response=await fetch('/local-api/'+localJobPath(j)+'/file');if(!response.ok)throw Error('MP4 chưa sẵn sàng hoặc bản tạm đã hết hạn. Mở phòng để kiểm tra.');const blob=await response.blob();if(blob.type!=='video/mp4'||blob.size<500)throw Error('Kết quả không phải MP4 hợp lệ.');const name=(room?.name||'SceneForge')+'.mp4';download(name,blob);
  if(room&&(!room.exportedAt||room.exportedAt<=(j.created||0)*1000)){await io('files','readwrite',room.id+':export',blob);room.stage='exported';room.exportedAt=Date.now();room.exportName=name;await persistRoom(room);if(SceneForgeStorage.managed)await SceneForgeStorage.flush();toast('Đã tải và lưu MP4 vào thư viện của phòng.');}else toast('Đã tải MP4; bản xuất mới hơn của phòng được giữ nguyên.');
 }catch(err){toast(err.message);}finally{if(b.isConnected)b.disabled=false;}
});
setTimeout(()=>{if(localRecoveryAllowed())refreshLocalJobs();},1200);
setInterval(()=>{if(localRecoveryAllowed()&&!document.hidden&&(!$('#queueDrawer').hidden||currentView==='overview'))refreshLocalJobs();},15000);
window.SceneForgeApp.recovery={refresh:refreshLocalJobs,attention:roomAttention,open:openRoomAttention};
