"""Browser integration with explicit transport fixtures; no real AI calls."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
import io
from PIL import Image
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[2]


class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Quiet, directory=str(ROOT / 'dist/web-demo')))
Thread(target=server.serve_forever, daemon=True).start()
png = io.BytesIO()
Image.new('RGB', (720, 480), '#615782').save(png, 'PNG')
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1600, 'height': 1000})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto(f'http://127.0.0.1:{server.server_port}/?demo=1')
        page.wait_for_function('rooms.length===7')
        rid = page.evaluate('rooms.find(r=>r.mode==="photos").id')
        page.evaluate('(id)=>openRoom(id,"analysis")', rid)
        page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length===5')
        frame = page.locator('#workflowFrame').content_frame
        expect(frame.locator('#photoProviderBar')).to_be_visible()
        assert frame.locator('[data-node=frames]').inner_text().startswith('Tạo clip theo Storyboard')
        assert 'Nhập ảnh khung rồi duyệt trước' not in frame.locator('[data-node=frames]').inner_text()
        assert 'Start from the approved frame' not in frame.locator('body').evaluate('()=>photoPrompt(draft.beats[0])')
        frame.locator('[data-voice-mode=native]').click()
        frame.locator('[data-voice-mode=ai]').click()
        expect(frame.locator('[data-action=create-voice]')).to_be_disabled()
        expect(frame.locator('[data-node=voice]')).to_contain_text('install-voice.bat')
        frame.locator('[data-voice-mode=native]').click()
        positions = frame.locator('body').evaluate('()=>JSON.stringify(draft.positions)')
        frame.locator('[data-photo-creative=muse]').click()
        expect(frame.locator('[data-photo-creative=muse]')).to_have_attribute('aria-pressed','true')
        frame.locator('[data-photo-creative=gemini]').click()
        frame.locator('#photoOverallStory').click()
        assert 'ONE overall storyboard' in frame.locator('#photoOverallPrompt').input_value()
        frame.locator('#photoImportOverall').click()
        frame.locator('#photoOverallUpload').set_input_files({'name': 'storyboard.png', 'mimeType': 'image/png', 'buffer': png.getvalue()})
        expect(frame.locator('[data-photo-overall-select]')).to_contain_text('Đang dùng')
        assert frame.locator('body').evaluate('()=>draft.storyboardImages.length') == 1
        frame.locator('#closePhotoDialog').click()
        frame.locator('#photoAllPrompts').click()
        assert 'OVERALL STORYBOARD' in frame.locator('#photoChatPrompt').input_value()
        assert 'storyboard.png' in frame.locator('#photoChatPrompt').input_value()
        frame.locator('#closePhotoDialog').click()
        # Stub ONLY transport. Exercise the actual send/confirm/import UI and file decode.
        frame.locator('body').evaluate('''()=>{
          window.flowFixtureCalls=[];
          bridge.engine=async(path,body)=>{
            flowFixtureCalls.push({path,body});
            if(path==='flow/status')return{configured:true,url:'http://127.0.0.1:8766',models:['fixture-video'],generation_verified:false};
            if(path==='flow/jobs')return{state:'submitted'};
            if(path.startsWith('flow/jobs/'))return{state:'done',result:{mime_type:'video/mp4'}};
            throw Error('Unexpected fixture route '+path);
          };
          photoTools().flowModel='fixture-video';
          for(const b of draft.beats){b.visualPrompt='Use the actual product references';b.motionPrompt='Slow camera push-in';}
        }''')
        frame.locator('#photoRunClips').click()
        frame.locator('#photoConfirmFlow').wait_for()
        assert frame.locator('body').evaluate("()=>flowFixtureCalls.filter(c=>c.path==='flow/jobs').length") == 0
        frame.locator('#photoConfirmFlow').click()
        frame.locator('#photoDialog').wait_for(state='hidden')
        assert frame.locator('body').evaluate('()=>draft.flowJobs.length') == 5
        requests = frame.locator('body').evaluate("()=>flowFixtureCalls.filter(c=>c.path==='flow/jobs').map(c=>c.body)")
        assert len(requests) == 5 and all(r['references'] for r in requests)
        assert all('Start from the approved frame' not in r['prompt'] for r in requests)
        sample = (ROOT / 'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()
        page.route('**/local-api/flow/files/*', lambda route: route.fulfill(status=200, content_type='video/mp4', body=sample))
        frame.locator('#photoRecoverFlow').click()
        frame.locator('body').evaluate('async()=>{for(let i=0;i<200&&!draft.flowJobs.every(j=>j.state==="imported");i++)await new Promise(r=>setTimeout(r,50));}')
        assert frame.locator('body').evaluate('()=>draft.flowJobs.every(j=>j.state==="imported")')
        assert frame.locator('body').evaluate('()=>draft.beats.every(b=>b.chosenClip)')
        assert frame.locator('body').evaluate('()=>JSON.stringify(draft.positions)') == positions
        # Switching provider must not delete prior images, clips or script.
        before = frame.locator('body').evaluate('()=>JSON.stringify([draft.beats,draft.storyboardImages])')
        frame.locator('[data-photo-video=muse]').click()
        assert frame.locator('body').evaluate('()=>JSON.stringify([draft.beats,draft.storyboardImages])') == before
        frame.locator('#photoRunClips').click()
        expect(frame.locator('#photoToast')).to_contain_text('chưa kết nối thật')
        page.reload()
        page.wait_for_function('(id)=>roomFor(id)?.photoDraft?.storyboardImages?.length===1', arg=rid)
        assert page.evaluate('(id)=>roomFor(id).photoDraft.flowJobs.every(j=>j.state==="imported")', rid)
        assert not errors, errors
        browser.close()
        print('PASS toolbar choices persist without data loss; one storyboard file; combined prompt; explicit Flow send with product photos, 5 imported clips, no mandatory scene frames; Muse clearly blocked. Browser transport fixtures, not provider verification.')
finally:
    server.shutdown()
