// IndexedDB remains a recoverable working cache. Verified SQLite checkpoints own the durable library.
window.SceneForgeStorage=(()=>{
 const enabled=['localhost','127.0.0.1'].includes(location.hostname)&&new URLSearchParams(location.search).get('demo')!=='1';
 const schemas={'sceneforge-app-shell':['products','rooms','jobs','files','prefs','notifications'],'sceneforge-workflows':['projects'],'sceneforge-editor-local':['drafts']};
 let lease=null,editing=false;
 let diskRoot='';
 let managed=false,revision=0,epoch=0,suppress=0,busy=null,timer=null,active=false,error='',lastSaved=0;
 const records=new Map(),dirty=new Set(),blobCache=new Map(),urlCache=new Map();let fullScan=true;
 const identity=(d,s,k)=>JSON.stringify([d,s,k]);
 function announce(){dispatchEvent(new CustomEvent('sceneforge:storage-status'));}
 async function api(path,body,method){const res=await fetch('/local-api/library/'+path,{method:method||(body===undefined?'GET':'POST'),headers:body===undefined?{}:{'Content-Type':'application/json','X-SceneForge-Local':'1'},body:body===undefined?undefined:JSON.stringify(body)});if(!res.ok){let data;try{data=await res.json();}catch{}const e=Error(data?.detail||'Không đọc được kho trên máy.');e.status=res.status;throw e;}return res.json();}
 function change(d,s,k){if(suppress||!schemas[d]?.includes(s))return;dirty.add(identity(d,s,k));epoch++;localStorage.setItem('sceneforge-library-dirty','1');if(active){clearTimeout(timer);timer=setTimeout(()=>checkpoint().catch(()=>{}),1800);}}
 function observeWindow(w){if(!enabled||w.IDBObjectStore.prototype.__sfStorage)return;const proto=w.IDBObjectStore.prototype;Object.defineProperty(proto,'__sfStorage',{value:true});for(const method of ['put','add','delete','clear']){const old=proto[method];proto[method]=function(...args){const tx=this.transaction,d=tx.db.name,s=this.name;if(!schemas[d]?.includes(s))return old.apply(this,args);const req=old.apply(this,args),key=method==='delete'?args[0]:undefined;tx.addEventListener('complete',()=>change(d,s,method==='clear'?null:method==='delete'?key:req.result),{once:true});return req;};}}
 function open(name){return new Promise((ok,no)=>{const req=indexedDB.open(name,1);req.onupgradeneeded=()=>(schemas[name]||schemas['sceneforge-app-shell']).forEach(s=>req.result.createObjectStore(s,name==='sceneforge-workflows'?{keyPath:'id'}:undefined));req.onsuccess=()=>ok(req.result);req.onerror=()=>no(req.error);});}
 async function readAll(demo=false){const out=[];for(const[d,stores]of Object.entries(schemas)){const db=await open(demo&&d==='sceneforge-app-shell'?'sceneforge-app-showcase':d);try{for(const s of stores)await new Promise((ok,no)=>{const req=db.transaction(s).objectStore(s).openCursor();req.onsuccess=()=>{const c=req.result;if(!c)return ok();out.push({db:d,store:s,key:c.key,value:c.value});c.continue();};req.onerror=()=>no(req.error);});}finally{db.close();}}return out;}
 async function equalBlob(a,b){if(a===b)return true;if(a.size!==b.size||a.type!==b.type)return false;for(let at=0;at<a.size;at+=1024*1024){const x=new Uint8Array(await a.slice(at,at+1024*1024).arrayBuffer()),y=new Uint8Array(await b.slice(at,at+1024*1024).arrayBuffer());for(let i=0;i<x.length;i++)if(x[i]!==y[i])return false;}return true;}
 function cachePut(cache,key,value){cache.delete(key);cache.set(key,value);const url=cache===urlCache,limit=url?32:128,budget=(url?16:128)*1024*1024;let bytes=[...cache.entries()].reduce((n,[k,v])=>n+(url?k.length*2:v.blob?.size||0),0);while(cache.size>limit||bytes>budget){const oldest=cache.keys().next().value;if(oldest===undefined)break;bytes-=url?oldest.length*2:cache.get(oldest).blob?.size||0;cache.delete(oldest);}}
 async function reusableHash(blob){if(blob.size<8*1024*1024||!window.SceneForgePortable?.fingerprintWorker)return null;const hash=(await SceneForgePortable.fingerprintWorker(blob)).hash;const found=await api('assets/check',{hash,size:blob.size});return found.exists?hash:null;}
 async function encode(value,path=''){
  if(value instanceof Blob){const prior=blobCache.get(path);let hash;if(prior&&await equalBlob(prior.blob,value))hash=prior.hash;else{hash=await reusableHash(value);if(!hash){const res=await fetch('/local-api/library/assets',{method:'POST',headers:{'X-SceneForge-Local':'1','Content-Type':value.type||'application/octet-stream'},body:value});if(!res.ok)throw Error('Chưa ghi được file vào kho.');const asset=await res.json();hash=asset.hash;}cachePut(blobCache,path,{blob:value,hash});}return {$sf:value instanceof File?'file':'blob',hash,type:value.type,name:value.name,lastModified:value.lastModified};}
  if(typeof value==='string'&&/^data:(image|audio|video)\//.test(value)){let marker=urlCache.get(value);if(!marker){const blob=await(await fetch(value)).blob();marker={...await encode(blob,path),$sf:'dataurl'};cachePut(urlCache,value,marker);}return marker;}
  if(value===undefined)return {$sf:'undefined'};
  if(value===null||typeof value!=='object')return value;
  if(value instanceof Date)return {$sf:'date',value:value.toISOString()};
  if(value instanceof ArrayBuffer)return {$sf:'buffer-asset',asset:await encode(new Blob([value]),path+'/$binary')};
  if(ArrayBuffer.isView(value))return {$sf:'typed-asset',type:value.constructor.name,asset:await encode(new Blob([new Uint8Array(value.buffer,value.byteOffset,value.byteLength).slice()]),path+'/$binary')};
  if(value instanceof Map)return {$sf:'map',entries:await encode([...value.entries()],path+'/map')};
  if(value instanceof Set)return {$sf:'set',values:await encode([...value],path+'/set')};
  if(typeof value.getFile==='function'||typeof value.getDirectoryHandle==='function')return {$sf:'handle',name:value.name};
  if(Array.isArray(value)){const out=[];for(let i=0;i<value.length;i++)out.push(await encode(value[i],path+'/'+i));return out;}
  const out={};for(const[k,v]of Object.entries(value))out[k]=await encode(v,path+'/'+k);return out;
 }
 async function decode(value,media=new Map()){
  if(!value||typeof value!=='object')return value;
  if(['blob','file','dataurl'].includes(value.$sf)){let blob=media.get(value.hash);if(!blob){const res=await fetch('/local-api/library/assets/'+value.hash);if(!res.ok)throw Error('Thiếu tư liệu '+value.hash.slice(0,12));blob=await res.blob();media.set(value.hash,blob);}blob=new Blob([blob],{type:value.type||''});if(value.$sf==='file')return new File([blob],value.name||'file',{type:blob.type,lastModified:value.lastModified||0});if(value.$sf==='dataurl')return new Promise((ok,no)=>{const f=new FileReader();f.onload=()=>ok(f.result);f.onerror=no;f.readAsDataURL(blob);});return blob;}
  if(value.$sf==='released')return undefined;
  if(value.$sf==='undefined'||value.$sf==='handle')return undefined;
  if(value.$sf==='date')return new Date(value.value);
  if(value.$sf==='buffer-asset')return (await decode(value.asset,media)).arrayBuffer();
  if(value.$sf==='typed-asset'){const constructors={Uint8Array,Uint8ClampedArray,Uint16Array,Uint32Array,Int8Array,Int16Array,Int32Array,Float32Array,Float64Array,DataView};const C=constructors[value.type];if(!C)throw Error('Kiểu nhị phân chưa hỗ trợ.');return new C(await(await decode(value.asset,media)).arrayBuffer());}
  if(value.$sf==='buffer')return new Uint8Array(value.data).buffer;
  if(value.$sf==='typed'){const constructors={Uint8Array,Uint8ClampedArray,Uint16Array,Uint32Array,Int8Array,Int16Array,Int32Array,Float32Array,Float64Array,DataView};const C=constructors[value.type];if(!C)throw Error('Kiểu dữ liệu nhị phân chưa hỗ trợ.');return new C(new Uint8Array(value.data).buffer);}
  if(value.$sf==='map')return new Map(await decode(value.entries,media));if(value.$sf==='set')return new Set(await decode(value.values,media));
  if(Array.isArray(value)){const out=[];for(const v of value)out.push(await decode(v,media));return out;}
  const out={};for(const[k,v]of Object.entries(value))out[k]=await decode(v,media);return out;
 }
 async function prepare(){const generation=epoch,changes=new Set(dirty),raw=await readAll(),seen=new Set();for(const row of raw){const id=identity(row.db,row.store,row.key);seen.add(id);if(fullScan||!records.has(id)||changes.has(id)||changes.has(identity(row.db,row.store,null)))records.set(id,{...row,value:await encode(row.value,id)});}for(const id of records.keys())if(!seen.has(id))records.delete(id);if(generation!==epoch)throw Error('Dữ liệu đang thay đổi; sẽ lưu lại khi ổn định.');return [...records.values()].sort((a,b)=>identity(a.db,a.store,a.key).localeCompare(identity(b.db,b.store,b.key)));}
 async function hydrate(snapshot){
  // Decode every referenced file BEFORE changing any working database.
  const media=new Map(),decoded=[];for(const row of snapshot.records)decoded.push({...row,value:await decode(row.value,media)});
  localStorage.setItem('sceneforge-library-hydrating',String(snapshot.revision));suppress++;try{for(const[d,stores]of Object.entries(schemas)){const db=await open(d);try{await new Promise((ok,no)=>{const tx=db.transaction(stores,'readwrite');for(const s of stores)tx.objectStore(s).clear();for(const row of decoded.filter(r=>r.db===d)){const s=tx.objectStore(row.store);s.keyPath?s.put(row.value):s.put(row.value,row.key);}tx.oncomplete=ok;tx.onerror=()=>no(tx.error);tx.onabort=()=>no(tx.error);});}finally{db.close();}}}finally{suppress--;}
  records.clear();for(const row of snapshot.records)records.set(identity(row.db,row.store,row.key),row);dirty.clear();fullScan=false;revision=snapshot.revision;localStorage.removeItem('sceneforge-library-hydrating');localStorage.removeItem('sceneforge-library-dirty');localStorage.setItem('sceneforge-library-revision',String(revision));
 }
 async function checkpoint(){if(editing)return;if(!managed||!active)return;if(busy)return busy;busy=(async()=>{try{const rows=JSON.parse(JSON.stringify(await prepare())),generation=epoch;const snapshot=await api('snapshot',{revision,records:rows});const canonical=v=>JSON.stringify(v,(k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.entries(x).sort(([a],[b])=>a.localeCompare(b))):x);const returned=new Map(snapshot.records.map(r=>[identity(r.db,r.store,r.key),canonical(r.value)]));if(snapshot.records.length!==rows.length||rows.some(r=>returned.get(identity(r.db,r.store,r.key))!==canonical(r.value)))throw Error('Số bản ghi chưa khớp sau khi lưu.');revision=snapshot.revision;if(generation===epoch){dirty.clear();localStorage.removeItem('sceneforge-library-dirty');}fullScan=false;lastSaved=Date.now();error=(snapshot.warnings||[]).join(' ');localStorage.setItem('sceneforge-library-revision',String(revision));announce();return snapshot;}catch(e){error=e.message;if(e.status===409)active=false;announce();throw e;}finally{busy=null;}})();return busy;}
 async function ready(){if(!enabled)return;let status;try{status=await api('status');}catch{return;}if(!Number.isInteger(status?.revision)||typeof status.root!=='string'||!Array.isArray(status.backups))return;diskRoot=status.root;managed=true;revision=status.revision;observeWindow(window);active=false;
  if(navigator.locks){let acquired;const granted=new Promise(ok=>acquired=ok);navigator.locks.request('sceneforge-library-writer',{ifAvailable:true},lock=>{acquired(!!lock);if(lock)return new Promise(resolve=>lease=resolve);}).catch(()=>acquired(false));if(!await granted){error='Thư viện đang mở ở cửa sổ khác. Đóng cửa sổ đó trước để tránh ghi đè.';throw Error(error);}}
  try{const remote=await api('snapshot'),raw=await readAll(),hasLocal=raw.length>0,known=Number(localStorage.getItem('sceneforge-library-revision')||-1);
   if(remote.records.length&&(!hasLocal||known===remote.revision||localStorage.getItem('sceneforge-library-hydrating'))){if(!hasLocal||localStorage.getItem('sceneforge-library-hydrating'))await hydrate(remote);else{for(const row of remote.records)records.set(identity(row.db,row.store,row.key),row);fullScan=localStorage.getItem('sceneforge-library-dirty')==='1';}}
   else if(remote.records.length&&hasLocal){error='Có dữ liệu trình duyệt và thư viện máy khác phiên bản. Chưa ghi đè. Mở Cài đặt → Thư mục lưu để xuất bản trình duyệt hoặc nạp thư viện máy.';throw Error(error);}
   active=true;if(remote.records.length&&fullScan)await checkpoint();if(!remote.records.length){const rows=await prepare();if(rows.length){await api('browser-bundle',{records:rows});await checkpoint();}}
   setInterval(()=>{if(active&&dirty.size&&!busy)checkpoint().catch(()=>{});},10000);
  }catch(e){error=e.message;active=false;announce();throw e;}
 }
 async function flush(){if(window.SceneForgeApp?.flush)await window.SceneForgeApp.flush();return checkpoint();}
 async function useDisk(){active=false;clearTimeout(timer);if(busy)await busy;await api('browser-bundle',{records:await prepare()});const snap=await api('snapshot?verify=1');await hydrate(snap);location.reload();}
 async function hashBlob(blob,key='version'){const marker=await encode(structuredClone(blob),key);return marker.hash;}
 async function pinBlob(blob,pinned,note=''){if(!managed)return;const marker=await encode(structuredClone(blob),'pin/'+note);return api('pin',{hash:marker.hash,pinned,note});}
 async function browserBundle(){return api('browser-bundle',{records:await prepare()});}
 window.addEventListener('beforeunload',e=>{if(managed&&(dirty.size||busy)){e.preventDefault();e.returnValue='';}});
 if(enabled)observeWindow(window);
 function pause(){active=false;clearTimeout(timer);}
 async function edit(fn){if(editing)throw Error('Đang cập nhật thư viện.');if(managed&&!active)throw Error('Thư viện chưa sẵn sàng để thu gọn.');if(busy)await busy;editing=true;clearTimeout(timer);try{return await fn();}finally{editing=false;if(active&&dirty.size)timer=setTimeout(()=>checkpoint().catch(()=>{}),1800);}}
 return {ready,edit,clearMediaCache:()=>{blobCache.clear();urlCache.clear();},observeWindow,rawRecords:readAll,checkpoint,flush,api,decode,hydrate,hashBlob,pinBlob,browserBundle,useDisk,pause,get managed(){return managed;},get state(){return {enabled,managed,revision,root:diskRoot,active,error,lastSaved,busy:!!busy,dirty:dirty.size};}};
})();
