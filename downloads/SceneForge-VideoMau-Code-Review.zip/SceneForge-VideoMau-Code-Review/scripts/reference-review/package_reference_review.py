"""Package the reference-video path and its shared source dependencies for review."""
import hashlib
import inspect
import json
import os
from pathlib import Path
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/SceneForge-VideoMau-Code-Review.zip'
PREFIX='SceneForge-VideoMau-Code-Review/'

START='''# ĐỌC TRƯỚC — gói kiểm tra code Video mẫu

Mục tiêu: kiểm toàn bộ đường chọn video ở trang chủ → phòng Video mẫu → CPU/Whisper/OCR → Gemini hiểu cảnh và viết → ảnh khung được duyệt → clip Flow/Muse → giọng/phụ đề/nhạc → Dựng → MP4 → trạng thái phòng.

Đây là mã nguồn + bản web dựng sẵn để rà liên kết, không phải chứng nhận đã chạy một video thành phẩm bằng tài khoản online thật. Snapshot sau đợt lưu trữ v2 ngày 26/10/2026; manifest ghi hash chính xác từng file trong gói.

## Nên đọc theo thứ tự

1. `review/DE_BAI_DANH_GIA.md`: phạm vi cần rà, câu hỏi cụ thể và các nghi vấn từ lần đọc code gần nhất.
2. `review/LIEN_KET_TUNG_BUOC.md`: bước, file, endpoint, động cơ, tài khoản và đầu ra.
3. `review/KET_QUA_VA_CHO_CHUA_CHAC.md`: phép thử thật/fixture và các khoảng trống đang biết.
4. `review/THU_BANG_TAI_KHOAN_THAT.md`: cách thử một phòng với tài khoản của bạn, ghi chi phí và kết quả; không tự gửi yêu cầu.
5. `review/routes.json`: endpoint lấy từ chính FastAPI app trong môi trường dữ liệu rỗng.
6. `review/manifest.json`: SHA-256 từng file nguồn, giao diện và báo cáo.

## Chạy và dựng lại

- Bản chạy đã có trong `dist/web-demo/`. Chạy `local_engine/start.bat` trên Windows để mở app qua backend local; không mở HTML bằng file:// để thử đăng nhập/AI.
- Gói không kèm Python venv, cookie, tài khoản, vault, dữ liệu phòng người dùng hoặc model. Giữ model đã cài trong thư mục dữ liệu SceneForge. Có bộ model trong gói đầy đủ trước đó thì `install-and-check-local.bat` sẽ nhập và kiểm; gói review này không tự mang trọng số.
- Model local/thư viện: `local_engine/install-and-check-local.bat`. Thiếu model thì báo thiếu, không báo sẵn sàng giả. SDK và thư viện vẫn cần mạng để cài lần đầu.
- Dựng lại giao diện: Node/npm và Python 3.11/3.12; chạy `REBUILD.bat`, hoặc `npm ci --prefix scripts/watermark-builder` rồi `python scripts/demo-web/build.py`. Build không gọi AI.
- Kiểm gói: `python review/verify_package.py`. Build làm thay đổi file đã đóng gói thì manifest phải được tạo lại cho snapshot mới.
- Các bài Chromium/CPU trong source có fixture và một số đường dẫn Linux. Kết quả chạy kèm là trên Linux phát triển; không coi chúng là đã kiểm trên Windows. Cài gói nhỏ không đồng nghĩa đã cài trên PC người nhận.

## Phạm vi mã nguồn

`scripts/workflow/` là canvas Video mẫu. `scripts/app-shell/` giữ chọn file/phòng, lưu trữ và Cài đặt tài khoản; `scripts/native-preview/` + `scripts/demo-lite/` là Dựng/xuất. `local_engine/` là backend và adapter. Các module dùng chung, kể cả photo-studio, vẫn đi kèm để shell dựng và mở được nguyên vẹn. Đây không phải app ảnh tĩnh riêng; phần chính cần rà đã đánh dấu trong bảng liên kết.

Không kèm EXE/bridge của phần mềm khác. Các SDK Flow/Muse/Gemini/VieNeu được cài riêng từ revision trong `docs/engine-audit`. Source/notice/license của phần watermark, codec và font được giữ cùng gói.
'''

MAPPING='''# Truy vết từng bước

| Bước | Giao diện / nguồn | API hoặc dữ liệu | Backend / engine | Tài khoản và đầu ra |
|---|---|---|---|---|
| Chọn video, chọn sản phẩm | app-shell/package6.js: importVideos, scheduleAnalysis | IndexedDB rooms/files; roomPayload; iframe openRoom | chưa gọi nhà cung cấp | Mỗi video có room ID, source riêng, bản sao refs sản phẩm; không có tài khoản vẫn nhập được |
| Xếp phân tích | app-shell/package6.js + workflow/package6-analysis.js | analysisSlots; runAnalysisPipeline | WorkBudget lane analysis | Tối đa hai phòng mở phân tích; CPU đắt được xếp; chưa tự gen clip |
| Đọc/cắt cảnh | workflow/cpu-analysis.js: cpuSubmitFile | POST analysis/local/upload; GET analysis/local/jobs/{id} | cpu_analysis.py → FFmpeg → cpu_worker.py → PySceneDetect | Không tài khoản. Binary 500 MB/10 phút; proxy 480 px/24 fps; mốc cảnh, ảnh bằng chứng và hash nguồn |
| Fallback khi CPU thiếu | workflow/app.js: analyzeSource | Canvas/HTML video, lưu mốc dự án | Trình duyệt so ảnh/histogram | Không phải hiểu ngữ nghĩa; còn thiếu chép lời/OCR sẽ hiện attention |
| Chép lời + OCR + camera | cpu_worker.py, motion.py, speech_guard.py | kết quả local.transcript/scenes | Faster-Whisper CPU int8; RapidOCR; LK optical flow + RANSAC | Model Whisper ở data/models/faster-whisper; không gọi dịch vụ; câu nghi ngờ cần rà |
| Hiểu cảnh, dịch/viết | workflow/package6-analysis.js, analysis-v3.js | POST ai/analyze-frames; Gemini Chat execute_json | frame_analysis.py → gemini_chat.py → gemini_chat_worker.py | Nguồn chọn ở Cài đặt. Chat dùng vault phiên; API key chỉ ở nguồn API riêng. IDs/mốc/câu gốc đối chiếu trước khi áp dụng |
| Dịch riêng | workflow/chat-translation.js | POST gemini-chat/translate | GeminiChat role translation | Giữ mã câu, bản gốc và mốc; cần rà trước khi áp dụng |
| Bộ ảnh tham khảo | app-shell/room payload, workflow/app.js: refsFor/autoConnect | project.refs + scene.refsUsed | UI và asset store | Phải kiểm cảnh nào nối role nào; ảnh thật gửi ở bước viết prompt/tạo ảnh |
| Prompt ảnh theo bộ ảnh | workflow/reference-prompts.js | POST gemini-chat/jobs kind=text, role=writing; GET jobs/{id} | GeminiChat SDK | Ảnh cảnh nguồn + refs; review JSON trước thay prompt; giữ lịch sử, không tự duyệt ảnh |
| Tạo ảnh khung | workflow/direct-providers.js, frame-v3.js | POST gemini-chat/jobs kind=image; GET files/{id} | Gemini SDK GeneratedImage + kiểm file | Tài khoản/selection_token dùng chung; kết quả về đúng scene; gốc giữ, chưa tự approve |
| Duyệt khung | frame-v3.js: frameApproved/approve | kiểm kích thước/nét/nhãn; lưu approvedFrame | frame_quality.py: OpenCV/RapidOCR nếu chọn | Không dùng “AI đã tạo” làm chứng nhận nhãn đúng; sai số đo/nhãn còn cần rà |
| Prompt video sau duyệt | reference-prompts.js + app.js: makePrompt | Gemini text job; visual/motion; speechForPart | Gemini viết theo ảnh đã duyệt; app ghép thoại/voice direction | Bị chặn nếu khung chưa duyệt; JSON không được đổi kịch bản nguồn; lời vắt clip cần chia |
| Chọn tài khoản/số slot | app-shell/account-dispatch.js + accounts-dashboard.js | muse/selection, flow/selection, gemini-chat/selection; concurrency | account_pool.py, video_slots.py, account_settings.py | Dùng riêng / dự phòng / chia việc. Token review đổi khi setting thay. Flow/Muse 1–16 slot/tài khoản; Gemini hiện 1 |
| Tạo clip Flow | direct-providers.js → flow/jobs | FlowProvider → engine loopback /v1/chat/completions, header ID | flow_provider.py → flow_accounts.py → flow_account_engine.py → upstream Flow2API | ID tài khoản engine được ghim bằng ContextVar và phản hồi xác nhận; engine xác nhận số slot trước gửi. API key ở đây là key engine local, không đồng nghĩa key Gemini trả phí |
| Tạo clip Muse | direct-providers.js → muse/jobs | worker riêng, SDK session/media RPC | muse_provider.py → muse_worker.py → Muse SDK | Vault phiên theo hồ sơ; thư mục tạm/job riêng, session ID từ chính events request, không đoán hội thoại gần nhất. Hiện muse.ai, chưa xác nhận meta.ai |
| Kết quả/phiên bản | directRecover; addFrame/addClip | request ledger, files/{id}, room/scene/part | request_ledger.py; ffprobe/Pillow kiểm file | Job ID khác nhau, không gán theo thứ tự hoàn tất. Unknown không tự resend; cảnh đã sửa thì không tự nhập |
| Giọng tùy chọn | workflow/voice-over.js | GET tts/status; POST tts; GET media/{file} | local_tts.py → voice_worker.py → VieNeu ONNX CPU | Không dùng tài khoản online; preset model thật, tạo WAV. Mặc định vẫn tiếng clip; mute/duck cố định được chuyển sang timeline |
| Phụ đề theo audio thật | speech-captions.js + reference-production.js | POST speech/transcribe binary; GET speech/capabilities | speech_captions.py → speech_worker.py → Whisper | Chép lại clip/giọng được chọn, không dịch hoặc thay script nguồn; review cues trước áp dụng. Không phải forced alignment chính xác tuyệt đối |
| Nhạc | reference-production.js | file/thư mục → project.merge.musicLibrary | Trình duyệt đọc file, đặt track | Tắt / bài chỉ định / ngẫu nhiên trong danh sách đã nhập; không tự tải nhạc |
| Sang Dựng | workflow/room-shell.js: openInEditor | workflow-open-editor → shell → editor workflow-import | native-preview/workflow-import.js | assembled cần đủ clip; library cho tự ghép; mang file, phiên bản, captions, voice, music và clipVolume |
| Xuất MP4 | native-preview/timeline-export.js | local-api/export/timeline/* hoặc bộ xuất browser | timeline_export.py / exports.py → FFmpeg | Không gọi AI; giữ trạng thái job và file xuất; app shell commit Blob + phòng rồi ACK về editor |

Tên API đầy đủ/method/file backend được lấy từ app tại `routes.json`; bảng trên mô tả hợp đồng, không thay cho chứng cứ live-provider.
'''

GAPS='''# Kết quả kiểm và chỗ chưa chắc

## Đã kiểm

- CPU thực: file binary 200 MiB → proxy → mốc/ảnh; SHA nguồn không đổi, file tạm được dọn. Video kiểm tổng hợp 0,5 giây được padding hợp chuẩn MP4, chỉ chứng minh đường nhận dung lượng, không phải benchmark video dài HD.
- Whisper thực qua API local, có lời và mốc từ. VieNeu thực tạo WAV rồi Whisper nghe WAV qua endpoint mới; có sai từ nên vẫn cần rà.
- PySceneDetect/OpenCV/RapidOCR thực trên dữ liệu kiểm tổng hợp; FFmpeg timeline xuất MP4 thực, kiểm khung và âm thanh.
- Chromium fixture xuyên UI: prompt ảnh → duyệt frame → prompt video; nhận file vào đúng cảnh; giọng/caption không đổi lời nguồn; mute/voice payload sang Dựng; CPU binary và không dò cảnh hai lượt.
- Tài khoản: fixture kiểm Cài đặt điều khiển dispatch, ID Flow ghim ở wrapper, review cũ bị chặn, mỗi job có ID riêng, cùng một tài khoản có slot đồng thời và hàng đợi, không gửi lại unknown.
- Endpoint thật của app + provider transport giả: phân tích/dịch/viết và JSON/ID validation. Không chuyển ngầm sang API trả phí.

## Sửa phát hiện trong lần rà này

R1: pipeline tự động trước đây chỉ nhìn cờ file model Whisper. Đã đổi để chỉ bật transcribe khi cả thư viện Whisper và model đều có; thiếu thư viện vẫn đo cảnh được và không gửi yêu cầu chép lời chắc chắn lỗi. Chromium fixture kiểm tình huống có model nhưng thiếu thư viện: binary upload gửi transcribe=false.

## Đợt reliability tiếp theo

Đã triển khai biên nhận chưa gửi, phục hồi từng job, sửa JSON, batch 8 cảnh, evidence nguồn rõ hơn, Flow/Muse journal và đối soát, ACK thành phẩm, cache bộ cài. Xem `docs/reference-reliability-update.md` để đối chiếu từng P0/P1/P2, phép thử và phần chưa làm. Không tự nâng model/slot Gemini.

## Lưu trữ v2 — 26/10/2026

Xem `docs/storage-lifecycle-v2.md` và `review/STORAGE_LIFECYCLE_CHECKS.json`: ba thao tác dọn/xóa, lease, quarantine, release/deleted, restore, registry kết quả và giới hạn đã được bổ sung. Những giới hạn còn được nêu riêng; không chứng nhận Windows/online.

## Chưa thể kết luận hoàn toàn liên thông trên dịch vụ thật

1. Chưa có account thật cho một vòng Gemini → ảnh → Flow/Muse → clip. SDK import/fixture không chứng minh phiên/credit/captcha/quyền model thật hoạt động.
2. Muse SDK hiện trỏ muse.ai. Chưa xác nhận đúng Meta AI người dùng muốn; đây là khoảng trống cần chốt, không phải đã nối mọi Meta account.
3. Chia clip còn theo khoảng 8 giây, chưa đọc duration của mọi model. Native speech/giọng/continuity và thời lượng sinh thật cần rà.
4. Camera được đo bằng optical flow/RANSAC. Hành động tay/người chưa có model local hiểu toàn bộ chuỗi; Gemini dựa ảnh mẫu/lời, có thể thiếu hành động giữa ảnh.
5. Phụ đề là ASR có mốc, chưa forced alignment theo câu chuẩn. Nhận dạng có lỗi. Giọng riêng có thể dài hơn hình, cần chỉnh trong Dựng; hạ tiếng clip là gain cố định 15%, không tự duck theo khoảng thoại.
6. Kho Kịch bản tự rút khung nhịp từ mốc; không mặc nhiên có đủ lời quảng cáo hoặc cập nhật lại mọi nội dung khi mốc không đổi.
7. Lưu trữ v2 đã gom kết quả mới được quản lý vào kho hash và ánh xạ URL cũ; không suy thành đã dọn mọi file backend cũ. File legacy chưa đủ liên kết được giữ; preview/gốc, browser và bản xuất ngoài app vẫn có thể chiếm dung lượng riêng. Xem báo cáo storage-v2.
8. Các bài Chromium có đường dẫn Linux. Bộ cài BAT có trong gói nhưng chưa chạy thử Windows. Codec nhập còn phụ thuộc trình duyệt/FFmpeg.

Các kết quả real-model đi kèm từ môi trường phát triển với đường dẫn model đã cấu hình. Gói review không chứa các model/venv đó. Trước khi thử account thật, đọc `THU_BANG_TAI_KHOAN_THAT.md`.
'''

LIVE='''# Checklist thử bằng tài khoản thật

Thực hiện trong bản cục bộ trên máy của bạn. Đây là hướng dẫn kiểm, không phải script tự gen; Flow hoặc dịch vụ có thể tính credit.

1. Chạy bộ kiểm local, xem các trường thiếu. Giữ báo cáo cùng Python/thư mục dữ liệu app đang chạy; có file model trên một thư mục khác chưa đủ.
2. Chọn một video ngắn, 2–3 cảnh, lời rõ, có sản phẩm. Tạo một phòng, ghi room ID. Đầu tiên chỉ cho chạy một job/tài khoản để dễ truy vết.
3. Đăng nhập một tài khoản từng nguồn; trong Cài đặt chọn Dùng riêng. Ghi tên hồ sơ, dịch vụ thực tế, model, thời điểm và số dư nếu đọc được; không đưa cookie vào báo cáo.
4. Đọc CPU: mốc cảnh khớp? nghe lại nguyên văn/mốc câu? OCR chỉ là chữ nhìn thấy? camera chưa chắc có để trống không?
5. Cho gửi Gemini Chat, chờ nhận và rà. Đối chiếu room/scene/line IDs. Đổi nguồn không được làm một request cũ chạy lại bằng API.
6. Viết prompt ảnh từ nguồn+bộ ảnh → tạo một frame → kiểm mặt/nhãn → duyệt. Trước duyệt, thử tạo clip phải bị chặn.
7. Viết prompt video với frame đã duyệt. Tạo đúng một clip Flow trước; kiểm engine account ID, request ID, credit, thoại/khẩu hình, duration và scene đích. Muse thử riêng, phải xác nhận đúng dịch vụ mà account dùng.
8. Sau khi một clip ổn, thử hai clip cùng tài khoản. Đối chiếu cả hai ID/kết quả; đảo thứ tự hoàn tất vẫn về đúng phần. Nếu timeout/unknown, kiểm lịch sử trước, không tự resend.
9. Thử native clip audio và VieNeu riêng; nghe rồi chọn giữ/hạ/tắt. Lấy phụ đề từ audio, sửa lỗi và xác nhận script nguồn không đổi. Thêm/tắt nhạc.
10. Sang Dựng: clip đúng thứ tự, phiên bản phụ trong Kho, tiếng và phụ đề đúng. Xuất MP4 và mở file ngoài app; xem đủ thời lượng, nghe nhạc/giọng, kiểm trạng thái phòng Đã xuất.
11. Tắt/mở app ở từng điểm chờ. Việc chưa rõ không tự phát lại; lựa chọn tài khoản mới chỉ ảnh hưởng việc mới.

Ghi cho mỗi bước: PASS/FAIL/BLOCKED, room/scene/request ID, model/account label (không cookie), ảnh lỗi, thời gian và thay đổi credit. Khi một bước BLOCKED thì chưa ghi cả quy trình là PASS.
'''

VERIFY='''from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'review/manifest.json').read_text())
for row in manifest['files']:
 path=root/row['path']
 assert path.is_file(),row['path']
 assert path.stat().st_size==row['bytes'],row['path']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS',len(manifest['files']),'files match the review snapshot. No provider requests made.')
'''

def main():
    files={}
    def add(path):
        relative=path.relative_to(ROOT).as_posix()
        if any(part in ('node_modules','__pycache__','.git','.venv')for part in path.parts):return
        if path.suffix in ('.pyc','.png','.webm','.wav')and relative.startswith('scripts/')and '/assets/'not in relative:return
        files[relative]=path.read_bytes()
    for name in ['app-shell','workflow','native-preview','demo-lite','photo-studio','shared','watermark-builder','demo-web']:
        for p in (ROOT/'scripts'/name).rglob('*'):
            if p.is_file():add(p)
    # Packaging a general distribution needs old design files; this review uses its own packager.
    files.pop('scripts/demo-web/package_local.py',None)
    for p in (ROOT/'local_engine').iterdir():
        if p.is_file()and p.suffix in ('.py','.bat','.sh','.txt','.md','.json'):add(p)
    for p in [ROOT/'preview.html',ROOT/'concat-demo.html',ROOT/'editor/public/fonts/LICENSE.txt',ROOT/'editor/public/fonts/SceneForgeSans.ttf']:add(p)
    for name in ['index.html','studio.html','workflow.html','photos.html','.nojekyll']:
        add(ROOT/'dist/web-demo'/name)
    for name in ['native','fonts','watermark']:
        for p in (ROOT/'dist/web-demo'/name).rglob('*'):
            if p.is_file():add(p)
    for name in ['reference-review-request.md','storage-lifecycle-v2.md','reference-reliability-update.md','reference-workflow-runtime-audit.md','reference-runtime-verification.json','multi-account-dispatch.md','multi-account-verification.json','video-same-account-concurrency.md','gemini-web-installation.md','muse-web-integration.md','flow-installation-status.md','frame-quality-hd.md','chat-translation.md','whisper-model-integration.md','local-voice-integration.md']:
        add(ROOT/'docs'/name)
    for p in (ROOT/'docs/engine-audit').iterdir():
        if p.is_file():add(p)
    for name in ['cpu-stream-real-check.json','voice-caption-real-check.json','whisper-api-real-check.json','voices/SceneForge-HaiDang-CPU.wav','voices/real-voice-check.json']:
        add(ROOT/'artifacts'/name)
    add(Path(__file__).resolve())
    storage_report=ROOT/'artifacts/storage-lifecycle-v2-checks.json'
    if storage_report.exists():files['review/STORAGE_LIFECYCLE_CHECKS.json']=storage_report.read_bytes()
    files['START_HERE.md']=START.encode()
    files['review/LIEN_KET_TUNG_BUOC.md']=MAPPING.encode()
    files['review/DE_BAI_DANH_GIA.md']=(ROOT/'docs/reference-review-request.md').read_bytes()
    files['review/KET_QUA_VA_CHO_CHUA_CHAC.md']=GAPS.encode()
    files['review/THU_BANG_TAI_KHOAN_THAT.md']=LIVE.encode()
    files['review/verify_package.py']=VERIFY.encode()
    check_report=ROOT/'artifacts/reference-review-checks.json'
    if check_report.exists():files['review/BUILD_AND_BOOT_CHECK.json']=check_report.read_bytes()
    packaging_report=ROOT/'artifacts/reference-packaging-checks-20261026.json'
    if packaging_report.exists():files['review/PACKAGING_CHECK_20261026.json']=packaging_report.read_bytes()
    files['REBUILD.bat']=b'@echo off\r\ncd /d "%~dp0"\r\ncall npm ci --prefix scripts\\watermark-builder\r\nif errorlevel 1 exit /b 1\r\npython scripts\\demo-web\\build.py\r\npause\r\n'
    # Load endpoint registrations with a fresh private temporary data directory.
    with tempfile.TemporaryDirectory(prefix='sf-review-routes-')as tmp:
        os.environ['SCENEFORGE_LOCAL_DATA']=tmp
        from local_engine import server
        routes=[]
        for route in server.app.routes:
            if not route.path.startswith('/local-api/'):continue
            endpoint=route.endpoint
            source=inspect.getsourcefile(endpoint)
            routes.append({'path':route.path,'methods':sorted(route.methods or []),'endpoint':endpoint.__module__+'.'+endpoint.__qualname__,
                'file':Path(source).relative_to(ROOT).as_posix()if source and Path(source).is_relative_to(ROOT)else None,
                'line':getattr(getattr(endpoint,'__code__',None),'co_firstlineno',None)})
        files['review/routes.json']=json.dumps(routes,ensure_ascii=False,indent=2).encode()
    manifest={'snapshot_application_release':'reference video review 2026-10-26; storage v2 included','scope':'reference video plus required shared modules','live_provider_verified':False,'models_included':False,
        'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}for name,raw in sorted(files.items())]}
    files['review/manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
    assert all(not any(part in ('.env','.git','.venv','node_modules','models')for part in Path(name).parts)for name in files)
    assert not any('vault.key'in name or 'vault.sqlite'in name or 'requests.sqlite'in name for name in files)
    with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED)as z:
        for name,raw in sorted(files.items()):z.writestr(PREFIX+name,raw)
    with zipfile.ZipFile(OUT)as z:assert z.testzip()is None
    digest=hashlib.sha256(OUT.read_bytes()).hexdigest();OUT.with_suffix('.zip.sha256').write_text(digest+'  '+OUT.name+'\n')
    print(OUT,len(files),'files',OUT.stat().st_size,'bytes',digest)

if __name__=='__main__':main()
