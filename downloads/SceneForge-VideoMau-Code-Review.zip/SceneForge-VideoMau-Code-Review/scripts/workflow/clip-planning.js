// Timeline durations are distinct from provider output durations. No invented model capabilities.
const legacyClipParts=clipParts;
function clipPartId(index){let value='';for(let n=index+1;n>0;n=Math.floor((n-1)/26))value=String.fromCharCode(97+(n-1)%26)+value;return value;}
function planClipParts(s,options={}){
 const max=8,total=s.end-s.start;if(!Number.isFinite(total)||total<=0)return[];
 if(options.mode==='legacy')return legacyClipParts(s);
 const lines=(project.script||[]).filter(l=>l.start<s.end&&l.end>s.start),cuts=(options.actionCuts||[]).filter(t=>Number.isFinite(t)&&t>s.start&&t<s.end);
 let count=Math.ceil((total-.001)/max),hold=0;
 const tail=total-(count-1)*max;
 if(options.holdTail&&count>1&&tail>0&&tail<=1.2&&!lines.some(l=>l.end>s.end-tail+.001&&l.start<s.end)){count--;hold=tail;}
 const parts=[];let at=s.start;
 for(let i=0;i<count;i++){
  const remaining=count-i,last=remaining===1,ideal=at+(s.end-at-hold)/remaining;
  let end=s.end;
  if(!last){
   const lo=Math.max(at+.2,s.end-(remaining-1)*max-hold),hi=Math.min(at+max,s.end-(remaining-1)*.2);
   const candidates=[Math.max(lo,Math.min(hi,ideal)),...lines.flatMap(l=>[l.start,l.end]),...cuts].filter(t=>t>=lo-.001&&t<=hi+.001);
   const cost=t=>Math.abs(t-ideal)+ (lines.some(l=>l.start<t-.02&&l.end>t+.02)?1000:0) -(cuts.includes(t)?10:0);
   end=candidates.sort((a,b)=>cost(a)-cost(b))[0];
  }
  end=Math.round(end*1000)/1000;const duration=end-at,extra=last?hold:0;
  parts.push({id:clipPartId(i),start:at,end,duration,generationDuration:Math.round((duration-extra)*1000)/1000,holdTail:extra});at=end;
 }
 return parts;
}
clipParts=function(s){
 if(s.clipPlan?.parts&&s.clipPlan.start===s.start&&s.clipPlan.end===s.end)return s.clipPlan.parts;
 // Never silently remap part IDs of existing generations.
 if(s.clips?.length||!s.clipPlanning&&Object.values(s.dialogueParts||{}).some(v=>String(v).trim())||(project.cloudJobs||[]).some(j=>j.sceneId===s.id&&j.kind==='video'))return legacyClipParts(s);
 return planClipParts(s,s.clipPlanning||{});
};
function clipChainReady(scene,part){if(!scene.clipPlanning?.continuity)return true;const parts=clipParts(scene),index=parts.findIndex(p=>p.id===(part.id||part));let previous=null;for(let i=0;i<index;i++){const c=chosenClip(scene,parts[i].id);if(!c||!assets.has(c.asset)||!scene.receivedClipIds?.includes(c.id)||c.reviewDecision?.status!=='accepted'||!c.tail||!frameApproved(scene)||c.frameId&&c.frameId!==scene.approvedFrame||approvalTaskState(scene,'clip',parts[i].id)||previous&&c.continuityFrom!==previous.id)return false;previous=c;}return true;}
function clipStartImage(scene,part){
 if(!scene.clipPlanning?.continuity||!part)return displayFrame(scene);
 const parts=clipParts(scene),index=parts.findIndex(p=>p.id===(part.id||part));if(index<=0)return displayFrame(scene);
 const previous=chosenClip(scene,parts[index-1].id);
 if(!previous||!clipChainReady(scene,part))throw Error('Duyệt clip '+parts[index-1].id+' trước để lấy khung cuối nối sang '+parts[index].id+'.');
 return previous.tail;
}
function clipContinuityFrom(scene,part){if(!scene.clipPlanning?.continuity)return null;const parts=clipParts(scene),i=parts.findIndex(p=>p.id===(part.id||part));return i>0?chosenClip(scene,parts[i-1].id)?.id||null:null;}
function clipPlanLocked(s){return s.clips.length||Object.values(s.dialogueParts||{}).some(v=>String(v).trim())||(project.cloudJobs||[]).some(j=>j.sceneId===s.id&&j.kind==='video');}
function clipPlanningDialog(){
 const room=project.id;
 modal('Chia clip theo cảnh và lời','<p>Chia cân đối theo mốc câu và mốc hành động bạn nhập. Thời lượng bên dưới dùng để dựng; dịch vụ có thể trả clip dài hơn để cắt bớt. Không tự nhận model hỗ trợ 4/6 giây.</p>'+project.scenes.map(s=>{const locked=clipPlanLocked(s),o=s.clipPlanning||{};return '<section data-clip-plan="'+s.id+'"><b>Cảnh '+(s.index+1)+' · '+(s.end-s.start).toFixed(1)+'s</b><p>'+clipParts(s).map(p=>p.id+': '+p.duration.toFixed(1)+'s'+(p.holdTail?' (giữ đuôi '+p.holdTail.toFixed(1)+'s)':'')).join(' · ')+'</p><label>Cách chia<select data-plan-mode '+(locked?'disabled':'')+'><option value="auto" '+(o.mode!=='legacy'?'selected':'')+'>Cân đối theo câu / hành động</option><option value="legacy" '+(o.mode==='legacy'?'selected':'')+'>Theo mốc 8 giây trước đây</option></select></label><label>Mốc hành động trong cảnh, giây (tùy chọn)<input data-plan-cuts value="'+esc((o.actionCuts||[]).map(t=>Number((t-s.start).toFixed(3))).join(', '))+'" '+(locked?'disabled':'')+' placeholder="Ví dụ 3.5, 6.2"></label><label><input type="checkbox" data-plan-tail '+(o.holdTail?'checked':'')+' '+(locked?'disabled':'')+'> Đuôi tĩnh ≤1,2s, không lời: giữ khung cuối để bớt một lượt gen</label><label><input type="checkbox" data-plan-continuity '+(o.continuity?'checked':'')+' '+(locked?'disabled':'')+'> Nối khung cuối: duyệt phần trước rồi tạo phần tiếp</label>'+(locked?'<small>Đã có clip/lượt tạo hoặc lời riêng từng clip: giữ cách chia, không xóa lời hay gán nhầm bản cũ.</small>':'')+'</section>';}).join('')+'<p id="clipPlanError"></p>','<button id="saveClipPlan" class="primary">Áp dụng trước khi tạo clip</button>');
 $('#saveClipPlan').onclick=async()=>{try{if(project.id!==room)throw Error('Phòng đã đổi.');const prepared=[];for(const row of $$('[data-clip-plan]')){const s=project.scenes.find(s=>s.id===row.dataset.clipPlan);if(!s||clipPlanLocked(s)||row.querySelector('[data-plan-mode]').disabled)continue;const raw=row.querySelector('[data-plan-cuts]').value.trim(),relative=raw?raw.split(/[,;\s]+/).map(Number):[];if(relative.some(t=>!Number.isFinite(t)||t<=0||t>=s.end-s.start))throw Error('Mốc hành động phải nằm trong cảnh.');const options={mode:row.querySelector('[data-plan-mode]').value,actionCuts:relative.map(t=>t+s.start),holdTail:row.querySelector('[data-plan-tail]').checked,continuity:row.querySelector('[data-plan-continuity]').checked};prepared.push({s,options,parts:planClipParts(s,options)});}for(const {s,options,parts}of prepared){s.clipPlanning=options;s.clipPlan={start:s.start,end:s.end,parts};s.dialogueParts={};}await storeProject();closeModal();render();toast('Đã lưu cách chia; chưa gửi tạo clip.');}catch(e){$('#clipPlanError').textContent=e.message;}};
}
const planningRenderBefore=render;render=function(){planningRenderBefore();if(project.mode==='photos')return;const header=$('#node-videos header');if(header&&!header.querySelector('[data-clip-planning]')){const b=document.createElement('button');b.dataset.clipPlanning='1';b.textContent='Chia clip';b.onclick=clipPlanningDialog;header.append(b);}};
const planningPromptBefore=makePrompt;makePrompt=function(s,part=null){const p=part||clipParts(s)[0];let text=planningPromptBefore(s,p);if(p.holdTail)text+='\nEDITOR HOLD: The final '+p.holdTail.toFixed(2)+' seconds are a silent static hold added locally, not an extra generation. Finish the action and dialogue before '+p.generationDuration.toFixed(2)+' seconds.';if(s.clipPlanning?.continuity&&clipContinuityFrom(s,p))text+='\nCONTINUITY: Begin exactly from the supplied final frame of the previous approved clip. Preserve person/product identity, pose, lighting and camera direction; do not restart the action.';return text;};

const planningAddClipBefore=addClip;addClip=async function(file,target){const scene=target&&project.scenes.find(s=>s.id===target.id),room=project.id;if(scene&&!scene.clipPlan&&frameApproved(scene))scene.clipPlan={start:scene.start,end:scene.end,parts:clone(clipParts(scene))};const before=scene?.clips.length||0;await planningAddClipBefore(file,target);if(scene&&project.id===room&&scene.clips.length>before){const c=scene.clips.at(-1),p=clipParts(scene).find(p=>p.id===c.part);if(p){c.slotStart=p.start;c.slotEnd=p.end;}await storeProject();}};

document.addEventListener('input',e=>{if(!e.target.dataset.partSpeech)return;const s=activeScene();if(s&&!s.clipPlan)s.clipPlan={start:s.start,end:s.end,parts:clone(clipParts(s))};},true);
const planningSpeechBefore=speechForPart;speechForPart=function(s,p){const value=planningSpeechBefore(s,p);if(p.holdTail){value.cueEnd=Math.min(value.cueEnd,p.generationDuration);if(value.lines.some(l=>l.end>p.start+p.generationDuration+.01))value.pending=true;}return value;};
