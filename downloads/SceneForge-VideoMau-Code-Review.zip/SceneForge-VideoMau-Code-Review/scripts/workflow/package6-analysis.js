// Automatic local work resumes; cloud analysis requires an explicit per-batch opt-in.
let g6PipelineActive=false,g6PipelinePause=false;
function g6Pipeline(){return project.analysis.pipeline6??={version:1,steps:{cuts:'waiting',speech:'waiting',ocr:'waiting',gemini:'waiting'},phase:'Chờ phân tích',running:false};}
async function g6Progress(key,state,phase){const p=g6Pipeline();if(key)p.steps[key]=state;p.phase=phase;p.running=g6PipelineActive;p.updatedAt=Date.now();await storeProject();render();}
const g6PublishBefore=publishRoomState;publishRoomState=function(){g6PublishBefore();if(shellRoomId&&project?.id===shellRoomId&&project.analysis.pipeline6)parent.postMessage({type:'sceneforge:analysis-pipeline',roomId:project.id,pipeline:clone(project.analysis.pipeline6)},location.origin);};
async function g6AnalyzePipeline(options={}){
 if(g6PipelineActive)return;g6PipelineActive=true;g6PipelinePause=false;const p=g6Pipeline();delete p.error;p.paused=false;p.running=true;project.analysis.frameQualityRequired=true;
 const stop=async()=>{if(!g6PipelinePause)return false;p.paused=true;p.running=false;p.phase='Chưa phân tích xong · bạn để sau';await storeProject();return true;};
 try{
  if(await stop())return;
  let cap=null;try{cap=await workflowLocalRequest('analysis/local/capabilities');}catch{}
  const file=cpuSourceFile(),canCPU=cap?.available&&file?.size<=cap.max_bytes&&project.source.duration<=cap.max_seconds;
  if(!canCPU&&(p.steps.cuts!=='done'||!project.scenes.length)){await g6Progress('cuts','running','Máy đang cắt cảnh');await analyzeSource();project.analysis.pipeline6=p;project.analysis.frameQualityRequired=true;if(!project.scenes.length)throw Error('Chưa cắt được cảnh nguồn.');await g6Progress('cuts','done','Đã cắt '+project.scenes.length+' cảnh');}
  if(await stop())return;

  if(!project.analysis.local&&cap?.available&&file?.size<=cap.max_bytes&&project.source.duration<=cap.max_seconds){
   const lock=parent!==window?parent.SceneForgeApp?.analysisSlots:null;let release=null;
   try{
    if(lock){await g6Progress(null,null,'Xếp hàng CPU trên máy');release=await lock.acquire();}
    if(await stop())return;
    await g6Progress('speech',cap.whisper&&cap.whisper_model?'running':'attention',cap.whisper&&cap.whisper_model?'CPU đang chép lời / OCR / đo máy quay':'CPU đo cảnh · chép lời cần model hoặc SRT');
    p.steps.ocr=cap.ocr?'running':'attention';await storeProject();
    let job=null;if(p.cpuJobId){try{job=await readJobWithBackoff('analysis/local/jobs/'+p.cpuJobId);}catch(error){if(error.status!==404)throw error;}}
    if(!job||['error','cancelled'].includes(job.state)){
     const raw=await cpuSubmitFile(file,{duration:project.source.duration,threshold:27,min_scene:.35,ocr:!!cap.ocr,transcribe:!!(cap.whisper&&cap.whisper_model),language:null});p.cpuJobId=raw.id;await storeProject();job=raw;
    }
    let lastSave=Date.now(),lastView='';while(!['done','error','cancelled'].includes(job.state)){await new Promise(r=>setTimeout(r,1000));job=await readJobWithBackoff('analysis/local/jobs/'+p.cpuJobId);p.percent=job.progress;p.phase=job.phase||'CPU đang đo';const nextView=JSON.stringify([job.state,job.progress,job.phase]),changed=nextView!==lastView;if(changed)render();if(changed&&Date.now()-lastSave>=1500||Date.now()-lastSave>=5000){await storeProject();lastSave=Date.now();}lastView=nextView;}
    if(job.state!=='done')throw Error(job.error||'CPU chưa hoàn tất.');
    project.analysis.pendingCPU={source:project.source.asset,signature:cpuSignature(),at:Date.now(),result:job.result};await storeProject();
    const r=job.result,same=project.scenes.length===r.scenes.length&&project.scenes.every((s,i)=>Math.abs(s.start-r.scenes[i].start)<.01&&Math.abs(s.end-r.scenes[i].end)<.01);
    if(!same){const {pipeline6,pendingCPU,...analysis}=project.analysis;project.localHistory??=[];project.localHistory.push({source:project.source.asset,at:Date.now(),scenes:clone(project.scenes),script:clone(project.script),analysis:clone(analysis),merge:clone(project.merge)});}
    project.scenes=r.scenes.map((s,i)=>{const row=same?project.scenes[i]:sceneRecord(s.start,s.end,i,clone(s.thumbs));row.thumbs=clone(s.thumbs);row.cpu=clone(s);return row;});
    if(!same)project.merge.order=project.scenes.map(s=>s.id);
    if(r.speech.state==='transcribed')project.script=r.transcript.map(l=>({id:uid(),...clone(l),translation:'',newText:'',faceTalking:false,source:'faster-whisper'}));
    const savedResult=clone(r);for(const row of savedResult.scenes)delete row.evidence_frames;project.analysis.local={source:project.source.asset,at:Date.now(),result:savedResult};project.analysis.cuts=clone(r.cuts);p.steps.cuts='done';delete project.analysis.pendingCPU;delete p.cpuJobId;applyCameraDirections();cpuCrossCheck();for(const key of Object.keys(refNames))autoConnect(key);await storeProject();
   }finally{release?.();}
  }
  const measured=project.analysis.local?.result;
  p.steps.speech=project.script.length||measured?.speech.audio_present===false||measured?.speech.state==='no_audio'||measured?.speech.state==='transcribed'?'done':'attention';
  p.steps.ocr=measured?.ocr_state==='sampled'?'done':'attention';p.steps.camera=measured?'done':'attention';p.steps.quality=measured?'done':'attention';
  if(await stop())return;
  if(project.analysis.pendingAI&&!options.resumeBatches){p.steps.gemini=project.analysis.pendingAI.result.can_apply===false?'attention':'review';p.phase='Kết quả AI đã nhận · mở để rà và áp dụng';return;}
  if(project.analysis.semantic&&!options.resumeBatches){p.steps.gemini='done';p.phase='Đã phân tích · kiểm tra khung';return;}
  let recoverRequest=(options.resumeBatches||project.analysis.aiRequest?.batches)?project.analysis.aiRequest?.request_id:null;
  if(!recoverRequest&&['submitted','unknown','invalid','missing','failed'].includes(project.analysis.aiRequest?.state)&&!project.analysis.aiRequest?.batches){const saved=project.analysis.aiRequest;if(saved.source==='gemini_chat'&&saved.request_id&&saved.editSignature===analysisEditSignature()){try{const record=await workflowLocalRequest('gemini-chat/jobs/'+jobWireId(saved));if(record.state==='done')recoverRequest=saved.request_id;else if(record.state==='not_submitted'&&record.submitted===false)jobReadRecord(saved,record);}catch(error){jobReadError(saved,error);}}if(!recoverRequest&&saved.state!=='not_submitted'){p.steps.gemini='unknown';p.phase='Lượt Gemini cũ cần kiểm tra · mở Các lượt đã gửi để nhận/sửa JSON hoặc đối soát';return;}}
  if(!options.allowGemini&&!recoverRequest){p.steps.gemini='attention';p.phase='Máy đã xử lý phần sẵn có · chờ bạn gửi Gemini';return;}
  if(p.steps.speech!=='done'){p.steps.gemini='attention';p.phase='Chờ lời nguồn / model Whisper trước khi gửi Gemini';return;}
  const providers=await workflowLocalRequest('status');if(!(providers.ai_configured??providers.gemini_configured)&&!recoverRequest){p.steps.gemini='attention';p.phase='Bước trên máy đã giữ · cần kết nối nguồn Gemini đã chọn';return;}
  await g6Progress('gemini','running','Gemini đang đọc ảnh và bản chữ');
  const manualLines=clone(project.script.filter(l=>!l.original?.trim()));const id=project.id,revision=project.updatedAt,editSignature=analysisEditSignature(),signature=JSON.stringify(project.scenes.map(s=>({start:s.start,end:s.end}))),scenes=v3Evidence();for(const s of scenes)s.frames=await Promise.all(s.frames.map(f=>smallImage(f,1024)));
  project.analysis.aiRequest={...(recoverRequest?project.analysis.aiRequest:{}),state:'submitted',provider:'gemini',source:recoverRequest?'gemini_chat':providers.ai_source||'gemini_api',request_id:recoverRequest||crypto.randomUUID(),editSignature,at:Date.now()};await storeProject();
  try{const result=await runFrameAnalysis({confirm_remaining:!!options.resumeBatches,request_id:project.analysis.aiRequest.request_id,ai_source:project.analysis.aiRequest.source,provider:'gemini',room_id:id,duration:project.source.duration,scenes,lines:project.script.filter(l=>l.original?.trim()).map(l=>({id:l.id,start:l.start,end:l.end,original:l.original,no_speech_prob:l.no_speech_prob,avg_logprob:l.avg_logprob,keep:l.speechReview?.accepted===true}))});if(result.can_apply&&manualLines.length){result.script.push(...manualLines);result.script.sort((a,b)=>a.start-b.start);}project.analysis.aiRequest={...project.analysis.aiRequest,state:'received',provider:'gemini',at:Date.now()};project.analysis.pendingAI={id,revision,editSignature,signature,sourceAsset:project.source.asset,at:Date.now(),result};p.steps.gemini=result.can_apply?'review':'attention';p.phase='Đã nhận kết quả Gemini · cần rà trước khi áp dụng';}catch(e){jobPostFailure(project.analysis.aiRequest,e);project.analysis.aiRequest.message=e.message;p.steps.gemini='attention';p.phase=e.message;}
 }catch(e){p.phase=e.readOnlyStatusInterrupted?'Tạm mất kết nối đọc trạng thái CPU; dữ liệu giữ nguyên, mở lại để tiếp tục đọc.':e.message;p.error=e.message;p.readInterrupted=!!e.readOnlyStatusInterrupted;throw e;}finally{project.analysis.pipeline6=p;g6PipelineActive=false;p.running=false;p.updatedAt=Date.now();await storeProject();render();}
}
const g6InitBefore=init;init=async function(){await g6InitBefore();const api=window.SceneForgeWorkflow,old=api.isAnalyzing,flush=api.flushRoom;api.isAnalyzing=()=>g6PipelineActive||!!old?.();api.flushRoom=async()=>{if(g6PipelineActive)throw Error('Đợi hoặc để sau phần phân tích trên máy trước khi đổi phòng.');return flush();};api.runAnalysisPipeline=g6AnalyzePipeline;api.openAIAnalysis=()=>project.analysis.pendingAI?showLiveAnalysisResult(project.analysis.pendingAI):liveAnalysisDialog();api.pauseAnalysis=()=>{g6PipelinePause=true;g6Pipeline().phase='Đang kết thúc bước hiện tại để tạm dừng';};};
const g6RenderAnalysisBefore=render;render=function(){g6RenderAnalysisBefore();const p=project.analysis.pipeline6;if(!p)return;if(project.analysis.semantic&&project.analysis.semantic.status!=='partial'&&!p.running){p.steps.gemini='done';p.phase='Đã phân tích · kiểm tra khung';}const body=$('#node-analysis .nodeBody');if(body){body.insertAdjacentHTML('afterbegin','<div class="g6PipelineStatus"><b>'+esc(p.phase)+'</b><div>'+[['cuts','Cắt cảnh'],['speech','Chép lời'],['ocr','Đọc chữ'],['gemini','Gemini']].map(([k,n])=>'<span class="'+(p.steps[k]||'waiting')+'">'+n+'</span>').join('')+'</div>'+(p.percent&&p.running?'<progress max="100" value="'+p.percent+'"></progress>':'')+'</div>');}if(p.running){for(const id of ['node-frames','node-videos','node-merge']){const n=$('#'+id);if(n){n.classList.add('g6AwaitAnalysis');n.inert=true;}}$$('#node-analysis .nodeFooter button,#node-source [data-action=upload],#node-source [data-action=analyze]').forEach(b=>b.disabled=true);}};
for(const name of ['analyze','live-analysis','live-analysis-run','cpu-analysis']){const before=actions[name];actions[name]=(...args)=>g6PipelineActive?toast('Đợi hoặc để sau phần phân tích hiện tại.'):before(...args);}
