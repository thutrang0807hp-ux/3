"""Scope immediate retirement to older versions of explicitly approved prompt slots."""
import copy
from .storage_lifecycle import collect_strings

def prune_approved(records,room,targets):
 from .library import hashes
 if not isinstance(targets,list)or not targets or len(targets)>500:raise ValueError('Danh sách duyệt không hợp lệ.')
 workflow=next((r for r in records if r['db']=='sceneforge-workflows'and r['key']==room),None)
 if not workflow:raise ValueError('Không có workflow của dự án.')
 value=workflow['value'];entries=dict(value.get('assetEntries',[]))
 editor=next((r['value']for r in records if r['db']=='sceneforge-editor-local'and r['key']==room),{})
 payload=editor.get('payload')or{};used={i.get('assetId')for i in payload.get('items',[])}
 timeline=set(hashes(payload.get('items',[])))
 for media in editor.get('media',[]):
  if media.get('id')in used:timeline.update(hashes(media))
 timeline_ids=collect_strings(payload.get('items',[]))
 timeline_ids.update(a.get('workflowKey')for a in payload.get('assets',[])if a.get('id')in used)

 removed=[];retired_assets=set();seen=set()
 for target in targets:
  if not isinstance(target,dict):raise ValueError('Sai ô duyệt.')
  sid,kind,part,keep=target.get('sceneId'),target.get('kind'),target.get('part'),target.get('keepId')
  if kind not in ('frame','clip')or (sid,kind,part)in seen:raise ValueError('Ô duyệt trùng hoặc sai loại.')
  seen.add((sid,kind,part));scene=next((s for s in value.get('scenes',[])if s.get('id')==sid),None)
  if not scene:raise ValueError('Cảnh đã thay đổi.')
  key='frames'if kind=='frame'else'clips'
  versions=[v for v in scene.get(key,[])if kind=='frame'or v.get('part')==part]
  if not versions or versions[-1].get('id')!=keep:raise ValueError('Bản mới nhất đã thay đổi; chưa dọn.')
  latest=versions[-1]
  jobs=[j for j in value.get('cloudJobs',[])if j.get('sceneId')==sid and j.get('kind')==('image'if kind=='frame'else'video')and(kind=='frame'or j.get('part')==part)]
  if jobs and jobs[-1].get('state')not in ('imported','applied','discarded'):raise ValueError('Lượt tạo mới nhất chưa kết thúc/đối soát; chưa dọn.')
  if kind=='frame':
   if scene.get('approvedFrame')!=keep or latest.get('status')!='approved':raise ValueError('Chưa duyệt ảnh mới nhất.')
  elif (scene.get('chosen')or{}).get(part)!=keep or keep not in scene.get('receivedClipIds',[])or(latest.get('reviewDecision')or{}).get('status')!='accepted':raise ValueError('Chưa duyệt clip mới nhất.')
  if not set(hashes(latest))and not set(hashes(entries.get(latest.get('asset')))):raise ValueError('Bản duyệt chưa lưu đủ media vào kho.')
  if kind=='clip'and latest.get('frameId')and latest['frameId']!=scene.get('approvedFrame'):raise ValueError('Clip không khớp khung đã duyệt.')
  if kind=='clip'and scene.get('clipPlan',{}).get('parts'):
   planned=next((p for p in scene['clipPlan']['parts']if p.get('id')==part),None)
   if not planned:raise ValueError('Phần clip không còn trong cách chia hiện tại.')
   if latest.get('slotStart')is not None and(abs(latest['slotStart']-planned['start'])>.002 or abs(latest.get('slotEnd',-1)-planned['end'])>.002):raise ValueError('Clip được tạo theo mốc khác; chưa duyệt/dọn.')
  if kind=='clip'and latest.get('continuityFrom'):
   cursor=latest;visited=set()
   while cursor.get('continuityFrom'):
    prior_id=cursor['continuityFrom']
    if prior_id in visited:raise ValueError('Chuỗi nối clip không hợp lệ.')
    visited.add(prior_id)
    previous=next((c for c in scene.get('clips',[])if c.get('id')==prior_id),None)
    group=[c for c in scene.get('clips',[])if previous and c.get('part')==previous.get('part')]
    if not group or group[-1].get('id')!=prior_id or prior_id not in scene.get('receivedClipIds',[])or(previous.get('reviewDecision')or{}).get('status')!='accepted':raise ValueError('Phần trước đã đổi/chưa duyệt; cần nối lại clip trước khi duyệt.')
    cursor=previous
  protected_frames={c.get('frameId')for c in scene.get('clips',[])if c.get('id')in(scene.get('chosen')or{}).values()}
  kept=[]
  for v in scene.get(key,[]):
   matching=kind=='frame'or v.get('part')==part
   media=set(hashes(v))|set(hashes(entries.get(v.get('asset'))))|set(hashes(entries.get(v.get('originalAsset'))))
   protected=v.get('pinned')or v.get('id')in timeline_ids or bool(media&timeline)or kind=='frame'and v.get('id')in protected_frames
   if not matching or v.get('id')==keep or protected:kept.append(v);continue
   removed.append((kind,copy.deepcopy(v)))
   retired_assets.update(x for x in (v.get('asset'),v.get('originalAsset'))if x)
  scene[key]=kept
  if kind=='frame':scene['frameSelectionId']=keep
 # Keep lightweight provenance; retired image previews and video bytes must not remain
 # reachable through old structural snapshots or undo copies in this same workflow.
 ids={v['id']for _,v in removed}
 # Remove only unused editor-library alternatives and pending imports of retired IDs.
 retired_editor={a.get('id')for a in payload.get('assets',[])if a.get('workflowKey')in ids and a.get('id')not in used}
 if retired_editor:
  payload['assets']=[a for a in payload.get('assets',[])if a.get('id')not in retired_editor]
  editor['media']=[m for m in editor.get('media',[])if m.get('id')not in retired_editor]
 for row in records:
  if row['db']=='sceneforge-app-shell'and row['store']=='files'and row['key']==room+':pending'and isinstance(row['value'],list):row['value']=[c for c in row['value']if c.get('key')not in ids]

 def strip(v):
  if isinstance(v,list):return [strip(x)for x in v if not(isinstance(x,dict)and x.get('id')in ids)]
  if isinstance(v,dict):
   out={k:strip(x)for k,x in v.items()}
   for field in ('approvedFrame','frameSelectionId'):
    if out.get(field)in ids:out[field]=None
   if isinstance(out.get('chosen'),dict):out['chosen']={k:x for k,x in out['chosen'].items()if x not in ids}
   return out
  return v
 for key in ('localHistory','local','pendingAI'):
  if key in value:value[key]=strip(value[key])
 value.setdefault('retiredVersionLog',[]).extend({k:v.get(k)for k in ('id','part','version','requestId','prompt','model','name','createdAt')}|{'kind':kind}for kind,v in removed)
 value['retiredVersionLog']=value['retiredVersionLog'][-2000:]
 remaining=copy.deepcopy(value);remaining.pop('assetEntries',None);remaining.pop('retiredVersionLog',None);strings=collect_strings(remaining)
 value['assetEntries']=[[a,b]for a,b in value.get('assetEntries',[])if a not in retired_assets or a in strings or set(hashes(b))&timeline]
 value['approvalCleanupPending']=[t for t in value.get('approvalCleanupPending',[])if t not in targets]
 return len(removed)
