"""Automatic import from the app-owned persistent login window; no generation."""
import asyncio,json,time
from pathlib import Path
from fastapi import HTTPException
from .google_login import open_flow_web_login
from .flow_connection import public_error

class FlowWebLogin:
    def __init__(self,data,accounts):
        self.data=Path(data);self.accounts=accounts;self.task=None
        self.state={'state':'idle','message':'Chưa mở đăng nhập web.'}
    def status(self):return dict(self.state)
    async def start(self):
        if self.task and not self.task.done():return {'opened':True,**self.status()}
        reuse=False
        try:
            import httpx
            port=int((self.data/'browser-profiles/flow-web/DevToolsActivePort').read_text().splitlines()[0])
            if 1<=port<=65535:
                async with httpx.AsyncClient(trust_env=False,timeout=1)as client:
                    response=await client.get('http://127.0.0.1:'+str(port)+'/json/version')
                if response.status_code==200 and 'Chrome'in str(response.json().get('Browser','')):reuse=True
        except Exception:pass
        if not reuse:await open_flow_web_login(self.data,auto_connect=True)
        self.state={'state':'waiting','message':'Đăng nhập Flow trong cửa sổ vừa mở. App sẽ tự kiểm tra và nhận tài khoản; giữ cửa sổ mở.'}
        self.task=asyncio.create_task(self.watch())
        return {'opened':True,**self.status()}
    async def close(self):
        if self.task and not self.task.done():
            self.task.cancel()
            try:await self.task
            except asyncio.CancelledError:pass
    async def import_account(self,cookies,context,email=''):
        self.state={'state':'checking','message':'Đã thấy phiên Flow. Đang xác minh tài khoản với engine; chưa tạo video.'}
        if email and getattr(self.accounts,'web_ui',None)and hasattr(self.accounts,'vault'):
            import hashlib
            aid='flow-web-'+hashlib.sha256(email.strip().casefold().encode()).hexdigest()[:24]
            self.accounts.vault.set_secret('flow-ui-profile',{'account_id':aid,'email':email.strip().casefold()})
            await self.accounts.web_ui.verify(aid)
            old=next((a for a in self.accounts.pool.rows()if a['id']==aid),{})
            self.accounts.vault.put('accounts',{**old,'id':aid,'service':'flow','name':email+' · web UI','login_transport':'web_ui','enabled':True,'session_verified':True,'state':'ready','active':False,'priority':old.get('priority',len(self.accounts.pool.rows())),'credit':None})
            self.accounts.pool.select({'mode':'selected','account_id':aid})
            self.state={'state':'done','account_id':aid,'message':'Đã nối tài khoản với cửa sổ Flow riêng. Bản thử sẽ thao tác trực tiếp trên giao diện web khi bạn tạo clip. Trên web chọn Lite 8 giây và Frames to Video; giữ cửa sổ mở.'}
            return
        # Preserve a previously paired native route for this same verified identity.
        existing=next((a for a in self.accounts.pool.rows() if email and str(a.get('name','')).casefold()==email.casefold() and a.get('native_route_id')),None)
        if existing:
            checked=await self.accounts.check(existing['id'])
            if not checked.get('ok'):raise HTTPException(409,'Tài khoản đã nối bằng mã chưa xác minh được; giữ kết nối cũ, không thay phiên đang dùng.')
            self.state={'state':'done','account_id':existing['id'],'message':'Đã nhận tài khoản Flow đã kết nối trong app; giữ nguyên kết nối bằng mã hiện có.'}
            return
        result=await self.accounts.import_session(cookies,browser_context=context)
        aid=result.get('imported_account_id')
        if not aid:raise HTTPException(502,'Engine chưa trả mã tài khoản.')
        checked=await self.accounts.check(aid)
        if not checked.get('ok'):raise HTTPException(409,'Engine chưa xác minh được phiên Flow.')
        if email and hasattr(self.accounts,'vault'):
            self.accounts.vault.set_secret('flow-ui-profile',{'account_id':aid,'email':email.strip().casefold()})
        self.state={'state':'done','account_id':aid,'message':'Đã nhận tài khoản Flow. Bản thử sẽ thao tác trực tiếp trên cửa sổ web này khi bạn bấm tạo clip. Giữ cửa sổ mở, chọn Lite 8 giây và Frames to Video trên web. Chưa gửi tạo video.'}
    async def watch(self):
        pw=None
        try:
            from playwright.async_api import async_playwright
            pw=await async_playwright().start();browser=None;deadline=time.monotonic()+300
            while time.monotonic()<deadline:
                if browser is None:
                    try:
                        port=int((self.data/'browser-profiles/flow-web/DevToolsActivePort').read_text().splitlines()[0])
                        if not 1<=port<=65535:raise ValueError()
                        browser=await pw.chromium.connect_over_cdp('http://127.0.0.1:'+str(port),timeout=2000)
                    except (OSError,ValueError,IndexError):pass
                    except Exception:pass
                if browser:
                    for context in browser.contexts:
                        for page in context.pages:
                            from urllib.parse import urlsplit,parse_qs
                            u=urlsplit(page.url)
                            if u.scheme!='https' or u.hostname!='flow.google.com':continue
                            try:
                                email=await page.evaluate(r"""() => {
                                    const value=window.WIZ_global_data?.oPEP7c;
                                    if(typeof value==='string')return value;
                                    const match=document.documentElement.innerHTML.match(/"oPEP7c"\s*:\s*("(?:[^"\\]|\\.)*")/);
                                    try{return match?JSON.parse(match[1]):'';}catch{return '';}
                                }""")
                                if '@'not in email:continue
                                cookies=[]if getattr(self.accounts,'web_ui',None)else await context.cookies(['https://flow.google.com/','https://accounts.google.com/','https://labs.google/'])
                                cookies=[c for c in cookies if c.get('domain','').lstrip('.')in {'google.com','flow.google.com','labs.google'}]
                                ua=await page.evaluate('() => navigator.userAgent')
                                value={'user_agent':ua};index=parse_qs(u.query).get('authuser',[''])[0]
                                if index.isdigit()and len(index)<=3:value['authuser']=index
                            except Exception:continue
                            await self.import_account(cookies,value,email)
                            return
                await asyncio.sleep(2)
            self.state={'state':'failed','code':'FLOW_WEB_LOGIN_TIMEOUT','message':'Chưa nhận được phiên sau 5 phút. Nếu cửa sổ profile Flow của bản v25 còn mở, đóng cửa sổ đó rồi bấm đăng nhập web lại.'}
        except asyncio.CancelledError:raise
        except Exception as exc:
            from .flow_ui_driver import UiFlowFailure
            from .flow_ui_session import SessionUnavailable
            safe={'code':'FLOW_WEB_UI_NOT_READY','message':str(exc)}if isinstance(exc,(UiFlowFailure,SessionUnavailable))else public_error(exc)
            self.state={'state':'failed','code':safe.get('code','FLOW_WEB_LOGIN_FAILED'),'message':'Chưa xác minh được tài khoản từ cửa sổ web. '+safe.get('message','Kiểm tra engine Flow rồi mở lại đăng nhập web.')}
        finally:
            # Disconnect Playwright, keep the user's window/profile intact.
            if pw:await pw.stop()
