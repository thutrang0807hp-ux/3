"""Experimental app-owned browser session for normal Flow UI operations.

No private RPCs, CAPTCHA tokens, fingerprint changes or credential export.
"""
from pathlib import Path
from urllib.parse import urlsplit
import asyncio

IDENTITY_SCRIPT="() => String(window.WIZ_global_data?.oPEP7c || '')"

class SessionUnavailable(RuntimeError):pass
class VerificationRequired(SessionUnavailable):pass

class FlowUiSession:
    def __init__(self,data):
        self.profile=Path(data)/'browser-profiles/flow-web'
        self.playwright=None;self.browser=None;self.page=None;self.email=None
        self.lock=asyncio.Lock()
    async def attach(self,playwright_factory):
        """Attach only to the persistent profile SceneForge opened explicitly."""
        try:
            port=int((self.profile/'DevToolsActivePort').read_text().splitlines()[0])
            if not 1<=port<=65535:raise ValueError()
        except (OSError,ValueError,IndexError):
            raise SessionUnavailable('Mở Đăng nhập Flow trên web trước.')from None
        self.playwright=await playwright_factory().start()
        try:
            self.browser=await self.playwright.chromium.connect_over_cdp('http://127.0.0.1:'+str(port),timeout=10000)
            pages=[p for c in self.browser.contexts for p in c.pages if self.is_flow(p.url)]
            if len(pages)!=1:raise SessionUnavailable('Giữ một tab Flow trong cửa sổ riêng để chọn đúng project.')
            self.page=pages[0]
            identity=await self.page.evaluate(IDENTITY_SCRIPT)
            if not isinstance(identity,str)or '@'not in identity:raise SessionUnavailable('Đăng nhập trong tab Flow trước.')
            self.email=identity.strip().casefold()
            await self.assert_ready()
        except BaseException:
            await self.disconnect();raise
    @staticmethod
    def is_flow(url):
        try:
            p=urlsplit(url)
            return p.scheme=='https'and p.hostname=='flow.google.com'and not p.username and not p.password
        except ValueError:return False
    async def assert_ready(self):
        if not self.browser or not self.browser.is_connected()or not self.page or self.page.is_closed():
            raise SessionUnavailable('Cửa sổ Flow đã đóng. Chưa gửi tác vụ mới.')
        if not self.is_flow(self.page.url):raise SessionUnavailable('Tab Flow đã chuyển trang. Chưa gửi tác vụ mới.')
        identity=await self.page.evaluate(IDENTITY_SCRIPT)
        if not isinstance(identity,str)or identity.strip().casefold()!=self.email:
            raise SessionUnavailable('Tài khoản trong tab đã đổi. Chưa gửi tác vụ mới.')
        # Pause for visible challenges. Never interact with or extract CAPTCHA data.
        for frame in self.page.frames:
            if 'google.com/recaptcha/'in frame.url and '/bframe'in frame.url:
                element=await frame.frame_element()
                if await element.is_visible():raise VerificationRequired('Hoàn tất xác minh trên web trước. App không tự vượt xác minh.')
        alerts=self.page.get_by_role('alert')
        for alert in await alerts.all():
            if not await alert.is_visible():continue
            text=(await alert.inner_text()).casefold()
            if any(word in text for word in ('unusual activity','hoạt động bất thường','public_error_unusual_activity')):
                raise VerificationRequired('Google từ chối hoạt động bất thường. Đã dừng, không thử lại.')
        return True
    async def disconnect(self):
        # Disconnect the automation client, never close/delete the user's profile.
        pw=self.playwright
        self.playwright=self.browser=self.page=None;self.email=None
        if pw:await pw.stop()
