# Câu hỏi có thể gửi người hỗ trợ

Tôi đang phát triển SceneForge: Gemini viết prompt rồi Flow tạo Veo 3.1 I2V từ ảnh khung đã duyệt. Tôi cần sử dụng credit Flow hiện có, không chuyển sang API tính phí riêng.

Flow web cùng tài khoản tạo video được. Qua app, engine báo:

```text
HTTP 500 | generate_video
Flow frontend RPC rejected: rpc=eb1hJf, error=PUBLIC_ERROR_UNUSUAL_ACTIVITY
```

Lượt đầu có `Flow native browser HTTP 504`. Sáu lượt sau đều lỗi unusual activity. App có native browser relay/extension riêng, không chỉ gọi nguyên bản Flow2API. Mã liên quan nằm trong ZIP, có mã gốc và diff để đối chiếu.

Flow2API pinned: `1bcb9275d154c330d29cac3ba836a13393ff49c7`.
Upstream issue có triệu chứng tương tự: https://github.com/TheSmallHanCat/flow2api/issues/190 (issue đó nói về ảnh/rpc khác; không coi là chẩn đoán chắc chắn cho video này).

Nhờ kiểm tra:
1. Adapter native browser/room project/account có không tương thích với hợp đồng của upstream không? Chỉ rõ tệp/hàm và bằng chứng.
2. `eb1hJf` và payload I2V của model đang chọn có đúng với revision ghim không?
3. Xử lý lỗi của journal có khiến lỗi upstream bị đổi thành `HTTP_409`/unknown hoặc làm UI giữ 7 lượt chưa rõ không?
4. Có hướng tích hợp tự động được dịch vụ hỗ trợ và dùng credit Flow hiện tại không? Nếu không, xin nói rõ giới hạn thay vì chỉ đưa bản vá UI.
5. Nếu có bản sửa, cần phân biệt kiểm thử fixture và tạo video thật. Không xem fixture pass là đã hết lỗi Google. Không tự đổi tài khoản, gửi lại hàng loạt hoặc bỏ receipt chưa đối soát.

Tôi không cung cấp cookie, token, key, HAR đầy đủ hay file flow.db. Nếu cần thêm bằng chứng, xin nêu chính xác thông tin đã che cần thu thập.
