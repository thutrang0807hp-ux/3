# Tệp thay đổi so với gói nguồn người dùng gửi

- `local_engine/check_flow_room_engine.py`
- `local_engine/check_video_node.py`
- `local_engine/flow_account_engine.py`
- `local_engine/flow_provider.py`
- `local_engine/flow_task_journal.py`
- `scripts/app-shell/accounts-dashboard.js`
- `scripts/recovered/workflow.js`
- `scripts/shared/prompt-contract.js`
- `scripts/shared/provider-receipts.js`
- `scripts/workflow/direct-providers.js`
- `scripts/workflow/media-nodes.js`
- `scripts/workflow/prompt-pipeline.js`

Các tệp khác có bản gốc kèm để đối chiếu. Tệp kiểm thử mới chỉ có trong source-current.
