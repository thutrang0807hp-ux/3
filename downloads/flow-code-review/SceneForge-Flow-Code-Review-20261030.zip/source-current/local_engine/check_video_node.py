"""Actual video node controls and one-click batch send, fixture provider only."""
import base64,io,json,os,socket,tempfile,time,urllib.request
from pathlib import Path
from threading import Thread
import uvicorn
from PIL import Image
from playwright.sync_api import sync_playwright,expect


def main():
    with tempfile.TemporaryDirectory()as tmp:
        os.environ['SCENEFORGE_LOCAL_DATA']=tmp
        from . import server
        with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        host=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'))
        thread=Thread(target=host.run,daemon=True);thread.start();base='http://127.0.0.1:'+str(port)
        image=io.BytesIO();Image.new('RGB',(90,160),'#3a827a').save(image,format='PNG')
        data='data:image/png;base64,'+base64.b64encode(image.getvalue()).decode()
        models=['veo-3.1-fast-i2v-6s-portrait','veo-3.1-quality-i2v-6s-portrait','omni-1.1-flash-8s-portrait','veo-3.1-lite-i2v-6s-portrait','veo-3.1-fast-8s-portrait']
        posts=[];writers=[];jobs={};mode={'fail':False,'switch':False}
        try:
            for _ in range(100):
                try:urllib.request.urlopen(base+'/local-api/health',timeout=.3);break
                except OSError:time.sleep(.05)
            with sync_playwright()as pw:
                browser=pw.chromium.launch(executable_path=os.environ.get('SCENEFORGE_BRIDGE_TEST_BROWSER')or'/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page(viewport={'width':1600,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                def route(r):
                    path=r.request.url.split('/local-api/',1)[1]
                    if path=='gemini-chat/status':return r.fulfill(json={'installed':True,'selection':{'available':True,'token':'fixture-writer'}})
                    if path=='gemini-chat/jobs':
                        body=r.request.post_data_json;writers.append(body);
                        if mode.get('writer_refuse'):
                            jobs[body['request_id']]={'state':'done','result':{'text':'Tôi không thể trợ giúp về điều đó, vì tôi chỉ là một mô hình ngôn ngữ nên không có thông tin hoặc khả năng cần thiết.'}}
                            return r.fulfill(json={'state':'submitted'})
                        if mode.get('writer_fail'):
                            jobs[body['request_id']]={'state':'failed','code':'SDK_CONTRACT_MISMATCH','message':'SDK Gemini Chat không tương thích với adapter hiện tại.'}
                            return r.fulfill(json={'state':'submitted'})
                        context=json.loads(body['prompt'].split('\nSCENE DATA:\n')[1])
                        result={'visual':{lang:{k:'Young man wearing brown shirt and checkered scarf'for k in ['person','product','scale','composition','background','lighting']}for lang in ['vi','en']},'motion':{lang:{k:'Lift the object gently'if k=='action'else'Keep the approved frame state'for k in ['camera','initial','action','final']}for lang in ['vi','en']},'used_refs':[b['code']for b in context['bindings']],'warnings':[]}
                        jobs[body['request_id']]={'state':'done','result':{'text':json.dumps(result)}}
                        return r.fulfill(json={'state':'submitted'})
                    if path.startswith('gemini-chat/jobs/'):return r.fulfill(json=jobs[path.rsplit('/',1)[-1]])
                    if path in ('flow/status','flow/models'):
                        if mode['switch']:
                            mode['switch']=False;page.evaluate("project.id='different-room'")
                        return r.fulfill(json={'account_binding':True,'models':models,'model_details':[{'id':models[-1],'accepts_images':False}],'selection':{'available':True,'mode':'selected','account_name':'Fixture Flow','token':'fixed-account'}})
                    if path=='flow/jobs':
                        body=r.request.post_data_json;posts.append(body)
                        if mode['fail']:return r.fulfill(status=503,json={'detail':'Fixture unavailable; outcome unknown'})
                        return r.fulfill(json={'state':'queued'})
                    if path.startswith('flow/jobs/'):return r.fulfill(json={'state':'queued'})
                    r.continue_()
                page.route('**/local-api/flow/**',route);page.route('**/local-api/gemini-chat/**',route)
                page.goto(base);page.wait_for_function('appBootReady&&SceneForgeStorage.state.active')
                page.goto(base+'/workflow.html?mode=reference');page.wait_for_function('!!window.SFMediaNodes')
                page.evaluate('''async image=>{
                 project=blankProject();project.id='node-run';project.source={poster:image,asset:'source'};project.analysis.frameQualityRequired=false;
                 const file=new File([await(await fetch(image)).blob()],'frame.png',{type:'image/png'});assets.set('real-frame',file);
                 project.scenes=Array.from({length:8},(_,i)=>sceneRecord(i*4,(i+1)*4,i,[image]));
                 for(const s of project.scenes){s.id='node-scene-'+s.index;s.hasPerson=false;s.refsUsed=[];s.sourceFrame={id:'source',asset:'real-frame',image};s.approvedFrame='source';s.frameSelectionId='source';}
                 project.scenes[0].visual.en.person='Young man wearing brown shirt and checkered scarf';project.scenes[0].refsUsed=['person'];project.refs.person.images=[{id:'replacement',image}];
                 const s=project.scenes[1];assets.set('old-video',new File(['fixture'],'old.mp4',{type:'video/mp4'}));s.clips=[{id:'old-clip',asset:'old-video',part:'a',duration:4,version:1,poster:image,frameId:'source',reviewDecision:{status:'accepted'}}];s.receivedClipIds=['old-clip'];
                 project.scenes[4].approvedFrame=null;
                 project.cloudJobs=[{id:'unknown',kind:'video',provider:'flow',sceneId:project.scenes[2].id,part:'a',state:'unknown'},{id:'failed',kind:'video',provider:'flow',sceneId:project.scenes[3].id,part:'a',state:'failed',error:'Known provider failure'},{id:'pending',kind:'video',provider:'flow',sceneId:project.scenes[5].id,part:'a',state:'queued'},{id:'retired',kind:'video',provider:'flow',sceneId:project.scenes[6].id,part:'a',state:'abandoned'},{id:'imported-receipt',kind:'video',provider:'flow',sceneId:project.scenes[7].id,part:'a',state:'imported'}];
                 await storeProject();render();
                }''',data)
                page.wait_for_selector('#node-videos select[data-mn-model] option[value="'+models[0]+'"]',state='attached')
                run=page.locator('#node-videos header [data-mn=run-clips]')
                expect(run).to_have_text('▶ Chạy 2 clip');expect(run).to_be_disabled()
                primary=page.locator('#node-videos .mnVideoControls>label select')
                assert primary.locator('option').count()==5
                assert primary.locator('option[value="'+models[-1]+'"]').count()==0
                assert 'I2V' in primary.locator('option[value="'+models[1]+'"]').inner_text()
                assert primary.locator('option[value="'+models[3]+'"]').count()==1
                page.evaluate("m=>{project.mediaNodes.flowModel=m;render();}",models[-1])
                expect(run).to_be_disabled()
                expect(page.locator('#node-videos .mnVideoControls [role=alert]')).to_contain_text('I2V')
                assert not posts and not writers
                page.locator('#node-videos [data-mn=refresh-models]').click()
                page.wait_for_function("!document.querySelector('#node-videos [data-mn=refresh-models]').disabled")
                expect(run).to_be_disabled()
                primary.select_option(models[1]);page.wait_for_function('project.mediaNodes.flowModel===\"'+models[1]+'\"')
                expect(run).to_be_enabled();assert not posts
                assert page.evaluate("SFMediaNodes.status(project.scenes[0],'clip','a').bucket")=='waiting'
                page.evaluate("()=>{document.querySelector('#node-videos header [data-mn=run-clips]').click();document.querySelector('#node-videos header [data-mn=run-clips]').dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));}")
                page.wait_for_function("project.cloudJobs.filter(j=>j.model).length===2&&project.cloudJobs.filter(j=>j.model).every(j=>j.state==='queued')",timeout=20000)
                assert len(posts)==2,posts
                assert {r['scene_id']for r in posts}=={'node-scene-0','node-scene-3'}
                assert all(r['model']==models[1]and r['confirm_send']for r in posts)
                assert len(writers)==2 and len(writers[0]['references'])==2
                assert all(len(r['references'])==1 and r['references'][0]['data']==image_data for r in posts for image_data in [data.split(',')[1]])
                assert all('Young man'not in r['prompt'] and 'Lift the object gently'in r['prompt'] and 'approved start frame'in r['prompt']for r in posts)
                assert all('R2'not in r['prompt']for r in posts)
                assert page.evaluate('project.scenes[1].clips[0].id')=='old-clip'
                assert page.evaluate('project.scenes[1].clips.length')==1
                assert not page.locator('#modal').evaluate('n=>n.open'),'Node run should not require prepare/send dialogs'
                expect(run).to_be_disabled()
                mode['fail']=True
                page.evaluate("()=>{project.scenes[4].approvedFrame='source';render();}")
                expect(run).to_have_text('▶ Chạy 1 clip');run.click()
                page.wait_for_function("project.cloudJobs.some(j=>j.sceneId==='node-scene-4'&&j.state==='unknown')")
                expect(page.locator('#node-videos .mnVideoControls [role=alert]')).to_contain_text('Fixture unavailable')
                assert len(posts)==3
                expect(run).to_be_disabled()
                assert not page.locator('#modal').evaluate('n=>n.open')
                page.evaluate("()=>{assets.delete('old-video');render();}")
                expect(run).to_have_text('▶ Chạy 0 clip');expect(run).to_be_disabled()
                assert len(posts)==3
                mode['fail']=False;mode['switch']=True
                page.evaluate("()=>{project.cloudJobs=[];project.scenes=[project.scenes[0]];render();}")
                expect(run).to_be_enabled();run.click()
                page.wait_for_function("project.id==='different-room'&&document.querySelector('#node-videos .mnVideoControls [role=alert]')?.textContent.includes('Phòng đã đổi')")
                assert len(posts)==3,'Old node dispatched into a changed room'
                page.evaluate("()=>{const n=document.querySelector('#node-videos');view.z=1;view.x=40-n.offsetLeft;view.y=40-n.offsetTop;applyView();}")
                screenshot=Path(__file__).resolve().parents[1]/'artifacts/video-node-controls.png';screenshot.parent.mkdir(exist_ok=True)
                page.locator('#node-videos').screenshot(path=str(screenshot))
                mode['writer_fail']=True
                before_posts=len(posts)
                page.evaluate("()=>{project.id='writer-failure';project.cloudJobs=[];project.promptPipeline={records:{}};project.scenes=[project.scenes[0]];render();}")
                expect(run).to_be_enabled();run.click()
                expect(page.locator('#node-videos .mnVideoControls [role=alert]')).to_contain_text('SDK_CONTRACT_MISMATCH',timeout=20000)
                writer_count=len(writers)
                run.click()
                expect(page.locator('#node-videos .mnVideoControls [role=alert]')).to_contain_text('SDK_CONTRACT_MISMATCH')
                assert len(writers)==writer_count and len(posts)==before_posts,'Failed writer was sent again'
                page.locator('#node-videos .mnVideoControls [data-mn=jobs]').click()
                expect(page.locator('#modal')).to_contain_text('SDK Gemini Chat không tương thích')
                assert len(writers)==writer_count and len(posts)==before_posts,'Viewing errors sent a request'
                page.evaluate('closeModal()')
                mode['writer_fail']=False;mode['writer_refuse']=True
                page.evaluate("()=>{project.id='writer-refusal';project.promptPipeline={records:{}};project.cloudJobs=[];render();}")
                run.click()
                expect(page.locator('#node-videos .mnVideoControls [role=alert]')).to_contain_text('từ chối viết prompt',timeout=20000)
                expect(page.locator('#node-videos [data-mn=rewrite-prompt]')).to_be_enabled()
                previous=page.evaluate('Object.values(project.promptPipeline.records)[0].job.id')
                count=len(writers);flow_count=len(posts)
                run.click()
                expect(page.locator('#node-videos .mnVideoControls [role=alert]')).to_contain_text('từ chối viết prompt')
                assert len(writers)==count and len(posts)==flow_count
                page.once('dialog',lambda d:d.dismiss())
                page.locator('#node-videos [data-mn=rewrite-prompt]').click()
                expect(page.locator('#node-videos [data-mn=rewrite-prompt]')).to_be_enabled()
                assert len(writers)==count
                mode['writer_refuse']=False
                page.once('dialog',lambda d:d.accept())
                page.locator('#node-videos [data-mn=rewrite-prompt]').click()
                page.wait_for_function('Object.values(project.promptPipeline.records).some(r=>r.applied)',timeout=20000)
                assert len(writers)==count+1 and len(posts)==flow_count
                assert page.evaluate('project.promptPipeline.history[0].job.id')==previous
                assert 'không thể trợ giúp'in page.evaluate('project.promptPipeline.history[0].rawText')
                assert page.evaluate('Object.values(project.promptPipeline.records)[0].job.id')!=previous
                assert 'NOT being asked to create' in writers[-1]['prompt']
                run.click()
                page.wait_for_function("project.cloudJobs.some(j=>j.provider==='flow'&&j.state==='queued')")
                assert len(posts)==flow_count+1 and len(writers)==count+1
                print('PASS refusal shown clearly; raw response retained; repeated Run never resends; cancelled rewrite sends nothing; explicit rewrite sends exactly one new writer ID, archives old result and does not call Flow until Run')
                assert not errors,errors
                browser.close()
            print('PASS actual video node: all I2V including Lite in primary select, text-only hidden, stale T2V selection blocks send, refresh keeps selection, explicit selection retained, header sends two missing/known-failed clips in one action, no per-clip/prepare/send modal, old result/unknown/queued/unapproved slots preserved, double-click sends once, changed room during preparation blocks dispatch. Fixture provider only; zero Google calls.')
        finally:
            host.should_exit=True;thread.join(timeout=10)
            for handler in list(server.RUNTIME_LOG.handlers):handler.close();server.RUNTIME_LOG.removeHandler(handler)
            server.LIBRARY._root_guard.instance.close()

if __name__=='__main__':main()
