# SceneForge — gói mã để nhờ kiểm tra lỗi tạo Veo qua Flow

Đọc `01-CAU-HOI-DE-GUI.md` trước. Đây là mã trích riêng từ app của người dùng, gồm adapter Flow, extension, node Veo, ghi/đối soát tác vụ và các bài kiểm thử. Không phải bộ cài, không phải toàn bộ dự án chạy độc lập. Không chứa cookie, token, API key thực tế, cơ sở dữ liệu, ảnh hay dữ liệu dự án của người dùng.

## Hiện trạng đã xác nhận
- Mục tiêu: AI viết prompt → tự động tạo Veo I2V bằng credit Flow hiện có → nhận clip vào đúng cảnh. Không thêm API trả phí riêng.
- Người dùng cho biết tạo video trực tiếp trên Flow web thành công, không cần đăng nhập lại.
- Engine tích hợp từ chối video I2V: `Flow frontend RPC rejected: rpc=eb1hJf, error=PUBLIC_ERROR_UNUSUAL_ACTIVITY`.
- Một lượt trước đó: `Flow native browser HTTP 504`.
- Nhật ký engine `request_logs`: 6 lượt HTTP 500 chứa lỗi trên; một lượt HTTP 500 do 504. Bảng `tasks` không có bản ghi thất bại. Điều này không tự chứng minh rằng không tiêu credit hoặc Google chưa nhận yêu cầu.
- Cửa sổ app đôi lúc chỉ thấy HTTP_409 do owned journal trả unresolved, không phải lỗi upstream gốc.
- Mã lỗi chưa đủ để kết luận tài khoản bị khóa, thiếu credit, quota hay lỗi model. Không có kết quả video online thành công được kiểm chứng qua adapter này.

## Phiên bản
- Flow2API: https://github.com/TheSmallHanCat/flow2api
- Revision được bộ cài ghim: `1bcb9275d154c330d29cac3ba836a13393ff49c7`.
- Upstream main đã kiểm tra: `b410e373d4e90772a31ce8d33b5a5e3172c6ca28`; diff so với bản ghim chỉ gồm `static/test.html`, `static/locales/test.json`, `tests/test_i18n_browser.py`.
- Extension SceneForge: `1.5.0`.
- `source-current`: mã sau các thay đổi tới updater v20, 2026.10.30.20.
- `source-original`: các tệp tương ứng từ gói nguồn người dùng cung cấp, chưa sửa. Không phải bản upstream Flow2API.
- Không khẳng định source trên PC byte-for-byte trùng mã current: có thể đã cập nhật app nhưng extension hoặc process engine chưa được nạp lại.

## Đường đi yêu cầu
Node Veo → `direct-providers.js` / `prompt-pipeline.js` → `/local-api/flow/jobs` → `flow_provider.py` → engine `/v1/chat/completions` với account/request/room identity → `flow_account_engine.py` + `flow_task_journal.py` → Flow2API.

Transport riêng của SceneForge: `flow_native_transport.py` chuyển một số lời gọi sang paired browser qua `flow_browser_relay.py` / `browser_bridge.py` → extension `worker.js` → `native-flow.js` trong tab Flow được ghim. Không mặc định đây là luồng nguyên bản của repo upstream. Cần so sánh riêng.

Trong Flow2API bản ghim, `eb1hJf` được dựng trong `src/services/flow_frontend.py`, `_build_frontend_video_generation_rpc`, mode `start` (I2V một khung đầu). Các hàm gửi nằm trong `src/services/flow_client.py`. Repo upstream không đóng gói trong ZIP này; lấy đúng revision từ URL ở trên, không thay bằng main rồi cho rằng tương đương.

## Những thay đổi đã làm — chưa phải sửa xong generation
- Hiện rõ I2V/Lite, chặn T2V ở node dùng ảnh; thêm đọc lại danh mục.
- Giữ prompt do Gemini viết; nhận diện câu AI từ chối và thêm thao tác viết lại có xác nhận, lưu kết quả cũ.
- Hiện đối soát thành cửa sổ riêng, không để lỗi lưu dự án che trạng thái.
- Sửa lọc nhật ký Flow cũ thiếu `service`/`account_id`; lưu nhóm nguyên nhân lỗi mới và không lưu raw body nhạy cảm.
- Các thay đổi trên có kiểm thử fixture/browser; CHƯA tạo clip thực tế thành công qua engine trên tài khoản người dùng.

## Kiểm thử
Các `check_*.py` được kèm để người kiểm tra đọc và ghép vào dự án đầy đủ. Chúng cần các module/dependency còn lại của app. Kết quả fixture không chứng minh Google chấp nhận gửi thật.
Các kiểm thử đã qua trong môi trường Linux: check_flow_error_details, check_provider_reconcile, check_flow_room_engine, check_flow_projects_images, check_reconcile_dialog, check_video_node và kiểm thử dashboard tài khoản/prompt pipeline. Updater Windows chưa được thực thi trong môi trường này.

Không chạy lại hàng loạt 7 clip, xóa DB, bỏ receipt chưa rõ hoặc tự thay ID để thử. Khi kiểm chứng online, cần người dùng chủ động cho phép một lượt, giữ đúng account/scene, và dừng khi dịch vụ yêu cầu xác minh. Gói này phục vụ kiểm tra tính tương thích; không yêu cầu vượt cơ chế xác minh của Google.
