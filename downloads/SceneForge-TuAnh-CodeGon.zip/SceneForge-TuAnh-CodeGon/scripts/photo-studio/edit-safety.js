// Explicit edits share one path. Retiming creates local reuse records, never AI jobs.
let photoEditBusy=false;
function photoHasProductionWork(){return !!(draft.storyboardImages?.length||draft.flowJobs?.length||draft.geminiJobs?.length||draft.voice.key||draft.plan?.length||draft.beats.some(b=>b.clipPlan||b.clips?.length||b.frames?.length||b.staleClips?.length));}
function photoAssertEditable(beats=draft.beats){
 if(photoEditBusy||photoApprovalBusy||photoProductionWorking)throw Error('Đợi thao tác hiện tại lưu xong.');
 const ids=new Set(beats.map(b=>b.id));
 if((draft.flowJobs||[]).some(j=>ids.has(j.beatId)&&photoPendingStates.has(j.state)))throw Error('Cảnh đang có lượt chưa nhận/đối soát. Nhận kết quả hoặc đối soát lượt đó trước khi sửa mốc/ảnh.');
}
function photoRememberManualEdit(wasCurrent,entry){
 const state=photoProductionState();delete state.finalizedSignature;
 if(wasCurrent)state.promptSource=photoProductionInput();
 state.manualEdits??=[];state.manualEdits.push({...entry,at:Date.now()});state.manualEdits=state.manualEdits.slice(-30);
}
function photoVisualIntent(b,p){const per=b.partPrompts?.[p.id]||{};return JSON.stringify({name:b.name,angle:b.angle||'',visual:per.visualPrompt||b.visualPrompt||'',motion:per.motionPrompt||b.motionPrompt||b.movement||'',frame:b.approvedFrame||null,refs:photoRefsFor(b),continuity:!!b.clipPlanning?.continuity});}
function photoEditProposal(edits){
 const result=[];
 for(const edit of edits){
  const original=draft.beats.find(b=>b.id===edit.id);if(!original)throw Error('Nhịp đã thay đổi.');
  const previous=structuredClone(original);if(previous.clipPlan)previous.seconds=previous.clipPlan.seconds;
  const next={...structuredClone(original),...structuredClone(edit.patch)};
  if(!Number.isFinite(next.seconds)||next.seconds<.2||next.seconds>120)throw Error('Thời lượng mỗi nhịp từ 0,2 đến 120 giây.');
  if(['angle','movement','visualPrompt','motionPrompt','partPrompts'].some(k=>Object.hasOwn(edit.patch,k)&&JSON.stringify(edit.patch[k])!==JSON.stringify(previous[k])))next.manualDirections=true;
  const retimed=next.seconds!==previous.seconds;
  if(next.angle!==previous.angle||next.visualPrompt!==previous.visualPrompt)delete next.approvedFrame;
  if(retimed){
   next.clipPlanning={...next.clipPlanning,actionCuts:(next.clipPlanning?.actionCuts||[]).filter(t=>t>0&&t<next.seconds)};
   next.clipPlan={seconds:next.seconds,parts:photoPlanParts(next)};
   const hadOverrides=Object.keys(previous.partText||{}).length>0;
   const speech=edit.patch.text!==undefined&&edit.patch.text!==previous.text?next.text:hadOverrides?photoParts(previous).map(p=>photoPartText(previous,p)).join(' '):next.text;
   next.partText=hadOverrides||speech!==next.text?Object.fromEntries(SFClipPlanning.assignText(speech,next.seconds,next.clipPlan.parts).map(p=>[p.id,p.text])):{};
   next.partPrompts=Object.fromEntries(Object.entries(next.partPrompts||{}).filter(([id])=>next.clipPlan.parts.some(p=>p.id===id)));
   delete next.chosenClip;next.chosenParts={};
  }else if(edit.patch.text!==undefined&&edit.patch.text!==previous.text)next.partText={};
  const slots=photoParts(next).map(p=>{
   const oldPart=photoParts(previous).find(old=>old.id===p.id),existing=photoLatest(next,p.id);
   if(oldPart&&photoSceneSignature(previous,oldPart)===photoSceneSignature(next,p)&&photoDraftReady(next,p,existing))return{p,keep:existing};
   const c=oldPart&&photoLatest(previous,p.id);
   const reusable=draft.voice.mode!=='native'&&!next.clipPlanning?.continuity&&oldPart&&photoDraftReady(previous,oldPart,c)&&!c.sourceIn&&c.duration+.025>=(p.generationDuration||p.duration)&&photoVisualIntent(previous,oldPart)===photoVisualIntent(next,p);
   return{p,reuse:reusable?c:null};
  });result.push({original,previous,next,slots,retimed});
 }
 return result;
}
async function photoApplyBeatEdits(edits,{voice=null,automatic=false,label='Áp dụng thay đổi'}={}){
 photoAssertEditable(edits.map(e=>draft.beats.find(b=>b.id===e.id)).filter(Boolean));
 const id=room.id,signature=JSON.stringify(draft),wasCurrent=photoPromptsCurrent(),proposal=photoEditProposal(edits);
 const counts={keep:0,reuse:0,generate:0};for(const row of proposal)for(const s of row.slots)counts[s.keep?'keep':s.reuse?'reuse':'generate']++;
 const commit=async()=>{
  if(id!==room.id||signature!==JSON.stringify(draft))throw Error('Dự án đã đổi; rà lại thay đổi.');
  photoAssertEditable(proposal.map(r=>r.original));photoEditBusy=true;photoMediaBusy++;
  const before=structuredClone(draft),attempt=proposal.map(row=>({...row,next:structuredClone(row.next)}));
  try{
   for(const row of attempt){for(const s of row.slots)if(s.reuse){
    const file=await bridge.getFile(s.reuse.key);if(!file)throw Error('Thiếu clip cần tận dụng; chưa thay đổi dự án.');
    const info=await photoReadClip(file,s.p.generationDuration||s.p.duration),order=photoNextOrder(row.original,s.p.id);
    const copy={...structuredClone(s.reuse),...info,id:uid(),version:order,generationOrder:order,part:s.p.id,slotStart:s.p.start,slotEnd:s.p.end,generationDuration:s.p.generationDuration||s.p.duration,signature:photoSceneSignature(row.next,s.p),reviewDecision:{status:'pending'},origin:'local-reuse',reusedFrom:s.reuse.id,sourceRequestId:s.reuse.requestId||s.reuse.sourceRequestId||null,sourceSignature:s.reuse.signature,sourcePrompt:s.reuse.prompt||null,reuseReason:'retime-muted-video',createdAt:Date.now()};delete copy.requestId;
    row.next.clips??=[];row.next.clips.push(copy);
   }}
   if(id!==room.id||signature!==JSON.stringify(draft))throw Error('Dự án đã đổi; chưa áp dụng.');
   for(const row of attempt){const index=draft.beats.findIndex(b=>b.id===row.original.id);draft.beats[index]=row.next;}
   if(voice)draft.voice=structuredClone(voice);draft.plan=[];draft.missing=[];
   photoRememberManualEdit(wasCurrent,{kind:'beat-edit',beats:edits.map(e=>e.id),...counts});photoUpdateDraft();await save();
   $('#photoDialog').close();render();toast('Đã cập nhật mốc. '+counts.reuse+' clip tận dụng, '+counts.generate+' phần chưa có clip phù hợp; chưa gửi tạo mới.');
  }catch(e){if(id===room.id){draft=before;try{await save();}catch{}}throw e;}finally{photoMediaBusy--;photoEditBusy=false;}
 };
 const needsReview=photoHasProductionWork()&&!automatic;
 if(!needsReview){await commit();return;}
 modal('Rà thay đổi · không tự gen lại','<p>'+counts.keep+' clip giữ nguyên · '+counts.reuse+' clip tận dụng hình đang có · <b>'+counts.generate+' phần cần clip phù hợp</b>.</p>'+proposal.map(r=>'<p>'+esc(r.next.name)+': '+r.previous.seconds.toFixed(1)+' → '+r.next.seconds.toFixed(1)+' giây · '+r.slots.length+' phần.</p>').join('')+'<p>Giữ toàn bộ tệp và phiên bản cũ. Clip có tiếng nói chỉ được dùng lại khi lời và mốc vẫn khớp; clip tắt tiếng có thể cắt từ tệp hiện có nếu đủ dài. Các phần cần tạo mới chỉ được gửi khi bạn bấm tạo và xác nhận riêng.</p><p>Phụ đề đã sửa tay cần rà lại nếu mốc/lời thay đổi.</p><p id="photoEditError" role="status"></p>','<button id="photoConfirmEdit" class="primary">'+esc(label)+'</button>');
 $('#photoConfirmEdit').onclick=async()=>{const button=$('#photoConfirmEdit');button.disabled=true;try{await commit();}catch(e){if($('#photoEditError'))$('#photoEditError').textContent=e.message;toast(e.message);button.disabled=false;}};
}
function photoAlignedDurations(voice,beats){
 const total=voice.duration,n=beats.length;if(!Number.isFinite(total)||!n||total<n*.2)throw Error('Giọng quá ngắn hoặc chưa có thời lượng hợp lệ.');
 const weights=beats.map(b=>Math.max(1,b.text.trim().length||b.seconds)),sum=weights.reduce((a,b)=>a+b),bounds=[0];let cumulative=0;
 for(let i=0;i<n-1;i++){cumulative+=weights[i];const ideal=total*cumulative/sum,min=bounds.at(-1)+.2,max=total-(n-i-1)*.2,pauses=(voice.pauses||[]).filter(p=>p>=min&&p<=max),nearest=pauses.sort((a,b)=>Math.abs(a-ideal)-Math.abs(b-ideal))[0];bounds.push(Math.max(min,Math.min(max,nearest??ideal)));}bounds.push(total);
 return beats.map((b,i)=>Number((bounds[i+1]-bounds[i]).toFixed(4)));
}
function photoVoiceTimingMatches(voice,beats){return Array.isArray(voice.beatTimings)&&voice.beatTimings.length===beats.length&&voice.beatTimings.every((s,i)=>s.id===beats[i].id&&s.text===beats[i].text&&Number.isFinite(s.start)&&Number.isFinite(s.end)&&s.end>s.start);}
async function photoAlignVoice(){const exact=photoVoiceTimingMatches(draft.voice,draft.beats),durations=exact?draft.voice.beatTimings.map(s=>s.end-s.start):photoAlignedDurations(draft.voice,draft.beats);return photoApplyBeatEdits(draft.beats.map((b,i)=>({id:b.id,patch:{seconds:durations[i]}})),{voice:{...draft.voice,alignment:exact?'Mốc từng nhịp do TTS tạo':draft.voice.pauses?.length?'Theo khoảng lặng; cần nghe rà':'Ước lượng theo lời; cần nghe rà'},label:'Cập nhật nhịp theo giọng'});}
async function photoSetVoiceMode(mode,voice=null){
 if(!['native','none','ai','file'].includes(mode))throw Error('Chế độ giọng không hợp lệ.');photoAssertEditable();
 const id=room.id,before=structuredClone(draft),signature=JSON.stringify(draft),wasCurrent=photoPromptsCurrent(),oldMode=draft.voice.mode,previousCue=photoCueSignature(),cuesCurrent=draft.post?.cueSignature===previousCue;
 const sources=oldMode==='native'&&mode!=='native'?draft.beats.flatMap(b=>photoParts(b).map(p=>({b,p,c:photoLatest(b,p.id)})).filter(s=>photoDraftReady(s.b,s.p,s.c))):[];
 photoEditBusy=true;
 try{
  for(const s of sources)if(!await bridge.getFile(s.c.key))throw Error('Thiếu clip hình; chưa đổi chế độ giọng.');
  if(id!==room.id||signature!==JSON.stringify(draft))throw Error('Dự án đã đổi; chọn lại chế độ giọng.');
  draft.voice=voice?structuredClone(voice):{...draft.voice,mode};
  for(const {b,p,c}of sources){const order=photoNextOrder(b,p.id),copy={...structuredClone(c),id:uid(),version:order,generationOrder:order,signature:photoSceneSignature(b,p),reviewDecision:{status:'pending'},origin:'local-reuse',reusedFrom:c.id,sourceRequestId:c.requestId||c.sourceRequestId||null,sourceSignature:c.signature,reuseReason:'mute-native-audio'};delete copy.requestId;b.clips.push(copy);}
  if(oldMode!=='native'&&mode!=='native'&&cuesCurrent)draft.post.cueSignature=photoCueSignature();
  photoRememberManualEdit(wasCurrent,{kind:'voice',from:oldMode,to:mode});draft.plan=[];pause();await save();render();
 }catch(e){if(id===room.id){draft=before;try{await save();}catch{}}throw e;}finally{photoEditBusy=false;}
}

async function photoInstallVoice(voice,segments=null){
 const hasPlan=draft.beats.some(b=>b.clipPlan||b.clips?.length)||draft.flowJobs?.length;
 const valid=voice.mode==='ai'&&Array.isArray(segments)&&segments.length===draft.beats.length&&segments.every(s=>Number.isFinite(s.start)&&Number.isFinite(s.end)&&s.end>s.start);
 voice={...voice,beatTimings:valid?segments.map((s,i)=>({id:draft.beats[i].id,text:draft.beats[i].text,start:s.start,end:s.end})):null,alignment:hasPlan?'Giữ nhịp hiện tại; có thể canh lại theo giọng':valid?'Mốc từng nhịp do TTS tạo':'Ước lượng theo lời/khoảng lặng; cần nghe rà'};
 if(hasPlan){await photoSetVoiceMode(voice.mode,voice);toast('Đã thay giọng; giữ mốc và clip hình. Muốn canh lại, bấm Canh nhịp theo giọng và rà thay đổi.');return;}
 const durations=valid?segments.map(s=>s.end-s.start):photoAlignedDurations(voice,draft.beats);
 return photoApplyBeatEdits(draft.beats.map((b,i)=>({id:b.id,patch:{seconds:durations[i]}})),{voice,automatic:true});
}
async function photoCommitRefs(nextRefs){
 const changed=[...new Set([...Object.keys(draft.refs||{}),...Object.keys(nextRefs||{})])].filter(k=>JSON.stringify(draft.refs[k])!==JSON.stringify(nextRefs[k]));
 if(!changed.length)return;
 const affected=draft.beats.filter(b=>changed.some(k=>!Array.isArray(b.refRoles)||b.refRoles.includes(k)));photoAssertEditable(affected);
 const wasCurrent=photoPromptsCurrent(),before=structuredClone(draft);photoEditBusy=true;try{draft.refs=structuredClone(nextRefs);for(const b of affected)delete b.approvedFrame;
 if(affected.length){draft.plan=[];draft.missing=[];}photoRememberManualEdit(wasCurrent,{kind:'references',roles:changed,beats:affected.map(b=>b.id)});await save();render();}catch(e){draft=before;try{await save();}catch{}throw e;}finally{photoEditBusy=false;}
 toast(affected.length?'Đã đổi ảnh cho '+affected.length+' cảnh liên quan; giữ clip cũ để rà/tạo lại.':'Đã thêm/đổi ảnh; các cảnh không dùng ảnh này được giữ nguyên.');
}
function photoReferenceUsage(){return draft.beats.flatMap((b,i)=>{const count=photoRefsFor(b).reduce((n,r)=>n+r.images.length,0)+(b.approvedFrame||b.clipPlanning?.continuity&&photoParts(b).length>1?1:0);return count>8?['Cảnh '+(i+1)+': '+count+'/8 ảnh — cần chọn bớt trước khi tạo.']:[];}).map(s=>'<p class="warning">'+esc(s)+'</p>').join('');}
async function photoApplyFormula(id){const recipe=libraryRecipes.find(r=>r.id===id),formula=recipe?recipeToFormula(recipe):formulas.find(f=>f.id===id);if(!formula)throw Error('Không tìm thấy công thức.');return photoChooseFormula(formula,recipe);}
async function photoChooseFormula(formula,recipe=null){
 photoAssertEditable();
 const beats=createBeats(formula);
 if(recipe)beats.forEach((b,i)=>Object.assign(b,{purpose:recipe.beats[i].purpose,text:recipe.scriptBody?.[i]?.text??recipe.beats[i].example??'',angle:recipe.beats[i].angle||'',movement:recipe.beats[i].movement||'',onScreen:recipe.beats[i].onScreen||''}));
 const fresh={...newDraft(),refs:structuredClone(draft.refs),idea:draft.idea,providers:structuredClone(photoTools()),formula:formula.id,formulaChosen:true,recipeSnapshot:recipe?SFRecipes.strip(recipe):undefined,beats,scriptMode:recipe?'manual':'ai'};
 if(!photoHasProductionWork()){
  if(draft.beats.some(b=>b.text.trim())&&!confirm('Thay lời/nhịp hiện tại bằng công thức này?'))return;
  if(recipe)await bridge.useRecipe(recipe.id,room.id);draft=fresh;await save();await loadRecipeSource();$('#photoDialog').close();render();return;
 }
 return photoOfferDraftFork(fresh,formula.name);
}
async function photoOfferDraftFork(fresh,title){
 const sourceId=room.id,signature=JSON.stringify(draft),newId=uid();
 modal('Dùng công thức trong dự án mới','<p>Dự án hiện tại đã có tư liệu hoặc lượt xử lý. Tạo dự án mới theo <b>'+esc(title)+'</b>, chép ảnh đầu vào và ý chính.</p><p>Dự án hiện tại giữ nguyên kịch bản, clip, giọng, timeline và lịch sử. Dự án mới chưa có clip/lượt gửi; không tự gọi AI.</p><label>Tên dự án mới<input id="photoForkName" maxlength="160" value="'+esc(room.name+' · '+title)+'"></label><p id="photoForkError" role="status"></p>','<button id="photoConfirmFork" class="primary">Tạo & mở dự án mới</button>');
 $('#photoConfirmFork').onclick=async()=>{const button=$('#photoConfirmFork');button.disabled=true;
  try{if(sourceId!==room.id||signature!==JSON.stringify(draft))throw Error('Dự án đã đổi; chọn lại công thức.');photoAssertEditable();photoEditBusy=true;await save();const result=await bridge.forkDraft({id:newId,sourceId,name:$('#photoForkName').value.trim(),draft:fresh});photoEditBusy=false;$('#photoDialog').close();await parent.SceneForgeApp.openRoom(result.id,'analysis');}
  catch(e){photoEditBusy=false;if($('#photoForkError'))$('#photoForkError').textContent=e.message;toast(e.message);button.disabled=false;}
 };
}

async function photoChooseScriptVariant(index){
 const variant=draft.scriptVariants?.[index];if(!variant)return;photoAssertEditable();
 if(photoHasProductionWork()){
  const fresh={...newDraft(),refs:structuredClone(draft.refs),idea:draft.idea,providers:structuredClone(photoTools()),formula:variant.formula,formulaChosen:true,recipeSnapshot:structuredClone(variant.recipeSnapshot),scriptMode:'manual',beats:variant.beats.map((b,i)=>({id:uid(),name:b.name||'Nhịp '+(i+1),type:b.type,seconds:b.seconds,text:b.text,angle:b.angle||'',movement:b.movement||'',onScreen:b.onScreen||'',purpose:b.purpose||''}))};
  return photoOfferDraftFork(fresh,variant.hook||'Phương án kịch bản');
 }
 if(!draft.variantPending&&draft.beats.some(b=>b.text.trim())&&!confirm('Dùng phương án khác sẽ thay lời đang chỉnh. Tiếp tục?'))return;
 draft.beats=structuredClone(variant.beats);draft.formula=variant.formula;draft.recipeSnapshot=structuredClone(variant.recipeSnapshot);draft.formulaChosen=true;draft.chosenVariant=index;draft.variantPending=false;draft.scriptMode='ai';draft.plan=[];draft.missing=[];if(libraryRecipes.some(r=>r.id===draft.formula))await bridge.useRecipe(draft.formula,room.id);await save();await loadRecipeSource();render();
}
