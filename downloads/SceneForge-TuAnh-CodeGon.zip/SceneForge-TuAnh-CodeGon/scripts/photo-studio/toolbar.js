// Compact task toolbar. Configuration and recovery remain explicit; no auto-generation.
const photoToolbar={busy:false,status:new Map(),reading:false,sequence:0};
const photoToolbarPending=new Set(['prepared','preparing','submitted','queued','running','downloading','unknown','missing','done']);
function photoToolbarJobs(){return [...(draft.geminiJobs||[]).map(j=>({...j,service:'gemini-chat'})),...(draft.flowJobs||[]).map(j=>({...j,service:j.provider||'flow'}))];}
function photoToolbarCounts(){const slots=draft.beats.flatMap(b=>photoParts(b).map(p=>({b,p,c:photoLatest(b,p.id)})));return {total:slots.length,approved:slots.filter(({b,p,c})=>photoClipValid(b,p,c)).length,review:slots.filter(({b,p,c})=>c&&!photoClipValid(b,p,c)&&!photoSlotJob(b,p)).length};}
function photoToolbarStep(){
 const jobs=photoToolbarJobs().filter(j=>photoToolbarPending.has(j.state));
 const counts=photoToolbarCounts();
 if(draft.variantPending)return {key:'variant',label:'Chọn bản kịch bản'};
 if(jobs.length)return {key:jobs.some(j=>j.state==='done')?'receive':'progress',label:jobs.some(j=>j.state==='done')?'Nhận kết quả':'Xem tiến độ'};
 if(counts.total&&counts.approved===counts.total)return {key:'editor',label:'Mở trong Dựng'};
 if(counts.review)return {key:'review',label:'Rà & duyệt clip'};
 if(!Object.values(draft.refs||{}).some(r=>r.images?.length))return {key:'refs',label:'Thêm ảnh đầu vào'};
 if(!draft.beats.length||!draft.idea?.trim()&&draft.beats.every(b=>!b.text?.trim()&&!b.visualPrompt?.trim()))return {key:'script',label:'Chuẩn bị kịch bản'};
 const prompts=draft.beats.every(b=>b.visualPrompt?.trim()&&b.motionPrompt?.trim());
 if(!prompts&&!photoOverall())return {key:'storyboard',label:photoTools().creative==='gemini'?'Tạo storyboard':'Chuẩn bị storyboard'};
 if(!prompts)return {key:'prompts',label:'Viết prompt video'};
 return {key:'clips',label:'Tạo clip còn thiếu'};
}
function photoToolbarConnection(service){const row=photoToolbar.status.get(service);if(!row)return null;if(row.error)return false;const s=row.value;return !!(s?.configured&&s.selection?.available&&(service!=='flow'||s.account_binding));}
function photoToolbarDisplayStep(){const step=photoToolbarStep(),service=['storyboard','prompts'].includes(step.key)&&photoTools().creative==='gemini'?'gemini-chat':step.key==='clips'?photoTools().video:null;if(service&&photoToolbarConnection(service)===false)return {key:'connect',service,label:service==='gemini-chat'?'Kết nối Gemini':service==='muse'?'Kết nối Muse':'Kết nối Flow'};return step;}
function photoToolbarFocus(id){const n=$('[data-node="'+id+'"]'),box=$('#photoViewport');if(!n)return;view.x=24-n.offsetLeft*view.z;view.y=24-n.offsetTop*view.z;applyView();selectNode(n);}
async function photoToolbarConnect(service){if(service==='gemini-chat')return photoGchatAccounts();return service==='muse'?photoMuseDialog():photoFlowDialog();}
function photoToolbarMount(){
 if(providerBar.dataset.compact==='true')return;
 document.body.classList.add('photoSimpleToolbar');providerBar.dataset.compact='true';providerBar.setAttribute('aria-label','Các bước tạo video từ ảnh');
 providerBar.innerHTML='<div class="photoSourceGroup"><label for="photoCreativeSource"><span>Ảnh / ý tưởng</span><select id="photoCreativeSource" aria-label="Nguồn ảnh và ý tưởng"><option value="gemini">Gemini Chat</option><option value="muse">Muse · thủ công</option></select></label><button type="button" class="photoConnectHint" id="photoCreativeConnect" aria-label="Kết nối Gemini" title="Kết nối Gemini">!</button></div><div class="photoSourceGroup"><label for="photoVideoSource"><span>Video</span><select id="photoVideoSource" aria-label="Nguồn tạo video"><option value="flow">Flow</option><option value="muse">Muse · muse.ai</option></select></label><button type="button" class="photoConnectHint" id="photoVideoConnect" aria-label="Kết nối video" title="Kết nối video">!</button></div><div class="photoToolbarActions"><button type="button" id="photoProgress" aria-haspopup="dialog"><i aria-hidden="true"></i><span>Tiến độ</span></button><button type="button" id="photoNext" class="primary">Bước tiếp theo</button><details id="photoMore"><summary aria-label="Tùy chọn tạo video" title="Tùy chọn">⋯</summary><div class="photoMoreMenu"><small>SẢN XUẤT</small><button type="button" data-photo-option="storyboard">Storyboard tổng</button><button type="button" data-photo-option="prompts">Viết / sửa prompt video</button><button type="button" data-photo-option="planning">Chia clip</button><button type="button" data-photo-option="clips">Tạo clip còn thiếu</button><small>TÀI KHOẢN</small><button type="button" data-photo-option="gemini">Tài khoản Gemini</button><button type="button" data-photo-option="video">Kết nối nguồn video</button><small>THEO DÕI</small><button type="button" data-photo-option="progress">Tiến độ & kết quả</button><button type="button" data-photo-option="history">Chi tiết các lượt đã gửi</button></div></details></div>';
 $('#photoNext').onclick=()=>photoToolbarRun(()=>photoToolbarNext());$('#photoProgress').onclick=photoToolbarProgress;
 for(const [id,key]of [['photoCreativeSource','creative'],['photoVideoSource','video']])$('#'+id).onchange=async e=>{const previous=photoTools()[key];photoTools()[key]=e.target.value;try{await save();photoToolbarPaint();await photoToolbarRefresh(true);}catch(error){photoTools()[key]=previous;photoToolbarPaint();toast(error.message);}};
 $('#photoCreativeConnect').onclick=()=>photoToolbarRun(()=>photoToolbarConnect('gemini-chat'));$('#photoVideoConnect').onclick=()=>photoToolbarRun(()=>photoToolbarConnect(photoTools().video));
 for(const button of $$('[data-photo-option]'))button.onclick=()=>{const key=button.dataset.photoOption;$('#photoMore').open=false;photoToolbarRun(async()=>{if(key==='storyboard')return photoOverallDialog();if(key==='prompts')return photoToolbarWritePrompts();if(key==='planning')return photoPlanningDialog();if(key==='clips')return photoRunClips();if(key==='gemini')return photoGchatAccounts();if(key==='video')return photoToolbarConnect(photoTools().video);if(key==='history')return photoSentJobs();return photoToolbarProgress();});};
}
function photoToolbarPaint(){
 if(!loaded)return;photoToolbarMount();const tools=photoTools(),counts=photoToolbarCounts(),jobs=photoToolbarJobs().filter(j=>photoToolbarPending.has(j.state)),attention=jobs.some(j=>['unknown','missing'].includes(j.state)),step=photoToolbarDisplayStep();
 $('#photoCreativeSource').value=tools.creative;$('#photoVideoSource').value=tools.video;$('#photoNext').textContent=step.label;$('#photoNext').dataset.step=step.key;$('#photoNext').disabled=photoToolbar.busy;
 const progress=$('#photoProgress');progress.querySelector('span').textContent=attention?'Cần kiểm tra':jobs.length?jobs.length+' việc đang chờ':counts.approved+'/'+counts.total+' clip đã duyệt';progress.dataset.state=attention?'attention':jobs.length?'working':counts.total&&counts.total===counts.approved?'done':'idle';progress.title='Tiến độ và kết quả · bấm để xem';
 for(const [id,service]of [['photoCreativeConnect',tools.creative==='gemini'?'gemini-chat':null],['photoVideoConnect',tools.video]]){const b=$('#'+id),bad=service&&photoToolbarConnection(service)===false;b.style.visibility=bad?'visible':'hidden';b.disabled=!bad;b.tabIndex=bad?0:-1;b.setAttribute('aria-hidden',bad?'false':'true');b.setAttribute('aria-label','Kết nối '+(service==='gemini-chat'?'Gemini':service==='muse'?'Muse':'Flow'));b.title=photoToolbar.status.get(service)?.error?'Chưa đọc được kết nối. Bấm để kiểm tra.':b.getAttribute('aria-label');}
}
async function photoToolbarRefresh(force=false){
 if(!loaded)return;if(photoToolbar.reading){if(force)photoToolbar.refreshAgain=true;return;}const services=[...(photoTools().creative==='gemini'?['gemini-chat']:[]),photoTools().video],needed=[...new Set(services)].filter(s=>force||Date.now()-(photoToolbar.status.get(s)?.at||0)>30000);if(!needed.length)return;
 const id=room.id,seq=++photoToolbar.sequence;photoToolbar.reading=true;
 try{const results=await Promise.allSettled(needed.map(service=>bridge.engine(service+'/status')));if(room.id!==id||seq!==photoToolbar.sequence)return;results.forEach((r,i)=>photoToolbar.status.set(needed[i],{at:Date.now(),...(r.status==='fulfilled'?{value:r.value}:{error:String(r.reason?.message||r.reason)})}));photoToolbarPaint();}finally{photoToolbar.reading=false;if(photoToolbar.refreshAgain){photoToolbar.refreshAgain=false;void photoToolbarRefresh(true);}}
}
async function photoToolbarRun(action){
 if(photoToolbar.busy||photoMediaBusy||photoApprovalBusy||pendingActions.size||typeof photoEditBusy!=='undefined'&&photoEditBusy)return toast('Đợi thao tác hiện tại hoàn tất.');photoToolbar.busy=true;photoToolbarPaint();
 try{await action();}catch(error){toast(error.message);}finally{photoToolbar.busy=false;photoToolbarPaint();}
}
async function photoToolbarWritePrompts(){if(photoTools().creative==='gemini')return photoGchatSubmit('text',photoChatPack(),'writing');return actions['photo-story-chat']();}
async function photoToolbarNext(){
 const step=photoToolbarDisplayStep();
 if(step.key==='connect')return photoToolbarConnect(step.service);
 if(step.key==='progress')return photoToolbarProgress();if(step.key==='receive')return photoToolbarReceive();
 if(step.key==='refs'){photoToolbarFocus('refs');selectedRef='product';return $('#photoRefFile').click();}
 if(step.key==='script'){photoToolbarFocus('script');return actions['edit-brief']();}
 if(step.key==='variant'){photoToolbarFocus('script');return;}
 if(step.key==='review'){photoToolbarFocus('frames');return;}
 if(step.key==='storyboard'){if(photoTools().creative==='gemini')return photoGchatSubmit('image',photoOverallImagePrompt(),'image');return photoOverallDialog();}
 if(step.key==='prompts')return photoToolbarWritePrompts();if(step.key==='clips')return photoRunClips();
 if(step.key==='editor'){const result=assemble(draft.variant);if(result.missing.length)throw Error('Rà và duyệt các clip còn thiếu trước khi sang Dựng.');await save();return actions['open-editor']();}
}
function photoToolbarProgress(){
 const counts=photoToolbarCounts(),jobs=photoToolbarJobs(),prompts=draft.beats.length&&draft.beats.every(b=>b.visualPrompt?.trim()&&b.motionPrompt?.trim()),labels={prepared:'Đang kiểm tra lượt đã chuẩn bị',preparing:'Đang chuẩn bị',queued:'Đang chờ',submitted:'Đã gửi',running:'Đang xử lý',downloading:'Đang tải kết quả',unknown:'Chưa rõ kết quả · cần kiểm tra',missing:'Chưa tìm thấy · cần đối soát',done:'Có kết quả để nhận',invalid:'JSON cần sửa · không tự gửi lại',imported:'Đã nhận',failed:'Lượt tạo thất bại',not_submitted:'Chưa gửi',abandoned:'Đã bỏ theo dõi',discarded:'Đã bỏ kết quả'};
 modal('Tiến độ & kết quả','<div class="photoProgressSteps"><div><span>01</span><b>Storyboard</b><small>'+esc(photoOverall()?'Đã có ảnh tổng':'Chưa có ảnh tổng')+'</small></div><div><span>02</span><b>Prompt video</b><small>'+(prompts?'Đã có chỉ dẫn clip':'Chưa viết đủ')+'</small></div><div><span>03</span><b>Clip</b><small>'+counts.approved+'/'+counts.total+' đã duyệt</small></div></div><p>Kết quả mới cần rà trước khi duyệt. Lượt chưa rõ sẽ được đối soát, không tự gửi lại.</p><div class="photoProgressJobs">'+(jobs.length?jobs.slice().reverse().map(j=>'<details><summary><b>'+esc(j.origin==='local-preserved'?'Giữ chỉ dẫn · không gọi AI':j.service==='gemini-chat'?(j.kind==='image'?'Ảnh storyboard':'Viết prompt'):'Clip '+(j.part||'a')+' · '+(j.service==='muse'?'Muse':'Flow'))+'</b><span>'+esc(j.stale?'Kết quả lỗi thời · đã giữ riêng':labels[j.state]||j.state)+'</span></summary><small>Mã lượt: '+esc(j.id)+'</small>'+(j.error?'<p>'+esc(j.error)+'</p>':'')+'</details>').join(''):'<p>Chưa gửi yêu cầu. Dùng nút bước tiếp theo trên thanh công cụ.</p>')+'</div>','<button id="photoProgressHistory">Chi tiết lượt gửi</button><button id="photoProgressClips">Mở node clip</button><button id="photoProgressReceive" class="primary">Kiểm tra kết quả</button>');
 $('#photoProgressHistory').onclick=()=>photoSentJobs();$('#photoProgressClips').onclick=()=>{$('#photoDialog').close();photoToolbarFocus('frames');};$('#photoProgressReceive').onclick=()=>photoToolbarRun(()=>photoToolbarReceive());
}
async function photoToolbarReceive(){
 // Read/reconcile existing receipts only. These methods never create a new AI job.
 if((draft.flowJobs||[]).some(j=>photoToolbarPending.has(j.state)))await photoRecoverFlows();
 if((draft.geminiJobs||[]).some(j=>photoToolbarPending.has(j.state))){await photoRecoverChat();if($('#photoApplyChat'))return;}
 photoToolbarProgress();
}
photoRenderProviders=function(){photoToolbarPaint();void photoToolbarRefresh();};
window.addEventListener('focus',()=>{if(loaded)void photoToolbarRefresh(true);});
document.addEventListener('pointerdown',e=>{const menu=$('#photoMore');if(menu?.open&&!menu.contains(e.target))menu.open=false;});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#photoMore')?.open){$('#photoMore').open=false;$('#photoMore summary').focus();}});
let photoToolbarPaintQueued=false;document.addEventListener('input',()=>{if(!loaded||photoToolbarPaintQueued)return;photoToolbarPaintQueued=true;requestAnimationFrame(()=>{photoToolbarPaintQueued=false;photoToolbarPaint();});});

$('#photoDialog').addEventListener('close',()=>{if(loaded)void photoToolbarRefresh(true);});
