# Nhờ kiểm độc lập code này

Mục tiêu của tôi: ít thao tác, luồng có giá trị thực tế, không phát sinh gen lại
hoặc mất dữ liệu vì các node không nối nhau. Xin đọc code, đừng chỉ dựa mô tả.

1. Storyboard tổng có thật được gửi cùng ảnh gốc + script tới Gemini không?
   Prompt trả về có đủ từng beat/part, được gắn đúng cảnh và giữ lời/thời lượng?
2. Nhóm 8+1, JSON thiếu/sai, một nhóm lỗi, đổi storyboard/script lúc chờ:
   có áp một phần sai, báo đã xong giả hoặc chặn vĩnh viễn không?
3. Mọi đường gửi có lấy đúng tài khoản/model từ Cài đặt, kiểm token, lưu ý định
   trước POST? Restart/timeout có thể tự gửi lại hoặc ghim sai kết quả không?
4. Tạo lại một ô nhiều lần có hiển thị đúng ứng viên mới nhất? Thao tác sửa riêng
   có làm hỏng prompt/cảnh khác hoặc gửi lại các clip đã nhận không?
5. Bộ cảnh có thực sự là clip của dự án theo storyboard? Còn đường UI nào bắt
   duyệt từng ô hoặc dùng nhầm thư viện cảnh chung để ghép hay không?
6. Bản xem thử có phát đúng thứ tự, âm thanh/phụ đề/đuôi tĩnh và khoảng trống?
   Có bị giới thiệu nhầm là MP4 xuất, hoặc khác bản sẽ nhập Dựng không?
7. Chốt toàn bộ có kiểm đủ mọi file/slot, lời/phụ đề, giọng/nhạc, busy state và
   chính xác snapshot vừa xem trước khi dọn? Có thể chỉ duyệt được một phần,
   dọn xong rồi mới phát hiện lỗi, hoặc phục hồi ACK làm sống lại bản cũ không?
8. Bản bị bỏ có dọn đúng phạm vi; clip đang ở timeline, dùng chung, ghim, các
   cảnh/dự án khác có được bảo vệ? Có giữ sót media làm ổ phình bất ngờ không?
9. Gemini/Flow/Muse có giới hạn và chỗ chưa nối nào cần nói rõ? Phân biệt Muse
   muse.ai với Meta AI; chỉ ra việc chưa có bằng chứng tài khoản thật.
10. Tests có kiểm ý nghĩa của hành vi hay chỉ bám implementation? Có lỗ hổng
    nào các fixture chưa chứng minh được, đặc biệt dịch vụ thật/Windows?

Trả kết quả: lỗi theo mức ảnh hưởng, file + hàm + dòng, cách tái hiện hoặc chứng
cứ suy luận, và sửa nhỏ nhất. Phân biệt lỗi đã tái hiện / rủi ro / giới hạn chủ ý.
Không cần dựng UI mới. Nếu thiếu dependency do gói rút gọn, nêu đúng file cần thêm.
