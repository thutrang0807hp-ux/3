# Lần này sửa gì

So sánh code xuất bản trước `3850bec` với code sau `0bff642`.
THAY_DOI.patch được kiểm bằng git apply trên chính gói trước, sau đó so từng file
với gói sau. SOURCE_PROVENANCE.json ghi hash gốc; không dựng lại một ví dụ thay code.

| Thay đổi hành vi | Trước | Sau |
|---|---|---|
| Storyboard | Có ảnh tổng, nhập/rà prompt còn tách thao tác | Chốt một ảnh tổng; Gemini đọc cùng ảnh gốc và script, viết nhóm tối đa 8 nhịp; kiểm kết quả rồi tự áp |
| Nơi xem clip | Bộ cảnh dùng chung và node clip dự án tách biệt | Một Bộ cảnh video theo storyboard; thư viện sản phẩm vẫn giữ riêng |
| Duyệt | Chưa duyệt từng clip thì chưa ghép | Clip đủ điều kiện vào bản ghép xem thử; chốt cả bản cuối |
| Nhận kết quả | Chủ yếu bấm kiểm tra | Kiểm các lượt đã gửi mỗi 12 giây khi app hiện và không mở hộp thoại; không tự gửi lại |
| Tạo lại | Có nguy cơ gửi lại clip đã nhận nhưng chưa duyệt | Bỏ qua ứng viên đã nhận đủ điều kiện; tạo lại đúng ô theo yêu cầu |
| Sửa một đoạn | Có thể kéo theo viết lại cả script | Sửa lời/chuyển động ngay trong ô, xác nhận gửi lại đúng đoạn |
| Phiên bản cũ | Thao tác duyệt từng ô có thể dọn ngay | Mặc định giữ tới khi chốt cả bản ghép; dùng giao dịch dọn đang có |
| Sang Dựng | Phụ thuộc các clip đã duyệt | Kiểm đủ file/mốc/âm thanh/phụ đề và đúng snapshot vừa xem, rồi chốt chung và nhập editor |
| Giọng mặc định dự án mới | AI local | Tiếng clip; giọng riêng vẫn tùy chọn, cần file trước khi chốt thời lượng |

## Hàm chịu trách nhiệm

| Việc | Điểm đọc |
|---|---|
| Chốt storyboard, tự viết prompt theo nhóm | `story-production.js:25` |
| Nhận và kiểm dữ liệu Gemini | `story-production.js:55` |
| Tự nhận kết quả, không tự gửi job mới | `story-production.js:75` |
| Bộ cảnh chứa clip theo storyboard | `story-production.js:85` |
| Storyboard tổng; thu gọn chi tiết | `story-production.js:91` |
| Nút chính đi theo bước thực tế | `story-production.js:114` |
| Chặn tạo video khi prompt chưa khớp | `story-production.js:131` |
| Sửa/tạo lại trong ô; bỏ duyệt lẻ mặc định | `story-production.js:141` |
| Kiểm file, giọng, nhạc, phụ đề và mốc | `story-production.js:148` |
| Phát toàn bộ bản ghép, giữ chỗ cảnh thiếu | `story-production.js:160` |
| Chốt đúng bản vừa xem rồi dọn và sang Dựng | `story-production.js:177` |

## Các file code thực sự khác trong phạm vi gói

| Loại | File |
|---|---|
| modified | `local_engine/check_photo_clip_flow.py` |
| added | `local_engine/check_photo_story_production.py` |
| modified | `local_engine/check_photo_toolbar.py` |
| modified | `scripts/demo-web/build.py` |
| modified | `scripts/photo-studio/clip-flow.js` |
| added | `scripts/photo-studio/story-production.css` |
| added | `scripts/photo-studio/story-production.js` |

Backend tài khoản/engine/kho/editor đi kèm là code nền để lần điểm nối.
Lần này không cài thêm repo/model hay hoàn thành kết nối Meta AI. Không tính
code nền sẵn có thành tính năng mới. Patch cho thấy thay đổi cụ thể, kể cả test.
