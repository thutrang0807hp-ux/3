# Lần này sửa gì — ba lỗi chỉnh sửa trong luồng ảnh

So sánh code đã công bố `170a49b` → `two-workflow-audit-20261026`. Diff được áp thử lên đúng gói
trước và đối chiếu byte với gói sau. Không sửa app khi đóng gói.

1. **Đổi thời lượng:** có bảng rà số clip giữ/tận dụng/cần mới, tính lại plan;
   dùng tệp hình tắt tiếng đủ dài, không tự cắt lời thoại, giữ mọi bản cũ.
   Kế hoạch bị lệch từ bản trước cũng có đường sửa. Thiếu file không áp nửa chừng.
2. **Đổi công thức:** dự án có tư liệu/lượt xử lý sẽ tạo dự án mới. Bản cũ giữ
   kịch bản, clip, giọng và timeline. Mất phản hồi rồi thử lại không nhân đôi room.
3. **Ảnh/giọng:** chỉ cảnh dùng role ảnh đã đổi bị ảnh hưởng. Giọng mới giữ nhịp
   hiện tại; canh lại là thao tác rõ ràng. Giữ mốc TTS để dùng khi script còn khớp;
   file nhập dùng ước lượng ghi rõ. File/AI cùng tắt tiếng clip, không bắt gen hình lại.

Handler cũ ở app.js, storyboard.js, production.js gọi edit-safety.js. Đây là lớp
xử lý chỉnh sửa chung, nạp sau story-production.js; không thay luồng Video mẫu.

| Việc | Điểm đọc |
|---|---|
| Rà và áp đổi thời lượng; giữ/tận dụng file | `edit-safety.js:43` |
| Giọng riêng giữ mốc; canh lại có rà tác động | `edit-safety.js:93` |
| Ảnh chỉ bỏ khung ở cảnh dùng role đã đổi | `edit-safety.js:101` |
| Công thức sang dự án mới khi đã có tư liệu | `edit-safety.js:111` |
| Phương án script cũng giữ bản gốc | `edit-safety.js:131` |

| Thay đổi code thật trong phạm vi gói | File |
|---|---|
| modified | `local_engine/gemini_chat.py` |
| modified | `scripts/photo-studio/clip-flow.js` |
| modified | `scripts/photo-studio/gemini-chat.js` |
| modified | `scripts/photo-studio/story-production.js` |
| modified | `scripts/shared/provider-receipts.js` |

Đọc `docs/photo-edit-safety.md`, `local_engine/check_photo_edit_safety.py` và
`review/PHOTO_EDIT_SAFETY_CHECKS.json`. Các báo cáo đợt storyboard cũ vẫn đi kèm
để tham khảo lịch sử; báo cáo mới ghi những check chạy lại và giới hạn kiểm chứng.
Không cài model/repo mới hay xác nhận Muse Meta/online generation trong đợt này.
