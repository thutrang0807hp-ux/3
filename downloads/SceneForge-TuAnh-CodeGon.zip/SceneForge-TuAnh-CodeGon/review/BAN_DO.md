# Bản đồ đọc code

## Thứ tự nạp frontend thật

shared/recipes.js → provider-receipts.js → clip-planning.js → image-quality.js →
photo-studio/app.js → recipes.js → storyboard.js → design-layout.js →
production.js → providers.js → gemini-chat.js → clip-flow.js → toolbar.js →
story-production.js → **edit-safety.js**.

build.py ghép các file theo thứ tự này. Hàm bị override thì định nghĩa cuối
mới là hành vi chạy; đọc riêng hàm trong app.js có thể kết luận sai.

| Điểm nối | File gốc |
|---|---|
| Phòng, bộ ảnh, photoBridge, saveDraft/engine | scripts/app-shell/package4.js; app-shell/app.js |
| Kịch bản, nhập ảnh, giọng, phụ đề, nhạc | photo-studio/app.js, recipes.js, production.js |
| Storyboard tổng, prompt tạo ảnh, ảnh gốc gửi Gemini | photo-studio/providers.js, gemini-chat.js, story-production.js |
| Lập clip theo nhịp, signature, lời và ảnh tham khảo từng phần | photo-studio/clip-flow.js; shared/clip-planning.js |
| Tài khoản/token/selection và giới hạn song song | app-shell/accounts-dashboard.js, account-dispatch.js; local_engine/account_settings.py, account_pool.py, flow_accounts.py, video_slots.py |
| Gemini Chat thực tế | local_engine/gemini_chat.py, gemini_chat_worker.py |
| Flow/Muse thực tế | local_engine/flow_provider.py, muse_provider.py, muse_worker.py |
| Prepared/unknown, chống gửi trùng và dự phòng ổ | shared/provider-receipts.js; local_engine/request_ledger.py, admission.py, storage_jobs.py |
| Chốt bản cuối rồi dọn | story-production.js → clip-flow.js/photoApproveSlots → app-shell/storage-actions.js/approveVersions → local_engine/library_api.py, storage_lifecycle.py, version_approval.py |
| Lưu/hash/files và phục hồi ACK | app-shell/library-runtime.js; local_engine/library.py, schema.py, library_lock.py |
| Nhập timeline, xuất và lưu kết quả | app-shell/app.js/transferToEditor; native-preview/workflow-import.js, timeline-export.js, ffmpeg-export.js, room-shell.js; local_engine/timeline_export.py, exports.py |
| Bằng chứng | local_engine/check_photo_story_production.py; review/PHOTO_STORY_PRODUCTION_CHECKS.json |

## Phần cố ý bỏ để gọn

- UI trang chủ đầy đủ, kho kịch bản đầy đủ, hàng loạt, phân tích video mẫu,
  CPU/OCR/Whisper/TTS implementation và các công cụ khác ngoài trọng tâm lần này.
- HTML đã build, media test, fonts, thư viện vendor, model, SDK/venv, tài khoản và
  dữ liệu phòng; các dependency cho việc khởi động app độc lập.
- Các import Python trực tiếp dưới đây được tham chiếu nhưng không đóng gói.
  Có thể mở gói đầy đủ ở link trong DOC_TRUOC.md để truy tiếp; không suy diễn rằng
  chúng thiếu ở app đầy đủ.

- `local_engine/ai_providers.py`
- `local_engine/cpu_analysis.py`
- `local_engine/frame_analysis.py`
- `local_engine/frame_quality.py`
- `local_engine/instance.py`
- `local_engine/local_translation.py`
- `local_engine/local_tts.py`
- `local_engine/local_vision.py`
- `local_engine/machine_checks.py`
- `local_engine/package5.py`
- `local_engine/policy.py`
- `local_engine/recipes.py`
- `local_engine/speech_captions.py`
- `local_engine/video_analysis.py`

Các endpoint liên quan và vị trí đăng ký nằm trong routes.json; source server.py
được giữ để đọc hợp đồng kết nối, không hứa chạy server từ riêng gói đọc code này.
