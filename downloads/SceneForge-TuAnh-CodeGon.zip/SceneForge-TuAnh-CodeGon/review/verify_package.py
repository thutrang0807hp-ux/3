from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for row in manifest['files']:
 raw=(root/row['path']).read_bytes()
 assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
print('PASS',len(manifest['files']),'files; original source hashes preserved. No app/provider calls.')
