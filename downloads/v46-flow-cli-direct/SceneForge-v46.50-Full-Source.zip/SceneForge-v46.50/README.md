# SceneForge .50 — mã nguồn nguyên trạng để kiểm tra

Đây là mã nguồn ứng dụng ghép từ Source ZIP v46 đã công bố và các payload cập
nhật v46.0 đến v46.50 đã phát hành. Mỗi tệp vá được lấy từ EXE, kiểm SHA256 rồi
áp vào nguồn nền. Danh sách EXE/phiên bản/hash nằm trong provenance/releases-applied.json.
Không lấy bản sửa mới từ working tree hoặc dữ liệu cá nhân trên máy người dùng.

## Hai tệp của riêng bản .50

- local_engine/simple_flow.py: nhánh nút tạo gọi flow_gflow_cli.generate sau chuẩn bị.
- local_engine/flow_gflow_cli.py: tìm repo trong Downloads, gọi python -m gflow_cli
  video r2v, giữ stdout/stderr, xử lý JSON và nhận video về cảnh.
- v50-patch/: nguyên manifest, apply_update.ps1 và hai tệp trích từ EXE .50.
- scripts/windows-installer/build_direct_cli_patch.py: script đóng gói .50 ở commit 8a22596.

## Lỗi đã thấy — giữ nguyên trong gói này

command() vẫn có '--duration', '8'. Báo cáo người dùng xác nhận CLI ConfigurationError
exit 11 vì tài khoản/model không có điều khiển 8s. Gói này KHÔNG bỏ tham số đó.
Gói này cũng KHÔNG tự coi lượt exit 11 là chưa gửi: mã .50 đánh dấu sent trước
khi gọi CLI nên kết quả nằm unknown. Đây là hành vi nguyên trạng để kiểm tra.

## Phạm vi

Các module worker/SDK cũ có thể vẫn còn từ bản cập nhật trước nhưng nhánh tạo .50
không gọi chúng. CLI và runtime gflow bên ngoài lấy từ bản GFlow trong Downloads;
chúng không được đóng trong EXE .50 và không thuộc source ZIP này. Không chứa
Python/Chrome/model binaries, cookie, tài khoản hoặc dữ liệu dự án người dùng.
Đây không phải ZIP toàn bộ lịch sử repository hay một EXE tự cài mới hoàn chỉnh.
