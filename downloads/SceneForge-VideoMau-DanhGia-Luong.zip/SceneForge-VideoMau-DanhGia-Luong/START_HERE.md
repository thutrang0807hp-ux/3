# Đánh giá luồng Video mẫu — chỉ đọc code

Mục đích: đánh giá code và cách nối các bước đã ổn chưa, không dựng/chạy app.

Đọc `review/DE_BAI_DANH_GIA.md` trước, sau đó `LIEN_KET_TUNG_BUOC.md` và
`KET_QUA_VA_CHO_CHUA_CHAC.md`. Truy vết theo file/hàm, phân biệt lỗi tái hiện,
rủi ro suy từ code và hạn chế có chủ ý. Không coi mô tả là bằng chứng đã hoạt động.

Luồng: chọn video/phòng → CPU tách mốc + lời/OCR/camera → Gemini hiểu cảnh/dịch
→ bộ ảnh tham khảo + prompt ảnh → tạo/duyệt ảnh → prompt video → Flow/Muse
→ nhận đúng cảnh/phiên bản → giọng/phụ đề/nhạc → Dựng → xuất/lưu/dọn.

Các file nguồn được giữ nguyên, không rút gọn/minify để che bớt logic. Workflow
có nhiều override theo thứ tự build: đọc `scripts/demo-web/build.py` để hiểu thứ tự.
Backend Python dùng chung và các đoạn shell/editor liên quan được giữ để truy vết.
Một số module dùng chung có nhánh ngoài phạm vi; chỉ rà đường Video mẫu.

Không có HTML dựng sẵn, font, ảnh/video/giọng mẫu, model, venv, tài khoản, cookie
hay dữ liệu dự án. Gói này không chạy độc lập. Đường dẫn tới tài nguyên/file UI
khác có thể không tồn tại do được loại chủ đích; không kết luận đó là lỗi của app.
Các bài test kèm chỉ để đọc cách kiểm; có bài cần tài nguyên nằm ngoài bản gọn.

Các báo cáo là kết quả chạy trước trên gói đầy đủ, không phải kiểm chạy bản gọn.
Chưa xác minh Windows hoặc vòng gen hoàn chỉnh bằng tài khoản thật. Muse SDK
hiện trỏ muse.ai, chưa chứng minh đúng Meta AI. Đợt mới đã sửa thumbnail/hash và các lỗi job/lưu/CPU; đọc
`docs/reference-flow-improvements.md` và báo cáo tương ứng. Hiểu hành động vẫn hạn chế.

Đối chiếu SHA-256 trong `manifest.json`. Báo lỗi nên có file/hàm/dòng, kịch bản
tái hiện, ảnh hưởng đến dữ liệu/credit và đề xuất sửa nhỏ nhất.
