# Checklist thử bằng tài khoản thật

Thực hiện trong bản cục bộ trên máy của bạn. Đây là hướng dẫn kiểm, không phải script tự gen; Flow hoặc dịch vụ có thể tính credit.

1. Chạy bộ kiểm local, xem các trường thiếu. Giữ báo cáo cùng Python/thư mục dữ liệu app đang chạy; có file model trên một thư mục khác chưa đủ.
2. Chọn một video ngắn, 2–3 cảnh, lời rõ, có sản phẩm. Tạo một phòng, ghi room ID. Đầu tiên chỉ cho chạy một job/tài khoản để dễ truy vết.
3. Đăng nhập một tài khoản từng nguồn; trong Cài đặt chọn Dùng riêng. Ghi tên hồ sơ, dịch vụ thực tế, model, thời điểm và số dư nếu đọc được; không đưa cookie vào báo cáo.
4. Đọc CPU: mốc cảnh khớp? nghe lại nguyên văn/mốc câu? OCR chỉ là chữ nhìn thấy? camera chưa chắc có để trống không?
5. Cho gửi Gemini Chat, chờ nhận và rà. Đối chiếu room/scene/line IDs. Đổi nguồn không được làm một request cũ chạy lại bằng API.
6. Viết prompt ảnh từ nguồn+bộ ảnh → tạo một frame → kiểm mặt/nhãn → duyệt. Trước duyệt, thử tạo clip phải bị chặn.
7. Viết prompt video với frame đã duyệt. Tạo đúng một clip Flow trước; kiểm engine account ID, request ID, credit, thoại/khẩu hình, duration và scene đích. Muse thử riêng, phải xác nhận đúng dịch vụ mà account dùng.
8. Sau khi một clip ổn, thử hai clip cùng tài khoản. Đối chiếu cả hai ID/kết quả; đảo thứ tự hoàn tất vẫn về đúng phần. Nếu timeout/unknown, kiểm lịch sử trước, không tự resend.
9. Thử native clip audio và VieNeu riêng; nghe rồi chọn giữ/hạ/tắt. Lấy phụ đề từ audio, sửa lỗi và xác nhận script nguồn không đổi. Thêm/tắt nhạc.
10. Sang Dựng: clip đúng thứ tự, phiên bản phụ trong Kho, tiếng và phụ đề đúng. Xuất MP4 và mở file ngoài app; xem đủ thời lượng, nghe nhạc/giọng, kiểm trạng thái phòng Đã xuất.
11. Tắt/mở app ở từng điểm chờ. Việc chưa rõ không tự phát lại; lựa chọn tài khoản mới chỉ ảnh hưởng việc mới.

Ghi cho mỗi bước: PASS/FAIL/BLOCKED, room/scene/request ID, model/account label (không cookie), ảnh lỗi, thời gian và thay đổi credit. Khi một bước BLOCKED thì chưa ghi cả quy trình là PASS.
