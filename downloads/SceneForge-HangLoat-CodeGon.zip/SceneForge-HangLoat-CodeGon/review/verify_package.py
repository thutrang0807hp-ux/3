from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
for r in json.loads((root/'manifest.json').read_text())['files']:
 p=root/r['path'];assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],r['path']
print('PASS source manifest; read-only review, not an installer')
