# SceneForge — code gọn Tạo hàng loạt

Đọc `docs/batch-source-review.md`, sau đó `review/CHECKS.json` và source theo bản đồ.
Runtime nguồn đang phát hành: c7ea29a. Đợt đóng gói không sửa runtime/giao diện.
Có chỉnh đường đi của một test để phù hợp sidebar đã ẩn; kèm log lỗi gốc.

Gói chỉ để đánh giá, KHÔNG phải bộ cài. Không media, model, SDK, venv, cookie/key
hoặc dữ liệu người dùng. Các file dùng chung giữ cả nhánh ngoài phạm vi để truy vết.
Thứ tự nạp trong build.py tham chiếu thêm file UI ngoài gói, bỏ chủ đích để gọn.
Các bài kiểm được chạy trên app đầy đủ, không chạy độc lập từ bản này.

Đề nghị đánh giá: đường gửi có rõ nguồn và xác nhận không; ledger có chống trùng
khi mất mạng/restart không; kết quả về đúng prompt/tài khoản không; scheduler và
phụ thuộc có gây kẹt; file còn được giữ khi gen lại; đường chuyển sang Video mẫu.
Phân biệt lỗi tái hiện với rủi ro đọc code và tính năng chưa nối.
Chưa kiểm tài khoản thật hoặc Windows. Video từ prompt trong Batch chưa nối.

Chạy `python review/verify_package.py` để kiểm hash, không gọi app/AI.
