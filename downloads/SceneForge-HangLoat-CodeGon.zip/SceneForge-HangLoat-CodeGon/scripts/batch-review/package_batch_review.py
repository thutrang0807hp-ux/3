"""Compact read-only batch workflow audit; never edit application source."""
from pathlib import Path
import hashlib,json,zipfile,tempfile,subprocess
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'artifacts/SceneForge-HangLoat-CodeGon.zip';PREFIX='SceneForge-HangLoat-CodeGon/'
files={}
def add(name):files[name]=(ROOT/name).read_bytes()
for name in ['batch-studio.js','batch-studio.css','app.js','package4.js','package5.js','package6.js','library-runtime.js','library-portable.js','storage-actions.js','account-dispatch.js','accounts-dashboard.js','analysis-v3-settings.js','workflow-navigation.js','recovery.js','home-archive.js']:
 add('scripts/app-shell/'+name)
for name in ['scripts/demo-web/build.py','scripts/workflow/room-shell.js','scripts/shared/provider-receipts.js','scripts/batch-review/package_batch_review.py','docs/batch-source-review.md','local_engine/check_batch_images.py','local_engine/check_web_images.py','local_engine/check_web_images_api.py','local_engine/check_account_settings.py','scripts/app-shell/check_accounts_dashboard.py','local_engine/install-chat-browser.bat','local_engine/requirements.txt','docs/batch-multisource.md']:
 add(name)
for p in (ROOT/'local_engine').glob('*.py'):
 if not p.name.startswith('check_'):add(p.relative_to(ROOT).as_posix())
for p in (ROOT/'scripts/app-shell').glob('check_batch_*.py'):add(p.relative_to(ROOT).as_posix())
files['review/CHECKS.json']=(ROOT/'artifacts/batch-multisource-checks.json').read_bytes()
for p in (ROOT/'artifacts/batch-multisource-tests').glob('*.log'):files['review/logs/'+p.name]=p.read_bytes()
files['START_HERE.md']='''# SceneForge — code gọn Tạo hàng loạt

Đọc `docs/batch-source-review.md`, sau đó `review/CHECKS.json` và source theo bản đồ.
Runtime: batch-multisource-20261026. Có thay đổi adapter/UI; xem docs/batch-multisource.md.
Phoma chỉ đọc tĩnh để tham khảo kiến trúc; không kèm mã/bộ cài bên thứ ba.

Gói chỉ để đánh giá, KHÔNG phải bộ cài. Không media, model, SDK, venv, cookie/key
hoặc dữ liệu người dùng. Các file dùng chung giữ cả nhánh ngoài phạm vi để truy vết.
Thứ tự nạp trong build.py tham chiếu thêm file UI ngoài gói, bỏ chủ đích để gọn.
Các bài kiểm được chạy trên app đầy đủ, không chạy độc lập từ bản này.

Đề nghị đánh giá: đường gửi có rõ nguồn và xác nhận không; ledger có chống trùng
khi mất mạng/restart không; kết quả về đúng prompt/tài khoản không; scheduler và
phụ thuộc có gây kẹt; file còn được giữ khi gen lại; đường chuyển sang Video mẫu.
Phân biệt lỗi tái hiện với rủi ro đọc code và tính năng chưa nối.
Chưa kiểm tài khoản thật hoặc Windows. Video từ prompt trong Batch chưa nối.

Chạy `python review/verify_package.py` để kiểm hash, không gọi app/AI.
'''.encode()
files['review/verify_package.py']=b'''from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
for r in json.loads((root/'manifest.json').read_text())['files']:
 p=root/r['path'];assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],r['path']
print('PASS source manifest; read-only review, not an installer')
'''
files['manifest.json']=(json.dumps({'scope':'Read-only batch-image workflow audit; not standalone app','runtime_source_release':'batch-multisource-20261026','runtime_modified_by_packaging':False,'live_provider_verified':False,'models_included':False,'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(files.items())]},ensure_ascii=False,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,b in sorted(files.items()):z.writestr(PREFIX+n,b)
with zipfile.ZipFile(OUT)as z:
 assert z.testzip()is None
 with tempfile.TemporaryDirectory(prefix='sf-batch-review-')as tmp:
  z.extractall(tmp);subprocess.run(['python','review/verify_package.py'],cwd=Path(tmp)/PREFIX,check=True)
 for n in files:
  if n.startswith(('scripts/','local_engine/','docs/')):assert z.read(PREFIX+n)==(ROOT/n).read_bytes()
OUT.with_suffix('.zip.sha256').write_text(hashlib.sha256(OUT.read_bytes()).hexdigest()+'  '+OUT.name+'\n')
print(OUT,OUT.stat().st_size,'bytes',len(files),'files')
