"""Batch browser routing for all added sources; intercepted AI only, no online sends."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,io
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-batch-multisource-')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  image=io.BytesIO();Image.new('RGB',(1400,1000),'#bd5275').save(image,format='PNG');raw=image.getvalue();ref=Path(temp)/'original.png';ref.write_bytes(raw)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];posts=[];records={};token=['choice-1'];page.on('pageerror',lambda e:errors.append(str(e)))
   def route(r):
    req=r.request;path=req.url.split('/local-api/')[1];source=path.split('/')[1]if path.startswith('web-images/')else'flow'
    if path.endswith('/status'):return r.fulfill(json={'configured':True,'installed':True,'account_binding':True,'selection':{'available':True,'mode':'selected','token':token[0],'account_id':'fixture-'+source,'account_name':'Fixture '+source},'accounts':[]})
    if path=='flow/models':return r.fulfill(json={'models':['veo-3','imagen-4']})
    if req.method=='POST':
     body=req.post_data_json;assert body['kind']=='image'and body['selection_token']==token[0];assert len(body['references'])==1
     import base64
     original=Image.open(io.BytesIO(base64.b64decode(body['references'][0]['data'])));assert original.size==(1400,1000),original.size
     source=body['source'];rid=body['request_id'];assert rid.startswith('flow-'if source=='flow'else'webimage-');posts.append(body);records[rid]={'state':'done','request_id':rid,'result':{'model':source+'-fixture','origin':source,'account_id':'fixture-'+source}};return r.fulfill(json={'state':'submitted','request_id':rid})
    if '/files/'in path:return r.fulfill(body=raw,content_type='image/png')
    rid=path.split('/')[-1];return r.fulfill(json=records[rid])
   page.route('**/local-api/web-images/**',route);page.route('**/local-api/flow/**',route)
   page.goto(base+'/#batch');page.wait_for_function('!!SceneForgeApp.batch.getState()');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}''');page.locator('#batchReferenceFiles').set_input_files(ref);expect(page.locator('[data-batch-ref]')).to_have_count(1)
   for source in ['flow','grok','chatgpt','meta']:
    page.locator('#batchEngine').select_option(source);expect(page.locator('#batchConnectSource')).to_be_visible()
    if source=='flow':page.locator('#batchCheckModels').click();expect(page.locator('#batchImageModel option')).to_have_count(1);expect(page.locator('#batchImageModel')).to_have_value('imagen-4')
    page.locator('#batchPrompts').fill('Cận cảnh '+source);page.locator('#batchEnqueue').click();count=len(posts)
    page.locator('#batchRun').click();expect(page.locator('#batchConfirmSend')).to_be_visible();assert len(posts)==count
    token[0]='changed-'+source;page.locator('#batchConfirmSend').click();expect(page.locator('#batchConfirmError')).to_contain_text('đã đổi');assert len(posts)==count
    page.locator('#batchConfirmNo').click();page.locator('#batchRun').click();page.locator('#batchConfirmSend').click();page.wait_for_function('batchState.jobs.every(j=>j.status==="done")',timeout=20000)
    assert len(posts)==count+1;assert posts[-1]['source']==source;assert page.evaluate('batchState.jobs.at(-1).origin')==source;expect(page.locator('.batchStatus').last).to_contain_text({'flow':'Flow','grok':'Grok Chat','chatgpt':'ChatGPT Chat','meta':'Meta AI'}[source])
    page.locator('[data-batch-select]').last.click();expect(page.locator('[data-batch-save-image]')).to_be_visible();page.locator('[data-batch-recover]').click();page.wait_for_timeout(150);assert len(posts)==count+1;page.locator('#shellDialog').evaluate('(d)=>d.close()')
   page.reload();page.wait_for_function('batchState?.jobs.length===4');assert page.evaluate('batchState.jobs.every(j=>j.status==="done"&&j.versions.length===1)');assert len(posts)==4
   page.screenshot(path=str(root/'artifacts/batch-multisource.png'),full_page=True)
   # Shared settings must expose the exact source, not the older muse.ai adapter.
   for source in ['grok','chatgpt','meta']:
    page.evaluate('(source)=>accountScreen(source)',source);expect(page.locator('#settingsAccounts')).to_be_visible();page.wait_for_function('(source)=>activeAccountService===source&&accountDashboard?.service===source',arg=source);assert page.locator('#settingsAccounts').inner_text().find({'grok':'Grok','chatgpt':'ChatGPT','meta':'Meta AI'}[source])>=0
   assert not errors,errors;browser.close()
  print('PASS batch multisource: Flow/Grok/ChatGPT/Meta correct source/account/token, original 1400px references, confirmation and changed-token blocks, original downloads, recovery/reload never replay, shared settings tabs; AI intercepted, not live provider certification.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
