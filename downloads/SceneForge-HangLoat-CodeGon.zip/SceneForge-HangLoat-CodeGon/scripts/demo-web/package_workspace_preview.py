from pathlib import Path
import base64,json,re,zipfile,os
r=Path(__file__).resolve().parents[2];d=r/'dist/web-demo';batch_preview=os.environ.get('SCENEFORGE_PREVIEW_MODE')=='batch'
font='data:font/ttf;base64,'+base64.b64encode((d/'fonts/SceneForgeSans.ttf').read_bytes()).decode()
children={}
for f in ['workflow.html','photos.html','native/index.html']:
 s=(d/f).read_text().replace('../fonts/SceneForgeSans.ttf',font)
 s=s.replace('location.search',"window.__sfPreviewSearch")
 s='<script>window.__sfPreviewSearch=__SF_PREVIEW_QUERY__;</script>'+s
 s=s.replace('location.origin','parent.location.origin').replace(',parent.location.origin)',",(parent.location.origin==='null'?'*':parent.location.origin))")
 children[f]=base64.b64encode(s.encode()).decode()
boot='''<script>
// Offline UI demonstration. Embedded real workspace bundles; no provider calls.
window.__sfPreviewFrames=PAYLOAD;
const originalSrc=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'src');
Object.defineProperty(HTMLIFrameElement.prototype,'src',{get(){return this.dataset.previewSrc||originalSrc.get.call(this)},set(v){const key=Object.keys(window.__sfPreviewFrames).find(k=>String(v).split('?')[0].replace(/^\\.\\//,'')===k);if(key){this.dataset.previewSrc=v;this.srcdoc=new TextDecoder().decode(Uint8Array.from(atob(window.__sfPreviewFrames[key]),c=>c.charCodeAt(0))).replace('__SF_PREVIEW_QUERY__',JSON.stringify(String(v).includes('?')?'?'+String(v).split('?').slice(1).join('?'):''));}else originalSrc.set.call(this,v)}});
const originalFetch=window.fetch.bind(window);
window.fetch=(input,options)=>{const u=String(input?.url||input);if(!u.startsWith('data:')&&!u.startsWith('blob:'))return Promise.reject(new Error('Bản mô phỏng offline: không gọi dịch vụ thật.'));return originalFetch(input,options)};
</script>'''.replace('PAYLOAD',json.dumps(children))
s=(d/'index.html').read_text().replace('new URLSearchParams(location.search).get(\'demo\')',"'1'").replace('sceneforge-app-showcase','sceneforge-workspace-offline-20261027')
s=re.sub(r'<link rel="preload" href="./fonts/SceneForgeSans.ttf"[^>]*>','',s).replace('./fonts/SceneForgeSans.ttf',font)
s=s.replace(',location.origin)',",(location.origin==='null'?'*':location.origin))")
s=s.replace("if(frame.contentWindow?.[name]?.getReadiness?.())","if(frame.contentWindow?.[name]?.getReadiness?.() && typeof frame.contentWindow[name].flushRoom==='function')")
s=s.replace('<head>','<head>'+boot,1)
# Open directly to the new shared workspace once fixture seeding finishes.
s=s.replace('</body>', '''<script>(()=>{const timer=setInterval(()=>{if(!appBootReady||!rooms.length)return;clearInterval(timer);const r=rooms.find(r=>r.mode!=='photos');if(r)openRoom(r.id,'analysis');},60);})();</script></body>''',1)
if batch_preview:s=s.replace("const r=rooms.find(r=>r.mode!=='photos');if(r)openRoom(r.id,'analysis');","openBatchStudio().then(async()=>{if(!batchState.jobs.length){document.querySelector('#batchSample').click();await batchEnqueue();}});")
stem='SceneForge-MoPhong-TaoAnhHangLoat' if batch_preview else 'SceneForge-MoPhong-HaiLuong'
out=r/('artifacts/'+stem+'.html');out.write_text(s)
with zipfile.ZipFile(r/('artifacts/'+stem+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 z.write(out,out.name)
 z.writestr('DOC-TRUOC.txt','Giải nén, mở SceneForge-MoPhong-HaiLuong.html bằng Chrome/Edge.\nMở sẵn Video mẫu. Bấm Từ ảnh & ý tưởng trên thanh trên để xem luồng thứ hai.\nDữ liệu minh họa, không đăng nhập hoặc tạo ảnh/video thật, không trừ credit.\nThử zoom, kéo canvas, bản đồ, nguồn, thông báo và chuyển chế độ.\n')
print(out,out.stat().st_size)
