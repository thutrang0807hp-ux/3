# Code gọn — Lưu trữ / Thu gọn sau xuất

Bản tách để đọc và phân tích mã, lưu trữ v2 ngày 26/10/2026 (nền 59cc255). Không thay đổi logic phần mềm khi đóng gói.

## Đọc theo thứ tự

1. `scripts/app-shell/storage-actions.js`, `local_engine/storage_lifecycle.py` và `storage_jobs.py`: ba thao tác + backend. Đọc `docs/storage-lifecycle-v2.md`.
2. `scripts/app-shell/archive-lifecycle.js`: kế hoạch thu gọn, journal, giữ thành phẩm/kịch bản, lịch/ghim.
2. `scripts/app-shell/library-runtime.js`: IndexedDB → serialize Blob/hash → checkpoint kho máy.
3. `local_engine/library.py` và `library_api.py`: SQLite, tham chiếu hash, sao lưu, pin, dọn file vật lý.
4. `review/excerpts/`: đoạn gốc đánh số dòng về ACK xuất, commit Blob và bản mirror ra thư mục ngoài. Đây là trích đoạn để đọc, không phải file JS thay thế.
5. `review/CAU_HOI_CAN_RA.md`: giới hạn/điểm cần kiểm, gồm job cloud chưa rõ kết quả, bản sao và dọn results backend. `TEST_RESULTS.json` ghi đúng cả bài qua và bài chưa qua.

Các file `.js` / `.py` giữ nguyên nội dung nguồn. Không có HTML dựng sẵn, font, ảnh/video mẫu, SDK, model, tài khoản hoặc dữ liệu người dùng. Một số đường dẫn trong bản đồ trỏ về toàn ứng dụng không có trong bản gọn.

**Gói này không chạy được toàn phần mềm độc lập.** Muốn dựng app hoặc chạy kiểm thử browser, dùng gói `SceneForge-LuuTru-Code-Review.zip` đầy đủ trước đó. Có thể kiểm logic dọn hash riêng bằng `python -m local_engine.check_archive_release` từ thư mục gốc gói này; bài đó chỉ dùng thư mục tạm.

`manifest.json` ghi SHA-256 từng file. Đừng suy từ tài liệu mô tả rằng tất cả nhánh đã được kiểm bằng dữ liệu thật.
