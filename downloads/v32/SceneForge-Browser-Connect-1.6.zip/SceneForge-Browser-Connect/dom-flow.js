'use strict';
// Identity is read only in the explicitly paired Google tab. No cookies/tokens.
async function sceneForgeFlowIdentity(){
 const email=String(window.WIZ_global_data?.oPEP7c||'').trim().toLowerCase();
 if(!email.includes('@'))return {status:401,code:'FLOW_UI_IDENTITY'};
 const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(email));
 return {status:200,email,account_hash:Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('')};
}
// Executed in extension ISOLATED world: page JS cannot access request state/bytes.
async function sceneForgeDomFlow(req){
 const fail=(code,uncertain=false)=>({status:422,code,uncertain});
 const visible=e=>!!e&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';
 const label=e=>{if(e.getAttribute('aria-label'))return e.getAttribute('aria-label').trim();const copy=e.cloneNode(true);copy.querySelectorAll('i,.material-symbols-outlined,.material-icons').forEach(n=>n.remove());return(copy.textContent||'').trim();};
 const buttons=()=>Array.from(document.querySelectorAll('button,[role="button"],[role="menuitem"],[role="menuitemradio"],[role="option"]')).filter(visible);
 const unique=(items)=>items.length===1?items[0]:null;
 const match=re=>unique(buttons().filter(e=>re.test(label(e))));
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const until=async fn=>{for(let n=0;n<40;n++){const value=fn();if(value)return value;await sleep(250);}return null;};
 const verification=()=>Array.from(document.querySelectorAll('[role="alert"],[role="alertdialog"]')).filter(visible).some(e=>/unusual activity|hoạt động bất thường|PUBLIC_ERROR_UNUSUAL_ACTIVITY|verify you are human/i.test(e.textContent))||Array.from(document.querySelectorAll('iframe[src*="recaptcha"][src*="bframe"]')).some(visible);
 const videos=()=>Array.from(document.querySelectorAll('video')).filter(visible);
 const mediaKey=e=>e.currentSrc||e.src||'';
 const signature=()=>location.href;
 const store=globalThis.__sceneForgeDomJobs||(globalThis.__sceneForgeDomJobs=new Map());
 if(verification())return fail('FLOW_UI_VERIFY',true);
 const rid=req.request_id;
 if(typeof rid!=='string'||!/^[a-zA-Z0-9_-]{1,100}$/.test(rid))return fail('FLOW_UI_REQUEST');
 let job=store.get(rid);
 if(req.action==='release'){store.delete(rid);return {status:200};}
 if(req.action==='prepare'){
  if(job)return job.prepared?{status:200}:fail('FLOW_UI_CHANGED',!!job.sent);
  if(store.size>=4)return fail('FLOW_UI_BUSY');
  job={page:signature(),sent:false,prepared:false};store.set(rid,job);
  try{
   // Agent UI is a separate composer. Toggle only when explicit pressed state says ON.
   const agent=match(/^(Agent|Tác nhân)$/i);
   if(agent){
    const pressed=agent.getAttribute('aria-pressed');
    if(pressed==='true'){agent.click();await sleep(600);if(match(/^(Agent|Tác nhân)$/i)?.getAttribute('aria-pressed')==='true')return fail('FLOW_UI_AGENT');}
    else if(pressed!== 'false')return fail('FLOW_UI_AGENT');
   }
   const settings=match(/^(Settings|Generation settings|Cài đặt|Cài đặt tạo|tune)$/i)||unique(buttons().filter(e=>e.matches('button[aria-haspopup]')&&Array.from(e.querySelectorAll('i,.material-symbols-outlined,.material-icons')).some(i=>/^crop_|^tune$/.test(i.textContent.trim()))));
   if(settings){settings.click();await sleep(300);}
   // Select Video before model; tolerate Frames-to-Video already selected.
   const mode=match(/^(Video|Videos|Video generation|Tạo video)$/i);
   if(mode&&mode.getAttribute('aria-selected')!=='true'&&mode.getAttribute('aria-pressed')!=='true'){mode.click();await sleep(300);}
   let lite=match(/^(Veo\s*3\.1\s*[-·]?\s*Lite)(?:\s.*)?$/i);
   if(!lite){const current=match(/^(Veo|Omni)\b/i);if(current){current.click();await sleep(300);lite=match(/^Veo\s*3\.1\s*[-·]?\s*Lite(?:\s.*)?$/i);}}
   if(!lite)return fail('FLOW_UI_MODEL');
   if(['option','menuitem','menuitemradio'].includes(lite.getAttribute('role'))){lite.click();await sleep(300);}
   // Settings are asserted, never inferred from a model name.
   for(const re of [/^(8\s*(s|sec|seconds|giây))$/i,/^9\s*:\s*16$/,/^(x\s*1|1x|1)$/i]){
    const option=match(re);if(!option)return fail('FLOW_UI_SETTINGS');
    const selected=e=>!!e&&(e.getAttribute('aria-selected')==='true'||e.getAttribute('aria-pressed')==='true'||e.getAttribute('aria-checked')==='true'||e.getAttribute('data-state')==='active');
    if(!selected(option)){option.click();if(!await until(()=>selected(match(re))))return fail('FLOW_UI_SETTINGS');}
   }
   // Close settings using Escape, then re-query nodes after React remounts.
   document.activeElement?.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',bubbles:true}));
   const frames=unique(Array.from(document.querySelectorAll('button[id$="-trigger-VIDEO_FRAMES"],button[role="tab"][aria-controls*="VIDEO_FRAMES"]')).filter(visible))||match(/^(Frames to Video|Frames|Khung hình thành video|Khung hình)$/i);
   if(frames){frames.click();await sleep(300);}
   const image=req.image;
   if(!image||!['image/png','image/jpeg','image/webp'].includes(image.mime_type)||typeof image.data!=='string'||image.data.length>9*1024*1024)return fail('FLOW_UI_IMAGE');
   let field=unique(Array.from(document.querySelectorAll('input[type="file"]')).filter(e=>/image|\.png|\.jpg|\.webp/i.test(e.accept)));
   if(!field){const upload=match(/^(Upload image|Upload media|Tải ảnh|Tải nội dung nghe nhìn|Add image|Thêm ảnh)$/i);if(upload){upload.click();await sleep(300);field=unique(Array.from(document.querySelectorAll('input[type="file"]')).filter(e=>/image|\.png|\.jpg|\.webp/i.test(e.accept)));}}
   if(!field)return fail('FLOW_UI_IMAGE');
   const bytes=Uint8Array.from(atob(image.data),c=>c.charCodeAt(0));
   const dt=new DataTransfer();dt.items.add(new File([bytes],'sceneforge-start.'+({'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[image.mime_type]),{type:image.mime_type}));
   field.files=dt.files;field.dispatchEvent(new Event('change',{bubbles:true}));
   const editor=await until(()=>unique(Array.from(document.querySelectorAll('textarea,[contenteditable="true"],[contenteditable="plaintext-only"]')).filter(visible)));
   if(!editor||typeof req.prompt!=='string'||!req.prompt.trim())return fail('FLOW_UI_EDITOR');
   editor.focus();
   if(editor.tagName==='TEXTAREA'){
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(editor,req.prompt);editor.dispatchEvent(new Event('input',{bubbles:true}));
   }else{
    const range=document.createRange();range.selectNodeContents(editor);const sel=getSelection();sel.removeAllRanges();sel.addRange(range);
    if(!document.execCommand('insertText',false,req.prompt))return fail('FLOW_UI_EDITOR');
   }
   await sleep(500);
   if((editor.value??editor.innerText).trim()!==req.prompt.trim())return fail('FLOW_UI_EDITOR');
   // Need an uploaded image preview in the same composer, not an unrelated library image.
   const container=editor.closest('form')||editor.closest('[data-testid*="composer"]')||editor.parentElement?.parentElement;
   if(!container||!await until(()=>Array.from(container.querySelectorAll('img')).filter(e=>visible(e)&&e.complete&&e.naturalWidth>0).length===1))return fail('FLOW_UI_IMAGE');
   const submit=unique(Array.from(container.querySelectorAll('button,[role="button"]')).filter(e=>visible(e)&&/^(Generate|Create|Create video|Tạo|Tạo video|Send|Gửi|arrow_forward)$/i.test(label(e))&&!e.disabled));
   if(!submit)return fail('FLOW_UI_SUBMIT');
   job.editor=editor;job.submit=submit;job.prompt=req.prompt;job.baseline=new Set(videos().map(mediaKey));job.prepared=true;
   return {status:200};
  }finally{if(!job.prepared)store.delete(rid);}
 }
 if(!job||job.page!==signature())return fail('FLOW_UI_CHANGED',true);
 if(req.action==='submit'){
  if(job.sent)return fail('FLOW_UI_CHANGED',true);
  if(!job.prepared||!job.submit.isConnected||job.submit.disabled||!job.editor.isConnected||(job.editor.value??job.editor.innerText).trim()!==job.prompt.trim())return fail('FLOW_UI_CHANGED');
  job.sent=true;job.submit.click();return {status:200};
 }
 if(req.action==='status'){
  if(!job.sent)return fail('FLOW_UI_CHANGED');
  if(job.bytes)return {status:200,ready:true,bytes:job.bytes.length,sha256:job.sha256};
  const fresh=videos().filter(e=>mediaKey(e)&&!job.baseline.has(mediaKey(e)));
  if(fresh.length>1)return fail('FLOW_UI_RESULTS',true);
  if(!fresh.length)return {status:200,ready:false};
  const url=new URL(mediaKey(fresh[0]),location.href);
  const allowed=url.protocol==='blob:'&&url.origin===location.origin||url.protocol==='https:'&&(url.origin===location.origin||/^(?:storage\.googleapis\.com|(?:[a-z0-9-]+\.)*googleusercontent\.com|(?:[a-z0-9-]+\.)*googlevideo\.com|flow-content\.google)$/.test(url.hostname));
  if(!allowed)return fail('FLOW_UI_DOWNLOAD',true);
  try{
   const response=await fetch(url.href,{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(60000)});
   if(!response.ok||!response.body)return fail('FLOW_UI_DOWNLOAD',true);
   const reader=response.body.getReader(),chunks=[];let size=0;
   while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>100*1024*1024){await reader.cancel();return fail('FLOW_UI_DOWNLOAD',true);}chunks.push(value);}
   if(!size)return fail('FLOW_UI_DOWNLOAD',true);
   job.bytes=new Uint8Array(size);let offset=0;for(const part of chunks){job.bytes.set(part,offset);offset+=part.length;}
   job.sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',job.bytes)),v=>v.toString(16).padStart(2,'0')).join('');
   return {status:200,ready:true,bytes:size,sha256:job.sha256};
  }catch{return fail('FLOW_UI_DOWNLOAD',true);}
 }
 if(req.action==='chunk'){
  if(!job.bytes||!Number.isInteger(req.offset)||req.offset<0||req.offset>=job.bytes.length)return fail('FLOW_UI_DOWNLOAD',true);
  const part=job.bytes.subarray(req.offset,req.offset+1024*1024);let text='';for(let i=0;i<part.length;i+=8192)text+=String.fromCharCode(...part.subarray(i,i+8192));
  return {status:200,data:btoa(text)};
 }
 return fail('FLOW_UI_REQUEST');
}
