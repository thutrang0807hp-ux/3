# Nhờ đánh giá luồng Từ ảnh & ý tưởng → video thành phẩm

Rà code thực tế, không chỉ mô tả. Không yêu cầu thêm tính năng hoặc đổi UI trước
khi chỉ ra lỗi. Phân biệt: lỗi tái hiện, rủi ro suy từ code, giới hạn có chủ ý.

Truy vết các tình huống:

1. Một sản phẩm có nhiều dự án: thay ảnh riêng có làm đổi bộ ảnh gốc/dự án khác không?
2. Một storyboard tổng + ảnh gốc + script: Gemini nhận đủ/đúng file không; kết quả
   có được kiểm beat/part/text trước áp dụng? Đổi nội dung trong lúc chờ thì sao?
3. Nhịp 4s, 9s, 13s, 24s: chia clip/câu, mốc thủ công, lời dài; có lặp/mất lời hoặc
   sai giả định khả năng thời lượng/credit của model không?
4. Giữ layout của dự án cũ; sửa thời lượng sau khi đã tạo; dùng lại mẫu mới có mang
   theo job/signature/clip của dự án cũ không?
5. Gửi Flow/Muse: lựa chọn tài khoản từ Cài đặt, token thay đổi, hết credit, nhiều
   job một tài khoản; backend có thật sự ghim kết quả về đúng request/part/account?
6. Tắt app hoặc đầy ổ trước/sau POST; timeout hoặc mất ACK: có gửi trùng, job ma,
   bỏ nhầm unknown thành chưa gửi, hay không còn đường đối soát/bỏ lượt không?
7. Một ô gen 15 lần, ô khác đang lỗi/chạy: luôn hiển thị mới nhất? Chốt cả bản ghép có dọn đúng
   các phiên bản thừa mà giữ timeline/Bộ cảnh/dự án khác/pin/ảnh còn phụ thuộc?
8. Nối khung cuối: đổi phần trước sau khi phần sau đã gen; sửa lời phần sau;
   tail có đúng khung kết thúc đoạn thực dùng trên timeline không?
9. Nhập clip máy hoặc dùng Bộ cảnh: version/signature/duration có được kiểm như clip
   AI? Bản xem thử cho clip chưa duyệt; bản cuối có chặn thiếu/sai khung/sai mốc trước khi dọn không?
10. Giọng native/riêng, caption riêng và nhạc: sửa lời part có làm phụ đề lệch không?
    Giữ/tắt tiếng clip đúng chưa? Đuôi tĩnh có biến thành freeze sai chỗ không?
11. Sang Dựng → xuất → lưu: đúng thứ tự/mốc/sourceDuration; ACK lưu thật; giữ sửa
    timeline cũ; có khai Đã xuất quá sớm hoặc làm mất file sau dọn không?
12. Lưu/dọn mất phản hồi, khởi động lại, backup restore: có phục hồi bản cũ đã xóa,
    ngừng ghi vĩnh viễn, đếm sai bytes hay xóa tư liệu dùng chung không?

Đầu ra mong muốn: bảng bước/file/hàm → tình trạng; danh sách lỗi theo ảnh hưởng
credit/dữ liệu, cách tái hiện và sửa nhỏ nhất. Không chấm độ sẵn sàng online từ
fixture hoặc coi Muse=muse.ai là Meta AI. Nêu rõ phần không đủ bằng chứng.
