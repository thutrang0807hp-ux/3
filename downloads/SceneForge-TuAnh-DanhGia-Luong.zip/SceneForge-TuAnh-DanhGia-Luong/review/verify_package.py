from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for row in m['files']:
 p=root/row['path'];assert p.is_file(),row['path']
 raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
print('PASS',len(m['files']),'files match manifest. No app/provider calls.')
