# Luồng / bản đồ code

## Thứ tự JS thực tế

Photo Studio được ghép trong `scripts/demo-web/build.py`:
shared recipes → provider-receipts → clip-planning → image-quality →
photo-studio/app.js → recipes.js → storyboard.js → design-layout.js →
production.js → providers.js → gemini-chat.js → clip-flow.js → toolbar.js → story-production.js → edit-safety.js.
Nhiều hàm được override qua các lớp; định nghĩa cuối cùng mới là hành vi chạy.
Đừng kết luận dựa riêng app.js hoặc chuỗi cảnh báo cũ trước override.

| Bước | Điểm vào / file | Dữ liệu và điểm nối |
|---|---|---|
| Sửa mốc/công thức/ảnh/giọng | photo-studio/edit-safety.js; app-shell/package4.js: forkDraft | Rà tác động, tính lại plan, reuse file cục bộ; đổi công thức giữ bản gốc; giọng giữ mốc |
| Luồng storyboard → bản ghép | photo-studio/story-production.js: photoPrepareStoryboard, photoWorkflowReceive, photoPreviewDraft | Một ảnh tổng + script + ảnh gốc → nhóm prompt → Bộ cảnh → tự cập nhật bản ghép; chốt cả bản mới dọn và nhập Dựng |
| Thanh tác vụ gọn | photo-studio/toolbar.js: photoToolbarStep, photoToolbarNext, photoToolbarProgress | nguồn AI, một nút theo bước, tiến độ chung, menu tùy chọn; gọi lại luồng tạo/nhận cũ |
| Chọn sản phẩm, mở dự án ảnh | app-shell/package4.js: makeFrame, roomPayload, photoBridge; app-shell/app.js: openRoom | photoDraft nằm trong room, ảnh tham khảo chép riêng; iframe photos.html |
| Bộ ảnh / file máy | photo-studio/production.js: photo-master-refs, photoRefFile; app.js: referenceNode | original qua bridge.putFile, preview riêng; refRoles chọn theo nhịp |
| Viết/dán/lấy kịch bản | app.js, recipes.js, storyboard.js; production.js: chooseRecipe, photo-save-script | draft.beats; dùng bản sao Kho, không sửa đè bản gốc |
| Storyboard tổng | providers.js: photoOverallDialog, photoOverallImagePrompt; gemini-chat.js: photoGchatSubmit, photoRecoverChat | một ảnh storyboardImages/storyboardImage; nhập tay hoặc Gemini Chat image |
| Chia clip | clip-flow.js: photoParts, photoFreezeParts, photoPlanningDialog; shared/clip-planning.js | b.clipPlan.parts, part IDs; mốc câu ước lượng, giữ layout cũ |
| Viết prompt | providers.js: photoChatPack; clip-flow.js: photoChatPack override, validatePhotoStory, photoPartPrompt | ảnh gốc + storyboard tổng + script/parts → Gemini text theo nhóm, kiểm source/schema rồi tự áp b.partPrompts |
| Quản lý Gemini | gemini-chat.js; local_engine/gemini_chat.py, gemini_chat_worker.py | selection/token dùng chung Cài đặt; Chat session, không tự fallback API |
| Chuẩn bị / gửi clip | clip-flow.js: photoRunClips, photoPartReferences | Flow/Muse toolbar; từng phần có signature, part, request ID; save/checkpoint trước POST |
| Tài khoản / đồng thời | app-shell/accounts-dashboard.js, account-dispatch.js; local_engine/flow_accounts.py, account_pool.py, account_settings.py, video_slots.py | selected/failover/balanced; backend là nơi áp tài khoản và giới hạn |
| Engine tạo video | local_engine/flow_provider.py, muse_provider.py, muse_worker.py; request_ledger.py, admission.py | online generation; biên nhận chuẩn bị/gửi, ràng buộc tài khoản, journal/đối soát |
| Nhận kết quả | clip-flow.js: photoRecoverFlows, photoReadClip; shared/provider-receipts.js | GET/reconcile không replay; request ID gắn đúng beat/part, giữ accountId; nhận xong tự vào bản ghép thử, chưa dọn bản cũ |
| Tạo lại / bản mới nhất | clip-flow.js: photoLatest, photoSlotDialog, photoSlotJob | một ô mỗi prompt/part; regenerate đúng ô, bản mới thay ứng viên hiển thị |
| Nối hình | clip-flow.js: photoChainReady, photoPreviousId, photoPartReferences | phần trước mới nhất đã duyệt + tail; tuần tự trong chuỗi, nhịp độc lập có thể song song |
| Duyệt và dọn | clip-flow.js: photoApproveSlots; app-shell/storage-actions.js: approveVersions; local_engine/version_approval.py: prune_photo_approved | scope=photo; revision/receipt; giao dịch chỉ chạy khi chốt bản ghép mới; giữ bản cũ trong quá trình tạo lại |
| Ghép | clip-flow.js: assemble override, photoProductionHandoff override | bản thử dùng clip mới nhất đúng signature/mốc; chốt bản cuối duyệt chung; sourceDuration và holdTail |
| Giọng / chữ / nhạc | production.js: photoProductionHandoff, photoCaptionNode, photoMusicNode; clip-flow.js: photoCues override | tiếng clip/giọng riêng; caption riêng, nhạc file; native caption theo lời từng part |
| Sang Dựng | app.js: openEditor; app-shell/app.js: transferToEditor; native-preview/workflow-import.js | Blob + timeline payload, ACK nhập; tail thành ảnh giữ nếu cần |
| Xuất/lưu | native-preview/timeline-export.js, ffmpeg-export.js, room-shell.js; app-shell/app.js: saveRoomExport | FFmpeg/browser theo khả năng; ACK sau lưu, không chỉ sau render |
| Lưu trữ/dọn | app-shell/library-runtime.js, storage-actions.js, archive-lifecycle.js; local_engine/library.py, library_api.py, storage_lifecycle.py, storage_jobs.py | IndexedDB → hash/files + SQLite; bảo vệ file chung/timeline/ghim, receipt khôi phục |

`review/routes.json` là hợp đồng endpoint lấy từ app đầy đủ đã build; module Python
có thể chứa endpoint ngoài phạm vi. `core-files.json` ghi đường dẫn và số dòng.

## Các giới hạn có chủ ý

- Không ép ảnh khung riêng cho từng cảnh; storyboard tổng không bị animate thành lưới.
- Muse creative/storyboard hiện còn đường thao tác tay; video Muse SDK trỏ muse.ai,
  chưa xác minh Meta AI. Không tuyên bố đã giải quyết đúng dịch vụ người dùng muốn.
- Mốc lời chia từ script là ước lượng, không ASR thực; có thể cần sửa tay.
- Thời lượng timeline không đồng nghĩa thời lượng model/credit. Nối hình không bảo đảm
  model giữ identity hay chuyển động tuyệt đối.
- Cấu hình/giới hạn nhiều tài khoản có code và fixture; chưa có online/Windows E2E.
