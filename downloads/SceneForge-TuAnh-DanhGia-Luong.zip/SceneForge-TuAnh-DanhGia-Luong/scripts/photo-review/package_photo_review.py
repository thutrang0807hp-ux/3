"""Focused Photo Studio source audit: preserve source, omit runtime/media/models/data."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/SceneForge-TuAnh-DanhGia-Luong.zip'
PREFIX='SceneForge-TuAnh-DanhGia-Luong/'
files={}
def add(name):files[name]=(ROOT/name).read_bytes()
# Include every Photo Studio override, in its real build order (see build.py).
for folder in ['photo-studio','shared']:
 for p in (ROOT/'scripts'/folder).iterdir():
  if p.is_file()and p.suffix in {'.js','.css','.html'}:add(p.relative_to(ROOT).as_posix())
# Shared backend modules are kept whole so contracts/imports can be traced.
for p in (ROOT/'local_engine').glob('*.py'):
 if not p.name.startswith('check_'):add(p.relative_to(ROOT).as_posix())
for name in [
 'scripts/app-shell/app.js','scripts/app-shell/package4.js','scripts/app-shell/package5.js',
 'scripts/app-shell/package6.js','scripts/app-shell/workflow-navigation.js',
 'scripts/app-shell/recipes.js','scripts/app-shell/recipe-library-v3.js','scripts/app-shell/storyboard-library.js',
 'scripts/app-shell/account-dispatch.js','scripts/app-shell/accounts-dashboard.js','scripts/app-shell/analysis-v3-settings.js',
 'scripts/app-shell/library-runtime.js','scripts/app-shell/library-portable.js','scripts/app-shell/library-panel.js',
 'scripts/app-shell/archive-lifecycle.js','scripts/app-shell/storage-actions.js','scripts/app-shell/home-archive.js',
 'scripts/app-shell/recovery.js','scripts/app-shell/batch-studio.js',
 'scripts/demo-web/build.py','scripts/demo-lite/app.js','scripts/demo-lite/workstation.js',
 'local_engine/requirements.txt','local_engine/requirements-cpu.txt','local_engine/speech_guard.json',
 'local_engine/check_photo_story_production.py','docs/photo-story-production.md','local_engine/check_photo_toolbar.py','local_engine/check_photo_review_fixes.py','local_engine/check_photo_clip_flow.py','local_engine/check_photo_version_approval.py',
 'local_engine/check_version_approval.py','local_engine/check_storage_lifecycle.py',
 'local_engine/check_storage_jobs.py','local_engine/check_admission_recovery.py',
 'local_engine/check_library_ack_recovery_ui.py','local_engine/check_timeline_export.py',
 'local_engine/check_export_commit.py','docs/photo-toolbar-compact.md','docs/photo-review-fixes.md','docs/photo-clip-flow.md','docs/photo-flow-integration.md',
 'docs/photo-archive-lifecycle.md','docs/storage-lifecycle-v2.md','docs/multi-account-dispatch.md',
 'docs/video-same-account-concurrency.md','docs/muse-web-integration.md',
 'docs/gemini-web-installation.md','docs/flow-installation-status.md',
]:
 if not(ROOT/name).is_file():raise FileNotFoundError(name)
 add(name)
for p in (ROOT/'scripts/native-preview').iterdir():
 if p.is_file()and p.suffix in {'.js','.css'}:add(p.relative_to(ROOT).as_posix())
add(Path(__file__).relative_to(ROOT).as_posix())
files['review/PHOTO_STORY_PRODUCTION_CHECKS.json']=(ROOT/'artifacts/photo-story-production-checks.json').read_bytes()
files['review/PHOTO_TOOLBAR_CHECKS.json']=(ROOT/'artifacts/photo-toolbar-checks.json').read_bytes()
files['review/PHOTO_REVIEW_FIXES_CHECKS.json']=(ROOT/'artifacts/photo-review-fixes-checks.json').read_bytes()
files['review/PHOTO_CLIP_FLOW_CHECKS.json']=(ROOT/'artifacts/photo-clip-flow-checks.json').read_bytes()
files['review/PACKAGING_CHECK_20261026.json']=(ROOT/'artifacts/reference-packaging-checks-20261026.json').read_bytes()
with zipfile.ZipFile(ROOT/'artifacts/SceneForge-VideoMau-Code-Review.zip')as z:
 routes=json.loads(z.read('SceneForge-VideoMau-Code-Review/review/routes.json'))
files['review/routes.json']=json.dumps([r for r in routes if r['path'].startswith(('/local-api/gemini-chat','/local-api/flow','/local-api/muse','/local-api/library','/local-api/requests','/local-api/tts','/local-api/export','/local-api/timeline','/local-api/ai/script','/local-api/status','/local-api/accounts'))],ensure_ascii=False,indent=2).encode()
files['START_HERE.md']='''# SceneForge — code tập trung luồng Từ ảnh & ý tưởng

Mục đích: mang đi đánh giá code và cách nối từng bước, không phải gói cài app.
Snapshot code sau sửa phản hồi: `photo-story-production-20261026`. Đóng gói không sửa logic.

Đọc theo thứ tự:

1. `review/LUONG_VA_BAN_DO.md`: luồng và file/hàm nối từng bước.
2. `review/DE_BAI_DANH_GIA.md`: yêu cầu đánh giá, tình huống cần kiểm.
3. `docs/photo-story-production.md`: luồng storyboard → Bộ cảnh → xem/chốt cả bản ghép mới; `photo-review-fixes.md` và `photo-clip-flow.md` là logic nền.
4. `scripts/photo-studio/` theo thứ tự trong `scripts/demo-web/build.py`.
5. Backend, shell, editor theo bảng liên kết; kiểm chứng ở các báo cáo trong `review/`.

Các file JS/Python/CSS được giữ nguyên, không rút gọn/chuyển thành ví dụ.
Các module dùng chung có nhánh ngoài phạm vi: chỉ rà đường Từ ảnh & ý tưởng.
Không đánh đồng code tồn tại hoặc transport fixture PASS với generation online đã chạy.

Gói không chứa HTML đã build, ảnh/video/giọng mẫu, font, trọng số model, SDK đã cài,
venv, cookie, API key, vault hay dữ liệu dự án người dùng. Nó KHÔNG dựng/chạy app
độc lập. `template.html` là mã nguồn UI. Những tài nguyên/UI ngoài phạm vi bị bỏ
chủ đích; đường dẫn không có ở gói này không có nghĩa app đầy đủ bị thiếu file.
Các bài test được giữ để đọc; nhiều bài cần media/Chromium/backend của gói đầy đủ.

Kiểm ZIP sau giải nén: `python review/verify_package.py` (chỉ cần Python stdlib).
`manifest.json` ghi SHA-256 từng file; `review/core-files.json` chỉ ra file trọng tâm.
Báo cáo kiểm chức năng/build là lần chạy trên app đầy đủ trước khi đóng gói này,
không phải chứng nhận gói gọn chạy được. Chưa kiểm Windows/tài khoản thật.
Muse hiện là muse.ai, chưa phải Meta AI.
'''.encode()
files['review/LUONG_VA_BAN_DO.md']='''# Luồng / bản đồ code

## Thứ tự JS thực tế

Photo Studio được ghép trong `scripts/demo-web/build.py`:
shared recipes → provider-receipts → clip-planning → image-quality →
photo-studio/app.js → recipes.js → storyboard.js → design-layout.js →
production.js → providers.js → gemini-chat.js → clip-flow.js → toolbar.js → story-production.js.
Nhiều hàm được override qua các lớp; định nghĩa cuối cùng mới là hành vi chạy.
Đừng kết luận dựa riêng app.js hoặc chuỗi cảnh báo cũ trước override.

| Bước | Điểm vào / file | Dữ liệu và điểm nối |
|---|---|---|
| Luồng storyboard → bản ghép | photo-studio/story-production.js: photoPrepareStoryboard, photoWorkflowReceive, photoPreviewDraft | Một ảnh tổng + script + ảnh gốc → nhóm prompt → Bộ cảnh → tự cập nhật bản ghép; chốt cả bản mới dọn và nhập Dựng |
| Thanh tác vụ gọn | photo-studio/toolbar.js: photoToolbarStep, photoToolbarNext, photoToolbarProgress | nguồn AI, một nút theo bước, tiến độ chung, menu tùy chọn; gọi lại luồng tạo/nhận cũ |
| Chọn sản phẩm, mở dự án ảnh | app-shell/package4.js: makeFrame, roomPayload, photoBridge; app-shell/app.js: openRoom | photoDraft nằm trong room, ảnh tham khảo chép riêng; iframe photos.html |
| Bộ ảnh / file máy | photo-studio/production.js: photo-master-refs, photoRefFile; app.js: referenceNode | original qua bridge.putFile, preview riêng; refRoles chọn theo nhịp |
| Viết/dán/lấy kịch bản | app.js, recipes.js, storyboard.js; production.js: chooseRecipe, photo-save-script | draft.beats; dùng bản sao Kho, không sửa đè bản gốc |
| Storyboard tổng | providers.js: photoOverallDialog, photoOverallImagePrompt; gemini-chat.js: photoGchatSubmit, photoRecoverChat | một ảnh storyboardImages/storyboardImage; nhập tay hoặc Gemini Chat image |
| Chia clip | clip-flow.js: photoParts, photoFreezeParts, photoPlanningDialog; shared/clip-planning.js | b.clipPlan.parts, part IDs; mốc câu ước lượng, giữ layout cũ |
| Viết prompt | providers.js: photoChatPack; clip-flow.js: photoChatPack override, validatePhotoStory, photoPartPrompt | ảnh gốc + storyboard tổng + script/parts → Gemini text theo nhóm, kiểm source/schema rồi tự áp b.partPrompts |
| Quản lý Gemini | gemini-chat.js; local_engine/gemini_chat.py, gemini_chat_worker.py | selection/token dùng chung Cài đặt; Chat session, không tự fallback API |
| Chuẩn bị / gửi clip | clip-flow.js: photoRunClips, photoPartReferences | Flow/Muse toolbar; từng phần có signature, part, request ID; save/checkpoint trước POST |
| Tài khoản / đồng thời | app-shell/accounts-dashboard.js, account-dispatch.js; local_engine/flow_accounts.py, account_pool.py, account_settings.py, video_slots.py | selected/failover/balanced; backend là nơi áp tài khoản và giới hạn |
| Engine tạo video | local_engine/flow_provider.py, muse_provider.py, muse_worker.py; request_ledger.py, admission.py | online generation; biên nhận chuẩn bị/gửi, ràng buộc tài khoản, journal/đối soát |
| Nhận kết quả | clip-flow.js: photoRecoverFlows, photoReadClip; shared/provider-receipts.js | GET/reconcile không replay; request ID gắn đúng beat/part, giữ accountId; nhận xong tự vào bản ghép thử, chưa dọn bản cũ |
| Tạo lại / bản mới nhất | clip-flow.js: photoLatest, photoSlotDialog, photoSlotJob | một ô mỗi prompt/part; regenerate đúng ô, bản mới thay ứng viên hiển thị |
| Nối hình | clip-flow.js: photoChainReady, photoPreviousId, photoPartReferences | phần trước mới nhất đã duyệt + tail; tuần tự trong chuỗi, nhịp độc lập có thể song song |
| Duyệt và dọn | clip-flow.js: photoApproveSlots; app-shell/storage-actions.js: approveVersions; local_engine/version_approval.py: prune_photo_approved | scope=photo; revision/receipt; giao dịch chỉ chạy khi chốt bản ghép mới; giữ bản cũ trong quá trình tạo lại |
| Ghép | clip-flow.js: assemble override, photoProductionHandoff override | bản thử dùng clip mới nhất đúng signature/mốc; chốt bản cuối duyệt chung; sourceDuration và holdTail |
| Giọng / chữ / nhạc | production.js: photoProductionHandoff, photoCaptionNode, photoMusicNode; clip-flow.js: photoCues override | tiếng clip/giọng riêng; caption riêng, nhạc file; native caption theo lời từng part |
| Sang Dựng | app.js: openEditor; app-shell/app.js: transferToEditor; native-preview/workflow-import.js | Blob + timeline payload, ACK nhập; tail thành ảnh giữ nếu cần |
| Xuất/lưu | native-preview/timeline-export.js, ffmpeg-export.js, room-shell.js; app-shell/app.js: saveRoomExport | FFmpeg/browser theo khả năng; ACK sau lưu, không chỉ sau render |
| Lưu trữ/dọn | app-shell/library-runtime.js, storage-actions.js, archive-lifecycle.js; local_engine/library.py, library_api.py, storage_lifecycle.py, storage_jobs.py | IndexedDB → hash/files + SQLite; bảo vệ file chung/timeline/ghim, receipt khôi phục |

`review/routes.json` là hợp đồng endpoint lấy từ app đầy đủ đã build; module Python
có thể chứa endpoint ngoài phạm vi. `core-files.json` ghi đường dẫn và số dòng.

## Các giới hạn có chủ ý

- Không ép ảnh khung riêng cho từng cảnh; storyboard tổng không bị animate thành lưới.
- Muse creative/storyboard hiện còn đường thao tác tay; video Muse SDK trỏ muse.ai,
  chưa xác minh Meta AI. Không tuyên bố đã giải quyết đúng dịch vụ người dùng muốn.
- Mốc lời chia từ script là ước lượng, không ASR thực; có thể cần sửa tay.
- Thời lượng timeline không đồng nghĩa thời lượng model/credit. Nối hình không bảo đảm
  model giữ identity hay chuyển động tuyệt đối.
- Cấu hình/giới hạn nhiều tài khoản có code và fixture; chưa có online/Windows E2E.
'''.encode()
files['review/DE_BAI_DANH_GIA.md']='''# Nhờ đánh giá luồng Từ ảnh & ý tưởng → video thành phẩm

Rà code thực tế, không chỉ mô tả. Không yêu cầu thêm tính năng hoặc đổi UI trước
khi chỉ ra lỗi. Phân biệt: lỗi tái hiện, rủi ro suy từ code, giới hạn có chủ ý.

Truy vết các tình huống:

1. Một sản phẩm có nhiều dự án: thay ảnh riêng có làm đổi bộ ảnh gốc/dự án khác không?
2. Một storyboard tổng + ảnh gốc + script: Gemini nhận đủ/đúng file không; kết quả
   có được kiểm beat/part/text trước áp dụng? Đổi nội dung trong lúc chờ thì sao?
3. Nhịp 4s, 9s, 13s, 24s: chia clip/câu, mốc thủ công, lời dài; có lặp/mất lời hoặc
   sai giả định khả năng thời lượng/credit của model không?
4. Giữ layout của dự án cũ; sửa thời lượng sau khi đã tạo; dùng lại mẫu mới có mang
   theo job/signature/clip của dự án cũ không?
5. Gửi Flow/Muse: lựa chọn tài khoản từ Cài đặt, token thay đổi, hết credit, nhiều
   job một tài khoản; backend có thật sự ghim kết quả về đúng request/part/account?
6. Tắt app hoặc đầy ổ trước/sau POST; timeout hoặc mất ACK: có gửi trùng, job ma,
   bỏ nhầm unknown thành chưa gửi, hay không còn đường đối soát/bỏ lượt không?
7. Một ô gen 15 lần, ô khác đang lỗi/chạy: luôn hiển thị mới nhất? Chốt cả bản ghép có dọn đúng
   các phiên bản thừa mà giữ timeline/Bộ cảnh/dự án khác/pin/ảnh còn phụ thuộc?
8. Nối khung cuối: đổi phần trước sau khi phần sau đã gen; sửa lời phần sau;
   tail có đúng khung kết thúc đoạn thực dùng trên timeline không?
9. Nhập clip máy hoặc dùng Bộ cảnh: version/signature/duration có được kiểm như clip
   AI? Bản xem thử cho clip chưa duyệt; bản cuối có chặn thiếu/sai khung/sai mốc trước khi dọn không?
10. Giọng native/riêng, caption riêng và nhạc: sửa lời part có làm phụ đề lệch không?
    Giữ/tắt tiếng clip đúng chưa? Đuôi tĩnh có biến thành freeze sai chỗ không?
11. Sang Dựng → xuất → lưu: đúng thứ tự/mốc/sourceDuration; ACK lưu thật; giữ sửa
    timeline cũ; có khai Đã xuất quá sớm hoặc làm mất file sau dọn không?
12. Lưu/dọn mất phản hồi, khởi động lại, backup restore: có phục hồi bản cũ đã xóa,
    ngừng ghi vĩnh viễn, đếm sai bytes hay xóa tư liệu dùng chung không?

Đầu ra mong muốn: bảng bước/file/hàm → tình trạng; danh sách lỗi theo ảnh hưởng
credit/dữ liệu, cách tái hiện và sửa nhỏ nhất. Không chấm độ sẵn sàng online từ
fixture hoặc coi Muse=muse.ai là Meta AI. Nêu rõ phần không đủ bằng chứng.
'''.encode()
CORE=['scripts/photo-studio/story-production.js','scripts/photo-studio/story-production.css','scripts/photo-studio/toolbar.js','scripts/photo-studio/app.js','scripts/photo-studio/production.js','scripts/photo-studio/providers.js','scripts/photo-studio/gemini-chat.js','scripts/photo-studio/clip-flow.js','scripts/shared/clip-planning.js','scripts/shared/provider-receipts.js','scripts/app-shell/package4.js','scripts/app-shell/storage-actions.js','scripts/app-shell/library-runtime.js','local_engine/version_approval.py','local_engine/request_ledger.py','local_engine/flow_provider.py','local_engine/muse_provider.py','local_engine/gemini_chat.py','local_engine/storage_lifecycle.py','local_engine/storage_jobs.py','scripts/native-preview/workflow-import.js','scripts/native-preview/timeline-export.js']
files['review/core-files.json']=json.dumps([{'path':n,'lines':len(files[n].splitlines())}for n in CORE],ensure_ascii=False,indent=2).encode()
files['review/verify_package.py']=b'''from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for row in m['files']:
 p=root/row['path'];assert p.is_file(),row['path']
 raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
print('PASS',len(m['files']),'files match manifest. No app/provider calls.')
'''
files['manifest.json']=json.dumps({'scope':'read-only Photo Studio flow audit, not standalone app','application_release':'photo-story-production-20261026','date_local':'2026-10-26','source_logic_modified':False,'files':[{'path':n,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}for n,raw in sorted(files.items())]},ensure_ascii=False,indent=2).encode()
OUT.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,raw in sorted(files.items()):z.writestr(PREFIX+name,raw)
with zipfile.ZipFile(OUT)as z:
 assert z.testzip()is None
 for item in json.loads(z.read(PREFIX+'manifest.json'))['files']:assert hashlib.sha256(z.read(PREFIX+item['path'])).hexdigest()==item['sha256']
 assert not any(Path(n).suffix.lower()in {'.mp4','.mp3','.wav','.ttf','.onnx','.bin','.dll','.exe','.sqlite'}for n in z.namelist())
digest=hashlib.sha256(OUT.read_bytes()).hexdigest();OUT.with_suffix('.zip.sha256').write_text(digest+'  '+OUT.name+'\n')
print(OUT,len(files),'files',OUT.stat().st_size,'bytes',digest)
if __name__=='__main__':pass
