// Workflow navigation opens a separate room. It never changes a room's mode or media.
const workflowModes=document.createElement('nav');workflowModes.id='workflowModes';workflowModes.setAttribute('aria-label','Hai cách tạo video');
workflowModes.innerHTML='<div class="workflowModeChoices" role="group" aria-label="Chọn cách tạo video"><button data-workflow-mode="reference" title="Mở phòng từ video mẫu"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M3 5l2-3 17 2-1 4m-12 5 6 3-6 3z"/></svg><span><strong>Từ video mẫu</strong><small>Phân tích & tái tạo</small></span></button><button data-workflow-mode="photos" title="Mở phòng từ ảnh và ý tưởng"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 6-6 4 4 3-3 5 5"/></svg><span><strong>Từ ảnh & ý tưởng</strong><small>Kịch bản & bộ cảnh</small></span></button></div><span id="workflowModeHint"></span><button id="photoWorkspaceToggle" hidden></button>';
$('.roomBar').after(workflowModes);
let changingWorkflow=false;
async function createWorkflowRoom(mode,product){
 const r={id:uid(),name:(mode==='photos'?'Video từ ảnh':'Video mẫu mới')+' · '+product.name,productId:product.id,mode,stage:mode==='photos'?'review':'new',createdAt:Date.now(),updatedAt:Date.now(),refs:clone(product.refs),sceneStates:[]};
 r.slug=uniqueSlug(r.name,rooms.filter(r=>r.productId===product.id));rooms.push(r);await persistRoom(r);return r;
}
async function switchWorkflow(mode){
 if(!['reference','photos'].includes(mode)||changingWorkflow)return;
 if(currentRoom?.mode===mode&&currentView==='analysis')return;
 changingWorkflow=true;renderWorkflowModes();
 try{
  await flushFrames();const product=productFor(currentRoom?.productId)||productFor(prefs.product)||products[0];
  if(!product)throw Error('Tạo sản phẩm trước khi mở không gian.');
  const remembered=roomFor(prefs.modeRooms?.[product.id]?.[mode]);
  let target=remembered&&remembered.productId===product.id&&remembered.mode===mode&&!archivedRoom(remembered)?remembered:rooms.filter(r=>r.productId===product.id&&(r.mode||'reference')===mode&&!archivedRoom(r)).sort((a,b)=>(b.updatedAt||b.createdAt)-(a.updatedAt||a.createdAt))[0];
  if(!target)target=await createWorkflowRoom(mode,product);
  await openRoom(target.id,'analysis');
 }catch(e){fail(e);}finally{changingWorkflow=false;renderWorkflowModes();}
}
function renderWorkflowModes(){
 workflowModes.hidden=currentView!=='analysis';workflowModes.setAttribute('aria-busy',String(changingWorkflow));const r=currentRoom;
 for(const b of workflowModes.querySelectorAll('[data-workflow-mode]')){const active=b.dataset.workflowMode===(r?.mode||'reference');b.classList.toggle('selected',active);b.setAttribute('aria-current',active?'page':'false');b.setAttribute('aria-pressed',String(active));b.disabled=changingWorkflow;}
 $('#workflowModeHint').textContent=changingWorkflow?'Đang lưu và đổi phòng…':r?.mode==='photos'?(r.photoWorkspace==='storyboard'?'Kịch bản theo cảnh · dự án cũ được giữ':'Bộ cảnh sản phẩm + kịch bản + giọng đọc + đạo diễn'):'Bám cấu trúc và nhịp video tham khảo';
 const toggle=$('#photoWorkspaceToggle');toggle.hidden=!(r?.mode==='photos'&&r.legacyPhotoAvailable);toggle.textContent=r?.photoWorkspace==='storyboard'?'Mở Bộ cảnh & đạo diễn →':'Mở kịch bản theo cảnh cũ →';
}
workflowModes.addEventListener('click',e=>{const b=e.target.closest('[data-workflow-mode]');if(b)switchWorkflow(b.dataset.workflowMode);});
$('#photoWorkspaceToggle').onclick=async()=>{const r=currentRoom;if(!r||changingWorkflow)return;try{await flushFrames();r.photoWorkspace=r.photoWorkspace==='storyboard'?'bank':'storyboard';await io('rooms','readwrite',r.id,r);$('#roomFrames').replaceChildren();frameRoom=null;await openRoom(r.id,'analysis');}catch(e){fail(e);}};
const renderBeforeNavigation=render;render=function(){renderBeforeNavigation();renderWorkflowModes();};
const openBeforeNavigation=openRoom;openRoom=async function(id,view=null){await openBeforeNavigation(id,view);const r=roomFor(id);if(currentRoom?.id===id&&r){prefs.modeRooms??={};prefs.modeRooms[r.productId]??={};prefs.modeRooms[r.productId][r.mode||'reference']=id;await savePrefs();}renderWorkflowModes();};
window.SceneForgeApp.openRoom=(...args)=>openRoom(...args);window.SceneForgeApp.switchWorkflow=switchWorkflow;
window.addEventListener('message',e=>{
 const frame=$('#workflowFrame');if(e.origin!==location.origin||e.source!==frame?.contentWindow)return;
 if(e.data?.type==='sceneforge:switch-workflow')switchWorkflow(e.data.mode);
 if(e.data?.type==='sceneforge:room-source-attached'){
  const r=roomFor(e.data.roomId);if(!r||r.id!==currentRoom?.id||r.mode==='photos'||!(e.data.file instanceof Blob))return;
  (async()=>{await io('files','readwrite',r.id+':source',e.data.file);r.sourceName=e.data.name;r.sourceSize=e.data.file.size;r.poster=e.data.poster||r.poster;await persistRoom(r);})().catch(fail);
 }
});
const payloadBeforeNavigation=roomPayload;roomPayload=async function(r){return{...await payloadBeforeNavigation(r),hostNavigation:true};};
async function restoreLegacyPhotoWorkspaces(){
 for(const r of rooms.filter(r=>r.mode==='photos')){
  const old=await workflowRecord(r.id);if(!old?.storyboard||!old.scenes?.length)continue;
  r.legacyPhotoAvailable=true;
  // Keep both stored versions. A migration must not silently hide the old frames/clips.
  if(!r.photoWorkspace)r.photoWorkspace=!r.photoDraft||r.photoDraft.migrationNotice?'storyboard':'bank';
  await io('rooms','readwrite',r.id,r);
 }
}
