"""Worker lifecycle contracts without browsers, credentials or provider calls."""
import asyncio,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from .flow_managed_driver import FlowManagedDriver

class Vault:
 def __init__(self):self.profiles={a:{'account_id':a,'profile_key':a*24,'email':a+'@invalid'}for a in ('a','b')}
 def secret(self,key):return self.profiles if key=='flow-managed-profiles' else None

class Session:
 created=[]
 def __init__(self,data,profile_key):
  self.key=profile_key;self.email=profile_key[0]+'@invalid';self.disconnected=0
  self.page=SimpleNamespace(url='https://flow.google.com/project/fixture')
  self.live=True;self.browser=SimpleNamespace(is_connected=lambda:self.live,contexts=[SimpleNamespace(pages=[self.page])]);Session.created.append(self)
 async def attach(self,factory):pass
 async def assert_ready(self):
  if not self.live:raise RuntimeError('disconnected')
 @staticmethod
 def is_flow(url):return url.startswith('https://flow.google.com/')
 async def disconnect(self):self.disconnected+=1;self.live=False

async def main():
 with tempfile.TemporaryDirectory() as tmp,patch('local_engine.flow_managed_driver.FlowUiSession',Session):
  vault=Vault();driver=FlowManagedDriver(Path(tmp),vault)
  async with driver.session('a') as first:
   async with driver.session('a') as nested:assert nested is first
  async with driver.session('a') as reused:assert reused['session'] is first['session']
  entered=asyncio.Event();release=asyncio.Event();second_entered=asyncio.Event()
  async def hold():
   async with driver.session('a'):entered.set();await release.wait()
  async def queued():
   async with driver.session('a'):second_entered.set()
  task=asyncio.create_task(hold());await entered.wait();waiting=asyncio.create_task(queued());await asyncio.sleep(0)
  assert not second_entered.is_set()
  # Different accounts have separate connections and can acquire their worker.
  async with driver.session('b') as other:assert other['session'] is not first['session']
  release.set();await asyncio.gather(task,waiting);assert second_entered.is_set()
  # Cancellation drops only its own worker; the next operation attaches afresh.
  entered.clear();release.clear();task=asyncio.create_task(hold());await entered.wait();task.cancel()
  try:await task
  except asyncio.CancelledError:pass
  assert 'a' not in driver.workers and 'b' in driver.workers
  async with driver.session('a') as fresh:assert fresh['session'] is not first['session']
  # Removal must invalidate a cached worker before any new operation.
  vault.profiles.pop('a')
  try:
   async with driver.session('a'):raise AssertionError('removed account admitted')
  except RuntimeError:pass
  assert 'a' not in driver.workers
  await driver.close();assert not driver.workers
  assert all(s.disconnected==1 for s in Session.created)
  try:
   async with driver.session('b'):raise AssertionError('closed pool admitted work')
  except RuntimeError:pass
 print('PASS workers: connection reuse, same-account queue, independent accounts, cancellation isolation, removal, shutdown; no browser or provider requests.')
if __name__=='__main__':asyncio.run(main())
