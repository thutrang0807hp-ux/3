Worker lifecycle update only. Still Playwright + DOM; not a full Phoma port. Does not resolve Google sign-in rejection. Local intercepted fixture passed; no Windows/live Google verification.
