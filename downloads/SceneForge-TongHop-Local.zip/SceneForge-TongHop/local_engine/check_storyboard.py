"""Mocked provider: one script request returns all options and storyboard; failures never retry."""
import os,sys,tempfile
from pathlib import Path
from unittest.mock import AsyncMock,patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
with tempfile.TemporaryDirectory(dir='/tmp') as temp:
 os.environ['SCENEFORGE_LOCAL_DATA']=temp
 from fastapi.testclient import TestClient
 from local_engine import server
 with TestClient(server.app) as c:
  def post(body):return c.post('/local-api/ai/script',headers={'X-SceneForge-Local':'1'},json=body)
  beat={'text':'Lời mới theo sản phẩm','type':'detail','angle':'Cận','movement':'Chậm','onScreen':''}
  payload={'beats':[{'name':'Hỏi','seconds':3}], 'variants':3}
  variants=[{'hook':h,'beats':[{**beat,'text':t}]}for h,t in [('Hỏi vấn đề','Bạn đang tìm gì?'),('Quan sát','Nhãn chai ở đây.'),('Review','Tôi xem nhãn trước.')]]
  with patch.object(server,'gemini',AsyncMock(return_value={'variants':variants})) as m:
   out=post(payload);assert out.status_code==200,out.text;assert len(out.json()['variants'])==3;assert m.await_count==1;assert 'SAME response' in m.await_args.args[1]
  for value in [{'variants':variants[:2]},{'variants':[variants[0]]*3},{'variants':[variants[0],variants[1],{'hook':'Khác','beats':[{**beat,'type':'unknown'}]}]}]:
   with patch.object(server,'gemini',AsyncMock(return_value=value)) as m:assert post(payload).status_code==502;assert m.await_count==1
  with patch.object(server,'gemini',AsyncMock(return_value={'beats':[beat]})) as m:
   assert post({'beats':[{}]}).json()['beats'][0]['angle']=='Cận';assert m.await_count==1
   assert post({**payload,'variants':True}).status_code==400;assert m.await_count==1
 print('PASS single request for 3 distinct hooks + storyboard; duplicate/partial/invalid outputs rejected, no retry, single-script compatibility; mocked provider only.')
