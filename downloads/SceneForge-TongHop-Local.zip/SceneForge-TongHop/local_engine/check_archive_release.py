"""Retired archive hashes never delete shared, pinned, backed-up or unrelated assets."""
from pathlib import Path
from tempfile import TemporaryDirectory
import time
from .library import Library,Conflict
with TemporaryDirectory(prefix='sf-release-')as directory:
 root=Path(directory);lib=Library(root)
 def asset(name):
  p=root/(name+'.bin');p.write_bytes(name.encode()*30);return lib.add_file(p)['hash']
 def marker(h):return {'$sf':'blob','hash':h,'type':'video/mp4'}
 def room(state='final-only',retired=None):return {'db':'sceneforge-app-shell','store':'rooms','key':'r','value':{'id':'r','archiveState':state,'compactedAt':time.time(),'archiveRetiredHashes':retired or []}}
 backed=asset('backed');snap=lib.commit([{'db':'sceneforge-app-shell','store':'files','key':'old','value':marker(backed)}],0);lib.backup()
 unique,shared,pinned,exported,unrelated=[asset(n)for n in ['unique','shared','pinned','exported','unrelated']];lib.set_pin(pinned,True)
 records=[room(retired=[unique,shared,pinned,backed]),{'db':'sceneforge-app-shell','store':'files','key':'r:export','value':marker(exported)},{'db':'sceneforge-app-shell','store':'files','key':'another:clip','value':marker(shared)}];snap=lib.commit(records,snap['revision'])
 try:lib.release_compacted('r',snap['revision']-1);raise AssertionError('accepted stale revision')
 except Conflict:pass
 result=lib.release_compacted('r',snap['revision']);assert result['files']==1 and result['protected']==3,result;assert not lib.asset_path(unique).exists()
 for h in [shared,pinned,backed,exported,unrelated]:assert lib.asset_path(h).exists(),h
 editable=lib.commit([room(state='editable',retired=[unrelated])],snap['revision'])
 try:lib.release_compacted('r',editable['revision']);raise AssertionError('deleted from editable room')
 except ValueError:pass
 assert lib.asset_path(unrelated).exists()
print('PASS targeted physical archive release; protects shared hashes, pin, backup, final export, unrelated orphan, stale revision and editable room.')
