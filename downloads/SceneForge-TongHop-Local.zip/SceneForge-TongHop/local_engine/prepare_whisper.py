"""Explicit optional model preparation. Analysis itself stays offline."""
import argparse,os
from pathlib import Path

def main():
 parser=argparse.ArgumentParser(description='Tải model faster-whisper CPU từ Hugging Face. Không chạy khi phân tích.')
 parser.add_argument('--download',action='store_true',help='Đồng ý tải model và lưu vào dữ liệu SceneForge.')
 parser.add_argument('--model',choices=['tiny','base','small'],default='base')
 args=parser.parse_args()
 if not args.download:parser.error('Cần --download để chủ động tải model (base khoảng 150 MB). Không tải tự động.')
 target=Path(os.environ.get('SCENEFORGE_LOCAL_DATA',str(Path.home()/'.sceneforge-local')))/'models/faster-whisper'
 if (target/'model.bin').exists():raise SystemExit('Model đã có; không ghi đè model đang dùng. Di chuyển bản cũ nếu muốn thay.')
 from faster_whisper.utils import download_model
 target.mkdir(parents=True,exist_ok=True)
 try:download_model(args.model,output_dir=str(target))
 except Exception:raise SystemExit('Không tải được model. Kiểm tra Internet/quyền truy cập Hugging Face rồi chạy lại; chưa thể dùng chép lời trên máy.')
 print('Đã chuẩn bị model ở',target)
if __name__=='__main__':main()
