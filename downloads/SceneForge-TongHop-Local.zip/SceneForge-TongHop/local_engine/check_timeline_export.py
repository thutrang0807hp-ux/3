"""Actual offline FFmpeg timeline output, frame samples, audio and safe rejection."""
import os,tempfile,subprocess,time,json,io
from pathlib import Path
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-timeline-check-')
from fastapi.testclient import TestClient
from PIL import Image
from local_engine import server
H={'X-SceneForge-Local':'1'}
def run(*args):return subprocess.check_output(['ffmpeg','-v','error',*args])
with tempfile.TemporaryDirectory()as td,TestClient(server.app)as client:
 client.get('/')  # obtain the document's loopback session cookie
 td=Path(td);inputs={}
 for key,color in [('red','red'),('blue','blue')]:
  path=td/(key+'.mp4');run('-f','lavfi','-i',f'color=c={color}:s=240x426:r=30:d=3','-c:v','libx264','-pix_fmt','yuv420p','-y',str(path));inputs[key]=path.read_bytes()
 path=td/'sound.wav';run('-f','lavfi','-i','sine=frequency=440:duration=4','-y',str(path));inputs['sound']=path.read_bytes()
 im=Image.new('RGBA',(240,426));im.paste((0,255,0,255),(80,100,160,130));buf=io.BytesIO();im.save(buf,format='PNG');inputs['caption']=buf.getvalue()
 def body(transition='none',direction='left'):
  return {'width':240,'height':426,'fps':30,'normalize':True,'clips':[
   {'asset':'red','bytes':len(inputs['red']),'kind':'video','track':'v','start':0,'duration':2,'transition':transition,'direction':direction,'transitionDuration':1,'muted':True},
   {'asset':'blue','bytes':len(inputs['blue']),'kind':'video','track':'v','start':2,'duration':2,'muted':True},
   {'asset':'caption','bytes':len(inputs['caption']),'kind':'image','track':'t','start':.5,'duration':3},
   {'asset':'sound','bytes':len(inputs['sound']),'kind':'audio','track':'a','start':0,'duration':4,'volume':2,'fadeIn':.2,'fadeOut':.3}]}
 def create(model):
  r=client.post('/local-api/export/timeline',headers=H,json=model);assert r.status_code==200,r.text;id=r.json()['id']
  for k in set(r['asset']for r in model['clips']):
   result=client.put(f'/local-api/export/timeline/{id}/assets/{k}',headers=H,content=inputs[k]);assert result.status_code==200,result.text
  return id
 def render(model):
  id=create(model);r=client.post(f'/local-api/export/timeline/{id}/start',headers=H);assert r.status_code==200,r.text
  for _ in range(1500):
   j=client.get('/local-api/export/timeline/'+id).json()
   if j['state']in ('done','error','cancelled'):break
   time.sleep(.02)
  assert j['state']=='done',j
  out=td/(id+'.mp4');out.write_bytes(client.get(f'/local-api/export/timeline/{id}/file').content)
  meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(out)]));v=next(s for s in meta['streams']if s['codec_type']=='video');assert v['width']==240 and v['height']==426 and v['codec_name']=='h264';assert any(s['codec_name']=='aac'for s in meta['streams']);assert abs(float(meta['format']['duration'])-4)<.08,meta
  assert not (server.TIMELINE_EXPORT_JOBS[id]['dir']/'output.part.mp4').exists()
  return out
 def pixel(path,t,xy):
  data=run('-ss',str(t),'-i',str(path),'-frames:v','1','-f','image2pipe','-vcodec','png','-');return Image.open(io.BytesIO(data)).convert('RGB').getpixel(xy)
 for tr in ['none','fade','dissolve','slide','wipe']:
  out=render(body(tr));a=pixel(out,.25,(120,200));b=pixel(out,3,(120,200));caption=pixel(out,1,(120,115));assert a[0]>200 and a[2]<40,(tr,a);assert b[2]>200 and b[0]<40,(tr,b);assert caption[1]>200,(tr,caption)
  if tr=='dissolve':
   middle=pixel(out,2,(120,200));assert 80<middle[0]<180 and 80<middle[2]<180,middle
  if tr=='fade':assert max(pixel(out,2,(120,200)))<45
  print('PASS actual MP4:',tr)
 # Reject unsupported effects before upload or encoding, and preserve original jobs.
 bad=body();bad['clips'][0]['keyframes']=[{}];assert client.post('/local-api/export/timeline',json=bad,headers=H).status_code==400
 bad=body();bad['clips'][0]['brightness']=115;assert client.post('/local-api/export/timeline',json=bad,headers=H).status_code==400
 assert client.post('/local-api/export/timeline',json=body()).status_code==403
 bad=body();bad['clips'][0]['asset']='../../passwd';assert client.post('/local-api/export/timeline',json=bad,headers=H).status_code==400
 id=create(body());assert client.get(f'/local-api/export/timeline/{id}/file').status_code==409
 assert client.post(f'/local-api/export/timeline/{id}/cancel',headers=H).json()['state']=='cancelled';assert not list(server.TIMELINE_EXPORT_JOBS[id]['dir'].iterdir())
 # Never let an uploaded local playlist make FFmpeg open arbitrary files.
 bad=body();bad['clips']=bad['clips'][:1];payload=b'#EXTM3U\n/etc/passwd\n';bad['clips'][0]['bytes']=len(payload)
 r=client.post('/local-api/export/timeline',json=bad,headers=H);id=r.json()['id'];r=client.put(f'/local-api/export/timeline/{id}/assets/red',headers=H,content=payload);assert r.status_code==400,r.text
 client.post(f'/local-api/export/timeline/{id}/cancel',headers=H)
 print('PASS: original cut timing; audio AAC + fades/gain; static transparent captions; no realtime record; unsupported effects/paths/missing header/playlist rejected; cancel cleans temporary files.')
