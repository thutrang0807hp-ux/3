"""Canonical media capture, durable job association, import proof and disk admission."""
import json,tempfile,uuid,shutil
from pathlib import Path
from unittest.mock import patch
from fastapi import HTTPException
from .library import Library
from .request_ledger import RequestLedger
from .storage_jobs import StorageJobs

def main():
 with tempfile.TemporaryDirectory(prefix='sf-storage-jobs-')as t:
  data=Path(t);lib=Library(data);ledger=RequestLedger(data);bridge=StorageJobs(lib,ledger,data);ledger.storage=bridge
  rid='flow-'+str(uuid.uuid4());payload={'room_id':'r','scene_id':'s','kind':'video','references':[]};ledger.claim(rid,payload)
  (data/'flow-results').mkdir();output=data/'flow-results'/(rid+'.mp4');output.write_bytes(b'provider-media-fixture')
  result={'file':output.name,'mime_type':'video/mp4','kind':'video'};ledger.finish(rid,'done',result)
  assert result['result_hash']and not output.exists()and bridge.file(rid).read_bytes()==b'provider-media-fixture'
  def room(r):return {'db':'sceneforge-app-shell','store':'rooms','key':r,'value':{'id':r}}
  def workflow(r,state):return {'db':'sceneforge-workflows','store':'projects','key':r,'value':{'id':r,'cloudJobs':[{'id':rid,'state':state}],'assetEntries':[['clip',{'$sf':'blob','hash':result['result_hash'],'type':'video/mp4'}]]}}
  snap=lib.commit([room('wrong'),workflow('wrong','imported')],0)
  with lib.db()as db:assert db.execute('SELECT state FROM generation_job WHERE id=?',(rid,)).fetchone()[0]=='done'
  try:lib.lifecycle.plan('r','delete',snap['revision'],0);raise AssertionError('unowned request accepted')
  except ValueError:pass
  snap=lib.commit([room('r'),workflow('r','done')],snap['revision'])
  try:lib.lifecycle.plan('r','delete',snap['revision'],0);raise AssertionError('unimported result deleted')
  except ValueError:pass
  snap=lib.commit([room('r'),workflow('r','imported')],snap['revision'])
  with lib.db()as db:assert db.execute('SELECT state FROM generation_job WHERE id=?',(rid,)).fetchone()[0]=='imported'
  plan=lib.lifecycle.plan('r','delete',snap['revision'],0);res=lib.lifecycle.execute({**plan,'confirm':True});assert bridge.file(rid)is not None and res['protected_files']>0 # wrong-room historical reference protects the shared hash
  # History stays; no generation request is replayed by sync or cleanup.
  bridge.sync()
  with lib.db()as db:assert db.execute('SELECT state FROM generation_job WHERE id=?',(rid,)).fetchone()[0]=='imported'
  # Photo Studio stores receipts in rooms.photoDraft, not workflow projects.
  photo_id='muse-'+str(uuid.uuid4());ledger.claim(photo_id,{'room_id':'photo','kind':'video'})
  (data/'muse-results').mkdir();photo_output=data/'muse-results'/(photo_id+'.mp4');photo_output.write_bytes(b'photo-provider-media')
  photo_result={'file':photo_output.name,'mime_type':'video/mp4'};ledger.finish(photo_id,'done',photo_result)
  photo=room('photo');photo['value']['photoDraft']={'flowJobs':[{'id':photo_id,'provider':'muse','kind':'video','state':'done'}]}
  file_row={'db':'sceneforge-app-shell','store':'files','key':'photo:photo-clip:'+photo_id,'value':{'$sf':'blob','hash':photo_result['result_hash'],'type':'video/mp4'}}
  snap=lib.commit([photo,file_row],lib.snapshot()['revision'])
  try:lib.lifecycle.plan('photo','delete',snap['revision'],7);raise AssertionError('photo receipt pending accepted')
  except ValueError:pass
  photo['value']['photoDraft']['flowJobs'][0]['state']='imported'
  snap=lib.commit([photo,file_row],snap['revision'])
  with lib.db()as db:assert db.execute('SELECT state FROM generation_job WHERE id=?',(photo_id,)).fetchone()[0]=='imported'
  assert lib.lifecycle.plan('photo','delete',snap['revision'],7)['room_id']=='photo'
  old=data/'old-photo.mp4';old.write_bytes(b'old-photo');old_marker=lib.add_file(old,'video/mp4')
  old_row={**file_row,'key':'photo:photo-clip:old','value':{'$sf':'blob',**old_marker}}
  photo['value']['photoDraft']['beats']=[{'id':'beat','chosenClip':'chosen','clips':[{'id':'chosen','key':file_row['key']},{'id':'old','key':old_row['key']}]}]
  snap=lib.commit([photo,file_row,old_row],snap['revision'])
  unused=lib.lifecycle.plan('photo','unused',snap['revision'],7)
  assert old_marker['hash']in unused['candidates'],unused
  assert photo_result['result_hash']not in unused['candidates']

  photo['value']['photoDraft']['geminiJobs']=[{'id':'gchat-restored','kind':'text','state':'unknown'}]
  snap=lib.commit([photo,file_row],snap['revision']);bridge.adopt_receipts()
  with lib.db()as db:assert db.execute('SELECT room_id,state FROM generation_job WHERE id=?',('gchat-restored',)).fetchone()==('photo','unknown')
  bridge.discard('gchat-restored',True)
  rid2='muse-'+str(uuid.uuid4());ledger.claim(rid2,{'room_id':'new','kind':'video'});ledger.finish(rid2,'unknown')
  lib.lifecycle.active_job=lambda j:j==rid2
  try:bridge.discard(rid2,True);raise AssertionError('active work discarded')
  except ValueError:pass
  lib.lifecycle.active_job=lambda j:False;bridge.discard(rid2,True)
  with patch('local_engine.storage_jobs.shutil.disk_usage',return_value=shutil._ntuple_diskusage(100,90,10)):
   try:ledger.claim('flow-'+str(uuid.uuid4()),{**payload,'room_id':'fresh'});raise AssertionError('low disk submitted')
   except HTTPException as e:assert e.status_code==507
 print('PASS: result copied once into canonical store; source alias removed; import requires exact job + correct room + committed hash; unimported/unknown protected; manual discard blocked while active; low disk stops new claims; no generation replay.')
if __name__=='__main__':main()
