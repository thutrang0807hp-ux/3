"""Real FFmpeg finish/cancel + strict Gemini contract; no live key/service used."""
import os,tempfile,base64,json,time,subprocess,asyncio
from pathlib import Path
from unittest.mock import AsyncMock,patch
import httpx
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sceneforge-all-')
from fastapi.testclient import TestClient
from local_engine import server
from local_engine.video_analysis import VISUAL,MOTION
H={'X-SceneForge-Local':'1'}
with tempfile.TemporaryDirectory()as td,TestClient(server.app)as client:
 raw=Path(td)/'source.webm'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=180x320:r=12:d=1.2','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=1.2','-c:v','libvpx-vp9','-c:a','libopus','-shortest','-y',str(raw)],check=True)
 r=client.post('/local-api/export/mp4?fps=30&normalize=true&duration=1.2',headers={**H,'Content-Type':'application/octet-stream'},content=raw.read_bytes());assert r.status_code==200,r.text;id=r.json()['id']
 for _ in range(300):
  job=client.get('/local-api/export/jobs/'+id).json()
  if job['state']in ('done','error'):break
  time.sleep(.02)
 assert job['state']=='done',job
 output=Path(td)/'output.mp4';r=client.get('/local-api/export/jobs/'+id+'/file');assert r.headers['content-type']=='video/mp4';output.write_bytes(r.content)
 meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(output)]));video=next(s for s in meta['streams']if s['codec_type']=='video');assert video['codec_name']=='h264'and video['width']==180 and video['height']==320 and video['pix_fmt']=='yuv420p';assert any(s['codec_name']=='aac'for s in meta['streams']);assert 1.0<float(meta['format']['duration'])<1.6
 assert client.post('/local-api/export/mp4?duration=1',content=b'fake',headers=H).status_code==400
 assert client.post('/local-api/export/mp4?duration=600',content=raw.read_bytes(),headers=H).status_code==400
 assert client.post('/local-api/export/mp4?duration=1',content=raw.read_bytes()).status_code==403
 assert client.get('/local-api/export/jobs/../../etc/passwd/file').status_code!=200
 r=client.post('/local-api/export/mp4?duration=1.2',content=raw.read_bytes(),headers=H);assert r.status_code==200
 cancel=client.post('/local-api/export/jobs/'+r.json()['id']+'/cancel',headers=H);assert cancel.status_code==200 and cancel.json()['state']in ('cancelled','done')
 row={'start':0,'end':1.2,'description':'Một khung màu xanh.','hasPerson':False,'faceTalking':False,'hasProduct':False,'competitorLogo':None,'visual':{l:{k:''for k in VISUAL}for l in ('vi','en')},'motion':{l:{k:''for k in MOTION}for l in ('vi','en')},'promptFrame':{'vi':'Giữ khung màu xanh.','en':'Preserve the blue frame.'}}
 body={'video_data':base64.b64encode(raw.read_bytes()).decode(),'mime_type':'video/webm','duration':1.2,'scenes':[{'start':0,'end':1.2}]};server.VAULT.set_secret('gemini','test-key-never-live')
 def response(data):return httpx.Response(200,json={'candidates':[{'content':{'parts':[{'text':json.dumps(data)}]}}],'usageMetadata':{'totalTokenCount':123}})
 with patch.object(httpx.AsyncClient,'post',AsyncMock(return_value=response({'scenes':[row],'script':[]})))as mock:
  r=client.post('/local-api/ai/analyze-video',headers=H,json=body);assert r.status_code==200,r.text;assert r.json()['script']==[];assert mock.await_count==1;provider=mock.await_args.kwargs['json'];assert 'inline_data'in provider['contents'][0]['parts'][1];assert body['video_data']not in provider['contents'][0]['parts'][0]['text']
 recipe={'name':'Show sản phẩm gọn','industry':'Chung','videoType':'Show sản phẩm','tips':'Giữ cấu trúc, dùng lời mới','beats':[{'name':'Giới thiệu','role':'solution','type':'wide','start':0,'end':1.2,'purpose':'Đặt sản phẩm vào bối cảnh','example':'Đây là [sản phẩm] của bạn.'}]}
 with patch.object(httpx.AsyncClient,'post',AsyncMock(return_value=response({'scenes':[row],'script':[],'recipe':recipe})))as mock:
  result=client.post('/local-api/ai/analyze-video',headers=H,json=body);assert result.status_code==200 and result.json()['recipe']['name']==recipe['name'];assert mock.await_count==1
 for bad in [{'scenes':[dict(row,end=5)],'script':[]},{'scenes':[dict(row,visual={})],'script':[]},{'scenes':[row],'script':[{'start':0,'end':2,'original':'x','translation':'x','newText':'x','faceTalking':False}]}]:
  with patch.object(httpx.AsyncClient,'post',AsyncMock(return_value=response(bad))):assert client.post('/local-api/ai/analyze-video',headers=H,json=body).status_code==502
 assert client.post('/local-api/ai/analyze-video',headers=H,json={**body,'scenes':[{'start':.5,'end':1.2}]}).status_code==400
 assert body['video_data']not in client.get('/local-api/logs').text
 print('PASS: real FFmpeg H.264/AAC/yuv420p MP4 + normalization stage, dimensions/duration, cancel/input/origin guards; Gemini video contract validates exact scenes and speech, rejects corrupt output, keeps base64 out of text/logs. Google transport mocked; no paid provider calls.')
