"""Direct Muse web SDK adapter: encrypted sessions, one lane/account, no resend.

No copy of the uploaded application's bridge, no real account certification.
"""
import asyncio
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
import uuid

from fastapi import HTTPException
from fastapi.responses import FileResponse
from .batch_images import BatchImages
from .request_ledger import NO_RESULT, RequestConflict


class MuseProvider:
    def __init__(self, vault, data, ledger, runner=None):
        self.vault, self.data, self.ledger = vault, Path(data), ledger
        self.root = self.data / 'muse-results'
        self.root.mkdir(exist_ok=True, mode=0o700)
        self.runner = runner or self.worker
        self.tasks, self.locks, self.phases = {}, {}, {}
        self.lane = asyncio.Semaphore(3)

    def engine(self):
        root = Path(os.environ.get('SCENEFORGE_MUSE_WEB_DIRECTORY', str(self.data / 'engines/muse-web')))
        return root / 'venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')

    def accounts(self):
        return sorted([r for r in self.vault.rows('accounts') if r.get('service') == 'muse'],
                      key=lambda a: a.get('priority', 0))

    def status(self):
        rows = self.accounts()
        return {'installed': self.engine().is_file(), 'adapter': True, 'service_url': 'https://muse.ai',
                'configured': any(a.get('enabled') and a.get('session_verified') for a in rows),
                'generation_verified': bool(self.vault.secret('muse-web-generation')),
                'max_concurrency': 3, 'per_account': 1, 'automatic_retry': False,
                'accounts': rows, 'reason': 'Muse web SDK; phiên mã hóa trên máy. Chưa xác minh tài khoản Meta AI.'}

    def require_sdk(self):
        if self.runner == self.worker and not self.engine().is_file():
            raise HTTPException(409, 'Chạy local_engine/install-muse-web.bat trước; không tự cài khi gửi tác vụ.')

    def account(self, aid):
        row = next((a for a in self.accounts() if a['id'] == aid), None)
        if not row:
            raise HTTPException(404, 'Không có tài khoản Muse này.')
        return row

    def lock(self, aid):
        return self.locks.setdefault(aid, asyncio.Lock())

    async def worker(self, body):
        # Parent owns scratch state, so a cancelled/killed SDK worker cannot
        # leave plaintext cookies behind after ordinary app shutdown.
        with tempfile.TemporaryDirectory(prefix='muse-work-', dir=self.data) as directory:
            process = await asyncio.create_subprocess_exec(str(self.engine()),
                str(Path(__file__).with_name('muse_worker.py')), stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            try:
                request = {**body, '_workspace': directory}
                stdout, _ = await asyncio.wait_for(process.communicate(json.dumps(request).encode()),
                                                  1100 if body['operation'] == 'generate' else 120)
                if process.returncode or len(stdout) > 2 * 1024**2:
                    raise ValueError('worker failure')
                return json.loads(stdout)
            finally:
                if process.returncode is None:
                    process.kill()
                    await process.wait()

    async def invoke(self, row, operation, **kwargs):
        session = self.vault.secret('muse-session:' + row['id']) or {}
        if not session and operation == 'check':
            previous = self.vault.secret('account:' + row['id']) or {}
            if previous.get('cookies'):
                session = {'cookies.json': previous['cookies']}
        try:
            result = await self.runner({'operation': operation, 'session': session, **kwargs})
        except Exception:
            raise HTTPException(502, 'Chưa hoàn tất kết nối Muse. Không tự gửi lại; kiểm tra phiên và lịch sử dịch vụ.') from None
        if not result.get('ok'):
            raise HTTPException(502, 'Muse chưa hoàn tất thao tác. Không tự gửi lại; kiểm tra phiên và lịch sử dịch vụ.')
        if 'session' in result:
            self.vault.set_secret('muse-session:' + row['id'], result['session'])
        return result

    async def login(self, body: dict):
        self.require_sdk()
        email = body.get('email', '')
        if not isinstance(email, str) or not re.fullmatch(r'[^\s@]{1,100}@[^\s@]{1,100}\.[^\s@]{1,50}', email):
            raise HTTPException(400, 'Nhập email Muse hợp lệ.')
        email = email.strip().lower()
        aid = 'muse-account-' + hashlib.sha256(email.encode()).hexdigest()[:24]
        row = next((a for a in self.accounts() if a['id'] == aid), None)
        if row is None:
            row = {'id': aid, 'service': 'muse', 'name': email, 'enabled': True, 'active': False,
                   'priority': len(self.accounts()), 'credit': None, 'created_at': time.time(),
                   'successes': 0, 'failures': 0, 'state': 'unverified', 'session_verified': False}
        if self.lock(aid).locked():
            raise HTTPException(409, 'Tài khoản đang xử lý; đợi xong trước khi đổi phiên.')
        async with self.lock(aid):
            cookies = body.get('cookies')
            if cookies is not None:
                if isinstance(cookies, str):
                    if len(cookies) > 200000:
                        raise HTTPException(400, 'Cookie quá lớn.')
                    try:
                        cookies = json.loads(cookies)
                    except ValueError:
                        raise HTTPException(400, 'Cookie cần định dạng JSON xuất từ trình duyệt.')
                if isinstance(cookies, dict):
                    cookies = cookies.get('cookies')
                if not isinstance(cookies, list) or not 1 <= len(cookies) <= 100:
                    raise HTTPException(400, 'Cookie cần là danh sách JSON.')
                clean = []
                for c in cookies:
                    if not isinstance(c, dict) or not isinstance(c.get('domain'), str) or c['domain'].lstrip('.') != 'muse.ai' and not c['domain'].lstrip('.').endswith('.muse.ai'):
                        raise HTTPException(400, 'Chỉ nhận cookie thuộc muse.ai.')
                    if not isinstance(c.get('name'), str) or not isinstance(c.get('value'), str) or len(c['name']) > 200 or len(c['value']) > 16000:
                        raise HTTPException(400, 'Cookie không hợp lệ.')
                    clean.append({k: c.get(k, '/') for k in ('name', 'value', 'domain', 'path')})
                result = await self.invoke(row, 'import', cookies=clean)
                row.update(state='ready', session_verified=True, checked_at=time.time())
            else:
                # Preserve the previous verified session if sending an OTP fails.
                result = await self.invoke(row, 'login_start', email=email)
                session = self.vault.secret('muse-session:' + aid) or {}
                session['pending_at'] = time.time()
                self.vault.set_secret('muse-session:' + aid, session)
                row.update(state='awaiting_login', session_verified=False, active=False)
            self.vault.put('accounts', row)
        return {'id': aid, 'awaiting_otp': cookies is None, 'account': row}

    async def confirm(self, body: dict):
        self.require_sdk()
        row = self.account(body.get('id'))
        otp = body.get('otp')
        if not isinstance(otp, str) or not re.fullmatch(r'[0-9]{4,10}', otp):
            raise HTTPException(400, 'Nhập mã OTP hợp lệ.')
        session = self.vault.secret('muse-session:' + row['id']) or {}
        if not session.get('pending') or time.time() - session.get('pending_at', 0) > 600:
            raise HTTPException(409, 'Lượt đăng nhập đã hết hạn; gửi lại OTP.')
        async with self.lock(row['id']):
            await self.invoke(row, 'login_confirm', otp=otp)
            row.update(state='ready', session_verified=True, checked_at=time.time())
            self.vault.put('accounts', row)
        return {'account': row, 'message': 'Đã kiểm tra phiên; chưa xác minh hạn mức hoặc tạo video.'}

    async def check(self, aid):
        self.require_sdk()
        row = self.account(aid)
        async with self.lock(aid):
            await self.invoke(row, 'check')
            row.update(state='ready', session_verified=True, checked_at=time.time())
            self.vault.put('accounts', row)
        return {'account': row, 'message': 'Phiên hợp lệ; không suy ra số dư hoặc khả năng tạo video.'}

    @staticmethod
    def valid_id(rid):
        if not isinstance(rid, str) or not re.fullmatch(r'muse-[a-f0-9-]{36}', rid):
            raise HTTPException(400, 'Mã tác vụ Muse không hợp lệ.')
        try:
            uuid.UUID(rid[5:])
        except ValueError:
            raise HTTPException(400, 'Mã tác vụ Muse không hợp lệ.')

    def lookup(self, rid):
        self.valid_id(rid)
        with self.ledger.connect() as db:
            row = db.execute('SELECT state,result FROM request WHERE id=?', (rid,)).fetchone()
        if not row:
            raise HTTPException(404, 'Không có tác vụ Muse này.')
        return {'request_id': rid, 'state': row[0], 'phase': 'queued_or_running' if rid in self.tasks else row[0],
                'result': json.loads(row[1]) if row[0] == 'done' else None, 'automatic_retry': False}

    async def submit(self, body):
        self.require_sdk()
        if body.get('confirm_send') is not True:
            raise HTTPException(409, 'Rà prompt và xác nhận gửi Muse trước khi tạo.')
        rid = body.get('request_id')
        self.valid_id(rid)
        prompt, refs = body.get('prompt'), body.get('references', [])
        if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 20000 or body.get('kind') != 'video':
            raise HTTPException(400, 'Hiện nối tạo video Muse; prompt tối đa 20.000 ký tự.')
        if not isinstance(refs, list) or len(refs) > 8 or sum(BatchImages.decode_image(r) for r in refs) > 24 * 1024**2:
            raise HTTPException(400, 'Tối đa 8 ảnh, tổng 24 MB.')
        rows = [a for a in self.accounts() if a.get('enabled') and a.get('session_verified')]
        chosen = body.get('account_id')
        if chosen:
            rows = [a for a in rows if a['id'] == chosen]
        if not rows:
            raise HTTPException(409, 'Kết nối và kiểm tra phiên Muse trước khi tạo.')
        # An explicit auto selection spreads queued work without rotating a failed
        # submission to another account or sending the prompt twice.
        row = min(rows, key=lambda a: sum(v == a['id'] for v in self.phases.values())) if not chosen else rows[0]
        payload = {'prompt': prompt, 'references': refs, 'account_id': chosen or 'auto',
                   'room_id': str(body.get('room_id', ''))[:100], 'scene_id': str(body.get('scene_id', ''))[:100]}
        if len(self.tasks) >= 30:
            raise HTTPException(429, 'Hàng chờ Muse đầy.')
        try:
            _, cached = self.ledger.claim(rid, payload)
        except (RequestConflict, ValueError) as e:
            raise HTTPException(409, str(e))
        if cached is not NO_RESULT:
            return self.lookup(rid)
        self.phases[rid] = row['id']
        self.tasks[rid] = asyncio.create_task(self.run(rid, row['id'], payload))
        self.tasks[rid].add_done_callback(lambda task: self.tasks.pop(rid, None))
        return self.lookup(rid)

    async def run(self, rid, aid, payload):
        state, result, dispatched = 'failed', None, False
        tmp = self.root / (rid + '.partial')
        try:
            # Acquire the account before a global slot: waiting jobs from one
            # account must not occupy all slots and starve other accounts.
            async with self.lock(aid), self.lane:
                row = self.account(aid)
                if not row.get('enabled') or not row.get('session_verified'):
                    return
                dispatched = True
                await self.invoke(row, 'generate', prompt=payload['prompt'], references=payload['references'], output=str(tmp))
                if not tmp.is_file() or not 0 < tmp.stat().st_size <= 500 * 1024**2:
                    raise ValueError('invalid result')
                from .machine_checks import run_command
                rc, output, _ = await run_command('ffprobe', '-v', 'error', '-protocol_whitelist', 'file,pipe',
                    '-show_streams', '-show_format', '-of', 'json', str(tmp), timeout=30)
                metadata = json.loads(output) if not rc else {}
                if rc or not any(s.get('codec_type') == 'video' for s in metadata.get('streams', [])):
                    raise ValueError('invalid video')
                format_name = metadata.get('format', {}).get('format_name', '')
                if 'mp4' in format_name or 'mov' in format_name:
                    extension, mime = '.mp4', 'video/mp4'
                elif 'webm' in format_name:
                    extension, mime = '.webm', 'video/webm'
                else:
                    raise ValueError('unsupported video container')
                name = rid + extension
                with tmp.open('rb') as source:
                    digest = hashlib.file_digest(source, 'sha256').hexdigest()
                size = tmp.stat().st_size
                os.replace(tmp, self.root / name)
                result = {'file': name, 'mime_type': mime, 'origin': 'muse', 'model': 'muse-web',
                          'kind': 'video', 'bytes': size, 'sha256': digest, 'account_id': aid,
                          'room_id': payload['room_id'], 'scene_id': payload['scene_id'], 'cost': None}
                state = 'done'
                self.vault.set_secret('muse-web-generation', {'at': time.time(), 'request_id': rid})
                current = self.account(aid)
                current['successes'] = current.get('successes', 0) + 1
                self.vault.put('accounts', current)
        except asyncio.CancelledError:
            state = 'unknown' if dispatched else 'failed'
            raise
        except Exception:
            state = 'unknown' if dispatched else 'failed'
        finally:
            tmp.unlink(missing_ok=True)
            self.phases.pop(rid, None)
            self.ledger.finish(rid, state, result)
            self.vault.put('logs', {'id': rid, 'service': 'muse', 'kind': 'Muse video', 'state': state,
                'account_id': aid, 'room_id': payload['room_id'], 'scene_id': payload['scene_id'],
                'at': time.time(), 'cost': None, 'code': 'DONE' if state == 'done' else 'CHECK_BEFORE_RESUBMIT'})

    def file(self, rid):
        record = self.lookup(rid)
        if record['state'] != 'done':
            raise HTTPException(409, 'Chưa có clip được lưu; không tự gửi lại.')
        name = record['result'].get('file')
        if name not in {rid + '.mp4', rid + '.webm'}:
            raise HTTPException(409, 'Tên tệp kết quả chưa hợp lệ.')
        file = self.root / name
        if not file.is_file():
            raise HTTPException(409, 'Chưa có clip được lưu; không tự gửi lại.')
        return FileResponse(file, media_type=record['result']['mime_type'], filename=file.name)

    def remove(self, aid):
        if aid in self.phases.values() or self.lock(aid).locked():
            raise HTTPException(409, 'Đợi tài khoản hoàn tất tác vụ trước khi xóa phiên.')
        self.vault.delete_secret('muse-session:' + aid)

    async def close(self):
        tasks = list(self.tasks.values())
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)


def install_muse_provider(app, vault, data, ledger):
    provider = MuseProvider(vault, data, ledger)
    app.get('/local-api/muse/status')(provider.status)
    app.post('/local-api/muse/login')(provider.login)
    app.post('/local-api/muse/confirm')(provider.confirm)
    @app.post('/local-api/muse/jobs')
    async def submit(body: dict):
        return await provider.submit(body)
    app.get('/local-api/muse/jobs/{rid}')(provider.lookup)
    app.get('/local-api/muse/files/{rid}')(provider.file)
    return provider
