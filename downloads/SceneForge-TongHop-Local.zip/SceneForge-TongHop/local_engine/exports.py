"""Bounded loopback FFmpeg finishing jobs. No shell, no arbitrary paths/URLs."""
import asyncio,json,re,shutil,time,uuid
from pathlib import Path
from .local_jobs import LocalJobs,JobRegistry,job_room
from fastapi import HTTPException,Request
from fastapi.responses import FileResponse

def install_exports(app,data,lock=None,store=None):
 folder=Path(data)/'exports';folder.mkdir(exist_ok=True);jobs=JobRegistry(store or LocalJobs(data),'finishing');lock=lock or asyncio.Lock()
 # Only expire the app's own temporary conversion files, never project folders.
 for p in folder.iterdir():
  if p.is_file()and re.fullmatch(r'[0-9a-f]{32}\.(source|mp4)',p.name)and time.time()-p.stat().st_mtime>3600:p.unlink(missing_ok=True)
 for j in jobs.values():
  j.update(input=folder/(j['id']+'.source'),output=folder/(j['id']+'.mp4'))
  if j['state']=='done'and not j['output'].is_file():j.update(state='error',error='MP4 tạm không còn trên máy. Bản đã lưu trong thư viện không bị ảnh hưởng.')
 async def process(job):
  async with lock:
   if job['state']=='cancelled':return
   job['state']='running'
   try:
    probe=await asyncio.create_subprocess_exec(shutil.which('ffprobe'),'-v','error','-protocol_whitelist','file,pipe','-show_streams','-show_format','-of','json',str(job['input']),stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
    job['process']=probe;stdout,_=await asyncio.wait_for(probe.communicate(),20)
    if probe.returncode!=0:raise ValueError('Không đọc được video đã gửi.')
    meta=json.loads(stdout);v=next((s for s in meta['streams']if s.get('codec_type')=='video'),None);duration=float(meta['format'].get('duration')or (v or {}).get('duration')or job['duration'])
    if not v or not 0<duration<=121 or int(v['width'])*int(v['height'])>8_400_000:raise ValueError('Video cần tối đa 2 phút, khung hình tối đa 8,4 triệu điểm ảnh.')
    job['duration']=duration
    args=[shutil.which('ffmpeg'),'-hide_banner','-loglevel','error','-nostdin','-protocol_whitelist','file,pipe','-i',str(job['input']),'-map','0:v:0','-map','0:a:0?','-vf','scale=trunc(iw/2)*2:trunc(ih/2)*2,setsar=1','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-r',str(job['fps']),'-c:a','aac','-b:a','192k']
    if job['normalize'] and any(s.get('codec_type')=='audio'for s in meta['streams']):args+=['-af','loudnorm=I=-16:TP=-1.5:LRA=11']
    args+=['-movflags','+faststart','-progress','pipe:1','-nostats','-y',str(job['output'])]
    p=await asyncio.create_subprocess_exec(*args,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE);job['process']=p
    async def progress():
     while line:=await p.stdout.readline():
      if line.startswith(b'out_time_us='):
       try:job['progress']=min(99,round(float(line.split(b'=')[1])/1e6/duration*100))
       except ValueError:pass
    # Drain stderr concurrently so neither pipe can block.
    await asyncio.wait_for(asyncio.gather(progress(),p.stderr.read(),p.wait()),600)
    if job['state']=='cancelled':return
    if p.returncode or not job['output'].is_file()or job['output'].stat().st_size<500:raise ValueError('FFmpeg không tạo được MP4. Bản ghi trình duyệt vẫn được giữ để tải dự phòng.')
    job.update(state='done',progress=100,bytes=job['output'].stat().st_size)
   except asyncio.CancelledError:
    job['state']='cancelled';raise
   except Exception as e:
    if job['state']!='cancelled':job.update(state='error',error=str(e)if isinstance(e,ValueError)else 'Không hoàn tất FFmpeg; hãy kiểm tra động cơ và dung lượng máy.')
   finally:
    p=job.pop('process',None)
    if p and p.returncode is None:p.kill();await p.wait()
    job['input'].unlink(missing_ok=True)
    if job['state']!='done':job['output'].unlink(missing_ok=True)
 def clean():
  for key,j in list(jobs.items()):
   if j['state']in ('done','error','cancelled')and time.time()-j['created']>3600:
    j['input'].unlink(missing_ok=True);j['output'].unlink(missing_ok=True);jobs.pop(key,None)
 def public(j):return {k:j.get(k)for k in ('id','state','progress','error','bytes','normalize','fps','duration')}
 def job_for(id):
  if id not in jobs:raise HTTPException(404,'Không còn lượt xuất này.')
  return jobs[id]
 @app.get('/local-api/export/capabilities')
 async def capabilities():return {'available':bool(shutil.which('ffmpeg')and shutil.which('ffprobe')),'engine':'FFmpeg','finishing_only':False,'timeline':True,'timeline_max_bytes':512*1024*1024,'timeline_max_seconds':600,'max_bytes':100*1024*1024,'max_seconds':120}
 @app.post('/local-api/export/mp4')
 async def start(request:Request,fps:int=30,normalize:bool=True,duration:float=0,room_id:str=''):
  clean()
  if not shutil.which('ffmpeg')or not shutil.which('ffprobe'):raise HTTPException(409,'Chưa cài FFmpeg và ffprobe trên máy.')
  if fps not in (30,60)or not 0<duration<=120:raise HTTPException(400,'Chỉ hỗ trợ 30/60 fps và bản dựng tối đa 2 phút.')
  if sum(j['state']in ('uploading','queued','running')for j in jobs.values())>=2:raise HTTPException(409,'Đã có hai lượt FFmpeg. Đợi một lượt xong trước.')
  try:length=int(request.headers.get('content-length','0'))
  except ValueError:length=0
  limit=100*1024*1024
  if not 0<length<=limit:raise HTTPException(413,'Bản ghi cần nhỏ hơn 100 MB.')
  if shutil.disk_usage(folder).free<length*3+64*1024*1024:raise HTTPException(507,'Ổ chứa companion không đủ chỗ để xuất MP4.')
  try:room_id=job_room(room_id)
  except ValueError as e:raise HTTPException(400,str(e))
  id=uuid.uuid4().hex;job={'id':id,'state':'uploading','progress':0,'created':time.time(),'room_id':room_id,'input':folder/(id+'.source'),'output':folder/(id+'.mp4'),'fps':fps,'normalize':normalize,'duration':duration};job=jobs.create(job)
  try:
   size=0
   with job['input'].open('wb')as f:
    async for chunk in request.stream():
     size+=len(chunk)
     if size>limit or size>length:raise HTTPException(413,'Bản ghi vượt giới hạn.')
     f.write(chunk)
   if size!=length or size<12:raise HTTPException(400,'Bản ghi chưa truyền đủ.')
   with job['input'].open('rb')as f:magic=f.read(12)
   if magic[:4]!=b'\x1aE\xdf\xa3'and magic[4:8]!=b'ftyp':raise HTTPException(400,'Chỉ nhận bản ghi MP4/WebM, không nhận đường dẫn.')
   job['state']='queued';job['task']=asyncio.create_task(process(job));return public(job)
  except BaseException:
   jobs.pop(id,None);job['input'].unlink(missing_ok=True);raise
 @app.get('/local-api/export/jobs/{id}')
 async def status(id:str):return public(job_for(id))
 @app.post('/local-api/export/jobs/{id}/cancel')
 async def cancel(id:str):
  j=job_for(id)
  if j['state']not in ('done','error','cancelled'):
   j['state']='cancelled';j['task'].cancel()
   try:await j['task']
   except asyncio.CancelledError:pass
   j['input'].unlink(missing_ok=True);j['output'].unlink(missing_ok=True)
  return public(j)
 @app.get('/local-api/export/jobs/{id}/file')
 async def file(id:str):
  j=job_for(id)
  if j['state']!='done':raise HTTPException(409,'MP4 chưa hoàn tất.')
  if not j['output'].is_file():
   j.update(state='error',error='MP4 tạm đã hết hạn hoặc bị chuyển khỏi máy.')
   raise HTTPException(410,j['error'])
  return FileResponse(j['output'],media_type='video/mp4',filename='sceneforge.mp4')
 return jobs
