@echo off
cd /d "%~dp0.."
python -c "import sys;sys.exit(0 if sys.version_info[:2] >= (3,11) else 1)"
if errorlevel 1 (
 echo Gemini web SDK requires Python 3.11 or newer. Install Python 3.11/3.12 and retry.
 pause
 exit /b 1
)
python -m local_engine.setup_optional_repos gemini
if errorlevel 1 (
 echo Setup did not finish. Read the error above; existing app data is preserved.
 pause
 exit /b 1
)
echo Gemini web SDK installed in an isolated environment. No model download.
echo Google login and automatic SceneForge send/receive are not enabled by this installer.
pause
