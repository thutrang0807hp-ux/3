"""Actual CPU scene/OCR/frame operations; no Google/Flow calls or model downloads."""
import os,tempfile,time,subprocess,base64,json
from pathlib import Path
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-cpu-test-')
from fastapi.testclient import TestClient
from local_engine import server
H={'X-SceneForge-Local':'1'}
with tempfile.TemporaryDirectory()as d,TestClient(server.app)as c:
 c.get('/')  # obtain the document's loopback session cookie
 path=Path(d)/'input.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=white:s=360x640:r=30:d=1','-f','lavfi','-i','color=blue:s=360x640:r=30:d=1','-filter_complex',"[0:v]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text=BRAND:fontsize=38:fontcolor=black:x=80:y=220[a];[a][1:v]concat=n=2:v=1:a=0",'-c:v','libx264','-y',str(path)],check=True)
 body={'video_data':base64.b64encode(path.read_bytes()).decode(),'mime_type':'video/mp4','duration':2,'ocr':True}
 assert c.post('/local-api/analysis/local/jobs',json=body).status_code==403
 caps=c.get('/local-api/analysis/local/capabilities').json();assert caps['available']and caps['ocr'],caps
 r=c.post('/local-api/analysis/local/jobs',json={**body,'threshold':None},headers=H);assert r.status_code==400
 r=c.post('/local-api/analysis/local/jobs',json={**body,'transcribe':True},headers=H);assert r.status_code==409
 r=c.post('/local-api/analysis/local/jobs',json=body,headers=H);assert r.status_code==200,r.text
 id=r.json()['id'];assert c.post('/local-api/analysis/local/jobs',json=body,headers=H).status_code==409
 for _ in range(1200):
  job=c.get('/local-api/analysis/local/jobs/'+id).json()
  if job['state']in ('done','error'):break
  time.sleep(.05)
 assert job['state']=='done',job
 r=job['result'];assert len(r['scenes'])==2,r['cuts'];assert abs(r['cuts'][1]-1)<=1/24+.001,r['cuts'];assert r['provider_requests']==0 and not r['transcript'];assert r['speech']['state']=='not_requested'
 observed=r['scenes'][0];assert any('BRAND'in o['text'].upper()for o in observed['ocr']),observed['ocr']
 polygon=observed['ocr'][0]['polygon'];response=c.post('/local-api/analysis/local/clean-frame',headers=H,json={'image':observed['thumbs'][0],'polygons':[polygon]});assert response.status_code==200,response.text;assert response.json()['needs_review']
 assert c.post('/local-api/analysis/local/clean-frame',headers=H,json={'image':observed['thumbs'][0],'polygons':[[[0,0],[1,0],[1,1],[0,1]]]}).status_code==400
 assert c.post('/local-api/analysis/local/jobs',json={**body,'video_data':'bad'},headers=H).status_code==400
 assert not list((server.DATA/'cpu-analysis').glob('job-*'))
 r=c.post('/local-api/analysis/local/jobs',json=body,headers=H);assert r.status_code==200
 result=c.post('/local-api/analysis/local/jobs/'+r.json()['id']+'/cancel',json={},headers=H);assert result.status_code==200 and result.json()['state']=='cancelled'
 assert not list((server.DATA/'cpu-analysis').glob('job-*'))
 Path('/tmp/sceneforge-cpu-test-result.json').write_text(json.dumps(job,ensure_ascii=False))
 print('PASS actual CPU scene cut at 1s within one 24-fps proxy frame, real RapidOCR BRAND boxes, OpenCV inpaint review copy, no whisper model auto-download, bad input/POST guards, single job, cancellation and temp cleanup. Synthetic fixture; not D5/D6/D7 real user-video certification.')
