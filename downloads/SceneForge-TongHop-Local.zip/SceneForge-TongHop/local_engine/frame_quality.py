"""Measure an actual supplied image, keep image bytes outside the report and never upscale here."""
import base64,io,math,unicodedata,json,asyncio
from fastapi import HTTPException

def normalized(text):return ''.join(c for c in unicodedata.normalize('NFKD',text).casefold()if c.isalnum())
def measure(body):
 encoded=body.get('image');label=body.get('expected_label','');required=body.get('label_required',False)
 if not isinstance(encoded,str)or len(encoded)>22*1024**2 or not encoded.startswith(('data:image/jpeg;base64,','data:image/png;base64,'))or not isinstance(label,str)or len(label)>200 or type(required)is not bool:raise HTTPException(400,'Cần ảnh JPEG/PNG tối đa 15 MB và nhãn đối chiếu tối đa 200 ký tự.')
 try:
  raw=base64.b64decode(encoded.split(',',1)[1],validate=True)
  from PIL import Image
  with Image.open(io.BytesIO(raw))as im:
   width,height=im.size
   if width*height>16000000 or max(width,height)>8192:raise ValueError()
   im.verify()
  import cv2,numpy as np
  image=cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_COLOR)
  if image is None:raise ValueError()
 except ImportError:raise HTTPException(409,'OpenCV chưa sẵn sàng; cài requirements-cpu.txt trước khi kiểm ảnh khung.')
 except Exception:raise HTTPException(400,'Ảnh không hợp lệ hoặc vượt 16 triệu điểm ảnh.')
 gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY);scale=min(1,1024/max(width,height));small=cv2.resize(gray,(max(1,round(width*scale)),max(1,round(height*scale))));sharpness=float(cv2.Laplacian(small,cv2.CV_64F).var());threshold=50.0
 resolution=max(width,height)>=2048 and width*height>=2000000;words=[];label_state='not_requested';notes=[]
 if required or label.strip():
  if not label.strip():label_state='missing_expected'
  else:
   try:
    from rapidocr_onnxruntime import RapidOCR
    ocr=RapidOCR(intra_op_num_threads=2,inter_op_num_threads=1);result,_=ocr(image)
    words=[{'text':str(text)[:500],'confidence':round(float(score),4)}for box,text,score in (result or [])[:100]if score>=.6]
    expected=normalized(label);observed=normalized(' '.join(w['text']for w in words));label_state='matched'if expected and expected in observed else'mismatch'if words else'unreadable'
   except ImportError:label_state='unavailable'
   except Exception:label_state='error'
 if not resolution:notes.append('Chưa đủ 2K theo kích thước thật; không tự coi tên file là đã nâng 2K.')
 if sharpness<threshold:notes.append('Khung hơi mờ / ít chi tiết; ngưỡng tạm cần rà thực tế.')
 if label_state not in ('matched','not_requested'):notes.append('Nhãn có thể bị méo hoặc chưa xác minh được; rà chữ gốc.')
 return {'version':1,'width':width,'height':height,'bytes':len(raw),'sha256':__import__('hashlib').sha256(raw).hexdigest(),'resolution_state':'2k'if resolution else'below_2k','sharpness':round(sharpness,3),'sharpness_threshold':threshold,'threshold_calibrated':False,'sharpness_state':'sharp'if sharpness>=threshold else'blur','label_state':label_state,'expected_label':label,'ocr':words,'warnings':notes,'can_quick_approve':resolution and sharpness>=threshold and label_state in ('matched','not_requested'),'note':'2K là kích thước ảnh, chưa chứng minh dịch vụ đã upscale. OCR khớp chữ không chứng minh hình dạng/nhãn/mặt hoàn hảo. Không nén, sửa hay ghi đè tệp nguồn.'}

def install_frame_quality(app):
 lock=asyncio.Lock()
 @app.post('/local-api/analysis/frame-check')
 async def check(body:dict):
  if lock.locked():raise HTTPException(409,'Đang kiểm một ảnh khung; chờ xong rồi thử.')
  async with lock:return await asyncio.to_thread(measure,body)
