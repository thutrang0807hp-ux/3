"""Owned account-pinning extension around the pinned Flow2API checkout.

Run with the engine's Python, --source <checkout>. No vendor code is copied.
"""
import argparse
from contextvars import ContextVar
import json
from pathlib import Path
import sys

PIN = ContextVar('sceneforge_flow_account', default=None)


def extend(engine):
    from fastapi import Depends, HTTPException
    from src.core.auth import verify_api_key_header
    from src.core.config import config
    original = engine.token_manager.get_active_tokens
    async def scoped_tokens():
        rows = await original()
        selected = PIN.get()
        return rows if selected is None else [r for r in rows if r.id == selected]
    engine.token_manager.get_active_tokens = scoped_tokens

    class PinMiddleware:
        def __init__(self, app):
            self.app = app
        async def __call__(self, scope, receive, send):
            if scope['type'] != 'http' or scope.get('path') != '/v1/chat/completions':
                return await self.app(scope, receive, send)
            headers = dict(scope.get('headers', []))
            raw = headers.get(b'x-sceneforge-account', b'')
            selected = int(raw) if raw.isdigit() else None
            token = PIN.set(selected)
            async def tagged(message):
                if message['type'] == 'http.response.start' and selected is not None:
                    message['headers'] = list(message.get('headers', [])) + [(b'x-sceneforge-account', str(selected).encode())]
                await send(message)
            try:
                await self.app(scope, receive, tagged)
            finally:
                PIN.reset(token)
    engine.app.add_middleware(PinMiddleware)

    @engine.app.get('/sceneforge/accounts')
    async def accounts(key=Depends(verify_api_key_header)):
        rows = await engine.token_manager.get_all_tokens()
        return {'protocol': 'sceneforge-account-pin-v1', 'single_attempt': config.flow_max_retries == 1,
                'accounts': [{'id': r.id, 'name': r.email or r.name or str(r.id), 'enabled': bool(r.is_active)} for r in rows]}

    @engine.app.post('/sceneforge/accounts')
    async def add(body: dict, key=Depends(verify_api_key_header)):
        cookies = body.get('cookies')
        if not isinstance(cookies, list) or not 1 <= len(cookies) <= 200:
            raise HTTPException(400, 'Cookie list required')
        clean = []
        for c in cookies:
            domain = str(c.get('domain', '')).lstrip('.') if isinstance(c, dict) else ''
            if domain in ('google.com', 'labs.google', 'flow.google.com') or domain.endswith('.google.com') or domain.endswith('.labs.google'):
                if isinstance(c.get('name'), str) and isinstance(c.get('value'), str) and len(c['value']) <= 16000:
                    clean.append(c)
        if not clean:
            raise HTTPException(400, 'No Flow/Google session')
        try:
            token = await engine.token_manager.add_token(st='', google_cookies=json.dumps(clean),
                        remark='SceneForge', image_concurrency=1, video_concurrency=1, auto_refresh_enabled=False)
            await engine.concurrency_manager.reset_token(token.id, image_concurrency=1, video_concurrency=1)
            return {'id': token.id}
        except Exception:
            raise HTTPException(409, 'Flow session could not be imported; no generation sent') from None

    @engine.app.post('/sceneforge/accounts/{aid}/check')
    async def check(aid: int, key=Depends(verify_api_key_header)):
        row = await engine.token_manager.get_token(aid)
        if row is None or not row.is_active:
            return {'ok': False, 'accepted': False, 'reason': 'auth'}
        try:
            valid = await engine.token_manager.ensure_valid_token(row)
            if not valid:
                return {'ok': False, 'accepted': False, 'reason': 'auth'}
            balance = await engine.token_manager._get_credits_for_token(valid, valid.at)
            credit = balance.get('credits')
            if type(credit) not in (int, float) or credit < 0:
                credit = None
            return {'ok': True, 'credit': credit, 'checked': True}
        except Exception:
            return {'ok': False, 'accepted': None, 'reason': 'unknown'}
    @engine.app.delete('/sceneforge/accounts/{aid}')
    async def remove(aid: int, key=Depends(verify_api_key_header)):
        if await engine.concurrency_manager.get_video_inflight(aid) or await engine.concurrency_manager.get_image_inflight(aid):
            raise HTTPException(409, 'Account has active work')
        await engine.token_manager.delete_token(aid)
        return {'ok': True}
    return engine.app


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.source.resolve()))
    from src import main as engine
    from src.core.config import config
    if config.server_host != '127.0.0.1' or config.flow_max_retries != 1:
        raise SystemExit('Flow requires loopback and max_retries=1 before account-pinned service can start')
    import uvicorn
    uvicorn.run(extend(engine), host='127.0.0.1', port=config.server_port, access_log=False)
