"""User-triggered, provider-free checks using real FFmpeg output on this machine."""
import asyncio,importlib.metadata,json,platform,shutil,tempfile,time
from pathlib import Path
from fastapi import HTTPException

async def run_command(*args,timeout=20):
 process=await asyncio.create_subprocess_exec(*args,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
 try:
  out,err=await asyncio.wait_for(process.communicate(),timeout)
  return process.returncode,out,err
 finally:
  if process.returncode is None:process.kill();await process.wait()

async def measure_machine(data):
 start=time.perf_counter();checks=[];disk=shutil.disk_usage(data)
 checks.append({'id':'storage','state':'passed'if disk.free>=32*1024**2 else 'failed','name':'Ổ chứa dữ liệu app','scope':'Không phải ổ dự án nếu bạn chọn thư mục khác.','measurements':{'free_bytes':disk.free}})
 def package_version(name):
  try:return importlib.metadata.version(name)
  except importlib.metadata.PackageNotFoundError:return None
 packages={name:package_version(name)for name in ('vieneu','flow2api','muse2api')}
 for name,version in packages.items():checks.append({'id':name,'state':'installed'if version else 'missing','name':name,'scope':'Chỉ kiểm tra có gói SDK; chưa chạy model, đăng nhập hoặc tạo clip.','measurements':{'installed_version':version}})
 ffmpeg,probe=shutil.which('ffmpeg'),shutil.which('ffprobe')
 if not ffmpeg or not probe:checks.append({'id':'mp4','state':'unavailable','name':'Xuất MP4 thử','scope':'Cần cả FFmpeg và ffprobe trong PATH.'})
 elif disk.free<32*1024**2:checks.append({'id':'mp4','state':'unavailable','name':'Xuất MP4 thử','scope':'Ổ chứa app còn dưới 32 MB; chưa tạo tệp thử.'})
 else:
  encode_start=time.perf_counter()
  try:
   with tempfile.TemporaryDirectory(prefix='machine-check-',dir=data)as work:
    path=Path(work)/'test.mp4';code,_,err=await run_command(ffmpeg,'-hide_banner','-loglevel','error','-nostdin','-f','lavfi','-i','color=c=blue:s=180x320:r=30:d=1','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=1','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p','-c:a','aac','-shortest','-movflags','+faststart','-y',str(path))
    if code:raise ValueError('FFmpeg không mã hóa được H.264/AAC. Kiểm tra bản cài có libx264 và AAC.')
    code,out,_=await run_command(probe,'-v','error','-show_streams','-show_format','-of','json',str(path),timeout=10)
    if code:raise ValueError('ffprobe không đọc được MP4 vừa tạo.')
    meta=json.loads(out);video=next((s for s in meta.get('streams',[])if s.get('codec_type')=='video'),{});audio=next((s for s in meta.get('streams',[])if s.get('codec_type')=='audio'),{});duration=float(meta['format']['duration'])
    if video.get('codec_name')!='h264'or audio.get('codec_name')!='aac'or(video.get('width'),video.get('height'))!=(180,320)or video.get('pix_fmt')!='yuv420p'or not .9<=duration<=1.2:raise ValueError('MP4 thử không đúng codec, kích thước hoặc thời lượng yêu cầu.')
    code,_,_=await run_command(ffmpeg,'-v','error','-nostdin','-i',str(path),'-f','null','-',timeout=10)
    if code:raise ValueError('Không giải mã trọn vẹn được MP4 vừa tạo.')
    checks.append({'id':'mp4','state':'passed','name':'Xuất và đọc MP4 thật','scope':'Video tổng hợp 1 giây trên máy hiện tại; chưa chứng nhận timeline dài hoặc Windows nếu máy này dùng hệ điều hành khác.','measurements':{'width':180,'height':320,'video_codec':video['codec_name'],'audio_codec':audio['codec_name'],'pixel_format':video['pix_fmt'],'duration_seconds':duration,'bytes':path.stat().st_size,'test_seconds':round(time.perf_counter()-encode_start,3)}})
  except (ValueError,OSError,asyncio.TimeoutError,json.JSONDecodeError,KeyError)as e:
   checks.append({'id':'mp4','state':'failed','name':'Xuất MP4 thử','scope':str(e)if isinstance(e,ValueError)else 'Kiểm tra không hoàn tất. Xem FFmpeg, dung lượng và quyền ghi của app.'})
 return {'version':1,'at':time.time(),'environment':{'system':platform.system(),'machine':platform.machine(),'python':platform.python_version()},'checks':checks,'elapsed_seconds':round(time.perf_counter()-start,3),'provider_requests':0,'note':'Không gọi Google, Flow, Muse hoặc TTS; không cài gói, tải model hay đọc key/cookie. Tệp thử được xóa sau kiểm tra.'}

def install_machine_checks(app,vault,data):
 lock=asyncio.Lock()
 @app.post('/local-api/checks/self-test')
 async def run(body:dict):
  if lock.locked():raise HTTPException(409,'Đang kiểm tra máy. Chờ kết quả hiện tại, không gửi thêm lượt.')
  async with lock:
   report=await measure_machine(data);vault.set_secret('machine-check-last',report);return report
 @app.get('/local-api/checks/last')
 async def last():return {'report':vault.secret('machine-check-last')}
