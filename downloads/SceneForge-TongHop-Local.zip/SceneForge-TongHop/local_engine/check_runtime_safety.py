"""No real providers: session attacks, migration rollback, duplicate requests, OS lock."""
import asyncio,json,os,socket,sqlite3,subprocess,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch,AsyncMock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from local_engine.schema import migrate
from local_engine.request_ledger import RequestLedger,RequestConflict
from local_engine.instance import Instance,listen
with tempfile.TemporaryDirectory(prefix='Sản phẩm mới ',dir='/tmp')as temp:
 root=Path(temp);dbpath=root/'old.sqlite'
 db=sqlite3.connect(dbpath);db.execute('CREATE TABLE keep(value TEXT)');db.execute("INSERT INTO keep VALUES('nguyên vẹn')");db.commit();db.close()
 try:migrate(dbpath,['CREATE TABLE added(id TEXT)','INVALID SQL'])
 except sqlite3.Error:pass
 else:raise AssertionError('migration should fail')
 with sqlite3.connect(dbpath)as db:
  assert db.execute('PRAGMA user_version').fetchone()[0]==0
  assert db.execute('SELECT * FROM keep').fetchone()[0]=='nguyên vẹn'
  assert not db.execute("SELECT 1 FROM sqlite_master WHERE name='added'").fetchone()
 assert list((root/'schema-backups').glob('*.sqlite'))
 migrate(dbpath,['CREATE TABLE added(id TEXT)'])
 with sqlite3.connect(dbpath)as db:assert db.execute('PRAGMA user_version').fetchone()[0]==1;db.execute('PRAGMA user_version=99')
 try:migrate(dbpath,['DELETE FROM keep'])
 except RuntimeError:pass
 else:raise AssertionError('future schema accepted')
 with sqlite3.connect(dbpath)as db:assert db.execute('SELECT count(*) FROM keep').fetchone()[0]==1
 from local_engine.library import Library
 library_data=root/'library-data';library_data.mkdir();library=Library(library_data)
 source=root/'source.bin';source.write_bytes(b'old referenced asset');asset=library.add_file(source)
 rows=[dict(db='sceneforge-app-shell',store='files',key='keep',value={'$sf':'blob','hash':asset['hash']})]
 library.commit(rows,0)
 with library.db()as db:db.execute('PRAGMA user_version=0')
 library=Library(library_data);assert list((library.root/'schema-backups').glob('*.sqlite'))
 library.commit([],1);assert asset['hash']in library.protected_hashes()
 library.relocate(root/'relocated library',2);assert list((library.root/'schema-backups').glob('*.sqlite'))
 ledger=RequestLedger(root);key='known-request-1';ledger.claim(key,{'x':1})
 ledger=RequestLedger(root);assert ledger.recent()[0]['state']=='unknown'
 try:ledger.claim(key,{'x':1})
 except RequestConflict:pass
 else:raise AssertionError('unknown retried')
 ledger.claim('null-result-1',{});ledger.finish('null-result-1','done',None);assert ledger.claim('null-result-1',{})[1]is None
 ledger.claim('done-request-1',{'x':2});ledger.finish('done-request-1','done',{'answer':'ok'})
 assert ledger.claim('done-request-1',{'x':2})[1]=={'answer':'ok'}
 try:ledger.claim('done-request-1',{'x':3})
 except RequestConflict:pass
 else:raise AssertionError('key reused with different payload')
 with Instance(root)as owner:
  assert owner.acquire()
  result=subprocess.run([sys.executable,'-c',"from local_engine.instance import Instance; from pathlib import Path; import sys; i=Instance(Path(sys.argv[1])); assert not i.acquire()",temp],capture_output=True,text=True)
  assert result.returncode==0,result.stderr
 with Instance(root)as next_owner:assert next_owner.acquire()
 occupied=listen(0)
 try:
  fallback=listen(occupied.getsockname()[1]);assert fallback.getsockname()[1]!=occupied.getsockname()[1];fallback.close()
 finally:occupied.close()
 os.environ['SCENEFORGE_LOCAL_DATA']=str(root/'service')
 from fastapi.testclient import TestClient
 from local_engine import server
 with TestClient(server.app)as c:
  assert c.get('/local-api/health').status_code==200
  assert c.get('/local-api/status').status_code==403
  assert c.get('/local-api/library/bundle').status_code==403
  assert c.get('/local-api/media/private.wav').status_code==403
  assert c.get('/',headers={'Sec-Fetch-Site':'cross-site'}).status_code==403
  assert c.get('/',headers={'Origin':'https://evil.example'}).status_code==403
  response=c.get('/');assert response.status_code==200
  assert 'HttpOnly'in response.headers['set-cookie']and 'SameSite=strict'in response.headers['set-cookie']
  assert c.get('/local-api/status').status_code==200
  assert c.get('/local-api/status',headers={'Origin':'http://testserver.evil.example'}).status_code==403
  assert c.get('/local-api/status',headers={'Origin':'https://testserver'}).status_code==403
  assert c.get('/local-api/status',headers={'Host':'testserver@evil.example'}).status_code==403
  assert c.get('/local-api/status',headers={'Sec-Fetch-Site':'cross-site'}).status_code==403
  assert c.post('/local-api/rotation',json={'service':'flow'}).status_code==403
  headers={'X-SceneForge-Local':'1'}
  assert c.post('/local-api/rotation',headers=headers,json={'service':'flow'}).status_code==200
  old=server.SESSION.secret;server.SESSION.secret='new-random-session';assert c.get('/local-api/status').status_code==403;c.get('/');assert c.get('/local-api/status').status_code==200;server.SESSION.secret=old;c.get('/')
  server.VAULT.set_secret('gemini','FAKE_NOT_A_KEY')
  async def duplicate_checks():
   body={'request_id':'same-operation-123','idea':'hello'}
   with patch.object(server,'gemini_request',new=AsyncMock(return_value={'ok':1}))as fn:
    assert await server.gemini(body,'test')=={'ok':1}
    assert await server.gemini(body,'test')=={'ok':1};assert fn.await_count==1
   with patch.object(server,'gemini_request',new=AsyncMock(side_effect=asyncio.CancelledError()))as fn:
    body={'request_id':'cancelled-operation-123'}
    try:await server.gemini(body,'test')
    except asyncio.CancelledError:pass
    try:await server.gemini(body,'test')
    except server.HTTPException as e:assert e.status_code==409
    else:raise AssertionError('cancelled operation resubmitted')
    assert fn.await_count==1
  asyncio.run(duplicate_checks())
  server.log('Gemini','unknown',{'idea':'api_key=DO_NOT_LOG_THIS'},time.monotonic())
  assert 'DO_NOT_LOG_THIS'not in c.get('/local-api/logs').text
  c.get('/local-api/status?token=DO_NOT_LOG_QUERY')
  for handler in server.RUNTIME_LOG.handlers:handler.flush()
  text=(root/'service/logs/runtime.log').read_text();assert 'DO_NOT_LOG'not in text;assert 'status=403'in text
 print('PASS session required for reads/writes/downloads; cross-site/Host/Origin rejection; session restart invalidation; HttpOnly cookie; bounded metadata logs; failed migration rollback/backup and future-version rejection; durable duplicate claims and cancellation recovery; process lock and occupied-port fallback. No external AI calls.')
