@echo off
cd /d "%~dp0.."
if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -r local_engine\requirements.txt
set SCENEFORGE_OPEN_BROWSER=1
python -m local_engine
pause
