"""Export stage/ACK follows browser durable writes; failed saves retain the clip."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from threading import Thread
from playwright.sync_api import sync_playwright

def main():
 class Quiet(SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(Path(__file__).resolve().parents[1]/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
 try:
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();page.goto(f'http://127.0.0.1:{server.server_port}/');page.wait_for_function('typeof saveRoomExport === "function"')
   page.evaluate('''async()=>{const room={id:'export-commit-fixture',stage:'editing',name:'Test'};rooms.push(room);const messages=[],target={postMessage:m=>messages.push(m)},file=new Blob(['fixture video'],{type:'video/mp4'}),original=io;let release;io=async(store,mode,key,value)=>{if(store==='files')await new Promise(r=>release=r);return original(store,mode,key,value);};const running=saveRoomExport({roomId:room.id,id:'one',file,name:'one.mp4'},target);await new Promise(r=>setTimeout(r,20));if(room.stage!=='editing'||messages.length)throw Error('ack before file commit');release();await running;if(room.stage!=='exported'||!messages[0].ok)throw Error('missing committed ack');io=original;const saved=await io('files','readonly',room.id+':export');if(await saved.text()!=='fixture video')throw Error('missing export blob');room.stage='editing';delete room.exportedAt;io=async()=>{throw Error('QuotaExceededError fixture');};try{await saveRoomExport({roomId:room.id,id:'two',file,name:'two.mp4'},target);}catch{}io=original;if(room.stage!=='editing'||room.exportedAt||messages.at(-1).ok!==false)throw Error('failed save reported exported');}''')
   browser.close();print('PASS: real IndexedDB export Blob; no exported stage/ACK before commit; quota failure returns negative ACK and preserves editing stage.')
 finally:server.shutdown()
if __name__=='__main__':main()
