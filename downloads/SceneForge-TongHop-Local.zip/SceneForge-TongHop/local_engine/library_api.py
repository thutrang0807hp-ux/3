"""Same-origin loopback library endpoints. Credentials stay in the separate encrypted vault."""
from pathlib import Path
import asyncio,os,tempfile,zipfile,sqlite3
from fastapi import HTTPException,Request
from fastapi.responses import FileResponse
from .library import Library,Conflict

def install_library(app,data,busy=lambda:False):
 library=Library(data)
 async def call(fn,*args,**kwargs):
  try:return await asyncio.to_thread(fn,*args,**kwargs)
  except Conflict as e:raise HTTPException(409,str(e))
  except (ValueError,KeyError,TypeError)as e:raise HTTPException(400,str(e))
  except zipfile.BadZipFile:raise HTTPException(400,'ZIP bị hỏng hoặc không đúng định dạng.')
  except sqlite3.Error:raise HTTPException(503,'SQLite đang bận hoặc không đọc được. Dữ liệu trình duyệt vẫn được giữ.')
  except OSError as e:raise HTTPException(507,'Không hoàn tất ghi dữ liệu: '+str(e))
 def idle():
  if busy():raise HTTPException(409,'Đang có tác vụ trên máy. Đợi xong trước khi khôi phục/chuyển thư mục.')
 async def receive(request,limit):
  stage=Path(data)/'library-incoming';stage.mkdir(exist_ok=True)
  fd,name=tempfile.mkstemp(dir=stage);size=0
  try:
   with os.fdopen(fd,'wb')as f:
    async for chunk in request.stream():
     size+=len(chunk)
     if size>limit:raise HTTPException(413,'File vượt giới hạn '+str(limit//1024**2)+' MB.')
     f.write(chunk)
    f.flush();os.fsync(f.fileno())
   return Path(name)
  except BaseException:Path(name).unlink(missing_ok=True);raise
 @app.get('/local-api/library/status')
 async def status():return await call(library.status)
 @app.get('/local-api/library/snapshot')
 async def snapshot(verify:bool=False):
  snap=await call(library.snapshot)
  if verify:await call(library.verify,library.validate(snap['records'])[1])
  return snap
 @app.post('/local-api/library/snapshot')
 async def save(body:dict):return await call(library.commit,body.get('records'),body.get('revision'))
 @app.post('/local-api/library/assets')
 async def upload(request:Request):
  tmp=await receive(request,2*1024**3)
  try:return await call(library.add_file,tmp,request.headers.get('content-type','application/octet-stream'),request.headers.get('x-content-sha256'))
  finally:tmp.unlink(missing_ok=True)
 @app.get('/local-api/library/assets/{hash}')
 async def asset(hash:str):
  try:p=library.asset_path(hash)
  except ValueError:raise HTTPException(400,'Mã file không hợp lệ.')
  if not p.is_file():raise HTTPException(404,'Không còn file trong kho.')
  await call(library.verify,{hash})
  return FileResponse(p,media_type='application/octet-stream')
 @app.get('/local-api/library/timeline-assets')
 async def timeline_assets():
  def protected():
   with library.lock,library.db()as db:return {'hashes':[r[0]for r in db.execute("SELECT DISTINCT hash FROM asset_ref WHERE db='sceneforge-editor-local' UNION SELECT hash FROM pin")]}
  return await call(protected)
 @app.post('/local-api/library/pin')
 async def pin(body:dict):await call(library.set_pin,body.get('hash',''),bool(body.get('pinned')),body.get('note',''));return {'ok':True}
 @app.post('/local-api/library/backup')
 async def backup():return {'name':await call(library.backup)}
 @app.post('/local-api/library/restore')
 async def restore(body:dict):idle();return await call(library.restore,body.get('name',''),body.get('revision'))
 @app.get('/local-api/library/bundle')
 async def bundle(room_id:str|None=None,file:str|None=None):
  if file:
   if Path(file).name!=file or not file.startswith(('phong-','thu-vien-','trinh-duyet-'))or not file.endswith('.zip'):raise HTTPException(400,'Tên ZIP không hợp lệ.')
   p=library.root/('sao-luu'if file.startswith('trinh-duyet-')else 'cache')/file
   if not p.is_file():raise HTTPException(404,'ZIP không còn trong cache.')
  else:p=await call(library.bundle,room_id)
  return FileResponse(p,filename=p.name,media_type='application/zip')
 @app.post('/local-api/library/browser-bundle')
 async def browser_bundle(body:dict):
  records=body.get('records');await call(library.validate,records)
  p=await call(library.bundle,snapshot={'format':'SceneForge-library-1','revision':0,'records':records,'pins':[]})
  dest=library.root/'sao-luu'/('trinh-duyet-'+str(__import__('time').time_ns())+'.zip');os.replace(p,dest)
  return {'name':dest.name,'url':'/local-api/library/bundle?file='+dest.name,'bytes':dest.stat().st_size}
 @app.post('/local-api/library/import')
 async def import_bundle(request:Request):
  idle()
  try:revision=int(request.headers.get('x-library-revision','-1'))
  except ValueError:raise HTTPException(400,'Thiếu phiên bản thư viện.')
  tmp=await receive(request,4*1024**3)
  try:return await call(library.import_bundle,tmp,revision)
  finally:tmp.unlink(missing_ok=True)
 @app.get('/local-api/library/cleanup')
 async def plan():return await call(library.cleanup_plan)
 @app.post('/local-api/library/cleanup')
 async def clean(body:dict):idle();return await call(library.cleanup,body.get('token'))
 @app.post('/local-api/library/output')
 async def output(body:dict):return await call(library.set_output,body.get('path',''))
 @app.post('/local-api/library/open-export')
 async def open_export(body:dict):
  import sys,subprocess
  folder=await call(library.export_folder,str(body.get('room_id','')))
  try:
   if os.name=='nt':os.startfile(str(folder))
   elif sys.platform=='darwin':subprocess.Popen(['open',str(folder)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   else:subprocess.Popen(['xdg-open',str(folder)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  except OSError:raise HTTPException(409,'Chưa mở được cửa sổ thư mục. Đường dẫn: '+str(folder))
  return {'path':str(folder)}
 @app.get('/local-api/library/cache')
 async def cache_plan():return await call(library.cache_plan)
 @app.post('/local-api/library/cache')
 async def cache_clean(body:dict):idle();return await call(library.clean_cache,body.get('token'))
 @app.post('/local-api/library/relocate')
 async def relocate(body:dict):idle();return await call(library.relocate,body.get('path',''),body.get('revision'))
 return library
