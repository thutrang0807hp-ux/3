"""Prepare reviewed repositories without accounts, browser startup or model download.

python -m local_engine.setup_optional_repos muse
python -m local_engine.setup_optional_repos voice

The Muse repository targets muse.ai; it is NOT a verified Meta AI integration.
"""
import argparse
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import venv

REPOS = {
    'muse': {'url': 'https://github.com/czg86389-hub/muse2api.git',
             'revision': '5542a479ec6ba036a9717e8776380ff5aacf3fe7', 'directory': 'muse2api', 'site': 'https://muse.ai/'},
    'voice': {'url': 'https://github.com/pnnbao97/VieNeu-TTS.git',
              'revision': '04044e1b8f822f946bafb2c88b716459f4164152', 'directory': 'vieneu', 'site': None},
}


def prepare(name, directory, source=None):
    spec = REPOS[name]
    root = Path(directory).resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    checkout, environment = root / 'source', root / 'venv'
    if not shutil.which('git'):
        raise RuntimeError('Cần cài Git trước.')
    if not checkout.exists():
        subprocess.run(['git', 'clone', '--no-hardlinks', source or spec['url'], str(checkout)], check=True)
        subprocess.run(['git', '-C', str(checkout), 'checkout', '--detach', spec['revision']], check=True)
    revision = subprocess.check_output(['git', '-C', str(checkout), 'rev-parse', 'HEAD'], text=True).strip()
    if revision != spec['revision']:
        raise RuntimeError('Repo khác revision đã kiểm tra; không tự ghi đè.')
    if not environment.exists():
        venv.EnvBuilder(with_pip=True).create(environment)
    python = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    dependency_args = ['-r', str(checkout / 'requirements.txt')] if name == 'muse' else [str(checkout)]
    subprocess.run([str(python), '-m', 'pip', 'install', *dependency_args], check=True)
    subprocess.run([str(python), '-m', 'pip', 'check'], check=True)
    runtime = root / 'runtime'
    runtime.mkdir(exist_ok=True, mode=0o700)
    env = {**os.environ, 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'HF_HOME': str(runtime / 'hf-cache')}
    if name == 'muse':
        # Import creates local metadata directories; scope them to this private runtime.
        # Do not enter the ASGI lifespan: upstream startup runs keepalive/browser work.
        keyfile = runtime / 'engine-key'
        if not keyfile.exists():
            with keyfile.open('x') as out:
                os.chmod(keyfile, 0o600)
                out.write(secrets.token_urlsafe(32))
        env.update(MUSE2API_HOME=str(runtime), MUSE2API_PROFILE_ROOT=str(runtime / 'profiles'),
                   MUSE2API_HOST='127.0.0.1', MUSE2API_KEY=keyfile.read_text(), MUSE2API_SITE=spec['site'])
        code = "from app import app; paths={r.path for r in app.routes}; assert '/v1/models' in paths and '/v1/videos' in paths; print('Muse import and routes OK; no startup/account calls')"
    else:
        code = "from vieneu import Vieneu; import importlib.util; assert importlib.util.find_spec('torch') is None; print('VieNeu CPU SDK import OK; no model loaded or downloaded')"
    subprocess.run([str(python), '-c', code], cwd=checkout, env=env, check=True)
    marker = {'repository': spec['url'], 'revision': revision, 'site': spec['site'],
              'dependencies_checked': True, 'import_checked': True, 'account_verified': False,
              'model_loaded': False, 'generation_verified': False, 'enabled_in_app': False}
    (root / 'installation.json').write_text(json.dumps(marker, indent=2), encoding='utf-8')
    return marker


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', choices=REPOS)
    parser.add_argument('--directory', type=Path)
    parser.add_argument('--source', help='Existing reviewed Git clone for offline source installation.')
    args = parser.parse_args()
    if args.repo == 'muse':
        print('Preparing muse.ai repository only; this does not enable Meta AI in SceneForge.', flush=True)
    data = Path(os.environ.get('SCENEFORGE_LOCAL_DATA', str(Path.home() / '.sceneforge-local')))
    marker = prepare(args.repo, args.directory or data / 'engines' / REPOS[args.repo]['directory'], args.source)
    print('Repository installed and import checked:', marker['repository'])
    print('No account or generation test. No model download. App adapter is not enabled by this installer.')
    if args.repo == 'muse':
        print('This repository targets muse.ai, NOT a verified Meta AI service.')


if __name__ == '__main__':
    main()
