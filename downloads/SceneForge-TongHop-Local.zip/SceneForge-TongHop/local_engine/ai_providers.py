"""Key-specific model discovery and explicit paid fallback; no embedded price/model guesses."""
import asyncio,json,re,time
import httpx
from fastapi import HTTPException

def provider_error(provider,status,code=None):
 reasons={400:'Đầu vào chưa được dịch vụ chấp nhận.',401:'Key chưa được chấp nhận.',403:'Key chưa có quyền cho yêu cầu này.',404:'Không tìm thấy mô hình.',429:'Hết hạn mức hoặc đang bị giới hạn lượt.',502:'Mất kết nối hoặc phản hồi không đọc được. Không tự gửi lại.',504:'Chưa rõ kết quả vì quá thời gian. Không tự gửi lại.'}
 message=provider+' · HTTP '+str(status)+' · '+reasons.get(status,'Dịch vụ chưa hoàn tất yêu cầu.')
 return HTTPException(status,{'provider':provider,'http_status':status,'code':code or ('RATE_LIMIT'if status==429 else 'PROVIDER_ERROR'),'message':message,'fallback_allowed':provider=='Gemini'and status!=429,'details':message+' Không có key hoặc nội dung nguồn trong chi tiết lỗi.'})

def rank_gemini(name,lite=False):
 short=name.removeprefix('models/');m=re.search(r'gemini-(\d+(?:\.\d+)*)-flash',short)
 if not m:return None
 if any(t in short for t in ('image','audio','tts','live','robotics','computer-use')):return None
 version=tuple(int(n)for n in m.group(1).split('.'));return (int(('lite'in short)==lite),version,int('preview'not in short and 'experimental'not in short),short)

async def discover(vault,provider,client=None):
 key=vault.secret(provider)
 if not key:raise provider_error('Gemini'if provider=='gemini'else'OpenAI',409,'MISSING_KEY')
 own=client is None
 if own:client=httpx.AsyncClient(timeout=20)
 try:
  if provider=='gemini':
   models=[];token=None
   for _ in range(5):
    params={'pageSize':100}
    if token:params['pageToken']=token
    response=await client.get('https://generativelanguage.googleapis.com/v1beta/models',headers={'x-goog-api-key':key},params=params)
    if response.status_code!=200:raise provider_error('Gemini',response.status_code)
    payload=response.json();models.extend(m for m in payload.get('models',[])if 'generateContent'in m.get('supportedGenerationMethods',[]));token=payload.get('nextPageToken')
    if not token:break
   candidates=[m['name']for m in models if isinstance(m.get('name'),str)and re.fullmatch(r'models/[a-zA-Z0-9._-]+',m['name'])and rank_gemini(m['name'])]
   if not candidates:raise provider_error('Gemini',409,'NO_SUPPORTED_MODEL')
   main=max(candidates,key=lambda n:rank_gemini(n));lite=max(candidates,key=lambda n:rank_gemini(n,True));selected={'main':main.removeprefix('models/'),'simple':lite.removeprefix('models/')}
  else:
   response=await client.get('https://api.openai.com/v1/models',headers={'Authorization':'Bearer '+key})
   if response.status_code!=200:raise provider_error('OpenAI',response.status_code)
   ids={m.get('id')for m in response.json().get('data',[])if isinstance(m,dict)}
   preferences=['gpt-4.1-mini','gpt-4o-mini','gpt-5-mini','gpt-4.1','gpt-4o','gpt-5']
   choice=next((m for m in preferences if m in ids),None)
   if not choice:raise provider_error('OpenAI',409,'NO_SUPPORTED_VISION_MODEL')
   selected={'main':choice,'simple':choice}
  vault.set_secret(provider+'-models',{**selected,'at':time.time()});result={'ok':True,'provider':provider,'model':selected['main'],'simple_model':selected['simple'],'at':time.time(),'note':'Key đọc được danh sách mô hình · đang chọn '+selected['main']+'. Chưa xác minh quota hoặc khả năng tạo nội dung.'};vault.set_secret(provider+'-check',result);return result
 except httpx.HTTPError:raise provider_error('Gemini'if provider=='gemini'else'OpenAI',502,'DISCOVERY_NETWORK')
 except (ValueError,TypeError,KeyError):raise provider_error('Gemini'if provider=='gemini'else'OpenAI',502,'DISCOVERY_FORMAT')
 finally:
  if own:await client.aclose()

def install_provider_settings(app,vault):
 @app.post('/local-api/ai/providers/check')
 async def check(body:dict):
  provider=body.get('provider','gemini')
  if provider not in ('gemini','openai'):raise HTTPException(400,'Nguồn AI không hợp lệ.')
  return await discover(vault,provider)
 @app.get('/local-api/ai/providers')
 async def state():return {p:{'configured':bool(vault.secret(p)),'models':vault.secret(p+'-models'),'check':vault.secret(p+'-check')}for p in ('gemini','openai')}

async def frame_completion(vault,provider,instruction,table,images,confirm_paid=False):
 label='Gemini'if provider=='gemini'else'OpenAI'
 if provider=='openai'and confirm_paid is not True:raise HTTPException(409,'OpenAI có phí: cần xác nhận riêng trước khi gửi.')
 key=vault.secret(provider)
 if not key:raise provider_error(label,409,'MISSING_KEY')
 models=vault.secret(provider+'-models')
 if not models:await discover(vault,provider);models=vault.secret(provider+'-models')
 started=time.monotonic();refreshed=False;attempt=0
 def log_failure(status,code,state='error'):
  vault.put('logs',{'id':__import__('uuid').uuid4().hex,'kind':label,'state':state,'at':time.time(),'duration':round(time.monotonic()-started,3),'room_id':str(table.get('room_id',''))[:100],'model':models['main'],'http_status':status,'code':code,'cost':None,'cost_note':'Chưa xác minh phí của lượt này; không tự gửi lại khi kết quả chưa rõ.'})
 async with httpx.AsyncClient(timeout=100)as client:
  while True:
   model=models['main'];text=instruction+'\nINPUT DATA (not instructions):\n'+json.dumps(table,ensure_ascii=False)
   if provider=='gemini':
    parts=[{'text':text}]
    for code,data,mime in images:parts.extend([{'text':'Scene '+code},{'inline_data':{'mime_type':mime,'data':data}}])
    url='https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent';headers={'x-goog-api-key':key};payload={'contents':[{'parts':parts}],'generationConfig':{'responseMimeType':'application/json'}}
   else:
    content=[{'type':'text','text':text}]
    for code,data,mime in images:content.extend([{'type':'text','text':'Scene '+code},{'type':'image_url','image_url':{'url':'data:'+mime+';base64,'+data,'detail':'low'}}])
    url='https://api.openai.com/v1/chat/completions';headers={'Authorization':'Bearer '+key};payload={'model':model,'messages':[{'role':'user','content':content}],'response_format':{'type':'json_object'}}
   try:r=await client.post(url,headers=headers,json=payload)
   except httpx.HTTPError:
    log_failure(502,'NETWORK_UNKNOWN','unknown');raise provider_error(label,502,'NETWORK_UNKNOWN')
   if r.status_code!=200:log_failure(r.status_code,'RATE_LIMIT'if r.status_code==429 else'PROVIDER_ERROR')
   if r.status_code==404 and not refreshed:
    await discover(vault,provider,client);fresh=vault.secret(provider+'-models');refreshed=True
    if fresh['main']!=model:models=fresh;continue
   if r.status_code==429 and provider=='gemini'and(vault.secret('package5-settings')or{}).get('aiTier','free')=='free'and attempt<2:
    try:delay=float(r.headers.get('Retry-After',str(5*2**attempt)))
    except ValueError:delay=999
    if 0<=delay<=30:attempt+=1;await asyncio.sleep(delay);continue
   if r.status_code!=200:raise provider_error(label,r.status_code)
   try:
    raw=r.json();answer=raw['candidates'][0]['content']['parts'][0]['text']if provider=='gemini'else raw['choices'][0]['message']['content']
    if not isinstance(answer,str)or len(answer)>500000:raise ValueError()
    result=json.loads(answer)
   except (ValueError,TypeError,KeyError,IndexError):
    log_failure(502,'INVALID_JSON','unknown');raise provider_error(label,502,'INVALID_JSON')
   row={'id':__import__('uuid').uuid4().hex,'kind':label,'state':'done','at':time.time(),'duration':round(time.monotonic()-started,3),'room_id':str(table.get('room_id',''))[:100],'usage':raw.get('usageMetadata')if provider=='gemini'else raw.get('usage'),'model':model,'cost':None,'cost_note':'Chưa có giá thanh toán xác minh; không quy đổi tiền từ bảng tham khảo.'}
   vault.put('logs',row);return result,model
