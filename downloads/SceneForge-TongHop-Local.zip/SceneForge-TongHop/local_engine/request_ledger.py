"""Durable AI submission claims; ambiguity blocks reuse, never dispatches a retry."""
import hashlib,json,sqlite3,threading,time,uuid
from .schema import migrate
NO_RESULT=object()
class RequestConflict(ValueError):pass
class RequestLedger:
 def __init__(self,root):
  self.path=root/'requests.sqlite';self.lock=threading.RLock()
  migrate(self.path,['CREATE TABLE IF NOT EXISTS request(id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,state TEXT NOT NULL,result TEXT,updated REAL NOT NULL)',
   'CREATE TABLE IF NOT EXISTS request_meta(id TEXT PRIMARY KEY,envelope TEXT,metadata TEXT)',
   'CREATE TABLE IF NOT EXISTS ledger_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)'],version=2)
  with self.connect()as db:
   db.execute("UPDATE request SET state='unknown',updated=? WHERE state='submitted'",(time.time(),))
   db.execute("INSERT OR IGNORE INTO ledger_meta VALUES('store_id',?)",(str(uuid.uuid4()),))
   self.store_id=db.execute("SELECT value FROM ledger_meta WHERE key='store_id'").fetchone()[0]
 def connect(self):
  return Connection(self.path)
 def claim(self,request_id,payload,envelope=None):
  request_id=request_id or str(uuid.uuid4())
  if not isinstance(request_id,str)or not 8<=len(request_id)<=128:raise ValueError('Mã yêu cầu không hợp lệ.')
  digest=hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
  with self.lock,self.connect()as db:
   db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT fingerprint,state,result FROM request WHERE id=?',(request_id,)).fetchone()
   if row:
    if row[0]!=digest:raise RequestConflict('Mã yêu cầu đã dùng cho nội dung khác.')
    if row[1]=='done':return request_id,json.loads(row[2])
    raise RequestConflict('Yêu cầu đã gửi hoặc chưa rõ kết quả. Không tự gửi lại; kiểm tra nhật ký trước.')
   db.execute('INSERT INTO request VALUES(?,?,?,?,?)',(request_id,digest,'submitted',None,time.time()))
   db.execute('INSERT INTO request_meta(id,envelope) VALUES(?,?)',(request_id,envelope))
  return request_id,NO_RESULT
 def receipt(self,request_id):
  with self.connect()as db:row=db.execute('SELECT state FROM request WHERE id=?',(request_id,)).fetchone()
  return {'store_id':self.store_id,'request_id':request_id,'state':row[0]if row else None,'submitted':False if row and row[0]=='not_submitted'else None}
 def reject_before_claim(self,request_id):
  with self.lock,self.connect()as db:
   db.execute('BEGIN IMMEDIATE')
   row=db.execute('SELECT state FROM request WHERE id=?',(request_id,)).fetchone()
   if row is None:db.execute('INSERT INTO request VALUES(?,?,?,?,?)',(request_id,'','not_submitted',None,time.time()))
  return self.receipt(request_id)
 def envelope(self,request_id):
  with self.connect()as db:row=db.execute('SELECT envelope FROM request_meta WHERE id=?',(request_id,)).fetchone()
  return row[0]if row else None
 def metadata(self,request_id):
  with self.connect()as db:row=db.execute('SELECT metadata FROM request_meta WHERE id=?',(request_id,)).fetchone()
  return json.loads(row[0])if row and row[0]else {}
 def set_metadata(self,request_id,value):
  with self.lock,self.connect()as db:
   current=db.execute('SELECT metadata FROM request_meta WHERE id=?',(request_id,)).fetchone()
   data=json.loads(current[0])if current and current[0]else {};data.update(value)
   db.execute('INSERT INTO request_meta(id,metadata) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET metadata=excluded.metadata',(request_id,json.dumps(data)))
 def recent(self):
  with self.connect()as db:return [dict(id=i,state=s,updated=t)for i,s,t in db.execute('SELECT id,state,updated FROM request ORDER BY updated DESC LIMIT 100')]
 def finish(self,request_id,state,result=None):
  if state not in {'done','failed','unknown'}:raise ValueError(state)
  with self.lock,self.connect()as db:db.execute('UPDATE request SET state=?,result=?,updated=? WHERE id=?',(state,json.dumps(result,ensure_ascii=False)if state=='done'else None,time.time(),request_id))
class Connection:
 def __init__(self,path):self.db=sqlite3.connect(path,timeout=30);self.db.execute('PRAGMA synchronous=FULL')
 def __enter__(self):return self.db
 def __exit__(self,*args):
  try:return self.db.__exit__(*args)
  finally:self.db.close()
