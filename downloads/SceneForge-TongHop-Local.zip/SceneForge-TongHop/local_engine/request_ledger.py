"""Durable AI submission claims; ambiguity blocks reuse, never dispatches a retry."""
import hashlib,json,sqlite3,threading,time,uuid
from .schema import migrate
NO_RESULT=object()
class RequestConflict(ValueError):pass
class RequestLedger:
 def __init__(self,root):
  self.path=root/'requests.sqlite';self.lock=threading.RLock()
  migrate(self.path,['CREATE TABLE IF NOT EXISTS request(id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,state TEXT NOT NULL,result TEXT,updated REAL NOT NULL)'])
  with self.connect()as db:db.execute("UPDATE request SET state='unknown',updated=? WHERE state='submitted'",(time.time(),))
 def connect(self):
  return Connection(self.path)
 def claim(self,request_id,payload):
  request_id=request_id or str(uuid.uuid4())
  if not isinstance(request_id,str)or not 8<=len(request_id)<=128:raise ValueError('Mã yêu cầu không hợp lệ.')
  digest=hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
  with self.lock,self.connect()as db:
   db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT fingerprint,state,result FROM request WHERE id=?',(request_id,)).fetchone()
   if row:
    if row[0]!=digest:raise RequestConflict('Mã yêu cầu đã dùng cho nội dung khác.')
    if row[1]=='done':return request_id,json.loads(row[2])
    raise RequestConflict('Yêu cầu đã gửi hoặc chưa rõ kết quả. Không tự gửi lại; kiểm tra nhật ký trước.')
   db.execute('INSERT INTO request VALUES(?,?,?,?,?)',(request_id,digest,'submitted',None,time.time()))
  return request_id,NO_RESULT
 def recent(self):
  with self.connect()as db:return [dict(id=i,state=s,updated=t)for i,s,t in db.execute('SELECT id,state,updated FROM request ORDER BY updated DESC LIMIT 100')]
 def finish(self,request_id,state,result=None):
  if state not in {'done','failed','unknown'}:raise ValueError(state)
  with self.lock,self.connect()as db:db.execute('UPDATE request SET state=?,result=?,updated=? WHERE id=?',(state,json.dumps(result,ensure_ascii=False)if state=='done'else None,time.time(),request_id))
class Connection:
 def __init__(self,path):self.db=sqlite3.connect(path,timeout=30);self.db.execute('PRAGMA synchronous=FULL')
 def __enter__(self):return self.db
 def __exit__(self,*args):
  try:return self.db.__exit__(*args)
  finally:self.db.close()
