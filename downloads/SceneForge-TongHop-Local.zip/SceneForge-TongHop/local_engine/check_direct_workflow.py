"""Browser fixture: review, receive into exact scene, preserve versions, no replay."""
import base64
import io
import subprocess
import tempfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from PIL import Image
from playwright.sync_api import sync_playwright


def main():
    root = Path(__file__).resolve().parents[1]
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self, *args): pass
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Quiet, directory=str(root/'dist/web-demo')))
    Thread(target=server.serve_forever, daemon=True).start()
    image = io.BytesIO(); Image.new('RGB', (90, 160), 'blue').save(image, format='WEBP')
    image = image.getvalue(); jobs = {}; posts = []; token = ['selection-A']
    try:
        with tempfile.TemporaryDirectory() as directory, sync_playwright() as pw:
            video = Path(directory)/'fixture.mp4'
            subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=90x160:r=10:d=0.4','-c:v','libx264',str(video)], check=True)
            def route(r):
                path = r.request.url.split('/local-api/')[1]
                provider = path.split('/')[0]
                if path.endswith('/status'):
                    data = {'account_binding': True, 'models': ['fixture-portrait'], 'selection': {'available': True, 'mode': 'selected', 'account_id': 'A', 'account_name': 'A', 'token': token[0]}}
                elif path.endswith('/jobs'):
                    body = r.request.post_data_json
                    assert body['selection_token'] == token[0] and body['confirm_send']
                    posts.append(body)
                    jobs[body['request_id']] = {'state': 'done', 'result': {'mime_type': 'image/webp' if provider == 'gemini-chat' else 'video/mp4', 'account_id': 'A'}}
                    data = {'state': 'submitted'}
                elif '/jobs/' in path: data = jobs[path.split('/')[-1]]
                elif '/files/' in path:
                    return r.fulfill(body=image if provider == 'gemini-chat' else video.read_bytes(), content_type='image/webp' if provider == 'gemini-chat' else 'video/mp4')
                else: data = {}
                r.fulfill(json=data)
            browser = pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1600, 'height': 1000})
            errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            page.route('**/local-api/**', route)
            page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html')
            page.wait_for_function('!!window.SceneForgeWorkflow')
            page.evaluate('''image=>{project=blankProject();project.id='direct-room';project.source={poster:image};project.scenes=[sceneRecord(0,.4,0,[image]),sceneRecord(.4,.8,1,[image])];project.scenes[0].promptFrame.en='Product detail';render();}''', 'data:image/webp;base64,'+base64.b64encode(image).decode())
            page.evaluate('directDialog([project.scenes[0]])')
            page.locator('#directPrepare').click();page.locator('#directSend').wait_for()
            assert not posts
            page.locator('#directSend').click();page.wait_for_function('project.cloudJobs[0]?.state==="submitted"')
            page.evaluate('directRecover()')
            assert page.evaluate('project.scenes[0].frames.length===1 && project.scenes[1].frames.length===0 && !frameApproved(project.scenes[0])')
            page.evaluate('directRecover()');assert len(posts)==1
            assert page.evaluate('project.scenes[0].frames.length===1')
            page.evaluate('''()=>{project.scenes[0].approvedFrame=project.scenes[0].frames[0].id;project.scenes[0].frameSelectionId=project.scenes[0].approvedFrame;directDialog([project.scenes[0]]);}''')
            page.locator('#directPrepare').click();page.locator('#directSend').wait_for();assert len(posts)==1
            page.locator('#directSend').click();page.wait_for_function('project.cloudJobs[1]?.state==="submitted"')
            page.evaluate('directRecover()')
            assert page.evaluate('project.scenes[0].clips.length===1 && project.scenes[1].clips.length===0 && project.scenes[0].clips[0].accountId==="A"')
            assert posts[1]['scene_id']==page.evaluate('project.scenes[0].id') and posts[1]['model']=='fixture-portrait'
            page.evaluate('directRecover()');assert len(posts)==2
            # An open review becomes invalid if Settings changes the shared selection.
            page.evaluate('directDialog([project.scenes[1]])');page.locator('#directPrepare').click();page.locator('#directSend').wait_for()
            token[0]='selection-B';page.locator('#directSend').click();page.wait_for_function('document.querySelector("#toast").textContent.includes("Lựa chọn tài khoản đã đổi")')
            assert len(posts)==2 and not errors,errors
            browser.close()
            print('PASS: reference workflow reviewed image/Flow clip jobs, WebP receipt, exact scene/part/account, no auto-approve, repeated recovery no duplicate, stale account review rejected. Service fixtures only.')
    finally: server.shutdown()


if __name__ == '__main__': main()
