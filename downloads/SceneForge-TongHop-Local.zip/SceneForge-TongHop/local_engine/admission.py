"""A durable negative receipt is proof; an HTTP code or missing row is not."""
from functools import wraps
from fastapi import HTTPException

def guarded_submission(method):
    @wraps(method)
    async def guarded(self,body):
        try:return await method(self,body)
        except HTTPException as error:
            rid=body.get('request_id')
            try:self.valid_id(rid)
            except HTTPException:raise error
            if not 400<=error.status_code<500:raise
            receipt=self.ledger.reject_before_claim(rid)
            detail=error.detail if isinstance(error.detail,dict)else {'message':str(error.detail)}
            # Existing submitted/done/unknown rows can never become negative receipts.
            detail={**detail,**receipt,'code':detail.get('code','NOT_SUBMITTED'if receipt['submitted']is False else'REQUEST_EXISTS')}
            raise HTTPException(error.status_code,detail)from None
    return guarded
