"""Isolated Muse SDK worker. JSON via pipes; no credentials in argv or logs.

Our adapter, independently implemented against the inspected SDK interface.
The third-party SDK is installed separately and is not redistributed here.
"""
import asyncio
import base64
import contextlib
import dataclasses
import json
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlsplit


async def strict_session(client, explicit, events, before):
    """Do not accept the SDK's fallback to an unrelated latest conversation."""
    from muse_ai.media import extract_session_ids
    if explicit:
        return explicit
    candidates = set(extract_session_ids(events)) - before
    if not candidates:
        candidates = set(extract_session_ids(await client.sessions_list())) - before
    if len(candidates) != 1:
        raise ValueError('cannot bind result to exactly one new conversation')
    return candidates.pop()


async def execute(body, auth_class=None, client_class=None):
    if auth_class is None:
        from muse_ai import MuseAuth, MuseClient
        auth_class, client_class = MuseAuth, MuseClient
    scratch = contextlib.nullcontext(body['_workspace']) if body.get('_workspace') else tempfile.TemporaryDirectory(prefix='muse-session-')
    with scratch as directory:
        root = Path(directory)
        state = body.get('session') or {}
        for name in ('cookies.json', 'device.json'):
            if name in state:
                (root / name).write_text(json.dumps(state[name]), encoding='utf-8')
        auth = auth_class(state_dir=root)
        client = None
        result = {}
        try:
            op = body['operation']
            if op == 'login_start':
                await auth.restart_login()
                await auth.send_otp(body['email'], 'VN')
                result['pending'] = {'waterfall_id': auth.waterfall_id, 'csrf_token': auth.csrf_token,
                                     'login_referer': auth.login_referer}
            elif op == 'login_confirm':
                await auth.load_cookies()
                pending = state.get('pending') or {}
                for key in ('waterfall_id', 'csrf_token', 'login_referer'):
                    if key in pending:
                        setattr(auth, key, pending[key])
                await auth.confirm_otp(body['otp'])
                await auth.save_account()
                if (await auth.auth_check()).get('ok') is not True:
                    raise ValueError('authentication not verified')
                result['authenticated'] = True
            elif op in ('check', 'import'):
                if op == 'import':
                    (root / 'cookies.json').write_text(json.dumps(body['cookies']), encoding='utf-8')
                await auth.load_cookies()
                if (await auth.auth_check()).get('ok') is not True:
                    raise ValueError('authentication not verified')
                result['authenticated'] = True
            elif op == 'generate':
                client = client_class(auth, state_dir=root)
                await client.connect()
                from muse_ai.media import extract_session_ids
                before = set(extract_session_ids(await client.sessions_list()))
                async def resolve(explicit, events, ignored):
                    return await strict_session(client, explicit, events, before)
                client._resolve_session_id = resolve
                refs = []
                for index, image in enumerate(body.get('references', [])):
                    ext = {'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp'}[image['mime_type']]
                    file = root / ('ref-' + str(index) + ext)
                    file.write_bytes(base64.b64decode(image['data'], validate=True))
                    refs.append(str(file))
                instruction = 'Create one finished video clip using these scene instructions and the supplied reference images. Do not respond only with a written description.\n\n' + body['prompt']
                generated = await client.generate_video(prompt=instruction, images=refs,
                                                        timeout=900, download=False)
                if not generated.session_id or not generated.videos:
                    raise ValueError('no video in resolved session')
                ref = generated.videos[0]
                # Use authenticated media/filesystem RPC, never fetch an arbitrary
                # model-supplied URL with the account's cookie-bearing HTTP client.
                if ref.url and not ref.url.startswith('sandbox://'):
                    parsed = urlsplit(ref.url)
                    if '/idea-cards/media/' not in parsed.path:
                        ref = dataclasses.replace(ref, url=None)
                output = Path(body['output'])
                await client.download_video(ref, output)
                if not output.is_file() or not 0 < output.stat().st_size <= 500 * 1024**2:
                    raise ValueError('invalid output size')
                result['generated'] = True
            else:
                raise ValueError('unsupported operation')
            await auth.save_cookies()
            result['session'] = {name: json.loads((root / name).read_text(encoding='utf-8'))
                                 for name in ('cookies.json', 'device.json') if (root / name).is_file()}
            if 'pending' in result:
                result['session']['pending'] = result.pop('pending')
            return {'ok': True, **result}
        except Exception:
            # Upstream errors can contain cookie values, URLs and server content.
            # Never return raw exception text, even for failed authentication.
            return {'ok': False, 'code': 'MUSE_OPERATION_FAILED'}
        finally:
            if client is not None:
                with contextlib.suppress(Exception):
                    await client.close()
            with contextlib.suppress(Exception):
                await auth.close()


def main():
    body = json.loads(sys.stdin.buffer.read(40 * 1024**2))
    with contextlib.redirect_stdout(sys.stderr):
        result = asyncio.run(execute(body))
    sys.stdout.write(json.dumps(result))


if __name__ == '__main__':
    main()
