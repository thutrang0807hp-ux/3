"""Install pinned Flow2API separately. Does not submit generation requests.

python -m local_engine.setup_flow --directory PATH
python -m local_engine.setup_flow --directory PATH --start
Credentials are written to private local files, never printed or packaged.
"""
import argparse
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import venv

REVISION = '018f75539fe97d5602e0dcac6783638093bb6479'
REPOSITORY = 'https://github.com/TheSmallHanCat/flow2api.git'


def read_settings(path, python):
    try:
        import tomllib
    except ImportError:  # App supports Python 3.10; tomli is installed in the engine venv.
        raw = subprocess.check_output([str(python), '-c', 'import json,sys,tomli;print(json.dumps(tomli.load(open(sys.argv[1],"rb"))))', str(path)], text=True)
        return json.loads(raw)
    with path.open('rb') as stream:
        return tomllib.load(stream)


def install(directory, source=REPOSITORY):
    root = Path(directory).resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    checkout, environment = root / 'source', root / 'venv'
    if not shutil.which('git'):
        raise RuntimeError('Cần cài Git trước khi cài engine Flow.')
    if not checkout.exists():
        subprocess.run(['git', 'clone', '--no-hardlinks', source, str(checkout)], check=True)
        subprocess.run(['git', '-C', str(checkout), 'checkout', '--detach', REVISION], check=True)
    actual = subprocess.check_output(['git', '-C', str(checkout), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != REVISION:
        raise RuntimeError('Engine khác bản đã kiểm tra; không tự ghi đè source.')
    if not environment.exists():
        venv.EnvBuilder(with_pip=True).create(environment)
    python = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    subprocess.run([str(python), '-m', 'pip', 'install', '-r', str(checkout / 'requirements.txt')], check=True)
    subprocess.run([str(python), '-m', 'pip', 'check'], check=True)
    config = checkout / 'config/setting.toml'
    if not config.exists():
        text = (checkout / 'config/setting_example.toml').read_text(encoding='utf-8')
        replacements = {
            'api_key = "han1234"': 'api_key = "' + secrets.token_urlsafe(32) + '"',
            'admin_password = "admin"': 'admin_password = "' + secrets.token_urlsafe(32) + '"',
            'host = "0.0.0.0"': 'host = "127.0.0.1"',
            'port = 8000': 'port = 8766',
            'max_retries = 3': 'max_retries = 1',
            'image_timeout_retry_count = 1': 'image_timeout_retry_count = 0',
            'log_requests = true': 'log_requests = false',
            'log_responses = true': 'log_responses = false',
            'captcha_method = "yescaptcha"': 'captcha_method = "personal"',
            'browser_captcha_generation_retries = 6': 'browser_captcha_generation_retries = 1',
        }
        for old, new in replacements.items():
            if old not in text:
                raise RuntimeError('Cấu hình upstream đã đổi; không tạo cấu hình suy đoán.')
            text = text.replace(old, new, 1)
        with config.open('x', encoding='utf-8') as output:
            os.chmod(config, 0o600)
            output.write(text)
    # Never silently reuse externally exposed/sample configuration on reinstall.
    settings = read_settings(config, python)
    if settings['server']['host'] != '127.0.0.1' or settings['global']['api_key'] == 'han1234' or settings['global']['admin_password'] == 'admin':
        raise RuntimeError('Cấu hình engine chưa riêng tư; kiểm tra trước khi chạy.')
    subprocess.run([str(python), '-c', "from src.main import app; assert any(r.path == '/v1/chat/completions' for r in app.routes); print('Flow import OK; no provider calls')"], cwd=checkout, check=True)
    marker = root / 'installation.json'
    marker.write_text(json.dumps({'repository': REPOSITORY, 'revision': actual, 'dependencies_checked': True,
                                  'generation_verified': False, 'config_file': str(config)}, indent=2), encoding='utf-8')
    return checkout, python


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    default = Path(os.environ.get('SCENEFORGE_LOCAL_DATA', str(Path.home() / '.sceneforge-local'))) / 'engines/flow2api'
    parser.add_argument('--directory', type=Path, default=default)
    parser.add_argument('--source', default=REPOSITORY, help='Reviewed Git source; useful for offline installation from an existing clone.')
    parser.add_argument('--start', action='store_true', help='Start the headed engine for manual Google login; requires a desktop browser.')
    parser.add_argument('--connect', action='store_true', help='Save this engine connection in the local SceneForge encrypted vault, without sending generation.')
    args = parser.parse_args()
    checkout, python = install(args.directory, args.source)
    if args.connect:
        from .vault import Vault
        config = read_settings(checkout / 'config/setting.toml', python)
        data = Path(os.environ.get('SCENEFORGE_LOCAL_DATA', str(Path.home() / '.sceneforge-local')))
        vault = Vault(data)
        connection = {'url': 'http://127.0.0.1:' + str(config['server']['port']), 'key': config['global']['api_key']}
        existing = vault.secret('flow-engine') or {}
        if any(existing.get(k) != v for k, v in connection.items()):
            vault.set_secret('flow-engine', {**connection, 'models': [], 'generation_verified': False})
        print('Engine connection saved in the local encrypted SceneForge vault; no generation submitted.')
    print('Installed pinned Flow engine. Config with local engine credentials:', checkout / 'config/setting.toml')
    print('Not verified: account, credit, real generation or concurrent provider work.')
    if args.start:
        print('Starting local engine. Complete login in its browser; no SceneForge generation is submitted by this installer.')
        subprocess.run([str(python), 'main.py'], cwd=checkout, check=True)


if __name__ == '__main__':
    main()
