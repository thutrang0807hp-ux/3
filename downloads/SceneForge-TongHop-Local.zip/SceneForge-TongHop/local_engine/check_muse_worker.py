"""Run in the Muse venv: actual SDK types/parsers with offline service fixtures."""
import asyncio
import json
import socket
import tempfile
from pathlib import Path
from types import SimpleNamespace

from muse_ai.media import VideoRef
from .muse_worker import execute, strict_session


class Auth:
    def __init__(self, state_dir):
        self.root = state_dir
        self.waterfall_id = self.csrf_token = self.login_referer = None
    async def restart_login(self):
        self.waterfall_id, self.csrf_token, self.login_referer = 'flow-fixture', 'csrf-fixture', 'https://muse.ai/'
    async def send_otp(self, email, region):
        assert email == 'fixture@example.com' and region == 'VN'
    async def load_cookies(self):
        assert (self.root / 'cookies.json').is_file()
    async def confirm_otp(self, otp):
        assert otp == '123456' and self.csrf_token == 'csrf-fixture'
    async def save_account(self):
        pass
    async def auth_check(self):
        return {'ok': True}
    async def save_cookies(self):
        (self.root / 'cookies.json').write_text(json.dumps([{'name': 'fixture', 'value': 'PRIVATE_COOKIE'}]))
    async def close(self):
        pass


class Client:
    def __init__(self, auth, state_dir):
        pass
    async def connect(self):
        pass
    async def chat_stream(self, **kwargs):
        return []
    async def sessions_list(self):
        return [{'session_id': 'old'}]
    async def generate_video(self, **kwargs):
        assert kwargs['download'] is False and kwargs['prompt'].endswith('private prompt')
        sid = await self._resolve_session_id(None, [{'session_id': 'new'}], {'old'})
        # The adapter must not download model-supplied external URLs with cookies.
        return SimpleNamespace(session_id=sid, videos=[VideoRef(path='workspace/result.mp4', url='http://127.0.0.1/private')])
    async def download_video(self, ref, output):
        assert ref.url is None
        Path(output).write_bytes(b'fixture output; backend separately probes real video')
    async def close(self):
        pass


async def main():
    # A fixture accidentally attempting network access must fail.
    def denied(*args, **kwargs):
        raise AssertionError('network forbidden in fixture check')
    socket.socket.connect = denied
    started = await execute({'operation': 'login_start', 'email': 'fixture@example.com'}, Auth, Client)
    assert started['ok'] and started['session']['pending']['csrf_token'] == 'csrf-fixture'
    session = started['session']
    confirmed = await execute({'operation': 'login_confirm', 'otp': '123456', 'session': session}, Auth, Client)
    assert confirmed['ok'] and 'pending' not in confirmed['session']
    with tempfile.TemporaryDirectory() as directory:
        output = Path(directory) / 'result'
        generated = await execute({'operation': 'generate', 'session': confirmed['session'],
                                   'prompt': 'private prompt', 'references': [], 'output': str(output)}, Auth, Client)
        assert generated['ok'] and output.is_file()
    for events in ([], [{'session_id': 'old'}], [{'session_id': 'a'}, {'session_id': 'b'}]):
        try:
            await strict_session(Client(None, None), None, events, {'old'})
            raise AssertionError('ambiguous/old session accepted')
        except ValueError:
            pass
    print('PASS: installed SDK VideoRef/session parser; isolated OTP state round trip; strict new-session binding; unsafe direct URL disabled. Fixtures only, no service requests.')


if __name__ == '__main__':
    asyncio.run(main())
