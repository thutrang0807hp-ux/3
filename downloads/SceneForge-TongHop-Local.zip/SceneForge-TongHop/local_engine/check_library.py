"""Real SQLite/files: dedup, transactions, backups, cleanup protection, ZIP and relocation."""
import sys,tempfile,os,time,hashlib,json,sqlite3,zipfile,threading
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from local_engine.library import Library,Conflict
with tempfile.TemporaryDirectory(dir='/tmp')as tmp:
 root=Path(tmp);lib=Library(root/'data');source=root/'video';source.write_bytes(b'video-content'*8192);asset=lib.add_file(source,'video/mp4');assert lib.add_file(source)==asset;assert len(list((lib.root/'kho').glob('*/*')))==1
 marker={'$sf':'blob','hash':asset['hash'],'type':'video/mp4'}
 room={'id':'room-1','productId':'p','name':'Video','stage':'editing','archived':False}
 rows=[{'db':'sceneforge-app-shell','store':'products','key':'p','value':{'id':'p','name':'Son'}},{'db':'sceneforge-app-shell','store':'rooms','key':'room-1','value':room},{'db':'sceneforge-app-shell','store':'files','key':'room-1:source','value':marker},{'db':'sceneforge-editor-local','store':'drafts','key':'room-1','value':{'payload':{'items':[{'asset':'original'}]},'media':[{'file':marker}]}}]
 saved=lib.commit(rows,0);assert saved['revision']==1;assert lib.status()['assets']==1
 assert lib.backups();backup=lib.backups()[0]['name'];assert not lib.cleanup_plan()['items']
 # Same asset used by two rooms and a timeline; rename does not touch asset path.
 second=[*rows,{'db':'sceneforge-app-shell','store':'files','key':'room-2:source','value':marker}];second[0]={**rows[0],'value':{'id':'p','name':'Đã đổi tên'}};lib.commit(second,1);assert lib.asset_path(asset['hash']).read_bytes()==source.read_bytes()
 try:lib.commit([],1);raise AssertionError('stale write accepted')
 except Conflict:pass
 assert len(lib.snapshot()['records'])==5
 # Failed metadata commit rolls back completely.
 invalid=[*second,{'db':'sceneforge-app-shell','store':'files','key':'missing','value':{'$sf':'blob','hash':'a'*64}}]
 try:lib.commit(invalid,2);raise AssertionError('missing file accepted')
 except ValueError:pass
 assert lib.snapshot()['revision']==2
 # Export contains all real bytes; import into another library and restore timeline exactly.
 bundle=lib.bundle('room-1');target=Library(root/'imported');imported=target.import_bundle(bundle,0);assert imported['records'];assert target.asset_path(asset['hash']).read_bytes()==source.read_bytes();assert any(r['db']=='sceneforge-editor-local'for r in imported['records'])
 with zipfile.ZipFile(bundle)as z:assert z.testzip()is None;assert 'du-an.json'in z.namelist()
 changed=[{**r,'value':{**r['value'],'name':'Tên khác'}}if r['store']=='products'else r for r in imported['records']];target.commit(changed,1)
 try:target.import_bundle(lib.bundle(),2);raise AssertionError('different product metadata overwrote imported room')
 except Conflict:pass
 # Missing asset makes restore refuse before changing metadata.
 path=lib.asset_path(asset['hash']);os.utime(path,(0,0));lib.commit([],2);assert not lib.cleanup_plan()['items'] # daily backup still protects old media
 source.write_bytes(b'orphan');orphan=lib.add_file(source);p=lib.asset_path(orphan['hash']);os.utime(p,(0,0));plan=lib.cleanup_plan();assert [i['hash']for i in plan['items']]==[orphan['hash']]
 lib.set_pin(orphan['hash'],True);assert not lib.cleanup_plan()['items'];lib.set_pin(orphan['hash'],False)
 with patch('send2trash.send2trash',side_effect=lambda p:Path(p).unlink())as trash:
  result=lib.cleanup(lib.cleanup_plan()['token']);assert result['files']==1;assert trash.call_count==1
 restored=lib.restore(backup,3);assert restored['revision']==4;assert len(restored['records'])==4
 # SQLite handles readers plus serialized commits; one of two same-revision writers must fail.
 results=[]
 def writer():
  try:lib.commit(restored['records'],4);results.append('ok')
  except Conflict:results.append('conflict')
 threads=[threading.Thread(target=writer)for _ in range(2)]
 for t in threads:t.start()
 for t in threads:t.join()
 assert sorted(results)==['conflict','ok']
 old=lib.root;dest=root/'new-drive'/'SceneForge';move=lib.relocate(dest,5);assert old.exists()and dest.exists()and move['oldKept'];assert Library(root/'data').root==dest;assert lib.asset_path(asset['hash']).read_bytes()==path.read_bytes()
 # Corrupt ZIP bytes are rejected; no partial records are committed.
 bad=root/'bad.zip'
 with zipfile.ZipFile(lib.bundle())as z,zipfile.ZipFile(bad,'w')as out:
  for name in z.namelist():out.writestr(name,b'bad-content'if name.startswith('assets/')else z.read(name))
 fresh=Library(root/'fresh')
 try:fresh.import_bundle(bad,0);raise AssertionError('corrupt asset accepted')
 except ValueError:pass
 assert fresh.snapshot()['records']==[]
 with lib.db()as db:assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert db.execute('PRAGMA journal_mode').fetchone()[0]=='wal'
 print('PASS real dedup, rename/shared timeline safety, CAS/transaction rollback, WAL/concurrent writers, verified room ZIP/import, collision/corruption rejection, daily backup references, pin + reviewed cleanup, monotonic restore and verified relocation retaining original. Send2Trash mocked only for test isolation.')
with tempfile.TemporaryDirectory(dir='/tmp')as tmp:
 root=Path(tmp);lib=Library(root/'data');raw=root/'media';raw.write_bytes(b'voice-bytes');voice=lib.add_file(raw,'audio/wav');raw.write_bytes(b'exported-video-bytes');video=lib.add_file(raw,'video/mp4')
 def mark(a,type):return {'$sf':'blob','hash':a['hash'],'type':type}
 rows=[{'db':'sceneforge-app-shell','store':'products','key':'p','value':{'id':'p','name':'Son'}},{'db':'sceneforge-app-shell','store':'rooms','key':'r','value':{'id':'r','name':'Video tên dễ đọc','productId':'p','photoDraft':{'voice':{'key':'voice:r:1'}}}},{'db':'sceneforge-app-shell','store':'files','key':'voice:r:1','value':mark(voice,'audio/wav')},{'db':'sceneforge-app-shell','store':'files','key':'r:export','value':mark(video,'video/mp4')}]
 lib.commit(rows,0);exports=list((lib.root/'xuat'/'Son').glob('*.mp4'));assert len(exports)==1 and exports[0].read_bytes()==b'exported-video-bytes'
 with zipfile.ZipFile(lib.bundle('r'))as z:manifest=json.loads(z.read('du-an.json'));assert any(r['key']=='voice:r:1'for r in manifest['records']);assert 'assets/'+voice['hash']in z.namelist()
 lib.commit(rows[:3],1);assert exports[0].exists() # deleting app export never deletes the user's output
 cache=lib.bundle();os.utime(cache,(0,0));plan=lib.cache_plan();lib.clean_cache(plan['token']);assert not cache.exists()and exports[0].exists()and lib.asset_path(voice['hash']).exists()
 lib.set_pin(video['hash'],True);target=Library(root/'new');target.import_bundle(lib.bundle(),0);assert target.status()['pins']==1;assert target.asset_path(video['hash']).is_file()
 recovered=lib.pause_recovered([{'db':'sceneforge-app-shell','store':'rooms','key':'x','value':{'stage':'analysis','allowAutoGemini':True}},{'db':'sceneforge-app-shell','store':'jobs','key':'j','value':{'status':'submitted'}},{'db':'sceneforge-app-shell','store':'prefs','key':'main','value':{}}]);assert recovered[0]['value']['analysisDeferred']and not recovered[0]['value']['allowAutoGemini'];assert recovered[1]['value']['status']=='unknown'and recovered[2]['value']['paused']
 print('PASS exported files have readable names and survive app deletion/cache cleanup; room ZIP includes voice files referenced by key; full ZIP preserves standalone pins; restore pauses provider work.')

with tempfile.TemporaryDirectory(dir='/tmp')as temp:
 import subprocess
 lib=Library(Path(temp)/'data');lib.commit([{'db':'sceneforge-app-shell','store':'rooms','key':'safe','value':{'id':'safe','name':'Keep'}}],0)
 code="import sqlite3,sys,time;db=sqlite3.connect(sys.argv[1]);db.execute('BEGIN IMMEDIATE');db.execute(\"DELETE FROM record\");db.execute(\"UPDATE meta SET value='999' WHERE key='revision'\");print('transaction-open',flush=True);time.sleep(30)"
 child=subprocess.Popen([sys.executable,'-c',code,str(lib.path)],stdout=subprocess.PIPE,text=True)
 assert child.stdout.readline().strip()=='transaction-open';child.kill();child.wait()
 assert lib.snapshot()['revision']==1 and len(lib.snapshot()['records'])==1
 with lib.db()as db:assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 print('PASS killed writer mid-transaction: pre-existing records and revision recovered intact from WAL.')
