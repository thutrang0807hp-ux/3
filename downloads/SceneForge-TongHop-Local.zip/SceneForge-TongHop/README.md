# SceneForge — bộ cục bộ gói 4

Bộ này chạy giao diện đã build và dịch vụ nhỏ của SceneForge trên **127.0.0.1:8840**. Không chứa tài khoản, key, cookie hay mô hình tải sẵn.

## Windows

Cài Python 3.11+; giải nén cả gói, mở `local_engine/start.bat`. Trình duyệt mở `http://127.0.0.1:8840/`. Nếu mở sớm trước khi máy chủ sẵn sàng, tải lại trang.

## macOS / Linux

```sh
sh local_engine/start.sh
```

Hoặc cài `local_engine/requirements.txt`, rồi chạy `python -m local_engine` tại thư mục gốc. Lệnh chuẩn chỉ bind loopback, không công khai máy chủ.

## Giọng VieNeu v3 tùy chọn

Trong cùng môi trường ảo:

```sh
python -m pip install "vieneu==3.8.3"
```

SDK được đọc theo repo `pnnbao97/VieNeu-TTS`, revision trong `docs/engine-audit/upstream-revisions.json`. Khi bấm Tạo giọng lần đầu, SDK có thể cần tải mô hình của nó. Dùng ONNX/CPU, một lượt mỗi lần. Mỗi nhịp được đọc riêng, lấy thời lượng WAV thật rồi nối để có mốc nhịp. Chưa kiểm chứng giọng miền Nam/tốc độ trên máy của bạn. Không tự dùng VieNeu V4 hoặc dịch vụ trả phí thay thế.

## Gemini tùy chọn

Vào Cài đặt → Giọng đọc & AI, lưu key trên bản localhost. Chỉ khi bạn bấm AI viết kịch bản / AI đạo diễn mới có yêu cầu ra Google. Không tự thử key bằng một lượt trả phí. Một lần gửi, không tự gửi lại khi mất kết nối; phí chưa xác minh được ghi chưa biết, có usage thực khi API trả về. Luồng phân tích mới đọc `models.list` của key để chọn Flash/Flash-Lite hỗ trợ, không gán tên mô hình hay bảng giá chưa xác minh. Model mặc định cũ chỉ còn cho adapter tương thích.

## Tài khoản

Cài trình duyệt cho cửa sổ đăng nhập:

```sh
python -m playwright install chromium
```

Kết nối tài khoản mở cửa sổ riêng để tự đăng nhập/xác minh. App không có trường nhập mật khẩu. Bấm Lưu phiên để mã hóa cookie rồi đóng cửa sổ; tài khoản được ghi **chưa kiểm chứng**, không giả là sẵn sàng. Có thể dùng `SCENEFORGE_BROWSER` trỏ Chrome/Chromium đã cài. Chưa tự chuyển cookie sang engine bên thứ ba.

Cookie và Gemini key mã hóa AES-GCM; khóa nằm trong thư mục dữ liệu riêng quyền 0600 trên Unix. Windows khóa được bọc bằng DPAPI của người dùng. Không có khóa mẫu trong source. Dữ liệu mặc định `~/.sceneforge-local`, có thể đặt `SCENEFORGE_LOCAL_DATA`. Bảo vệ cả tài khoản hệ điều hành và thư mục này; không chia sẻ nó trong ZIP.

## Động cơ tạo clip — CHƯA BẬT

Đã đọc repo gốc và giấy phép:

- flow2api: `TheSmallHanCat/flow2api`, MIT. Cấu hình mẫu còn admin/admin, key mẫu, bind 0.0.0.0, dịch vụ captcha thuê và tự refresh. **Không chạy nguyên trạng.**
- muse2api: `czg86389-hub/muse2api`, MIT. Repo dùng **muse.ai**, chưa xác minh là Meta AI. Mặc định mã hiện tại có bind 0.0.0.0, concurrency 2, lưu cookie JSON, keepalive/renew. Cần sửa và kiểm thử trước khi bật với tài khoản thật.
- VieNeu-TTS: Apache-2.0, SDK tùy chọn nêu trên.

Bộ này **không tự tải/chạy hai engine tạo clip**, chưa có adapter cấp phiên/đọc credit/quota hoặc worker thực thi Flow/Muse. Hàng chờ hai làn lưu chuẩn bị và phụ thuộc khung-trước; không gửi render, không giả tiến độ. Các quy tắc tài khoản/không gửi lại đã có hàm và bài kiểm tra cục bộ, chưa phải chứng nhận engine thật tuân thủ mọi quy tắc đó.

Chưa kiểm chứng giới hạn dịch vụ, watermark, giữ nhãn/mặt, quota ngày, xác minh tài khoản hoặc thời gian nghỉ. Không dùng captcha thuê. Đừng gửi cookie sang dịch vụ khác vì tên "Meta/Muse" trong tài liệu.

## Lưu dữ liệu

Bản Pages và bản localhost có origin khác nhau: bộ nhớ trình duyệt không tự chuyển giữa hai bản. Giữ bản cũ để mở dữ liệu đã có; JSON không nhúng toàn bộ video. Chưa có import trọn cây thư mục sang origin mới. Bản dựng hiện tại vẫn xuất bằng MediaRecorder, chưa có FFmpeg xuất nền.

## Kho kịch bản (gói mới)

Kho được mở từ node Công thức trong luồng Từ ảnh: tự thêm, lọc, đổi tên, xóa, chọn và đánh giá sau khi xuất. Dữ liệu chung nằm trong trình duyệt; không mất khi dọn tệp của phòng. Có snapshot cho các phòng đã dùng.

Có Gemini key cục bộ: rút công thức từ lời có mốc giây, phân tích video MP4/WebM dọc tối đa 18 MB trong kho (có xác nhận sử dụng API), gợi ý công thức và viết lời mới theo khung. Tự rút một lần cho video mẫu có lời đã phân tích; chỉ mới dò hình thì chưa đủ. Không tự gửi lại khi lỗi, không lưu nguyên lời nguồn vào kho. Chưa thử bằng key thật; phí tiền chưa quy đổi khi chưa có bảng giá xác minh.

Thêm `?demo=1` vào địa chỉ để xem dữ liệu mẫu lưu riêng, không kết nối tài khoản hay gọi AI. Bỏ query để quay về dữ liệu làm việc.

## Gói 5

Mở bánh răng → Cài đặt để xem bảy mục mới và màn chào. Đồng hành vẫn nghe ở `127.0.0.1:8840`; không đổi sang cổng mẫu 8000 trong đặc tả. Key, cookie và kết quả kiểm tra lưu qua vault mã hóa đã có.

Cập nhật này thêm node gộp, cài đặt, chuông phân mức và tự xử lý logo trên bản sao clip nhập. Đọc `docs/package5-implementation.md` để phân biệt phần đã chạy với phần chưa nối (engine render, cài model, cân âm/ducking, dời ổ). Không bảo đảm xử lý được mọi logo Veo; không loại SynthID. Tệp SRT tùy chọn xuất cùng video lấy từ phụ đề thật, không tự nhận giọng nói.

## Bản tổng hợp: Gemini trong node và MP4 FFmpeg

Xem `docs/aggregate-implementation.md` và bảng thử riêng. Trong node Phân tích, bấm **Đo trên máy · CPU** để lấy lời/mốc, rồi **AI · ảnh & bản chữ**. Luồng mới chỉ gửi ảnh và bản chữ đã đo; app quản lý lời gốc và mốc giây. Adapter gửi video cũ chỉ giữ để tương thích, không còn là nút mặc định. Kết quả được xem trước trước khi áp dụng. Kết quả đã nhận có thể mở lại sau reload mà không gửi thêm lượt. Chưa dùng key thật để chứng nhận chất lượng/quota/chi phí.

Nếu máy có **FFmpeg và ffprobe trong PATH**, hộp Xuất tự hiện lựa chọn **MP4 bằng FFmpeg** và cân âm lượng. Vẫn dựng hình/hiệu ứng theo thời gian thực bằng trình duyệt trước, sau đó FFmpeg mã hóa H.264/AAC. Giới hạn 2 phút/100 MB; chưa phải dựng nền toàn bộ timeline bằng FFmpeg. Nếu động cơ lỗi, có nút tải bản ghi dự phòng, không đánh dấu MP4 thành công giả. MP4/SRT được giữ theo phòng, bản gốc không bị thay thế.

## Bổ sung CPU từ gói tổng hợp mới

Node Phân tích → **Đo trên máy · CPU** dùng PySceneDetect, FFmpeg, OpenCV; tùy chọn RapidOCR và faster-whisper. Xem `docs/aggregate-2-implementation.md`. Cần Python 3.10–3.12 và FFmpeg/ffprobe. Chạy `local_engine/install-cpu.bat` để cài các thư viện CPU riêng, khởi động lại app; không tải model Whisper trong bước này. Chuẩn bị model tùy chọn bằng `python -m local_engine.prepare_whisper --model base --download` trong môi trường app.

Phân tích không tự tải model/gửi video lên dịch vụ. Kết quả được xem trước, có dừng và khôi phục; cảnh vàng cần rà. OCR chỉ lấy mẫu; OpenCV chỉ ước lượng. Chưa kiểm chứng chép lời bằng model thật, video TikTok/Trung của người dùng hoặc máy Windows. Giá/credit vẫn không đoán từ tài liệu.

## Local AI / rà clip

Xem `docs/local-ai-implementation.md`. Clip nhập mới được lấy 5 khung để người dùng rà trên máy; không tự kết luận đúng mặt/logo. Trong node Phân tích có **Mô tả local · Ollama**; trong Kiểm clip có lựa chọn đối chiếu bằng model vision local đã chuẩn bị tại `127.0.0.1:11434`. Không tự tải model hoặc dùng model cloud/tài khoản chat. Ollama/model thật chưa được kiểm chứng trong môi trường phát triển này; adapter và UI được kiểm bằng transport giả. Dự án cũ/clip cũ giữ nguyên, không tự quét lại khi mở.

## Tài khoản · giao diện mới

Cài đặt → Tài khoản mở dashboard có sơ đồ, nhật ký theo dịch vụ, bảng kéo ưu tiên và biểu đồ chi phí xác nhận. Demo `?demo=1&accounts=flow` dùng dữ liệu minh họa lưu riêng, không gọi API tài khoản. Tên/ghi chú/bật-tắt/ưu tiên có lưu trên bản cục bộ; bật tài khoản không tự xác minh phiên. Chưa nối kiểm tra/cập nhật engine hay đọc credit/quota thật. Xem `docs/accounts-dashboard-implementation.md`.

## Phân tích · bản chốt 22/10

Xem `docs/analysis-revision-3-implementation.md`. Lời CPU có nhãn Thật / Mảnh vụn / Nghi bịa, giữ câu nghi bịa để bạn kiểm tra chứ không xóa. Câu nghi bịa chưa được giữ lại không vào AI, prompt Flow hay phụ đề. Ngưỡng còn tạm thời. Thiếu model Whisper: chuẩn bị model hoặc nhập SRT, không giả là đã chép được lời.

Gemini nhận ảnh + bản chữ; chỉ trả mã cảnh/câu. Sai mã hoặc tự bịa thời gian thì kết quả vàng, không áp dụng. OpenAI chỉ gửi sau xác nhận riêng có phí, dùng key mã hóa trong Cài đặt → AI. Không tự chuyển nguồn. Lỗi có tên nhà cung cấp/mã HTTP và chi tiết đã loại key.

Ảnh nhập JPEG/PNG giữ nguyên byte, ảnh xem trước tách riêng. Kiểm ảnh trên máy cần OpenCV/RapidOCR và ảnh nguồn còn trong kho: kích thước 2K, độ nét, nhãn. Dự án áp dụng phân tích mới cần ảnh đạt kiểm tra trước khi duyệt nhanh. Dự án cũ không bị khóa tự động. Chuẩn bị hai biến thể, nâng 2K và tạo lại bằng Pro hiện là hướng dẫn thao tác Flow thủ công; chưa có adapter tự tạo/nâng ảnh và chưa xác minh credit.

Bảng thử cập nhật 30 mục, giữ trạng thái chưa thử thật; bài test với dữ liệu tổng hợp và provider giả không chứng nhận Flow/Gemini/model Whisper thật hoặc Windows.

## Gói 6 · lưới khung/clip, hàng phân tích và sản phẩm

Tab Tạo video dùng lưới 6 cột, bộ lọc, đếm lỗi và duyệt các khung đạt. Bấm ảnh/clip để so khung gốc và các phiên bản, ← → đổi cảnh, Enter duyệt khung, R chuẩn bị lại, Esc đóng. Nút Danh sách chi tiết giữ đầy đủ bộ công cụ cũ. Mô hình Lite/Pro và Veo chỉnh trong màn xem lớn. Tạo lại vẫn là chuẩn bị prompt khi Flow chưa có adapter; không tự trừ credit.

Thả nhiều video tạo ngay từng phòng tên nối tiếp, tối đa hai phòng phân tích cùng lúc. CPU nặng xếp hàng một lượt để tránh tranh tài nguyên. Có Để sau / Phân tích, giữ bước đã xong và khôi phục khi tải lại. Không gửi Gemini mặc định: chọn rõ Tự gửi ảnh/bản chữ trong Video mới hoặc bảng chọn sản phẩm nếu muốn dùng hạn mức API. Lượt Gemini chưa rõ kết quả không tự gửi lại. Thiếu CPU/model/key thì hiển thị phần cần thêm, không giả bước đã xong.

Menu ⋯ sản phẩm: đổi tên/màu, bộ ảnh, gộp, lưu trữ và xóa có xem trước. Xóa dùng Thùng rác trong app, khôi phục ít nhất 30 ngày, chưa đưa tệp vào Thùng rác hệ điều hành và chưa tự dọn quá hạn. Tệp trong thư mục máy và bản xuất giữ nguyên. Số byte trong hộp là tổng payload tệp lưu trong app, chưa phải dung lượng vật lý ngoài đĩa. Kho kịch bản trên thanh trái dùng cùng kho với Từ ảnh; tự lưu khung nhịp theo mốc cảnh không cần gọi thêm AI. Xem docs/package6-implementation.md.

## Bản tổng hợp · xuất trực tiếp từ timeline

Mở ứng dụng localhost, vào Dựng → Xuất video → **FFmpeg · trực tiếp từ timeline**. Cần FFmpeg và ffprobe trên PATH. Engine nhận byte nguồn + timeline, mã hóa CPU thành MP4, có tiến độ/ETA/hủy; không dùng MediaRecorder. Giới hạn hiện tại 10 phút, 512 MB tư liệu, 120 mục. Đóng hộp xuất hoặc chuyển tab trình duyệt vẫn tiếp tục; giữ ứng dụng/phòng đang xuất mở cho tới khi nhận tệp.

Có chữ tĩnh, âm lượng/fade/speed, layer và chuyển cảnh tuyến tính giữ thời gian cũ. Keyframe/chữ động/chỉnh màu/effect âm thanh nâng cao/tiếng gốc ở chuyển cảnh chưa khớp renderer mới: app báo rõ và bạn chọn **Bộ ghi trình duyệt** để giữ hiệu ứng. Đây chưa phải toàn bộ MVP trong đặc tả mới. Chi tiết đối chiếu, bài thử, giới hạn và phần cần model/tài khoản thật: `docs/consolidated-implementation.md`.
