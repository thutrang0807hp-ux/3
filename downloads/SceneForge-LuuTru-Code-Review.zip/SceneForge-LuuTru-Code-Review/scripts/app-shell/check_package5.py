from pathlib import Path
from functools import partial
import http.server,threading,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1700,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://localhost:'+str(server.server_port)+'/?demo=1');page.wait_for_function('SceneForgeApp.getState().rooms.length===7',timeout=60000)
 page.locator('#openStorage').click();expect(page.locator('.g5Settings')).to_be_visible();page.wait_for_timeout(250);assert page.locator('#shellDialog').bounding_box()['width']>1000;page.screenshot(path='/tmp/g5-settings.png');expect(page.locator('#g5SaveKey')).to_be_disabled()
 page.locator('[data-g5-tab=export]').click();page.locator('[data-g5-setting=resolution]').select_option('720');page.locator('[data-g5-setting=sidecarSrt]').check();page.wait_for_timeout(150);assert page.evaluate('SceneForgeApp.settings.get().resolution')==720
 page.locator('#closeDialog').click();page.evaluate('SceneForgeApp.settings.notify("Khung chờ duyệt · phòng thử",null,{level:"attention",kind:"frames"})');page.evaluate('SceneForgeApp.settings.notify("Phân tích xong",null,{level:"done",kind:"analysis"})');assert page.locator('#notificationCount').inner_text()=='1';page.locator('#openNotifications').click();expect(page.locator('.g5Notice')).to_have_count(2);page.locator('[data-g5-filter=attention]').click();expect(page.locator('.g5Notice')).to_have_count(1);page.locator('#g5ReadAll').click();expect(page.locator('#notificationCount')).to_be_hidden();page.locator('#closeDialog').click()
 rid=page.evaluate('SceneForgeApp.getState().rooms.find(r=>r.mode==="reference").id');page.evaluate('(id)=>SceneForgeApp.openRoom(id,"analysis")',rid);wf=page.frame_locator('#workflowFrame');expect(wf.locator('#node-frames')).to_be_visible(timeout=20000);page.wait_for_timeout(500);expect(wf.locator('#node-frames .g5GroupedRow')).to_have_count(3);expect(wf.locator('#node-videos .g5GroupedRow')).to_have_count(3);expect(wf.locator('#node-references [data-ref-description]')).to_have_count(4)
 wf.locator('[data-ref-description=background]').fill('Gói 5 phải giữ nội dung này');wf.locator('[data-g5-merge=captionStyle]').select_option('box');page.wait_for_timeout(300)
 wf.locator('.canvasTools [data-action=fit]').click();page.screenshot(path='/tmp/g5-workflow.png');data=page.locator('#workflowFrame').evaluate('''f=>{const d=f.contentDocument,ns=[...d.querySelectorAll('.node')].map(n=>({id:n.id,x:n.offsetLeft,y:n.offsetTop,r:n.offsetLeft+n.offsetWidth,b:n.offsetTop+n.offsetHeight}));return{overlap:ns.flatMap((a,i)=>ns.slice(i+1).filter(b=>a.x<b.r&&a.r>b.x&&a.y<b.b&&a.b>b.y).map(b=>[a.id,b.id])),ids:ns.map(n=>n.id)};}''');assert not data['overlap'],data
 wf.locator('#node-frames header').first.click();expect(wf.locator('#node-frames')).to_have_class(__import__('re').compile('nodeSelected'));expect(wf.locator('#minimap i.minimapSelected')).to_have_count(1)
 header=wf.locator('#node-frames > header').bounding_box();page.mouse.move(header['x']+header['width']/2,header['y']+header['height']/2);page.mouse.down();page.mouse.move(header['x']+header['width']/2,header['y']+header['height']/2+45,steps=8);page.mouse.up();position=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState().layout.nodes["node-frames"]');assert position['y']>55,position
 wf.locator('[data-approve]').first.click();page.wait_for_timeout(150);after=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState().layout.nodes["node-frames"]');assert after==position,(position,after)
 wf.locator('[data-detail]').first.click();expect(wf.locator('#details')).to_be_visible();page.locator('#homeFromRoom').click();page.reload();page.wait_for_function('SceneForgeApp.getState().rooms.length===7');assert page.evaluate('SceneForgeApp.settings.get().resolution')==720
 print('ERRORS',errors);assert not errors,errors;b.close()
server.shutdown()
print('PASS G5 settings, persistence, bell classification/filters/read, compact nodes with full editors, all references retained, no overlap and minimap selection')
