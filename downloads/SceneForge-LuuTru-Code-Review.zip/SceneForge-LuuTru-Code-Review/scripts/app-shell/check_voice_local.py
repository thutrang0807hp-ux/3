"""Opt-in real-model browser test; requires SCENEFORGE_VIENEU_DIRECTORY prepared.

No account/provider call. Exercises actual UI -> local API -> CPU model -> stored WAV.
"""
import os, sys, socket, subprocess, tempfile, time, urllib.request, base64, json, wave
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

root = Path(__file__).resolve().parents[2]
engine = os.environ.get('SCENEFORGE_VIENEU_DIRECTORY')
if not engine:
    raise SystemExit('Set SCENEFORGE_VIENEU_DIRECTORY to a prepared real VieNeu engine. This test never downloads a model.')
artifacts = root / 'artifacts/voices'
artifacts.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix='sf-voice-real-', dir='/tmp') as temporary:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]
    log = open(Path(temporary) / 'server.log', 'w')
    proc = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'local_engine.server:app', '--host', '127.0.0.1', '--port', str(port), '--log-level', 'warning'], cwd=root,
                            env={**os.environ, 'SCENEFORGE_LOCAL_DATA': temporary}, stdout=log, stderr=log)
    base = f'http://127.0.0.1:{port}'
    try:
        for _ in range(100):
            try:
                urllib.request.urlopen(base + '/local-api/health', timeout=.2); break
            except OSError:
                time.sleep(.1)
        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1600, 'height': 1000})
            page.set_default_timeout(120000)
            errors, posts = [], []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.on('request', lambda r: posts.append(r.url) if r.method == 'POST' else None)
            page.goto(base)
            page.wait_for_function('!!db&&products.length>0&&SceneForgeStorage.state.active')
            page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'voice-real',slug:'voice-real',name:'Thử giọng CPU thật',mode:'photos',stage:'review',productId:products[0].id,createdAt:Date.now()};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
            page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length>0')
            frame = page.locator('#workflowFrame').content_frame
            frame.locator('body').evaluate("async()=>{draft.beats=[{id:'a',name:'Mở đầu',type:'wide',seconds:3,text:'Xin chào, đây là giọng đọc được tạo ngay trong SceneForge.'},{id:'b',name:'Kết thúc',type:'detail',seconds:3,text:'Phần mềm đã dùng model trên máy để đọc kịch bản này.'}];draft.voice.mode='ai';draft.voice.preset='Hải Đăng';await save();render();}")
            expect(frame.locator('[data-action=create-voice]')).to_be_enabled()
            assert frame.locator('[data-local-voice] option').count() == 26
            frame.locator('[data-action=create-voice]').click()
            frame.locator('#voicePreview').wait_for(state='attached')
            frame.locator('body').evaluate("async()=>{for(let i=0;i<1200&&!draft.voice.key;i++)await new Promise(r=>setTimeout(r,100));}")
            result = frame.locator('body').evaluate("async()=>({voice:draft.voice,beats:draft.beats.map(b=>({id:b.id,text:b.text,seconds:b.seconds})),base64:await new Promise(async(resolve,reject)=>{const f=await bridge.getFile(draft.voice.key);if(!f)return reject(Error('No stored voice'));const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.readAsDataURL(f);})})")
            assert result['voice']['key'] and result['voice']['duration'] > 0
            assert abs(sum(b['seconds'] for b in result['beats']) - result['voice']['duration']) < .01
            output = artifacts / 'SceneForge-HaiDang-CPU.wav'
            output.write_bytes(base64.b64decode(result.pop('base64')))
            with wave.open(str(output)) as audio:
                assert audio.getframerate() == 48000 and audio.getnchannels() == 1 and audio.getsampwidth() == 2
                assert audio.getnframes() > 48000
            # Persist/reload retains actual media and exact beat timing.
            await_save = page.evaluate('SceneForgeStorage.flush()')
            page.reload()
            page.wait_for_function('roomFor("voice-real")?.photoDraft?.voice?.key')
            assert page.evaluate('roomFor("voice-real").photoDraft.voice.duration') == result['voice']['duration']
            assert len([u for u in posts if u.endswith('/local-api/tts')]) == 1
            assert not [u for u in posts if '/local-api/ai/' in u or '/local-api/flow/jobs' in u]
            assert not errors, errors
            (artifacts / 'real-voice-check.json').write_text(json.dumps({'voice': result['voice']['preset'], 'duration': result['voice']['duration'], 'beats': result['beats'], 'backend': 'onnx-cpu-fp32', 'real_model': True, 'api_calls': 1}, ensure_ascii=False, indent=2))
            browser.close()
            print('PASS real browser -> local TTS -> real CPU model -> original WAV stored/reloaded; 25 voices, exact per-beat timing, one TTS request, no cloud provider calls. Output:', output)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait()
        log.close()
