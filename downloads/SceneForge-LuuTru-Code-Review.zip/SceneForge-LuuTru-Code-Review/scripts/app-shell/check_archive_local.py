"""Final-only archives survive the real SQLite checkpoint and a new browser profile."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
video=base64.b64encode((root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()).decode()
with tempfile.TemporaryDirectory(prefix='sf-archive-library-',dir='/tmp')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp},stdout=subprocess.PIPE,stderr=subprocess.PIPE);base=f'http://127.0.0.1:{port}'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);context=browser.new_context();page=context.new_page();errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append((r.method,r.url)));page.goto(base);page.wait_for_function('!!db&&products.length>0&&SceneForgeStorage.state.active');page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}")
   page.evaluate('''async video=>{const file=new Blob([Uint8Array.from(atob(video),c=>c.charCodeAt(0))],{type:'video/mp4'}),p=products[0];const room={id:'archive-local',name:'Archive local',slug:'archive-local',productId:p.id,mode:'reference',stage:'exported',exportedAt:Date.now(),archived:true,createdAt:Date.now()};rooms.push(room);await persistRoom(room);await io('files','readwrite',room.id+':export',file);await io('files','readwrite',room.id+':source',new Blob(['PRIVATE-INTERMEDIATE']));await writeForeign('projects','sceneforge-workflows',room.id,{id:room.id,script:[{start:0,end:1,original:'Original',newText:'Final script'}],scenes:[],assetEntries:[]});await SceneForgeStorage.flush();}''',video)
   # Simulate a durable prepared journal followed by interruption, then recover in a new profile.
   page.evaluate('''async()=>{const id='archive-local';await io('prefs','readwrite',archiveJournalKey,{id,room:clone(roomFor(id)),workflow:await workflowRecord(id),editor:null,files:await archiveOwnFiles(id),phase:'prepared'});await io('files','readwrite',id+':source');await SceneForgeStorage.flush();}''');context.close();context=browser.new_context();page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);page.wait_for_function('rooms.some(r=>r.id==="archive-local")');page.evaluate('archiveRecoverJournal()');assert page.evaluate("async()=>!!await io('files','readonly','archive-local:source')")
   # Auto compaction only follows explicit verified/hash-matched consent, and respects pin.
   status=page.evaluate('''async()=>{const r=roomFor('archive-local'),plan=await archiveCompactPlan(r.id);r.archiveVerified=plan.verified;r.archivePolicy={automatic:true,pinned:true,paused:false,dueAt:Date.now()-1};await persistRoom(r);await archiveRunDue();return r.archiveState||'editable';}''');assert status=='editable'
   page.evaluate("async()=>{roomFor('archive-local').archivePolicy.pinned=false;await persistRoom(roomFor('archive-local'));await archiveRunDue();}");assert page.evaluate("roomFor('archive-local').archiveState")=='final-only';page.evaluate('SceneForgeStorage.flush()');snap=page.evaluate('SceneForgeStorage.api("snapshot")');assert not any(r['store']=='files'and r['key']=='archive-local:source'for r in snap['records']);assert not any(r['store']=='prefs'and r['key']=='archive-compaction-journal-v1'for r in snap['records'])
   context.close();context=browser.new_context();page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);page.wait_for_function('roomFor("archive-local")?.archiveState==="final-only"');assert page.evaluate("roomFor('archive-local').archiveText.workflow.script[0].newText")=='Final script';assert page.evaluate("async()=>!!await io('files','readonly','archive-local:export')");assert not page.evaluate("async()=>!!await io('files','readonly','archive-local:source')")
   assert not errors,errors;assert not [u for method,u in calls if method=='POST'and any(x in u for x in ['/local-api/ai/','/local-api/tts','/local-api/render'])];browser.close();print('PASS real SQLite journal recovery, pinned schedule, explicitly verified due compaction, canonical source removed/export+script preserved, fresh-profile restoration, no provider submission.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
