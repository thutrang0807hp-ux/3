"""Send imported real PNG through the visible dialog into a real workflow frame."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
import tempfile
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory(dir='/tmp')as temp,sync_playwright()as p:
  file=Path(temp)/'real.png';Image.new('RGB',(90,160),'#c17389').save(file)
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{server.server_port}/?demo=1#batch');page.wait_for_function('rooms.length===7&&!!batchState');target=page.evaluate('rooms.find(r=>r.mode==="reference").id')
  # Seed/open the actual room so the destination has persisted scene records.
  page.evaluate('(id)=>openRoom(id,"analysis")',target);page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().scenes.length>0');before=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState()');scene=before['scenes'][0]['id'];page.locator('#openBatchStudio').click();page.locator('#batchPrompts').fill('Khung nhập cho cảnh 1');page.locator('#batchEnqueue').click();page.wait_for_function('batchState.jobs.length===1');job=page.evaluate('batchState.jobs[0].id');page.evaluate('(id)=>batchImportTarget=id',job);page.locator('#batchResultFiles').set_input_files(file);page.wait_for_function('batchState.jobs[0].origin==="imported"');page.locator('[data-batch-select]').click();page.locator('[data-batch-send-workflow]').click();page.locator('#batchDestinationRoom').select_option(target);page.locator('#batchDestinationRoom').dispatch_event('change');expect(page.locator('#batchDestinationScene option')).not_to_have_count(0);page.locator('#batchDestinationScene').select_option(scene);page.locator('#batchDeliverFrame').click();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().scenes[0].frames.some(f=>f.batchResultKey)');after=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState()');assert len(after['scenes'][0]['frames'])==len(before['scenes'][0]['frames'])+1;assert after['scenes'][0]['approvedFrame']==before['scenes'][0]['approvedFrame'];assert after['scenes'][0]['clips']==before['scenes'][0]['clips'];assert after['scenes'][0]['chosen']==before['scenes'][0]['chosen'];assert after['scenes'][0]['frames'][-1]['status']=='pending'
  # Delivering the same result twice is idempotent; malformed multi-item input is atomic.
  result=page.locator('#workflowFrame').evaluate('''async f=>{const w=f.contentWindow,api=w.SceneForgeWorkflow,s=api.getState(),frame=s.scenes[0].frames.at(-1),item={sceneId:s.scenes[0].id,image:frame.image,resultKey:frame.batchResultKey,origin:'imported'};const twice=await api.importBatchFrames({roomId:s.id,items:[item]});let rejected=false;try{await api.importBatchFrames({roomId:s.id,items:[{...item,resultKey:'new-valid'}, {...item,sceneId:'missing'}]});}catch{rejected=true;}return {twice,rejected,count:api.getState().scenes[0].frames.length};}''');assert result['twice']['added']==0 and result['rejected'];assert result['count']==len(after['scenes'][0]['frames']);assert not errors,errors;b.close();print('PASS real imported PNG into selected product/room/scene; frame pending, approved frame/clip choices retained; repeated delivery deduplicated; invalid multi-item payload atomic. No AI calls.')
finally:server.shutdown()
