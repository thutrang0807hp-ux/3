"""Recovered CPU results require the same source bytes and explicit review."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
import hashlib,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();calls=[];page.on('request',lambda r:calls.append((r.method,r.url)));page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html');page.wait_for_function('typeof window.SceneForgeWorkflow?.localAnalysis?.resume==="function"')
  before=page.evaluate('''()=>{assets.set('cpu-guard-source',new Blob(['same-source-bytes']));project.source={...project.source,asset:'cpu-guard-source'};return JSON.stringify({scenes:project.scenes,script:project.script});}''')
  result={'source_sha256':'0'*64,'scenes':[{'start':0,'end':1,'thumbs':[],'sample_times':[],'camera':{'kind':'static'},'quality':{'brightness_0_255':100},'faces':{'detected':False},'warnings':[],'ocr':[]}],'transcript':[],'speech':{'state':'not_requested'},'ocr_state':'not_requested','elapsed_seconds':1,'timing_note':'fixture','cuts':[0,1]}
  def reply(route):route.fulfill(status=200,content_type='application/json',body=json.dumps({'id':'aabbcc','state':'done','result':result}))
  page.route('**/local-api/analysis/local/jobs/aabbcc',reply)
  page.evaluate('SceneForgeWorkflow.localAnalysis.resume("aabbcc")');expect(page.locator('#cpuProgressError')).to_contain_text('không khớp');assert not page.evaluate('!!project.analysis.pendingCPU');assert page.evaluate('JSON.stringify({scenes:project.scenes,script:project.script})')==before
  result['source_sha256']=hashlib.sha256(b'same-source-bytes').hexdigest();page.evaluate('SceneForgeWorkflow.localAnalysis.resume("aabbcc")');expect(page.locator('#cpuApply')).to_be_visible();assert page.evaluate('!!project.analysis.pendingCPU');assert page.evaluate('JSON.stringify({scenes:project.scenes,script:project.script})')==before
  # Corruption/missing result fields cannot reach the Apply screen.
  page.evaluate('delete project.analysis.pendingCPU');result['scenes']=[];page.evaluate('SceneForgeWorkflow.localAnalysis.resume("aabbcc")');expect(page.locator('#cpuProgressError')).to_contain_text('thiếu dữ liệu');assert not page.evaluate('!!project.analysis.pendingCPU')
  assert not [url for method,url in calls if method!='GET'and'/local-api/'in url],calls
  browser.close();print('PASS recovered CPU hash mismatch/missing result rejected; matching source opens review without altering scenes/script; only GET status, no analysis/provider submission.')
finally:server.shutdown()
