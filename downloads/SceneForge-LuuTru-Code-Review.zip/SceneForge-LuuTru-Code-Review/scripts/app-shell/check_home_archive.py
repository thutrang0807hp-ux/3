from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1536,'height':1000});errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
  page.goto(f'http://localhost:{server.server_port}/?demo=1');page.wait_for_function('rooms.length===7&&prefs.showcaseVersion===1',timeout=60000);page.wait_for_function('document.querySelectorAll("#board [data-room]").length===7');page.evaluate('document.fonts.ready');page.screenshot(path='/tmp/home-stable-preview.png')
  # A normal background update preserves the actual DOM nodes, focused button and scroll.
  page.evaluate('''()=>{window.originalCard=document.querySelector('#board [data-room]');window.originalImg=originalCard.querySelector('img');window.originalProduct=document.querySelector('[data-product]:not([data-product=all])');window.originalColumn=document.querySelector('.columnCards');window.imageChanges=[];window.observer=new MutationObserver(ms=>imageChanges.push(...ms.filter(m=>m.type==='childList'||m.attributeName==='src')));observer.observe(document.querySelector('#board'),{subtree:true,childList:true,attributes:true});}''')
  page.locator('[data-open-room]').first.focus();page.evaluate('window.focused=document.activeElement;for(let i=0;i<8;i++)render()');page.wait_for_timeout(100)
  assert page.evaluate('originalCard===document.querySelector("#board [data-room]")&&originalImg===originalCard.querySelector("img")&&originalProduct===document.querySelector("[data-product]:not([data-product=all])")&&focused===document.activeElement')
  assert page.evaluate('imageChanges.length')==0,page.evaluate('imageChanges.map(m=>m.target.outerHTML.slice(0,100))')
  # Background updates with a lot of cards keep the viewport where the user left it.
  page.evaluate('''()=>{const base=rooms.find(r=>r.stage==='review');for(let i=0;i<14;i++)rooms.push({...structuredClone(base),id:'scroll-fixture-'+i,name:'Scroll fixture '+i});render();document.querySelector('[data-stage=attention] .columnCards').scrollTop=240;}''');assert page.locator('[data-stage=attention] .columnCards').evaluate('(n)=>n.scrollTop')>0
  y=page.locator('[data-stage=attention] .columnCards').evaluate('(n)=>n.scrollTop');page.evaluate('rooms.find(r=>r.stage==="review").pendingFrames=1;render()');assert page.locator('[data-stage=attention] .columnCards').evaluate('(n)=>n.scrollTop')==y
  page.locator('#archiveProduct').click();expect(page.locator('#archiveView')).to_be_visible();page.locator('#archiveBack').click();expect(page.locator('#board')).to_be_visible();assert page.locator('[data-stage=attention] .columnCards').evaluate('(n)=>n.scrollTop')==y, page.evaluate('({last:deskLastKey,positions:[...deskPositions],actual:document.querySelector("[data-stage=attention] .columnCards").scrollTop,header:document.querySelector(".deskHeader").offsetHeight})')
  # A typed inline product name survives updates from unrelated rooms.
  product=page.evaluate('products[0].id');page.locator('[data-g6-rename="'+product+'"]').dblclick();page.locator('.g6InlineRename').fill('Tên đang nhập');page.evaluate('render()');expect(page.locator('.g6InlineRename')).to_have_value('Tên đang nhập');page.locator('.g6InlineRename').press('Escape');expect(page.locator('.g6InlineRename')).to_have_count(0)
  page.evaluate('rooms=rooms.filter(r=>!r.id.startsWith("scroll-fixture-"));render()')
  header=page.locator('.deskHeader').bounding_box();title=page.locator('#deskTitle').bounding_box();sidebar=page.locator('.products').bounding_box()
  page.locator('#archiveProduct').click();expect(page.locator('#archiveView')).to_be_visible();expect(page.locator('#shellDialog')).not_to_be_visible();expect(page.locator('.archiveEmpty h2')).to_have_text('Lưu trữ đang trống');expect(page.locator('#archiveClean')).to_have_text('Chưa có tệp tạm',timeout=10000)
  assert page.locator('.deskHeader').bounding_box()==header;assert page.locator('#deskTitle').bounding_box()['y']==title['y'];assert page.locator('.products').bounding_box()==sidebar
  # Populate actual isolated IndexedDB records, including an old automatic archive.
  ids=page.evaluate('''async()=>{const list=rooms.slice(0,3);for(const [i,r] of list.entries()){r.archived=true;r.archivedAt=Date.now()-i*86400000;await io('rooms','readwrite',r.id,r);}const old=rooms[6];old.archived=false;old.exportedAt=Date.now()-9*86400000;delete old.archiveRestoredAt;await io('rooms','readwrite',old.id,old);await io('files','readwrite','cache:preview:test',new Blob(['preview']));await io('files','readwrite',list[0].id+':not-cache',new Blob(['keep me']));render();return [...list.map(r=>r.id),old.id];}''')
  expect(page.locator('.archiveRow')).to_have_count(4);page.wait_for_function('document.querySelector("#archiveSize").textContent!=="Đang đo…"');page.screenshot(path='/tmp/archive-integrated-preview.png')
  page.locator('#archiveSearch').fill('không có kết quả này');expect(page.locator('.archiveEmpty h2')).to_have_text('Không tìm thấy video');page.locator('[data-archive-empty=filters]').click();expect(page.locator('.archiveRow')).to_have_count(4)
  # Cache cleanup requires a click and keeps source/owned/shared files.
  await_key=ids[0];before=page.evaluate('async id=>(await io("files","readonly",id+":source")).size',await_key);shared=page.evaluate('products[0].sceneBank[0].key');page.locator('#archiveClean').click();page.locator('#archiveConfirmClean').click();expect(page.locator('#archiveClean')).to_have_text('Chưa có tệp tạm')
  assert page.evaluate('async()=>!(await io("files","readonly","cache:preview:test"))');assert page.evaluate('async id=>(await io("files","readonly",id+":source")).size',await_key)==before;assert page.evaluate('async id=>(await io("files","readonly",id+":not-cache")).size',await_key)==7
  # Restoring an old export persists and does not fall back into Archive immediately.
  page.locator('[data-archive-restore="'+ids[3]+'"]').click();expect(page.locator('.archiveRow')).to_have_count(3);page.reload();expect(page.locator('.archiveRow')).to_have_count(3,timeout=60000);assert not page.evaluate('(id)=>archivedRoom(roomFor(id))',ids[3])
  # Restoring one room from an archived product leaves its siblings archived.
  page.evaluate('async()=>{products[0].archived=true;await io("products","readwrite",products[0].id,products[0]);render()}');page.locator('[data-archive-restore="'+ids[0]+'"]').click();page.wait_for_function('(id)=>!roomFor(id).archived',arg=ids[0]);assert page.evaluate('!products[0].archived&&archiveRooms().every(r=>r.id!=='+repr(ids[0])+')');assert page.evaluate('rooms.filter(r=>r.productId===products[0].id&&r.id!=='+repr(ids[0])+').every(archivedRoom)')
  # Permanent deletion is confirmed and scoped to a room, never a product bank.
  target=ids[1];page.locator('[data-archive-delete="'+target+'"]').click();page.locator('#archiveCancelDelete').click();assert page.evaluate('(id)=>!!roomFor(id)',target)
  page.locator('[data-archive-delete="'+target+'"]').click();page.locator('#archiveConfirmDelete').click();page.wait_for_function('(id)=>!roomFor(id)',arg=target);assert page.evaluate('async key=>!!(await io("files","readonly",key))',shared);assert page.evaluate('async id=>!(await readEditorDraft(id))',target)
  # Live board nodes survive Archive/back, and menu still leads to photo/reference rooms.
  page.locator('#archiveBack').click();expect(page.locator('#board')).to_be_visible();assert page.evaluate('document.querySelectorAll("#board .stageColumn").length===4');page.locator('#newVideo').click();expect(page.locator('#createPhotos')).to_be_visible();page.locator('#closeDialog').click()
  for width,height in [(1366,768),(390,844)]:
   page.set_viewport_size({'width':width,'height':height});page.locator('#archiveProduct').click();expect(page.locator('#archiveView')).to_be_visible();assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.screenshot(path=f'/tmp/archive-integrated-{width}.png');page.locator('#archiveBack').click()
  assert not errors,errors;assert not [u for u in requests if '/local-api/' in u],requests
  b.close()
 print('PASS stable card/image/product identity and focus; zero unchanged-board mutations; background update + scroll; inline rename; fixed shared header/sidebar; empty/list/search; real local byte measurement; safe temporary cleanup; old export restore/reload; archived-product sibling preservation; scoped confirmed delete; photo entry; responsive layout; zero demo provider calls.')
finally:server.shutdown()
