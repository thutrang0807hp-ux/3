"""Check the aggregate ZIP and every nested design file without replacing prior specs."""
from pathlib import Path
import zipfile,hashlib,json
root=Path(__file__).resolve().parents[2];source=next(Path('/workspace/attachments').rglob('SceneForge_TatCa.zip'));base=root/'design/all-spec-received';top=zipfile.ZipFile(source);entries=[]
for info in top.infolist():
 if info.is_dir():continue
 p=base/info.filename;assert p.is_file()and p.read_bytes()==top.read(info),p
 if p.suffix=='.zip':
  for child in zipfile.ZipFile(p).infolist():
   if child.is_dir():continue
   z=zipfile.ZipFile(p);target=p.parent/'extracted'/p.stem/child.filename;assert target.read_bytes()==z.read(child),target
   entries.append({'archive':p.name,'path':str(target.relative_to(root)),'bytes':child.file_size,'sha256':hashlib.sha256(z.read(child)).hexdigest()})
old={}
for p in (root/'design').rglob('*'):
 if p.is_file()and 'all-spec-received'not in p.parts:old.setdefault(hashlib.sha256(p.read_bytes()).hexdigest(),[]).append(str(p.relative_to(root)))
for e in entries:e['identical_previous']=old.get(e['sha256'],[])
report={'top_files_preserved':len([i for i in top.infolist()if not i.is_dir()]),'checked_nested_files':len(entries),'identical_previous':sum(bool(e['identical_previous'])for e in entries),'new_or_changed':[e['path']for e in entries if not e['identical_previous']],'files':entries}
(root/'docs/aggregate-archive-integrity.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('PASS:',report['top_files_preserved'],'top-level files and',len(entries),'nested files preserved;',report['identical_previous'],'identical to previous specs. Original workbook unchanged.')
