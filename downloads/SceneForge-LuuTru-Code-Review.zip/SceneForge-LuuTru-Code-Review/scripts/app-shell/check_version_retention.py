"""Actual workflow version pruning; only disk protection lookup is a labelled fixture."""
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from functools import partial
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://localhost:{server.server_port}/?demo=1');page.wait_for_function('rooms.length===7');rid=page.evaluate('rooms.find(r=>r.mode==="reference").id');page.evaluate('(id)=>SceneForgeApp.openRoom(id,"analysis")',rid);page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().scenes?.length>0');frame=page.locator('#workflowFrame').element_handle().content_frame()
  page.evaluate('''()=>{jobs.forEach(j=>j.status='done');window.keptStorage=SceneForgeStorage;window.protectionLookups=0;window.SceneForgeStorage={managed:true,flush:async()=>{},hashBlob:async blob=>(await SceneForgePortable.fingerprint(blob)).hash,api:async()=>{protectionLookups++;return{hashes:[(await SceneForgePortable.fingerprint(new Blob(['frame-3']))).hash]};}};}''')
  frame.evaluate('''()=>{const s=project.scenes[0];s.frames=Array.from({length:7},(_,i)=>{const n=i+1,key='retention-asset-'+n;assets.set(key,new Blob(['frame-'+n],{type:'image/png'}));return{id:'retention-'+n,asset:key,version:n,pinned:n===2,quality:{state:'pass'}};});s.frameSelectionId='retention-1';window.testScene=s.id;const keep=g6VersionKeep(s,'frame');if(keep.size!==4||!keep.has('retention-1')||!keep.has('retention-2')||!keep.has('retention-6')||!keep.has('retention-7'))throw Error('Selected/pinned/latest keep failed');g6Open('frame',s.id);}''')
  page.once('dialog',lambda d:d.accept());frame.evaluate('()=>g6PruneOldVersions()');state=frame.evaluate('()=>({ids:sceneBy(testScene).frames.map(v=>v.id),removed:!assets.has("retention-asset-4")&&!assets.has("retention-asset-5"),selected:sceneBy(testScene).frameSelectionId})');assert state['ids']==['retention-1','retention-2','retention-3','retention-6','retention-7'],state;assert state['removed']and state['selected']=='retention-1';assert page.evaluate('protectionLookups')==1
  persisted=page.evaluate('(id)=>workflowRecord(id)',rid);assert [v['id']for v in persisted['scenes'][0]['frames']]==state['ids'];assert not errors,errors;browser.close()
 print('PASS selected + pinned + latest two retained, timeline-protected version retained via fixture lookup, only confirmed old versions removed, unreferenced Blob entries removed and actual IndexedDB workflow persists. No providers or real deletion.')
finally:server.shutdown()
