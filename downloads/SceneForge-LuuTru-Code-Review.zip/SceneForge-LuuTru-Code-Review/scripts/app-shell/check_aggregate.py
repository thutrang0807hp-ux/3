"""Legacy video adapter compatibility + real FFmpeg room/SRT; primary frame workflow tested in workflow/check_analysis_v3.py."""
from pathlib import Path
import os,tempfile,socket,threading,time,subprocess,json,sys
from unittest.mock import patch,AsyncMock
import httpx,uvicorn
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root));temp=tempfile.TemporaryDirectory(prefix='sceneforge-all-browser-');os.environ['SCENEFORGE_LOCAL_DATA']=temp.name
from local_engine import server
from local_engine.video_analysis import VISUAL,MOTION
server.VAULT.set_secret('gemini','test-not-a-real-provider-key')
provider_calls=[]
async def provider(url,**kwargs):
 assert url.startswith('https://generativelanguage.googleapis.com/')
 body=json.loads(kwargs['json']['contents'][0]['parts'][0]['text'].rsplit('\n',1)[1]);provider_calls.append(body)
 rows=[]
 for s in body['scenes']:rows.append({**s,'description':'Khung xanh trong video kiểm tra.','hasPerson':False,'faceTalking':False,'hasProduct':False,'competitorLogo':False,'visual':{l:{k:('Khung xanh.'if l=='vi'else 'Blue frame.')for k in VISUAL}for l in ('vi','en')},'motion':{l:{k:('Máy quay cố định.'if l=='vi'else 'Locked camera.')for k in MOTION}for l in ('vi','en')},'promptFrame':{'vi':'Giữ nguyên bố cục.','en':'Preserve composition.'}})
 out={'scenes':rows,'script':[{'start':0,'end':1.2,'original':'Lời giả lập để thử đường kết nối.','translation':'Lời kiểm tra.','newText':'Ữ ặ ỡ ợ ẫ · Chào bạn.','faceTalking':False}]}
 return httpx.Response(200,json={'candidates':[{'content':{'parts':[{'text':json.dumps(out,ensure_ascii=False)}]}}],'usageMetadata':{'totalTokenCount':123}})
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();svc=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'));thread=threading.Thread(target=svc.run,daemon=True)
try:
 with patch.object(httpx.AsyncClient,'post',AsyncMock(side_effect=provider)):
  thread.start()
  for _ in range(100):
   if svc.started:break
   time.sleep(.05)
  source=Path(temp.name)/'source.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=180x320:r=15:d=2.4','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=2.4','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest','-y',str(source)],check=True)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1700,'height':1100});page.set_default_timeout(20000);errors=[];dialogs=[];downloads=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('download',lambda d:downloads.append(d));page.on('dialog',lambda d:(dialogs.append(d.message),d.accept()));page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('SceneForgeApp.getState().products.length>0');page.wait_for_timeout(500)
   if page.locator('#shellDialog').is_visible():page.locator('#closeDialog').click()
   page.locator('[data-product]').nth(1).click();page.locator('#videoFiles').set_input_files(str(source));page.wait_for_function('SceneForgeApp.getState().rooms[0]?.sceneCount>0',timeout=40000);rid=page.evaluate('SceneForgeApp.getState().rooms[0].id');page.evaluate('(id)=>SceneForgeApp.openRoom(id,"analysis")',rid);wf=page.frame_locator('#workflowFrame');expect(wf.locator('[data-action=live-analysis]')).to_be_enabled();page.locator('#workflowFrame').element_handle().content_frame().evaluate('project.galleryLayout="list";project.analysis.frameQualityRequired=false;render()');assert not provider_calls
   wf.locator('[data-action=live-analysis]').click();expect(wf.locator('#modal')).to_be_visible();assert not provider_calls;page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.eval("liveBeforeCPU()")');expect(wf.locator('#applyLiveAnalysis')).to_be_visible(timeout=20000);assert len(provider_calls)==1
   # Close/reload/resume the received response; must not charge another AI request.
   wf.locator('#modal [data-action=close-modal]').first.click();page.reload();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().analysis.pendingAI');wf=page.frame_locator('#workflowFrame');wf.locator('[data-action=live-analysis]').click();wf.locator('[data-action=live-analysis-review]').click();wf.locator('#applyLiveAnalysis').click();assert len(provider_calls)==1;state=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState()');assert state['analysis']['semantic']['provider']=='Gemini';assert state['script'][0]['newText'].startswith('Ữ');assert not dialogs,dialogs
   wf.locator('[data-action=undo-live-analysis]').click();assert not page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState().script.length')
   # Second explicit user request, apply, then edit/export in the same room.
   wf.locator('[data-action=live-analysis]').click();page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.eval("liveBeforeCPU()")');expect(wf.locator('#applyLiveAnalysis')).to_be_visible();wf.locator('#applyLiveAnalysis').click();assert len(provider_calls)==2
   wf.locator('[data-approve]').first.click();wf.locator('[data-clip-upload]').first.click();wf.locator('#clipFile').set_input_files(str(source));expect(wf.locator('#node-merge [data-action=merge]')).to_be_enabled(timeout=30000)
   page.evaluate('async()=>{await SceneForgeApp.settings.set("sidecarSrt",true);await SceneForgeApp.settings.set("resolution",720)}');wf.locator('#node-merge [data-action=merge]').click();page.wait_for_function('document.querySelector("#standaloneEditorDemo")?.contentWindow?.SceneForgeEditor?.getState().items.length===2');ed=page.frame_locator('#standaloneEditorDemo');expect(ed.locator('#localFinishingControls')).not_to_be_visible();ed.locator('#export').click();expect(ed.locator('#localFinishingControls')).to_be_visible();expect(ed.locator('#useLocalMp4')).to_be_checked();ed.locator('#exportSize').select_option('720');ed.locator('#realExport').click();expect(ed.locator('#exportProgress')).to_have_attribute('value','100',timeout=45000);page.wait_for_timeout(300)
   assert len(downloads)==2,[d.suggested_filename for d in downloads];assert any(d.suggested_filename.endswith('.mp4')for d in downloads);assert any(d.suggested_filename.endswith('.srt')for d in downloads)
   data=page.evaluate('''async id=>{const mp4=await io('files','readonly',id+':export'),srt=await io('files','readonly',id+':export:srt');return{type:mp4?.type,bytes:mp4?.size,srt:srt?await srt.text():null,name:roomFor(id).exportSrtName}}''',rid);assert data['type']=='video/mp4'and data['bytes']>1000;assert 'Ữ ặ ỡ ợ ẫ'in data['srt'];assert data['name'].endswith('.srt');assert len(provider_calls)==2,provider_calls;assert not errors,errors
   page.screenshot(path='/tmp/sceneforge-all-export-verified.png');b.close()
 print('PASS: explicit Gemini consent/one request, persistent review survives reload with no repeat, apply/undo, same-room captions/media handoff, real local FFmpeg MP4 + SRT downloaded and both saved to room; no page errors. Gemini mocked; FFmpeg and file I/O real.')
finally:
 svc.should_exit=True;thread.join(timeout=10);temp.cleanup()
