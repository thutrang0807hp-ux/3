"""Browser persistence, shared editing and option selection. AI transport uses explicit fixtures only."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1536,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://localhost:{s.server_port}/?demo=1');page.wait_for_function('rooms.length===7&&prefs.showcaseVersion===1')
  # Metrics are optional, editable, persisted, and user feedback dominates all supported metrics.
  page.locator('#g6OpenRecipes').click();page.locator('[data-g6-recipe]').first.click();rid=page.locator('[data-g6-recipe]').first.get_attribute('data-g6-recipe');page.locator('[data-kv=edit]').click();page.locator('#g6RecipeLikes').fill('700');page.locator('#g6RecipeCTR').fill('150');page.locator('#g6SaveRecipe').click();expect(page.locator('#g6RecipeError')).to_contain_text('CTR');page.locator('#g6RecipeCTR').fill('2.5');page.locator('#g6RecipeHook').fill('Hỏi vấn đề');page.locator('#g6SaveRecipe').click();page.wait_for_function('(id)=>recipeCache.items.find(r=>r.id===id)?.metrics?.likes===700',arg=rid)
  assert page.evaluate('SFRecipes.rank({up:1})>SFRecipes.rank({metrics:{ctr:100,likes:99999999999}})')
  photo=page.evaluate('rooms.find(r=>r.mode==="photos").id');page.evaluate('(id)=>SceneForgeApp.openRoom(id,"analysis")',photo);page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length===5');f=page.frame_locator('#workflowFrame');frame=page.locator('#workflowFrame');
  def inside(code):return frame.element_handle().content_frame().evaluate(code)
  expect(f.locator('[data-action=three-scripts]')).to_be_disabled()
  # Real source transcript remains only in its original workflow record.
  page.evaluate('''async id=>{const r=await listRecipes(),target=r[0];target.sourceRoomId='test-source';await putRecipe(target);const db=await workflowRecord('test-source');await writeForeign('projects','sceneforge-workflows','test-source',{id:'test-source',script:[{original:'Đây là lời nguồn dùng riêng để kiểm tra cảnh báo giống nhau.'}]});}''',photo)
  inside('''async()=>{await refreshRecipes();draft.formula=libraryRecipes[0].id;draft.recipeSnapshot=SFRecipes.strip(libraryRecipes[0]);await loadRecipeSource();draft.scriptView='storyboard';render();}''')
  expect(f.locator('.storyCard')).to_have_count(5);field=f.locator('.storyCard').first.locator('[data-story-field=text]');field.fill('Đây là lời nguồn dùng riêng để kiểm tra cảnh báo giống nhau.');expect(f.locator('.storyWarning')).to_be_visible();field.fill('Lời mới hoàn toàn cho sản phẩm của tôi');f.locator('.storyCard').first.locator('[data-story-field=angle]').fill('Góc ngang');expect(f.locator('.beatList')).to_contain_text('Lời mới hoàn toàn');f.locator('[data-node=script] [data-beat]').first.click();expect(f.locator('[data-edit-story=angle]')).to_have_value('Góc ngang');f.locator('#beatText').fill('Lời chỉnh trong bảng kịch bản');f.locator('#saveBeat').click();expect(f.locator('.storyCard').first.locator('[data-story-field=text]')).to_have_value('Lời chỉnh trong bảng kịch bản')
  expect(f.locator('[data-node=storyboard]')).to_be_visible();expect(f.locator('[data-story-view]')).to_have_count(0);assert f.locator('.photoNode').count()==11
  inside("()=>{view.z=.85;actions['focus-storyboard']();}");page.screenshot(path='/tmp/sceneforge-storyboard.png')
  # Wheel scrolls the storyboard cards without panning the canvas.
  camera=inside('()=>({...view})');grid=f.locator('[data-node=storyboard] .storyGrid');box=grid.bounding_box();page.mouse.move(box['x']+box['width']-10,box['y']+100);page.mouse.wheel(0,250);page.wait_for_timeout(250);assert grid.evaluate('(n)=>n.scrollTop')>0;assert inside('()=>({...view})')==camera
  # Move the independent node through real pointer events, then persist/reload its position.
  saved=inside('()=>structuredClone(draft.positions)');header=f.locator('[data-node=storyboard]>header').bounding_box();page.mouse.move(header['x']+50,header['y']+15);page.mouse.down();page.mouse.move(header['x']+130,header['y']+65,steps=8);page.mouse.up();inside('()=>SceneForgeWorkflow.flushRoom()');moved=inside('()=>structuredClone(draft.positions.storyboard)');assert moved and moved[0]>1280;assert {k:v for k,v in inside('()=>structuredClone(draft.positions)').items()if k!='storyboard'}=={k:v for k,v in saved.items()if k!='storyboard'}
  assert inside('()=>Object.keys(draft.positions).filter(k=>k!=="storyboard").length')==len([k for k in saved if k!='storyboard'])
  inside('()=>fit()')
  # One fixture call returns three options; no bank enqueue occurs before or after selection.
  inside('''()=>{testCalls=[];capabilities.gemini_configured=true;draft.idea='Chai sữa rửa mặt, thông tin do người dùng nhập';bridge.engine=async(path,body)=>{testCalls.push(path);if(path!=='ai/script')throw Error('unexpected request');return{variants:['Hỏi vấn đề','Quan sát thật','Review thật'].map((hook,i)=>({hook,beats:body.beats.map((b,j)=>({text:'Lời phương án '+i+' nhịp '+j,type:b.type,angle:'Góc '+i,movement:'Chậm',onScreen:''}))}))};};render();}''')
  f.locator('[data-action=three-scripts]').click();expect(f.locator('[data-choose-script]')).to_have_count(3);assert inside('()=>draft.variantPending');assert inside('()=>testCalls')==['ai/script']
  inside('''async()=>{let blocked=false;try{await queueBank('detail');}catch{blocked=true;}if(!blocked)throw Error('Generation was not blocked');}''');f.locator('[data-choose-script="1"]').click();expect(f.locator('[data-choose-script="1"]')).to_be_disabled();state=inside('()=>SceneForgeWorkflow.getState()');assert state['beats'][0]['text']=='Lời phương án 1 nhịp 0';assert state['beats'][0]['seconds']<=3;assert not state['variantPending'];assert inside('()=>testCalls')==['ai/script'];assert 'lời nguồn dùng riêng'not in str(state).lower()
  page.reload();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().chosenVariant===1');f=page.frame_locator('#workflowFrame');expect(f.locator('.storyCard').first.locator('[data-story-field=text]')).to_have_value('Lời phương án 1 nhịp 0');assert inside('()=>draft.positions.storyboard')==moved;assert not errors,errors;b.close()
 print('PASS optional metric validation/persistence and feedback priority; independent visible draggable Storyboard, shared live edits, position persists without moving old nodes; source similarity warning without transcript persistence; one request/three options; generation blocked pending selection; chosen script + board persist after reload. AI fixtures only.')
finally:s.shutdown()
