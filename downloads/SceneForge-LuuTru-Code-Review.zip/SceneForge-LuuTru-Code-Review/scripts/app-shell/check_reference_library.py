from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import struct,zlib
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1536,'height':1000});errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append(r.url));page.goto(f'http://localhost:{s.server_port}/?demo=1');page.wait_for_function('rooms.length===7&&prefs.showcaseVersion===1',timeout=60000)
  snapshot=page.evaluate('JSON.stringify(rooms.map(r=>({id:r.id,refs:r.refs})).sort((a,b)=>a.id.localeCompare(b.id)))');page.locator('[data-product-tab=references]').click();expect(page.locator('[data-reference-add]')).to_have_count(4);page.screenshot(path='/tmp/references-direct-before.png')
  def chunk(name,data):return struct.pack('>I',len(data))+name+data+struct.pack('>I',zlib.crc32(name+data)&0xffffffff)
  png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',1,1,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b'\x00\xff\x00\x00\xff'))+chunk(b'IEND',b'')
  with page.expect_file_chooser() as fc:page.locator('[data-reference-add=person]').click()
  fc.value.set_files([{'name':name,'mimeType':'image/png','buffer':png} for name in ['Ảnh người 1.png','Ảnh người 2.png']]);expect(page.locator('#referenceGroup-person .referencePreview')).to_have_count(2);expect(page.locator('[data-product-tab=references]')).to_contain_text('3')
  assert page.evaluate('JSON.stringify(rooms.map(r=>({id:r.id,refs:r.refs})).sort((a,b)=>a.id.localeCompare(b.id)))')==snapshot
  page.locator('#referenceGroup-person .referencePreview').first.click();expect(page.locator('#dialogTitle')).to_have_text('Ảnh người 1.png');expect(page.locator('.referenceFullPreview')).to_be_visible();page.locator('#closeDialog').click()
  for group in ['outfit','product','background']:
   page.locator('[data-reference-file='+group+']').set_input_files([{'name':group+'.png','mimeType':'image/png','buffer':png}])
   expect(page.locator('#referenceGroup-'+group+' .referencePreview')).to_have_count(2 if group=='product' else 1)
  page.locator('[data-reference-file=person]').set_input_files([{'name':'khong-phai-anh.txt','mimeType':'text/plain','buffer':b'text'},{'name':'hong.png','mimeType':'image/png','buffer':b'bad image'}]);expect(page.locator('#shellToast')).to_contain_text('không đọc được ảnh');expect(page.locator('#referenceGroup-person .referencePreview')).to_have_count(2)
  page.screenshot(path='/tmp/references-direct-preview.png')
  page.reload();page.wait_for_function('rooms.length===7',timeout=60000);page.locator('[data-product-tab=references]').click();expect(page.locator('#referenceGroup-person .referencePreview')).to_have_count(2);expect(page.locator('#referenceGroup-product .referencePreview')).to_have_count(2);expect(page.locator('[data-product-tab=references]')).to_contain_text('6');assert page.evaluate('JSON.stringify(rooms.map(r=>({id:r.id,refs:r.refs})).sort((a,b)=>a.id.localeCompare(b.id)))')==snapshot
  page.locator('#editReferences').click();expect(page.locator('[data-ref-thumbs=person] img')).to_have_count(2);page.locator('#cancelProduct').click()
  page.set_viewport_size({'width':390,'height':844});expect(page.locator('[data-reference-add]')).to_have_count(4);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');assert not errors,errors;assert not [u for u in calls if '/local-api/' in u];b.close()
 print('PASS direct multi-image picker in all four groups, existing images retained, names/preview, invalid images rejected, durable product refs and tab counts after reload, old room snapshots unchanged, existing editor retained, mobile fit; no API calls.')
finally:s.shutdown()
