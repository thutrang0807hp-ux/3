"""Browser-only ZIP + incremental hashes are verified by Python and imported into SQLite."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
import tempfile,hashlib,zipfile,json,sys
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from local_engine.library import Library
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory(dir='/tmp')as temp,sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(accept_downloads=True);errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append(r.url));page.goto(f'http://localhost:{server.server_port}/?demo=1');page.wait_for_function('rooms.length===7')
  for n in [0,1,63,64,65,1048589]:
   actual=page.evaluate('(n)=>SceneForgePortable.fingerprint(new Blob([Uint8Array.from({length:n},(_,i)=>i%251)]))',n);assert actual['hash']==hashlib.sha256(bytes(i%251 for i in range(n))).hexdigest(),(n,actual)
  page.evaluate('''async()=>{const p={id:'portable-product',name:'Mang sang máy',refs:Object.fromEntries(['person','outfit','product','background'].map(k=>[k,{images:[],description:''}]))};products.push(p);await io('products','readwrite',p.id,p);const r={id:'portable-room',productId:p.id,name:'Phòng cần mang',mode:'photos',stage:'editing',refs:clone(p.refs),photoDraft:{voice:{key:'voice:portable-room:1'}}};rooms.push(r);await io('rooms','readwrite',r.id,r);const blob=new File(['real-file-data'],'video.mp4',{type:'video/mp4',lastModified:1234});await io('files','readwrite',r.id+':source',blob);await io('files','readwrite','voice:'+r.id+':1',new Blob(['voice-data'],{type:'audio/wav'}));await writeForeign('projects','sceneforge-workflows',r.id,{id:r.id,assetEntries:[['source',blob]],scenes:[{frames:[{id:'pinned-frame',asset:'source',pinned:true}],clips:[]}],script:[{newText:'Giữ lời này'}]});await writeForeign('drafts','sceneforge-editor-local',r.id,{payload:{items:[{id:'keep',start:2,duration:4}]},media:[{file:blob}]});}''')
  with page.expect_download()as d:page.evaluate('SceneForgePortable.save("portable-room")')
  archive=Path(temp)/'portable.zip';d.value.save_as(archive)
  with zipfile.ZipFile(archive)as z:
   assert z.testzip()is None;manifest=json.loads(z.read('du-an.json'));assert len(manifest['assets'])==2
   for name in z.namelist():
    if name.startswith('assets/'):assert hashlib.sha256(z.read(name)).hexdigest()==name.split('/')[1]
   assert any(r['key']=='voice:portable-room:1'for r in manifest['records'])
  library=Library(Path(temp)/'disk');snap=library.import_bundle(archive,0);assert len(snap['records'])==len(manifest['records']);assert library.status()['assets']==2 and library.status()['pins']==1
  assert any(r['db']=='sceneforge-editor-local'and r['value']['payload']['items'][0]['start']==2 for r in snap['records'])
  assert not errors,errors;assert not [url for url in calls if '/local-api/'in url],calls;browser.close()
 print('PASS SHA-256 boundary/large-block vectors, CRC/ZIP validity, room File + voice + workflow + timeline portable export, byte dedup, exact hashes and real SQLite import; browser-only Pages mode makes no local/provider requests.')
finally:server.shutdown()
