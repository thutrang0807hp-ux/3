"""Compatibility entry point for the current compact-toolbar browser integration check."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from local_engine.check_photo_toolbar import main
if __name__=='__main__':main()
