"""Actual local API/Chromium: actionable cards, recovered MP4, no accidental render."""
import hashlib,json,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from local_engine.local_jobs import LocalJobs,JobRegistry
with tempfile.TemporaryDirectory(prefix='sf-recovery-ui-',dir='/tmp')as tmp:
 data=Path(tmp);(data/'exports').mkdir();job_id='1234aabb';mp4=data/'exports'/(job_id+'.mp4')
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=240x426:r=30:d=1','-c:v','libx264','-pix_fmt','yuv420p','-y',str(mp4)],check=True)
 actual=mp4.read_bytes();store=LocalJobs(data);jobs=JobRegistry(store,'finishing');jobs.create({'id':job_id,'state':'done','progress':100,'bytes':len(actual),'created':time.time(),'room_id':'recover-export','duration':1,'fps':30,'normalize':False})
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp};proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);base=f'http://127.0.0.1:{port}'
 try:
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);context=browser.new_context(viewport={'width':1440,'height':960},accept_downloads=True);page=context.new_page();errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append((r.method,r.url)))
   page.goto(base);page.wait_for_function('db&&products.length>0&&SceneForgeApp.recovery');page.evaluate('''async()=>{const p=products[0],now=Date.now();for(const [id,stage,extra]of [['frames','review',{sceneCount:3,pendingFrames:2,readyScenes:0}],['missing','generating',{sceneCount:3,pendingFrames:0,readyScenes:1}],['recover-export','editing',{}],['uncertain','generating',{}]]){const r={id,name:id,productId:p.id,stage,createdAt:now,updatedAt:now,sceneStates:[],refs:clone(p.refs),...extra};rooms.push(r);await persistRoom(r);}const j={id:'submitted-fixture',roomId:'uncertain',status:'submitted',kind:'clip',sceneIndex:0};jobs.push(j);await io('jobs','readwrite',j.id,j);await SceneForgeStorage.flush();render();await SceneForgeApp.recovery.refresh();}''')
   expect(page.locator('[data-attention-room="frames"]')).to_contain_text('Rà 2 khung chưa duyệt');expect(page.locator('[data-attention-room="missing"]')).to_contain_text('Còn 2 cảnh chưa đủ clip');expect(page.locator('[data-attention-room="recover-export"]')).to_contain_text('MP4 đã xong')
   page.reload();page.wait_for_function('jobs.some(j=>j.id==="submitted-fixture"&&j.status==="unknown")');assert page.evaluate('jobs.find(j=>j.id==="submitted-fixture").error')
   page.locator('[data-attention-room="uncertain"]').click();expect(page.locator('#queueDrawer')).to_be_visible();expect(page.locator('#queueList [data-job="submitted-fixture"]')).to_contain_text('Ứng dụng đã đóng')
   page.locator('[data-close-drawer]').click();page.locator('[data-attention-room="recover-export"]').click();expect(page.locator('#localJobHistory [data-local-download]')).to_be_visible()
   page.screenshot(path='/tmp/sceneforge-recovery-queue.png')
   with page.expect_download()as result:page.locator('[data-local-download="'+job_id+'"]').click()
   saved=data/'downloaded.mp4';result.value.save_as(saved);assert saved.read_bytes()==actual
   page.wait_for_function('roomFor("recover-export").stage==="exported"');assert page.evaluate('''async()=>{const b=await io('files','readonly','recover-export:export');return b.size}''')==len(actual)
   page.evaluate('SceneForgeStorage.flush()');assert page.evaluate('SceneForgeStorage.api("status")')['assets']>=1
   # Re-downloading an old completed result must not overwrite a newer room export.
   page.evaluate('''async()=>{await io('files','readwrite','recover-export:export',new Blob(['newer-export-must-stay'],{type:'video/mp4'}));roomFor('recover-export').exportedAt=Date.now()+1000;await persistRoom(roomFor('recover-export'));}''')
   with page.expect_download():page.locator('[data-local-download="'+job_id+'"]').click()
   assert page.evaluate('''async()=>await(await io('files','readonly','recover-export:export')).text()''')=='newer-export-must-stay'
   assert not [u for method,u in calls if method in ('POST','PUT')and('/local-api/ai/'in u or '/local-api/export/'in u)],calls
   page.locator('[data-close-drawer]').click();page.evaluate('g5OpenSettings("storage")');expect(page.locator('#dialogBody')).to_contain_text(str(data));expect(page.locator('#dialogBody')).to_contain_text('Chuyển thư viện không chuyển các phần này');page.screenshot(path='/tmp/sceneforge-recovery-storage.png')
   assert not errors,errors;browser.close()
  print('PASS local actionable frame/clip cards; submitted job reload becomes unknown; queue recovery/download byte-for-byte and library sync; newer export retained; storage roots shown; no AI/render submissions from recovery. Chromium + actual companion.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
