"""Opt-in sample projects have playable timelines and cannot overwrite the working board."""
from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')))
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1700,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));requests=[];page.on('request',lambda r:requests.append(r.url))
  base='http://localhost:'+str(server.server_port)
  page.goto(base);page.wait_for_function('SceneForgeApp.getState().products.length===1');main=page.evaluate('SceneForgeApp.getState().products[0].id')
  page.goto(base+'/?demo=1');page.wait_for_function('document.querySelectorAll(".stageColumn").length===4&&SceneForgeApp.getState().rooms.length===7',timeout=60000);expect(page.locator('.showcaseBanner')).to_contain_text('không gọi AI');state=page.evaluate('SceneForgeApp.getState()');assert len(state['products'])==5;assert len([r for r in state['rooms']if r.get('editorInitialized')])==2
  assert page.locator('.runningBadge').count()==2;assert page.locator('.roomCard').count()==7;assert page.locator('.stageColumn').nth(1).locator('.stageHeading b').inner_text()=='2';page.screenshot(path='/tmp/sceneforge-showcase-home.png')
  exported=next(r['id']for r in state['rooms']if r['stage']=='exported');page.evaluate('(id)=>SceneForgeApp.openRoom(id,"editor")',exported);page.wait_for_function('document.querySelector("#standaloneEditorDemo")?.contentWindow?.SceneForgeEditor?.getState().items.length===5',timeout=30000);editor=page.locator('#standaloneEditorDemo').evaluate('(f)=>f.contentWindow.SceneForgeEditor.getState()');assert all(i['volume']==0 for i in editor['items']);assert all(not a.get('missing')for a in editor['assets']);page.screenshot(path='/tmp/sceneforge-showcase-editor.png')
  page.locator('#homeFromRoom').click();reference=next(r['id']for r in state['rooms']if r['mode']=='reference');page.evaluate('(id)=>SceneForgeApp.openRoom(id,"analysis")',reference);page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().scenes.length===3');page.locator('#homeFromRoom').click()
  photo=next(r['id']for r in state['rooms']if r['mode']=='photos');page.evaluate('(id)=>SceneForgeApp.openRoom(id,"analysis")',photo);page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length===5');ph=page.frame_locator('#workflowFrame');ph.locator('[data-action=open-recipes]').first.click();recipe_count=page.evaluate('(async()=>{return(await SceneForgeApp.photoBridge.listRecipes()).length})()');assert recipe_count>=3;expect(ph.locator('.recipeRow')).to_have_count(recipe_count);page.screenshot(path='/tmp/sceneforge-showcase-recipes.png')
  page.goto(base);page.wait_for_function('SceneForgeApp.getState().products.length===1');assert page.evaluate('SceneForgeApp.getState().products[0].id')==main;assert not page.evaluate('SceneForgeApp.getState().rooms.length')
  page.goto(base+'/?demo=1#overview');page.wait_for_function('document.querySelectorAll(".stageColumn").length===4');assert page.evaluate('SceneForgeApp.getState().products.length')==5;assert page.evaluate('SceneForgeApp.getState().rooms.length')==7
  assert not any('/local-api/'in url or 'googleapis.com'in url or 'muse.ai'in url for url in requests),[u for u in requests if '/local-api/'in u or 'googleapis.com'in u or 'muse.ai'in u];assert not errors,errors;browser.close()
 print('PASS: opt-in sample board, five products/seven rooms/eight shot types, two real playable muted timelines, reference nodes and recipe overlay; reload persists; live working database not changed; no API/account/provider requests.')
finally:server.shutdown()
