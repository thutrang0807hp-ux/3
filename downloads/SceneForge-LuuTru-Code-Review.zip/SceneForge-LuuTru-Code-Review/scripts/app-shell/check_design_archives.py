"""Verify every uploaded spec/PNG remains byte-identical; no design is silently discarded."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2];attachments=Path('/workspace/attachments');entries=[]
for archive in sorted(attachments.rglob('*.zip')):
 if archive.name not in {'SceneForge_Goi4.zip','SceneForge_DacTa_TabTaoVideo.zip','SceneForge_DacTa_TabDung.zip','SceneForge_KhungSuonApp.zip','SceneForge_Goi5 (1).zip'}:continue
 z=zipfile.ZipFile(archive)
 for info in z.infolist():
  if info.is_dir():continue
  path=Path(info.filename)
  if archive.name=='SceneForge_Goi5 (1).zip':target=root/'design/package-5-spec'/path
  elif archive.name=='SceneForge_DacTa_TabTaoVideo.zip':target=root/'design/workflow-spec'/path
  elif archive.name=='SceneForge_DacTa_TabDung.zip':target=root/'design/editor-spec'/Path(*path.parts[1:])
  elif archive.name=='SceneForge_KhungSuonApp.zip':target=root/'design/app-shell-spec'/Path(*path.parts[1:])
  elif any(name.endswith('/08-kho-kich-ban.png')for name in z.namelist()):target=root/'design/package-4-received'/path
  else:target=root/'design/package-4-spec'/Path(*path.parts[1:])
  expected=hashlib.sha256(z.read(info)).hexdigest();assert target.is_file(),str(target)
  assert hashlib.sha256(target.read_bytes()).hexdigest()==expected,str(target)
  entries.append({'archive':archive.name,'path':str(target.relative_to(root)),'bytes':info.file_size,'sha256':expected})
out=root/'docs/design-archive-integrity.json';out.write_text(json.dumps({'checked_files':len(entries),'files':entries},ensure_ascii=False,indent=2)+'\n')
print('PASS:',len(entries),'original spec/image files across uploaded archives are present and byte-identical. Manifest:',out)
