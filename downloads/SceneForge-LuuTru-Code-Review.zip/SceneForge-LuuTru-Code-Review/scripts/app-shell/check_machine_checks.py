from pathlib import Path
from functools import partial
import http.server,threading,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright()as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1500,'height':1050});errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url));page.goto('http://localhost:'+str(server.server_port)+'/?demo=1');page.wait_for_function('SceneForgeApp.getState().rooms.length===7')
 page.evaluate('SceneForgeApp.settings.open("engines")');page.locator('#openMachineChecks').click();expect(page.locator('[data-check-case]')).to_have_count(30);expect(page.locator('#runMachineCheck')).to_be_disabled()
 page.locator('#runFontCheck').click();expect(page.locator('#fontCheckResult')).to_contain_text('Đạt kiểm tra này',timeout=15000)
 page.locator('[data-check-group=D]').click();expect(page.locator('[data-check-case]')).to_have_count(11)
 page.locator('[data-check-case=D4]').click();page.locator('#manualCheckStatus').select_option('pass');page.locator('#saveManualCheck').click();expect(page.locator('#manualCheckError')).to_contain_text('ít nhất 10')
 page.locator('#manualCheckStatus').select_option('fail');page.locator('#manualCheckNote').fill('Chưa thấy thông báo trên máy thử. token=secret-value');page.locator('#saveManualCheck').click();expect(page.locator('[data-check-case=D4]')).to_contain_text('Không đạt · bạn ghi nhận')
 report=page.evaluate('SceneForgeApp.checks.getReport()');assert report['font']['state']=='passed';result=next(c for c in report['cases']if c['id']=='D4')['result'];assert result['verified_by_app']is False and 'secret-value'not in result['note']
 with page.expect_download()as download:page.locator('#exportChecksJson').click()
 parsed=json.loads(Path(download.value.path()).read_text());assert len(parsed['cases'])==30
 with page.expect_download()as download:page.locator('#exportChecksCsv').click()
 assert 'Tự ghi nhận' in Path(download.value.path()).read_text(encoding='utf-8-sig')
 page.screenshot(path='/tmp/sceneforge-machine-checks.png',full_page=True)
 page.reload();page.wait_for_function('SceneForgeApp.getState().rooms.length===7');page.evaluate('SceneForgeApp.checks.open()');expect(page.locator('[data-check-case=D4]')).to_contain_text('Không đạt · bạn ghi nhận');assert not [r for r in requests if '/local-api/'in r],requests;assert not errors,errors
 browser.close()
server.shutdown()
print('PASS 30 cases, settings entry, actual font bytes/hash/browser loading, evidence requirement, secret redaction, JSON/CSV exports, persistence; demo makes no local API calls. Desktop notification reception not certified.')
