"""Real browser UI/persistence; AI responses are explicit local fixtures, never paid calls."""
from pathlib import Path
from functools import partial
import http.server,threading
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')))
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('http://localhost:'+str(server.server_port));page.wait_for_function('SceneForgeApp.getState().products.length===1')
  page.locator('[data-product]').nth(1).click();page.locator('#newVideo').click()
  expect(page.locator('#shellDialog')).to_have_class(__import__('re').compile('videoMenu'))
  menu=page.locator('#shellDialog').bounding_box();anchor=page.locator('#newVideo').bounding_box();assert menu['y']>=anchor['y']+anchor['height']
  page.locator('#createPhotos').click();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length===5')
  room=page.evaluate('SceneForgeApp.getState().currentRoom');ph=page.frame_locator('#workflowFrame')
  ph.locator('[data-node=formula] [data-action=open-recipes]').first.click();expect(ph.locator('#photoDialog')).to_have_class(__import__('re').compile('recipeDialog'));assert ph.locator('.recipeRow').count()==3
  expect(ph.locator('#recommendRecipes')).to_be_disabled();expect(ph.locator('.recipeOrigin')).to_have_count(0)
  ph.locator('#addRecipe').click();ph.locator('#recipeFromManual').click();ph.locator('#manualRecipeName').fill('Công thức kiểm thử riêng');ph.locator('#manualRecipeIndustry').select_option('Mỹ phẩm')
  ph.locator('[data-manual-beat="0"] [data-prop=seconds]').fill('0');ph.locator('#saveManualRecipe').click();expect(ph.locator('#manualRecipeError')).to_contain_text('Mốc giây')
  ph.locator('[data-manual-beat="0"] [data-prop=seconds]').fill('3');ph.locator('[data-manual-beat="0"] [data-prop=purpose]').fill('Giới thiệu nhu cầu');ph.locator('[data-manual-beat="0"] [data-prop=example]').fill('Bạn đang tìm [sản phẩm] phù hợp?');ph.locator('#saveManualRecipe').click()
  expect(ph.locator('.recipeRow')).to_have_count(4);expect(ph.locator('#photoDialog')).to_have_class(__import__('re').compile('recipeDialog'));assert ph.locator('#photoDialog').bounding_box()['width']>1200;expect(ph.locator('#recipeDetail')).to_contain_text('Công thức kiểm thử riêng')
  ph.locator('#recipeIndustry').select_option('Mỹ phẩm');expect(ph.locator('.recipeRow')).to_have_count(1);ph.locator('#recipeSourceFilter').select_option('manual');expect(ph.locator('.recipeRow')).to_have_count(1);ph.locator('#recipeSearch').fill('không tồn tại');expect(ph.locator('.recipeRow')).to_have_count(0);ph.locator('#recipeSearch').fill('kiểm thử');expect(ph.locator('.recipeRow')).to_have_count(1)
  page.screenshot(path='/tmp/sceneforge-recipes-tested.png');ph.locator('#useRecipe').click();expect(ph.locator('#photoDialog')).not_to_be_visible();page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().beats.length===2');state=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState()');recipe=state['formula'];assert sum(b['seconds']for b in state['beats'])==7;assert all(not b['text']for b in state['beats'])
  page.reload();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().formula=== '+__import__('json').dumps(recipe));ph=page.frame_locator('#workflowFrame');expect(ph.locator('#scriptRecipe')).to_have_value(recipe)
  # Vote toggles are idempotent, do not navigate, and persist independently of room cleanup.
  page.locator('#homeFromRoom').click();page.evaluate('async(id)=>{const r=roomFor(id);r.stage="exported";await persistRoom(r)}',room)
  page.locator('[data-recipe-vote="'+room+':1"]').click();assert page.evaluate('SceneForgeApp.getState().currentView')=='overview'
  stats=page.evaluate('listRecipes()');assert next(r for r in stats if r['id']==recipe)['up']==1
  page.locator('[data-recipe-vote="'+room+':1"]').click();assert next(r for r in page.evaluate('listRecipes()')if r['id']==recipe)['up']==0
  page.locator('[data-recipe-vote="'+room+':-1"]').click();assert next(r for r in page.evaluate('listRecipes()')if r['id']==recipe)['down']==1
  # A second product uses the same library. Deleting a used recipe never destroys its room snapshot.
  page.locator('#newProduct').click();page.locator('#productName').fill('Sản phẩm khác');page.locator('#saveProduct').click();page.locator('#newVideo').click();page.locator('#createPhotos').click();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length===5');ph=page.frame_locator('#workflowFrame');ph.locator('[data-action=open-recipes]').first.click();expect(ph.locator('.recipeRow')).to_have_count(4)
  ph.locator('#recipeSearch').fill('kiểm thử');ph.locator('.recipeRow').click();page.once('dialog',lambda d:d.accept());ph.locator('#deleteRecipe').click();expect(ph.locator('.recipeRow')).to_have_count(0);assert page.evaluate('(id)=>roomFor(id).photoDraft.recipeSnapshot.name',room)=='Công thức kiểm thử riêng'
  ph.locator('#closePhotoDialog').click();page.locator('#homeFromRoom').click()
  # Extract once from real persisted source text. Mock only Gemini transport, count submissions.
  page.evaluate('''async()=>{
   const p=products[0],r={id:uid(),name:'Nguồn có lời',mode:'reference',stage:'review',productId:p.id,createdAt:Date.now(),refs:clone(p.refs)};rooms.push(r);await persistRoom(r);
   await workflowRecord(r.id);await writeForeign('projects','sceneforge-workflows',r.id,{id:r.id,analysis:{status:'done'},scenes:[{id:'s1',start:0,end:4}],script:[{start:0,end:4,original:'Lời gốc riêng không được sao chép sang công thức.'}]});
   window.recipeCalls=0;engineRequest=async(path)=>{if(path==='status')return{gemini_configured:true};if(path==='ai/recipe'){window.recipeCalls++;return{name:'Công thức đã viết lại',industry:'Chung',videoType:'Review',tips:'Kiểm tra lời mới',beats:[{name:'Hỏi',role:'question',type:'problem',start:0,end:4,purpose:'Đặt nhu cầu',example:'Bạn muốn tìm hiểu [sản phẩm] nào?'}]};}throw Error('unexpected request');};
   await Promise.all([extractReferenceRecipe(r.id),extractReferenceRecipe(r.id)]);await extractReferenceRecipe(r.id);window.recipeSourceId=r.id;
  }''');assert page.evaluate('recipeCalls')==1
  recipe_records=page.evaluate('recipeLibrary()');assert any(r.get('source')=='reference'for r in recipe_records['items']);assert 'Lời gốc riêng'not in __import__('json').dumps(recipe_records,ensure_ascii=False)
  # Exercise layout with populated columns at desktop/tablet/mobile widths.
  page.evaluate('''async()=>{prefs.product=products[0].id;await savePrefs();for(const [i,stage]of ['review','generating','new','exported'].entries()){const r={id:uid(),name:['Son đỏ gạch · mẫu 2','Son lì không khô môi','Màu này ai đánh cũng xinh','Màu nude đi làm'][i],mode:i%2?'photos':'reference',productId:products[0].id,createdAt:Date.now(),updatedAt:Date.now(),stage,sceneStates:['done','done','review'],pendingFrames:2};rooms.push(r);if(i===1)jobs.push({id:uid(),roomId:r.id,status:'running',kind:'clip',lane:'muse'});}render();}''')
  for width in [1920,1440,1280,1024,768,390]:
   page.set_viewport_size({'width':width,'height':1000});page.wait_for_timeout(80)
   bounds=page.evaluate('''()=>{const rect=s=>{const r=document.querySelector(s).getBoundingClientRect();return{x:r.x,y:r.y,right:r.right,bottom:r.bottom}};return{header:rect('.deskHeader'),tabs:rect('#productTabs'),board:rect('#board'),body:document.documentElement.scrollWidth,w:innerWidth,columns:[...document.querySelectorAll('.stageColumn')].map(n=>n.getBoundingClientRect().width)}}''')
   assert bounds['header']['bottom']<=bounds['tabs']['y']+1,(width,bounds);assert bounds['tabs']['bottom']<=bounds['board']['y']+1,(width,bounds);assert bounds['body']<=width,(width,bounds)
   assert all(n>=190 for n in bounds['columns'])if width<950 else max(bounds['columns'])-min(bounds['columns'])<2
   page.screenshot(path='/tmp/sceneforge-layout-'+str(width)+'.png')
  assert not errors,errors;browser.close()
 print('PASS: anchored menu; shared recipe CRUD/filter/apply/reload/deleted snapshot; no copied example narration; idempotent +/- votes; one extraction only; 1920/1440/1280/1024/768/390 layouts with no overlap or document overflow. Gemini was mocked; no provider calls.')
finally:server.shutdown()
