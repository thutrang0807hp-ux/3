"""Gallery upgrade: JSON, reference pairing, variants, pacing and real ZIP bytes."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
import tempfile, zipfile, json
from PIL import Image
from playwright.sync_api import sync_playwright, expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a): pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')))
Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory(dir='/tmp') as tmp,sync_playwright() as pw:
  tmp=Path(tmp)
  refs=[]
  for i,color in enumerate(['#c75171','#d5b89a']):
   path=tmp/f'ref-{i}.png';Image.new('RGB',(120,180),color).save(path);refs.append(path)
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1600,'height':1000},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}/?demo=1#batch');page.wait_for_function('!!SceneForgeApp.batch.getState()')
  page.locator('#batchReferenceFiles').set_input_files(refs);expect(page.locator('[data-batch-ref]')).to_have_count(2)
  page.locator('#batchInputMode').select_option('json');page.locator('#batchPrompts').fill('[{"prompt":"Ánh sáng ban mai","refs":[1]},{"prompt":"Góc nghiêng","refs":[99]}]');page.locator('#batchEnqueue').click();expect(page.locator('#batchFormError')).to_contain_text('hợp lệ');assert page.evaluate('batchState.jobs.length')==0
  page.locator('#batchRefMode').select_option('custom');page.locator('#batchPrompts').fill('[{"prompt":"Ánh sáng ban mai","refs":[1]},{"prompt":"Góc nghiêng","refs":[2]}]')
  page.locator('.batchAdvanced').evaluate('(d)=>d.open=true');page.locator('#batchCopies').select_option('2');page.locator('#batchGroupSize').fill('1');page.locator('#batchGroupGap').fill('1');page.locator('#batchPromptGap').fill('1');page.locator('#batchEnqueue').click();page.wait_for_function('batchState.jobs.length===4');assert page.evaluate('batchState.jobs[0].refs[0]===batchState.refs[0].id&&batchState.jobs[2].refs[0]===batchState.refs[1].id');expect(page.locator('.batchPromptGroup')).to_have_count(2)
  page.locator('#batchRun').click();page.wait_for_function('batchState.jobs.every(j=>j.status==="done")',timeout=30000)
  assert page.evaluate('batchState.jobs[1].startedAt-batchState.jobs[0].startedAt>=1000');assert page.evaluate('batchState.jobs[2].startedAt-Math.max(batchState.jobs[0].finishedAt,batchState.jobs[1].finishedAt)>=1000')
  page.locator('#batchSelectAll').click();page.locator('.batchExportMenu summary').click()
  with page.expect_download() as out:page.locator('#batchDownloadSelected').click()
  path=tmp/'gallery.zip';out.value.save_as(path)
  with zipfile.ZipFile(path) as z:
   assert z.testzip() is None;assert len(z.namelist())==5;assert len(json.loads(z.read('prompts.json')))==4
   for name in z.namelist():
    if name.endswith('.png'):assert z.read(name).startswith(b'\x89PNG\r\n\x1a\n')
  page.locator('.batchExportMenu summary').click();old=page.evaluate('batchState.jobs.slice(0,2).map(j=>({id:j.id,key:j.resultKey,versions:j.versions}))');page.locator('[data-batch-regenerate]').first.click();page.wait_for_function('batchState.jobs.length===6');assert page.evaluate('batchState.jobs.slice(0,2).map(j=>({id:j.id,key:j.resultKey,versions:j.versions}))')==old
  page.locator('#batchPause').click();page.wait_for_function('batchWorkers.size===0',timeout=20000)
  page.locator('#batchRefMode').select_option('paired');page.locator('#batchInputMode').select_option('lines');page.locator('#batchPrompts').fill('Một prompt');page.locator('#batchEnqueue').click();expect(page.locator('#batchFormError')).to_contain_text('bằng số prompt');assert page.evaluate('batchState.jobs.length')==6
  page.locator('#batchPrompts').fill('Cận cảnh son, ánh sáng mềm\nĐặt son cạnh cửa sổ');page.locator('#batchCopies').select_option('1');page.locator('#batchEnqueue').click();page.wait_for_function('batchState.jobs.length===8');assert page.evaluate('batchState.jobs[6].refs[0]!==batchState.jobs[7].refs[0]')
  # Selection survives paint. Header stays fixed while both content panes scroll independently.
  page.locator('[data-batch-ref]').first.uncheck();page.evaluate('batchPaintRefs()');assert not page.locator('[data-batch-ref]').first.is_checked()
  before=page.locator('.batchHeader').bounding_box();page.locator('#batchJobList').evaluate('(el)=>el.scrollTop=el.scrollHeight');assert page.locator('.batchHeader').bounding_box()==before
  page.locator('#batchJobList').evaluate('(el)=>el.scrollTop=0');page.locator('.batchComposeScroll').evaluate('(el)=>el.scrollTop=0');page.screenshot(path='/tmp/sceneforge-batch-gallery.png')
  for width in [1920,1440,1000,760]:
   page.set_viewport_size({'width':width,'height':1000});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
  assert not errors,errors;browser.close();print('PASS JSON atomic validation, 1–1/custom references, two variants grouped per prompt, actual scheduling gaps, valid ZIP/PNG bytes, regenerate preserves originals, reference selections, fixed header, responsive gallery.')
finally:server.shutdown()
