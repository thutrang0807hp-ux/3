"""Real browser persistence and migration; no AI/provider requests."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')))
Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1700,'height':1050});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://localhost:{server.server_port}/?demo=1');page.wait_for_function('rooms.length===7&&prefs.showcaseVersion===1')
  page.locator('#g6OpenRecipes').click();expect(page.locator('.kvShell')).to_be_visible();expect(page.locator('.kvOverview')).to_be_visible()
  assert page.evaluate('recipeCache.version')==3
  assert page.locator('.rail [data-view].active').count()==0
  # Snapshot a used recipe before editing; results count only explicitly recorded rows.
  ids=page.evaluate('''async()=>{const r=recipeCache.items[0],room=rooms.find(r=>r.mode==='photos');await useRecipe(r.id,room.id);room.photoDraft.formula=r.id;await persistRoom(room);recipeCache.usage['test-unrecorded']={roomId:'deleted-room',formula:r.id,roomName:'Video đã dọn'};await saveRecipeLibrary();return {recipe:r.id,room:room.id,key:room.id+':'+r.id,snapshot:structuredClone(room.recipeSnapshot)};}''')
  page.evaluate('()=>kvDraw()');page.locator('#g6RecipeList [data-g6-recipe="'+ids['recipe']+'"]').click();expect(page.locator('[data-kv=edit]')).to_be_visible();assert page.locator('#g6RecipeName').count()==0
  page.locator('[data-kv=edit]').click();page.locator('#g6RecipeName').fill('Công thức đã sửa');page.locator('#g6RecipeCTR').fill('150');page.locator('#g6SaveRecipe').click();expect(page.locator('#g6RecipeError')).to_contain_text('CTR');page.locator('#g6RecipeCTR').fill('2.5');page.locator('#g6SaveRecipe').click();expect(page.locator('.kvDetailHead h1')).to_have_text('Công thức đã sửa')
  assert page.evaluate('(id)=>roomFor(id).recipeSnapshot',ids['room'])==ids['snapshot']
  page.locator('[data-kv-tab=history]').click();page.locator('[data-use="'+ids['key']+'"]').click();page.locator('#kvResultVote').select_option('up');page.locator('#kvResultOrders').fill('-1');page.locator('#kvResultSave').click();expect(page.locator('#kvResultError')).to_contain_text('không âm');page.locator('#kvResultOrders').fill('7');page.locator('#kvResultViews').fill('0');page.locator('#kvResultNote').fill('Kết quả nhập tay');page.locator('#kvResultSave').click();expect(page.locator('#shellDialog')).not_to_be_visible()
  stats=page.evaluate('(id)=>kvStats(recipeCache,recipeCache.items.find(r=>r.id===id))',ids['recipe']);assert stats['up']==1 and stats['recorded']==1 and len(stats['uses'])>=2 and stats['orders']==7
  # Classification is local, bulk and persistent; trash retains complete formula.
  page.evaluate("async()=>{await putRecipe({...structuredClone(SFRecipes.starters[0]),id:'v3-inbox',name:'Khung sườn thử',source:'reference'});kv.filter='inbox';kv.selected=null;await kvDraw();}")
  page.locator('[data-kv-check="v3-inbox"]').check();page.locator('[data-kv=classify]').click();page.locator('#kvClassTopic').select_option('review');page.locator('#kvClassSave').click();page.wait_for_function("recipeCache.items.find(r=>r.id==='v3-inbox').inbox===false")
  page.locator('[data-kv-filter="all"]').click();page.locator('#g6RecipeList [data-g6-recipe="v3-inbox"]').click();page.locator('.kvDetailActions [data-kv=delete]').click();page.locator('[data-kv-filter=trash]').click();page.locator('#g6RecipeList [data-g6-recipe="v3-inbox"]').click();page.locator('.kvDetailActions [data-kv=restore]').click();expect(page.locator('#g6RecipeList [data-g6-recipe="v3-inbox"]')).to_have_count(0)
  page.reload();page.wait_for_function('rooms.length===7');page.wait_for_function('g6RecipeOpen&&recipeCache?.version===3');assert page.evaluate("recipeCache.items.find(r=>r.id==='v3-inbox').topicId")=='review';assert page.evaluate('(id)=>kvStats(recipeCache,recipeCache.items.find(r=>r.id===id)).orders',ids['recipe'])==7
  # New page controls retain fixed panel geometry while switching views.
  page.locator('#g6RecipeList [data-g6-recipe="'+ids['recipe']+'"]').click();box=page.locator('.kvShell').bounding_box();page.locator('[data-kv-tab=history]').click();assert page.locator('.kvShell').bounding_box()==box
  (root/'artifacts').mkdir(exist_ok=True);page.screenshot(path=str(root/'artifacts/kho-kich-ban-v3.png'),full_page=True)
  # Topic creation, duplication, explicit passing and product tags remain independent of results.
  page.locator('[data-kv=add-topic]').click();page.locator('#kvTopicName').fill('Chủ đề tự thêm');page.locator('#kvTopicSave').click();expect(page.locator('#kvTopics')).to_contain_text('Chủ đề tự thêm')
  page.locator('.kvDetailActions [data-kv=duplicate]').click();expect(page.locator('.kvDetailHead h1')).to_contain_text('bản sao')
  copy_id=page.evaluate('kv.selected');page.locator('.kvCard.selected [data-kv=pass]').click();expect(page.locator('.kvDetailHead .kvBadge')).to_have_text('✓ Đạt')
  assert page.evaluate('(id)=>kvStats(recipeCache,recipeCache.items.find(r=>r.id===id)).recorded',copy_id)==0
  # Separate column scroll and page containment at desktop and narrow widths.
  for width in [1366,390]:
   page.set_viewport_size({'width':width,'height':844});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  page.set_viewport_size({'width':1700,'height':1050})
  # Use creates a real photo workflow with a complete draft and correct beat timing.
  page.locator('[data-kv=use]').click();page.locator('[data-choose-product]').first.click()
  page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState()?.formula=== "'+copy_id+'"')
  frame=page.locator('#workflowFrame').element_handle().content_frame()
  state=frame.evaluate('()=>SceneForgeWorkflow.getState()');assert len(state['beats'])==5 and state['voice']['mode']=='ai'
  assert not errors,errors
  browser.close()
 print('PASS V3 migration, view/edit, validation, immutable room snapshot, recorded-only outcomes, bulk classification, full trash restore, reload persistence, stable frame. No provider calls.')
finally:server.shutdown()
