"""Setup appears once on a fresh connected local app; no popup in preview/normal usage."""
from pathlib import Path
from functools import partial
import http.server,threading,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Q(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Q,directory=str(root/'dist/web-demo')));threading.Thread(target=s.serve_forever,daemon=True).start();base=f'http://localhost:{s.server_port}'
def connected(page):
 data={'status':{'connected':True,'accounts':[],'logs':[],'engines':{},'gemini_configured':False},'system':{'engines':[],'disk':{'free':10*1024**3}},'ai/usage':{},'settings':{}}
 page.route('**/local-api/**',lambda route:route.fulfill(content_type='application/json',body=json.dumps(data.get(route.request.url.split('/local-api/')[-1],{}))))
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);errors=[]
  preview=b.new_page();preview.on('pageerror',lambda e:errors.append(str(e)));preview.goto(base);preview.wait_for_timeout(1200);expect(preview.locator('.g5Welcome')).to_have_count(0);preview.close()
  ctx=b.new_context(viewport={'width':1366,'height':768});page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));connected(page);page.add_init_script("Object.defineProperty(window,'showDirectoryPicker',{value:undefined,configurable:true})");page.goto(base);expect(page.locator('.g5Welcome')).to_be_visible(timeout=15000);expect(page.locator('#g5WizardRoot')).to_be_disabled();expect(page.locator('#g5WizardNext')).to_be_disabled();expect(page.locator('.g5Connection')).to_contain_text('Chrome hoặc Edge')
  page.screenshot(path='/tmp/sceneforge-setup-refined.png')
  for width,height in [(1366,768),(390,740)]:
   page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(70);dlg=page.locator('#shellDialog').bounding_box();foot=page.locator('#dialogActions').bounding_box();btn=page.locator('#g5WizardNext').bounding_box();assert dlg['x']>=0 and dlg['y']>=0 and dlg['x']+dlg['width']<=width and dlg['y']+dlg['height']<=height,(dlg,width,height);assert btn['x']+btn['width']<=foot['x']+foot['width']-10 and btn['y']+btn['height']<=dlg['y']+dlg['height']-10,(dlg,foot,btn)
  page.locator('#closeDialog').click();page.reload();page.wait_for_timeout(800);expect(page.locator('.g5Welcome')).to_have_count(0);page.evaluate('SceneForgeApp.settings.welcome()');page.wait_for_timeout(100);expect(page.locator('.g5Welcome')).to_have_count(0);page.evaluate('SceneForgeApp.settings.open("ai")');expect(page.locator('.g5Settings')).to_be_visible();expect(page.locator('#g5Welcome')).to_have_count(0);ctx.close()
  # Fresh setup can finish all five steps; nested redraws preserve the same session.
  ctx=b.new_context();page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));connected(page);page.goto(base);expect(page.locator('.g5Welcome')).to_be_visible(timeout=15000);page.evaluate("async()=>{prefs.root={name:'Thư mục fixture'};await savePrefs();await g5Welcome(0)}");page.locator('#g5WizardNext').click();expect(page.locator('.g5Welcome section h2')).to_have_text('Kiểm tra máy');page.locator('#g5WizardSkip').click();expect(page.locator('.g5Welcome section h2')).to_have_text('Key Gemini');page.locator('#g5WizardSkip').click();page.locator('#g5WizardSkip').click();page.locator('#g5WizardSkip').click();expect(page.locator('#shellDialog')).not_to_be_visible();assert page.evaluate('prefs.package5WelcomeDone')is True;page.reload();page.wait_for_timeout(800);expect(page.locator('.g5Welcome')).to_have_count(0);ctx.close()
  demo=b.new_page();connected(demo);demo.goto(base+'/?demo=1');demo.wait_for_function('SceneForgeApp.getState().rooms.length===7',timeout=60000);demo.evaluate('SceneForgeApp.settings.welcome()');expect(demo.locator('.g5Welcome')).to_have_count(0);assert not errors,errors;b.close();print('PASS: absent on static preview/demo; fresh connected-local first run only; close/reload/manual call cannot reopen; settings entry removed; five-step completion persists; unsupported picker disabled; footer and dialog inside desktop/mobile viewport. Backend status fixture only.')
finally:s.shutdown()
