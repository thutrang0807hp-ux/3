"""Check actual DOM landmarks against the interior of supplied 01-trang-chu.png."""
from pathlib import Path
from functools import partial
import http.server,threading,json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':2018,'height':1258});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://localhost:'+str(server.server_port)+'/?demo=1');page.wait_for_function('document.querySelectorAll(".stageColumn").length===4&&SceneForgeApp.getState().rooms.length===7',timeout=60000)
  # Compare app interior only; original PNG has a slide title/frame outside the app.
  page.add_style_tag(content='.showcaseBanner{display:none!important}.showcase{padding-top:0}.showcase .rail{top:0}.showcase #roomWorkspace{top:0}')
  boxes=page.evaluate('''()=>Object.fromEntries(['.rail','.products','.deskHeader','#productTabs','.roomCard','#newVideo','.logo svg rect'].map(s=>{const r=document.querySelector(s).getBoundingClientRect();return[s,{x:r.x,y:r.y,w:r.width,h:r.height}]}))''')
  # PNG landmarks minus its (48,138) application-frame origin, +/- a few antialias/layout pixels.
  targets={'.rail':{'w':100},'.products':{'x':100,'w':330},'.deskHeader':{'x':480},'#productTabs':{'x':480,'y':142},'.roomCard':{'x':480,'y':304,'w':300},'#newVideo':{'x':1772,'w':194,'h':54}}
  for selector,values in targets.items():
   for key,expected in values.items():assert abs(boxes[selector][key]-expected)<=7,(selector,key,boxes[selector],expected)
  assert not page.locator('.logo').inner_text().strip();assert page.locator('.logo rect').get_attribute('rx')=='4';assert page.locator('[data-method=reference] svg').count()==1;assert page.locator('[data-method=photos] svg').count()==1
  assert page.locator('.roomCard').count()==7;assert page.locator('.compactCard').count()==0
  assert page.locator('[data-product] .productName>b').all_text_contents()==['Tất cả','Son','Nước hoa ô tô','Kem chống nắng','GLYTWIN xịt bếp','Máy hút bụi mini']
  page.screenshot(path='/tmp/sceneforge-desk-design-verified.png');(root/'docs/desk-design-landmarks.json').write_text(json.dumps({'viewport':[2018,1258],'referenceAppOrigin':[48,138],'target':targets,'actual':boxes},indent=2)+'\n')
  # Many projects still compact, as specified by the older 20-video design. Nothing is hidden/deleted.
  page.evaluate('''()=>{const seed=rooms[0];for(let n=0;n<15;n++)rooms.push({...structuredClone(seed),id:crypto.randomUUID(),name:'Nhiều video '+n});render();}''');assert page.locator('.compactCard').count()>0;assert page.locator('[data-room]').count()>=22
  assert not errors,errors;b.close()
 print('PASS: SVG logo/icons, product order, 7 full cards vs compact dense board, measured rail/sidebar/card/header/button positions match supplied image landmarks within 7px at identical app size. No API calls.')
finally:server.shutdown()
