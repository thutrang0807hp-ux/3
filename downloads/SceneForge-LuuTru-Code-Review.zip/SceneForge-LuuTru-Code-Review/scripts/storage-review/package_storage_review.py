"""Package the current storage path, shared runnable dependencies and audit map."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/SceneForge-LuuTru-Code-Review.zip'
PREFIX='SceneForge-LuuTru-Code-Review/'
CORE=['scripts/app-shell/storage-actions.js','local_engine/storage_lifecycle.py','local_engine/storage_jobs.py','local_engine/library_lock.py','local_engine/request_ledger.py','scripts/app-shell/archive-lifecycle.js','scripts/app-shell/home-archive.js','scripts/app-shell/library-runtime.js','scripts/app-shell/library-panel.js','scripts/app-shell/library-portable.js','scripts/app-shell/app.js','scripts/app-shell/recovery.js','scripts/native-preview/room-shell.js','scripts/native-preview/ffmpeg-export.js','scripts/native-preview/timeline-export.js','scripts/native-preview/editor-storage.js','local_engine/library.py','local_engine/library_api.py','local_engine/schema.py','local_engine/local_jobs.py','local_engine/exports.py','local_engine/timeline_export.py','local_engine/server.py']
START='''# Gói code Lưu trữ / Thu gọn sau xuất

Snapshot mã hiện tại 26/10/2026, lưu trữ v2 và receipt schema 3 sau củng cố luồng Video mẫu. Mục tiêu là mang đi phân tích, không thay đổi logic hoặc tự dọn dữ liệu khi đóng gói.

Đọc `review/BAN_DO_CODE.md` trước. Danh sách file trọng tâm và số dòng nằm trong `review/core-files.json`. `review/CAU_HOI_CAN_RA.md` nêu các giới hạn và điểm cần kiểm thêm; không coi mô tả trong docs là bằng chứng code đã làm đủ.

Code gốc giữ nguyên đường dẫn trong `scripts/` và `local_engine/`. Các module của app khác đi kèm là phụ thuộc dùng chung để shell/backend có thể dựng và khởi động nguyên vẹn; không phải toàn bộ đều là logic lưu trữ. Có bản web trong `dist/web-demo/`. Không kèm model, tài khoản, cookie, vault, venv, video người dùng, dữ liệu phòng hoặc EXE phần mềm khác.

## Chạy / kiểm

- Kiểm hash: `python review/verify_package.py`.
- Dựng: `npm ci --prefix scripts/watermark-builder`, rồi `python scripts/demo-web/build.py`.
- Backend local: `local_engine/start.bat` trên Windows, hoặc tạo venv Python 3.11/3.12, cài `local_engine/requirements.txt`, chạy `python -m local_engine`.
- Dùng thư mục dữ liệu thử riêng qua `SCENEFORGE_LOCAL_DATA`; không dùng kho đang có dữ liệu quan trọng để thử xóa. Các bài kiểm có temporary directory / profile riêng.
- Bài kiểm trọng tâm: `python -m local_engine.check_archive_release`, `python -m local_engine.check_export_commit`, `python scripts/app-shell/check_archive_local.py`, `python scripts/app-shell/check_photo_archive_lifecycle.py`.
- Chromium checks hiện dùng `/usr/bin/chromium` trên Linux; cần điều chỉnh trình duyệt nếu kiểm trên máy khác. Không chứng nhận Windows/online E2E.

`review/TEST_RESULTS.json` chỉ ghi kết quả đã chạy cho gói này. Manifest chứa SHA-256 từng file, không là đánh giá code an toàn hoàn chỉnh.
'''
MAP='''# Bản đồ luồng lưu trữ

| Bước | File cần đọc | Vai trò |
|---|---|---|
| Xuất xong → lưu Blob → báo Đã xuất | `scripts/native-preview/room-shell.js`, `scripts/app-shell/app.js` | `queueRoomExport`, `saveRoomExport`, ACK về editor; retry lưu không dựng lại |
| Chép bền từ IndexedDB xuống máy | `scripts/app-shell/library-runtime.js` | Theo dõi transaction, serialize Blob/data URL thành hash, checkpoint; localStorage dirty flag, lease/recovery |
| SQLite + file theo hash | `local_engine/library.py` | commit/revision, asset_ref, backup, pin, verify, relocate, cleanup/release_compacted |
| API kho | `local_engine/library_api.py` | `/local-api/library/*`; upload/restore/cleanup/release-compacted/bundle |
| Chuyển Lưu trữ | `scripts/app-shell/home-archive.js` | danh sách, restore, trạng thái, thống kê. Chuyển Lưu trữ chưa tự xóa tư liệu |
| Thu gọn chỉ giữ thành phẩm | `scripts/app-shell/archive-lifecycle.js` | archiveCompactPlan, archivePerformCompact; hash video, text-only snapshot, journal prepared/committed, giữ export/SRT và file chia sẻ |
| Lịch / ghim / dùng lại kịch bản | cùng file archive-lifecycle | archiveRunDue, archiveLifecycleDialog, archiveSaveScript; app mở mới xét lịch; không giữ timeline đầy đủ sau final-only |
| Sao lưu / chuyển máy / Thùng rác | `scripts/app-shell/library-panel.js`, `library-portable.js`, `local_engine/library.py` | UI và snapshot/bundle; refs trong backup có thể giữ media khỏi bị xóa |
| File tạm FFmpeg và job | `local_engine/timeline_export.py`, `exports.py`, `local_jobs.py` | nguồn export tạm, output tạm, cleanup/cancel/restart. Khác với Blob thành phẩm đã commit vào kho |
| Bản sao ra thư mục ngoài | `scripts/app-shell/app.js` | mirrorRoom, writeImmutableFile; thu gọn không xóa bản sao ngoài app |
| Tệp gen ở backend | `local_engine/flow_provider.py`, `muse_provider.py`, `gemini_chat.py`, `request_ledger.py` | các thư mục results/journal riêng; chưa dọn thống nhất với final-only |
| Bootstrap/quyền | `local_engine/server.py`, `runtime_safety.py`, `schema.py` | đăng ký route, dữ liệu local, same-origin/session, migration |

API đúng path/method xem `review/storage-routes.json`, trích từ inventory của app cùng bản dựng. Mã frontend giữ nguyên, gồm các wrapper/hàm được ghi đè ở cuối module; cần theo đúng thứ tự ghép trong `scripts/demo-web/build.py` khi phân tích.
'''
QUESTIONS='''# Điểm cần mang đi rà

1. Thu gọn xóa file trung gian nào thực sự trên ổ? Phân biệt IndexedDB, kho hash, schema/metadata backups, results Flow/Muse/Gemini và bản mirror ngoài app. Không mặc định estimated bytes = freed bytes.
2. `archiveTaskGuard` nhìn shell jobs/activeWorkers. Cần đối chiếu thêm cloudJobs, referencePromptJobs, analysis.aiRequest/batches của workflow mới, cả planned/unknown/missing/done chưa import; chưa có kiểm thử chứng minh chặn thu gọn đầy đủ cho mọi trạng thái đó. Đây là điểm rà bổ sung, không tự sửa trong gói bàn giao.
3. Shared refs theo key/hash có bảo vệ đủ assets nằm trong workflow/editor của phòng khác? Kiểm cả Thùng rác, pin và backups; dữ liệu giữ trong backup có thể khiến không dọn được dung lượng như dự tính.
4. Cross-DB journal/lease/checkpoint: thử crash/quota ở từng pha. ACK xuất hiện mới xác nhận Blob+room ghi browser; checkpoint xuống SQLite/mirror là các tầng tiếp theo, chưa có giao thức ACK end-to-end cho mọi tầng.
5. Thu gọn final-only giữ kịch bản/prompt nhưng bỏ timeline chỉnh sửa đầy đủ. Kiểm restore/new-room/các phiên bản và bản chữ nào được giữ thật, đặc biệt fields mới bổ sung.
6. Lịch chỉ xét khi app mở; mặc định tắt, hash thành phẩm phải khớp, ghim và mở lại chỉnh thì dừng. Có đồng bộ đầy đủ khi thay export/restore/đổi thư mục dữ liệu không?
7. RAM khác dung lượng đĩa: encode/hash/equalBlob và journal có thể materialize Blob/arrayBuffer/copy. Chưa có benchmark RAM với 10 dự án thật hoặc video lớn. Không dùng 200MB upload fixture làm bằng chứng mức RAM thu gọn.
8. Chưa triển khai thu hồi đồng bộ results Flow/Muse/Gemini. Đừng nối lệnh xóa chỉ dựa tuổi file; phải bảo vệ live jobs, unknown requests, các phiên bản và timeline.
9. `scripts/app-shell/check_photo_archive_lifecycle.py` hiện timeout ở bước Storyboard trước phần thu gọn (`#photoChatPrompt`); không tính phần sau đó là đã chạy. `check_archive_local` độc lập đã kiểm journal/lịch/giữ thành phẩm trên SQLite thật.
10. `scripts/app-shell/check_home_archive.py` là bài cũ đang timeout tại selector layout `#board [data-room]`; không ghi PASS. Có các bài tập trung lifecycle/backend riêng trong TEST_RESULTS.

Đây là snapshot phục vụ đánh giá. Không có tài khoản online/Windows E2E trong gói; không tự chạy AI hay tự dọn dữ liệu khi giải nén.
'''
VERIFY='''from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'review/manifest.json').read_text())
for item in m['files']:
 raw=(root/item['path']).read_bytes()
 assert len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256'],item['path']
print('PASS:',len(m['files']),'files match manifest; no data cleanup or provider calls')
'''
MAP='# Bản đồ lưu trữ v2\n\n| Vùng | File |\n|---|---|\n| Ba thao tác, chọn nhiều, lấy lại/thử lại, setting dung lượng | scripts/app-shell/storage-actions.js |\n| Quyền xóa ở backend, plan/CAS, release/deleted, quarantine/revive/cancel/expedite | local_engine/storage_lifecycle.py |\n| Registry job, nhập đúng job/room/hash, alias, dự phòng dung lượng | local_engine/storage_jobs.py |\n| Hash store/SQLite/backup/ZIP/restore và chuyển thư viện | local_engine/library.py |\n| Các API kho mới | local_engine/library_api.py |\n| Khóa một bộ chạy trên máy | local_engine/library_lock.py, instance.py |\n| Claim chống gửi trùng và nối catalogue | local_engine/request_ledger.py |\n| Browser checkpoint, worker hash, binary assets, cache | scripts/app-shell/library-runtime.js, library-portable.js |\n| Đường browser cũ và lịch chốt; local chuyển sang backend | scripts/app-shell/archive-lifecycle.js |\n| MP4/WAV/results vào catalogue | local_engine/timeline_export.py, exports.py, server.py; provider adapters |\n\nĐọc docs/storage-lifecycle-v2.md trước, sau đó TEST_RESULTS.json. Những phần phụ thuộc app đi kèm để dựng/chạy; gói không kèm model, tài khoản hoặc dữ liệu phòng thật.\n'
QUESTIONS='# Những điểm còn cần đánh giá\n\n- Thử Windows thật với file đang mở/antivirus; hiện mới có Linux và fixture lỗi/crash.\n- Dọn hiện đợi tác vụ đang chạy kết thúc; chưa cho dọn song song tùy hash trong lúc gen.\n- Chỉ dọn file đủ bằng chứng sở hữu/tham chiếu. Backend cũ không nhận diện được vẫn giữ, không đoán theo tuổi file.\n- Không quản lý file người dùng đã tự chép ngoài app; published có lựa chọn riêng khi xóa dự án.\n- Snapshot vẫn ghi toàn metadata, chưa delta; quét backup/hash còn I/O, chưa benchmark 10 video thật.\n- Không hỗ trợ nhiều máy cùng ghi qua NAS/Drive; khóa OS chỉ cho một máy.\n- ZIP không mang pending quarantine: phải chốt/lấy lại trước, hoặc chuyển nguyên thư viện. Policy toàn thư viện chỉ nhập vào kho mới chưa có dự án/lịch sử xóa.\n- Restore thiếu shared/pin vẫn chặn; partial restore chỉ khi bỏ qua được các phòng hỏng mà không làm mất shared data.\n- Giữ bản ghim, live refs, upload lease và job chưa nhập; xóa ngay không đảm bảo xóa mọi hash vừa mới upload.\n- Cần rà root DATA temp/cache/logs riêng; không hứa dọn mọi byte trong toàn ổ.\n- Xem TEST_RESULTS: các bài browser cũ timeout không được tính PASS. Không có thử tài khoản online.\n'

def main():
 files={}
 # This validated source bundle already contains every dependency needed to rebuild five runtime pages.
 with zipfile.ZipFile(ROOT/'artifacts/SceneForge-VideoMau-Code-Review.zip')as base:
  prefix='SceneForge-VideoMau-Code-Review/'
  for name in base.namelist():
   rel=name.removeprefix(prefix)
   if rel.startswith(('review/','artifacts/'))or rel in ('START_HERE.md','REBUILD.bat'):continue
   path=ROOT/rel
   files[rel]=path.read_bytes()if path.is_file()else base.read(name)
  routes=json.loads(base.read(prefix+'review/routes.json'))
  files['review/storage-routes.json']=json.dumps([row for row in routes if row['path'].startswith(('/local-api/library/','/local-api/export/'))],ensure_ascii=False,indent=2).encode()
 for name in ['docs/storage-lifecycle-v2.md','docs/photo-archive-lifecycle.md','docs/reference-reliability-update.md','docs/storage-library-implementation.md','docs/job-recovery-implementation.md','scripts/storage-review/package_storage_review.py']:
  files[name]=(ROOT/name).read_bytes()
 for name in CORE:
  assert name in files or not(ROOT/name).exists(),name
 core=[{'path':name,'lines':len(files[name].splitlines())}for name in CORE if name in files]
 files['START_HERE.md']=START.encode();files['review/BAN_DO_CODE.md']=MAP.encode();files['review/CAU_HOI_CAN_RA.md']=QUESTIONS.encode();files['review/verify_package.py']=VERIFY.encode();files['review/core-files.json']=json.dumps(core,ensure_ascii=False,indent=2).encode()
 results=ROOT/'artifacts/storage-lifecycle-v2-checks.json'
 if results.exists():files['review/TEST_RESULTS.json']=results.read_bytes()
 files['review/REFERENCE_FLOW_FIX_CHECKS.json']=(ROOT/'artifacts/reference-flow-fix-checks.json').read_bytes()
 manifest={'snapshot':'storage review, 2026-10-26, reference flow fixes, schema 3','contains_user_data':False,'models_included':False,'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}for name,raw in sorted(files.items())]}
 files['review/manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
 assert not any(any(part in ('.git','.venv','node_modules','models')for part in Path(name).parts)for name in files)
 with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED)as z:
  for name,raw in sorted(files.items()):z.writestr(PREFIX+name,raw)
 with zipfile.ZipFile(OUT)as z:assert z.testzip()is None
 digest=hashlib.sha256(OUT.read_bytes()).hexdigest();OUT.with_suffix('.zip.sha256').write_text(digest+'  '+OUT.name+'\n')
 print(OUT,OUT.stat().st_size,'bytes',len(files),'files',digest)
if __name__=='__main__':main()
