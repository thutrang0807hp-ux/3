const transformKeys = ["x", "y", "scale", "rotation", "opacity", "textX", "textY", "volume"];
const fonts = [["system-ui", "Hiện đại"], ["Arial", "Arial"], ["Georgia", "Serif"], ["Verdana", "Verdana"], ["monospace", "Mono"]];
const looks = { none: "Gốc", warm: "Ấm", cool: "Lạnh", mono: "Đen trắng", cinema: "Điện ảnh", vintage: "Cổ điển" };
let booting = true, draftCandidate = null, draftTimer, recording = false, exportCancelled = false, exportAudioContext, exportDestination;
const audioSources = /* @__PURE__ */ new Map();
function extraDefaults() {
  return { linkGroup:"",audioMuted:false,audioBypass:true,audioGainDb:0,audioBass:0,audioMid:0,audioTreble:0,audioHighpass:20,audioLowpass:20000,audioPan:0,audioThreshold:-24,audioRatio:1,audioPreset:"original",audioPreservePitch:true,transitionDirection:"left",transitionEasing:"linear",flipX: false, flipY: false, brightness: 100, contrast: 100, saturation: 100, temperature:0, blur: 0, look: "none", fontFamily: "system-ui", outline: 0, outlineColor: "#000000", letterSpacing: 0, textAnimation: "none", animationDuration: 0.5, keyframes: [] };
}
function evaluateProps(i, at = time) {
  const out = Object.fromEntries(transformKeys.map((k) => [k, i[k]]));
  const keys = [...i.keyframes || []].sort((a2, b2) => a2.at - b2.at), local = clamp(at - i.start, 0, i.duration);
  if (!keys.length) return out;
  let a = keys[0], b = keys[keys.length - 1];
  for (let j = 0; j < keys.length; j++) {
    if (keys[j].at <= local) a = keys[j];
    if (keys[j].at >= local) {
      b = keys[j];
      break;
    }
  }
  const p = a.at === b.at ? 0 : clamp((local - a.at) / (b.at - a.at), 0, 1);
  for (const k of transformKeys) out[k] = (a.values[k] ?? i[k]) + ((b.values[k] ?? i[k]) - (a.values[k] ?? i[k])) * p;
  return out;
}
function updateKeyframedProp(i, key, value) {
  if (!transformKeys.includes(key) || !i.keyframes?.length) return;
  let at = clamp(time - i.start, 0, i.duration), frame = i.keyframes.find((k) => Math.abs(k.at - at) < 0.05);
  if (!frame) {
    frame = { at, values: evaluateProps(i) };
    i.keyframes.push(frame);
  }
  frame.values[key] = value;
}
function visualFilter(i, unit = 1) {
  const presets = { none: "", warm: "sepia(.25) saturate(1.15)", cool: "hue-rotate(12deg) saturate(.8)", mono: "grayscale(1)", cinema: "contrast(1.18) saturate(.75)", vintage: "sepia(.55) contrast(.9)" };
  return `${presets[i.look] || ""} brightness(${i.brightness}%) contrast(${i.contrast}%) saturate(${i.saturation}%) blur(${i.blur * unit}px) ${i.temperature?`sepia(${Math.abs(i.temperature)*.003}) hue-rotate(${i.temperature<0?Math.abs(i.temperature)*1.8:0}deg)`:""}`;
}
function trackVisible(t) {
  return !t.hidden && (!tracks.some((x) => x.solo && x.kind === t.kind) || t.solo);
}
function animatedText(i) {
  if (i.textAnimation === "typewriter") return i.text.slice(0, Math.ceil(i.text.length * clamp((time - i.start) / Math.max(0.1, i.animationDuration), 0, 1)));
  return i.text;
}
function textEffect(i) {
  let progress = clamp((time - i.start) / Math.max(0.1, i.animationDuration), 0, 1);
  return { opacity: i.textAnimation === "fade" ? progress : 1, y: i.textAnimation === "rise" ? (1 - progress) * 15 : 0 };
}
function styleTextPreview(n, i, v) {
  const f = textEffect(i);
  n.style.fontFamily = i.fontFamily;
  n.style.letterSpacing = i.letterSpacing / projectFrame.width * 100 + "cqw";
  n.style.webkitTextStroke = i.outline / projectFrame.width * 100 + "cqw " + i.outlineColor;
  n.style.paintOrder = "stroke fill";
  n.style.opacity = v.opacity * f.opacity;
  n.style.transform = `translate(-50%,-50%) translateY(${f.y}%) rotate(${v.rotation}deg) scale(${v.scale})`;
}
function enhancedInspector(i) {
  let html = "";
  if (i.kind !== "text" && i.kind !== "audio") html += `<details class="editSection" open><summary>Chỉnh màu & lật hình</summary><div class="presetGrid">${Object.entries(looks).map(([k, n]) => `<button data-look="${k}" class="${i.look === k ? "active" : ""}">${n}</button>`).join("")}</div><div class="pair">${field("Độ sáng (%)", "brightness", i.brightness, "number", 'min="0" max="200"')}${field("Tương phản (%)", "contrast", i.contrast, "number", 'min="0" max="200"')}</div><div class="pair">${field("Bão hòa (%)", "saturation", i.saturation, "number", 'min="0" max="300"')}${field("Làm mờ (px)", "blur", i.blur, "number", 'min="0" max="20"')}</div><div class="pair"><label class="checkLabel"><input id="prop-flipX" type="checkbox" data-prop="flipX" ${i.flipX ? "checked" : ""}>Lật ngang</label><label class="checkLabel"><input id="prop-flipY" type="checkbox" data-prop="flipY" ${i.flipY ? "checked" : ""}>Lật dọc</label></div><button data-reset-look>Đặt lại màu</button></details>`;
  if (i.kind === "text") html += `<details class="editSection" open><summary>Kiểu chữ & hiệu ứng</summary><div class="presetGrid"><button data-text-preset="title">Tiêu đề</button><button data-text-preset="subtitle">Phụ đề</button><button data-text-preset="label">Nhãn</button></div>${selectField("Phông chữ máy có sẵn", "fontFamily", i.fontFamily, fonts)}<div class="pair">${field("Viền chữ (px)", "outline", i.outline, "number", 'min="0" max="12"')}${field("Màu viền", "outlineColor", i.outlineColor, "color")}</div>${field("Giãn chữ (px)", "letterSpacing", i.letterSpacing, "number", 'min="0" max="25"')}${selectField("Hiệu ứng vào", "textAnimation", i.textAnimation, [["none", "Không"], ["fade", "Hiện dần"], ["rise", "Trượt lên"], ["typewriter", "Gõ chữ"]])}${field("Thời lượng hiệu ứng (s)", "animationDuration", i.animationDuration, "number", 'min="0.1" max="5"')}</details>`;
  html += `<div class="actions"><button id="copySettings">Sao chép thuộc tính</button><button id="pasteSettings" ${copiedSettings ? "" : "disabled"}>Dán</button></div><details class="editSection" open><summary>◇ Keyframe chuyển động</summary><p class="hint">Đặt vạch phát trong mục, thêm mốc rồi chỉnh vị trí, xoay, zoom, độ trong hoặc âm lượng. Khi đã có mốc, chỉnh tại thời điểm khác sẽ tạo mốc mới. Nội suy tuyến tính.</p><div class="actions"><button id="addKeyframe">＋ Mốc tại vạch phát</button><button id="clearKeyframes">Xóa mốc</button></div><div class="keyframes">${[...i.keyframes || []].sort((a, b) => a.at - b.at).map((k) => `<button data-seek-key="${k.at}">◇ ${k.at.toFixed(2)}s</button>`).join("") || "<small>Chưa có keyframe</small>"}</div></details>`;
  return html;
}
function addInspectorNavigation(){organizeInspector();decorateReferenceInspector();}
function sanitizeExtraProp(key, value) {
  const limits = { temperature:[-100,100], brightness: [0, 200], contrast: [0, 200], saturation: [0, 300], blur: [0, 20], outline: [0, 12], letterSpacing: [0, 25], animationDuration: [0.1, 5] };
  return limits[key] ? clamp(value, ...limits[key]) : value;
}
function sanitizeRestoredExtras(out, raw) {
  for (const key of ["temperature","brightness", "contrast", "saturation", "blur", "outline", "letterSpacing", "animationDuration"]) out[key] = sanitizeExtraProp(key, out[key]);
  for(const [key,limits]of Object.entries(audioParameterLimits))out[key]=Number.isFinite(out[key])?clamp(out[key],...limits):extraDefaults()[key];
  out.audioBypass=out.audioBypass!==false;
  out.audioPreset=['original','clear','warm','soft','custom'].includes(out.audioPreset)?out.audioPreset:'custom';
  out.audioPreservePitch=out.audioPreservePitch!==false;
  out.transitionDirection=['left','right','up','down'].includes(out.transitionDirection)?out.transitionDirection:'left';
  out.transitionEasing=['linear','easeIn','easeOut','easeInOut'].includes(out.transitionEasing)?out.transitionEasing:'linear';
  out.look = Object.hasOwn(looks, out.look) ? out.look : "none";
  out.fontFamily = fonts.some((f) => f[0] === out.fontFamily) ? out.fontFamily : "system-ui";
  out.textAnimation = ["none", "fade", "rise", "typewriter"].includes(out.textAnimation) ? out.textAnimation : "none";
  if (!/^#[0-9a-f]{6}$/i.test(out.outlineColor)) out.outlineColor = "#000000";
  const bounds = { x: [-100, 100], y: [-100, 100], scale: [0.1, 4], rotation: [-360, 360], opacity: [0, 1], textX: [0, 100], textY: [0, 100], volume: [0, 20] };
  out.keyframes = Array.isArray(raw.keyframes) ? raw.keyframes.slice(0, 150).filter((k) => Number.isFinite(k.at) && k.at >= 0 && k.at <= out.duration && k.values).map((k) => ({ at: k.at, values: Object.fromEntries(transformKeys.map((key) => [key, clamp(Number.isFinite(k.values[key]) ? k.values[key] : out[key], ...bounds[key])])) })) : [];
}
$("#inspector").addEventListener("click", (e) => {
  const i = selected();
  if (!i) return;
  const look = e.target.closest("[data-look]"), preset = e.target.closest("[data-text-preset]"), seek = e.target.closest("[data-seek-key]");
  if (seek) {
    pause();
    time = i.start + Number(seek.dataset.seekKey);
    updateStage(true);
    inspector();
    return;
  }
  if (look || preset || e.target.matches("#addKeyframe,#clearKeyframes,[data-reset-look]")) {
    if (!allowEdit()) return;
    transact(() => {
      if (look) i.look = look.dataset.look;
      if (preset) {
        const v = { title: { fontSize: 96, bold: true, textY: 22, textBg: false, color: "#ffffff", outline: 2 }, subtitle: { fontSize: 54, bold: true, textY: 82, textBg: true, background: "#000000", color: "#ffffff", outline: 0 }, label: { fontSize: 48, bold: false, textY: 15, textBg: true, background: "#324b53", color: "#8be8d4", outline: 0 } };
        Object.assign(i, v[preset.dataset.textPreset]);
      }
      if (e.target.matches("[data-reset-look]")) Object.assign(i, { look: "none", brightness: 100, contrast: 100, saturation: 100, temperature:0, blur: 0 });
      if (e.target.id === "clearKeyframes") i.keyframes = [];
      if (e.target.id === "addKeyframe") {
        const at = clamp(time - i.start, 0, i.duration), values = evaluateProps(i);
        if (time < i.start || time > end(i)) {
          notify("Đưa vạch phát vào mục đang chọn.");
          return;
        }
        i.keyframes = i.keyframes || [];
        i.keyframes = i.keyframes.filter((k) => Math.abs(k.at - at) > 0.05);
        i.keyframes.push({ at, values });
      }
    });
  }
});
function enhanceTrackControls() {
  $$(".trackTitle").forEach((el) => {
    const row = el.closest("[data-track]");
    if (!row || el.querySelector("[data-track-extra]")) return;
    const t = getTrack(row.dataset.track), buttons = el.querySelector(".trackButtons");
    for (const [action, title, label] of [["up", "Đưa track lên", "↑"], ["down", "Đưa track xuống", "↓"], ["solo", "Chỉ phát track này", "S"]]) {
      const b = document.createElement("button");
      b.dataset.trackExtra = action;
      b.dataset.id = t.id;
      b.title = title;
      b.textContent = label;
      b.classList.toggle("active", action === "solo" && t.solo);
      buttons.append(b);
    }
    el.querySelector("b").title = "Bấm đúp để đổi tên track";
    el.querySelector("b").ondblclick = () => {
      const name = prompt("Tên track", t.name);
      if (name?.trim()) transact(() => t.name = name.trim().slice(0, 60));
    };
  });
}
$("#tracks").addEventListener("click", (e) => {
  const b = e.target.closest("[data-track-extra]");
  if (!b) return;
  const t = getTrack(b.dataset.id);
  transact(() => {
    const k = tracks.indexOf(t);
    if (b.dataset.trackExtra === "solo") t.solo = !t.solo;
    else {
      const n = k + (b.dataset.trackExtra === "up" ? -1 : 1);
      if (n >= 0 && n < tracks.length) [tracks[k], tracks[n]] = [tracks[n], tracks[k]];
    }
  });
});
$("#closeGaps").onclick = () => {
  const i = selected();
  if (!i) {
    notify("Chọn mục trên track muốn xếp liền.");
    return;
  }
  if (!allowEdit()) return;
  transact(() => {
    let at = 0;
    items.filter((x) => x.trackId === i.trackId).sort((a, b) => a.start - b.start).forEach((x) => {
      x.start = at;
      at = end(x);
    });
  });
};
$("#addSticker").onclick = () => {
  addText();
  const i = selected();
  i.text = "★";
  i.name = "Nhãn dán";
  i.fontSize = 180;
  i.color = "#ffe69a";
  i.textY = 25;
  render();
};
function srtTime(s) {
  const m = s.trim().match(/^(\d{1,2}):(\d{2}):(\d{2})[,.](\d{3})$/);
  if (!m || +m[2] > 59 || +m[3] > 59) return NaN;
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1e3;
}
function toSrtTime(n) {
  const ms = Math.round(n * 1e3);
  return String(Math.floor(ms / 36e5)).padStart(2, "0") + ":" + String(Math.floor(ms / 6e4) % 60).padStart(2, "0") + ":" + String(Math.floor(ms / 1e3) % 60).padStart(2, "0") + "," + String(ms % 1e3).padStart(3, "0");
}
$("#importSrt").onclick = () => $("#srtFile").click();
$("#srtFile").onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    if (f.size > 1e6) throw Error();
    const lines = (await f.text()).replace(/^\uFEFF/, "").replace(/\r/g, "").trim().split(/\n\s*\n/);
    const subs = lines.map((block) => {
      const a = block.split("\n");
      if (/^\d+$/.test(a[0].trim())) a.shift();
      const pair = a.shift().split(/\s*-->\s*/), start = srtTime(pair[0]), finish = srtTime(pair[1] || "");
      const text = a.join("\n").replace(/<[^>]*>/g, "").trim();
      if (!Number.isFinite(start) || !Number.isFinite(finish) || finish - start < 0.2 || finish > 3600 || !text) throw Error();
      return { start, duration: finish - start, text: text.slice(0, 500) };
    });
    if (!subs.length || subs.length > 250 || items.length + subs.length > 300) throw Error();
    transact(() => {
      const t = { id: uid(), name: "Phụ đề SRT", kind: "text" };
      tracks.push(t);
      subs.forEach((s) => items.push({ ...defaults("text"), id: uid(), kind: "text", trackId: t.id, name: "Phụ đề", ...s, fontSize: 54, textBg: true, textY: 82, subtitle: true }));
      selection = items[items.length - 1].id;
    });
    notify("Đã nhập " + subs.length + " đoạn phụ đề, có thể sửa trực tiếp.");
  } catch {
    notify("SRT không hợp lệ: dùng thời gian HH:MM:SS,mmm; tối đa 250 đoạn và 60 phút.");
  }
  e.target.value = "";
};
$("#exportSrt").onclick = () => {
  const captions = items.filter((i) => i.kind === "text").sort((a, b) => a.start - b.start);
  if (!captions.length) {
    notify("Chưa có văn bản để xuất SRT.");
    return;
  }
  downloadBlob("sceneforge-subtitles.srt", new Blob([captions.map((i, n) => `${n + 1}
${toSrtTime(i.start)} --> ${toSrtTime(end(i))}
${i.text}`).join("\n\n") + "\n"], { type: "application/x-subrip" }));
  notify("Đã xuất tất cả mục chữ thành phụ đề SRT.");
};
function projectPayload() {
  return { format: "sceneforge-timeline", version: 1, tracks, items, markers, frame:projectFrame,timelineSettings:{mode:timelineEditMode,importPlacement:$("#importPlacement").value}, assets: assets.map(({ url, poster, ...a }) => a) };
}
function scheduleDraft() {
  if (booting) return;
  clearTimeout(draftTimer);
  draftTimer = setTimeout(() => {
    try {
      localStorage.setItem("sceneforge-editor-draft-v2", JSON.stringify(projectPayload()));
    } catch {
    }
  }, 700);
}
function detectDraft() {
  try {
    draftCandidate = localStorage.getItem("sceneforge-editor-draft-v2");
    if (draftCandidate) $("#restoreDraft").hidden = false;
  } catch {
  }
}
$("#restoreDraft").onclick = () => {
  try {
    const s = draftCandidate || localStorage.getItem("sceneforge-editor-draft-v2");
    if (!s) return;
    const f = new File([s], "draft.json", { type: "application/json" });
    $("#projectFile").onchange({ target: { files: [f], value: "" } });
    $("#restoreDraft").hidden = true;
  } catch {
    notify("Không đọc được bản nháp.");
  }
};
$("#fullscreen").onclick = () => {
  const el = $(".preview");
  if (document.fullscreenElement) document.exitFullscreen?.();
  else el.requestFullscreen?.().catch(() => notify("Trình duyệt không cho mở toàn màn hình."));
};
function downloadBlob(name, blob) {
  const url = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2e3);
}
function sortedVisuals() {
  return [...items].filter((i) => i.kind !== "audio").sort((a, b) => {
    if (a.kind === "text" && b.kind !== "text") return 1;
    if (b.kind === "text" && a.kind !== "text") return -1;
    return tracks.findIndex((t) => t.id === b.trackId) - tracks.findIndex((t) => t.id === a.trackId) || a.start-b.start;
  });
}
function textLines(g, text, max) {
  const out = [];
  for (const paragraph of text.split("\n")) {
    let line = "";
    for (const ch of paragraph) {
      if (g.measureText(line + ch).width > max && line) {
        out.push(line.trimEnd());
        line = "";
      }
      line += ch;
    }
    out.push(line);
  }
  return out;
}
function drawComposition(canvas) {
  prepareDissolveFrame();
  const g = canvas.getContext("2d"), w = canvas.width, h = canvas.height;
  g.save();
  g.fillStyle = "#090a0c";
  g.fillRect(0, 0, w, h);
  for (const i of sortedVisuals()) {
    if (!trackVisible(getTrack(i.trackId)) || !clipActive(i)) continue;
    const n = mediaNode(i), v = evaluateProps(i);
    g.save();
    if (i.kind === "text") {
      const anim = textEffect(i), font = i.fontSize * w / projectFrame.width;
      g.font = `${i.bold ? "750" : "400"} ${font}px ${i.fontFamily}`;
      if ("letterSpacing" in g) g.letterSpacing = i.letterSpacing * w / projectFrame.width + "px";
      const lines = textLines(g, animatedText(i), w * 0.95), lineHeight = font * 1.2, width = Math.max(0, ...lines.map((l) => g.measureText(l).width)), height = lines.length * lineHeight;
      g.globalAlpha = v.opacity * anim.opacity;
      g.translate(w * v.textX / 100, h * v.textY / 100 + height * anim.y / 100);
      g.rotate(v.rotation * Math.PI / 180);
      g.scale(v.scale, v.scale);
      if (i.textBg) {
        g.fillStyle = i.background;
        g.fillRect(-width / 2 - w * 8e-3, -height / 2 - w * 4e-3, width + w * 0.016, height + w * 8e-3);
      }
      g.textAlign = i.align;
      g.textBaseline = "middle";
      g.fillStyle = i.color;
      g.strokeStyle = i.outlineColor;
      g.lineJoin = "round";
      g.lineWidth = i.outline * w / projectFrame.width * 2;
      let x = i.align === "left" ? -width / 2 : i.align === "right" ? width / 2 : 0;
      lines.forEach((line, j) => {
        const y = -height / 2 + lineHeight * (j + 0.5);
        if (i.outline) g.strokeText(line, x, y);
        g.fillText(line, x, y);
      });
      g.restore();
      continue;
    }
    const sw = n.videoWidth || n.naturalWidth, sh = n.videoHeight || n.naturalHeight;
    if (!sw || !sh) {
      g.restore();
      continue;
    }
    const effect = transitionState(i);
    g.globalAlpha = v.opacity * effect.opacity;
    if (effect.clip !== "none") {
      const match = effect.clip.match(/inset\(([-\d.]+)%? ([-\d.]+)%? ([-\d.]+)%? ([-\d.]+)%?\)/);
      if (match) {
        g.beginPath();
        const [top,right,bottom,left]=match.slice(1).map(Number);
        g.rect(w*left/100,h*top/100,w*(1-left/100-right/100),h*(1-top/100-bottom/100));
        g.clip();
      }
    }
    g.translate(w / 2 + w * (v.x + effect.dx) / 100, h / 2 + h * (v.y + effect.dy) / 100);
    g.rotate(v.rotation * Math.PI / 180);
    g.scale(v.scale * (i.flipX ? -1 : 1), v.scale * (i.flipY ? -1 : 1));
    g.filter = visualFilter(i, w / 1080);
    const ratio = i.fit === "cover" ? Math.max(w / sw, h / sh) : Math.min(w / sw, h / sh);
    g.drawImage(n, -sw * ratio / 2, -sh * ratio / 2, sw * ratio, sh * ratio);
    g.restore();
  }
  g.restore();
}
async function settleMedia() {
  const waits = [];
  for (const i of items) {
    if (i.kind === "text") continue;
    const a = getAsset(i.assetId), n = mediaNode(i);
    if (!a?.url) throw Error("Thiếu tư liệu: " + i.name);
    if (i.kind === "image") {
      if (!n.complete) waits.push(n.decode());
    } else if (n.readyState < 2 || n.seeking) waits.push(new Promise((resolve, reject) => {
      const check = () => {
        if (n.readyState >= 2 && !n.seeking) {
          clearTimeout(timer);
          n.removeEventListener("loadeddata", check);
          n.removeEventListener("seeked", check);
          resolve();
        }
      };
      const timer = setTimeout(() => {
        n.removeEventListener("loadeddata", check);
        n.removeEventListener("seeked", check);
        reject(Error("Không đọc được tư liệu: " + i.name));
      }, 9e3);
      n.addEventListener("loadeddata", check);
      n.addEventListener("seeked", check);
      check();
    }));
  }
  await Promise.all(waits);
}
$("#captureFrame").onclick = async () => {
  try {
    pause();
    if (time >= total()) time = Math.max(0, total() - 0.05);
    updateStage(true);
    await settleMedia();
    const c = document.createElement("canvas");
    c.width=projectFrame.width;c.height=projectFrame.height;
    drawComposition(c);
    const blob = await new Promise((r) => c.toBlob(r, "image/png"));
    if (!blob) throw Error("Không tạo được ảnh");
    downloadBlob("sceneforge-frame-" + time.toFixed(2) + ".png", blob);
    notify(`Đã lưu khung hình ${c.width} × ${c.height}, gồm chữ và chỉnh màu.`);
  } catch (e) {
    notify(e.message);
  }
};
function refreshExportFormats() {
  const options = [["video/mp4;codecs=avc1.42E01E,mp4a.40.2", "MP4 · H.264 / AAC"], ["video/webm;codecs=vp9,opus", "WebM · VP9 / Opus"], ["video/webm;codecs=vp8,opus", "WebM · VP8 / Opus"]].filter(([mime]) => window.MediaRecorder?.isTypeSupported(mime));
  $("#exportFormat").innerHTML = options.map(([m, n]) => `<option value="${m}">${n}</option>`).join("");
  $("#realExport").disabled = !options.length;
  $("#codecHint").textContent = options.length ? "Chỉ hiển thị định dạng trình duyệt hỗ trợ. Tối đa 2 phút / lần xuất; 24 fps." : "Trình duyệt này thiếu bộ ghi video. Hãy dùng Chrome/Edge mới hoặc xuất bằng ứng dụng đầy đủ.";
}
const audioParameterLimits={audioGainDb:[-24,12],audioBass:[-18,18],audioMid:[-18,18],audioTreble:[-18,18],audioHighpass:[20,1000],audioLowpass:[1000,20000],audioPan:[-100,100],audioThreshold:[-60,0],audioRatio:[1,20]};
function makeAudioRoute(context,source){
 const highpass=context.createBiquadFilter(),lowpass=context.createBiquadFilter(),bass=context.createBiquadFilter(),mid=context.createBiquadFilter(),treble=context.createBiquadFilter(),compressor=context.createDynamicsCompressor(),pan=context.createStereoPanner(),gain=context.createGain();
 highpass.type='highpass';highpass.Q.value=.707;lowpass.type='lowpass';lowpass.Q.value=.707;bass.type='lowshelf';bass.frequency.value=200;mid.type='peaking';mid.frequency.value=1000;mid.Q.value=.8;treble.type='highshelf';treble.frequency.value=4000;compressor.knee.value=20;compressor.attack.value=.003;compressor.release.value=.25;
 source.connect(highpass);highpass.connect(lowpass);lowpass.connect(bass);bass.connect(mid);mid.connect(treble);treble.connect(compressor);compressor.connect(pan);pan.connect(gain);
 return{source,highpass,lowpass,bass,mid,treble,compressor,pan,gain};
}
function configureAudioRoute(route,i){
 const number=(key)=>clamp(Number.isFinite(i[key])?i[key]:extraDefaults()[key],...audioParameterLimits[key]);
 if(i.audioBypass){route.highpass.frequency.value=0;route.lowpass.frequency.value=route.source.context.sampleRate/2;route.bass.gain.value=0;route.mid.gain.value=0;route.treble.gain.value=0;route.pan.pan.value=0;route.compressor.ratio.value=1;return;}
 route.highpass.frequency.value=number('audioHighpass');route.lowpass.frequency.value=number('audioLowpass');route.bass.gain.value=number('audioBass');route.mid.gain.value=number('audioMid');route.treble.gain.value=number('audioTreble');route.pan.pan.value=number('audioPan')/100;route.compressor.threshold.value=number('audioThreshold');route.compressor.ratio.value=number('audioRatio');
}
function releaseAudioRoute(n){const route=audioSources.get(n);if(route){for(const node of Object.values(route))try{node.disconnect();}catch{}audioSources.delete(n);}}
function routeAudioVolume(i,n,active){
 if('preservesPitch'in n)n.preservesPitch=i.audioPreservePitch!==false;
 const route=audioSources.get(n);if(!route)return;configureAudioRoute(route,i);
 const t=getTrack(i.trackId),v=evaluateProps(i),elapsed=Math.max(0,time-i.start),remaining=Math.max(0,end(i)-time),fade=Math.min(1,i.fadeIn?elapsed/i.fadeIn:1,i.fadeOut?remaining/i.fadeOut:1);
 route.gain.gain.value=active&&trackVisible(t)&&!t.muted&&!i.audioMuted?clamp(v.volume*fade*transitionAudioGain(i),0,20)*Math.pow(10,(i.audioBypass?0:clamp(i.audioGainDb||0,-24,12))/20):0;
 n.volume=1;n.muted=false;
}
async function prepareExportAudio(){
 if(!items.some(i=>['video','audio'].includes(i.kind)))return [];
 exportAudioContext=exportAudioContext||new AudioContext();await exportAudioContext.resume();
 exportDestination=exportDestination||exportAudioContext.createMediaStreamDestination();
 for(const i of items){if(!['video','audio'].includes(i.kind))continue;const n=mediaNode(i);if(!getAsset(i.assetId)?.url)continue;if(!audioSources.has(n)){const route=makeAudioRoute(exportAudioContext,exportAudioContext.createMediaElementSource(n));route.gain.connect(exportAudioContext.destination);route.gain.connect(exportDestination);audioSources.set(n,route);}routeAudioVolume(i,n,clipActive(i));}
 return exportDestination.stream.getAudioTracks();
}
$("#realExport").onclick = async () => {
  if (recording) return;
  if (total() > 120) {
    notify("Bản ghi trình duyệt giới hạn 2 phút mỗi lần.");
    return;
  }
  if (!items.length) {
    notify("Timeline đang trống.");
    return;
  }
  let recorder, stream, previous = time;
  recording = true;
  exportCancelled = false;
  pause();
  $("#realExport").disabled = true;
  $("#closeExport").disabled = true;
  $("#startExport").disabled = true;
  $("#cancelExport").hidden = false;
  $("#exportProgress").value = 0;
  $("#exportStatus").textContent = "Đang chuẩn bị tư liệu…";
  try {
    time = 0;
    updateStage(true);
    await settleMedia();
    const c = document.createElement("canvas"), dims=frameDimensions(+$("#exportSize").value),width=dims.width;
    c.width = dims.width;
    c.height = dims.height;
    const audioTracks = await prepareExportAudio();
    drawComposition(c);
    stream = c.captureStream(24);
    const tracksForRecord = [...stream.getVideoTracks(), ...audioTracks];
    const mime = $("#exportFormat").value;
    if (!mime || !window.MediaRecorder) throw Error("Trình duyệt không hỗ trợ ghi video");
    recorder = new MediaRecorder(new MediaStream(tracksForRecord), { mimeType: mime, videoBitsPerSecond: width === 1080 ? 7e6 : 4e6, audioBitsPerSecond: 128e3 });
    const chunks = [], stopped = new Promise((resolve, reject) => {
      recorder.ondataavailable = (e) => {
        if (e.data.size) chunks.push(e.data);
      };
      recorder.onstop = resolve;
      recorder.onerror = (e) => reject(e.error || Error("Bộ ghi bị lỗi"));
    });
    recorder.start(250);
    playing = true;
    lastTick = performance.now();
    $("#play").textContent = "❚❚";
    updateStage(true);
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(tick);
    $("#exportStatus").textContent = "Đang ghi video thật… giữ cửa sổ ở phía trước.";
    await new Promise((resolve) => {
      const frame = () => {
        drawComposition(c);
        $("#exportProgress").value = Math.min(99, time / total() * 100);
        if (exportCancelled || !playing || time >= total()) {
          resolve();
          return;
        }
        requestAnimationFrame(frame);
      };
      frame();
    });
    if (recorder.state !== "inactive") recorder.stop();
    await stopped;
    if (exportCancelled) throw Error("Đã hủy xuất, không tải tệp.");
    if (time < total() - 0.1) throw Error("Xuất bị ngắt. Giữ tab Dựng video trong khi ghi.");
    let blob = new Blob(chunks, { type: mime.split(";")[0] });
    if (mime.startsWith("video/webm")) blob = await finalizeWebm(blob, total());
    if (blob.size < 1e3) throw Error("Bộ ghi không tạo được video");
    downloadBlob((($("#editorExportName")?.value||"sceneforge-"+Date.now()).replace(/[\\/:*?"<>|\x00-\x1f]/g,"-").replace(/\.(mp4|webm)$/i,"").trim()||"sceneforge") + (mime.startsWith("video/mp4") ? ".mp4" : ".webm"), blob);
    $("#exportProgress").value = 100;
    $("#exportStatus").textContent = "Đã tải video thật (" + (blob.size / 1024 / 1024).toFixed(2) + " MB). Không gửi dữ liệu lên máy chủ.";
  } catch (e) {
    $("#exportStatus").textContent = e.message || "Không xuất được video trên trình duyệt này.";
  } finally {
    if (recorder?.state !== "inactive") try {
      recorder?.stop();
    } catch {
    }
    stream?.getVideoTracks().forEach((t) => t.stop());
    pause();
    time = previous;
    updateStage(true);
    recording = false;
    $("#realExport").disabled = false;
    $("#closeExport").disabled = false;
    $("#startExport").disabled = false;
    $("#cancelExport").hidden = true;
  }
};
$("#cancelExport").onclick = () => {
  exportCancelled = true;
  pause();
};
document.addEventListener("visibilitychange", () => {
  if (recording && document.hidden) {
    exportCancelled = true;
    pause();
  }
});
$("#featureHelp").onclick = () => {
  $("#featuresContent").innerHTML = `<p><b>Đã có:</b> bố cục tư liệu/preview/inspector/timeline, menu Tệp/Chỉnh sửa/Hiển thị, xem nguồn riêng bằng bấm đúp, menu chuột phải, chiều cao từng track, filmstrip lấy mẫu từ video, waveform giải mã từ nguồn audio, thu phóng màn xem; video/ảnh/chữ/âm thanh nhiều track; tải lên tự có clip/lớp, nhấc clip lên khoảng trống tự tạo dòng mới, chế độ Chèn/Đổi chỗ/Ghi đè/Lớp riêng; Shift chọn nhiều, di chuyển/xóa/nhân đôi/tách hàng loạt; marker có tên/màu; phím ↑↓ nhảy điểm cắt; cắt, tách, nhân đôi, lấp khoảng trống; tốc độ; keyframe tuyến tính; chỉnh màu, lật, phóng/thu, xoay; kiểu chữ, viền, hiệu ứng vào; nhập/xuất SRT; nhãn dán dạng chữ; tách âm, volume, fade; chuyển cảnh qua đen/trượt/quét; ảnh PNG; lưu/mở JSON và bản nháp; xuất video thật bằng bộ ghi trình duyệt.</p><p><b>Giới hạn:</b> xuất theo thời gian thực, tối đa 2 phút, 24 fps; codec do trình duyệt quyết định. Giữ tab ở phía trước. Tư liệu từ máy cần nối lại sau khi mở dự án. Keyframe là nội suy tuyến tính; nhãn dán dùng ký tự/phông hệ thống.</p><p><b>Chưa có:</b> nhiều sequence độc lập, dock kéo thả tự do, bộ hiệu ứng Concat; tự tạo phụ đề từ giọng nói, TTS, tách nền/khử nhiễu AI, tracking/masking/chroma key, nhóm clip liên kết/compound clip, đảo ngược video, speed ramp, graph editor, cân màu bằng curves/LUT, proxy cho video nặng, kho nhạc/hiệu ứng bản quyền, mẫu CapCut, cộng tác, xuất nền bằng máy chủ, xuất MP4 trên mọi trình duyệt.</p>`;
  $("#featuresDialog").showModal();
};
$("#closeFeatures").onclick = () => $("#featuresDialog").close();
function drawKeyframeMarkers() {
  for (const i of items) {
    const el = $('[data-item="' + i.id + '"]');
    if (!el) continue;
    for (const k of i.keyframes || []) {
      if (k.at > i.duration) continue;
      const d = document.createElement("span");
      d.className = "keyframeDot";
      d.style.left = Math.min(i.duration * px - 8, k.at * px) + "px";
      d.textContent = "◆";
      el.append(d);
    }
  }
}
function splitItemKeyframes(i, n, offset) {
  if (!i.keyframes?.length) return;
  const middle = evaluateProps(i, i.start + offset), old = clone(i.keyframes);
  i.keyframes = [...old.filter((k) => k.at < offset), { at: offset, values: middle }];
  n.keyframes = [{ at: 0, values: middle }, ...old.filter((k) => k.at > offset).map((k) => ({ ...k, at: k.at - offset }))];
}
function retimeTrimmedKeyframes(i, old, delta) {
  if (!old.keyframes?.length) return;
  const atZero = evaluateProps(old, old.start + delta), atEnd = evaluateProps(old, old.start + delta + i.duration);
  i.keyframes = [{ at: 0, values: atZero }, ...old.keyframes.filter((k) => k.at > delta && k.at < delta + i.duration).map((k) => ({ ...k, at: k.at - delta })), { at: i.duration, values: atEnd }];
}
async function finalizeWebm(blob, seconds) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  function read(p2, id = false) {
    if (p2 >= bytes.length || !bytes[p2]) throw Error("WebM header không hợp lệ");
    let n = 1;
    while (n <= 8 && !(bytes[p2] & 1 << 8 - n)) n++;
    if (n > 8 || p2 + n > bytes.length) throw Error("WebM header bị thiếu");
    let value = bytes[p2] & (id ? 255 : (1 << 8 - n) - 1);
    for (let k = 1; k < n; k++) value = value * 256 + bytes[p2 + k];
    return { value, n, unknown: !id && bytes.slice(p2, p2 + n).every((b, k) => b === (k === 0 ? (1 << 9 - n) - 1 : 255)) };
  }
  function vint(n) {
    let count = 1;
    while (n >= 2 ** (7 * count) - 1) count++;
    const b = new Uint8Array(count);
    for (let k = count - 1; k >= 0; k--) {
      b[k] = n % 256;
      n = Math.floor(n / 256);
    }
    b[0] |= 1 << 8 - count;
    return b;
  }
  let p = 0, segment;
  while (p < bytes.length) {
    const id = read(p, true), size = read(p + id.n), data = p + id.n + size.n;
    if (id.value === 408125543) {
      segment = { p, size, data };
      break;
    }
    p = data + size.value;
  }
  if (!segment) throw Error("Không tìm thấy WebM Segment");
  p = segment.data;
  while (p < bytes.length) {
    const id = read(p, true), size = read(p + id.n), start = p + id.n + size.n;
    if (id.value === 357149030) {
      let scale = 1e6, q = start;
      while (q < start + size.value) {
        const cid = read(q, true), cs = read(q + cid.n), d = q + cid.n + cs.n;
        if (cid.value === 2807729) {
          scale = 0;
          for (let k = 0; k < cs.value; k++) scale = scale * 256 + bytes[d + k];
        }
        if (cid.value === 17545 && cs.value === 8) {
          new DataView(bytes.buffer).setFloat64(d, seconds * 1e9 / scale, false);
          return new Blob([bytes], { type: blob.type });
        }
        q = d + cs.value;
      }
      const duration = new Uint8Array(11);
      duration.set([68, 137, 136]);
      new DataView(duration.buffer).setFloat64(3, seconds * 1e9 / scale, false);
      const payload = [bytes.slice(start, start + size.value), duration], sizeBytes = vint(size.value + duration.length);
      if (!segment.size.unknown) throw Error("Bộ ghi WebM này cần bộ ghép tệp riêng");
      return new Blob([bytes.slice(0, p + id.n), sizeBytes, ...payload, bytes.slice(start + size.value)], { type: blob.type });
    }
    if (size.unknown) break;
    p = start + size.value;
  }
  throw Error("Không tìm thấy WebM Info");
}
let copiedSettings = null;
function copySettings() {
  if (!selected()) return;
  const i = selected();
  const keys = i.kind === "text" ? ["fontSize", "fontFamily", "color", "background", "textBg", "bold", "align", "outline", "outlineColor", "letterSpacing", "textAnimation", "animationDuration"] : ["look", "brightness", "contrast", "saturation", "blur", "flipX", "flipY", "scale", "rotation", "opacity", "x", "y", "fit", "volume", "fadeIn", "fadeOut", "transition", "transitionDuration"];
  copiedSettings = { kind: i.kind, values: Object.fromEntries(keys.map((k) => [k, i[k]])) };
  notify("Đã sao chép thuộc tính chỉnh sửa, không sao chép thời gian hay tư liệu.");
}
function pasteSettings() {
  if (!allowEdit() || !copiedSettings) return;
  const i = selected();
  if (i.kind === "text" !== (copiedSettings.kind === "text") || i.kind === "audio" !== (copiedSettings.kind === "audio")) {
    notify("Chọn mục cùng loại để dán thuộc tính.");
    return;
  }
  transact(() => Object.assign(i, clone(copiedSettings.values)));
  notify("Đã dán thuộc tính chỉnh sửa.");
}
const inspectorCommands = $("#inspector").onclick;
$("#inspector").onclick = (e) => {
  if (e.target.id === "copySettings") {
    copySettings();
    return;
  }
  if (e.target.id === "pasteSettings") {
    pasteSettings();
    return;
  }
  inspectorCommands(e);
};
// Batch selection operates on the same clip model and history as single edits.
function syncSelection(){selectedIds=new Set([...selectedIds].filter(id=>items.some(i=>i.id===id)));if(!selection){selectedIds.clear()}else if(!selectedIds.has(selection))selectedIds=new Set([selection]);updateSelectionSummary()}
function updateSelectionSummary(){const el=$('#selectionCount');if(el)el.textContent=selectedIds.size>1?selectedIds.size+' mục đang chọn · Esc bỏ chọn':''}
function batchMembers(){return items.filter(i=>selectedIds.has(i.id))}
function batchEditable(){const group=batchMembers();if(group.some(i=>getTrack(i.trackId).locked)){notify('Nhóm chọn có track đang khóa. Mở khóa trước khi sửa.');return null}return group}
function renderBatchInspector(){const group=batchMembers(),start=Math.min(...group.map(i=>i.start)),finish=Math.max(...group.map(end));$('#inspector').innerHTML=`<h3>${group.length} mục đang chọn</h3><p class="hint">Shift + bấm để thêm mục. Kéo một mục đang chọn để di chuyển cả nhóm, giữ nguyên khoảng cách và track. Esc bỏ chọn.</p><div class="pair"><div class="field"><label>Bắt đầu nhóm (s)</label><input id="batchStart" type="number" min="0" step="0.1" value="${start.toFixed(2)}"></div><div class="field"><label>Khoảng thời gian (s)</label><input readonly value="${(finish-start).toFixed(2)}"></div></div><div class="actions"><button id="applyBatchStart">Di chuyển nhóm</button><button id="isolateSelection">Chỉ chọn mục này</button></div><div class="sectionTitle">Âm lượng hàng loạt</div><div class="field"><label>Video / âm thanh đã chọn (%)</label><input id="batchVolume" type="number" min="0" max="2000" value="100"></div><button id="applyBatchVolume">Áp dụng âm lượng</button><p class="hint">Thay cả giá trị âm lượng trong keyframe của những mục đã chọn.</p><div class="sectionTitle">Thao tác hàng loạt</div><div class="actions"><button data-command="duplicate">Nhân đôi</button><button data-command="split">Tách tại vạch</button><button data-command="delete">Xóa</button></div><p class="hint">Đây là nhóm chọn tạm thời, chưa phải nhóm clip liên kết hoặc compound clip.</p>`}
function batchCommand(action){const group=batchEditable();if(!group?.length)return;pause();if(action==='split'){const eligible=group.filter(i=>time-i.start>=.2&&end(i)-time>=.2);if(!eligible.length){notify('Đưa vạch phát vào giữa một hoặc nhiều mục đang chọn.');return}transact(()=>{for(const i of eligible){const offset=time-i.start,n={...clone(i),id:uid(),start:time,duration:i.duration-offset,mediaIn:i.mediaIn+offset*i.speed,fadeIn:0};splitItemKeyframes(i,n,offset);i.duration=offset;i.fadeOut=0;i.transition='none';items.push(n);selectedIds.add(n.id)}});return}if(action==='duplicate'){const a=Math.min(...group.map(i=>i.start)),b=Math.max(...group.map(end)),span=b-a,trackSet=new Set(group.map(i=>i.trackId));if(items.some(i=>!selectedIds.has(i.id)&&trackSet.has(i.trackId)&&i.start<b&&end(i)>b)){notify('Có mục khác cắt ngang vị trí chèn. Tách mục đó trước khi nhân đôi nhóm.');return}transact(()=>{items.filter(i=>!selectedIds.has(i.id)&&trackSet.has(i.trackId)&&i.start>=b).forEach(i=>i.start+=span);const copies=group.map(i=>({...clone(i),id:uid(),start:i.start+span}));items.push(...copies);selection=copies[0].id;selectedIds=new Set(copies.map(i=>i.id))});return}if(action==='delete'){transact(()=>{const removed=new Set(group.map(i=>i.id));items=items.filter(i=>!removed.has(i.id));if(ripple){for(const t of tracks){const ranges=group.filter(i=>i.trackId===t.id).map(i=>[i.start,end(i)]).sort((a,b)=>a[0]-b[0]),union=[];for(const r of ranges){const prev=union[union.length-1];if(prev&&r[0]<=prev[1])prev[1]=Math.max(prev[1],r[1]);else union.push([...r])}for(const i of items.filter(i=>i.trackId===t.id))i.start-=union.filter(r=>r[1]<=i.start).reduce((sum,r)=>sum+r[1]-r[0],0)}}tracks=compactTimelineTracks(items,tracks);selection=null;selectedIds.clear()})}}
$('#inspector').addEventListener('click',e=>{if(e.target.id==='isolateSelection'){selectedIds=new Set([selection]);choose(selection);return}if(e.target.id==='applyBatchStart'){const group=batchEditable();if(!group?.length)return;const at=Number($('#batchStart').value);if(!Number.isFinite(at)||at<0||at>3600){notify('Thời điểm nhóm phải nằm trong 0–3600 giây.');return}const delta=at-Math.min(...group.map(i=>i.start));if(group.some(i=>i.start+delta>3600)){notify('Di chuyển này đưa một mục quá mốc 3600 giây.');return}const plan=planGroupMove(items,tracks,group.map(i=>i.id),delta,timelineEditMode,uid());if(!plan.valid){notify(plan.reason);return}transact(()=>{items=plan.items;tracks=plan.tracks;})}if(e.target.id==='applyBatchVolume'){const group=batchEditable();if(!group)return;const volume=clamp(Number($('#batchVolume').value)/100,0,20);transact(()=>group.filter(i=>['audio','video'].includes(i.kind)).forEach(i=>{i.volume=volume;(i.keyframes||[]).forEach(k=>k.values.volume=volume)}))}});
function validateMarkers(raw){if(!Array.isArray(raw))return[];return raw.slice(0,300).filter(m=>m&&typeof m.id==='string'&&/^[\w-]+$/.test(m.id)&&Number.isFinite(m.at)&&m.at>=0&&m.at<=3600).map(m=>({id:m.id,at:m.at,label:String(m.label||'Mốc').slice(0,100),color:/^#[0-9a-f]{6}$/i.test(m.color)?m.color:'#f7c77e'}))}
function drawMarkers(){$$('#ruler .timelineMarker').forEach(n=>n.remove());for(const m of markers){const b=document.createElement('button');b.className='timelineMarker';b.style.left=m.at*px+'px';b.style.color=m.color;b.textContent='⚑';b.title=m.label+' · '+fmt(m.at);b.dataset.marker=m.id;b.onpointerdown=e=>e.stopPropagation();b.onclick=e=>{e.stopPropagation();pause();time=m.at;updateStage(true);openMarkerDialog(m)};$('#ruler').append(b)}}
let editingMarker=null;
const markerDialog=document.createElement('dialog');markerDialog.id='markerDialog';markerDialog.innerHTML='<h2>Mốc timeline</h2><div class="field"><label for="markerLabel">Tên mốc</label><input id="markerLabel" maxlength="100"></div><div class="pair"><div class="field"><label for="markerAt">Thời điểm (s)</label><input id="markerAt" type="number" min="0" max="3600" step="0.01"></div><div class="field"><label for="markerColor">Màu</label><input id="markerColor" type="color" value="#f7c77e"></div></div><div class="actions"><button id="saveMarker" class="primary">Lưu mốc</button><button id="deleteMarker">Xóa</button><button id="closeMarker">Đóng</button></div>';document.body.append(markerDialog);
function openMarkerDialog(marker=null){editingMarker=marker?.id||null;$('#markerLabel').value=marker?.label||'Mốc '+(markers.length+1);$('#markerAt').value=(marker?.at??time).toFixed(2);$('#markerColor').value=marker?.color||'#f7c77e';$('#deleteMarker').hidden=!marker;markerDialog.showModal();$('#markerLabel').select()}
$('#addMarker').onclick=()=>{pause();openMarkerDialog()};$('#closeMarker').onclick=()=>markerDialog.close();$('#saveMarker').onclick=()=>{const at=Number($('#markerAt').value),label=$('#markerLabel').value.trim();if(!label||!Number.isFinite(at)||at<0||at>3600){notify('Nhập tên và thời điểm mốc trong 0–3600 giây.');return}transact(()=>{const values={at,label,color:$('#markerColor').value};const m=markers.find(m=>m.id===editingMarker);if(m)Object.assign(m,values);else markers.push({id:uid(),...values})});markerDialog.close()};$('#deleteMarker').onclick=()=>{transact(()=>markers=markers.filter(m=>m.id!==editingMarker));markerDialog.close()};
function jumpCut(direction){pause();const points=[0,...items.flatMap(i=>[i.start,end(i)])].sort((a,b)=>a-b);time=direction>0?(points.find(p=>p>time+.03)??total()):([...points].reverse().find(p=>p<time-.03)??0);updateStage(true)}
document.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)||$('dialog[open]')||e.target.closest('#workstationPopup'))return;const mod=e.ctrlKey||e.metaKey;if(mod&&e.key.toLowerCase()==='a'){e.preventDefault();e.stopImmediatePropagation();selectedIds=new Set(items.map(i=>i.id));selection=items[0]?.id||null;timeline();inspector();updateSelectionSummary()}else if(mod&&e.key.toLowerCase()==='d'){e.preventDefault();e.stopImmediatePropagation();commands.duplicate()}else if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();choose(null)}else if(e.key.toLowerCase()==='m'&&!mod){e.preventDefault();e.stopImmediatePropagation();$('#addMarker').click()}else if(e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();e.stopImmediatePropagation();jumpCut(e.key==='ArrowDown'?1:-1)}},true);
