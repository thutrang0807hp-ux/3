"""Verify layout changes and presets edit actual project data."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright

os.chdir(Path(__file__).resolve().parents[2])
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1600, 'height':1000})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.route('http://demo.test/**', lambda r: r.fulfill(content_type='text/html', body=Path('concat-demo.html').read_text()))
    page.goto('http://demo.test/')
    state = lambda: page.evaluate('SceneForgeEditor.getState()')
    original = state()['items']
    page.locator('[data-library="effects"]').click()
    page.locator('[data-motion-preset="zoom"]').click()
    video = next(i for i in state()['items'] if i['id']==original[0]['id'])
    assert video['keyframes'][-1]['values']['scale'] > video['keyframes'][0]['values']['scale']
    page.evaluate('SceneForgeEditor.seek(2)')
    # Keyframes visibly affect the preview transform, not just a stored label.
    assert '1.075' in page.locator('#stageLayers .visualLayer').first.evaluate('(e)=>e.style.transform')
    page.locator('#undo').click()
    assert state()['items'] == original
    page.locator('[data-library="templates"]').click()
    page.locator('[data-story-template="cta"]').click()
    assert len(state()['items']) == len(original)+1
    assert any(i.get('text')=='HẸN GẶP Ở VIDEO TIẾP THEO' for i in state()['items'])
    page.locator('#undo').click()
    assert state()['items']==original  # one undo for the complete template action
    page.locator('#swapPanels').click()
    assert page.locator('#mediaPanel').bounding_box()['x'] > page.locator('#inspectorPanel').bounding_box()['x']
    handle=page.locator('#mediaPanel>[data-resize]').bounding_box()
    page.mouse.move(handle['x']+handle['width']/2, handle['y']+70)
    page.mouse.down()
    page.mouse.move(handle['x']-20, handle['y']+70, steps=4)
    page.mouse.up()
    assert page.locator('#mediaPanel').bounding_box()['width'] > 390
    assert state()['items'] == original
    page.reload()
    assert page.locator('body').get_attribute('data-panel-order')=='right'
    assert page.locator('#mediaPanel').bounding_box()['width'] > 390
    page.locator('#swapPanels').click()
    page.locator('#prototypeProgressButton').click()
    assert page.locator('#prototypeProgress .done').count()==24
    assert page.locator('#prototypeProgress .pending').count()==8
    page.screenshot(path='/tmp/sceneforge-progress-checklist.png')
    page.locator('#closePrototypeProgress').click()
    page.locator('[data-library="effects"]').click()
    page.wait_for_function("document.querySelector('.clipArtwork[data-ready=waveform]')", timeout=30000)
    page.wait_for_timeout(3100)
    page.screenshot(path='/tmp/sceneforge-concat-panels-v2.png')
    assert not errors, errors
    print('PASS: motion preset affects preview; template adds editable text with one-step undo; panel swap/resizing/preferences; checklist counts. No JS errors.')
    browser.close()
