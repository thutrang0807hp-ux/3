// Placement and collision planning for timeline edits. Plans always start from
// the pointer-down snapshot, so dragging back and forth never accumulates edits.
let timelineEditMode='insert';
const editModeNames={insert:'Chèn',swap:'Đổi chỗ',overwrite:'Ghi đè',layer:'Lớp riêng'};
function sameLaneItems(list,trackId,exclude=new Set()){return list.filter(i=>i.trackId===trackId&&!exclude.has(i.id)).sort((a,b)=>a.start-b.start)}
function intervalsOverlap(a,b){return a.start<end(b)-.00001&&b.start<end(a)-.00001}
function trackIsLinear(list,trackId){const row=sameLaneItems(list,trackId);return row.every((i,n)=>!n||i.start>=end(row[n-1])-.00001)}
function makeMediaTrack(kind,list=tracks,id=uid()){const type=kind==='image'?'video':kind;return{id,kind:type,name:({video:'Video',audio:'Âm thanh',text:'Văn bản'})[type]+' '+(list.filter(t=>t.kind===type).length+1)}}
function addTrackInFront(track,list){const index=list.findIndex(t=>t.kind===track.kind);list.splice(index<0?list.length:index,0,track)}
function sliceTimelineItem(source,start,finish,id=source.id){const piece=clone(source),offset=start-source.start;piece.id=id;piece.start=start;piece.duration=finish-start;piece.mediaIn=source.mediaIn+offset*source.speed;piece.fadeIn=Math.min(piece.fadeIn,piece.duration);piece.fadeOut=Math.min(piece.fadeOut,piece.duration);if(finish<end(source)-.00001)piece.transition='none';retimeTrimmedKeyframes(piece,source,offset);piece.transitionDuration=Math.min(piece.transitionDuration,piece.duration);return piece}
function insertionBoundary(list,trackId,desired,pointerTime=desired){const row=sameLaneItems(list,trackId),hit=row.find(i=>pointerTime>=i.start&&pointerTime<end(i))||row.find(i=>desired>i.start&&desired<end(i));if(!hit)return{at:Math.max(0,desired),anchor:null};const after=pointerTime>=hit.start+hit.duration/2;return{at:after?end(hit):hit.start,anchor:hit.id,after}}
// Video rows use order slots, never an arbitrary empty time under the pointer.
// Only affected picture rows are packed; unrelated music/text retain absolute timing.
function magneticSlot(row,pointerTime){const n=row.findIndex(i=>pointerTime<i.start+i.duration/2);return n<0?row.length:n;}
function planMagneticVideoMove(baseline,baseTracks,ids,targetTrackId,pointerTime){
 const selected=new Set(ids),members=baseline.filter(i=>selected.has(i.id)),pictures=members.filter(i=>['video','image'].includes(i.kind));
 if(!pictures.length||new Set(pictures.map(i=>i.trackId)).size!==1)return null;
 const sourceId=pictures[0].trackId,target=baseTracks.find(t=>t.id===targetTrackId);
 if(!target||target.kind!=='video'||members.some(i=>!['video','image'].includes(i.kind)&&!pictures.some(v=>v.linkGroup&&v.linkGroup===i.linkGroup)))return null;
 if(target.locked||baseTracks.find(t=>t.id===sourceId)?.locked)return{valid:false,reason:'Mở khóa hàng trước khi di chuyển clip.'};
 if(!trackIsLinear(baseline,sourceId)||!trackIsLinear(baseline,target.id))return{valid:false,reason:'Hàng có clip chồng sẵn. Tách chúng sang hàng riêng trước.'};
 const out=clone(baseline),originals=new Map(baseline.map(i=>[i.id,i])),byId=new Map(out.map(i=>[i.id,i])),pictureIds=new Set(pictures.map(i=>i.id));
 const rest=sameLaneItems(baseline,target.id,pictureIds),slot=magneticSlot(rest,pointerTime);
 const moving=pictures.slice().sort((a,b)=>a.start-b.start),ordered=[...rest.slice(0,slot),...moving,...rest.slice(slot)];
 function pack(row,trackId,anchor){let at=anchor;for(const old of row){const item=byId.get(old.id);item.trackId=trackId;item.start=at;at=end(item);}}
 const targetRow=sameLaneItems(baseline,target.id),targetAnchor=targetRow.length?targetRow[0].start:0;
 if(sourceId!==target.id){const sourceRow=sameLaneItems(baseline,sourceId);pack(sourceRow.filter(i=>!pictureIds.has(i.id)),sourceId,sourceRow[0]?.start||0);}
 pack(ordered,target.id,targetAnchor);
 // Extracted dialogue follows its own picture, including neighbors displaced by insertion.
 const offsets=new Map();for(const old of baseline){if(!['video','image'].includes(old.kind)||!old.linkGroup)continue;const delta=byId.get(old.id).start-old.start;if(offsets.has(old.linkGroup)&&Math.abs(offsets.get(old.linkGroup)-delta)>.001)return{valid:false,reason:'Nhóm hình–tiếng không thể đổi thứ tự cùng nhau. Bỏ liên kết trước.'};offsets.set(old.linkGroup,delta);}
 for(const old of baseline){if(['video','image'].includes(old.kind)||!old.linkGroup||!offsets.has(old.linkGroup))continue;const item=byId.get(old.id);item.start=old.start+offsets.get(old.linkGroup);}
 const changed=out.filter(i=>{const old=originals.get(i.id);return Math.abs(old.start-i.start)>.00001||old.trackId!==i.trackId;});
 if(changed.some(i=>i.start<0||end(i)>3600||baseTracks.find(t=>t.id===i.trackId)?.locked))return{valid:false,reason:'Không thể di chuyển: hàng liên kết đang khóa hoặc vượt thời lượng.'};
 for(const rowId of new Set(changed.map(i=>i.trackId))){if(trackIsLinear(baseline,rowId)&&!trackIsLinear(out,rowId))return{valid:false,reason:'Âm thanh liên kết sẽ đè clip khác. Tách âm thanh sang hàng riêng trước.'};}
 return{valid:true,items:out,tracks:clone(baseTracks),guide:byId.get(moving[0].id).start,description:'Đổi thứ tự · tự khít clip, không ghi đè'};
}
function overwriteInterval(list,moving,token){const out=[];for(const other of list){if(other.trackId!==moving.trackId||!intervalsOverlap(other,moving)){out.push(other);continue}if(other.start<moving.start-.00001){out.push(sliceTimelineItem(other,other.start,moving.start));}if(end(other)>end(moving)+.00001){out.push(sliceTimelineItem(other,end(moving),end(other),other.start<moving.start-.00001?'piece_'+token+'_'+other.id:other.id));}}return out}
function planSingleMove(baseline,baseTracks,id,targetTrackId,desired,pointerTime,mode,layerId,magnetic=true){const next=clone(baseline),nextTracks=clone(baseTracks),moving=next.find(i=>i.id===id),original=baseline.find(i=>i.id===id),target=nextTracks.find(t=>t.id===targetTrackId);if(!moving||!target||target.locked||!compatible(moving.kind,target))return{valid:false,reason:'Track không phù hợp hoặc đang khóa.'};desired=clamp(desired,0,3600);const excluded=new Set([id]);let others=next.filter(i=>i.id!==id),guide=desired,description=editModeNames[mode];if(mode==='layer'){const layer=makeMediaTrack(moving.kind,nextTracks,layerId);addTrackInFront(layer,nextTracks);moving.trackId=layer.id;moving.start=desired;return{valid:true,items:[...others,moving],tracks:nextTracks,guide:desired,description:'Tạo '+layer.name+' · không che clip trên cùng track'}}
if(mode==='swap'){if(target.id!==original.trackId)return{valid:false,reason:'Đổi chỗ áp dụng cho hai clip cùng track.'};const row=sameLaneItems(baseline,target.id),hit=row.find(i=>i.id!==id&&pointerTime>=i.start&&pointerTime<end(i));if(!hit)return{valid:false,reason:'Thả vào clip muốn đổi chỗ.'};if(!trackIsLinear(baseline,target.id))return{valid:false,reason:'Track hiện có clip chồng nhau. Tách lớp trước khi đổi chỗ.'};const a=row.findIndex(i=>i.id===id),b=row.findIndex(i=>i.id===hit.id),lo=Math.min(a,b),hi=Math.max(a,b),ordered=clone(row.slice(lo,hi+1));[ordered[0],ordered[ordered.length-1]]=[ordered[ordered.length-1],ordered[0]];let at=row[lo].start;const replacements=new Map();for(const item of ordered){item.start=at;at=end(item);replacements.set(item.id,item)}return{valid:true,items:next.map(i=>replacements.get(i.id)||i),tracks:nextTracks,guide:replacements.get(id).start,description:'Đổi chỗ với '+hit.name}}
if(mode==='overwrite'){moving.trackId=target.id;moving.start=desired;others=overwriteInterval(others,moving,layerId);return{valid:true,items:[...others,moving],tracks:nextTracks,guide:desired,description:'Ghi đè · cắt phần clip bị phủ'}}
if(magnetic){const plan=planMagneticVideoMove(baseline,baseTracks,[id],targetTrackId,pointerTime);if(plan)return plan;}
// Insert removes the source interval and inserts at a target edge; no media is destroyed.
if(!trackIsLinear(baseline,target.id)||!trackIsLinear(baseline,original.trackId))return{valid:false,reason:'Track có clip chồng sẵn. Dùng Lớp riêng để tách chúng trước.'};const rawBoundary=insertionBoundary(baseline.filter(i=>i.id!==id),target.id,desired,pointerTime);if(trackIsLinear(baseline,original.trackId)){for(const i of others)if(i.trackId===original.trackId&&i.start>=end(original)-.00001)i.start=Math.max(0,i.start-original.duration)}let at=rawBoundary.at;if(rawBoundary.anchor){const anchor=others.find(i=>i.id===rawBoundary.anchor);at=rawBoundary.after?end(anchor):anchor.start}const boundary=insertionBoundary(others,target.id,at,at);at=boundary.at;moving.trackId=target.id;moving.start=at;for(const i of others)if(i.trackId===target.id&&i.start>=at-.00001)i.start+=moving.duration;return{valid:true,items:[...others,moving],tracks:nextTracks,guide:at,description:'Chèn · các clip phía sau nhường chỗ'};}
function planGroupMove(baseline,baseTracks,ids,delta,mode,token,targetTrackId=null,sourceTrackId=null,pointerTime=null){const excluded=new Set(ids),members=baseline.filter(i=>excluded.has(i.id)),others=clone(baseline.filter(i=>!excluded.has(i.id))),nextTracks=clone(baseTracks),moved=members.map(i=>({...clone(i),start:i.start+delta}));if(targetTrackId&&targetTrackId!==(sourceTrackId||members[0]?.trackId)&&mode!=='layer'){
 const target=baseTracks.find(t=>t.id===targetTrackId);
 if(new Set(members.map(i=>i.trackId)).size!==1)return{valid:false,reason:'Nhóm nhiều hàng: kéo vào khoảng trống để tạo các hàng mới.'};
 if(!target||target.locked||members.some(i=>!compatible(i.kind,target)))return{valid:false,reason:'Hàng đích không phù hợp hoặc đang khóa.'};
 moved.forEach(i=>i.trackId=target.id);
}
if(mode==='insert'){const magnetic=planMagneticVideoMove(baseline,baseTracks,ids,targetTrackId||members[0]?.trackId,pointerTime??Math.min(...moved.map(i=>i.start)));if(magnetic)return magnetic;}if(mode==='swap')return{valid:false,reason:'Chỉ chọn một clip để đổi chỗ.'};if(mode==='layer'){for(const trackId of new Set(members.map(i=>i.trackId))){const source=baseTracks.find(t=>t.id===trackId),newTrack=makeMediaTrack(source.kind,nextTracks,'group_'+token+'_'+trackId);addTrackInFront(newTrack,nextTracks);moved.filter(i=>i.trackId===trackId).forEach(i=>i.trackId=newTrack.id)}return{valid:true,items:[...others,...moved],tracks:nextTracks,guide:Math.min(...moved.map(i=>i.start)),description:'Đưa nhóm chọn sang lớp riêng'}}if(mode==='overwrite'){let remaining=others;for(const item of moved)remaining=overwriteInterval(remaining,item,token);return{valid:true,items:[...remaining,...moved],tracks:nextTracks,guide:Math.min(...moved.map(i=>i.start)),description:'Ghi đè theo từng mục trong nhóm'}}for(const trackId of new Set(moved.map(i=>i.trackId))){if(!trackIsLinear(baseline,trackId))return{valid:false,reason:'Track có clip chồng sẵn. Chọn Lớp riêng trước.'};const row=moved.filter(i=>i.trackId===trackId).sort((a,b)=>a.start-b.start),rest=others.filter(i=>i.trackId===trackId).sort((a,b)=>a.start-b.start);let previousEnd=0;for(const other of rest){other.start=Math.max(other.start,previousEnd);let collision;while((collision=row.find(i=>intervalsOverlap(other,i))))other.start=end(collision);previousEnd=end(other)}}return{valid:true,items:[...others,...moved],tracks:nextTracks,guide:Math.min(...moved.map(i=>i.start)),description:'Di chuyển nhóm · giữ khoảng cách, đẩy clip vướng sang phải'}}
function planTrim(baseline,baseTracks,id,edge,delta){const out=clone(baseline),i=out.find(x=>x.id===id),old=baseline.find(x=>x.id===id),row=sameLaneItems(baseline,i.trackId,new Set([id]));if(edge==='left'){const prev=Math.max(0,...row.filter(x=>end(x)<=old.start+.00001).map(end));let min=Math.max(-old.start,prev-old.start);if(!['text','image'].includes(i.kind))min=Math.max(min,-old.mediaIn/old.speed);delta=clamp(delta,min,old.duration-.2);i.start=old.start+delta;i.duration=old.duration-delta;i.mediaIn=old.mediaIn+delta*old.speed}else{let max=3600;if(!['text','image'].includes(i.kind))max=(getAsset(i.assetId).duration-old.mediaIn)/old.speed;const nextStart=Math.min(Infinity,...row.filter(x=>x.start>=end(old)-.00001).map(x=>x.start));if(timelineEditMode!=='insert')max=Math.min(max,nextStart-old.start);i.duration=clamp(old.duration+delta,.2,max);if(timelineEditMode==='insert'){const shift=i.duration-old.duration;for(const other of out)if(other.id!==id&&other.trackId===i.trackId&&other.start>=end(old)-.00001)other.start+=shift}}if(row.some(x=>intervalsOverlap(x,i))&&!(edge==='right'&&timelineEditMode==='insert'))return{valid:false,reason:'Mép clip đã chạm clip bên cạnh.'};retimeTrimmedKeyframes(i,old,i.start-old.start);i.fadeIn=Math.min(i.fadeIn,i.duration);i.fadeOut=Math.min(i.fadeOut,i.duration);i.transitionDuration=Math.min(i.transitionDuration,i.duration);return{valid:true,items:out,tracks:clone(baseTracks),guide:edge==='left'?i.start:end(i),description:edge==='right'&&timelineEditMode==='insert'?'Cắt mép · kéo theo các clip phía sau':'Cắt mép · không chồng clip'}}
// During a gesture, only a compositor ghost follows the pointer. The project model
// and captured DOM stay untouched until the single commit on pointer-up.
let activeClipDrag=null;
function compactTimelineTracks(list,rows){
 const occupied=new Set(list.map(i=>i.trackId)),used=rows.filter(t=>occupied.has(t.id));
 return used.length?used:[rows.find(t=>t.kind==='video')||makeMediaTrack('video',rows)];
}
function beginClipDrag(ids,baseline,x,y,trim=false){
 endClipDrag();const overlay=document.createElement('div');overlay.id='clipDragOverlay';overlay.inert=true;overlay.setAttribute('aria-hidden','true');
 const nodes=new Map(),source=new Map(baseline.map(i=>[i.id,i])),ghosts=[];
 // Read all geometry before writing any preview styles.
 for(const el of $$('#tracks .timelineItem')){const original=source.get(el.dataset.item);if(!original)continue;
  const rect=ids.has(original.id)?el.getBoundingClientRect():null;nodes.set(original.id,{el,original,rect,opacity:el.style.opacity||'1'});
 }
 for(const [id,entry]of nodes)if(ids.has(id)){
  const clone=entry.el.cloneNode(true);clone.removeAttribute('data-item');clone.removeAttribute('tabindex');clone.removeAttribute('role');clone.dataset.dragGhost=id;clone.classList.add('clipDragGhost');
  for(const [index,canvas]of [...clone.querySelectorAll('canvas')].entries()){const old=entry.el.querySelectorAll('canvas')[index];if(old)canvas.getContext('2d').drawImage(old,0,0);}
  const r=entry.rect;Object.assign(clone.style,{position:'fixed',left:'0px',top:'0px',width:r.width+'px',height:r.height+'px',margin:'0',opacity:'.94',transform:'translate3d('+r.left+'px,'+r.top+'px,0)',zIndex:'1',pointerEvents:'none'});
  overlay.append(clone);ghosts.push({el:clone,rect:r,id});
 }
 document.body.append(overlay);activeClipDrag={ids,source,nodes,ghosts,overlay,x,y,trim,pointer:{clientX:x,clientY:y},sequenceTop:0};
 for(const id of ids){const entry=nodes.get(id);if(entry){entry.el.style.opacity='.18';entry.el.style.pointerEvents='none';}}
 document.body.classList.add('timeline-drag-active');
}
function endClipDrag(){if(activeClipDrag){for(const {el,opacity}of activeClipDrag.nodes.values()){el.style.transform='';el.style.transformOrigin='';el.style.opacity=opacity;el.style.pointerEvents='';}activeClipDrag.overlay.remove();activeClipDrag=null;}document.body.classList.remove('timeline-drag-active');}
function paintDragPlan(plan,selected,baseline){
 const ctx=activeClipDrag;if(!ctx)return;
 const byId=plan.valid?new Map(plan.items.map(i=>[i.id,i])):ctx.source;
 for(const {el,original,opacity}of ctx.nodes.values()){
  if(selected.has(original.id))continue;const item=byId.get(original.id);
  const changed=item&&(item.start!==original.start||item.duration!==original.duration);const transform=changed?'translate3d('+((item.start-original.start)*px)+'px,0,0) scaleX('+(item.duration/original.duration)+')':'';
  if(el.style.transform!==transform){el.style.transformOrigin='left center';el.style.transform=transform;}
  const nextOpacity=item?opacity:'.12';if(el.style.opacity!==nextOpacity)el.style.opacity=nextOpacity;
 }
 const dx=ctx.pointer.clientX-ctx.x,dy=ctx.pointer.clientY-ctx.y;
 for(const ghost of ctx.ghosts){const planned=byId.get(ghost.id),r=ghost.rect;
  // The held clip is never clamped to an insertion boundary; only the drop guide snaps.
  const gx=ctx.trim&&planned?r.left+(planned.start-ctx.source.get(ghost.id).start)*px:r.left+dx;
  const gy=ctx.trim?r.top:r.top+dy;
  ghost.el.style.transform='translate3d('+gx+'px,'+gy+'px,0)';
  if(ctx.trim&&planned)ghost.el.style.width=Math.max(6,planned.duration*px)+'px';
  ghost.el.classList.toggle('invalid',!plan.valid);
 }
 if(!plan.valid){$('#newTrackIndicator')?.remove();showDropGuide(ctx.desired,plan.reason,true);return;}
 showDropGuide(plan.guide,plan.description);paintNewTrackBoundary(plan);
}
function showDropGuide(at,label,invalid=false){let el=$('#dropGuide');if(!el){el=document.createElement('div');el.id='dropGuide';el.innerHTML='<span></span>';$('#sequence').append(el)}el.hidden=false;el.classList.toggle('invalid',invalid);el.style.left='0px';el.style.transform='translate3d('+(timelineHeaderWidth+(at??time)*px)+'px,0,0)';el.querySelector('span').textContent=label;}
function hideDropGuide(){$('#dropGuide')?.remove();$('#newTrackIndicator')?.remove()}
function insertNewAsset(asset,trackId=null,at=null,ownLayer=false,atTrackEnd=false){activeClipDrag?.cancel?.();const original=getTrack(trackId);if(original&&(original.locked||!compatible(asset.kind,original))){notify('Chọn track đúng loại và mở khóa trước khi thêm.');return}transact(()=>{let target=original;if(ownLayer){target=makeMediaTrack(asset.kind);if(atTrackEnd)tracks.push(target);else addTrackInFront(target,tracks)}else target=target||findTrack(asset.kind);let start=at===null?Math.max(0,...items.filter(i=>i.trackId===target.id).map(end)):Math.max(0,at),duration=asset.sampleDuration||asset.duration||5;const item={...defaults(asset.kind),id:uid(),kind:asset.kind,assetId:asset.id,trackId:target.id,name:asset.name,start,duration,mediaIn:asset.sourceIn||0};if(at!==null&&!ownLayer){if(timelineEditMode==='layer'){target=makeMediaTrack(asset.kind);addTrackInFront(target,tracks);item.trackId=target.id}else if(timelineEditMode==='overwrite'){items=overwriteInterval(items,item,uid())}else{const point=insertionBoundary(items,target.id,start,at);item.start=point.at;for(const i of items)if(i.trackId===target.id&&i.start>=item.start-.00001)i.start+=item.duration}}items.push(item);tracks=compactTimelineTracks(items,tracks);selection=item.id;selectedIds=new Set([item.id]);time=item.start;pause()});notify(ownLayer?'Đã tạo lớp riêng và đưa video lên timeline.':'Đã thêm clip vào timeline, không chồng lên clip khác.');}
function autoPlaceImported(asset){const mode=$('#importPlacement')?.value||'layer';if(mode==='library'){scheduleDraft();return}insertNewAsset(asset,null,null,mode==='layer');}
$('#timelineEditMode').onchange=e=>{timelineEditMode=e.target.value;$('#timelineEditMode').title={insert:'Chèn: đẩy các clip phía sau, không làm mất nội dung.',swap:'Đổi vị trí hai clip trên cùng track.',overwrite:'Cắt phần clip đang bị phủ. Có thể hoàn tác.',layer:'Tạo lớp mới để hai clip cùng tồn tại.'}[timelineEditMode];notify(editModeNames[timelineEditMode]+' · '+$('#timelineEditMode').title)};

async function mediaPoster(video,duration){try{await new Promise(resolve=>{const done=()=>{clearTimeout(timer);video.removeEventListener('seeked',done);resolve()};const timer=setTimeout(done,1500);video.addEventListener('seeked',done);video.currentTime=Math.min(.08,duration/2)});if(video.readyState<2||!video.videoWidth)return null;const canvas=document.createElement('canvas');canvas.width=360;canvas.height=640;const ratio=Math.max(360/video.videoWidth,640/video.videoHeight);canvas.getContext('2d').drawImage(video,(360-video.videoWidth*ratio)/2,(640-video.videoHeight*ratio)/2,video.videoWidth*ratio,video.videoHeight*ratio);return canvas.toDataURL('image/jpeg',.65)}catch{return null}}

function applyNumericPlacement(i,key,value){if(Math.abs(i[key]-value)<.00001)return;const plan=key==='start'?planSingleMove(items,tracks,i.id,i.trackId,value,value,timelineEditMode,uid(),false):planTrim(items,tracks,i.id,'right',value-i.duration);if(!plan.valid){notify(plan.reason);inspector();return}transact(()=>{items=plan.items;tracks=plan.tracks;});}
function repairTimingChange(i,old){const row=items.filter(x=>x.id!==i.id&&x.trackId===i.trackId);if(timelineEditMode==='insert'){const diff=i.duration-old.duration;for(const n of row)if(n.start>=end(old)-.00001)n.start=Math.max(0,n.start+diff);}else{const next=Math.min(Infinity,...row.filter(x=>x.start>=end(old)-.00001).map(x=>x.start));i.duration=Math.max(.2,Math.min(i.duration,next-i.start));}}
// Lifting a clip into a row gap creates a track at that gap, independently of
// the current horizontal edit mode. Geometry is read from existing rows only.
function locateTrackBoundary(clientX,clientY){const viewport=$('#timelineScroll').getBoundingClientRect(),ruler=$('#ruler').getBoundingClientRect();if(clientX<ruler.left-5||clientX>viewport.right||clientY<ruler.bottom-2||clientY>viewport.bottom)return null;const rows=$$('#tracks>.trackRow');if(!rows.length)return null;const first=rows[0].getBoundingClientRect();if(clientY>=ruler.bottom-2&&clientY<=first.top+5)return{index:0,y:first.top-9};for(let n=0;n<rows.length-1;n++){const a=rows[n].getBoundingClientRect(),b=rows[n+1].getBoundingClientRect();if(clientY>=a.bottom-5&&clientY<=b.top+5)return{index:n+1,y:(a.bottom+b.top)/2}}const last=rows[rows.length-1].getBoundingClientRect();if(clientY>=last.bottom-5&&clientY<=last.bottom+16)return{index:rows.length,y:last.bottom+8};return null}
function placePlannedTracksAtBoundary(plan,baseTracks,boundary){if(!plan.valid)return plan;const previous=new Set(baseTracks.map(t=>t.id)),added=plan.tracks.filter(t=>!previous.has(t.id)),existing=plan.tracks.filter(t=>previous.has(t.id));existing.splice(Math.min(boundary.index,existing.length),0,...added);plan.tracks=existing;plan.newTrackBoundary=boundary;plan.description='Thả để tạo '+(added.length>1?'các hàng mới':'hàng mới')+' tại đây';return plan}
function paintNewTrackBoundary(plan){let band=$('#newTrackIndicator');if(!plan.newTrackBoundary){band?.remove();return}if(!band){band=document.createElement('div');band.id='newTrackIndicator';band.innerHTML='<span>＋ Thả để tạo hàng mới</span>';$('#sequence').append(band)}const y=plan.newTrackBoundary.y-(activeClipDrag?.sequenceTop??$('#sequence').getBoundingClientRect().top);band.style.top=y+'px';if(activeClipDrag)return;for(const id of selectedIds){const el=$('[data-item="'+id+'"]');if(!el)continue;const base=el.parentElement.getBoundingClientRect().top+6;el.style.transform='translateY('+(plan.newTrackBoundary.y-base-20)+'px)';el.style.zIndex='14';el.style.opacity='.7'}}
// Retiming preserves the chosen source interval; linked picture/sound is atomic.
function speedEditMembers(item,list){return[item];}
function applyPlaybackSpeed(item,value){
 if(!Number.isFinite(value))return;
 value=clamp(value,.25,3);
 const members=speedEditMembers(item,items),ids=new Set(members.map(i=>i.id));
 if(members.some(i=>!['video','audio'].includes(i.kind)||getTrack(i.trackId).locked)){notify('Mở khóa các track hình–tiếng liên kết trước khi đổi tốc độ.');inspector();return;}
 if(members.every(i=>Math.abs(i.speed-value)<.00001))return;
 const next=clone(items),updated=new Map();
 for(const old of members){
  const duration=old.duration*old.speed/value,asset=getAsset(old.assetId);
  if(duration<.2||old.start+duration>3600||!asset||old.mediaIn+old.duration*old.speed>asset.duration+.05){notify('Tốc độ này vượt giới hạn thời lượng hoặc phần nguồn của clip.');inspector();return;}
  const i=next.find(i=>i.id===old.id);i.speed=value;i.duration=duration;
  i.keyframes=(old.keyframes||[]).map(k=>({...clone(k),at:k.at*old.speed/value}));
  i.fadeIn=Math.min(i.fadeIn,duration);i.fadeOut=Math.min(i.fadeOut,duration);i.transitionDuration=Math.min(i.transitionDuration,duration);
  updated.set(i.id,i);
 }
 const starts=members.map(i=>i.start),durations=[...updated.values()].map(i=>i.duration);
 if(members.length>1&&(Math.max(...starts)-Math.min(...starts)>.001||Math.max(...durations)-Math.min(...durations)>.001||new Set(members.map(i=>i.trackId)).size!==members.length)){
  notify('Nhóm hình–tiếng có phần cắt khác nhau. Bỏ liên kết trước khi đổi riêng từng phần.');inspector();return;
 }
 if(timelineEditMode==='insert'){
  for(const old of members){const shift=updated.get(old.id).duration-old.duration;for(const other of next)if(!ids.has(other.id)&&other.trackId===old.trackId&&other.start>=end(old)-.00001)other.start+=shift;}
 }
 if(next.some(i=>i.start<0||end(i)>3600)||members.some(i=>!trackIsLinear(next,i.trackId))){notify('Clip sẽ chồng lên cảnh bên cạnh. Chọn chế độ Chèn hoặc tạo khoảng trống trước.');inspector();return;}
 // A ripple must not silently move just one half of a later linked pair.
 const linkOffsets=new Map();for(const old of items){if(!old.linkGroup||ids.has(old.id))continue;const changed=next.find(i=>i.id===old.id),delta=changed.start-old.start;if(!linkOffsets.has(old.linkGroup))linkOffsets.set(old.linkGroup,delta);else if(Math.abs(linkOffsets.get(old.linkGroup)-delta)>.001){notify('Đổi tốc độ sẽ làm lệch cặp hình–tiếng phía sau. Tách lớp hoặc bỏ liên kết trước.');inspector();return;}}
 pause();transact(()=>items=next);
}
