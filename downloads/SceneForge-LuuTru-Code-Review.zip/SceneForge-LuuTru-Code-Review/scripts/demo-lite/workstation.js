// Original browser implementation of a desktop editing workspace.
// Reference: Concat's public screenshot and documented interaction concepts.
const workstationCache=new Map(), workstationQueue=[];
let workstationBusy=false;
function cachedArtwork(asset){
 if(!asset?.url||asset.missing)return null;
 const key=asset.id+'|'+asset.url;
 if(workstationCache.has(key))return workstationCache.get(key);
 if(workstationCache.size>=24)return null;
 const data={frames:[],peaks:null,status:'pending'};
 workstationCache.set(key,data);
 workstationQueue.push(async()=>{
  try{
   if(asset.kind==='video'){
    const video=document.createElement('video');video.muted=true;video.preload='auto';video.src=asset.url;
    try{
     await mediaEvent(video,'loadeddata',()=>video.load());
     const length=Number.isFinite(video.duration)?video.duration:asset.duration;
     for(let n=0;n<8;n++){
      const at=Math.min(Math.max(0,length-.05),length*n/7);
      if(Math.abs(video.currentTime-at)>.015)await mediaEvent(video,'seeked',()=>video.currentTime=at);
      const c=document.createElement('canvas');c.width=72;c.height=96;
      c.getContext('2d').drawImage(video,0,0,72,96);
      data.frames.push({at,image:c});
     }
    }finally{video.removeAttribute('src');video.load()}
   }else if(asset.kind==='audio'){
    const response=await fetch(asset.url),blob=await response.blob();
    if(blob.size>32*1024*1024)throw Error('Âm thanh lớn: chưa tính sóng trong bản web');
    const ctx=new (window.AudioContext||window.webkitAudioContext)();
    try{
     const decoded=await ctx.decodeAudioData(await blob.arrayBuffer());
     const samples=decoded.getChannelData(0),count=600,peaks=[];
     for(let n=0;n<count;n++){
      const from=Math.floor(n*samples.length/count),to=Math.floor((n+1)*samples.length/count);let peak=0;
      for(let x=from;x<to;x++)peak=Math.max(peak,Math.abs(samples[x]));
      peaks.push(peak);
     }
     data.peaks=peaks;data.duration=decoded.duration;
    }finally{await ctx.close()}
   }
   data.status='ready';
  }catch{data.status='unavailable'}
  paintTimelineArtwork();
 });
 runArtworkQueue();return data;
}
async function runArtworkQueue(){if(workstationBusy)return;workstationBusy=true;try{while(workstationQueue.length)await workstationQueue.shift()()}finally{workstationBusy=false}}
function mediaEvent(node,event,action){return new Promise((resolve,reject)=>{const clean=()=>{clearTimeout(timer);node.removeEventListener(event,done);node.removeEventListener('error',fail)};const done=()=>{clean();resolve()};const fail=()=>{clean();reject(Error('Không đọc được tư liệu'))};const timer=setTimeout(fail,4500);node.addEventListener(event,done,{once:true});node.addEventListener('error',fail,{once:true});try{action()}catch(e){clean();reject(e)}})}
function paintTimelineArtwork(){
 for(const el of $$('.timelineItem')){
  const item=items.find(i=>i.id===el.dataset.item),asset=getAsset(item?.assetId);if(!asset)continue;
  const data=cachedArtwork(asset);if(!data)continue;
  let canvas=el.querySelector('.clipArtwork');
  if(!canvas){canvas=document.createElement('canvas');canvas.className='clipArtwork';canvas.setAttribute('aria-hidden','true');el.prepend(canvas)}
  const width=Math.min(2400,Math.max(6,Math.round(item.duration*px))),height=Math.max(12,el.clientHeight-21);
  canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d');
  if(data.frames.length){
   const tile=height*.75;
   for(let x=0;x<width;x+=tile){const at=item.mediaIn+(x/width)*item.duration*item.speed;const frame=data.frames.reduce((a,b)=>Math.abs(b.at-at)<Math.abs(a.at-at)?b:a);ctx.drawImage(frame.image,x,0,tile,height)}
   canvas.dataset.ready='frames';
  }else if(data.peaks){
   const max=Math.max(.01,...data.peaks);ctx.fillStyle='#addec0';
   for(let x=0;x<width;x+=3){const at=item.mediaIn+x/width*item.duration*item.speed;const index=clamp(Math.floor(at/data.duration*data.peaks.length),0,data.peaks.length-1);const h=Math.max(2,data.peaks[index]/max*(height-5));ctx.fillRect(x,(height-h)/2,2,h)}
   canvas.dataset.ready='waveform';
  }else if(data.status==='unavailable'){canvas.title='Chưa đọc được hình / sóng âm của tệp này'}
 }
}
function decorateWorkstationTimeline(){
 for(const row of $$('#tracks>.trackRow')){
  const track=getTrack(row.dataset.track);if(!track)continue;
  row.style.setProperty('--lane-height',(track.height||({video:86,text:53,audio:70}[track.kind]))+'px');
  row.dataset.kind=track.kind;
 }
 paintTimelineArtwork();
}

// Move creative categories into the media pane, freeing vertical preview space.
$('#mediaPanel').prepend($('#creativeToolbar'));
const rail=document.createElement('aside');rail.id='libraryRail';rail.setAttribute('aria-label','Loại tư liệu');
rail.innerHTML='<small>DỰ ÁN</small>'+[['all','Tất cả'],['video','Video'],['audio','Âm thanh'],['image','Hình ảnh']].map(([k,label])=>`<button data-rail-kind="${k}">${uiIcon(k==='audio'?'music':k==='image'?'camera':'media')}<span>${label}</span></button>`).join('')+'<div class="railDivider"></div><small>TẠO MỚI</small><button data-rail-library="text">'+uiIcon('text')+'<span>Văn bản</span></button><button data-rail-library="captions">'+uiIcon('captions')+'<span>Phụ đề</span></button>';
const libraryBody=document.createElement('div');libraryBody.id='libraryBody';
$('#mediaPanel').append(libraryBody);libraryBody.append(rail,$('.mediaContent'),$('#creativeLibrary'));
rail.onclick=e=>{const kind=e.target.closest('[data-rail-kind]')?.dataset.railKind;if(kind){showLibrary(kind==='audio'?'audio':'media');filter=kind;renderAssets();$$('#mediaTabs button').forEach(b=>b.classList.toggle('active',b.dataset.kind===kind));$$('[data-rail-kind]').forEach(b=>b.classList.toggle('active',b.dataset.railKind===kind));return}const tab=e.target.closest('[data-rail-library]')?.dataset.railLibrary;if(tab)showLibrary(tab)};
rail.querySelector('button').classList.add('active');
const libraryActions=document.createElement('div');libraryActions.className='libraryActions';libraryActions.innerHTML='<button id="openSampleEdit">'+uiIcon('play')+'<span>Mở bản dựng mẫu</span></button><select id="assetOrder" aria-label="Sắp xếp tư liệu"><option value="original">Mới thêm</option><option value="name">Tên A–Z</option><option value="duration">Thời lượng</option></select>';
// Keep the complete-demo action obvious in the Vietnamese UI.
libraryActions.querySelector('span').textContent='Mở bản dựng mẫu';libraryActions.querySelector('select').setAttribute('aria-label','Sắp xếp tư liệu');
$('#sourceLibrary').prepend(libraryActions);
$('#assetOrder').onchange=e=>{const mode=e.target.value;const elements=[...$('#assets').children];if(mode!=='original')elements.sort((a,b)=>{const aa=getAsset(a.dataset.asset),bb=getAsset(b.dataset.asset);return mode==='name'?aa.name.localeCompare(bb.name,'vi'):aa.duration-bb.duration});else elements.sort((a,b)=>assets.findIndex(x=>x.id===a.dataset.asset)-assets.findIndex(x=>x.id===b.dataset.asset));$('#assets').append(...elements)};
$('#openSampleEdit').onclick=()=>{
 if(items.some(i=>i.demoShowcase)){notify('Dự án mẫu đã có chữ và nhạc trên timeline.');return}
 transact(()=>{
  const textTrack=findTrack('text'),audioTrack=findTrack('audio');
  const text={...defaults('text'),id:uid(),kind:'text',trackId:textTrack.id,name:'Tiêu đề mở đầu',text:'MỘT NGÀY MỚI',fontSize:76,textY:70,start:0,duration:4,demoShowcase:true,textAnimation:'fade'};
  if(items.some(i=>i.trackId===text.trackId&&intervalsOverlap(i,text))){const layer=makeMediaTrack('text');addTrackInFront(layer,tracks);text.trackId=layer.id}
  const music={...defaults('audio'),id:uid(),kind:'audio',assetId:'music',trackId:audioTrack.id,name:'Giai điệu mẫu.wav',start:0,duration:12,volume:.5,fadeIn:.6,fadeOut:1,demoShowcase:true};
  if(items.some(i=>i.trackId===music.trackId&&intervalsOverlap(i,music))){const layer=makeMediaTrack('audio');addTrackInFront(layer,tracks);music.trackId=layer.id}
  items.push(text,music);const first=items.find(i=>i.kind==='video');if(first){first.transition='fade';first.transitionDuration=.5;selection=first.id;selectedIds=new Set([first.id])}time=1;pause();
 });notify('Mẫu gồm 3 cảnh, tiêu đề, nhạc và chuyển cảnh. Bấm Phát để thử.');
};

// Source monitor is separate from the editing preview: double-click to inspect.
const sourceDialog=document.createElement('dialog');sourceDialog.id='sourceMonitor';sourceDialog.innerHTML='<div class="monitorHead"><b>Xem tư liệu gốc</b><button id="closeSourceMonitor" aria-label="Đóng tư liệu">×</button></div><div id="sourceMonitorBody"></div><p id="sourceMonitorName"></p><button id="sourceMonitorInsert" class="primary">Thêm vào bản dựng</button>';document.body.append(sourceDialog);
let sourceMonitorId=null;
$('#assets').ondblclick=null; // Double-click now opens the source, rather than inserting it.
$('#assets').addEventListener('dblclick',e=>{if(e.target.closest('button'))return;const asset=getAsset(e.target.closest('[data-asset]')?.dataset.asset);if(!asset?.url)return;pause();sourceMonitorId=asset.id;const media=document.createElement(asset.kind==='image'?'img':asset.kind==='audio'?'audio':'video');media.src=asset.url;if(asset.kind!=='image')media.controls=true;$('#sourceMonitorBody').replaceChildren(media);$('#sourceMonitorName').textContent=asset.name;sourceDialog.showModal()});
$('#closeSourceMonitor').onclick=()=>sourceDialog.close();sourceDialog.addEventListener('close',()=>{$('#sourceMonitorBody video, #sourceMonitorBody audio')?.pause();$('#sourceMonitorBody').replaceChildren()});$('#sourceMonitorInsert').onclick=()=>{addAsset(sourceMonitorId);sourceDialog.close()};

// Desktop project menus use the same commands as toolbar and keyboard shortcuts.
const menus=document.createElement('nav');menus.className='desktopMenus';menus.setAttribute('aria-label','Menu trình dựng');
const menuData={file:[['Nhập tư liệu','Ctrl I',()=>$('#upload').click()],['Mở dự án','',()=>$('#openProject').click()],['Lưu dự án','',()=>$('#saveProject').click()],['Xuất video','',()=>$('#export').click()]],edit:[['Hoàn tác','Ctrl Z',()=>commands.undo()],['Làm lại','Ctrl Shift Z',()=>commands.redo()],['Tách tại vạch phát','Ctrl B',()=>commands.split()],['Nhân đôi','Ctrl D',()=>commands.duplicate()],['Xóa mục','Delete',()=>commands.delete()]],view:[['Bố cục mặc định','',()=>setWorkspaceLayout('balanced')],['Tập trung khung xem','',()=>setWorkspaceLayout('preview')],['Mở rộng timeline','',()=>setWorkspaceLayout('timeline')],['Vùng an toàn 9:16','',()=>$('#safe').click()],['Vừa khung timeline','',()=>$('#fitTimeline').click()]]};
menus.innerHTML=[['file','Tệp'],['edit','Chỉnh sửa'],['view','Hiển thị']].map(([key,label])=>`<button data-desktop-menu="${key}" aria-haspopup="menu" aria-expanded="false">${label}</button>`).join('');$('header>div').append(menus);
const popup=document.createElement('div');popup.id='workstationPopup';popup.hidden=true;popup.setAttribute('role','menu');document.body.append(popup);
function closeWorkstationMenu(){popup.hidden=true;$$('[data-desktop-menu]').forEach(b=>b.setAttribute('aria-expanded','false'))}
function openWorkstationMenu(actions,x,y){popup.replaceChildren();for(const [label,shortcut,action,disabled=false] of actions){const b=document.createElement('button');b.setAttribute('role','menuitem');b.disabled=disabled;b.innerHTML='<span>'+esc(label)+'</span><kbd>'+esc(shortcut)+'</kbd>';b.onclick=()=>{closeWorkstationMenu();action()};popup.append(b)}popup.hidden=false;popup.style.left=Math.max(4,Math.min(x,innerWidth-240))+'px';popup.style.top=Math.max(4,Math.min(y,innerHeight-popup.offsetHeight-8))+'px';popup.querySelector('button:not(:disabled)')?.focus()}
menus.onclick=e=>{const b=e.target.closest('[data-desktop-menu]');if(!b)return;const r=b.getBoundingClientRect();openWorkstationMenu(menuData[b.dataset.desktopMenu],r.left,r.bottom+5);b.setAttribute('aria-expanded','true')};
document.addEventListener('pointerdown',e=>{if(!e.target.closest('#workstationPopup,.desktopMenus'))closeWorkstationMenu()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeWorkstationMenu();if(e.target.closest('#workstationPopup')&&['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();const buttons=[...popup.querySelectorAll('button:not(:disabled)')],at=buttons.indexOf(document.activeElement);buttons[(at+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus()}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='i'){e.preventDefault();$('#upload').click()}});
function setWorkspaceLayout(mode){$('#workspace').style.removeProperty('--media');document.body.style.removeProperty('--media');document.body.style.removeProperty('--inspector');document.body.style.removeProperty('--timeline');document.body.dataset.workspaceView=mode;$$('[data-workspace-view]').forEach(b=>{const active=b.dataset.workspaceView===mode;b.classList.toggle('active',active);b.setAttribute('aria-pressed',active)});timeline()}
for(const b of $$('[data-workspace-view]'))b.onclick=()=>setWorkspaceLayout(b.dataset.workspaceView);

$('#tracks').addEventListener('contextmenu',e=>{
 const row=e.target.closest('[data-track]');if(!row)return;e.preventDefault();const track=getTrack(row.dataset.track),cell=e.target.closest('[data-item]');if(cell&&!selectedIds.has(cell.dataset.item))choose(cell.dataset.item);
 const actions=[];if(cell){const item=selected(),locked=!!track.locked;actions.push(['Tách tại vạch phát','Ctrl B',()=>commands.split(),locked],['Nhân đôi','Ctrl D',()=>commands.duplicate(),locked],['Đưa lên lớp riêng','',()=>{if(!allowEdit())return;const plan=selectedIds.size>1?planGroupMove(items,tracks,[...selectedIds],0,'layer',uid()):planSingleMove(items,tracks,item.id,item.trackId,item.start,item.start,'layer',uid());if(plan.valid)transact(()=>{items=plan.items;tracks=plan.tracks})},locked],['Xóa mục','Delete',()=>commands.delete(),locked]);if(item.kind==='video')actions.push(['Tách âm thanh','',()=>{switchInspectorTab('audio');$('#extractAudio')?.click()},locked]);}
 actions.push([track.locked?'Mở khóa track':'Khóa track','',()=>transact(()=>track.locked=!track.locked)]);
 for(const [size,label] of [[48,'Gọn'],[76,'Vừa'],[110,'Lớn']])actions.push(['Chiều cao track · '+label,track.height===size?'✓':'',()=>transact(()=>track.height=size)]);
 openWorkstationMenu(actions,e.clientX,e.clientY);
});

const trackSize=document.createElement('select');trackSize.id='trackSizePreset';trackSize.setAttribute('aria-label','Chiều cao các track');trackSize.innerHTML='<option value="auto">Track · Tự động</option><option value="48">Track · Gọn</option><option value="76">Track · Vừa</option><option value="110">Track · Lớn</option>';$('.toolbar .grow').before(trackSize);trackSize.onchange=()=>{transact(()=>tracks.forEach(t=>t.height=trackSize.value==='auto'?null:+trackSize.value))};
const monitorZoom=document.createElement('select');monitorZoom.id='monitorZoom';monitorZoom.setAttribute('aria-label','Thu phóng khung xem');monitorZoom.innerHTML='<option value="1">Vừa khung</option><option value="1.25">125%</option><option value="1.5">150%</option><option value="2">200%</option>';$('.previewHead').append(monitorZoom);monitorZoom.onchange=()=>{$('#stage').style.transform='scale('+monitorZoom.value+')';$('#stageWrap').classList.toggle('zoomedMonitor',monitorZoom.value!=='1')};
const densityButton=document.createElement('button');densityButton.id='workspaceGuide';densityButton.innerHTML=uiIcon('info')+'<span>Thao tác nhanh</span>';$('.sequenceHead').append(densityButton);densityButton.onclick=()=>notify('Bấm đúp tư liệu để xem gốc · Chuột phải clip để mở menu · Kéo mép bảng để đổi kích thước · Nhấc clip để tạo lớp');
