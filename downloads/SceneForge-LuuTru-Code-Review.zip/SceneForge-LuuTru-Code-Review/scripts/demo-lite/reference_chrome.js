// Visual arrangement matched to the user's supplied Concat screenshot.
// Original implementation; all controls retain their existing handlers.
const topProjectName=$('header strong');topProjectName.textContent='SceneForge demo';
const savedLabel=document.createElement('small');savedLabel.textContent=' · bản mô phỏng';topProjectName.append(savedLabel);
const dots=document.createElement('span');dots.className='windowDots';dots.setAttribute('aria-hidden','true');$('.desktopMenus').before(dots);
const paneSearch=$('.toolSearchWrap');$('#mediaPanel .panelHead').prepend(paneSearch);
const sampleAction=$('#openSampleEdit');$('#libraryRail').append(sampleAction);
const sourceActionRow=document.createElement('div');sourceActionRow.className='sourceActionRow';sourceActionRow.append($('#upload'),$('#assetOrder'));$('#sourceLibrary').prepend(sourceActionRow);
$('.libraryActions').remove();
const collapsedInspectorGroups=new Set();
function decorateReferenceInspector(){
 const box=$('#inspector');box.dataset.selectedKind=selected()?.kind||'none';
 if(selected()?.kind==='audio'){const speed=box.querySelector('#prop-speed')?.closest('.field'),pane=box.querySelector('[data-inspector-pane=audio]');if(speed&&pane)pane.append(speed)}
 const sections=[['#prop-volume','Âm lượng'],['#prop-fadeIn','Vào / ra dần'],['#prop-speed','Tốc độ'],['#prop-start','Thời gian'],['#prop-fit','Khung hình'],['#prop-fontSize','Kiểu chữ']];
 for(const [selector,title]of sections){const input=box.querySelector(selector);if(!input)continue;let anchor=input.closest('.pair')||input.closest('.field');if(!anchor||anchor.previousElementSibling?.classList.contains('referenceSection'))continue;const heading=document.createElement('h4');heading.className='referenceSection';heading.textContent=title;anchor.before(heading)}
 for(const heading of box.querySelectorAll('.referenceSection')){
  const title=heading.textContent,key=(selected()?.kind||'none')+':'+title;
  const group=document.createElement('div');group.className='referenceGroup';
  let node=heading.nextElementSibling;
  while(node&&!node.matches('.referenceSection,.sectionTitle,details')){const next=node.nextElementSibling;group.append(node);node=next}
  heading.after(group);const button=document.createElement('button');button.type='button';button.textContent=title;button.className='referenceGroupToggle';
  group.hidden=collapsedInspectorGroups.has(key);button.setAttribute('aria-expanded',String(!group.hidden));
  button.onclick=()=>{group.hidden=!group.hidden;button.setAttribute('aria-expanded',String(!group.hidden));if(group.hidden)collapsedInspectorGroups.add(key);else collapsedInspectorGroups.delete(key)};
  heading.replaceChildren(button);
 }
}
