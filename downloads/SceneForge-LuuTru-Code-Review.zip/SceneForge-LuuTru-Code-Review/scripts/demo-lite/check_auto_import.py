from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[2])
from playwright.sync_api import sync_playwright
import json,base64,subprocess
s=Path('preview.html').read_text();m='const DEMO_VIDEO=';data,_=json.JSONDecoder().raw_decode(s[s.index(m)+len(m):]);raw=base64.b64decode(data.split(',')[1]);Path('/tmp/upload-a.mp4').write_bytes(raw);Path('/tmp/upload-c.mp4').write_bytes(raw);Path('/tmp/upload-library.mp4').write_bytes(raw)
subprocess.run(['ffmpeg','-v','error','-y','-stream_loop','3','-i','/tmp/upload-a.mp4','-t','35','-c','copy','/tmp/upload-b.mp4'],check=True)
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path(os.environ.get('SCENEFORGE_EDITOR_PREVIEW','editor-demo.html')).read_text()));page.goto('http://demo.test/')
 state=lambda:page.evaluate('SceneForgeEditor.getState()')
 page.locator('#file').set_input_files(['/tmp/upload-a.mp4','/tmp/upload-b.mp4']);page.wait_for_function('SceneForgeEditor.getState().items.length===5')
 s=state();new=[i for i in s['items']if i['name'].startswith('upload-')];assert len(new)==2;assert len({i['trackId']for i in new})==2;assert all(i['trackId']!='v1'for i in new);assert len(s['tracks'])==5
 assert next(i for i in new if i['name']=='upload-b.mp4')['duration']>34.9
 assert all(a.get('poster','').startswith('data:image/jpeg')for a in s['assets']if a['name'].startswith('upload-'))
 page.locator('#importPlacement').select_option('append');page.locator('#file').set_input_files('/tmp/upload-c.mp4');page.wait_for_function('SceneForgeEditor.getState().items.length===6');s=state();clip=next(i for i in s['items']if i['name']=='upload-c.mp4');assert clip['start']>34.9 and len(s['tracks'])==5
 page.locator('#importPlacement').select_option('library');page.locator('#file').set_input_files('/tmp/upload-library.mp4');page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name==="upload-library.mp4")');assert len(state()['items'])==6
 page.locator('#timelineEditMode').select_option('overwrite')
 with page.expect_download()as dl:page.locator('#saveProject').click()
 dl.value.save_as('/tmp/import-modes-project.json');page.locator('#reset').click();page.locator('#projectFile').set_input_files('/tmp/import-modes-project.json');page.wait_for_timeout(150);assert state()['timelineEditMode']=='overwrite';assert page.locator('#importPlacement').input_value()=='library'
 # Reconnecting an existing file must not add a second timeline item.
 before=len(state()['items']);page.locator('#file').set_input_files('/tmp/upload-a.mp4');page.wait_for_function('!SceneForgeEditor.getState().assets.find(a=>a.name==="upload-a.mp4").missing');assert len(state()['items'])==before
 page.locator('#reset').click();page.locator('#timelineEditMode').select_option('insert');page.locator('#importPlacement').select_option('layer')
 # Dropping a file on a lane adds exactly once despite the automatic import default.
 page.locator('[data-lane="v1"]').evaluate('''(lane,base64)=>{const binary=atob(base64),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0)),dt=new DataTransfer();dt.items.add(new File([bytes],'drop-once.mp4',{type:'video/mp4'}));const r=lane.getBoundingClientRect();lane.dispatchEvent(new DragEvent('drop',{bubbles:true,dataTransfer:dt,clientX:r.left+62*4,clientY:r.top+20}));}''',data.split(',')[1]);page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.name==="drop-once.mp4")');s=state();assert len([i for i in s['items']if i['name']=='drop-once.mp4'])==1
 row=sorted([i for i in s['items']if i['trackId']=='v1'],key=lambda i:i['start']);assert all(a['start']+a['duration']<=c['start']+.001 for a,c in zip(row,row[1:]))
 # Dragging a library asset to the blank lane creates its own track.
 before=len(s['tracks']);page.locator('#newLayerDrop').evaluate('''(el)=>{const dt=new DataTransfer();dt.setData('application/sceneforge-asset','sample2');const r=el.getBoundingClientRect();el.dispatchEvent(new DragEvent('drop',{bubbles:true,dataTransfer:dt,clientX:r.left+10,clientY:r.top+10}));}''');assert len(state()['tracks'])==before+1
 assert not errors,errors
 print('PASS: multi-file auto placement into separate tracks with thumbnails; full 35s source preserved; append/library options; saved mode preferences; media reconnect without duplication; file-drop inserts once; blank-lane auto track; no overlap.')
 b.close()
