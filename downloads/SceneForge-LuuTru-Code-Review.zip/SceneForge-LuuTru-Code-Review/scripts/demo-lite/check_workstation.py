"""Exercise the source monitor, real timeline artwork and desktop workspace."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright

os.chdir(Path(__file__).resolve().parents[2])
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1600, 'height': 1000})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.route('http://demo.test/**', lambda r: r.fulfill(
        content_type='text/html', body=Path('concat-demo.html').read_text()))
    page.goto('http://demo.test/')
    state = lambda: page.evaluate('SceneForgeEditor.getState()')
    assert len(state()['items']) == 5
    assert page.locator('#mediaPanel #creativeToolbar').count() == 1
    page.wait_for_function("document.querySelectorAll('.clipArtwork[data-ready=frames]').length === 3", timeout=30000)
    page.wait_for_function("document.querySelector('.clipArtwork[data-ready=waveform]')", timeout=30000)
    # A decoded waveform must contain pixels, rather than a decorative pattern.
    assert page.locator('.clipArtwork[data-ready=waveform]').evaluate(
        '(c)=>c.getContext("2d").getImageData(0,0,c.width,c.height).data.some((v,n)=>n%4===3&&v>0)')
    baseline = state()['items']
    for mode in ['preview', 'timeline', 'balanced']:
        page.locator('[data-workspace-view="' + mode + '"]').click()
        assert state()['items'] == baseline
    # Double-click a source to inspect without inserting it.
    page.locator('[data-asset="sample0"]').dblclick()
    assert page.locator('#sourceMonitor').is_visible()
    assert len(state()['items']) == 5
    page.locator('#closeSourceMonitor').click()
    page.wait_for_function("!document.querySelector('#sourceMonitorBody video')")
    # Context-menu action changes track height, and undo restores it.
    page.locator('.timelineItem.video').first.click(button='right')
    page.get_by_role('menuitem', name='Chiều cao track · Lớn').click()
    assert state()['tracks'][0]['height'] == 110
    page.locator('#undo').click()
    assert state()['tracks'][0].get('height') is None
    page.locator('.timelineItem.video').first.click(button='right')
    page.get_by_role('menuitem', name='Đưa lên lớp riêng').click()
    assert len(state()['tracks']) == 4
    page.locator('#undo').click()
    assert len(state()['tracks']) == 3
    # Escape dismisses menus without clearing the underlying clip selection.
    selected_before = state()['selectedIds']
    page.locator('[data-desktop-menu="view"]').click()
    page.keyboard.press('Escape')
    assert not page.locator('#workstationPopup').is_visible()
    assert state()['selectedIds'] == selected_before
    # Menus invoke the actual export workflow; no provider calls.
    page.locator('[data-desktop-menu="file"]').click()
    page.get_by_role('menuitem', name='Xuất video').click()
    assert page.locator('#exportDialog').is_visible()
    page.locator('#closeExport').click()
    page.locator('#monitorZoom').select_option('1.5')
    assert '1.5' in page.locator('#stage').evaluate('(e)=>e.style.transform')
    page.locator('#monitorZoom').select_option('1')
    page.wait_for_timeout(3100)
    page.screenshot(path='/tmp/sceneforge-concat-workstation.png')
    page.set_viewport_size({'width': 430, 'height': 932})
    assert page.locator('#upload').is_visible()
    assert page.locator('#play').is_visible()
    page.screenshot(path='/tmp/sceneforge-concat-workstation-mobile.png', full_page=True)
    assert not errors, errors
    print('PASS: populated example; decoded filmstrips/waveform; source monitor; layouts; context menu; track sizes and undo; new layers; project menu; monitor zoom; mobile. No JS errors.')
    browser.close()
