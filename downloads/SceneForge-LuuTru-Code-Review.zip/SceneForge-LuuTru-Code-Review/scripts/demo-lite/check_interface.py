from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[2])
from playwright.sync_api import sync_playwright
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path('editor-demo.html').read_text()));page.goto('http://demo.test/')
 assert page.locator('[data-library]').count()==9
 assert page.locator('[data-inspector-pane="basic"]').is_visible()
 assert not page.locator('[data-inspector-pane="color"]').is_visible()
 page.locator('[data-library="filters"]').click();assert page.locator('[data-palette-look]').count()==6
 page.locator('[data-palette-look="warm"]').click();assert page.evaluate('SceneForgeEditor.getState().items[0].look')=='warm';assert page.locator('#prop-brightness').is_visible()
 slider=page.locator('[data-inspector-pane="color"] .field:has(#prop-brightness) .propertySlider');slider.press('End');assert page.evaluate('SceneForgeEditor.getState().items[0].brightness')==200;page.locator('#undo').click();assert page.evaluate('SceneForgeEditor.getState().items[0].brightness')==100
 page.locator('[data-library="transitions"]').click();page.locator('[data-palette-transition="fade"]').click();assert page.locator('#prop-transitionDuration').is_visible()
 page.locator('#prop-transitionDuration').fill('1.2');page.locator('#prop-transitionDuration').press('Tab')
 assert page.evaluate('SceneForgeEditor.getState().items[0].transitionDuration')==1.2
 page.locator('[data-library="text"]').click();page.locator('[data-palette-text="subtitle"]').click();assert page.locator('#prop-text').is_visible();page.locator('#prop-text').fill('Một hành trình mới');page.locator('#prop-text').press('Tab')
 page.locator('[data-library="stickers"]').click();page.locator('[data-palette-sticker="heart"]').click();assert any(i.get('text')=='♥'for i in page.evaluate('SceneForgeEditor.getState().items'))
 page.locator('[data-library="captions"]').click();assert page.locator('[data-caption-action="import"]').is_visible()
 page.locator('[data-library="media"]').click();page.locator('#assetSearch').fill('bình');assert page.locator('#assets .asset').count()==1
 # Tool search supports accents, no accents and keyboard activation.
 page.locator('#toolSearch').fill('chuyen canh');assert page.locator('#toolSearchResults button').count()==1;page.locator('#toolSearch').press('Enter')
 # Heart is selected, so requesting a visual-specific tool must not silently edit the text.
 assert page.locator('[data-library="transitions"]').evaluate('(e)=>e.classList.contains("active")')
 page.keyboard.press('Control+k');assert page.locator('#toolSearch').evaluate('(e)=>e===document.activeElement');page.locator('#toolSearch').fill('xyz missing');assert page.locator('.noToolResults').is_visible();page.locator('#toolSearch').press('Escape')
 assert page.locator('#split svg').count()==1 and page.locator('#split').get_attribute('aria-label')
 page.screenshot(path='/tmp/sceneforge-visual-ui.png')
 assert not errors,errors
 print('PASS: visual tool categories, actual filter/transition/text/sticker cards, contextual property tabs, media search, tool search/keyboard, labeled icon controls; no JS errors.')
 b.close()
