from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[2])
from browser_controls import controls
from playwright.sync_api import sync_playwright
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path(os.environ.get('SCENEFORGE_EDITOR_PREVIEW','editor-demo.html')).read_text()));page.goto('http://demo.test/')
 q=controls(page)
 state=lambda:page.evaluate('SceneForgeEditor.getState()')
 for i in state()['items'][1:]:q('[data-item="'+i['id']+'"]').click();q('#delete').click()
 q('[data-item]').click();q('#prop-duration').fill('1.5');q('#prop-duration').press('Tab')
 q('[data-look="warm"]').click()
 q('#newText').click();q('#prop-text').fill('XUẤT VIDEO THẬT');q('#prop-text').press('Tab');q('#prop-color').fill('#ffff00');q('#prop-color').press('Tab')
 if page.locator('#miniAudioControls').count():
  import wave,math,struct
  with wave.open('/tmp/short-export.wav','wb')as wav:
   wav.setparams((1,2,16000,0,'NONE',''));wav.writeframes(b''.join(struct.pack('<h',int(math.sin(n*2*math.pi*440/16000)*1800))for n in range(24000)))
  q('#file').set_input_files('/tmp/short-export.wav');page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.kind==="audio")')
 else:
  q('[data-add-asset="music"]').click();q('#prop-duration').fill('1.5');q('#prop-duration').press('Tab')
 q('#export').click();formats=q('#exportFormat option').all_text_contents();print('Supported formats:',formats,flush=True)
 with page.expect_download(timeout=25000)as dl:q('#realExport').click()
 path='/tmp/sceneforge-browser-export'+('.mp4' if dl.value.suggested_filename.endswith('.mp4')else'.webm');dl.value.save_as(path)
 assert Path(path).stat().st_size>5000
 assert 'video thật' in q('#exportStatus').inner_text()
 q('#realExport').click();page.wait_for_timeout(200);q('#cancelExport').click();page.wait_for_function('document.querySelector("#cancelExport").hidden');assert 'hủy' in q('#exportStatus').inner_text()
 q('#closeExport').click();q('#file').set_input_files(path);page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name.startsWith("sceneforge-browser-export"))')
 assert not errors,errors
 print('PASS: real local export downloaded',path,Path(path).stat().st_size,'bytes',flush=True)
 b.close()

import subprocess,json,array,math
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height','-show_entries','format=duration','-of','json',path]))
assert any(s.get('width')==720 and s.get('height')==1280 for s in probe['streams'])
assert any(s['codec_name'] in ('opus','aac') for s in probe['streams'])
assert 1.4<float(probe['format']['duration'])<1.8
raw=subprocess.check_output(['ffmpeg','-v','error','-i',path,'-map','0:a:0','-f','f32le','-'])
samples=array.array('f');samples.frombytes(raw);rms=math.sqrt(sum(x*x for x in samples)/len(samples));assert rms>.001,rms
subprocess.run(['ffmpeg','-v','error','-y','-ss','0.6','-i',path,'-frames:v','1','/tmp/sceneforge-browser-export-frame.png'],check=True)
from PIL import Image
im=Image.open('/tmp/sceneforge-browser-export-frame.png').convert('RGB')
yellow=sum(1 for r,g,b in im.getdata()if r>190 and g>190 and b<100);assert yellow>200,yellow
print('PASS: decoded 720x1280 output with finite duration, audible audio, burned-in yellow text; cancel and reimport verified.')
