from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[2])
from playwright.sync_api import sync_playwright
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path(os.environ.get('SCENEFORGE_EDITOR_PREVIEW','editor-demo.html')).read_text()));page.goto('http://demo.test/')
 state=lambda:page.evaluate('SceneForgeEditor.getState()')
 a=state()['items'][0]['id'];original=state()
 def lift(id,index):
  cell=page.locator('[data-item="'+id+'"]').bounding_box();rows=page.locator('#tracks>.trackRow');rect=rows.nth(index).bounding_box();target=rect['y']-9
  page.mouse.move(cell['x']+25,cell['y']+20);page.mouse.down();page.mouse.move(cell['x']+25,target,steps=12)
  assert page.locator('#newTrackIndicator').is_visible()
  assert 'lớp mới' in page.locator('#dropGuide').inner_text()
  page.mouse.up();page.wait_for_timeout(50)
 # Default insertion mode must still lift into an automatic top track.
 lift(a,0);s=state();assert len(s['tracks'])==4;assert s['tracks'][0]['id']==next(i['trackId']for i in s['items']if i['id']==a);assert next(i for i in s['items']if i['id']==a)['start']==0
 assert next(i for i in s['items']if i['assetId']=='sample1')['start']==4
 page.locator('#undo').click();assert len(state()['tracks'])==3;assert state()['items']==original['items']
 # Gaps between rows place a new track at the actual drop position.
 second=state()['items'][1]['id'];lift(second,1);s=state();track=next(i['trackId']for i in s['items']if i['id']==second);assert s['tracks'][1]['id']==track
 page.locator('#undo').click()
 # Creation is exactly once per drop, even with many pointer updates and another edit mode.
 page.locator('#timelineEditMode').select_option('overwrite')
 for n in range(3):
  before=len(state()['tracks']);lift(a,0);assert len(state()['tracks'])==before+1
 assert len(state()['items'])==3
 # Cancel while hovering must restore both tracks and clip placement.
 before=state();cell=page.locator('[data-item="'+a+'"]').bounding_box();row=page.locator('#tracks>.trackRow').first.bounding_box();page.mouse.move(cell['x']+25,cell['y']+20);page.mouse.down();page.mouse.move(cell['x']+25,row['y']-9,steps=8)
 page.locator('[data-item="'+a+'"]').dispatch_event('pointercancel',{'pointerId':1});page.mouse.up();page.wait_for_timeout(50)
 assert state()['tracks']==before['tracks'] and state()['items']==before['items']
 assert not page.locator('#newTrackIndicator').count()
 assert not errors,errors
 page.screenshot(path='/tmp/sceneforge-lift-track.png')
 print('PASS: lifting above/in between tracks creates a row at the drop position, independent of edit mode; one track per drop, timing preserved, undo and cancel restore everything. No JS errors.')
 b.close()
