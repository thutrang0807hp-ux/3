from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[2])
from browser_controls import controls
from playwright.sync_api import sync_playwright
import json
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path(os.environ.get('SCENEFORGE_EDITOR_PREVIEW','editor-demo.html')).read_text()));page.goto('http://demo.test/')
 q=controls(page)
 state=lambda:page.evaluate('SceneForgeEditor.getState()')
 q('[data-look="mono"]').click();assert 'grayscale' in q('video').first.evaluate('(n)=>n.style.filter')
 q('#prop-brightness').fill('130');q('#prop-brightness').press('Tab');q('#prop-flipX').check()
 assert state()['items'][0]['brightness']==130 and state()['items'][0]['flipX']
 # Keyframes add at start, changing scale at a later time creates the second key.
 page.evaluate('SceneForgeEditor.seek(0)');q('#addKeyframe').click();page.evaluate('SceneForgeEditor.seek(3)')
 q('#prop-scale').fill('160');q('#prop-scale').press('Tab')
 assert len(state()['items'][0]['keyframes'])==2
 page.evaluate('SceneForgeEditor.seek(1.5)');transform=q('video').first.evaluate('(n)=>n.style.transform');assert '1.3' in transform,transform
 assert q('.keyframeDot').count()==2
 q('#split').click();ks=[i['keyframes']for i in state()['items']if i['keyframes']];assert len(ks)==2 and ks[1][0]['at']==0
 q('#undo').click()
 # text styles and animations
 q('#newText').click();q('[data-text-preset="subtitle"]').click();q('#prop-textAnimation').select_option('typewriter');q('#prop-outline').fill('3');q('#prop-outline').press('Tab');q('#prop-fontFamily').select_option('Georgia')
 t=next(i for i in state()['items']if i['kind']=='text');assert t['outline']==3 and t['fontFamily']=='Georgia'
 # SRT import/export positions and content.
 Path('/tmp/captions-test.srt').write_text('1\n00:00:00,500 --> 00:00:01,500\nXin chào\n\n2\n00:00:02,000 --> 00:00:03,500\nMột ngày đẹp\n')
 q('#srtFile').set_input_files('/tmp/captions-test.srt');page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.subtitle&&i.text==="Xin chào")')
 assert any(i['start']==.5 and i.get('text')=='Xin chào' for i in state()['items'])
 with page.expect_download()as dl:q('#exportSrt').click()
 dl.value.save_as('/tmp/exported-captions.srt');assert '00:00:00,500 --> 00:00:01,500' in Path('/tmp/exported-captions.srt').read_text()
 # PNG is a real composited image.
 page.evaluate('SceneForgeEditor.seek(1)')
 with page.expect_download(timeout=15000)as dl:q('#captureFrame').click()
 dl.value.save_as('/tmp/sceneforge-composition.png');assert Path('/tmp/sceneforge-composition.png').stat().st_size>10000
 # Track names and reorder are editable, solo works.
 assert q('[data-track-extra="solo"]').count()>=3
 q('[data-track-extra="solo"][data-id="v1"]').click();assert state()['tracks'][0]['solo']
 q('#featureHelp').click();assert 'Chưa có' in q('#featuresContent').inner_text();q('#closeFeatures').click()
 page.wait_for_timeout(900);page.reload();assert q('#restoreDraft').is_visible();page.wait_for_timeout(900);q('#restoreDraft').click();page.wait_for_timeout(200)
 assert any(i.get('text')=='Xin chào' for i in state()['items'])
 assert state()['items'][0]['keyframes']
 assert not errors,errors
 print('PASS: visual filter, brightness, flip, keyframe interpolation/split preservation, text styling/animation, SRT roundtrip, actual composited PNG, solo, feature inventory, draft restore with keyframes. No JS errors.')
 b.close()
