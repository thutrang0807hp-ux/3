from pathlib import Path
from browser_controls import controls
from playwright.sync_api import sync_playwright
import json,base64,wave,math,struct,os
os.chdir(Path(__file__).resolve().parents[2])
s=Path('preview.html').read_text();k='const DEMO_VIDEO=';video,_=json.JSONDecoder().raw_decode(s[s.index(k)+len(k):]);Path('/tmp/demo-import.mp4').write_bytes(base64.b64decode(video.split(',')[1]))
k='const DEMO_FRAMES=';frames,_=json.JSONDecoder().raw_decode(s[s.index(k)+len(k):]);Path('/tmp/demo-import.png').write_bytes(base64.b64decode(frames[0].split(',')[1]))
with wave.open('/tmp/demo-import.wav','wb')as w:w.setparams((1,2,8000,0,'NONE',''));w.writeframes(b''.join(struct.pack('<h',int(math.sin(t*2*math.pi*440/8000)*1800))for t in range(8000)))
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path(os.environ.get('SCENEFORGE_EDITOR_PREVIEW','editor-demo.html')).read_text()));page.goto('http://demo.test/')
 q=controls(page)
 q('#importPlacement').select_option('library')
 for name,kind in [('demo-import.mp4','video'),('demo-import.png','image'),('demo-import.wav','audio')]:
  q('#file').set_input_files('/tmp/'+name)
  page.wait_for_function('(name)=>SceneForgeEditor.getState().assets.some(a=>a.name===name)',arg=name)
  a=next(a for a in page.evaluate('SceneForgeEditor.getState().assets')if a['name']==name)
  q('[data-add-asset="'+a['id']+'"]').click()
  i=next(i for i in page.evaluate('SceneForgeEditor.getState().items')if i['assetId']==a['id']);assert i['kind']==kind
  page.evaluate('(t)=>SceneForgeEditor.seek(t)',i['start']+.1)
  if kind=='audio':
   q('#play').click();page.wait_for_timeout(200)
   assert page.evaluate('Array.from(document.querySelectorAll("audio")).some(n=>!n.paused&&n.currentTime>0)')
   q('#play').click()
 # Text edit undo restores the content preceding a typing session.
 q('#newText').click();old=q('#prop-text').input_value();q('#prop-text').fill('Nội dung mới');q('#prop-text').press('Tab');q('#undo').click();assert q('#prop-text').input_value()==old
 # Imported sources deliberately excluded from JSON; reconnect using same filename.
 with page.expect_download()as dl:q('#saveProject').click()
 dl.value.save_as('/tmp/media-project.json');project=json.loads(Path('/tmp/media-project.json').read_text());assert not any('url'in a for a in project['assets'])
 q('#reset').click();q('#projectFile').set_input_files('/tmp/media-project.json');page.wait_for_timeout(100)
 assert any(a.get('missing')for a in page.evaluate('SceneForgeEditor.getState().assets'))
 q('#file').set_input_files('/tmp/demo-import.mp4');page.wait_for_function('!SceneForgeEditor.getState().assets.find(a=>a.name==="demo-import.mp4").missing')
 assert not errors,errors
 print('PASS: imported video/image/audio added to separate timelines; native audio played; text undo restores previous text; JSON excludes local URLs and reconnects original media by filename.')
 b.close()
