"""Navigate the visible property tabs and asset categories for browser smoke checks."""
def controls(page):
    def locate(selector):
        aliases={
            '#newText': ('text', '#palettePlainText'),
            '#importSrt': ('captions', '[data-caption-action="import"]'),
            '#exportSrt': ('captions', '[data-caption-action="export"]'),
            '#addSticker': ('stickers', '[data-palette-sticker="star"]'),
        }
        if selector in aliases:
            category, selector=aliases[selector]
            if category=='captions' and not page.locator('[data-library="captions"]').count():
                category='text'
                selector=selector.replace('[data-caption-action="import"]','[data-shared-caption="import"]').replace('[data-caption-action="export"]','[data-shared-caption="srt"]')
            page.locator('[data-library="'+category+'"]').click()
        if page.locator('#miniAudioControls').count() and page.locator('#miniAudioControls').is_visible():
            mini={'#prop-volume':'#miniVolume','#prop-fadeIn':'#miniFadeIn','#prop-fadeOut':'#miniFadeOut','#extractAudio':'#miniExtractAudio'}
            if selector=='#prop-speed' and page.locator('body.audio-mini-selected').count():mini[selector]='#miniSpeed'
            if selector in mini:
                target=page.locator(mini[selector])
                if target.evaluate('(e)=>!!e.closest("#miniAudioOptions")') and not target.is_visible():page.locator('#miniAudioMore').click()
                return target
        locator=page.locator(selector)
        if locator.count() and not locator.first.is_visible():
            pane=locator.first.evaluate('(e)=>e.closest("[data-inspector-pane]")?.dataset.inspectorPane||null')
            if not pane and locator.first.evaluate('(e)=>!!e.closest("#sourceLibrary")'):
                page.locator('[data-library="media"]').click()
            if pane:
                page.locator('[data-inspector-tab="'+pane+'"]').first.click()
            if locator.first.evaluate('(e)=>!!e.closest("#audioBasicControls")'):
                page.locator('[data-audio-view=basic]').click()
        if locator.count() and not locator.first.is_visible():
            group=locator.first.evaluate('(e)=>e.closest(".referenceGroup")?.previousElementSibling?.querySelector(".referenceGroupToggle")?.textContent||null')
            if group:
                page.locator('.referenceGroupToggle').filter(has_text=group).first.click()
        if locator.count() and not locator.first.is_visible():
            details=locator.first.locator('xpath=ancestor::details[1]')
            if details.count() and not details.get_attribute('open'):
                details.locator('summary').first.click()
        return locator
    return locate
