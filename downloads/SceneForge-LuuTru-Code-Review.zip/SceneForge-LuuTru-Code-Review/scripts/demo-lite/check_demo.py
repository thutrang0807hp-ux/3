from pathlib import Path
from browser_controls import controls
from playwright.sync_api import sync_playwright
import json, os
os.chdir(Path(__file__).resolve().parents[2])
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1000},accept_downloads=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path('editor-demo.html').read_text()))
 page.goto('http://demo.test/')
 q=controls(page)
 state=lambda:page.evaluate('SceneForgeEditor.getState()')
 assert len(state()['items'])==3
 q('#play').click();page.wait_for_timeout(600);q('#play').click();assert state()['time']>.4
 q('#newText').click();assert len(state()['items'])==4
 q('#prop-text').fill('Video dọc của tôi');q('#prop-text').press('Tab')
 q('#prop-start').fill('1');q('#prop-start').press('Tab')
 q('#prop-duration').fill('3');q('#prop-duration').press('Tab')
 q('#prop-fontSize').fill('90');q('#prop-fontSize').press('Tab')
 page.evaluate('SceneForgeEditor.seek(2)')
 assert q('.textLayer').inner_text()=='Video dọc của tôi'
 assert q('.textLayer').is_visible()
 text=next(i for i in state()['items'] if i['kind']=='text');assert text['duration']==3 and text['start']==1 and text['fontSize']==90
 # Add independently timed audio, adjust volume and fade, split/undo.
 q('[data-add-asset="music"]').click()
 q('#prop-volume').fill('45');q('#prop-volume').press('Tab')
 q('#prop-fadeIn').fill('1.5');q('#prop-fadeIn').press('Tab')
 page.evaluate('SceneForgeEditor.seek(3)');q('#split').click();assert len([i for i in state()['items'] if i['kind']=='audio'])==2
 q('#undo').click();assert len([i for i in state()['items'] if i['kind']=='audio'])==1
 q('#redo').click();assert len([i for i in state()['items'] if i['kind']=='audio'])==2
 q('#undo').click()
 # Video-only inspector: arbitrary transition duration, transform, extract audio.
 vid=next(i for i in state()['items'] if i['kind']=='video')
 q('[data-item="'+vid['id']+'"]').click()
 q('#prop-transition').select_option('fade')
 q('#prop-transitionDuration').fill('1.2');q('#prop-transitionDuration').press('Tab')
 page.evaluate('SceneForgeEditor.seek(3.8)')
 opacity=q('video').first.evaluate('(n)=>+n.style.opacity');assert 0<opacity<1,opacity
 q('#extractAudio').click();assert next(i for i in state()['items'] if i['id']==vid['id'])['volume']==0
 # Lock really blocks edits; track creation/moving, edge trim.
 q('[data-track-action="lock"][data-id="v1"]').click()
 before=len(state()['items']);q('#duplicate').click();assert len(state()['items'])==before
 q('[data-track-action="lock"][data-id="v1"]').click()
 q('#newTrack').select_option('video');newtrack=state()['tracks'][-1]['id']
 q('[data-item="'+vid['id']+'"]').click()
 h=q('[data-item="'+vid['id']+'"] .edge.right').bounding_box()
 page.mouse.move(h['x']+3,h['y']+10);page.mouse.down();page.mouse.move(h['x']-45,h['y']+10,steps=10);page.mouse.up()
 assert next(i for i in state()['items'] if i['id']==vid['id'])['duration']<4
 q('#undo').click()
 # Compact rows let the source and destination fit even with extra audio tracks.
 q('#trackSizePreset').select_option('48')
 # Increase timeline height so both the source and the newly added destination are visible.
 r=q('#timelineResize').bounding_box();page.mouse.move(r['x']+r['width']/2,r['y']+3);page.mouse.down();page.mouse.move(r['x']+r['width']/2,580,steps=8);page.mouse.up()
 # Move clip between compatible video tracks without losing offsets.
 item=q('[data-item="'+vid['id']+'"]').bounding_box();lane=q('[data-lane="'+newtrack+'"]').bounding_box()
 page.mouse.move(item['x']+35,item['y']+15);page.mouse.down();page.mouse.move(item['x']+35,lane['y']+25,steps=12);page.mouse.up()
 assert next(i for i in state()['items'] if i['id']==vid['id'])['trackId']==newtrack
 # Media layout / collapsed panes.
 q('#mediaMode').click();assert q('#mediaPanel').evaluate('(e)=>e.classList.contains("media-list")')
 q('#collapseMedia').click();assert q('#mediaPanel').bounding_box()['width']==42
 q('#collapseMedia').click()
 # Save project is a real JSON download; restored sample media and track edits work.
 with page.expect_download() as dl:q('#saveProject').click()
 target=Path('/tmp/sceneforge-multitrack.json');dl.value.save_as(target)
 saved=json.loads(target.read_text());assert saved['version']==1
 q('#reset').click();q('#projectFile').set_input_files(str(target));page.wait_for_timeout(300)
 assert len(state()['items'])==len(saved['items'])
 q('#export').click();q('#startExport').click();page.wait_for_timeout(1400);assert 'Hoàn tất' in q('#exportStatus').inner_text();q('#closeExport').click()
 assert not errors,errors
 page.screenshot(path='/tmp/sceneforge-multitrack-desktop.png')
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path='/tmp/sceneforge-multitrack-mobile.png',full_page=True)
 assert not errors,errors
 print('PASS: text timing/style, audio trim/split/fades, undo/redo, transition preview, extract audio, lock track, cross-track drag, edge trim, media modes/collapse, JSON roundtrip, simulated export, mobile. No JS errors.')
 b.close()
