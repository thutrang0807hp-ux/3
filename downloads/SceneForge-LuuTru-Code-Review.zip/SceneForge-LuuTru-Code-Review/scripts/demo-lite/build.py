"""Build the dependency-free editor preview and replace its studio embed."""
from pathlib import Path
import base64,json,re
root=Path(__file__).resolve().parents[2]
preview=root/'preview.html'
s=preview.read_text()
marker='const DEMO_FRAMES='
i=s.index(marker)+len(marker)
frames,_=json.JSONDecoder().raw_decode(s[i:])
video_marker='const DEMO_VIDEO='
video,_=json.JSONDecoder().raw_decode(s[s.index(video_marker)+len(video_marker):])
app_source=(Path(__file__).parent/'app.js').read_text()
if app_source.count('/*__EXTENSIONS__*/')!=1: raise RuntimeError('Editor extensions must be initialized exactly once')
html=(Path(__file__).parent/'template.html').read_text().replace('__FRAMES__',json.dumps(frames)).replace('__VIDEO__',json.dumps(video)).replace('__CSS__',((Path(__file__).parent/'style.css').read_text()+'\n'+(Path(__file__).parent/'reference_skin.css').read_text()+'\n'+(Path(__file__).parent/'screenshot_skin.css').read_text())).replace('__JS__',app_source.replace('/*__EXTENSIONS__*/',(Path(__file__).parent/'enhancements.js').read_text()+'\n'+(Path(__file__).parent/'timeline_modes.js').read_text()+'\n'+(Path(__file__).parent/'interface.js').read_text()+'\n'+(Path(__file__).parent/'workstation.js').read_text()+'\n'+(Path(__file__).parent/'studio_panels.js').read_text()+'\n'+(Path(__file__).parent/'reference_chrome.js').read_text()))
(root/'editor-demo.html').write_text(html)
# A self-contained entry opens a populated project immediately for design review.
showcase=html.replace('</script>', "\ndocument.querySelector('#openSampleEdit').click();\n</script>")
(root/'concat-demo.html').write_text(showcase)
# Keep the existing studio navigation; replace only the final demo payload.
pattern=r"Uint8Array\.from\(atob\('[A-Za-z0-9+/=]+'\),c=>c\.charCodeAt\(0\)\)"
encoded=base64.b64encode(html.encode()).decode()
s,count=re.subn(pattern,"Uint8Array.from(atob('"+encoded+"'),c=>c.charCodeAt(0))",s)
if count!=1: raise RuntimeError(f'Expected one studio embed, found {count}')
preview.write_text(s)
print(f'Built editor-demo.html ({len(html.encode()):,} bytes); refreshed studio embed')
