from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[2])
from browser_controls import controls
from playwright.sync_api import sync_playwright
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path(os.environ.get('SCENEFORGE_EDITOR_PREVIEW','editor-demo.html')).read_text()));page.goto('http://demo.test/')
 q=controls(page)
 state=lambda:page.evaluate('SceneForgeEditor.getState()')
 a,c=state()['items'][:2]
 q('[data-item="'+a['id']+'"]').click();q('[data-item="'+c['id']+'"]').click(modifiers=['Shift']);assert len(state()['selectedIds'])==2
 assert '2 mục đang chọn' in q('#inspector').inner_text()
 q('#batchStart').fill('2');q('#applyBatchStart').click();assert [next(i['start']for i in state()['items']if i['id']==id)for id in [a['id'],c['id']]]==[2,6]
 # Drag both clips by the same distance.
 r=q('[data-item="'+a['id']+'"]').bounding_box();page.mouse.move(r['x']+30,r['y']+20);page.mouse.down();page.mouse.move(r['x']+92,r['y']+20,steps=10);page.mouse.up();positions=[next(i['start']for i in state()['items']if i['id']==id)for id in [a['id'],c['id']]];assert positions[0]>2 and abs(positions[1]-positions[0]-4)<.01,positions
 q('#undo').click();assert [next(i['start']for i in state()['items']if i['id']==id)for id in [a['id'],c['id']]]==[2,6]
 q('#undo').click();q('#duplicate').click();assert len(state()['items'])==5;assert len(state()['selectedIds'])==2
 q('#undo').click();assert len(state()['items'])==3
 q('#delete').click();assert len(state()['items'])==1;q('#undo').click();assert len(state()['items'])==3
 page.keyboard.press('Escape');page.keyboard.press('Control+a');assert len(state()['selectedIds'])==3;page.keyboard.press('Escape');assert not state()['selectedIds']
 # Split all selected items intersected by the playhead; undo restores group.
 q('[data-item="'+a['id']+'"]').click();q('[data-item="'+c['id']+'"]').click(modifiers=['Shift']);page.evaluate('SceneForgeEditor.seek(2)');q('#split').click();assert len(state()['items'])==4;q('#undo').click()
 page.keyboard.press('Escape');page.evaluate('SceneForgeEditor.seek(1.25)');page.keyboard.press('m');assert q('#markerDialog').is_visible();q('#markerLabel').fill('Nhịp vào');q('#saveMarker').click();assert len(state()['markers'])==1
 q('.timelineMarker').click();q('#markerAt').fill('2.5');q('#saveMarker').click();assert state()['markers'][0]['at']==2.5
 page.keyboard.press('ArrowDown');assert state()['time']>2.5;page.keyboard.press('ArrowUp');assert state()['time']<6
 with page.expect_download()as dl:q('#saveProject').click()
 dl.value.save_as('/tmp/sceneforge-batch.json');q('#reset').click();q('#projectFile').set_input_files('/tmp/sceneforge-batch.json');page.wait_for_timeout(200);assert state()['markers'][0]['label']=='Nhịp vào'
 # Repeated reset must not register duplicate extension event handlers.
 for _ in range(3):q('#reset').click()
 q('#newText').click();q('[data-text-preset="title"]').click();q('#undo').click();text=next(i for i in state()['items']if i['kind']=='text');assert text['fontSize']==64
 assert not errors,errors
 print('PASS: Shift selection, batch move/drag/duplicate/delete/split with undo, Ctrl+A/Esc, marker edit/JSON roundtrip, cut navigation, repeat reset without duplicate event handlers.')
 b.close()
