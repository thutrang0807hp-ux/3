(() => {
  "use strict";
  const $ = (s) => document.querySelector(s), $$ = (s) => [...document.querySelectorAll(s)], esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  let counter = 100;
  const uid = () => String(++counter), clone = (o) => JSON.parse(JSON.stringify(o)), clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  let timelineHeaderWidth=128;
  let projectFrame={width:1080,height:1920};
  function validFrame(value){return value&&Number.isFinite(value.width)&&Number.isFinite(value.height)&&value.width>=240&&value.height>=240&&value.width<=3840&&value.height<=3840?{width:Math.round(value.width/2)*2,height:Math.round(value.height/2)*2}:{width:1080,height:1920};}
  function frameDimensions(shortSide=1080){const scale=Math.min(shortSide/Math.min(projectFrame.width,projectFrame.height),3840/Math.max(projectFrame.width,projectFrame.height));return{width:Math.round(projectFrame.width*scale/2)*2,height:Math.round(projectFrame.height*scale/2)*2};}
  function fitStage(){const s=$('#stageWrap');if(!s)return;const padding=getComputedStyle(s),w=s.clientWidth-parseFloat(padding.paddingLeft)-parseFloat(padding.paddingRight),h=s.clientHeight-parseFloat(padding.paddingTop)-parseFloat(padding.paddingBottom),ratio=projectFrame.width/projectFrame.height;$('#stage').style.width=Math.max(1,Math.min(w,h*ratio))+'px';$('#stage').style.height=Math.max(1,Math.min(h,w/ratio))+'px';}
  function tone() {
    const rate = 16e3, len = rate * 12, b = new ArrayBuffer(44 + len * 2), v = new DataView(b), str = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
    str(0, "RIFF");
    v.setUint32(4, 36 + len * 2, true);
    str(8, "WAVE");
    str(12, "fmt ");
    v.setUint32(16, 16, true);
    v.setUint16(20, 1, true);
    v.setUint16(22, 1, true);
    v.setUint32(24, rate, true);
    v.setUint32(28, rate * 2, true);
    v.setUint16(32, 2, true);
    v.setUint16(34, 16, true);
    str(36, "data");
    v.setUint32(40, len * 2, true);
    for (let i = 0; i < len; i++) {
      let t = i / rate, f = [261.63, 329.63, 392, 329.63][Math.floor(t * 2) % 4], env = Math.sin(Math.PI * (t * 2 % 1));
      v.setInt16(44 + i * 2, Math.sin(2 * Math.PI * f * t) * env * 2300, true);
    }
    return URL.createObjectURL(new Blob([b], { type: "audio/wav" }));
  }
  const builtins = () => [...FRAMES.map((poster, i) => ({ id: "sample" + i, name: ["B\xECnh minh", "Con \u0111\u01B0\u1EDDng", "To\xE0n c\u1EA3nh k\u1EBFt"][i] + ".mp4", kind: "video", url: SAMPLE_VIDEO, poster, duration: 12, sourceIn: i * 4, sampleDuration: 4, builtin: true })), { id: "music", name: "Giai \u0111i\u1EC7u m\u1EABu.wav", kind: "audio", url: tone(), duration: 12, builtin: true }];
  let assets = builtins(), tracks = [], items = [], selection = null, time = 0, playing = false, px = 62, filter = "all", snap = true, ripple = false, undo = [], redo = [], lastTick = 0, raf = 0, toastTimer, exportTimer;
  let selectedIds=new Set(), markers=[];
  const nodes = /* @__PURE__ */ new Map();
  const getTrack = (id) => tracks.find((t) => t.id === id), getAsset = (id) => assets.find((a) => a.id === id), selected = () => items.find((i) => i.id === selection), end = (i) => i.start + i.duration, total = () => Math.max(0.2, ...items.map(end));
  const fmt = (t) => {
    t = Math.max(0, t);
    return String(Math.floor(t / 60)).padStart(2, "0") + ":" + (t % 60).toFixed(1).padStart(4, "0");
  };
  function notify(s) {
    $("#toast").textContent = s;
    $("#toast").style.display = "block";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $("#toast").style.display = "none", 2900);
  }
  function snapshot() {
    return clone({ frame:projectFrame,tracks, items, selection, selectedIds:[...selectedIds], markers });
  }
  function remember() {
    undo.push(snapshot());
    if (undo.length > 60) undo.shift();
    redo = [];
  }
  function pause() {
    playing = false;
    $("#play").textContent = "\u25B6";
    $("#play").setAttribute("aria-label", "Ph\xE1t video");
    nodes.forEach((n) => {
      if (n.pause) n.pause();
    });
    decorateTransport();
  }
  function transact(fn) {
    remember();
    fn();
    time = Math.min(time, total());
    render();
  }
  function defaults(kind) {
    return { ...extraDefaults(), mediaIn: 0, speed: 1, volume: 1, opacity: 1, x: 0, y: 0, scale: 1, rotation: 0, fit: "contain", fadeIn: 0, fadeOut: 0, transition: "none", transitionDuration: 0.5, text: "V\u0103n b\u1EA3n c\u1EE7a b\u1EA1n", fontSize: 64, color: "#ffffff", background: "#000000", textBg: false, bold: true, align: "center", textX: 50, textY: 80 };
  }
  function init() {
    pause();
    selectedIds.clear(); markers=[];projectFrame={width:1080,height:1920};
    tracks = [{ id: "v1", kind: "video", name: "Video 1" }, { id: "t1", kind: "text", name: "V\u0103n b\u1EA3n 1" }, { id: "a1", kind: "audio", name: "\xC2m thanh 1" }];
    items = FRAMES.map((p, i) => ({ ...defaults("video"), id: uid(), kind: "video", assetId: "sample" + i, trackId: "v1", name: assets[i].name, start: i * 4, duration: 4, mediaIn: i * 4 }));
    selection = items[0].id;
    time = 0;
    undo = [];
    redo = [];
    render();
  }
  function compatible(kind, t) {
    return t.kind === (kind === "image" ? "video" : kind);
  }
  function findTrack(kind) {
    let t = tracks.find((t2) => compatible(kind, t2) && !t2.locked);
    if (!t) {
      t = { id: uid(), kind: kind === "image" ? "video" : kind, name: (kind === "text" ? "V\u0103n b\u1EA3n" : kind === "audio" ? "\xC2m thanh" : "Video") + " " + (tracks.filter((t2) => compatible(kind, t2)).length + 1) };
      tracks.push(t);
    }
    return t;
  }
  function addAsset(id,trackId=null,at=null){const asset=getAsset(id);if(!asset)return;const target=getTrack(trackId);if(target&&!target.locked&&!compatible(asset.kind,target))insertNewAsset(asset,null,at,true);else insertNewAsset(asset,trackId,at);}
  function addText() {
    transact(() => {
      const t = findTrack("text"), i = { ...defaults("text"), id: uid(), kind: "text", trackId: t.id, name: "V\u0103n b\u1EA3n", text: "C\xE2u chuy\u1EC7n c\u1EE7a b\u1EA1n", start: time, duration: Math.min(4, Math.max(1, total() - time)) };
      if(items.some(x=>x.trackId===i.trackId&&intervalsOverlap(x,i))){const layer=makeMediaTrack("text");addTrackInFront(layer,tracks);i.trackId=layer.id;}
      items.push(i);
      selection = i.id;
    });
  }
  function renderAssets() {
    const query=normalizeText($("#assetSearch")?.value||"");
    const show = assets.filter((a) => (filter === "all" || a.kind === filter)&&normalizeText(a.name).includes(query));
    const assetOrder=$('#assetOrder')?.value;
    if(assetOrder==='name')show.sort((a,b)=>a.name.localeCompare(b.name,'vi'));
    if(assetOrder==='duration')show.sort((a,b)=>a.duration-b.duration);
    $$('[data-rail-kind]').forEach(b=>b.classList.toggle('active',b.dataset.railKind===filter));
    $("#assets").innerHTML = show.map((a) => `<article class="asset" draggable="true" data-asset="${a.id}" tabindex="0"><div>${a.poster ? `<img src="${esc(a.poster)}" alt="">` : `<div class="assetIcon">${a.kind === "audio" ? "\u266B" : "\u25A7"}</div>`}</div><span class="assetName">${esc(a.name)}</span><small>${a.kind === "image" ? "\u1EA2nh" : fmt(a.sampleDuration || a.duration)} \xB7 ${a.missing ? "C\u1EA7n ch\u1ECDn l\u1EA1i t\u1EC7p" : "C\u1EE5c b\u1ED9"}</small><button data-add-asset="${a.id}" aria-label="Th\xEAm ${esc(a.name)}">\uFF0B</button></article>`).join("") || '<p class="hint">Ch\u01B0a c\xF3 t\u01B0 li\u1EC7u lo\u1EA1i n\xE0y.</p>';
  }
  function timeline() {
    const w = Math.max($("#timelineScroll").clientWidth - timelineHeaderWidth, (Math.max(total(),0,...markers.map(m=>m.at)) + 3) * px);
    $("#sequence").style.width = w + timelineHeaderWidth + "px";
    const step = px < 35 ? 5 : px < 70 ? 2 : 1;
    $("#ruler").innerHTML = Array.from({ length: Math.ceil(w / px / step) }, (_, n) => `<span style="left:${n * step * px}px">${fmt(n * step)}</span>`).join("");
    $("#trackCount").textContent = tracks.length;
    $("#tracks").innerHTML = tracks.map((t) => `<div class="trackRow" data-track="${t.id}"><div class="trackTitle"><div class="trackName"><b>${t.kind === "video" ? "\u25A7" : t.kind === "text" ? "\uFF34" : "\u266B"} ${esc(t.name)}</b></div><div class="trackButtons"><button data-track-action="lock" data-id="${t.id}" class="${t.locked ? "active" : ""}" title="Kh\xF3a track">${t.locked ? "\u{1F512}" : "\u2659"}</button><button data-track-action="hide" data-id="${t.id}" class="${t.hidden ? "active" : ""}" title="\u1EA8n track">${t.hidden ? "\u1EA8n" : "Hi\u1EC7n"}</button><button data-track-action="mute" data-id="${t.id}" class="${t.muted ? "active" : ""}" title="T\u1EAFt \xE2m track">${t.muted ? "T\u1EAFt \xE2m" : "\u266B"}</button><button data-track-action="remove" data-id="${t.id}" title="X\xF3a track r\u1ED7ng">\xD7</button></div></div><div class="lane" data-lane="${t.id}" style="background-size:${px}px 100%">${items.filter((i) => i.trackId === t.id).map((i) => {
      const a = getAsset(i.assetId);
      return `<div class="timelineItem ${i.kind} ${selectedIds.has(i.id) ? "selected" : ""}" data-item="${i.id}" style="left:${i.start * px}px;width:${Math.max(6, i.duration * px)}px;opacity:${t.hidden ? 0.4 : 1}" tabindex="0" role="button" aria-label="${esc(i.name)}"><i class="edge left" data-edge="left"></i><i class="edge right" data-edge="right"></i>${a?.poster ? `<img src="${esc(a.poster)}" alt="">` : ""}<span class="itemLabel">${esc(i.kind === "text" ? i.text : i.name)}<br><small>${i.duration.toFixed(1)}s${i.speed !== 1 ? " \xB7 " + i.speed + "\xD7" : ""}</small></span>${i.transition !== "none" ? `<span class="transMarker">\u25C7 ${i.transitionDuration}s</span>` : ""}</div>`;
    }).join("") || '<div class="laneHint">K\xE9o t\u01B0 li\u1EC7u v\xE0o \u0111\xE2y</div>'}</div></div>`).join("");
    $("#summary").textContent = items.length + " m\u1EE5c \xB7 " + fmt(total()) + " \xB7 9:16";
    $("#undo").disabled = !undo.length;
    $("#redo").disabled = !redo.length;
    updateClock();
    enhanceTrackControls();
    drawKeyframeMarkers();
    drawMarkers();
    decorateTimelineControls();
    decorateWorkstationTimeline();
  }
  function field(label, key, value, type = "number", extra = "") {
    return `<div class="field"><label for="prop-${key}">${label}</label><input id="prop-${key}" data-prop="${key}" type="${type}" value="${esc(value)}" ${type === "number" ? 'step="0.1"' : ""} ${extra}></div>`;
  }
  function selectField(label, key, value, opts) {
    return `<div class="field"><label for="prop-${key}">${label}</label><select id="prop-${key}" data-prop="${key}">${opts.map(([v, n]) => `<option value="${v}" ${String(value) === String(v) ? "selected" : ""}>${n}</option>`).join("")}</select></div>`;
  }
  function inspector() {
    const original = selected();
    const i = original ? { ...original, ...evaluateProps(original) } : null;
    if(selectedIds.size>1){renderBatchInspector();return;}
    if (!i) {
      $("#inspector").innerHTML = '<p class="emptyInspector">Ch\u1ECDn video, v\u0103n b\u1EA3n ho\u1EB7c \xE2m thanh tr\xEAn timeline \u0111\u1EC3 m\u1EDF b\u1EA3ng ch\u1EC9nh t\u01B0\u01A1ng \u1EE9ng.<br><br>K\xE9o m\xE9p m\u1EE5c \u0111\u1EC3 c\u1EAFt; k\xE9o gi\u1EEFa m\u1EE5c \u0111\u1EC3 \u0111\u1ED5i v\u1ECB tr\xED.</p>';
      return;
    }
    const t = getTrack(i.trackId);
    let html = `<h3>${esc(i.kind === "text" ? i.text : i.name)}</h3><div class="inspectorType">${i.kind === "text" ? "V\u0102N B\u1EA2N" : i.kind === "audio" ? "\xC2M THANH" : i.kind === "image" ? "H\xCCNH \u1EA2NH" : "VIDEO"} \xB7 ${esc(t.name)}${t.locked ? " \xB7 \u0110ANG KH\xD3A" : ""}</div><div class="pair">${field("B\u1EAFt \u0111\u1EA7u timeline (s)", "start", i.start.toFixed(2), "number", 'min="0"')}${field("\u0110\u1ED9 d\xE0i (s)", "duration", i.duration.toFixed(2), "number", 'min="0.2"')}</div>`;
    if (i.kind === "text") {
      html += `<div class="sectionTitle">N\u1ED9i dung & ki\u1EC3u ch\u1EEF</div><div class="field"><label>N\u1ED9i dung</label><textarea data-prop="text" id="prop-text" maxlength="500">${esc(i.text)}</textarea></div><div class="pair">${field("C\u1EE1 ch\u1EEF (px / 1080)", "fontSize", i.fontSize, "number", 'min="12" max="200"')}${field("M\xE0u ch\u1EEF", "color", i.color, "color")}</div>${selectField("C\u0103n ch\u1EEF", "align", i.align, [["left", "Tr\xE1i"], ["center", "Gi\u1EEFa"], ["right", "Ph\u1EA3i"]])}<label class="checkLabel"><input type="checkbox" data-prop="bold" ${i.bold ? "checked" : ""}> In \u0111\u1EADm</label><label class="checkLabel"><input type="checkbox" data-prop="textBg" ${i.textBg ? "checked" : ""}> N\u1EC1n sau ch\u1EEF</label>${field("M\xE0u n\u1EC1n", "background", i.background, "color")}<div class="pair">${field("Ngang (%)", "textX", i.textX)}${field("D\u1ECDc (%)", "textY", i.textY)}</div><p class="hint">C\xF3 th\u1EC3 k\xE9o ch\u1EEF tr\u1EF1c ti\u1EBFp tr\xEAn khung xem.</p>`;
    } else {
      if (i.kind !== "image") html += `${field("\u0110i\u1EC3m v\xE0o t\u01B0 li\u1EC7u (s)", "mediaIn", i.mediaIn.toFixed(2), "number", 'min="0"')}${selectField("T\u1ED1c \u0111\u1ED9 ph\xE1t", "speed", i.speed, [[0.25, "0,25\xD7"], [0.5, "0,5\xD7"], [1, "1\xD7"], [1.5, "1,5\xD7"], [2, "2\xD7"], [3, "3\xD7"]])}`;
      if (i.kind !== "audio") html += `<div class="sectionTitle">Khung h\xECnh & bi\u1EBFn \u0111\u1ED5i</div>${selectField("C\xE1ch l\u1EA5p khung 9:16", "fit", i.fit, [["contain", "Gi\u1EEF \u0111\u1EE7 khung"], ["cover", "L\u1EA5p \u0111\u1EA7y \xB7 c\u1EAFt m\xE9p"]])}<div class="pair">${field("Ph\xF3ng to (%)", "scale", (i.scale * 100).toFixed(0), "number", 'min="10" max="400"')}${field("Xoay (\xB0)", "rotation", i.rotation)}</div><div class="pair">${field("Ngang (%)", "x", i.x)}${field("D\u1ECDc (%)", "y", i.y)}</div>${field("\u0110\u1ED9 trong su\u1ED1t (%)", "opacity", (i.opacity * 100).toFixed(0), "number", 'min="0" max="100"')}<div class="sectionTitle">Chuy\u1EC3n c\u1EA3nh \u1EDF cu\u1ED1i clip</div>${selectField("Ki\u1EC3u chuy\u1EC3n c\u1EA3nh", "transition", i.transition, [["none", "Kh\xF4ng"], ["dissolve", "Hòa hai hình"], ["fade", "M\u1EDD qua \u0111en"], ["slide", "Tr\u01B0\u1EE3t ngang"], ["wipe", "Qu\xE9t khung"]])}${field("Th\u1EDDi l\u01B0\u1EE3ng chuy\u1EC3n (s)", "transitionDuration", i.transitionDuration, "number", 'min="0.1" max="5"')}<button id="applyTransitions" class="wide">\xC1p d\u1EE5ng cho c\xE1c \u0111i\u1EC3m c\u1EAFt c\xF9ng track</button><p class="hint">\xC1p d\u1EE5ng t\u1EA1i \u0111i\u1EC3m c\u1EAFt gi\u1EEFa hai clip li\u1EC1n nhau tr\xEAn c\xF9ng track. Th\u1EDDi l\u01B0\u1EE3ng \u0111\u01B0\u1EE3c gi\u1EDBi h\u1EA1n theo \u0111\u1ED9 d\xE0i hai clip.</p>`;
      if (i.kind !== "image") html += `<div class="sectionTitle">\xC2m thanh</div>${field("\xC2m l\u01B0\u1EE3ng (%)", "volume", (i.volume * 100).toFixed(0), "number", 'min="0" max="100"')}<div class="pair">${field("V\xE0o d\u1EA7n (s)", "fadeIn", i.fadeIn, "number", 'min="0"')}${field("Ra d\u1EA7n (s)", "fadeOut", i.fadeOut, "number", 'min="0"')}</div>${i.kind === "video" ? '<button id="extractAudio" class="wide">\u266B T\xE1ch \xE2m thanh sang track ri\xEAng</button>' : ""}`;
    }
    html += enhancedInspector(i);
    html += `<div class="sectionTitle">Thao t\xE1c</div><div class="actions"><button data-command="duplicate">Nh\xE2n \u0111\xF4i</button><button data-command="split">T\xE1ch</button><button data-command="delete">X\xF3a</button></div><p class="hint">Thay \u0111\u1ED5i \xE1p d\u1EE5ng ngay v\xE0o ph\u1EA7n xem tr\u01B0\u1EDBc. Có thể xuất tệp thật bằng bộ ghi trình duyệt; định dạng phụ thuộc codec hỗ trợ.</p>`;
    $("#inspector").innerHTML = html;
    addInspectorNavigation();
  }
  function updateClock() {
    decorateTransport();
    $("#clock").textContent = fmt(time) + " / " + fmt(total());
    $("#seek").max = total();
    $("#seek").value = time;
    $("#playhead").style.left = timelineHeaderWidth + time * px + "px";
  }
  function mediaNode(i) {
    const old = nodes.get(i.id);
    if (old) return old;
    const a = getAsset(i.assetId);
    let n = document.createElement(i.kind === "text" ? "div" : i.kind === "image" ? "img" : i.kind === "audio" ? "audio" : "video");
    if (i.kind === "text") {
      n.className = "textLayer";
      n.dataset.textItem = i.id;
    } else if (i.kind !== "audio") {
      n.className = "visualLayer";
      if (i.kind === "video") {
        n.playsInline = true;
        n.preload = "auto";
        n.poster = a?.poster || FRAMES[0];
      }
    }
    if (i.kind !== "text" && a?.url) {
      n.src = a.url;
      if(i.kind==='video'||i.kind==='audio')n.addEventListener('loadedmetadata',()=>{
        const current=items.find(x=>x.id===i.id);if(!current||time>=current.start||!Number.isFinite(n.duration))return;
        n.currentTime=clamp(current.mediaIn,0,Math.max(0,n.duration-.04));
      },{once:true});
    }
    $("#stageLayers").append(n);
    n.onerror = () => {
      if (!n.dataset.warned) {
        n.dataset.warned = "1";
        notify("Kh\xF4ng \u0111\u1ECDc \u0111\u01B0\u1EE3c " + i.name + ". H\xE3y nh\u1EADp l\u1EA1i t\u1EC7p t\u01B0 li\u1EC7u.");
      }
    };
    nodes.set(i.id, n);
    return n;
  }
  function renderStage() {
    for (const [id, n] of nodes) {
      if (!items.some((i) => i.id === id)) {
        if (n.pause) n.pause();
        releaseAudioRoute(n);n.remove();
        nodes.delete(id);
      }
    }
    // Preview decodes active/nearby media only; export preflight still resolves every source.
    updateStage(true);
  }
  // A dissolve has two simultaneously visible sources around the cut.
  let dissolveFrame=new Map();
  function prepareDissolveFrame(){
    dissolveFrame=new Map();const lanes=new Map();
    for(const i of items)if(['video','image'].includes(i.kind)){if(!lanes.has(i.trackId))lanes.set(i.trackId,[]);lanes.get(i.trackId).push(i);}
    for(const row of lanes.values()){
      row.sort((a,b)=>a.start-b.start);
      for(let n=0;n<row.length-1;n++){
        const a=row[n],b=row[n+1];if(!['dissolve','slide','wipe'].includes(a.transition)||Math.abs(b.start-end(a))>=.001)continue;
        const d=Math.min(5,a.transitionDuration,a.duration,b.duration),join=end(a);
        if(time>=join-d/2&&time<join+d/2){const window={a,b,d,progress:transitionCurve(clamp((time-join+d/2)/d,0,1),a.transitionEasing)};dissolveFrame.set(a.id,window);dissolveFrame.set(b.id,window);}
      }
    }
  }
  function dissolveWindow(i){return dissolveFrame.get(i.id)||null;}
  function clipActive(i) {const at=time===total()?Math.max(0,time-.00001):time;return (at>=i.start&&at<end(i))||!!dissolveWindow(i);}
  function sourceTime(i) {const raw=i.mediaIn+(time-i.start)*i.speed,d=getAsset(i.assetId)?.duration||Infinity;return clamp(raw,0,Math.max(0,d-.04));}
  function transitionAudioGain(i) {const w=dissolveWindow(i);return w?(i.id===w.a.id?1-w.progress:w.progress):1;}
  function transitionCurve(p,curve){return curve==='easeIn'?p*p:curve==='easeOut'?1-(1-p)*(1-p):curve==='easeInOut'?p*p*(3-2*p):p;}
  function transitionState(i) {
    const dissolve=dissolveWindow(i);
    if(dissolve){
      const incoming=i.id===dissolve.b.id,p=dissolve.progress,type=dissolve.a.transition,dir=dissolve.a.transitionDirection||'left';
      const out={opacity:1,dx:0,dy:0,clip:'none'};
      if(type==='dissolve')out.opacity=incoming?p:1;
      if(type==='slide'){const amount=incoming?1-p:-p,sign=['left','up'].includes(dir)?1:-1;if(['left','right'].includes(dir))out.dx=amount*100*sign;else out.dy=amount*100*sign;}
      if(type==='wipe'&&incoming){const hidden=(1-p)*100;out.clip=dir==='left'?`inset(0% 0% 0% ${hidden}%)`:dir==='right'?`inset(0% ${hidden}% 0% 0%)`:dir==='up'?`inset(${hidden}% 0% 0% 0%)`:`inset(0% 0% ${hidden}% 0%)`;}
      return out;
    }
    const tr = items.filter((x) => x.trackId === i.trackId && x.id !== i.id && x.kind !== "text" && x.kind !== "audio");
    const next = tr.find((x) => Math.abs(x.start - end(i)) < 0.04), prev = tr.find((x) => Math.abs(end(x) - i.start) < 0.04);
    let out = { opacity: 1, dx: 0, dy:0, clip: "none" };
    const effect = (type, d, phase) => {
      if (type === "fade") out.opacity *= phase;
      else if (type === "slide") out.dx += (1 - phase) * 100;
      else if (type === "wipe") out.clip = `inset(0 ${(1 - phase) * 100}% 0 0)`;
    };
    if (next && i.transition !== "none") {
      let d = Math.min(i.transitionDuration, i.duration, next.duration);
      if (time > end(i) - d / 2) effect(i.transition, d, clamp((end(i) - time) / (d / 2), 0, 1));
    }
    if (prev && prev.transition !== "none") {
      let d = Math.min(prev.transitionDuration, prev.duration, i.duration);
      if (time < i.start + d / 2) effect(prev.transition, d, clamp((time - i.start) / (d / 2), 0, 1));
    }
    return out;
  }
  function updateStage(force = false) {
    prepareDissolveFrame();
    const ordered = [...items].sort((a, b) => {
      if (a.kind === "text" && b.kind !== "text") return 1;
      if (b.kind === "text" && a.kind !== "text") return -1;
      return tracks.findIndex((t) => t.id === b.trackId) - tracks.findIndex((t) => t.id === a.trackId) || a.start-b.start;
    });
    ordered.forEach((i, z) => {
      const t=getTrack(i.trackId),active=trackVisible(t)&&clipActive(i);
      let n=nodes.get(i.id);
      // Creating hundreds of hidden video decoders blocked clip selection/drag.
      if(!n&&!active&&!(['video','audio'].includes(i.kind)&&i.start>time&&i.start-time<=3))return;
      n=n||mediaNode(i);const values=evaluateProps(i);
      if (i.kind !== "audio") n.style.display = active ? "block" : "none";
      if (!active) {
        if (n.pause) routeAudioVolume(i,n,false);
        if (n.pause && !n.paused) n.pause();
        if(!recording&&n.pause&&(end(i)<time-2||i.start>time+4)){
          releaseAudioRoute(n);n.removeAttribute('src');n.load();n.remove();nodes.delete(i.id);return;
        }
        // Keep future sources at their trimmed entry frame before a cut arrives.
        if (n.currentTime!==undefined&&time<i.start&&n.readyState>=1&&!n.seeking&&Math.abs(n.currentTime-i.mediaIn)>.04) {
          try{n.currentTime=Math.min(i.mediaIn,Math.max(0,(getAsset(i.assetId)?.duration||0)-.04));}catch{}
        }
        return;
      }
      n.style.zIndex = z;
      if (i.kind === "text") {
        styleTextPreview(n, i, values);
        n.textContent = animatedText(i);
        n.style.left = values.textX + "%";
        n.style.top = values.textY + "%";
        n.style.fontSize = i.fontSize / projectFrame.width * 100 + "cqw";
        n.style.color = i.color;
        n.style.background = i.textBg ? i.background : "transparent";
        n.style.padding = i.textBg ? ".4cqw .8cqw" : "0";
        n.style.fontWeight = i.bold ? "750" : "400";
        n.style.textAlign = i.align;
        n.classList.toggle("chosen", i.id === selection);
        return;
      }
      if (i.kind !== "audio") {
        const effect = transitionState(i);
        n.style.objectFit = i.fit;
        n.style.opacity = values.opacity * effect.opacity;
        n.style.filter = visualFilter(i,$("#stage").clientWidth/1080);
        n.style.transform = `translate(${values.x + effect.dx}%,${values.y + effect.dy}%) rotate(${values.rotation}deg) scale(${values.scale * (i.flipX ? -1 : 1)},${values.scale * (i.flipY ? -1 : 1)})`;
        n.style.clipPath = effect.clip;
      }
      if (n.currentTime !== void 0) {
        const target = sourceTime(i);
        if (force || Math.abs(n.currentTime - target) > 0.22) {
          try {
            n.currentTime = target;
          } catch {
          }
        }
        n.playbackRate = i.speed;
        const elapsed = Math.max(0,time - i.start), remaining = Math.max(0,end(i) - time);
        let fade = Math.min(1, i.fadeIn > 0 ? elapsed / i.fadeIn : 1, i.fadeOut > 0 ? remaining / i.fadeOut : 1);
        n.volume = clamp(values.volume * fade * transitionAudioGain(i), 0, 1);
        n.muted = !!t.muted || !!i.audioMuted || values.volume === 0;
        routeAudioVolume(i,n,true);
        if (playing && sourceTime(i) === i.mediaIn+(time-i.start)*i.speed && n.paused && !n.dataset.playPending) {
          n.dataset.playPending = "1";
          n.play().catch(() => {
          }).finally(() => delete n.dataset.playPending);
        } else if ((!playing || sourceTime(i) !== i.mediaIn+(time-i.start)*i.speed) && !n.paused) n.pause();
      }
    });
    updateClock();
  }
  function render() {
    fitStage();
    syncSelection();
    renderAssets();
    timeline();
    inspector();
    renderStage();
    scheduleDraft();
    decorateEditorControls();
  }
  function choose(id, seek = false, add=false, preserve=false) {
    if(!id) selectedIds.clear();
    else if(add) selectedIds.add(id);
    else if(!(preserve&&selectedIds.has(id))) selectedIds=new Set([id]);
    selection = id;
    const i = selected();
    if (seek && i) {
      time = i.start;
      pause();
    }
    $$(".timelineItem").forEach((e) => e.classList.toggle("selected", selectedIds.has(e.dataset.item)));
    updateSelectionSummary();
    inspector();
    $("#inspector").scrollTop = 0;
    updateStage(true);
  }
  function togglePlay() {
    if (playing) {
      pause();
      return;
    }
    if (time >= total() - 0.02) time = 0;
    prepareExportAudio().catch(()=>notify('Không khởi tạo được bộ xử lý âm thanh trên trình duyệt này.'));
    playing = true;
    lastTick = performance.now();
    $("#play").textContent = "\u275A\u275A";
    $("#play").setAttribute("aria-label", "T\u1EA1m d\u1EEBng");
    updateStage(true);
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(tick);
  }
  function tick(now) {
    if (!playing) return;
    time += Math.min(0.1, (now - lastTick) / 1e3);
    lastTick = now;
    if (time >= total()) {
      time = total();
      pause();
    }
    updateStage();
    if (playing) raf = requestAnimationFrame(tick);
  }
  function allowEdit() {
    const i = selected();
    if (!i) {
      notify("Ch\u1ECDn m\u1ED9t m\u1EE5c tr\xEAn timeline.");
      return false;
    }
    if (getTrack(i.trackId).locked) {
      notify("Track \u0111ang kh\xF3a. M\u1EDF kh\xF3a \u0111\u1EC3 ch\u1EC9nh s\u1EEDa.");
      return false;
    }
    return true;
  }
  const commands = { undo() {
    if (!undo.length) return;
    pause();
    redo.push(snapshot());
    const h = undo.pop();
    projectFrame=validFrame(h.frame);
    tracks = h.tracks;
    items = h.items;
    selection = h.selection;
    selectedIds=new Set(h.selectedIds||[selection].filter(Boolean));markers=h.markers||[];
    render();
  }, redo() {
    if (!redo.length) return;
    pause();
    undo.push(snapshot());
    const h = redo.pop();
    projectFrame=validFrame(h.frame);
    tracks = h.tracks;
    items = h.items;
    selection = h.selection;
    selectedIds=new Set(h.selectedIds||[selection].filter(Boolean));markers=h.markers||[];
    render();
  }, split() {
    if(selectedIds.size>1)return batchCommand("split");
    if (!allowEdit()) return;
    const i = selected(), offset = time - i.start;
    if (offset < 0.2 || i.duration - offset < 0.2) {
      notify("\u0110\u01B0a v\u1EA1ch ph\xE1t v\xE0o gi\u1EEFa m\u1EE5c c\u1EA7n t\xE1ch.");
      return;
    }
    transact(() => {
      let n = { ...clone(i), id: uid(), start: time, duration: i.duration - offset, mediaIn: i.mediaIn + offset * i.speed, fadeIn: 0 };
      splitItemKeyframes(i,n,offset);
      i.duration = offset;
      i.transition = "none";
      i.fadeOut = 0;
      items.push(n);
      selection = n.id;
    });
  }, duplicate() {
    if(selectedIds.size>1)return batchCommand("duplicate");
    if (!allowEdit()) return;
    transact(() => {
      const i = selected(), at = end(i), n = { ...clone(i), id: uid(), start: at };
      items.filter((x) => x.id !== i.id && x.trackId === i.trackId && x.start >= at).forEach((x) => x.start += i.duration);
      items.push(n);
      selection = n.id;
    });
  }, delete() {
    if(selectedIds.size>1)return batchCommand("delete");
    if (!allowEdit()) return;
    transact(() => {
      const i = selected();
      items = items.filter((x) => x.id !== i.id);
      if (ripple) items.filter((x) => x.trackId === i.trackId && x.start >= end(i)).forEach((x) => x.start = Math.max(0, x.start - i.duration));
      tracks=compactTimelineTracks(items,tracks);
      selection = null;
    });
  } };
  ["undo", "redo", "split", "duplicate", "delete"].forEach((k) => $("#" + k).onclick = commands[k]);
  $("#inspector").onclick = (e) => {
    let c = e.target.closest("[data-command]");
    if (c) {
      commands[c.dataset.command]();
      return;
    }
    if (e.target.id === "applyTransitions") {
      if (!allowEdit()) return;
      transact(() => {
        const i = selected(), siblings = items.filter((x) => x.trackId === i.trackId);
        siblings.forEach((x) => {
          if (siblings.some((n) => n.id !== x.id && Math.abs(n.start - end(x)) < 0.04)) {
            x.transition = i.transition;
            x.transitionDirection=i.transitionDirection;x.transitionEasing=i.transitionEasing;
            x.transitionDuration = Math.min(i.transitionDuration, x.duration);
          }
        });
      });
      notify("\u0110\xE3 \xE1p d\u1EE5ng chuy\u1EC3n c\u1EA3nh \u1EDF c\xE1c \u0111i\u1EC3m c\u1EAFt li\u1EC1n nhau.");
      return;
    }
    if (e.target.id === "extractAudio") {
      if (!allowEdit()) return;
      transact(() => {
        const i = selected();
        let t = tracks.find((t2) => t2.kind === "audio" && !t2.locked && !items.some((x) => x.trackId === t2.id && x.start < end(i) && end(x) > i.start));
        if (!t) {
          t = { id: uid(), kind: "audio", name: "\xC2m thanh " + (tracks.filter((t2) => t2.kind === "audio").length + 1) };
          tracks.push(t);
        }
        i.linkGroup=i.linkGroup||uid();
        items.push({ ...clone(i), id: uid(), kind: "audio", trackId: t.id, transition: "none", name: i.name + " \xB7 \xE2m thanh" });
        i.volume = 0;
      });
      notify("\u0110\xE3 t\xE1ch \xE2m thanh; clip g\u1ED1c \u0111\xE3 t\u1EAFt ti\u1EBFng.");
    }
  };
  function setProp(el) {
    if (!allowEdit()) {
      inspector();
      return;
    }
    const i = selected(), key = el.dataset.prop, oldItem=clone(selected());
    let value = el.type === "checkbox" ? el.checked : ["text", "color", "background", "align", "fit", "transition", "look", "fontFamily", "textAnimation", "outlineColor"].includes(key) ? el.value : Number(el.value);
    if (typeof value === "number" && !Number.isFinite(value)) return;
    if(key==="speed"){applyPlaybackSpeed(i,Number(value));return;}
    if (key !== "start"&&key!=="duration"&&(key !== "text" || !el.dataset.undoSaved)) remember();
    if (["scale", "opacity", "volume"].includes(key)) value /= 100;
    const limits = { start: [0, 3600], duration: [0.2, 3600], mediaIn: [0, 3600], speed: [0.25, 3], scale: [0.1, 4], opacity: [0, 1], volume: [0, 20], fontSize: [12, 200], textX: [0, 100], textY: [0, 100], x: [-100, 100], y: [-100, 100], rotation: [-360, 360], transitionDuration: [0.1, 5], fadeIn: [0, i.duration], fadeOut: [0, i.duration] };
    if (limits[key]) value = clamp(value, ...limits[key]);
    if(key==="start"||key==="duration"){applyNumericPlacement(i,key,value);return;}
    i[key] = sanitizeExtraProp(key, value);
    updateKeyframedProp(i, key, i[key]);
    const a = getAsset(i.assetId);
    if (a && i.kind !== "image") {
      i.mediaIn = clamp(i.mediaIn, 0, Math.max(0, a.duration - 0.2 * i.speed));
      i.duration = Math.max(0.2, Math.min(i.duration, (a.duration - i.mediaIn) / i.speed));
    }
    if(key==="duration"&&oldItem.keyframes?.length)retimeTrimmedKeyframes(i,oldItem,0);
    i.fadeIn = Math.min(i.fadeIn, i.duration);
    i.fadeOut = Math.min(i.fadeOut, i.duration);
    i.transitionDuration = Math.min(i.transitionDuration, i.duration,items.find(x=>x.id!==i.id&&x.trackId===i.trackId&&Math.abs(x.start-end(i))<.001)?.duration||i.duration);
    if(key==="mediaIn")repairTimingChange(i,oldItem);
    time = Math.min(time, total());
    timeline();
    updateStage(true);
    scheduleDraft();
    if (el.tagName !== "TEXTAREA") inspector();
  }
  $("#inspector").addEventListener("change", (e) => {
    if (e.target.dataset.prop) setProp(e.target);
  });
  $("#inspector").addEventListener("focusin", (e) => {
    if (e.target.dataset.prop === "text") delete e.target.dataset.undoSaved;
  });
  $("#inspector").addEventListener("input", (e) => {
    if (e.target.dataset.prop === "text") {
      const i = selected();
      if (i && !getTrack(i.trackId).locked) {
        if (!e.target.dataset.undoSaved) {
          remember();
          e.target.dataset.undoSaved = "1";
        }
        i.text = e.target.value;
        updateStage();
      }
    }
  });
  function snapped(n, exclude) {
    if (!snap) return Math.max(0, n);
    let points = [0, time, ...markers.map(m=>m.at), ...items.filter((i) => i.id !== exclude && !(selectedIds.size>1&&selectedIds.has(i.id))).flatMap((i) => [i.start, end(i)])], best = n, distance = 8 / px;
    for (let p of points) if (Math.abs(p - n) < distance) { best = p; distance = Math.abs(p - n); }
    return Math.max(0, best);
  }
  let suppressClick = false;
  $("#tracks").addEventListener("pointerdown",e=>{
    if(e.button!==0||e.target.closest('button,input,select,textarea'))return;
    const cell=e.target.closest('[data-item]');if(!cell)return;
    const clip=items.find(i=>i.id===cell.dataset.item),edge=e.target.dataset.edge;
    choose(clip.id,false,e.shiftKey,selectedIds.has(clip.id)&&selectedIds.size>1&&!edge);
    const ids=new Set(selectedIds),members=items.filter(i=>ids.has(i.id));
    if(members.some(i=>getTrack(i.trackId).locked)){notify('Mở khóa track trước khi kéo clip.');return;}
    e.preventDefault();pause();
    const baseline=clone(items),baseTracks=clone(tracks),old=clone(clip),x=e.clientX,y=e.clientY,layerId=uid(),priorRedo=redo.slice(),mode=timelineEditMode,initialScrollLeft=$('#timelineScroll').scrollLeft;
    const snapPoints=[0,time,...markers.map(m=>m.at),...baseline.filter(i=>!ids.has(i.id)).flatMap(i=>[i.start,end(i)])];
    let moved=false,lastPlan=null,dragFrame=0,pendingMove=null,finished=false;
    // Capture on a stable ancestor; a clip may cross lanes without losing the gesture.
    const capture=$('#timelineScroll');
    capture.setPointerCapture(e.pointerId);
    const paintMove=v=>{
      if(!moved&&Math.abs(v.clientX-x)+Math.abs(v.clientY-y)<3)return;
      if(!moved){remember();moved=true;suppressClick=true;beginClipDrag(ids,baseline,x,y,!!edge);activeClipDrag.cancel=cancelDrag;}
      const scroll=$('#timelineScroll'),bounds=scroll.getBoundingClientRect();
      if(v.clientY>bounds.bottom-20)scroll.scrollTop+=12;else if(v.clientY<bounds.top+20)scroll.scrollTop-=12;
      if(v.clientX>bounds.right-30)scroll.scrollLeft+=14;else if(v.clientX<bounds.left+150)scroll.scrollLeft-=14;
      let delta=(v.clientX-x+scroll.scrollLeft-initialScrollLeft)/px;
      let desired=Math.max(0,old.start+delta);
      if(snap){const closest=snapPoints.reduce((best,p)=>Math.abs(p-desired)<Math.abs(best-desired)?p:best,desired+9/px);if(Math.abs(closest-desired)<8/px)desired=closest;}
      const hit=document.elementFromPoint(v.clientX,v.clientY),blank=!edge?hit?.closest('#newLayerDrop'):null;
      const boundary=!edge?(locateTrackBoundary(v.clientX,v.clientY)||(blank?{index:baseTracks.length,y:blank.getBoundingClientRect().top+12}:null)):null;
      const rulerBottom=$('#ruler').getBoundingClientRect().bottom;
      if(!edge&&(v.clientX<bounds.left+timelineHeaderWidth-5||v.clientX>bounds.right||v.clientY<rulerBottom-2||v.clientY>bounds.bottom))lastPlan={valid:false,reason:'Thả clip trong timeline.'};
      else if(boundary){if(ids.size>1){delta=clamp(desired-old.start,-Math.min(...members.map(i=>i.start)),3600-Math.max(...members.map(i=>i.start)));lastPlan=planGroupMove(baseline,baseTracks,[...ids],delta,'layer',layerId);}else lastPlan=planSingleMove(baseline,baseTracks,old.id,old.trackId,desired,desired,'layer',layerId);lastPlan=placePlannedTracksAtBoundary(lastPlan,baseTracks,boundary);}
      else if(edge){if(snap){const base=edge==='left'?old.start:end(old),desiredEdge=base+delta,nearest=snapPoints.reduce((best,p)=>Math.abs(p-desiredEdge)<Math.abs(best-desiredEdge)?p:best,desiredEdge+9/px);if(Math.abs(nearest-desiredEdge)<8/px)delta=nearest-base;}lastPlan=planTrim(baseline,baseTracks,old.id,edge,delta);}
      else if(ids.size>1){delta=clamp(desired-old.start,-Math.min(...members.map(i=>i.start)),3600-Math.max(...members.map(i=>i.start)));const target=hit?.closest('[data-lane]')?.dataset.lane||old.trackId;const lane=hit?.closest('[data-lane]');const pointerTime=lane?(v.clientX-lane.getBoundingClientRect().left)/px:desired;lastPlan=planGroupMove(baseline,baseTracks,[...ids],delta,mode,layerId,target,old.trackId,pointerTime);}
      else{const lane=hit?.closest('[data-lane]')||$('[data-lane="'+old.trackId+'"]');const target=lane?.dataset.lane||old.trackId,pointerTime=lane?Math.max(0,(v.clientX-lane.getBoundingClientRect().left)/px):desired;lastPlan=planSingleMove(baseline,baseTracks,old.id,target,desired,pointerTime,blank?'layer':mode,layerId);}
      if(activeClipDrag){activeClipDrag.pointer=v;activeClipDrag.desired=desired;activeClipDrag.sequenceTop=$('#sequence').getBoundingClientRect().top;}
      paintDragPlan(lastPlan,ids,baseline);
    };
    const finish=v=>{
      if(finished)return;finished=true;
      if(pendingMove&&v.type!=='pointercancel')paintMove(pendingMove);
      cancelAnimationFrame(dragFrame);pendingMove=null;
      window.removeEventListener('keydown',cancelKey,true);window.removeEventListener('blur',cancelDrag);
      capture.removeEventListener('pointermove',move);capture.removeEventListener('pointerup',finish);capture.removeEventListener('pointercancel',finish);
      if(capture.hasPointerCapture(e.pointerId))capture.releasePointerCapture(e.pointerId);
      endClipDrag();hideDropGuide();
      if(!moved)return;
      if(v.type==='pointercancel'||!lastPlan?.valid){items=baseline;tracks=baseTracks;undo.pop();redo=priorRedo;if(lastPlan&&!lastPlan.valid)notify(lastPlan.reason);}
      else{items=lastPlan.items;tracks=compactTimelineTracks(items,lastPlan.tracks);const changed=JSON.stringify(items)!==JSON.stringify(baseline)||JSON.stringify(tracks)!==JSON.stringify(baseTracks);if(!changed){undo.pop();redo=priorRedo;}scheduleDraft();}
      render();setTimeout(()=>suppressClick=false,30);
    };
    const frame=()=>{dragFrame=0;if(!pendingMove)return;paintMove(pendingMove);const b=$('#timelineScroll').getBoundingClientRect(),v=pendingMove;if(moved&&(v.clientX>b.right-30||v.clientX<b.left+150||v.clientY>b.bottom-20||v.clientY<b.top+20))dragFrame=requestAnimationFrame(frame);};
    const move=v=>{pendingMove={clientX:v.clientX,clientY:v.clientY};if(!dragFrame)dragFrame=requestAnimationFrame(frame);};
    const cancelDrag=()=>finish({type:'pointercancel'});
    const cancelKey=v=>{if(v.key==='Escape'){v.preventDefault();v.stopImmediatePropagation();cancelDrag();}};
    window.addEventListener('keydown',cancelKey,true);window.addEventListener('blur',cancelDrag);
    capture.addEventListener('pointermove',move);capture.addEventListener('pointerup',finish);capture.addEventListener('pointercancel',finish);
  });
  $("#tracks").onclick = (e) => {
    if (suppressClick) return;
    const b = e.target.closest("[data-item]");
    if (b) {
      choose(b.dataset.item,false,e.shiftKey,true);
      return;
    }
    const a = e.target.closest("[data-track-action]");
    if (a) {
      const t = getTrack(a.dataset.id), action = a.dataset.trackAction;
      if (action === "remove") {
        if (items.some((i) => i.trackId === t.id)) {
          notify("X\xF3a ho\u1EB7c chuy\u1EC3n c\xE1c m\u1EE5c tr\u01B0\u1EDBc khi x\xF3a track.");
          return;
        }
        transact(() => tracks = tracks.filter((x) => x !== t));
        return;
      }
      transact(() => t[{ hide: "hidden", lock: "locked", mute: "muted" }[action]] = !t[{ hide: "hidden", lock: "locked", mute: "muted" }[action]]);
      return;
    }
    const lane = e.target.closest("[data-lane]");
    if (lane) {
      pause();
      time = clamp((e.clientX - lane.getBoundingClientRect().left) / px, 0, total());
      choose(null);
      updateStage(true);
    }
  };
  function scrub(e) {
    const r = $("#ruler").getBoundingClientRect();
    time = clamp((e.clientX - r.left) / px, 0, total());
    updateStage(true);
  }
  for (const el of [$("#ruler"), $("#playhead")]) el.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    pause();
    el.setPointerCapture(e.pointerId);
    scrub(e);
    const move = (v) => scrub(v), finish = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", finish);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", finish);
  });
  $("#play").onclick = togglePlay;
  $("#jumpStart").onclick = () => {
    pause();
    time = 0;
    updateStage(true);
  };
  $("#seek").oninput = (e) => {
    pause();
    time = +e.target.value;
    updateStage(true);
  };
  $("#safe").onclick = () => $("#safeGuide").hidden = !$("#safeGuide").hidden;
  $("#stageLayers").addEventListener("pointerdown", (e) => {
    const n = e.target.closest("[data-text-item]");
    if (!n) return;
    e.preventDefault();
    choose(n.dataset.textItem);
    if (!allowEdit()) return;
    const i = selected(), r = $("#stage").getBoundingClientRect(), ox = i.textX, oy = i.textY, x = e.clientX, y = e.clientY;
    remember();
    n.setPointerCapture(e.pointerId);
    const move = (v) => {
      i.textX = clamp(ox + (v.clientX - x) / r.width * 100, 0, 100);
      i.textY = clamp(oy + (v.clientY - y) / r.height * 100, 0, 100);
      updateStage();
    };
    n.onpointermove = move;
    n.onpointerup = () => {
      n.onpointermove = null;
      inspector();
    };
  });
  $("#zoom").oninput = (e) => {
    px = +e.target.value;
    timeline();
  };
  $("#fitTimeline").onclick = () => {
    px = clamp(($("#timelineScroll").clientWidth - timelineHeaderWidth - 22) / Math.max(1, total()), 20, 160);
    $("#zoom").value = px;
    timeline();
  };
  $("#snap").onclick = () => {
    snap = !snap;
    $("#snap").textContent = "H\xEDt m\u1ED1c: " + (snap ? "B\u1EADt" : "T\u1EAFt");
    $("#snap").setAttribute("aria-pressed", snap);
  };
  $("#ripple").onclick = () => {
    ripple = !ripple;
    $("#ripple").textContent = "L\u1EA5p kho\u1EA3ng tr\u1ED1ng: " + (ripple ? "B\u1EADt" : "T\u1EAFt");
    $("#ripple").setAttribute("aria-pressed", ripple);
  };
  $("#newTrack").onchange = (e) => {
    if (!e.target.value) return;
    transact(() => {
      const kind = e.target.value;
      tracks.push({ id: uid(), kind, name: { video: "Video", text: "V\u0103n b\u1EA3n", audio: "\xC2m thanh" }[kind] + " " + (tracks.filter((t) => t.kind === kind).length + 1) });
    });
    e.target.value = "";
  };
  $("#newText").onclick = addText;
  $("#reset").onclick = () => { assets = builtins(); init(); };
  $("#mediaMode").onclick = () => $("#mediaPanel").classList.toggle("media-list");
  $("#collapseMedia").onclick = () => {
    document.body.classList.toggle("media-collapsed");
    $("#collapseMedia").textContent = document.body.classList.contains("media-collapsed") ? "\u203A" : "\u2039";
  };
  $("#collapseInspector").onclick = () => {
    document.body.classList.toggle("inspector-collapsed");
    $("#collapseInspector").textContent = document.body.classList.contains("inspector-collapsed") ? "\u2039" : "\u203A";
  };
  $("#mediaTabs").onclick = (e) => {
    const b = e.target.closest("[data-kind]");
    if (!b) return;
    filter = b.dataset.kind;
    $$("#mediaTabs button").forEach((x) => x.classList.toggle("active", x === b));
    renderAssets();
  };
  $("#assets").onclick = (e) => {
    const a = e.target.closest("[data-add-asset]");
    if (a) addAsset(a.dataset.addAsset);
  };
  $("#assets").ondblclick = (e) => {
    let a = e.target.closest("[data-asset]");
    if (a) addAsset(a.dataset.asset);
  };
  $("#assets").ondragstart = (e) => {
    const a = e.target.closest("[data-asset]");
    if (a) e.dataTransfer.setData("application/sceneforge-asset", a.dataset.asset);
  };
  $("#mediaPanel").ondragover = (e) => {
    if (e.dataTransfer.types.includes("Files")) e.preventDefault();
  };
  $("#mediaPanel").ondrop = async (e) => {
    if (!e.dataTransfer.files.length) return;
    e.preventDefault();
    for (const f of e.dataTransfer.files) await importFile(f);
  };
  $("#sequence").ondragover=e=>{if(e.dataTransfer.types.includes('application/sceneforge-asset')||e.dataTransfer.types.includes('Files'))e.preventDefault();};
  $("#sequence").ondrop=async e=>{
    const lane=e.target.closest('[data-lane]'),row=lane||$('#ruler');
    let at=Math.max(0,(e.clientX-row.getBoundingClientRect().left)/px);
    if(e.dataTransfer.files.length){
      e.preventDefault();
      for(const file of e.dataTransfer.files){const asset=await importFile(file,{autoPlace:false});if(!asset)continue;if(lane)addAsset(asset.id,lane.dataset.lane,at);else insertNewAsset(asset,null,at,true,!!e.target.closest('#newLayerDrop'));at+=asset.sampleDuration||asset.duration||5;}
      return;
    }
    const id=e.dataTransfer.getData('application/sceneforge-asset'),asset=getAsset(id);if(!asset)return;e.preventDefault();
    if(lane)addAsset(id,lane.dataset.lane,at);else insertNewAsset(asset,null,at,true,!!e.target.closest('#newLayerDrop'));
  };
  function bindResize(el, fn) {
    el.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      el.setPointerCapture(e.pointerId);
      const move = (v) => fn(v);
      el.addEventListener("pointermove", move);
      const finish = () => {
        el.removeEventListener("pointermove", move);
        timeline();
      };
      el.addEventListener("pointerup", finish, { once: true });
    });
  }
  $$("[data-resize]").forEach((el) => bindResize(el, (e) => {
    let r = $("#workspace").getBoundingClientRect();
    const panel=$(el.dataset.resize==='media'?'#mediaPanel':'#inspectorPanel').getBoundingClientRect();
    const width=panel.left>r.left+r.width/2?panel.right-e.clientX:e.clientX-panel.left;
    document.body.style.setProperty(el.dataset.resize==='media'?'--media':'--inspector',clamp(width,el.dataset.resize==='media'?160:200,420)+'px');
  }));
  bindResize($("#timelineResize"), (e) => {
    document.body.style.setProperty("--timeline", clamp(innerHeight - e.clientY - 7, 190, innerHeight * 0.65) + "px");
  });
  $("#upload").onclick = () => $("#file").click();
  async function importFile(f,options={}) {
    const kind = f.type.split("/")[0];
    if (!["video", "audio", "image"].includes(kind)) {
      notify("Ch\u1ECDn t\u1EC7p video, \xE2m thanh ho\u1EB7c \u1EA3nh.");
      return;
    }
    const url = URL.createObjectURL(f);
    let duration = 5, poster = kind === "image" ? url : null;
    try {
      if (kind !== "image") {
        const n = document.createElement(kind === "audio" ? "audio" : "video");
        n.preload = "metadata";
        n.src = url;
        duration = await new Promise((resolve, reject) => {
          const timer = setTimeout(() => reject(Error("timeout")), 7e3);
          n.onloadedmetadata = () => {
            clearTimeout(timer);
            resolve(n.duration);
          };
          n.onerror = () => {
            clearTimeout(timer);
            reject(Error("decode"));
          };
        });
        if(kind==="video"&&Number.isFinite(duration))poster=await mediaPoster(n,duration);
        n.removeAttribute("src");
        n.load();
        if (!Number.isFinite(duration) || duration < 0.2) throw Error("duration");
      }
      let missing = assets.find((a) => a.missing && a.name === f.name);
      if (missing) {
        activeClipDrag?.cancel?.();
        Object.assign(missing, { url, poster, duration, missing: false });
        nodes.forEach((n, id) => {
          if (items.find((i) => i.id === id)?.assetId === missing.id) {
            if (n.pause) n.pause();
            n.remove();
            nodes.delete(id);
          }
        });
        render();
        notify("\u0110\xE3 n\u1ED1i l\u1EA1i t\u01B0 li\u1EC7u " + f.name);
        return missing;
      }
      const asset = { id: uid(), kind, name: f.name, url, poster, duration };
      assets.push(asset);
      renderAssets();
      if(options.autoPlace!==false)autoPlaceImported(asset);
      if(options.autoPlace===false||$("#importPlacement").value==="library")notify("Đã nhập "+f.name+" vào kho tư liệu.");
      return asset;
    } catch {
      URL.revokeObjectURL(url);
      notify("Kh\xF4ng \u0111\u1ECDc \u0111\u01B0\u1EE3c t\u1EC7p " + f.name + ". Th\u1EED MP4 / WAV / PNG.");
    }
  }
  $("#file").onchange = async (e) => {
    for (const f of e.target.files) await importFile(f);
    e.target.value = "";
  };
  function download(name, data) {
    const url = URL.createObjectURL(new Blob([data], { type: "application/json" })), a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  $("#saveProject").onclick = () => {
    download("sceneforge-project.json", JSON.stringify({ format: "sceneforge-timeline", version: 1, tracks, items, markers, frame:projectFrame,timelineSettings:{mode:timelineEditMode,importPlacement:$("#importPlacement").value}, assets: assets.map(({ url, poster, ...a }) => a) }, null, 2));
    notify("\u0110\xE3 l\u01B0u d\u1EF1 \xE1n JSON. T\u1EC7p tr\xEAn m\xE1y c\u1EA7n nh\u1EADp l\u1EA1i khi m\u1EDF d\u1EF1 \xE1n.");
  };
  $("#openProject").onclick = () => $("#projectFile").click();
  $("#projectFile").onchange = async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    try {
      if (f.size > 2e6) throw Error();
      const p = JSON.parse(await f.text());
      if (p.format !== "sceneforge-timeline" || p.version !== 1 || !Array.isArray(p.tracks) || !Array.isArray(p.items) || !Array.isArray(p.assets) || p.items.length > 300 || p.tracks.length > 30) throw Error();
      const safeTracks = p.tracks.map((t) => {
        if (!["video", "text", "audio"].includes(t.kind) || typeof t.id !== "string" || !/^[\w-]+$/.test(t.id)) throw Error();
        return { solo: !!t.solo, id: t.id, kind: t.kind, name: String(t.name).slice(0, 80), hidden: !!t.hidden, locked: !!t.locked, muted: !!t.muted, height: Number.isFinite(t.height) ? clamp(t.height,48,110) : null };
      });
      const built = builtins();
      const safeAssets = p.assets.map((a) => {
        if (!["video", "audio", "image"].includes(a.kind) || typeof a.id !== "string" || !/^[\w-]+$/.test(a.id) || !Number.isFinite(a.duration) || a.duration < 0.2) throw Error();
        return built.find((b) => b.id === a.id) || { id: a.id, kind: a.kind, name: String(a.name).slice(0, 150), duration: a.duration, url: null, missing: true, workflowKey:typeof a.workflowKey==="string"?a.workflowKey.slice(0,150):null,workflowScene:typeof a.workflowScene==="string"?a.workflowScene.slice(0,150):null,workflowPart:typeof a.workflowPart==="string"?a.workflowPart.slice(0,20):null,workflowSceneIndex:Number.isFinite(a.workflowSceneIndex)?a.workflowSceneIndex:null,workflowVersion:Number.isFinite(a.workflowVersion)?a.workflowVersion:null,newVersion:!!a.newVersion };
      });
      const safeItems = p.items.map((i) => {
        if (!["video", "image", "audio", "text"].includes(i.kind) || typeof i.id !== "string" || !/^[\w-]+$/.test(i.id) || !safeTracks.some((t) => t.id === i.trackId && compatible(i.kind, t)) || !Number.isFinite(i.start) || i.start < 0 || i.start > 3600 || !Number.isFinite(i.duration) || i.duration < 0.2 || i.duration > 3600) throw Error();
        const d = defaults(i.kind), out = { ...d, id: i.id, kind: i.kind, trackId: i.trackId, assetId: i.assetId, name: String(i.name || "M\u1EE5c").slice(0, 150), start: i.start, duration: i.duration };
        if (i.kind !== "text" && !safeAssets.some((a) => a.id === i.assetId)) throw Error();
        for (const key of Object.keys(d)) {
          if (typeof d[key] === "number") {
            if (Number.isFinite(i[key])) out[key] = i[key];
          } else if (typeof d[key] === "boolean") out[key] = !!i[key];
          else if (typeof i[key] === "string") out[key] = i[key].slice(0, 500);
        }
        out.speed = clamp(out.speed, 0.25, 3);
        out.mediaIn = Math.max(0, out.mediaIn);
        out.volume = clamp(out.volume, 0, 20);
        out.opacity = clamp(out.opacity, 0, 1);
        out.scale = clamp(out.scale, 0.1, 4);
        out.transitionDuration = clamp(out.transitionDuration, 0.1, 5);
        out.fit = ["contain", "cover"].includes(out.fit) ? out.fit : "contain";
        out.transition = ["none", "fade", "slide", "wipe", "dissolve"].includes(out.transition) ? out.transition : "none";
        out.align = ["left", "center", "right"].includes(out.align) ? out.align : "center";
        for (const key of ["color", "background"]) if (!/^#[0-9a-f]{6}$/i.test(out[key])) out[key] = d[key];
        sanitizeRestoredExtras(out, i);
        return out;
      });
      if (new Set(safeItems.map((i) => i.id)).size !== safeItems.length || new Set(safeTracks.map((t) => t.id)).size !== safeTracks.length) throw Error();
      activeClipDrag?.cancel?.();
      pause();
      nodes.forEach((n) => {releaseAudioRoute(n);n.remove();});
      nodes.clear();
      assets = safeAssets;
      projectFrame=validFrame(p.frame);
      tracks = safeTracks;
      items = safeItems;
      selection = items[0]?.id;
      selectedIds=new Set([selection].filter(Boolean));
      markers=validateMarkers(p.markers);
      timelineEditMode=Object.hasOwn(editModeNames,p.timelineSettings?.mode)?p.timelineSettings.mode:"insert";$("#timelineEditMode").value=timelineEditMode;
      $("#importPlacement").value=["layer","append","library"].includes(p.timelineSettings?.importPlacement)?p.timelineSettings.importPlacement:"layer";
      counter = Math.max(counter, ...[...assets, ...tracks, ...items, ...markers].map((x) => Number(x.id) || 0));
      time = 0;
      undo = [];
      redo = [];
      render();
      notify(assets.some((a) => a.missing) ? "\u0110\xE3 m\u1EDF d\u1EF1 \xE1n. Nh\u1EADp l\u1EA1i c\xE1c t\u1EC7p g\u1ED1c c\xF9ng t\xEAn \u0111\u1EC3 n\u1ED1i t\u01B0 li\u1EC7u." : "\u0110\xE3 m\u1EDF d\u1EF1 \xE1n");
    } catch {
      notify("T\u1EC7p d\u1EF1 \xE1n kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c v\u01B0\u1EE3t gi\u1EDBi h\u1EA1n.");
    }
    e.target.value = "";
  };
  $("#export").onclick = () => {
    $("#exportInfo").textContent = tracks.length + " track \xB7 " + items.length + " m\u1EE5c \xB7 " + fmt(total());
    refreshExportFormats();
    $("#exportDialog").showModal();
  };
  $("#closeExport").onclick = () => $("#exportDialog").close();
  $("#startExport").onclick = () => {
    let n = 0;
    clearInterval(exportTimer);
    $("#startExport").disabled = true;
    $("#exportStatus").textContent = "\u0110ang m\xF4 ph\u1ECFng gh\xE9p track v\xE0 chuy\u1EC3n c\u1EA3nh\u2026";
    exportTimer = setInterval(() => {
      n += 10;
      $("#exportProgress").value = n;
      if (n >= 100) {
        clearInterval(exportTimer);
        $("#startExport").disabled = false;
        $("#exportStatus").textContent = "Ho\xE0n t\u1EA5t m\xF4 ph\u1ECFng. Ch\u01B0a t\u1EA1o MP4; kh\xF4ng ph\xE1t sinh ph\xED API.";
      }
    }, 120);
  };
  document.addEventListener("keydown", (e) => {
    if (["INPUT", "TEXTAREA", "SELECT"].includes(e.target.tagName) || $('dialog[open]') || e.target.closest('#workstationPopup')) return;
    const mod = e.ctrlKey || e.metaKey;
    if (e.code === "Space") {
      e.preventDefault();
      togglePlay();
    } else if (mod && e.key.toLowerCase() === "b") {
      e.preventDefault();
      commands.split();
    } else if (mod && e.key.toLowerCase() === "z") {
      e.preventDefault();
      commands[e.shiftKey ? "redo" : "undo"]();
    } else if (e.key === "Delete" || e.key === "Backspace") {
      e.preventDefault();
      commands.delete();
    } else if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      e.preventDefault();
      pause();
      time = clamp(time + (e.key === "ArrowLeft" ? -0.1 : 0.1), 0, total());
      updateStage(true);
    }
  });
  new ResizeObserver(fitStage).observe($("#stageWrap"));
  window.SceneForgeEditor = { getState: () => clone({ frame:projectFrame,items, tracks, time, markers, timelineEditMode, selectedIds:[...selectedIds], assets: assets.map(({ url, ...a }) => a) }), seek: (t) => {
    pause();
    time = clamp(t, 0, total());
    updateStage(true);
  } };
  window.addEventListener("message", (e) => { if (e.source === parent && e.data?.type === "sceneforge:pause-preview") pause(); });
  /*__EXTENSIONS__*/
  init();
  booting=false;
  detectDraft();
})();
