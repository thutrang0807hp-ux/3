from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[2])
from playwright.sync_api import sync_playwright
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=Path(os.environ.get('SCENEFORGE_EDITOR_PREVIEW','editor-demo.html')).read_text()));page.goto('http://demo.test/')
 state=lambda:page.evaluate('SceneForgeEditor.getState()')
 def no_overlap():
  s=state()
  for t in s['tracks']:
   row=sorted([i for i in s['items']if i['trackId']==t['id']],key=lambda i:i['start'])
   assert all(a['start']+a['duration']<=c['start']+.001 for a,c in zip(row,row[1:])),row
 def drag(id,at,track='v1'):
  cell=page.locator('[data-item="'+id+'"]').bounding_box();lane=page.locator('[data-lane="'+track+'"]').bounding_box()
  page.mouse.move(cell['x']+20,cell['y']+20);page.mouse.down();page.mouse.move(lane['x']+at*62+20,lane['y']+23,steps=18)
  assert page.locator('#dropGuide').is_visible()
  page.mouse.up();page.wait_for_timeout(50)
 # Default insert: reorder without removing or overlapping another clip.
 a,bid,c=[i['id']for i in state()['items']];drag(a,11)
 assert [i['id']for i in sorted(state()['items'],key=lambda i:i['start'])]==[bid,c,a];no_overlap()
 page.locator('#undo').click();assert next(i for i in state()['items']if i['id']==a)['start']==0
 # Swap preserves identities and the full duration of all clips.
 page.locator('#timelineEditMode').select_option('swap');drag(a,9)
 assert [i['id']for i in sorted(state()['items'],key=lambda i:i['start'])]==[c,bid,a];no_overlap();page.locator('#undo').click()
 # Overwrite cuts the covered source into left/right pieces, with proper source offsets.
 page.locator('#timelineEditMode').select_option('insert');page.locator('[data-item="'+a+'"]').click();page.locator('#prop-duration').fill('1');page.locator('#prop-duration').press('Tab')
 # Numeric trim currently leaves a gap; close it via the existing command.
 page.locator('#closeGaps').click();page.locator('#timelineEditMode').select_option('overwrite');drag(a,5/2)
 s=state();pieces=[i for i in s['items']if i['assetId']=='sample1'];assert len(pieces)==2,pieces;no_overlap()
 # Layer mode creates a distinct track instead of stacking clips on one row.
 page.locator('#reset').click();a=state()['items'][0]['id'];count=len(state()['tracks']);page.locator('#timelineEditMode').select_option('layer');drag(a,2)
 assert len(state()['tracks'])==count+1;assert next(i for i in state()['items']if i['id']==a)['trackId']!='v1';no_overlap();page.locator('#undo').click()
 # Right edge trim in insert mode pushes adjacent clips.
 page.locator('#timelineEditMode').select_option('insert');page.locator('[data-item="'+a+'"]').click();h=page.locator('[data-item="'+a+'"] .edge.right').bounding_box();page.mouse.move(h['x']+3,h['y']+15);page.mouse.down();page.mouse.move(h['x']+65,h['y']+15,steps=10);page.mouse.up();no_overlap();assert next(i for i in state()['items']if i['assetId']=='sample1')['start']>4
 assert not errors,errors
 print('PASS: default insertion/reorder with undo; swap; overwrite preserves trimmed source pieces; new-layer placement; ripple edge trim; no same-track overlaps or JS errors.')
 b.close()
