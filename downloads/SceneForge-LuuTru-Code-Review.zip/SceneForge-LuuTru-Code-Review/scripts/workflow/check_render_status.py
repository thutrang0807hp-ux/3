"""Verify a plain inline error box, legacy-data compatibility and unchanged usage."""
from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import threading,tempfile,subprocess
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory()as tmp:
  for name,size in [('portrait','90x160'),('landscape','160x90')]:
   subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s='+size+':d=1:r=10','-c:v','libx264','-pix_fmt','yuv420p','-y',tmp+'/'+name+'.mp4'],check=True)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1080});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html?mode=reference');page.wait_for_function('!!window.SceneForgeWorkflow');state=lambda:page.evaluate('SceneForgeWorkflow.getState()');first=state()['scenes'][0]['id']
   assert page.locator('[data-task-action],.renderErrorBox').count()==0
   # Existing saved manual failures migrate to an inline message, no task manager.
   page.evaluate('''()=>{const s=project.scenes[0];s.renderTasks={a:[{id:'old-job',status:'error',message:'Flow báo lỗi kết nối.',errorCode:'network',createdAt:1,updatedAt:2}]};save();render();}''')
   expect(page.locator('.renderErrorBox')).to_contain_text('Flow báo lỗi kết nối.');assert page.locator('.renderErrorBox button,[data-task-action]').count()==0
   page.wait_for_timeout(700);page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');expect(page.locator('.renderErrorBox')).to_contain_text('Flow báo lỗi kết nối.');page.locator('[data-approve="'+first+'"]').click();page.locator('[data-prepare="'+first+'"]').click();expect(page.locator('#modalTitle')).to_contain_text('Tạo clip');assert 'Tác vụ'not in page.locator('#modalTitle').inner_text();assert page.locator('[data-task-action]').count()==0;page.locator('[data-action=close-modal]').first.click()
   
   with page.expect_file_chooser()as choice:page.locator('[data-clip-upload="'+first+'"]').first.click()
   choice.value.set_files(tmp+'/landscape.mp4');page.wait_for_function('!!SceneForgeWorkflow.getState().scenes[0].importError');expect(page.locator('.renderErrorBox')).to_contain_text('9:16')
   page.locator('#clipFile').set_input_files(tmp+'/portrait.mp4');page.wait_for_function('SceneForgeWorkflow.getState().scenes[0].clips.length===1');assert page.locator('.renderErrorBox').count()==0;assert state()['scenes'][0]['renderTasks']['a'][0]['id']=='old-job';clip_id=state()['scenes'][0]['chosen']['a']
   page.evaluate('''()=>{project.scenes[0].renderError={message:'Lần tạo thêm bị lỗi.'};save();render();}''');expect(page.locator('.renderErrorBox')).to_contain_text('Lần tạo thêm bị lỗi.');assert state()['scenes'][0]['chosen']['a']==clip_id
   page.locator('[data-action=usage]').click();page.locator('#usageFlow').fill('50');page.locator('#usageAI').fill('10');page.locator('[data-action=usage-save]').click();expect(page.locator('#usageStrip')).to_contain_text('50 credit · tự nhập');page.screenshot(path='/tmp/sceneforge-simple-error.png',full_page=True)
   page.set_viewport_size({'width':390,'height':844});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');expect(page.locator('#usageStrip')).to_be_visible();assert not errors,errors;b.close()
 print('PASS: inline red error only, no task UI/gates, legacy errors survive reload, real import errors visible, successful import clears errors, old clips/history retained, quota unchanged, mobile/no JS errors.')
finally:server.shutdown()
