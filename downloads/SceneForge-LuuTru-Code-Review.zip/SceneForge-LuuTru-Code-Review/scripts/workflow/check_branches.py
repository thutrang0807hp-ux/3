"""Verify independent image/video workspaces, approval gates and persistence."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading,io,json
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1080},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:'+str(server.server_port)+'/workflow.html');page.wait_for_function('!!window.SceneForgeWorkflow');state=lambda:page.evaluate('SceneForgeWorkflow.getState()')
  expect(page.locator('#workflowChooser')).to_be_visible();page.screenshot(path='/tmp/sceneforge-workflow-choice.png',full_page=True)
  page.locator('[data-mode-open=reference]').click();expect(page.locator('#node-source')).to_be_visible();reference_id=state()['id'];page.locator('#projectName').fill('Reference project')
  image=io.BytesIO();Image.new('RGB',(90,160),'red').save(image,format='PNG')
  with page.expect_file_chooser()as choice:page.locator('[data-ref-upload=product]').click()
  choice.value.set_files({'name':'reference-product.png','mimeType':'image/png','buffer':image.getvalue()});page.wait_for_function('SceneForgeWorkflow.getState().refs.product.images.length===1')
  reference_image=state()['refs']['product']['images'][0]['image']
  page.locator('[data-branch=photos]').click();expect(page.locator('#node-brief')).to_be_visible();photo_id=state()['id'];assert photo_id!=reference_id and state()['source']is None and not state()['scenes'] and not state()['refs']['product']['images']
  assert page.locator('#node-source,#node-analysis,#node-scenes,#node-script').count()==0
  page.locator('#projectName').fill('Image project');page.locator('[data-brief=idea]').fill('Video sản phẩm mới, rõ ràng và tự nhiên');page.locator('[data-brief=productInfo]').fill('Chỉ dùng thông tin đã cung cấp.');page.locator('[data-brief=duration]').select_option('16')
  image=io.BytesIO();Image.new('RGB',(90,160),'green').save(image,format='PNG')
  for kind in ['person','product']:
   with page.expect_file_chooser()as choice:page.locator('[data-ref-upload='+kind+']').click()
   choice.value.set_files({'name':kind+'.png','mimeType':'image/png','buffer':image.getvalue()});page.wait_for_function('(k)=>SceneForgeWorkflow.getState().refs[k].images.length===1',arg=kind)
  data={'format':'sceneforge-photo-storyboard','version':1,'scenes':[{'start':0,'end':8,'description':'Cảnh mới từ ảnh người','hasPerson':True,'hasProduct':True,'faceTalking':True,'dialogue':'Câu mở đầu cho video mới.','visual':{'vi':{'composition':'Dọc 9:16'},'en':{'composition':'Portrait 9:16'}},'motion':{'en':{'action':'Introduce the supplied product naturally.'}},'promptFrame':{'vi':'Tạo khung mới từ ảnh người và sản phẩm.','en':'Create a new portrait frame using person and product references.'}},{'start':8,'end':16,'description':'Cảnh sản phẩm mới','hasPerson':False,'hasProduct':True,'dialogue':'Lời ngoài hình cho cảnh sản phẩm.'}]}
  page.locator('[data-action=import-story]').click();page.locator('#analysisFile').set_input_files({'name':'story.json','mimeType':'application/json','buffer':json.dumps(data).encode()});page.wait_for_function('SceneForgeWorkflow.getState().scenes.length===2');assert state()['source']is None and not state()['storyboard']['approved']
  expect(page.locator('[data-approve]').first).to_be_disabled()
  page.locator('[data-action=story-review]').click();page.locator('[data-action=approve-story]').click();assert state()['storyboard']['approved']
  # No source frame is used as an image-generated keyframe.
  first=state()['scenes'][0];page.locator('[data-frame-upload="'+first['id']+'"]').click();page.locator('#frameFile').set_input_files({'name':'keyframe.png','mimeType':'image/png','buffer':image.getvalue()});page.wait_for_function('SceneForgeWorkflow.getState().scenes[0].frames.length===1');page.locator('[data-approve="'+first['id']+'"]').click();assert state()['scenes'][0]['approvedFrame']
  # Editing approved story words invalidates downstream approvals.
  page.locator('[data-action=story-review]').click();page.locator('[data-line]').first.fill('Câu đã sửa cần duyệt lại.');page.locator('[data-action=close-modal]').first.click();assert not state()['storyboard']['approved']and not state()['scenes'][0]['approvedFrame']
  page.locator('[data-action=projects]').first.click();expect(page.locator('#modalTitle')).to_contain_text('Từ ảnh');assert 'Reference project'not in page.locator('#modalContent').inner_text();page.locator('[data-action=close-modal]').first.click()
  page.locator('[data-branch=reference]').click();page.wait_for_function('(id)=>SceneForgeWorkflow.getState().id===id',arg=reference_id);assert state()['id']==reference_id and state()['name']=='Reference project'and state()['refs']['product']['images'][0]['image']==reference_image and len(state()['scenes'])==3
  page.locator('[data-branch=photos]').click();page.wait_for_function('(id)=>SceneForgeWorkflow.getState().id===id',arg=photo_id);assert state()['id']==photo_id and len(state()['scenes'])==2 and state()['source']is None and state()['script'][0]['newText']=='Câu đã sửa cần duyệt lại.'
  page.wait_for_timeout(650);page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');assert state()['mode']=='photos'and state()['id']==photo_id and not page.locator('#workflowChooser').is_visible()
  # Cross-workflow JSON is rejected without partially changing the project.
  before=state()['scenes'];page.locator('#analysisFile').set_input_files({'name':'video-analysis.json','mimeType':'application/json','buffer':json.dumps({'scenes':[{'start':0,'end':16}]}).encode()});expect(page.locator('#toast')).to_contain_text('Không nhập');assert state()['scenes']==before
  page.screenshot(path='/tmp/sceneforge-image-workflow.png',full_page=True)
  page.set_viewport_size({'width':390,'height':844});page.locator('[data-action=choose-workflow]').click();expect(page.locator('#workflowChooser')).to_be_visible();page.screenshot(path='/tmp/sceneforge-workflow-choice-mobile.png',full_page=True);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  assert not errors,errors;b.close()
 print('PASS: separate mode chooser/canvases, no video-source nodes in image mode, independent IDs/images/script/assets, photo storyboard import/approval and invalidation, no original-frame approval, scoped project list, switch/reload isolation, reject cross-mode JSON, mobile/no JS errors.')
finally:server.shutdown();server.server_close();thread.join()
