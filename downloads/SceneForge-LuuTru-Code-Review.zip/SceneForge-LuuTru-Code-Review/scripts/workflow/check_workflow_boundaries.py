"""Check user-facing rejection paths and avoid pretending external services are connected."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading,tempfile,subprocess,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with tempfile.TemporaryDirectory()as temp:
  landscape=Path(temp)/'landscape.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=red:s=160x90:d=1:r=24','-c:v','libx264','-threads','1',str(landscape)],check=True)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1536,'height':1040},accept_downloads=True);errors=[];external=[]
   page.on('pageerror',lambda e:errors.append(str(e)));base='http://127.0.0.1:'+str(server.server_port);page.on('request',lambda r:external.append(r.url)if r.url.startswith(('http:','https:'))and not r.url.startswith(base)else None)
   page.goto(base+'/workflow.html?mode=reference');page.wait_for_function('!!window.SceneForgeWorkflow');state=lambda:page.evaluate('SceneForgeWorkflow.getState()');original=state()
   page.locator('#sourceFile').set_input_files(str(landscape));expect(page.locator('#toast')).to_contain_text('9:16');assert state()['source']==original['source']and state()['scenes']==original['scenes']
   # A later malformed row must not apply an earlier valid row partially.
   data={'scenes':[{'start':s['start'],'end':s['end'],'description':'WOULD CHANGE'}for s in original['scenes']]};data['scenes'][-1]['end']=999
   page.locator('#analysisFile').set_input_files({'name':'invalid.json','mimeType':'application/json','buffer':json.dumps(data).encode()});expect(page.locator('#toast')).to_contain_text('không khớp');assert state()['scenes']==original['scenes']
   page.locator('#scriptFile').set_input_files({'name':'bad.srt','mimeType':'text/plain','buffer':b'1\n00:00:00,000 --> 00:00:30,000\nToo long.\n\n'});expect(page.locator('#toast')).to_contain_text('vượt');assert state()['script']==[]
   page.locator('[data-action=fit]').first.click();page.locator('[data-clip-upload]').first.click();expect(page.locator('#toast')).to_contain_text('duyệt khung');assert not state()['scenes'][0]['clips']
   page.locator('[data-action=review-run]').click();expect(page.locator('#modalContent')).to_contain_text('chưa kết nối');expect(page.locator('#modalContent')).to_contain_text('chưa có giá đã xác minh');page.locator('[data-action=costs]').click();page.locator('[data-cost=lite]').fill('10');page.locator('[data-action=save-costs]').click();expect(page.locator('#runBar')).to_contain_text('30 credit theo mức bạn nhập');expect(page.locator('.connection')).to_contain_text('chưa kết nối')
   # This is an explicit information dialog, not a fake successful AI operation.
   page.locator('.promptExcerpt button').first.click();page.locator('[data-action=ai-help]').click();expect(page.locator('#modalTitle')).to_contain_text('chưa kết nối');page.locator('[data-action=close-modal]').first.click();page.locator('[data-action=close-details]').click()
   with page.expect_download()as dl:page.locator('[data-action=export]').click()
   exported=json.loads(Path(dl.value.path()).read_text());assert exported['format']=='sceneforge-workflow'and exported['project']['scenes']==state()['scenes']and'assetEntries'not in exported['project']
   ready=page.evaluate('SceneForgeWorkflow.getReadiness()');assert ready['localShotDetection']and not ready['aiAnalysis']and not ready['flowAutomation']and not ready['transcription']
   assert not external,external;assert not errors,errors;b.close()
 print('PASS: reject landscape without losing project, reject mismatched AI timeline atomically and out-of-range transcript, gate clip import by frame approval, unknown-vs-manual credit labels, honest AI readiness, actual JSON download; no external/API requests or page errors.')
finally:server.shutdown();server.server_close();thread.join()
