"""Exercise real node UI, local cuts, shared text, references, versions and editor handoff."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading,tempfile,subprocess,json,io
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with tempfile.TemporaryDirectory() as temp:
  source=Path(temp)/'source.mp4';clip=Path(temp)/'clip.mp4'
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=red:s=90x160:d=6:r=24','-f','lavfi','-i','color=blue:s=90x160:d=6:r=24','-filter_complex','[0:v][1:v]concat=n=2:v=1:a=0[v]','-map','[v]','-c:v','libx264','-threads','1',str(source)],check=True)
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=green:s=90x160:d=1:r=24','-f','lavfi','-i','sine=frequency=520:sample_rate=48000:duration=1','-c:a','aac','-shortest','-c:v','libx264','-threads','1',str(clip)],check=True)
  image=io.BytesIO();Image.new('RGB',(90,160),'orange').save(image,format='PNG')
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1080},accept_downloads=True);errors=[];bad=[]
   page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:bad.append(r.url) if r.status>=400 and 'favicon'not in r.url else None)
   page.on('dialog',lambda d:d.accept())
   base='http://127.0.0.1:'+str(server.server_port)+'/'
   page.goto(base+'#analysis');frame=page.frame_locator('#workflowFrame');frame.locator('[data-mode-open=reference]').click();frame.locator('#node-source').wait_for();wf=page.locator('#workflowFrame').content_frame
   state=lambda:wf.locator('body').evaluate('()=>SceneForgeWorkflow.getState()')
   assert len(state()['scenes'])==3 and state()['demo']
   frame.locator('.sceneRow').first.click();expect(frame.locator('#details')).to_be_visible()
   frame.locator('[data-language=en]').click();expect(frame.locator('[data-prompt-key=composition]')).to_contain_text('9:16')
   frame.locator('[data-action=close-details]').click()
   frame.locator('#sourceFile').set_input_files(str(source));wf.locator('body').wait_for();page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().source.name==="source.mp4"')
   frame.locator('[data-action=analyze]').click();page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().analysis.status==="done"',timeout=45000)
   s=state();assert len(s['scenes'])==2,s['analysis'];assert abs(s['scenes'][0]['end']-6)<.1,s['analysis'];assert all(len(x['thumbs'])==3 and x['evidence'] for x in s['scenes']);assert not any(x['visual']['en'].get('person') for x in s['scenes'])
   # A long scene is retained as one scene but divided into <=8-second clip jobs.
   frame.locator('[data-action=timings]').click();frame.locator('[data-end-time="0"]').fill('9.5');frame.locator('[data-action=apply-timings]').click()
   page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes[0].end===9.5')
   expect(frame.locator('#modal')).not_to_be_visible()
   frame.locator('[data-action=script]').first.click()
   frame.locator('#scriptFile').set_input_files({'name':'speech.srt','mimeType':'text/plain','buffer':b'1\n00:00:04,000 --> 00:00:10,000\nBan goc qua hai canh.\n\n'})
   expect(frame.locator('.scriptGrid textarea')).to_have_value('Ban goc qua hai canh.')
   frame.locator('.scriptGrid textarea').fill('Loi moi duoc dung chung.');frame.locator('[data-line-face]').check()
   frame.locator('[data-action=close-modal]').first.click()
   for row in [0,1]:
    frame.locator('.sceneRow').nth(row).click();frame.locator('[data-detail-tab=script]').click();expect(frame.locator('#details [data-line]')).to_have_value('Loi moi duoc dung chung.');frame.locator('[data-action=close-details]').click()
   # Import externally produced analysis only when all scene timings match source.
   s=state();payload={'scenes':[{**{k:x[k] for k in ['start','end']},'description':'Observed test scene','hasPerson':i==0,'hasProduct':False,'visual':{'vi':{'person':'Mot nguoi' if i==0 else 'Khong co nguoi'},'en':{'person':'One person'if i==0 else'No people','composition':'Portrait 9:16 source framing.'}},'motion':{'en':{'action':'Preserve the observed action.'}}}for i,x in enumerate(s['scenes'])]}
   frame.locator('#analysisFile').set_input_files({'name':'analysis.json','mimeType':'application/json','buffer':json.dumps(payload).encode()});page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes[0].aiImported===true')
   frame.locator('[data-ref-upload=person]').click();frame.locator('#referenceFile').set_input_files({'name':'person.png','mimeType':'image/png','buffer':image.getvalue()});page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().refs.person.images.length===1')
   s=state();assert 'person' in s['scenes'][0]['refsUsed'] and 'person' not in s['scenes'][1]['refsUsed']
   # A changed-reference scene cannot approve its unchanged original frame.
   frame.locator('[data-approve="'+s['scenes'][0]['id']+'"]').click();assert not state()['scenes'][0]['approvedFrame']
   frame.locator('[data-frame-upload="'+s['scenes'][0]['id']+'"]').click();frame.locator('#frameFile').set_input_files({'name':'new-frame.png','mimeType':'image/png','buffer':image.getvalue()});page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes[0].frames.length===1')
   # Drag-pan/zoom alter the viewport without changing project contents.
   before=state();frame.locator('[data-action=zoom-in]').click();assert state()['scenes']==before['scenes']
   frame.locator('[data-action=fit]').first.click()
   for scene in state()['scenes']:
    frame.locator('[data-approve="'+scene['id']+'"]').click()
    frame.locator('.sceneRow').nth(scene['index']).click();frame.locator('[data-detail-tab=versions]').click()
    for n,part in enumerate(['a','b'] if scene['end']-scene['start']>8 else ['a']):
     frame.locator('#details [data-clip-upload="'+scene['id']+'"][data-part="'+part+'"]').click();frame.locator('#clipFile').set_input_files(str(clip))
     page.wait_for_function('(args)=>document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes.find(s=>s.id===args[0]).clips.length===args[1]',arg=[scene['id'],n+1])
    frame.locator('[data-action=close-details]').click()
   assert all(not x['expanded'] for x in state()['scenes'])
   # Re-import another version; old file and choice history remain.
   first=state()['scenes'][0];frame.locator('[data-detail="'+first['id']+'"]').click();expect(frame.locator('.versionCard video').first).to_be_visible()
   frame.locator('[data-clip-upload="'+first['id']+'"]').first.click();frame.locator('#clipFile').set_input_files(str(clip));page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes[0].clips.length===3')
   frame.locator('[data-action=close-details]').click();frame.locator('[data-action=fit]').first.click()
   # IndexedDB restores blobs, selected versions, script text and links after reload.
   page.wait_for_timeout(700);page.reload();frame=page.frame_locator('#workflowFrame');wf=page.locator('#workflowFrame').content_frame;frame.locator('#node-source').wait_for();assert len(state()['scenes'][0]['clips'])==3 and state()['script'][0]['newText']=='Loi moi duoc dung chung.'
   page.screenshot(path='/tmp/sceneforge-node-workflow-desktop.png',full_page=True)
   frame.locator('[data-action=fit]').first.click();frame.locator('[data-action=merge]').click();frame.locator('#includeCaptions').check();frame.locator('#confirmMerge').click()
   editor=page.frame_locator('#standaloneEditorDemo');expect(editor.locator('#stage')).to_be_visible();page.wait_for_function('document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.getState().items.some(i=>i.name.includes("giữ khung cuối"))',timeout=30000)
   model=editor.locator('body').evaluate('()=>SceneForgeEditor.getState()');videos=[i for i in model['items']if i['kind']=='video'];stills=[i for i in model['items']if i['kind']=='image'];assert len(videos)==3 and len(stills)==3 and abs(max(i['start']+i['duration']for i in model['items'])-12)<.1;assert any(i['kind']=='text'and i['text']=='Loi moi duoc dung chung.'for i in model['items'])
   assert all(i['volume']==1 for i in videos) and not any(i['kind']=='audio' for i in model['items'])
   editor.locator('#export').click()
   with page.expect_download(timeout=30000)as sound_export:editor.locator('#realExport').click()
   import numpy as np
   pcm=subprocess.check_output(['ffmpeg','-v','error','-i',sound_export.value.path(),'-map','0:a:0','-ar','48000','-ac','1','-f','f32le','-'])
   samples=np.frombuffer(pcm,dtype='<f4')[8000:30000];assert float(np.sqrt(np.mean(samples*samples)))>.01
   editor.locator('#closeExport').click()
   editor.locator('#undo').click();assert len(editor.locator('body').evaluate('()=>SceneForgeEditor.getState().items'))==3
   # Image-only projects can also send their own selected clips into this same editor.
   page.locator('[data-nav=analysis]').click();frame.locator('[data-branch=photos]').click();expect(frame.locator('#node-brief')).to_be_visible()
   frame.locator('[data-brief=duration]').select_option('16')
   with page.expect_file_chooser()as picker:frame.locator('[data-ref-upload=product]').click()
   picker.value.set_files({'name':'photo-product.png','mimeType':'image/png','buffer':image.getvalue()})
   page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().refs.product.images.length===1')
   photo_story={'format':'sceneforge-photo-storyboard','scenes':[{'start':i*8,'end':(i+1)*8,'description':'New image scene '+str(i+1),'hasPerson':False,'hasProduct':True,'dialogue':''}for i in range(2)]}
   frame.locator('#analysisFile').set_input_files({'name':'photo-story.json','mimeType':'application/json','buffer':json.dumps(photo_story).encode()})
   page.wait_for_function('document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes.length===2')
   frame.locator('[data-action=story-review]').click();frame.locator('[data-action=approve-story]').click();frame.locator('[data-action=fit]').first.click()
   for scene in state()['scenes']:
    frame.locator('[data-frame-upload="'+scene['id']+'"]').click();frame.locator('#frameFile').set_input_files({'name':'new-frame.png','mimeType':'image/png','buffer':image.getvalue()})
    page.wait_for_function('(id)=>document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes.find(s=>s.id===id).frames.length===1',arg=scene['id'])
    frame.locator('[data-approve="'+scene['id']+'"]').click();frame.locator('[data-clip-upload="'+scene['id']+'"]').first.click();frame.locator('#clipFile').set_input_files(str(clip))
    page.wait_for_function('(id)=>document.querySelector("#workflowFrame").contentWindow.SceneForgeWorkflow.getState().scenes.find(s=>s.id===id).clips.length===1',arg=scene['id'])
   assert state()['source']is None and state()['mode']=='photos'
   frame.locator('[data-action=merge]').click();frame.locator('#confirmMerge').click()
   page.wait_for_function('document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.getState().items.filter(i=>i.kind==="video").length===2')
   photo_model=editor.locator('body').evaluate('()=>SceneForgeEditor.getState()');assert abs(max(i['start']+i['duration']for i in photo_model['items'])-16)<.1
   editor.locator('#undo').click();assert len(editor.locator('body').evaluate('()=>SceneForgeEditor.getState().items'))==3
   # Existing editor and navigation remain available.
   page.locator('[data-nav=analysis]').click();frame=page.frame_locator('#workflowFrame');frame.locator('[data-branch=reference]').click();frame.locator('.sceneRow').first.click();page.set_viewport_size({'width':390,'height':844});expect(frame.locator('#details')).to_be_visible();page.screenshot(path='/tmp/sceneforge-node-workflow-mobile.png',full_page=True);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');assert frame.locator('body').evaluate('()=>document.documentElement.scrollWidth<=innerWidth+1')
   assert not errors,errors;assert not bad,bad
   browser.close()
 print('PASS: node canvas, real hard-cut detection and evidence, cross-scene shared speech, AI JSON validation, conditional reference wires, approval gate, retained clip versions/blobs, exact-duration editor handoff with held frames/captions and undo; mobile; no page/asset errors.')
finally:server.shutdown();server.server_close();thread.join()
