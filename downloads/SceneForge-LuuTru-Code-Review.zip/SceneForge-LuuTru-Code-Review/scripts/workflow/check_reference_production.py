"""Verify reference production nodes, caption isolation, persistence and hosted handoff."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
import io,wave,base64,json
from playwright.sync_api import sync_playwright
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
root=Path(__file__).resolve().parents[2]
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1000});errors=[];calls=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:calls.append((r.method,r.url)));page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html?mode=reference&room=production-test');page.wait_for_function('!!window.SceneForgeWorkflow');page.evaluate("closeChooser();project=demoProject();project.id='production-test';render();")
  assert page.locator('#node-captions').count()==1 and page.locator('#node-music').count()==1
  page.evaluate("actions['production-chat']()");assert 'OUTPUT TEMPLATE' in page.locator('#modal textarea').input_value();page.evaluate('closeModal()')
  page.evaluate("project.script=[{id:'line',start:0,end:1,original:'Lời gốc',newText:'Lời mới'}];project.merge.captions=true;render();actions['production-caption-edit']()")
  page.locator('[data-field=text]').first.fill('Phụ đề riêng');page.locator('#productionSaveCues').click();assert page.evaluate("project.script[0].newText")=='Lời mới';assert page.evaluate("package5Captions()[0].text")=='Phụ đề riêng'
  page.evaluate("project.script[0].newText='Lời đổi';render()");assert 'Kịch bản đã đổi' in page.locator('#node-captions').inner_text()
  page.on('dialog',lambda d:d.accept());page.evaluate("actions['production-caption-refresh']()");assert page.evaluate("package5Captions()[0].text")=='Lời đổi'
  validation=page.evaluate('''()=>{const original=JSON.stringify(project);const valid=analysisTemplate();valid.script=project.script.map(l=>({...l}));productionValidateChat(valid);valid.script[0].original='Bịa lời';let blocked=false;try{productionValidateChat(valid)}catch{blocked=true}return {blocked,same:original===JSON.stringify(project)};}''');assert validation['blocked'] and validation['same'],validation
  imported=page.evaluate("()=>{const data=analysisTemplate();data.script=project.script.map(l=>({...l}));data.scenes[0].promptFrame={vi:'Khung từ chat',en:'Frame from chat'};return data;}")
  page.locator('#productionChatFile').set_input_files({'name':'chat.json','mimeType':'application/json','buffer':json.dumps(imported).encode()});page.locator('#productionApplyChat').wait_for();assert page.evaluate("project.scenes[0].promptFrame.vi")!='Khung từ chat';page.locator('#productionApplyChat').click();assert page.evaluate("project.scenes[0].promptFrame.vi")=='Khung từ chat'
  # Actual decoded WAV, not a filename-only library entry.
  wav=io.BytesIO()
  with wave.open(wav,'wb')as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(8000);f.writeframes(b'\x00\x00'*16000)
  page.locator('#productionMusicFiles').set_input_files({'name':'nhac.wav','mimeType':'audio/wav','buffer':wav.getvalue()});page.wait_for_function('project.merge.musicLibrary.length===1');assert page.evaluate("project.merge.musicMode")=='off'
  page.locator('[data-production=musicMode]').select_option('selected');page.locator('[data-production=musicVolume]').fill('22');page.locator('[data-production=musicVolume]').dispatch_event('change')
  page.evaluate('storeProject()');page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');assert page.evaluate('project.merge.musicLibrary.length')==1;assert page.evaluate('project.merge.musicVolume')==.22
  # Bridge payload preserves clips; subtitles and music remain editable separate tracks.
  result=page.evaluate('''async()=>{project.scenes=project.scenes.slice(0,1);const s=project.scenes[0];s.start=0;s.end=2;const part=clipParts(s)[0];const asset=putAsset(new Blob(['clip'],{type:'video/mp4'}));s.clips=[{id:'picked',part:part.id,asset,duration:2,name:'clip',version:1}];s.chosen={[part.id]:'picked'};project.merge.order=[];project.merge.captionDraft=undefined;project.script=[{id:'l',start:0,end:1,newText:'Chữ riêng'}];window.parent.postMessage=message=>{if(message.type==='sceneforge:workflow-open-editor')window.testPayload=message.payload};await openInEditor();return {music:window.testPayload.audio.map(a=>({role:a.role,volume:a.volume,place:a.place})),captions:window.testPayload.captions,clips:window.testPayload.clips.length,options:window.testPayload.captionOptions};}''')
  assert result['clips']==1 and result['music'][0]['volume']==.22 and result['captions'][0]['text']=='Chữ riêng',result
  page.evaluate("project.merge.musicMode='off';openInEditor()");assert page.evaluate('window.testPayload.audio.length')==0
  # Node rectangles stay separate after resize and automatic layout.
  page.wait_for_timeout(300)
  assert page.evaluate('''()=>{const r=[...document.querySelectorAll('.node')].map(n=>({x:n.offsetLeft,y:n.offsetTop,w:n.offsetWidth,h:n.offsetHeight}));return r.every((a,i)=>r.slice(i+1).every(b=>a.x+a.w<=b.x||b.x+b.w<=a.x||a.y+a.h<=b.y||b.y+b.h<=a.y));}''')
  page.screenshot(path='/tmp/sceneforge-reference-production.png',full_page=True)
  page.goto(f'http://127.0.0.1:{server.server_port}/native/index.html');page.wait_for_function('!!window.SceneForgeEditor');
  ack=page.evaluate('''async data=>{const blob=(b64,type)=>new Blob([Uint8Array.from(atob(b64),c=>c.charCodeAt(0))],{type});const payload={clips:[{file:blob(data.video,'video/mp4'),name:'Cảnh đã chọn',duration:1,sourceDuration:2,start:0}],audio:[{file:blob(data.audio,'audio/wav'),name:'Nhạc riêng',role:'music',place:true,volume:.22}],captions:[{start:0,end:.8,text:'Phụ đề riêng'}],captionStyle:'box',captionOptions:{fontSize:72,textY:65}};return await new Promise(resolve=>{const timer=setTimeout(()=>resolve('timeout'),10000);window.addEventListener('message',function ack(e){if(e.data?.type==='sceneforge:workflow-import-ack'){clearTimeout(timer);window.removeEventListener('message',ack);resolve(e.data.error||'ok');}});window.postMessage({type:'sceneforge:workflow-import',id:'test',payload},location.origin);});}''',{'video':base64.b64encode((root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()).decode(),'audio':base64.b64encode(wav.getvalue()).decode()})
  assert ack=='ok',ack
  model=page.evaluate('SceneForgeEditor.getState()');music=[i for i in model['items']if i['kind']=='audio'];captions=[i for i in model['items']if i.get('subtitle')];assert len(music)==1 and music[0]['volume']==.22 and music[0]['duration']==1,music;assert captions[0]['fontSize']==72 and captions[0]['textY']==65 and captions[0]['text']=='Phụ đề riêng',captions
  assert not errors,errors;assert not [u for method,u in calls if method=='POST' and '/local-api/' in u];b.close()
 print('PASS nodes, chat pack, subtitle isolation/staleness, decoded music import/persistence, volume/no-music handoff, non-overlap and zero paid/API POST requests.')
finally:server.shutdown()
