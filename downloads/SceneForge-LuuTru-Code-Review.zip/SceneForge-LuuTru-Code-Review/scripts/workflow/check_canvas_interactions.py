"""Use real pointer events to verify node layout, dragging, wires and persistence."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading,io
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1080});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  url='http://127.0.0.1:'+str(server.server_port)+'/workflow.html?mode=reference';page.goto(url);page.wait_for_function('!!window.SceneForgeWorkflow');page.wait_for_timeout(200)
  state=lambda:page.evaluate('SceneForgeWorkflow.getState()')
  def rect(node):return page.locator('#'+node).evaluate('(n)=>({x:n.offsetLeft,y:n.offsetTop,w:n.offsetWidth,h:n.offsetHeight})')
  def no_overlap():
   collisions=page.locator('.node').evaluate_all('ns=>{const out=[];for(let i=0;i<ns.length;i++)for(let j=i+1;j<ns.length;j++){const a=ns[i],b=ns[j];if(a.offsetLeft<b.offsetLeft+b.offsetWidth&&a.offsetLeft+a.offsetWidth>b.offsetLeft&&a.offsetTop<b.offsetTop+b.offsetHeight&&a.offsetTop+a.offsetHeight>b.offsetTop)out.push([a.id,b.id]);}return out;}')
   assert not collisions,collisions
  no_overlap()
  assert page.locator('.node.inactive').evaluate_all('ns=>ns.every(n=>getComputedStyle(n).opacity==="1"&&getComputedStyle(n).backgroundColor!=="rgba(0, 0, 0, 0)")')
  # Speech uses a nearby free corridor instead of routing to the world bottom.
  assert page.locator('.wire.voice').first.evaluate('path=>{const nodes=[...document.querySelectorAll(".node[id^=ref-]")];for(let t=0;t<=1;t+=.002){const p=path.getPointAtLength(path.getTotalLength()*t);if(nodes.some(n=>p.x>n.offsetLeft&&p.x<n.offsetLeft+n.offsetWidth&&p.y>n.offsetTop&&p.y<n.offsetTop+n.offsetHeight))return false;}return true;}')
  assert page.locator('[data-from="node-script"][data-to="node-merge"]').count()==0
  assert page.locator('.wire.voice[data-from="node-script"]').count()==len(state()['scenes'])
  assert page.locator('.wire.voice[data-from="node-script"]').evaluate_all('ps=>ps.every(p=>{const r=p.getBBox();return r.y+r.height<parseFloat(document.querySelector("#world").style.height)-80;})')
  # Click/keyboard selection is distinct from dragging and approval.
  page.locator('#node-source>header').click();expect(page.locator('#node-source')).to_have_class(__import__('re').compile('nodeSelected'));assert page.locator('.nodeSelected').count()==1
  assert page.locator('.wireSelected[data-from="node-source"]').count()==1
  expect(page.locator('#minimap .minimapSelected')).to_have_attribute('data-node-id','node-source')
  page.locator('#node-analysis').focus();expect(page.locator('#node-analysis')).to_have_class(__import__('re').compile('nodeSelected'));assert page.locator('.nodeSelected').count()==1
  expect(page.locator('#minimap .minimapSelected')).to_have_attribute('data-node-id','node-analysis')
  page.evaluate('render()');expect(page.locator('#node-analysis')).to_have_class(__import__('re').compile('nodeSelected'))
  page.locator('#viewport').click(position={'x':5,'y':5});assert page.locator('.nodeSelected,.wireSelected,#minimap .minimapSelected').count()==0
  # Drag an actual card header at a non-100% zoom; wires update during movement.
  first=state()['scenes'][0];target='frame-'+first['id'];before=rect(target);before_model=state()['scenes'];wire=page.locator('[data-from="'+target+'"]').get_attribute('d')
  head=page.locator('#'+target+'>header').bounding_box();page.mouse.move(head['x']+45,head['y']+13);page.mouse.down();page.mouse.move(head['x']+60,head['y']+90,steps=12);page.wait_for_timeout(100)
  assert page.locator('#'+target).evaluate('n=>n.classList.contains("nodeMoving")')
  expect(page.locator('#minimap .minimapSelected')).to_have_attribute('data-node-id',target)
  assert page.locator('[data-from="'+target+'"]').get_attribute('d')!=wire
  page.mouse.up();page.wait_for_timeout(80);after=rect(target);assert after!=before and state()['layout']['nodes'][target]['y']==after['y'];assert state()['scenes']==before_model;no_overlap()
  # A drag may be cancelled without moving the canvas or saving the partial edit.
  view=page.locator('#world').get_attribute('style');saved=state()['layout']['nodes'].copy();head=page.locator('#'+target+'>header').bounding_box();page.mouse.move(head['x']+30,head['y']+10);page.mouse.down();page.mouse.move(head['x']+90,head['y']+75,steps=8);page.wait_for_timeout(80);page.keyboard.press('Escape');page.mouse.up();assert rect(target)==after and state()['layout']['nodes']==saved
  # The three upstream cards also drag from ordinary body content, not just headers.
  for node_id,body_selector in [('node-source','.sourceMeta b'),('node-analysis','.analysisStep'),('node-script','.scriptSummary p')]:
   page.locator('[data-action=fit]').first.click();before_body=rect(node_id);body=page.locator('#'+node_id+' '+body_selector).first.bounding_box();page.mouse.move(body['x']+min(20,body['width']/2),body['y']+min(7,body['height']/2));page.mouse.down();page.mouse.move(body['x']-22,body['y']+35,steps=12);page.wait_for_timeout(70);assert page.locator('#'+node_id).evaluate('n=>n.classList.contains("nodeMoving")');page.mouse.up();assert rect(node_id)!=before_body;assert node_id in state()['layout']['nodes'];assert not page.evaluate('getSelection().toString()');no_overlap()
  page.wait_for_timeout(230)
  # A simple click on a prompt surface must still open its editor.
  page.locator('.promptExcerpt p').first.click();expect(page.locator('#details')).to_be_visible();page.locator('[data-action=close-details]').click()
  # Dropping over another card resolves to free space, not a hidden card stack.
  a=page.locator('#node-source>header').bounding_box();b=page.locator('#node-scenes>header').bounding_box();page.mouse.move(a['x']+35,a['y']+12);page.mouse.down();page.mouse.move(b['x']+35,b['y']+12,steps=15);page.wait_for_timeout(80);expect(page.locator('#node-source')).to_have_class(__import__('re').compile('nodeCollision'));assert page.locator('#node-source').evaluate('n=>getComputedStyle(n).outlineStyle!=="dashed"');expect(page.locator('#minimap .minimapSelected')).to_have_attribute('data-node-id','node-source');page.mouse.up();no_overlap()
  positions=state()['layout']['nodes'];page.wait_for_timeout(700);page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');page.wait_for_timeout(200);assert state()['layout']['nodes']==positions;assert rect(target)==after;no_overlap()
  # Three reference thumbnails plus the add control must stay inside their card.
  image=io.BytesIO();Image.new('RGB',(90,160),'orange').save(image,format='PNG')
  page.locator('[data-action=fit]').first.click()
  with page.expect_file_chooser()as chooser:page.locator('[data-ref-upload=person]').click()
  chooser.value.set_files([{'name':'person'+str(n)+'.png','mimeType':'image/png','buffer':image.getvalue()}for n in range(3)])
  page.wait_for_function('SceneForgeWorkflow.getState().refs.person.images.length===3')
  assert page.locator('#ref-person .refImages').evaluate('n=>n.scrollWidth<=n.clientWidth+1')
  assert page.locator('#ref-person .refImages').evaluate('n=>[...n.children].every(c=>c.getBoundingClientRect().right<=n.getBoundingClientRect().right+1)')
  # A user-resized textarea grows its card and triggers layout of following cards.
  textarea=page.locator('#ref-outfit textarea');r=textarea.bounding_box();old_height=textarea.evaluate('n=>n.offsetHeight');page.mouse.move(r['x']+r['width']-3,r['y']+r['height']-3);page.mouse.down();page.mouse.move(r['x']+r['width']-3,r['y']+r['height']+95,steps=12);page.mouse.up();page.wait_for_timeout(200);assert textarea.evaluate('n=>n.offsetHeight')>old_height;no_overlap()
  # Manual positions survive opening details and saving prompt edits.
  page.locator('.promptExcerpt button').first.click();expect(page.locator('#details')).to_be_visible();page.locator('[data-action=save-details]').click();page.wait_for_timeout(100);assert state()['layout']['nodes'][target]==positions[target];no_overlap();page.locator('[data-action=close-details]').click()
  page.locator('[data-action=arrange-nodes]').click();page.wait_for_timeout(100);assert state()['layout']['nodes']=={};assert rect('node-source')['x']==70;no_overlap()
  page.screenshot(path='/tmp/sceneforge-node-layout-fixed.png',full_page=True)
  page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(100);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1');assert not errors,errors
  browser.close()
 print('PASS: opaque cards, short static voice routes, node/wire/minimap selection and no dashed drag border, no card overlaps, zoom-correct header/body drag on source-analysis-script, normal prompt clicks/live wires, Escape, safe drop, saved positions/reload, 3 images+add fit, resized textarea reflows, prompt save preserves layout, arrange reset, mobile/no JS errors.')
finally:server.shutdown();server.server_close();thread.join()
