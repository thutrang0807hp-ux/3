"""Manual Gemini Chat exchange: browser validation/persistence, no real chat calls."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
import json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1400,'height':950});errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
  page.goto(f'http://localhost:{s.server_port}/workflow.html');page.wait_for_function('window.SceneForgeWorkflow&&project?.scenes?.length>0')
  page.evaluate('''async()=>{project.script=[{id:'zh',start:0,end:1,original:'你好。',translation:'',newText:'Lời tôi tự viết',faceTalking:false},{id:'it',start:1,end:2,original:'Buongiorno.',translation:'',newText:'',faceTalking:false}];await storeProject();scriptDialog();}''')
  page.locator('[data-action=chat-translate]').click();page.locator('#prepareChatTranslation').click();expect(page.locator('#chatTranslationPrompt')).to_have_value(__import__('re').compile('Buongiorno'))
  page.locator('#chatTranslationResult').fill(json.dumps({'lines':[{'id':'zh','translation':'Chào'},{'id':'zh','translation':'Sai'}]}));page.locator('#reviewChatTranslation').click();expect(page.locator('#chatTranslationError')).to_contain_text('trùng');assert page.evaluate('project.script[0].translation')==''
  response=json.dumps({'lines':[{'id':'it','translation':'Chào buổi sáng.'},{'id':'zh','translation':'Xin chào.'}]})
  page.locator('#chatTranslationResult').fill(response);page.locator('#reviewChatTranslation').click();expect(page.locator('#applyChatTranslation')).to_be_visible();assert page.evaluate('project.script[0].translation')==''
  page.locator('[data-action=chat-translate]').click();expect(page.locator('#chatTranslationResult')).to_have_value(response);page.locator('#reviewChatTranslation').click();page.locator('#applyChatTranslation').click();expect(page.locator('.scriptGrid')).to_contain_text('Chào buổi sáng.')
  rows=page.evaluate('project.script');assert rows[0]['original']=='你好。' and rows[0]['start']==0 and rows[0]['end']==1 and rows[0]['newText']=='Lời tôi tự viết';assert rows[1]['translation']=='Chào buổi sáng.'
  page.locator('[data-action=chat-translate]').click();page.locator('#chatTranslateReplace').check();page.locator('#prepareChatTranslation').click();page.locator('#chatTranslationResult').fill(response);page.locator('#reviewChatTranslation').click();page.evaluate("project.script[0].original='Nguồn thay đổi'");page.locator('#applyChatTranslation').click();assert page.evaluate('project.script[0].original')=='Nguồn thay đổi'
  assert not errors,errors;assert not [u for u in requests if '/local-api/' in u or 'generativelanguage.googleapis.com' in u],requests
  browser.close()
 print('PASS mixed-language prompt, JSON IDs/duplicates, review before apply, Back preserves pasted result, original times/manual rewrite unchanged, stale-source rejection; no API/chat calls. Pasted translations are fixtures.')
finally:s.shutdown()
