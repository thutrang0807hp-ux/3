"""Browser translation review/persistence with explicit model-response fixtures."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1400,'height':950});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://localhost:{s.server_port}/workflow.html');page.wait_for_function('window.SceneForgeWorkflow&&project?.scenes?.length>0')
  page.evaluate('''async()=>{project.script=[{id:'zh1',start:0,end:1,original:'你好。',translation:'',newText:'Lời Việt tự viết',faceTalking:false},{id:'zh2',start:1,end:2,original:'这是产品。',translation:'Đã dịch trước',newText:'',faceTalking:false}];await storeProject();testRequests=[];testAvailable=false;workflowLocalRequest=async(path,body)=>{testRequests.push(path);if(body)testSourceLanguage=body.source_language;if(path.endsWith('/status'))return{available:testAvailable};return{lines:body.lines.map(l=>({...l,translation:'Xin chào · bản dịch kiểm thử'})),provider_requests:0};};scriptDialog();}''')
  page.locator('[data-action=local-translate]').click();page.locator('#localTranslateLanguage').select_option('zh');page.locator('#runLocalTranslate').click();expect(page.locator('#localTranslateStatus')).to_contain_text('M2M100');assert page.evaluate('testRequests')==['translation/local/status']
  page.evaluate('testAvailable=true');page.locator('#localTranslateLanguage').select_option('it');page.locator('#runLocalTranslate').click();expect(page.locator('#applyLocalTranslate')).to_be_visible();assert page.evaluate('project.script[0].translation')=='';assert page.evaluate('testSourceLanguage')=='it';assert page.locator('#localTranslateLanguage').count()==0
  page.locator('#applyLocalTranslate').click();expect(page.locator('.scriptGrid')).to_contain_text('Xin chào');rows=page.evaluate('project.script');assert rows[0]['start']==0 and rows[0]['end']==1 and rows[0]['original']=='你好。' and rows[0]['newText']=='Lời Việt tự viết';assert rows[1]['translation']=='Đã dịch trước'
  page.locator('[data-action=local-translate]').click();page.locator('#localTranslateReplace').check();page.locator('#localTranslateLanguage').select_option('zh');page.locator('#runLocalTranslate').click();expect(page.locator('#applyLocalTranslate')).to_be_visible();page.evaluate("project.script[0].original='Nguồn đã sửa'");page.locator('#applyLocalTranslate').click();assert page.evaluate('project.script[1].translation')=='Đã dịch trước'
  assert not errors,errors;assert all(not path.startswith('ai/') for path in page.evaluate('testRequests'));b.close()
 print('PASS no-model block, explicit preview/apply, preserves manual rewrites and timestamps, skips old translations, stale-source rejection, no paid routes. Model responses are fixtures only.')
finally:s.shutdown()
