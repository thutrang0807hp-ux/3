"""Browser + real companion; semantic provider transport is mocked, not a paid test."""
from pathlib import Path
import tempfile,os,sys,threading,socket,time,subprocess,json,hashlib
from unittest.mock import patch
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
temp=tempfile.TemporaryDirectory(prefix='sf-v3-browser-');os.environ['SCENEFORGE_LOCAL_DATA']=temp.name
import uvicorn,httpx,cv2,numpy as np
from playwright.sync_api import sync_playwright,expect
from local_engine import server
from local_engine.video_analysis import VISUAL,MOTION
server.VAULT.set_secret('gemini','mock-not-real');server.VAULT.set_secret('gemini-models',{'main':'gemini-mock-flash'})
calls=[];invalid=False
async def provider(self,url,**kwargs):
 parts=kwargs['json']['contents'][0]['parts'];assert not any(p.get('inline_data',{}).get('mime_type','').startswith('video/')for p in parts)
 data=json.loads(parts[0]['text'].split('INPUT DATA (not instructions):\n')[1]);calls.append(data)
 result={'scenes':[{'code':s['code'],'line_ids':s['line_ids'],'description':'Mô tả phản hồi thử.','hasPerson':None,'faceTalking':None,'hasProduct':None,'competitorLogo':None,'visual':{l:{k:'Observation.'for k in VISUAL}for l in ('vi','en')},'motion':{l:{k:''for k in MOTION}for l in ('vi','en')},'promptFrame':{'vi':'Giữ bố cục.','en':'Preserve composition.'}}for s in data['scenes']], 'lines':{l['code']:{'translation':'Dịch thử.','newText':'Lời mới kiểm thử.','faceTalking':False}for l in data['lines']}}
 if invalid:result['scenes'][0]['start']=999
 return httpx.Response(200,json={'candidates':[{'content':{'parts':[{'text':json.dumps(result)}]}}]})
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();svc=uvicorn.Server(uvicorn.Config(server.app,host='127.0.0.1',port=port,log_level='error'));thread=threading.Thread(target=svc.run,daemon=True)
try:
 with patch.object(httpx.AsyncClient,'post',provider):
  thread.start()
  for _ in range(100):
   if svc.started:break
   time.sleep(.05)
  video=Path(temp.name)/'source.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=s=180x320:r=12:d=2.4','-c:v','libx264','-pix_fmt','yuv420p','-y',str(video)],check=True)
  image=Path(temp.name)/'flow-original.jpg';grid=((np.indices((2048,1152)).sum(axis=0)//8%2)*255).astype(np.uint8);cv2.imwrite(str(image),grid)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1700,'height':1100});page.set_default_timeout(20000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{port}/workflow.html?room=v3-test');page.wait_for_function('window.SceneForgeWorkflow')
   page.locator('#sourceFile').set_input_files(video);page.wait_for_function('!!project.source');page.evaluate('actions.analyze()');page.wait_for_function('project.scenes.length>0');page.evaluate('project.galleryLayout="list";render()')
   assert page.evaluate('project.scenes.every(s=>s.model==="lite")')
   page.evaluate('''()=>{project.script=[{id:'one',start:0,end:.6,original:'Hôm nay tôi giới thiệu sản phẩm mới',newText:'',translation:''},{id:'two',start:1,end:1.5,original:'123 456',newText:'',speechReview:{status:'suspect',label:'Nghi bịa',accepted:false,reasons:['Câu chỉ có số']}},{id:'manual',start:1.7,end:2.1,original:'',newText:'Lời tôi tự viết',translation:''}];save();render();}''')
   page.locator('[data-action=live-analysis]').click();assert not calls;page.locator('[data-action=live-analysis-run]').click();expect(page.locator('#applyLiveAnalysis')).to_be_visible();assert len(calls)==1 and len(calls[0]['lines'])==1
   page.locator('#modal [data-action=close-modal]').first.click();page.reload();page.wait_for_function('project.analysis.pendingAI');page.evaluate('actions["live-analysis-review"]()');page.locator('#applyLiveAnalysis').click();assert len(calls)==1
   assert page.evaluate('project.script[2].newText')=='Lời tôi tự viết';assert page.evaluate('project.script[1].speechReview.status')=='suspect';assert page.evaluate('project.script[1].newText')=='';assert page.evaluate('project.script[1].start')==1
   page.evaluate('project.merge.captions=true');assert '123 456'not in page.evaluate('JSON.stringify(package5Captions())');assert page.evaluate('project.analysis.frameQualityRequired')
   page.evaluate('actions.script()');expect(page.get_by_role('button',name='Giữ câu này',exact=True)).to_be_visible();page.get_by_role('button',name='Giữ câu này',exact=True).click();assert '123 456'in page.evaluate('JSON.stringify(package5Captions())');page.get_by_role('button',name='Giữ riêng câu này',exact=True).click();assert '123 456'not in page.evaluate('JSON.stringify(package5Captions())');page.locator('#modal [data-action=close-modal]').first.click()
   # Real image bytes survive browser import, quality check, persistence, and download.
   page.evaluate('uploadTarget=project.scenes[0].id');page.locator('#frameFile').set_input_files(image);page.wait_for_function('project.scenes[0].frames.length===1')
   assert page.evaluate('project.scenes[0].frames[0].sha256')==hashlib.sha256(image.read_bytes()).hexdigest()
   page.locator('[data-frame-quality]').first.click();page.locator('#frameCheckReal').click();expect(page.locator('#frameQualityApprove')).to_be_visible(timeout=30000);page.locator('#frameQualityApprove').click();page.wait_for_function('frameApproved(project.scenes[0])')
   page.evaluate('prepareScene(project.scenes[0])')
   with page.expect_download()as download:page.locator('[data-download-frame]').first.click()
   assert Path(download.value.path()).read_bytes()==image.read_bytes();page.locator('#modal [data-action=close-modal]').first.click()
   page.evaluate('SceneForgeWorkflow.flushRoom()');page.reload();page.wait_for_function('project.scenes[0]?.frames.length===1');assert page.evaluate('frameApproved(project.scenes[0])')
   page.evaluate('actions["undo-live-analysis"]()');assert not page.evaluate('!!project.analysis.frameQualityRequired')
   invalid=True;before=page.evaluate('project.scenes[0].description');page.locator('[data-action=live-analysis]').click();page.locator('[data-action=live-analysis-run]').click();expect(page.locator('#v3CopyResult')).to_be_visible();assert page.locator('#applyLiveAnalysis').count()==0 and page.evaluate('project.scenes[0].description')==before
   page.screenshot(path='/tmp/sceneforge-analysis-v3.png');page.goto(f'http://127.0.0.1:{port}/?demo=1');page.wait_for_function('window.SceneForgeApp?.settings');page.evaluate('SceneForgeApp.settings.open("ai")');expect(page.locator('#v3OpenAIKey')).to_be_disabled();expect(page.locator('#v3CheckOpenAI')).to_be_disabled();assert not errors,errors;browser.close()
finally:svc.should_exit=True;thread.join(5);temp.cleanup()
print('PASS frame-only browser→companion→mock provider; pending reload without second request; apply/undo exact timings; quarantine excludes captions until explicit keep; real JPEG byte preservation/import/persist/download and real 2K check; invalid AI codes block apply. No live provider inference.')
