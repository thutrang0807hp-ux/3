"""Real browser removal on a controlled 9:16 video with audible AAC; no mocked engine."""
from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import threading,tempfile,subprocess,json,re,base64,hashlib
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
def make_fixtures(tmp):
 source=(root/'scripts/workflow/vendor/gwr/src/core/embeddedAlphaMaps.js').read_text();encoded=re.search(r"'96-20260520': '([^']+)'",source).group(1)
 alpha=np.frombuffer(base64.b64decode(encoded),dtype='<f4').reshape(96,96)
 alpha=np.asarray(Image.fromarray(alpha).resize((48,48),Image.Resampling.BOX))
 w,h=720,1280;y,x=np.mgrid[:h,:w];frame=np.empty((h,w,3),dtype=np.uint8);frame[:,:,0]=40+x*.05;frame[:,:,1]=60+y*.04;frame[:,:,2]=95+x*.03+y*.01
 for label,watermark in [('clean',False),('watermarked',True)]:
  command=['ffmpeg','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r','12','-i','pipe:0','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=2','-shortest','-c:v','libx264','-preset','ultrafast','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-y',str(tmp/(label+'.mp4'))]
  proc=subprocess.Popen(command,stdin=subprocess.PIPE)
  for n in range(24):
   f=frame.copy();f[250:400,160+n*4:260+n*4]=[170,110,60]
   if watermark:
    roi=f[1136:1184,576:624].astype(float);f[1136:1184,576:624]=np.round(roi*(1-alpha[:,:,None])+255*alpha[:,:,None]).clip(0,255).astype(np.uint8)
   proc.stdin.write(f.tobytes())
  proc.stdin.close();assert proc.wait()==0
 return tmp/'watermarked.mp4',tmp/'clean.mp4'
def probe(path):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
def image(path):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','pipe:1']);return np.frombuffer(raw,np.uint8).reshape(1280,720,3).astype(float)
def audio_hashes(path):
 d=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','a','-show_packets','-show_data_hash','sha256','-show_entries','packet=pts_time,data_hash','-of','json',str(path)]));return [p['data_hash']for p in d['packets']if float(p.get('pts_time',0))>=0]
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory()as td:
  tmp=Path(td);watermarked,clean=make_fixtures(tmp)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1080});errors=[];external=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:external.append(r.url)if r.url.startswith('http')and'127.0.0.1'not in r.url else None)
   page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html?mode=reference');page.wait_for_function('!!window.SceneForgeWorkflow');state=lambda:page.evaluate('SceneForgeWorkflow.getState()');scene_id=state()['scenes'][0]['id'];expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Chưa có clip Veo');expect(page.locator('[data-watermark-scene="'+scene_id+'"]')).to_have_text('✧ Xử lý watermark');page.locator('[data-approve="'+scene_id+'"]').click()
   with page.expect_file_chooser()as chooser:page.locator('[data-clip-upload="'+scene_id+'"]').first.click()
   chooser.value.set_files(str(watermarked));page.wait_for_function('SceneForgeWorkflow.getState().scenes[0].clips.length===1');original=state()['scenes'][0]['chosen']['a'];expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Chưa kiểm tra watermark');assert page.evaluate('watermarkJob===null')
   page.locator('[data-watermark-scene="'+scene_id+'"]').click();page.wait_for_function('SceneForgeWorkflow.getState().scenes[0].clips.some(c=>c.watermark)',timeout=180000)
   expect(page.locator('.watermarkInlinePreview video')).to_be_visible();expect(page.locator('#modal')).to_be_hidden();s=state()['scenes'][0];assert s['chosen']['a']==original and len(s['clips'])==2;processed=next(c for c in s['clips']if c.get('watermark'));assert processed['watermark']['audioCopied'];expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Đã xử lý · chưa chọn để ghép')
   page.locator('[data-action=fit]').first.click();page.screenshot(path='/tmp/sceneforge-watermark-inline.png',full_page=True)
   with page.expect_download()as download:page.evaluate('''()=>{const c=project.scenes[0].clips.find(c=>c.watermark),a=document.createElement('a');a.href=mediaUrl(c.asset);a.download='processed.mp4';a.click();}''')
   output=tmp/'processed.mp4';download.value.save_as(str(output));metadata=probe(output);video=next(s for s in metadata['streams']if s['codec_type']=='video');assert(video['width'],video['height'])==(720,1280);assert abs(float(video['duration'])-2)<1/12;assert int(video['nb_frames'])==24
   original_audio=audio_hashes(watermarked);result_audio=audio_hashes(output);assert result_audio==original_audio,(len(result_audio),len(original_audio))
   ref=image(clean);before=image(watermarked);after=image(output);roi=np.s_[1136:1184,576:624,:];baseline=np.abs(before[roi]-ref[roi]).mean();restored=np.abs(after[roi]-ref[roi]).mean();print('Pixel MAE in watermark region:',baseline,'->',restored,flush=True);assert restored<baseline*.65,(baseline,restored);assert np.abs(after[:1050]-ref[:1050]).mean()<3
   page.locator('[data-watermark-use="'+scene_id+'"]').click();assert state()['scenes'][0]['chosen']['a']==processed['id'];expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Đã xử lý · đang dùng');page.wait_for_timeout(700);page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');assert state()['scenes'][0]['chosen']['a']==processed['id'];expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Đã xử lý · đang dùng');page.locator('[data-watermark-scene="'+scene_id+'"]').click();expect(page.locator('.watermarkInlinePreview video')).to_be_visible();assert len(state()['scenes'][0]['clips'])==2;page.locator('[data-watermark-preview=source]').click();assert page.locator('.watermarkInlinePreview video').get_attribute('data-watermark-video')==original;page.locator('[data-watermark-use="'+scene_id+'"]').click();assert state()['scenes'][0]['chosen']['a']==original
   # A clean video is not relabeled as a successful removal.
   page.evaluate('(id)=>{uploadTarget={id,part:"a"};}',scene_id);page.locator('#clipFile').set_input_files(str(clean));page.wait_for_function('SceneForgeWorkflow.getState().scenes[0].clips.length===3');clean_id=state()['scenes'][0]['chosen']['a'];page.locator('[data-watermark-scene="'+scene_id+'"]').click();page.wait_for_function('!watermarkJob',timeout=120000);assert len(state()['scenes'][0]['clips'])==3 and state()['scenes'][0]['chosen']['a']==clean_id;expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Chưa nhận diện được watermark phù hợp');page.wait_for_timeout(700);page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Chưa nhận diện được watermark phù hợp')
   # Cancel before export; do not create a processed version.
   page.locator('[data-watermark-scene="'+scene_id+'"]').click();page.locator('[data-action=watermark-cancel]').click();page.wait_for_function('!watermarkJob',timeout=30000);assert len(state()['scenes'][0]['clips'])==3;expect(page.locator('[data-watermark-status="'+scene_id+'"]')).to_contain_text('Đã hủy')
   assert not errors,errors;assert not external,external;browser.close()
 print('PASS: real 9:16 alpha-watermark removal reduces error against clean reference; exact AAC packet copy, frame count/duration/resolution, original retained, inline node preview/progress without modal, explicit selection and reload, comparison cache, no-mark no-op, cancellation, no external media requests or JS errors.')
finally:server.shutdown()
