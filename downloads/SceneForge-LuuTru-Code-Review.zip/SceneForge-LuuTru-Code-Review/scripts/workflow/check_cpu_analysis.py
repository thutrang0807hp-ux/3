"""Actual browser + CPU companion pipeline, no external providers/model downloads."""
import os,tempfile,subprocess,socket,time,json
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory()as td:
 data=Path(td);video=data/'source.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=white:s=180x320:r=30:d=1','-f','lavfi','-i','color=blue:s=180x320:r=30:d=1','-filter_complex',"[0:v]drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text=BRAND:fontsize=28:fontcolor=black:x=30:y=100[a];[a][1:v]concat=n=2:v=1:a=0",'-c:v','libx264','-y',str(video)],check=True)
 with socket.socket()as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 env={**os.environ,'SCENEFORGE_LOCAL_DATA':td};log=open(data/'server.log','w');server=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port)],cwd=root,env=env,stdout=log,stderr=log)
 try:
  for _ in range(100):
   try:
    with socket.create_connection(('127.0.0.1',port),timeout=.1):break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1700,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{port}/workflow.html?room=cpu-test');page.wait_for_function('window.SceneForgeWorkflow')
   page.locator('#sourceFile').set_input_files(video);page.wait_for_function('SceneForgeWorkflow.getState().source?.name==="source.mp4"')
   page.locator('[data-action=cpu-analysis]').click();expect(page.locator('#cpuStart')).to_be_enabled();page.locator('#cpuOcr').check();page.locator('#cpuStart').click();expect(page.locator('#cpuApply')).to_be_visible(timeout=90000)
   assert page.evaluate('SceneForgeWorkflow.getState().scenes.length')==0
   page.locator('[data-action=close-modal]').last.click();page.reload();page.wait_for_function('window.SceneForgeWorkflow');page.locator('[data-action=cpu-review]').click();expect(page.locator('#cpuApply')).to_be_visible();page.locator('#cpuApply').click();page.wait_for_function('SceneForgeWorkflow.getState().scenes.length===2')
   state=page.evaluate('SceneForgeWorkflow.getState()');assert len(state['localHistory'])==1 and state['analysis']['local']['result']['provider_requests']==0;assert any(s['localWarnings']for s in state['scenes'])
   page.locator('[data-cpu-scene]').last.click();expect(page.locator('#cpuReviewed')).to_be_visible();page.locator('#cpuReviewed').click();expect(page.locator('[data-cpu-scene]').last).to_contain_text('✓')
   page.locator('[data-cpu-scene]').first.click();page.locator('#cpuCleanFrame').click();expect(page.locator('[data-cpu-polygon]').first).to_be_visible();page.locator('[data-cpu-box]').first.check();page.locator('#cpuCleanRun').click();expect(page.locator('#cpuCleanSave')).to_be_enabled(timeout=15000);page.screenshot(path='/tmp/sceneforge-cpu-frame-cleanup.png');page.locator('#cpuCleanSave').click();state=page.evaluate('SceneForgeWorkflow.getState()');assert state['scenes'][0]['frames'][-1]['engine']=='OpenCV TELEA'and state['scenes'][0]['approvedFrame']is None
   page.evaluate('project.scenes[0].clips.push({id:"keep-old-clip",asset:"keep-asset"});save();');page.wait_for_timeout(450)
   page.locator('[data-action=cpu-analysis]').click();page.locator('#cpuStart').click();expect(page.locator('#cpuApply')).to_be_visible(timeout=90000);page.locator('#cpuApply').click();page.wait_for_function('SceneForgeWorkflow.getState().localHistory.length===2');assert page.evaluate('SceneForgeWorkflow.getState().scenes[0].clips.some(c=>c.id==="keep-old-clip")')
   page.on('dialog',lambda d:d.accept());page.locator('[data-action=cpu-undo]').click();page.wait_for_function('SceneForgeWorkflow.getState().localHistory.length===1');assert page.evaluate('SceneForgeWorkflow.getState().scenes[0].clips.some(c=>c.id==="keep-old-clip")')
   page.locator('.canvasTools [data-action=fit]').click();page.screenshot(path='/tmp/sceneforge-cpu-workflow.png',full_page=True)
   assert not errors,errors;browser.close()
 finally:server.terminate();server.wait(timeout=15);log.close()
print('PASS real browser to CPU backend, preview before apply, pending report reload, exact two scenes, quality warnings/review, repeated analysis keeps clips and undo; no provider calls.')
