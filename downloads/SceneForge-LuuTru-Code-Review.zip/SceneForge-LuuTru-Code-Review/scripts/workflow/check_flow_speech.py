"""Verify Flow-native dialogue prompts, clip-boundary splitting and legacy draft migration."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright()as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1536,'height':1040},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('http://127.0.0.1:'+str(server.server_port)+'/workflow.html?mode=reference');page.wait_for_function('!!window.SceneForgeWorkflow');state=lambda:page.evaluate('SceneForgeWorkflow.getState()')
  expect(page.locator('#node-script')).to_contain_text('Kịch bản & lời thoại');assert page.locator('#voiceFile,[data-action=voice-import],[data-action=listen]').count()==0
  assert page.locator('.clipNode [data-extra]').count()==0
  page.locator('[data-action=script]').first.click();expect(page.locator('#modalTitle')).to_contain_text('lời thoại gửi Flow');page.locator('[data-flow-voice=accent]').select_option('northern');page.locator('[data-flow-voice=gender]').select_option('male')
  transcript='1\n00:00:04,000 --> 00:00:07,500\nSản phẩm này rất dễ dùng.\n\n'
  page.locator('#scriptFile').set_input_files({'name':'words.srt','mimeType':'text/plain','buffer':transcript.encode()});page.locator('[data-line-face]').check();page.locator('[data-action=close-modal]').first.click()
  page.locator('[data-action=g6-ready-run]').click()
  with page.expect_download()as dl:page.locator('[data-action=export-prompts]').click()
  text=Path(dl.value.path()).read_text();assert 'EXACT VIETNAMESE DIALOGUE: "Sản phẩm này rất dễ dùng."'in text and 'Northern Vietnamese'in text and'adult male'in text and'native audio together'in text and'audible speech'in text
  assert 'shared voice track'not in text and 'mouths this exact'not in text and text.count('Sản phẩm này rất dễ dùng.')==1
  page.locator('[data-action=close-modal]').first.click()
  # A sentence straddling a cut cannot silently be sent in full to two clips.
  crossing='1\n00:00:03,000 --> 00:00:05,000\nVế đầu câu. Vế cuối câu.\n\n'
  page.locator('#scriptFile').set_input_files({'name':'crossing.srt','mimeType':'text/plain','buffer':crossing.encode()});page.locator('[data-action=close-modal]').first.click()
  page.locator('[data-action=g6-ready-run]').click();page.locator('[data-action=export-prompts]').click();expect(page.locator('#toast')).to_contain_text('chia lời');expect(page.locator('#details')).to_be_visible()
  page.locator('[data-part-speech=a]').fill('Vế đầu câu.');page.locator('[data-action=save-details]').click();page.locator('[data-action=close-details]').click()
  page.locator('.sceneRow').nth(1).click();page.locator('[data-detail-tab=script]').click();page.locator('[data-part-speech=a]').fill('Vế cuối câu.');page.locator('[data-action=save-details]').click();page.locator('[data-action=close-details]').click()
  page.locator('[data-action=g6-ready-run]').click()
  with page.expect_download()as dl:page.locator('[data-action=export-prompts]').click()
  text=Path(dl.value.path()).read_text();assert text.count('EXACT VIETNAMESE DIALOGUE: "Vế đầu câu."')==1 and text.count('EXACT VIETNAMESE DIALOGUE: "Vế cuối câu."')==1 and '"Vế đầu câu. Vế cuối câu."'not in text
  page.locator('[data-action=close-modal]').first.click()
  # Rewriting the shared source line invalidates prior per-clip words.
  page.locator('[data-action=script]').first.click();page.locator('#modal [data-line]').fill('Nội dung mới phải chia lại.');page.locator('[data-action=close-modal]').first.click();assert all(not s.get('dialogueParts')for s in state()['scenes'])
  # Old separate-voice files remain stored, but the new default does not use them.
  page.wait_for_timeout(650)
  page.evaluate('''async()=>{const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('sceneforge-workflows',1);r.onsuccess=()=>resolve(r.result);r.onerror=reject;});const key=localStorage.getItem('sceneforge-workflow-last');const row=await new Promise(resolve=>{const r=db.transaction('projects').objectStore('projects').get(key);r.onsuccess=()=>resolve(r.result);});row.voice={asset:'legacyVoice',name:'legacy',duration:1};row.assetEntries.push(['legacyVoice',new Blob(['legacy-data'],{type:'audio/wav'})]);delete row.audioPolicy;delete row.flowVoice;await new Promise((resolve,reject)=>{const tx=db.transaction('projects','readwrite');tx.objectStore('projects').put(row);tx.oncomplete=resolve;tx.onerror=reject;});db.close();}''')
  page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');s=state();assert s['audioPolicy']=='flow-native'and s['voice']['asset']=='legacyVoice'and s['flowVoice']['accent']=='southern'
  page.locator('[data-action=script]').first.click();assert page.locator('#voiceFile,[data-action=voice-import],[data-action=listen]').count()==0
  page.screenshot(path='/tmp/sceneforge-flow-dialogue.png',full_page=True)
  assert not errors,errors;browser.close()
 print('PASS: Flow-native spoken Vietnamese, regional/gender prompt settings, no separate-TTS UI, no duplicated card input, gate split sentences, distinct per-clip words, invalidate stale overrides, preserve legacy data while defaulting to clip audio.')
finally:server.shutdown();server.server_close();thread.join()
