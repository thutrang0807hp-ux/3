"""Real browser removal on a controlled 9:16 video with audible AAC; automatic Gói 5 path; controlled fixture."""
from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import threading,tempfile,subprocess,json,re,base64,hashlib
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
def make_fixtures(tmp):
 source=(root/'scripts/workflow/vendor/gwr/src/core/embeddedAlphaMaps.js').read_text();encoded=re.search(r"'96-20260520': '([^']+)'",source).group(1)
 alpha=np.frombuffer(base64.b64decode(encoded),dtype='<f4').reshape(96,96)
 alpha=np.asarray(Image.fromarray(alpha).resize((48,48),Image.Resampling.BOX))
 w,h=720,1280;y,x=np.mgrid[:h,:w];frame=np.empty((h,w,3),dtype=np.uint8);frame[:,:,0]=40+x*.05;frame[:,:,1]=60+y*.04;frame[:,:,2]=95+x*.03+y*.01
 for label,watermark in [('clean',False),('watermarked',True)]:
  command=['ffmpeg','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r','12','-i','pipe:0','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=2','-shortest','-c:v','libx264','-preset','ultrafast','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-y',str(tmp/(label+'.mp4'))]
  proc=subprocess.Popen(command,stdin=subprocess.PIPE)
  for n in range(24):
   f=frame.copy();f[250:400,160+n*4:260+n*4]=[170,110,60]
   if watermark:
    roi=f[1136:1184,576:624].astype(float);f[1136:1184,576:624]=np.round(roi*(1-alpha[:,:,None])+255*alpha[:,:,None]).clip(0,255).astype(np.uint8)
   proc.stdin.write(f.tobytes())
  proc.stdin.close();assert proc.wait()==0
 return tmp/'watermarked.mp4',tmp/'clean.mp4'
def probe(path):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
def image(path):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','pipe:1']);return np.frombuffer(raw,np.uint8).reshape(1280,720,3).astype(float)
def audio_hashes(path):
 d=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','a','-show_packets','-show_data_hash','sha256','-show_entries','packet=pts_time,data_hash','-of','json',str(path)]));return [p['data_hash']for p in d['packets']if float(p.get('pts_time',0))>=0]
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with tempfile.TemporaryDirectory()as td:
  tmp=Path(td);watermarked,clean=make_fixtures(tmp)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1080});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html?mode=reference');page.wait_for_function('!!window.SceneForgeWorkflow');state=lambda:page.evaluate('SceneForgeWorkflow.getState()');sid=state()['scenes'][0]['id']
   assert page.locator('[data-watermark-scene]').count()==0
   page.locator('[data-approve="'+sid+'"]').click()
   with page.expect_file_chooser()as chooser:page.locator('[data-clip-upload="'+sid+'"]').click()
   chooser.value.set_files(str(watermarked));page.wait_for_function('SceneForgeWorkflow.getState().scenes[0].clips.some(c=>c.watermark)&&!package5Drain',timeout=180000)
   scene=state()['scenes'][0];assert len(scene['clips'])==2;processed=next(c for c in scene['clips']if c.get('watermark'));source=next(c for c in scene['clips']if not c.get('watermark'));assert scene['chosen']['a']==processed['id'];assert source['asset']!=processed['asset'];assert processed['watermark']['audioCopied'];assert page.locator('[data-watermark-scene]').count()==0
   with page.expect_download()as download:page.evaluate("()=>{const c=project.scenes[0].clips.find(c=>c.watermark),a=document.createElement('a');a.href=mediaUrl(c.asset);a.download='processed.mp4';a.click();}")
   output=tmp/'processed.mp4';download.value.save_as(str(output));assert audio_hashes(output)==audio_hashes(watermarked);assert int(next(s for s in probe(output)['streams']if s['codec_type']=='video')['nb_frames'])==24
   ref=image(clean);before=image(watermarked);after=image(output);roi=np.s_[1136:1184,576:624,:];baseline=np.abs(before[roi]-ref[roi]).mean();restored=np.abs(after[roi]-ref[roi]).mean();assert restored<baseline*.65,(baseline,restored)
   # A real import + injected processing failure must keep the original and show only a retry warning.
   sid2=state()['scenes'][1]['id'];page.locator('[data-approve="'+sid2+'"]').click();page.evaluate("watermarkEnginePromise=Promise.resolve({processWatermark:async()=>{throw Error('test engine unavailable')}})")
   with page.expect_file_chooser()as chooser:page.locator('[data-clip-upload="'+sid2+'"]').click()
   chooser.value.set_files(str(watermarked));page.wait_for_function('!package5Drain&&!!SceneForgeWorkflow.getState().scenes[1].watermarkError',timeout=15000);scene2=state()['scenes'][1];assert len(scene2['clips'])==1;expect(page.locator('[data-g5-watermark-retry="'+sid2+'"]')).to_be_visible();assert page.locator('#clip-'+sid2+' .renderErrorBox').count()==0
   assert page.evaluate("package5Captions().length")==0
   page.evaluate("project.script=[{start:0,end:2,newText:'Lời có mốc thật'}];project.merge.captions=true;project.merge.order=[project.scenes[1].id,project.scenes[0].id,project.scenes[2].id]")
   captions=page.evaluate('package5Captions()');assert captions==[{'start':4,'end':6,'text':'Lời có mốc thật'}],captions
   page.evaluate('storeProject()');page.reload();page.wait_for_function('!!window.SceneForgeWorkflow');assert state()['scenes'][0]['chosen']['a']==processed['id'];assert len(state()['scenes'][0]['clips'])==2;assert not errors,errors;b.close()
   print('PASS: automatic real watermark processing selects derived copy, preserves original + identical AAC packets, restores controlled logo region MAE',round(baseline,2),'→',round(restored,2),'; failed processing keeps original/yellow retry; caption timings follow scene reorder; reload retains versions.')
finally:server.shutdown()
