// Shared duration planner. Inputs are explicit; this module never sends provider requests.
(function(){
function partId(index){let value='';for(let n=index+1;n>0;n=Math.floor((n-1)/26))value=String.fromCharCode(97+(n-1)%26)+value;return value;}
function plan(s,options={},lines=[]){
 const max=8,total=s.end-s.start;if(!Number.isFinite(total)||total<=0)return[];
 const cuts=(options.actionCuts||[]).filter(t=>Number.isFinite(t)&&t>s.start&&t<s.end);
 let count=Math.ceil((total-.001)/max),hold=0;
 const tail=total-(count-1)*max;
 if(options.holdTail&&count>1&&tail>0&&tail<=1.2&&!lines.some(l=>l.end>s.end-tail+.001&&l.start<s.end)){count--;hold=tail;}
 const parts=[];let at=s.start;
 for(let i=0;i<count;i++){
  const remaining=count-i,last=remaining===1,ideal=at+(s.end-at-hold)/remaining;
  let end=s.end;
  if(!last){
   const lo=Math.max(at+.2,s.end-(remaining-1)*max-hold),hi=Math.min(at+max,s.end-(remaining-1)*.2);
   const candidates=[Math.max(lo,Math.min(hi,ideal)),...lines.flatMap(l=>[l.start,l.end]),...cuts].filter(t=>t>=lo-.001&&t<=hi+.001);
   const cost=t=>Math.abs(t-ideal)+ (lines.some(l=>l.start<t-.02&&l.end>t+.02)?1000:0) -(cuts.includes(t)?10:0);
   end=candidates.sort((a,b)=>cost(a)-cost(b))[0];
  }
  end=Math.round(end*1000)/1000;const duration=end-at,extra=last?hold:0;
  parts.push({id:partId(i),start:at,end,duration,generationDuration:Math.round((duration-extra)*1000)/1000,holdTail:extra});at=end;
 }
 return parts;
}
window.SFClipPlanning={plan,partId};
})();
