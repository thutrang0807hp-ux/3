"""Build the complete SceneForge web shell with the native Concat UI preview."""
from pathlib import Path
import shutil
import runpy
import hashlib
import json
root = Path(__file__).resolve().parents[2]
output = root / 'dist/web-demo'
output.mkdir(parents=True, exist_ok=True)
runpy.run_path(str(root / 'scripts/native-preview/build.py'), run_name='__main__')
runpy.run_path(str(root / 'scripts/workflow/build.py'), run_name='__main__')
# Room-oriented production shell; media tools remain in their existing iframes.
icons={
 'HOME':'<path d="M3 10.5 12 3l9 7.5M5 9v12h5v-7h4v7h5V9"/>',
 'CREATE':'<rect x="5" y="3" width="11" height="18" rx="2"/><path d="m17 9 4 3-4 3"/>',
 'EDIT':'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 9v11"/>',
 'BELL':'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9m3 12h6"/>',
 'FOLDER':'<path d="M3 7h7l2-3h9v16H3z"/>',
 'SEARCH':'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>'}
observer='<script>try{if(parent!==window)parent.SceneForgeStorage?.observeWindow(window);}catch{}</script>'
for child in ['workflow.html','native/index.html']:
 p=output/child;child_html=p.read_text();p.write_text(child_html.replace('</head>',observer+'</head>',1)if '</head>'in child_html else child_html.replace('<script',observer+'<script',1))
workflow_hash=hashlib.sha256((output/'workflow.html').read_bytes()).hexdigest()[:12]
editor_hash=hashlib.sha256((output/'native/index.html').read_bytes()).hexdigest()[:12]
photos=root/'scripts/photo-studio'
photo_html=(photos/'template.html').read_text().replace('</head>',observer+'</head>',1).replace('__CSS__',(photos/'style.css').read_text()+'\n'+(photos/'recipes.css').read_text()+'\n'+(photos/'storyboard.css').read_text()+'\n'+(photos/'providers.css').read_text()+'\n'+(photos/'story-production.css').read_text()).replace('__JS__',(root/'scripts/shared/recipes.js').read_text()+'\n'+(root/'scripts/shared/provider-receipts.js').read_text()+'\n'+(root/'scripts/shared/clip-planning.js').read_text()+'\n'+(root/'scripts/shared/image-quality.js').read_text()+'\n'+(photos/'app.js').read_text()+'\n'+(photos/'recipes.js').read_text()+'\n'+(photos/'storyboard.js').read_text()+'\n'+(photos/'design-layout.js').read_text()+'\n'+(photos/'production.js').read_text()+'\n'+(photos/'providers.js').read_text()+'\n'+(photos/'gemini-chat.js').read_text()+'\n'+(photos/'clip-flow.js').read_text()+'\n'+(photos/'toolbar.js').read_text()+'\n'+(photos/'story-production.js').read_text())
(output/'photos.html').write_text(photo_html)
photo_hash=hashlib.sha256(photo_html.encode()).hexdigest()[:12]
source=root/'scripts/app-shell'
preview=(root/'preview.html').read_text()
def sample_literal(marker):
 return json.JSONDecoder().raw_decode(preview[preview.index(marker)+len(marker):])[0]
showcase_sample=json.dumps({'video':sample_literal('const DEMO_VIDEO='),'frames':sample_literal('const DEMO_FRAMES=')})
html=(source/'template.html').read_text().replace('__CSS__',(source/'style.css').read_text()+'\n'+(source/'layout.css').read_text()+'\n'+(source/'desk-design.css').read_text()+'\n'+(source/'package5.css').read_text()+'\n'+(source/'machine-checks.css').read_text()+'\n'+(source/'accounts-dashboard.css').read_text()+'\n'+(source/'package6.css').read_text()+'\n'+(source/'topbar.css').read_text()+'\n'+(source/'home-archive.css').read_text()+'\n'+(source/'reference-library.css').read_text()+'\n'+(source/'sidebar-compact.css').read_text()+'\n'+(source/'workflow-navigation.css').read_text()+'\n'+(source/'shell-alignment.css').read_text()+'\n'+(source/'batch-studio.css').read_text()+'\n'+(source/'recipe-library-v3.css').read_text()).replace('__JS__',((root/'scripts/shared/recipes.js').read_text()+'\n'+(source/'library-runtime.js').read_text()+'\n'+(source/'app.js').read_text()+'\n'+(source/'package4.js').read_text()+'\n'+(source/'recipes.js').read_text()+'\n'+(source/'showcase.js').read_text().replace('__SHOWCASE_SAMPLE__',showcase_sample)+'\n'+(source/'workflow-navigation.js').read_text()+'\n'+(source/'desk-icons.js').read_text()+'\n'+(source/'package5.js').read_text()+'\n'+(source/'machine-checks.js').read_text().replace('__CHECK_SHEET__',(source/'check-sheet.json').read_text().strip()).replace('__CHECK_FONT__',(source/'check-font.json').read_text().strip())+'\n'+(source/'accounts-dashboard.js').read_text()+'\n'+(source/'analysis-v3-settings.js').read_text()+'\n'+(source/'package6.js').read_text()+'\n'+(source/'storyboard-library.js').read_text()+'\n'+(source/'home-archive.js').read_text()+'\n'+(source/'reference-library.js').read_text()+'\n'+(source/'topbar.js').read_text()+'\n'+(source/'library-portable.js').read_text()+'\n'+(source/'library-panel.js').read_text()+'\n'+(source/'recovery.js').read_text()+'\n'+(source/'batch-studio.js').read_text()+'\n'+(source/'archive-lifecycle.js').read_text()+'\n'+(source/'recipe-library-v3.js').read_text()+'\n'+(source/'account-dispatch.js').read_text()+'\n'+(source/'storage-actions.js').read_text()).replace('__PHOTO_HASH__',photo_hash).replace('__WORKFLOW_HASH__',workflow_hash).replace('__EDITOR_HASH__',editor_hash))
for key,path in icons.items():html=html.replace('__'+key+'__','<svg viewBox="0 0 24 24" aria-hidden="true">'+path+'</svg>')
html=html.replace('SceneForge-Goi4-Local.zip','SceneForge-TongHop-Local.zip').replace('SceneForge-Goi5-Local.zip','SceneForge-TongHop-Local.zip')
for name in ('index.html','studio.html'):(output/name).write_text(html)
# Retain the earlier interactive prototype at its existing separate URL.
shutil.copyfile(root / 'concat-demo.html', output / 'editor.html')
(output / '.nojekyll').write_text('')
(output / 'README.md').write_text('SceneForge Studio multi-track browser editor: file/library drag-drop, automatic tracks, clip trim/split, insertion modes, visual effects and keyframes, merged text/subtitles, SRT/VTT import and SRT/ASS export, and browser recording export when supported. Optional local companion supports Gemini analysis and CPU scene/OCR/transcription adapters; CPU models require separate setup. Flow/Muse adapters and shared account routing are integrated; actual provider generation requires a compatible verified session and has not been certified by fixture tests. Concat native references remain at native/reference.html.\n')
print('Built integrated static site:', output)
