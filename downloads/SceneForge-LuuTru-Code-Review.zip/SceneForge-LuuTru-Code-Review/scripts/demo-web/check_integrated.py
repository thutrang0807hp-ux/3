from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist')))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1536,'height':1024});errors=[];failed=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:failed.append((r.status,r.url)) if r.status>=400 and 'favicon' not in r.url else None)
  url=f'http://127.0.0.1:{server.server_port}/web-demo/'
  page.goto(url,wait_until='networkidle')
  for nav in ['library','analysis','queue','settings','overview']:
   page.locator(f'[data-nav="{nav}"]').click()
   expect(page.locator(f'[data-nav="{nav}"]')).to_have_attribute('aria-current','page')
   assert page.url.endswith('#'+nav)
   if nav=='analysis':
    flow=page.frame_locator('#workflowFrame');flow.locator('[data-mode-open=reference]').click();expect(flow.locator('#node-source')).to_be_visible();flow.locator('[data-action=projects]').first.click();flow.locator('[data-action=back-studio]').click();expect(page.locator('[data-nav=overview]')).to_have_attribute('aria-current','page')
  page.locator('[data-nav="editor"]').click()
  frame=page.frame_locator('#standaloneEditorDemo')
  expect(frame.locator('#stage')).to_be_visible()
  # Shortcuts work after the sidebar was clicked, before focusing the iframe.
  page.keyboard.press('Space')
  page.wait_for_function('document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.getState().time>.1')
  page.keyboard.press('Space')
  page.wait_for_function('!document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.isPlaying()')
  frame.locator('body').evaluate('()=>SceneForgeEditor.seek(2)')
  page.keyboard.press('Control+b')
  page.wait_for_function('document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.getState().items.length===4')
  page.keyboard.press('Control+z')
  page.wait_for_function('document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.getState().items.length===3')
  frame.locator('body').evaluate('()=>window.integrationVideo=document.querySelector("#stageLayers video")')
  frame.locator('[data-library=text]').click()
  expect(frame.locator('.salesTextGrid')).to_be_visible()
  page.screenshot(path='/tmp/sceneforge-integrated-desktop.png',full_page=True)
  frame.locator('#play').click()
  page.wait_for_function('document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.getState().time>.2')
  frame.locator('#editorStudioHome').click()
  page.wait_for_function('!document.querySelector("#standaloneEditorDemo").contentWindow.SceneForgeEditor.isPlaying()')
  page.locator('[data-nav="editor"]').click()
  expect(frame.locator('.salesTextGrid')).to_be_visible()
  assert frame.locator('body').evaluate('()=>window.integrationVideo===document.querySelector("#stageLayers video")')
  frame.locator('[data-library=captions]').click()
  expect(frame.locator('.sharedCaptionPresets')).to_be_visible()
  assert page.locator('#standaloneEditorDemo').count()==1
  assert frame.locator('main').evaluate('(e)=>e.getBoundingClientRect().width>=innerWidth-1')
  assert frame.locator('#timeline').evaluate('(e)=>e.getBoundingClientRect().bottom<=innerHeight+1')
  assert not page.locator('.app-rail').is_visible()
  page.reload(wait_until='networkidle')
  expect(page.locator('[data-nav="editor"]')).to_have_attribute('aria-current','page')
  expect(page.frame_locator('#standaloneEditorDemo').locator('#stage')).to_be_visible()
  page.set_viewport_size({'width':1024,'height':768})
  page.screenshot(path='/tmp/sceneforge-integrated-mobile.png',full_page=True)
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  assert frame.locator('body').evaluate('()=>document.documentElement.scrollWidth<=innerWidth+1')
  assert not errors,errors
  assert not failed,failed
  browser.close()
 print('PASS: all Studio navigation, shared editor panels, video playback/pause on leave, preserved media node, full-width viewport and visible timeline, direct editor URL, 1024px editor width, no JS or asset errors.')
finally:server.shutdown();server.server_close();thread.join()
