// Compact audio controls and point-of-cut inspector.
let intervalPreviewToken=0;
function previewInterval(start,finish){
 const token=++intervalPreviewToken;effectPreviewToken++;pause();time=clamp(start,0,total());togglePlay();
 const check=()=>{if(token!==intervalPreviewToken||!playing)return;if(time>=finish){pause();time=Math.min(finish,total());updateStage(true);return;}requestAnimationFrame(check);};requestAnimationFrame(check);
}
// Keep the full inspector available; the mini strip is a shortcut, not its replacement.
let audioPanelView='basic';
const soundPresets={
 clear:{name:'Giọng rõ',description:'Giảm ù thấp, nhấn nhẹ độ rõ.',values:{audioHighpass:85,audioMid:2,audioTreble:2,audioThreshold:-20,audioRatio:2}},
 warm:{name:'Ấm hơn',description:'Thêm âm trầm nhẹ, dịu tiếng cao.',values:{audioBass:3,audioTreble:-2}},
 soft:{name:'Dịu tiếng cao',description:'Giảm dải cao chói; vẫn chỉnh tay được.',values:{audioTreble:-5,audioLowpass:12000}}
};
function soundEffectDefaults(){return Object.fromEntries([...Object.keys(audioParameterLimits),'audioPreset'].map(k=>[k,extraDefaults()[k]]));}
function soundControl(key,label,unit,step=1){const i=selected(),bounds=audioParameterLimits[key];return '<label class="soundParameter"><span>'+label+' <output data-sound-value="'+key+'">'+i[key]+' '+unit+'</output></span><input type="range" data-sound-param="'+key+'" min="'+bounds[0]+'" max="'+bounds[1]+'" step="'+step+'" value="'+i[key]+'" aria-label="'+label+'"><input type="number" data-sound-number="'+key+'" min="'+bounds[0]+'" max="'+bounds[1]+'" step="'+step+'" value="'+i[key]+'" aria-label="'+label+' giá trị"></label>';}
function audioInspectorPanel(){
 const i=selected(),pane=$('[data-inspector-pane=audio]');if(!i||!pane||!['video','audio'].includes(i.kind))return;
 const extraction=pane.querySelector('#extractAudio');if(extraction)extraction.hidden=false;
 const basic=document.createElement('div');basic.id='audioBasicControls';basic.append(...pane.childNodes);pane.append(basic);
 const volume=basic.querySelector('#prop-volume');if(volume){volume.max=2000;const range=volume.parentElement.querySelector('input[type=range]');if(range){range.max=2000;range.value=volume.value;}}
 const nav=document.createElement('div');nav.className='audioPaneModes';nav.innerHTML='<button data-audio-view="basic">Cơ bản</button><button data-audio-view="effects">Hiệu ứng âm thanh</button>';pane.prepend(nav);
 const fx=document.createElement('section');fx.id='audioEffectsControls';fx.innerHTML='<div class="soundEffectHeader"><b>Hiệu ứng âm thanh</b><button data-sound-bypass aria-pressed="'+!i.audioBypass+'">'+(i.audioBypass?'Đang tắt':'Đang bật')+'</button></div><p class="inspectorDescription">Áp dụng cho clip đang chọn. Bật/tắt để nghe đối chiếu; không thay đổi âm lượng gốc.</p><div class="audioPresetGrid">'+Object.entries(soundPresets).map(([id,p])=>'<button data-audio-preset="'+id+'" aria-pressed="'+(i.audioPreset===id)+'"><b>'+p.name+'</b><small>'+p.description+'</small></button>').join('')+'</div><details open class="soundSection"><summary>Cân bằng âm sắc · EQ</summary>'+soundControl('audioBass','Âm trầm','dB')+soundControl('audioMid','Âm trung','dB')+soundControl('audioTreble','Âm cao','dB')+'</details><details class="soundSection"><summary>Lọc dải tần</summary>'+soundControl('audioHighpass','Cắt tần số thấp','Hz',5)+soundControl('audioLowpass','Cắt tần số cao','Hz',100)+'<p class="inspectorDescription">Bộ lọc tần số giúp giảm ù hoặc chói; không phải khử nhiễu AI.</p></details><details class="soundSection"><summary>Giữ mức tiếng đều hơn</summary>'+soundControl('audioThreshold','Ngưỡng nén','dB')+soundControl('audioRatio','Tỉ lệ nén',':1',.1)+'</details><details class="soundSection"><summary>Cân trái / phải & gain bổ sung</summary>'+soundControl('audioPan','Cân trái / phải','%')+soundControl('audioGainDb','Gain bổ sung','dB',.5)+'</details><button data-sound-reset class="wide">Đặt lại riêng hiệu ứng</button><p class="inspectorDescription">Thay đổi nghe được khi phát và được giữ trong tệp xuất.</p>';
 pane.append(fx);setAudioPanelView(audioPanelView);
 if(getTrack(i.trackId).locked||recording)pane.querySelectorAll('input,select,button:not([data-audio-view])').forEach(n=>n.disabled=true);
 updateMiniAudio();
}
function setAudioPanelView(view){audioPanelView=view;for(const b of $$('[data-audio-view]'))b.setAttribute('aria-pressed',String(b.dataset.audioView===view));const basic=$('#audioBasicControls'),effects=$('#audioEffectsControls');if(basic)basic.hidden=view!=='basic';if(effects)effects.hidden=view!=='effects';}
function openSoundInspector(){if(!miniAudioTarget())return;closeMiniOptions();document.body.classList.remove('inspector-collapsed');inspector();switchInspectorTab('audio');setAudioPanelView('effects');}
$('#inspector').addEventListener('click',e=>{
 const view=e.target.closest('[data-audio-view]');if(view){setAudioPanelView(view.dataset.audioView);return;}
 const action=e.target.closest('[data-audio-preset],[data-sound-bypass],[data-sound-reset]');if(!action)return;
 const i=miniCanEdit();if(!i)return;
 transact(()=>{if(action.hasAttribute('data-sound-bypass'))i.audioBypass=!i.audioBypass;else{Object.assign(i,soundEffectDefaults());i.audioBypass=action.hasAttribute('data-sound-reset');const preset=soundPresets[action.dataset.audioPreset];if(preset){Object.assign(i,preset.values);i.audioPreset=action.dataset.audioPreset;}}});
});
function changeSoundParameter(input,rememberEdit){const i=miniCanEdit(),key=input.dataset.soundParam||input.dataset.soundNumber,value=Number(input.value);if(!i||!audioParameterLimits[key]||!Number.isFinite(value))return false;if(rememberEdit)remember();i[key]=clamp(value,...audioParameterLimits[key]);i.audioBypass=false;i.audioPreset='custom';const pane=$('#audioEffectsControls');for(const n of pane.querySelectorAll('[data-sound-param="'+key+'"],[data-sound-number="'+key+'"]'))if(n!==input)n.value=i[key];const output=pane.querySelector('[data-sound-value="'+key+'"]');output.textContent=i[key]+(key==='audioPan'?' %':key==='audioRatio'?' :1':key.includes('pass')?' Hz':' dB');const toggle=pane.querySelector('[data-sound-bypass]');toggle.textContent='Đang bật';toggle.setAttribute('aria-pressed','true');pane.querySelectorAll('[data-audio-preset]').forEach(n=>n.setAttribute('aria-pressed','false'));updateStage();return true;}
$('#inspector').addEventListener('input',e=>{if(!e.target.dataset.soundParam)return;const n=e.target;if(changeSoundParameter(n,!n.dataset.history))n.dataset.history='1';});
$('#inspector').addEventListener('change',e=>{const n=e.target;if(n.dataset.soundParam){delete n.dataset.history;timeline();scheduleDraft();}else if(n.dataset.soundNumber&&changeSoundParameter(n,true)){timeline();scheduleDraft();}});
function transitionInspectorPanel(){
 const i=selected(),pane=$('[data-inspector-pane=transition]');if(!i||!pane||selectedIds.size>1)return;
 const next=joinAfter(i);if(!next){pane.innerHTML='<div class="contextTip">Chưa có clip liền sau trên cùng track. Đặt hai clip sát nhau để thêm chuyển cảnh.</div>';return;}
 const names={none:'Cắt thẳng',dissolve:'Hòa hai hình',fade:'Mờ qua đen',slide:'Trượt ngang / dọc',wipe:'Quét khung'},limit=joinLimit(i,next),duration=Math.min(i.transitionDuration,limit);
 pane.innerHTML='<section id="transitionDetails" class="advancedInspector"><h4>Chuyển cảnh tại điểm nối</h4><div class="joinClipPair">'+[i,next].map((clip,n)=>'<div><img src="'+esc(getAsset(clip.assetId)?.poster||FRAMES[n])+'" alt=""><small>'+(n?'Vào':'Ra')+' · '+esc(clip.name)+'</small></div>').join('')+'</div><p class="inspectorDescription">'+fmt(end(i))+' · '+esc(i.name)+' → '+esc(next.name)+'</p>'+selectField('Kiểu chuyển cảnh','transition',i.transition,Object.entries(names))+field('Thời lượng (giây)','transitionDuration',duration,'number',`min="0.1" max="${limit}" step="0.05"`)+`<input id="joinDurationSlider" type="range" min="0.1" max="${limit}" step="0.05" value="${duration}" aria-label="Độ dài chuyển cảnh trên điểm nối">`+'<label class="advancedSelect">Hướng chuyển<select data-transition-option="transitionDirection" '+(!['slide','wipe'].includes(i.transition)?'disabled':'')+'>'+[['left','← Sang trái'],['right','→ Sang phải'],['up','↑ Lên trên'],['down','↓ Xuống dưới']].map(([id,label])=>'<option value="'+id+'" '+(i.transitionDirection===id?'selected':'')+'>'+label+'</option>').join('')+'</select></label><label class="advancedSelect">Nhịp chuyển<select data-transition-option="transitionEasing" '+(!['dissolve','slide','wipe'].includes(i.transition)?'disabled':'')+'>'+[['linear','Đều'],['easeInOut','Mượt đầu & cuối'],['easeIn','Chậm → nhanh'],['easeOut','Nhanh → chậm']].map(([id,label])=>'<option value="'+id+'" '+(i.transitionEasing===id?'selected':'')+'>'+label+'</option>').join('')+'</select></label><p class="inspectorDescription">Tối đa '+limit.toFixed(2)+' giây theo độ dài hai clip. Có thể kéo hai mép khối chuyển cảnh trên timeline.</p><div class="advancedActions"><button data-transition-preview>▶ Xem điểm nối</button><button data-transition-remove>Bỏ chuyển cảnh</button></div><button id="applyTransitions" class="wide">Áp dụng kiểu & thời lượng cho các điểm nối cùng track</button></section>';
}
const inspectorBeforeAdvanced=inspector;
inspector=function(){
 const focused=selected(),savedIds=selectedIds,linkedAudio=['audio','video'].includes(focused?.kind)&&focused.linkGroup&&selectedIds.size>1&&items.filter(i=>selectedIds.has(i.id)).every(i=>i.linkGroup===focused.linkGroup);
 if(linkedAudio)selectedIds=new Set([focused.id]);
 try{inspectorBeforeAdvanced();}finally{selectedIds=savedIds;}
 audioInspectorPanel();transitionInspectorPanel();
};
$('#inspector').addEventListener('input',e=>{
 const input=e.target,i=selected();if(input.id==='joinDurationSlider'&&i&&!getTrack(i.trackId).locked){if(!input.dataset.history){remember();input.dataset.history='1';}const next=joinAfter(i);if(!next)return;i.transitionDuration=clamp(Number(input.value),.1,joinLimit(i,next));$('#prop-transitionDuration').value=i.transitionDuration;paintJoinBlocks();updateStage(true);}
});
$('#inspector').addEventListener('change',e=>{
 const input=e.target,i=selected();if(!i||getTrack(i.trackId).locked)return;
 if(input.id==='joinDurationSlider'){delete input.dataset.history;timeline();inspector();scheduleDraft();}
 if(input.dataset.transitionOption){const key=input.dataset.transitionOption,allowed=key==='transitionDirection'?['left','right','up','down']:['linear','easeIn','easeOut','easeInOut'];if(allowed.includes(input.value))transact(()=>i[key]=input.value);}
});
$('#inspector').addEventListener('click',e=>{
 const i=selected();if(!i||getTrack(i.trackId).locked)return;
 if(e.target.closest('[data-transition-preview]')){const next=joinAfter(i);if(next){const d=Math.min(i.transitionDuration,joinLimit(i,next));previewInterval(Math.max(i.start,end(i)-d/2-.3),Math.min(end(next),end(i)+d/2+.3));}}
 if(e.target.closest('[data-transition-remove]'))applyJoin(i.id,'none');
});
// Preserve visible labels each time the original chrome redecorates icons.
const timelineControlsBeforeAdvanced=decorateTimelineControls;
decorateTimelineControls=function(){timelineControlsBeforeAdvanced();decorateButton('split','split','Cắt · Ctrl+B',true);};
decorateTransport=function(){decorateButton('play',playing?'pause':'play',playing?'Dừng · Space':'Phát · Space',true);};
const framePresets={'9:16':{width:1080,height:1920},'16:9':{width:1920,height:1080},'1:1':{width:1080,height:1080},'4:5':{width:1080,height:1350}};
const frameSelect=document.createElement('select');frameSelect.id='projectAspect';frameSelect.setAttribute('aria-label','Tỉ lệ khung hình dự án');frameSelect.innerHTML='<option value="9:16">9:16 · Dọc</option><option value="16:9">16:9 · Ngang</option><option value="1:1">1:1 · Vuông</option><option value="4:5">4:5 · Dọc</option><option value="custom">Tùy chỉnh…</option>';$('.previewHead').append(frameSelect);
const frameDialog=document.createElement('dialog');frameDialog.id='frameDialog';frameDialog.innerHTML='<h3>Khung hình tùy chỉnh</h3><p>Đổi tỉ lệ toàn bộ bản dựng. Clip giữ cách lấp khung đang chọn.</p><label>Chiều rộng <input id="frameWidth" type="number" min="240" max="3840" step="2"></label><label>Chiều cao <input id="frameHeight" type="number" min="240" max="3840" step="2"></label><p id="frameError" role="status"></p><button id="cancelFrame">Hủy</button><button id="applyFrame">Áp dụng</button>';document.body.append(frameDialog);
function frameName(){return Object.entries(framePresets).find(([,value])=>value.width===projectFrame.width&&value.height===projectFrame.height)?.[0]||'custom';}
function updateFrameChrome(){
 const name=frameName();frameSelect.value=name;const label=projectFrame.width+' × '+projectFrame.height+' · '+(name==='custom'?'Tùy chỉnh':name);
 $('.previewHead>span:nth-child(2)').textContent=label;const title=$('header strong');title.textContent='SceneForge · Dựng video '+(name==='custom'?'Tùy chỉnh':name);
 $('#stage').style.aspectRatio=projectFrame.width+' / '+projectFrame.height;
 $('#exportDialog h2').textContent='Xuất video';
 for(const option of $$('#exportSize option')){const d=frameDimensions(Number(option.value));option.textContent=d.width+' × '+d.height;}
 $('#summary').textContent=$('#summary').textContent.replace(/9:16$/,name==='custom'?projectFrame.width+':'+projectFrame.height:name);
 const fitLabel=$('label[for=prop-fit]');if(fitLabel)fitLabel.textContent='Cách lấp khung '+(name==='custom'?'tùy chỉnh':name);
 const sequence=$('.sequenceHead>span small');if(sequence)sequence.textContent=name==='custom'?projectFrame.width+':'+projectFrame.height:name;
 $('#safe').title='Vùng an toàn · '+label;
}
frameSelect.onchange=()=>{if(recording){updateFrameChrome();return;}if(frameSelect.value==='custom'){$('#frameWidth').value=projectFrame.width;$('#frameHeight').value=projectFrame.height;$('#frameError').textContent='';frameDialog.showModal();return;}pause();transact(()=>projectFrame={...framePresets[frameSelect.value]});};
$('#cancelFrame').onclick=()=>{frameDialog.close();updateFrameChrome();};frameDialog.addEventListener('cancel',()=>queueMicrotask(updateFrameChrome));
$('#applyFrame').onclick=()=>{const width=Number($('#frameWidth').value),height=Number($('#frameHeight').value);if(!Number.isFinite(width)||!Number.isFinite(height)||width<240||height<240||width>3840||height>3840){$('#frameError').textContent='Mỗi chiều cần từ 240 đến 3840 px.';return;}pause();transact(()=>projectFrame=validFrame({width,height}));frameDialog.close();};
const decorateBeforeAdvanced=decorateEditorControls;
decorateEditorControls=function(){decorateBeforeAdvanced();updateFrameChrome();updateMiniAudio();};
const shortcutsButton=document.createElement('button');shortcutsButton.id='keyboardHelp';shortcutsButton.textContent='⌨ Phím tắt';shortcutsButton.title='Các phím dựng video';$('.transport').append(shortcutsButton);
const shortcutsDialog=document.createElement('dialog');shortcutsDialog.id='keyboardDialog';shortcutsDialog.innerHTML='<h3>Phím tắt dựng video</h3><dl>'+[['Space / K','Phát hoặc tạm dừng'],['Ctrl / Cmd + B','Cắt các clip đang chọn tại vạch phát'],['← / →','Tua từng khung hình (24 fps)'],['Shift + ← / →','Tua 1 giây'],['Home / End','Về đầu / cuối bản dựng'],['Ctrl / Cmd + Z','Hoàn tác'],['Ctrl / Cmd + Shift + Z','Làm lại'],['Ctrl / Cmd + D','Nhân đôi'],['Delete','Xóa clip hoặc chuyển cảnh đang chọn'],['Ctrl / Cmd + S','Lưu dự án'],['Esc','Hủy kéo / bỏ chọn']].map(([key,label])=>'<dt><kbd>'+key+'</kbd></dt><dd>'+label+'</dd>').join('')+'</dl><p>Phím dựng tạm ngưng khi đang nhập chữ, chỉnh ô số hoặc mở hộp thoại.</p><button id="closeKeyboard">Đóng</button>';document.body.append(shortcutsDialog);
shortcutsButton.onclick=()=>shortcutsDialog.showModal();$('#closeKeyboard').onclick=()=>shortcutsDialog.close();
function editorShortcut(e){
 if(activeClipDrag&&e.key!=='Escape'){e.preventDefault();e.stopImmediatePropagation();return true;}
 if(e.key==='Escape'&&handleMiniEscape()){e.preventDefault();e.stopImmediatePropagation();return true;}
 if(e.defaultPrevented||e.isComposing||e.altKey||['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName)||e.target?.isContentEditable||$('dialog[open]'))return false;
 const mod=e.ctrlKey||e.metaKey,key=e.key.toLowerCase();let action;
 if(recording)return false;
 if((e.code==='Space'||key===' '||key==='k')&&!mod)action=togglePlay;
 if(mod&&key==='b')action=()=>commands.split();
 if(mod&&key==='s')action=()=>$('#saveProject').click();
 if(mod&&key==='z')action=()=>commands[e.shiftKey?'redo':'undo']();
 if(mod&&key==='d')action=()=>commands.duplicate();
 if(mod&&key==='a')action=()=>{selectedIds=new Set(items.map(i=>i.id));selection=items[0]?.id||null;timeline();inspector();updateSelectionSummary();};
 if(!mod&&['Delete','Backspace'].includes(e.key))action=()=>{if(selectedJoin){applyJoin(selectedJoin,'none');selectedJoin=null;}else commands.delete();};
 if(!mod&&e.key==='Escape'){if(document.body.classList.contains('timeline-drag-active'))return false;action=()=>{selectedJoin=null;choose(null);};}
 if(!mod&&['ArrowUp','ArrowDown'].includes(e.key))action=()=>jumpCut(e.key==='ArrowDown'?1:-1);

 if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)&&!mod)action=()=>{pause();time=e.key==='Home'?0:e.key==='End'?total():clamp(time+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?1:1/24),0,total());updateStage(true);};
 if(!action)return false;e.preventDefault();e.stopImmediatePropagation();action();return true;
}
window.addEventListener('keydown',editorShortcut,true);
// Only the same-origin studio may forward keys while its editor tab is visible.
window.addEventListener('message',e=>{if(e.source!==parent||e.origin!==location.origin||e.data?.type!=='sceneforge:editor-shortcut')return;const k=e.data;editorShortcut({key:String(k.key||''),code:String(k.code||''),ctrlKey:!!k.ctrlKey,metaKey:!!k.metaKey,shiftKey:!!k.shiftKey,target:document.activeElement,preventDefault(){},stopImmediatePropagation(){}});});
window.SceneForgeEditor.getAudioStatus=()=>({state:exportAudioContext?.state||'idle',routes:audioSources.size});
// Essential sound controls sit directly above the timeline.
const miniAudio=document.createElement('div');miniAudio.id='miniAudioControls';miniAudio.hidden=true;
miniAudio.innerHTML='<span id="miniAudioName"></span><button id="miniMute" title="Tắt / bật tiếng clip" aria-label="Tắt / bật tiếng clip">'+uiIcon('volume')+'</button><input id="miniVolumeSlider" type="range" min="-60" max="26.0206" step="0.1" value="0" aria-label="Âm lượng clip"><label class="miniVolumeValue"><input id="miniVolume" type="number" min="0" max="2000" step="1" value="100" aria-label="Âm lượng clip phần trăm"><span>%</span></label><button id="miniAudioMore" aria-label="Vào ra dần và tốc độ âm thanh" aria-expanded="false" title="Vào/ra dần · tốc độ · mốc âm lượng">'+uiIcon('sliders')+'</button>';
$('.sequenceHead').append(miniAudio);
const soundPanelButton=document.createElement('button');soundPanelButton.id='miniAudioEffects';soundPanelButton.title='Mở bảng hiệu ứng âm thanh';soundPanelButton.setAttribute('aria-label',soundPanelButton.title);soundPanelButton.textContent='FX';$('#miniAudioMore').before(soundPanelButton);soundPanelButton.onclick=openSoundInspector;
const miniAudioOptions=document.createElement('div');miniAudioOptions.id='miniAudioOptions';miniAudioOptions.hidden=true;miniAudioOptions.innerHTML='<div class="miniAudioOptionsTitle"><b>Âm thanh</b><button id="closeMiniAudio" aria-label="Đóng chỉnh âm thanh">×</button></div><div class="miniFadeRow"><label>Vào dần <input id="miniFadeIn" type="number" min="0" step="0.1" value="0" aria-label="Âm thanh vào dần"> s</label><label>Ra dần <input id="miniFadeOut" type="number" min="0" step="0.1" value="0" aria-label="Âm thanh ra dần"> s</label></div><label class="miniSpeedRow">Tốc độ <select id="miniSpeed" aria-label="Tốc độ âm thanh"><option value="0.25">0,25×</option><option value="0.5">0,5×</option><option value="0.75">0,75×</option><option value="1">1×</option><option value="1.25">1,25×</option><option value="1.5">1,5×</option><option value="2">2×</option><option value="3">3×</option></select></label><div class="miniAudioActions"><button id="miniResetVolume">Về 100%</button><button id="miniVolumeKeyframe">◇ Mốc âm lượng</button><button id="miniExtractAudio">Tách tiếng</button></div><p>Đoạn nhỏ: cắt riêng rồi tăng âm lượng, hoặc đặt mốc trước/sau đoạn đó. Tối đa 2.000%.</p>';
$('#timeline').append(miniAudioOptions);
function miniAudioTarget(){const i=selected();return i&&['video','audio'].includes(i.kind)?i:null;}
function updateMiniAudio(){
 const i=miniAudioTarget();miniAudio.hidden=!i;$('.sequenceHead').classList.toggle('hasMiniAudio',!!i);
 if(!i){miniAudioOptions.hidden=true;return;}
 const value=evaluateProps(i).volume,percent=Math.round(value*100),locked=!!getTrack(i.trackId).locked;
 const panelVolume=$('#prop-volume');if(panelVolume&&document.activeElement!==panelVolume){panelVolume.value=percent;const range=panelVolume.parentElement.querySelector('input[type=range]');if(range&&document.activeElement!==range)range.value=percent;}
 $('#miniAudioName').textContent=i.name;$('#miniAudioName').title=i.name;
 if(document.activeElement!==$('#miniVolume'))$('#miniVolume').value=percent;
 if(document.activeElement!==$('#miniVolumeSlider')&&!$('#miniVolumeSlider').dataset.history)$('#miniVolumeSlider').value=value>0?Math.max(-60,20*Math.log10(value)):-60;
 $('#miniVolumeSlider').setAttribute('aria-valuetext',percent+'%');$('#miniMute').setAttribute('aria-pressed',String(!!i.audioMuted));$('#miniMute').title=i.audioMuted?'Bật tiếng clip':'Tắt tiếng clip';
 for(const [id,key]of [['miniFadeIn','fadeIn'],['miniFadeOut','fadeOut']]){const n=$('#'+id);if(document.activeElement!==n)n.value=i[key];n.max=i.duration;}
 if(document.activeElement!==$('#miniSpeed'))$('#miniSpeed').value=i.speed;
 $('#miniExtractAudio').hidden=i.kind!=='video';
 for(const input of [...miniAudio.querySelectorAll('input,button'),...miniAudioOptions.querySelectorAll('input,select,button')])if(!['closeMiniAudio','miniAudioMore'].includes(input.id))input.disabled=locked||recording;
}
function miniCanEdit(){const i=miniAudioTarget();if(!i||recording)return null;if(getTrack(i.trackId).locked){notify('Mở khóa track trước khi chỉnh âm thanh.');return null;}return i;}
function changeMiniVolume(value){const i=miniCanEdit();if(!i)return;transact(()=>{i.volume=clamp(value,0,20);updateKeyframedProp(i,'volume',i.volume);});}
$('#miniVolume').onchange=e=>{const value=Number(e.target.value);if(!Number.isFinite(value)||value<0||value>2000){notify('Âm lượng từ 0 đến 2.000%.');updateMiniAudio();return;}changeMiniVolume(value/100);};
$('#miniVolumeSlider').oninput=e=>{if(suppressMiniVolumeInput){syncMiniVolumeValue();return;}const i=miniCanEdit();if(!i)return;if(!e.target.dataset.history){remember();e.target.dataset.history='1';}i.volume=Number(e.target.value)<=-60?0:Math.min(20,Math.pow(10,Number(e.target.value)/20));updateKeyframedProp(i,'volume',i.volume);$('#miniVolume').value=Math.round(i.volume*100);e.target.setAttribute('aria-valuetext',Math.round(i.volume*100)+'%');updateStage();};
$('#miniVolumeSlider').onchange=e=>{if(suppressMiniVolumeInput){syncMiniVolumeValue();return;}delete e.target.dataset.history;if(miniVolumeSession)finishMiniVolume(false);else{timeline();scheduleDraft();updateMiniAudio();}};
$('#miniMute').onclick=()=>{const i=miniCanEdit();if(i)transact(()=>i.audioMuted=!i.audioMuted);};
$('#miniResetVolume').onclick=()=>changeMiniVolume(1);
for(const [id,key]of [['miniFadeIn','fadeIn'],['miniFadeOut','fadeOut']])$('#'+id).onchange=e=>{const i=miniCanEdit(),value=Number(e.target.value);if(i&&Number.isFinite(value))transact(()=>i[key]=clamp(value,0,i.duration));};
$('#miniSpeed').onchange=e=>{if(miniCanEdit())setProp({type:'number',value:e.target.value,dataset:{prop:'speed'}});e.target.value=miniAudioTarget()?.speed||1;};
$('#miniAudioMore').onclick=()=>{miniAudioOptions.hidden=!miniAudioOptions.hidden;$('#miniAudioMore').setAttribute('aria-expanded',String(!miniAudioOptions.hidden));};
$('#closeMiniAudio').onclick=()=>{miniAudioOptions.hidden=true;$('#miniAudioMore').setAttribute('aria-expanded','false');};
$('#miniExtractAudio').onclick=()=>{if(miniCanEdit()){$('#extractAudio')?.click();closeMiniOptions();}};
$('#miniVolumeKeyframe').onclick=()=>{const i=miniCanEdit();if(!i)return;if(time<i.start||time>end(i)){notify('Đặt vạch phát vào đoạn âm thanh cần chỉnh.');return;}transact(()=>{const at=clamp(time-i.start,0,i.duration),values=evaluateProps(i);if(!i.keyframes.length)i.keyframes=[{at:0,values:clone(values)},{at:i.duration,values:clone(values)}];if(!i.keyframes.some(k=>Math.abs(k.at-at)<.01))i.keyframes.push({at,values:clone(values)});});notify('Đã đặt mốc âm lượng. Tua tới mốc khác để chỉnh riêng đoạn nhỏ.');};
const transportBeforeMini=decorateTransport;
decorateTransport=function(){transportBeforeMini();updateMiniAudio();};
const miniChoose=choose;
choose=function(...args){const prior=selection;miniChoose(...args);if(prior!==selection){miniAudioOptions.hidden=true;$('#miniAudioMore').setAttribute('aria-expanded','false');}updateMiniAudio();};
const compactVolumeCommand=toolCommands.find(command=>command[0]==='volume');
if(compactVolumeCommand)compactVolumeCommand[4]=()=>{if(!miniAudioTarget()){notify('Chọn clip video hoặc âm thanh trên timeline.');return;}$('#miniVolume').focus();$('#miniVolume').select();};

// Treat a volume fader drag as one cancellable edit, like a timeline clip drag.
let miniVolumeSession=null,suppressMiniVolumeInput=false;
function syncMiniVolumeValue(){const i=miniAudioTarget();if(!i)return;const value=evaluateProps(i).volume;$('#miniVolumeSlider').value=value>0?Math.max(-60,20*Math.log10(value)):-60;$('#miniVolume').value=Math.round(value*100);$('#miniVolumeSlider').setAttribute('aria-valuetext',Math.round(value*100)+'%');}
function finishMiniVolume(cancel){
 const session=miniVolumeSession;if(!session)return;miniVolumeSession=null;
 delete $('#miniVolumeSlider').dataset.history;
 if(cancel){items=session.items;undo=session.undo;redo=session.redo;suppressMiniVolumeInput=true;render();}
 else{if(JSON.stringify(items)===JSON.stringify(session.items)){undo=session.undo;redo=session.redo;}timeline();scheduleDraft();}
 syncMiniVolumeValue();updateMiniAudio();
}
$('#miniVolumeSlider').addEventListener('pointerdown',()=>{if(!miniCanEdit())return;suppressMiniVolumeInput=false;miniVolumeSession={items:clone(items),undo:undo.slice(),redo:redo.slice()};});
$('#miniVolumeSlider').addEventListener('keydown',e=>{if(e.key!=='Escape')suppressMiniVolumeInput=false;});
window.addEventListener('pointerup',()=>{const session=miniVolumeSession;if(session)setTimeout(()=>{if(miniVolumeSession===session)finishMiniVolume(false);},0);},true);
window.addEventListener('pointercancel',()=>{if(miniVolumeSession)finishMiniVolume(true);},true);
window.addEventListener('blur',()=>{if(miniVolumeSession)finishMiniVolume(true);});
function closeMiniOptions(){miniAudioOptions.hidden=true;$('#miniAudioMore').setAttribute('aria-expanded','false');}
function handleMiniEscape(){if(miniVolumeSession){finishMiniVolume(true);return true;}if(!miniAudioOptions.hidden){closeMiniOptions();return true;}return false;}
document.addEventListener('pointerdown',e=>{if(!miniAudioOptions.hidden&&!e.target.closest('#miniAudioOptions,#miniAudioControls'))closeMiniOptions();},true);
