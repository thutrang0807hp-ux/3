"""Check point-of-cut controls and actual two-source vertical/horizontal transitions."""
from pathlib import Path
import io,json
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1536,'height':1040},accept_downloads=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()));page.goto('http://demo.test/');state=lambda:page.evaluate('SceneForgeEditor.getState()')
 a=state()['items'][0];page.locator('[data-join="'+a['id']+'"]').click();expect(page.locator('#transitionDetails')).to_be_visible();assert page.locator('.joinClipPair img').count()==2
 page.locator('#prop-transition').select_option('slide');page.locator('[data-transition-option=transitionDirection]').select_option('up');page.locator('[data-transition-option=transitionEasing]').select_option('easeInOut')
 page.locator('#joinDurationSlider').evaluate('(n)=>{n.value=1.2;n.dispatchEvent(new Event("input",{bubbles:true}));n.dispatchEvent(new Event("change",{bubbles:true}))}')
 assert abs(state()['items'][0]['transitionDuration']-1.2)<.01
 page.locator('[data-transition-preview]').click();page.wait_for_function('SceneForgeEditor.isPlaying()');page.wait_for_function('!SceneForgeEditor.isPlaying()',timeout=5000)
 page.locator('[data-transition-remove]').click();assert state()['items'][0]['transition']=='none';page.locator('#undo').click();assert state()['items'][0]['transition']=='slide'
 page.screenshot(path='/tmp/sceneforge-transition-inspector.png',full_page=True)
 model=state();first=model['items'][0]
 model.update(format='sceneforge-timeline',version=1,tracks=[model['tracks'][0]],assets=[{'id':name,'name':name+'.png','kind':'image','duration':5}for name in ['red','blue']],items=[dict(first,id=name,assetId=name,kind='image',name=name,start=n*2,duration=2,mediaIn=0,transition='slide'if n==0 else'none',transitionDuration=1,transitionDirection='up',transitionEasing='linear')for n,name in enumerate(['red','blue'])])
 page.locator('#projectFile').set_input_files({'name':'join.json','mimeType':'application/json','buffer':json.dumps(model).encode()});page.wait_for_function('SceneForgeEditor.getState().items.length===2')
 for name,color in [('red',(255,0,0)),('blue',(0,0,255))]:
  raw=io.BytesIO();Image.new('RGB',(90,160),color).save(raw,format='PNG');page.locator('#file').set_input_files({'name':name+'.png','mimeType':'image/png','buffer':raw.getvalue()});page.wait_for_function('(id)=>!SceneForgeEditor.getState().assets.find(a=>a.id===id).missing',arg=name)
 page.locator('[data-join=red] .joinLabel').click()
 def png():
  page.evaluate('SceneForgeEditor.seek(2)')
  with page.expect_download()as dl:page.evaluate("document.querySelector('#captureFrame').click()")
  return Image.open(dl.value.path()).convert('RGB')
 image=png();top=image.getpixel((image.width//2,image.height//4));bottom=image.getpixel((image.width//2,3*image.height//4));assert top[0]>240 and bottom[2]>240,(top,bottom)
 page.locator('#prop-transition').select_option('wipe');page.locator('[data-transition-option=transitionDirection]').select_option('right')
 image=png();left=image.getpixel((image.width//4,image.height//2));right=image.getpixel((3*image.width//4,image.height//2));assert left[2]>240 and right[0]>240,(left,right)
 # Easing changes the actual revealed fraction, not just a saved label.
 page.locator('[data-transition-option=transitionEasing]').select_option('easeIn');image=png();pixel=image.getpixel((int(image.width*.4),image.height//2));assert pixel[0]>240,pixel
 # Duration clamps to both neighbours, including typed input.
 page.locator('#prop-transitionDuration').fill('5');page.locator('#prop-transitionDuration').press('Tab');assert state()['items'][0]['transitionDuration']<=2
 assert not errors,errors
 print('PASS: dedicated join inspector with clip pair, slider/type/direction/easing/preview/remove/undo; decoded PNG proves upward push, rightward wipe and easing fraction; duration bounded by both clips.')
 b.close()
