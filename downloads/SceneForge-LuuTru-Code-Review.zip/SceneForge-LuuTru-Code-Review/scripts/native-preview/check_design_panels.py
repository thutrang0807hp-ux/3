"""Exercise the redesigned interior controls and real local shared library/meter."""
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.sync_api import sync_playwright,expect
import threading,io,wave,math,struct
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1366,'height':768},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{server.server_port}/native/')
  state=lambda:page.evaluate('SceneForgeEditor.getState()')
  assert page.locator('.designPrimaryTabs button').all_text_contents()==['Video','Âm thanh','Tốc độ']
  assert page.locator('.designSecondaryTabs button').all_text_contents()==['Cơ bản','Màu']
  # Original numeric properties, new slider layout and exact reset use the same model.
  page.locator('#prop-scale').fill('50');page.locator('#prop-scale').press('Tab');assert state()['items'][0]['scale']==.5
  page.locator('[data-design-align=left]').click();assert abs(state()['items'][0]['x']+25)<.2
  page.locator('[data-design-reset=transform]').click();assert state()['items'][0]['scale']==1 and state()['items'][0]['x']==0
  page.locator('[data-inspector-tab=color]').click();page.locator('#prop-temperature').fill('35');page.locator('#prop-temperature').press('Tab');assert state()['items'][0]['temperature']==35
  page.locator('#applyColorAll').click();assert all(i['temperature']==35 for i in state()['items'] if i['kind']=='video')
  page.locator('[data-design-reset=color]').click();assert state()['items'][0]['temperature']==0
  page.locator('[data-inspector-tab=speed]').click();page.locator('[data-design-speed="0.8"]').click();assert state()['items'][0]['speed']==.8
  page.locator('#undo').click();assert state()['items'][0]['speed']==1
  # Timeline playhead and actual row boundary agree after widening the track header.
  page.evaluate('SceneForgeEditor.seek(1)');head=page.locator('#playhead').bounding_box();lane=page.locator('[data-lane=v1]').bounding_box();assert abs(head['x']-lane['x']-62)<1.5,(head,lane)
  # Shared library saves the actual WAV, survives a reload and can add it to a new timeline.
  raw=io.BytesIO()
  with wave.open(raw,'wb') as w:
   w.setparams((1,2,48000,0,'NONE','not compressed'));w.writeframes(b''.join(struct.pack('<h',int(5000*math.sin(n*math.tau*330/48000))) for n in range(48000)))
  page.locator('#file').set_input_files({'name':'nhac-dung-chung.wav','mimeType':'audio/wav','buffer':raw.getvalue()});page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name==="nhac-dung-chung.wav")')
  asset=next(a for a in state()['assets'] if a['name']=='nhac-dung-chung.wav')
  page.locator('[data-asset="'+asset['id']+'"]').click(button='right');page.locator('[data-design-asset-action=pin]').click();expect(page.locator('#toast')).to_contain_text('Đã ghim')
  page.locator('[data-design-scope=shared]').click();assert page.locator('#assets .asset').count()==1
  page.wait_for_function('document.querySelector("#editorSaveStatus").dataset.state==="saved"');page.reload();page.locator('[data-design-scope=shared]').click();page.wait_for_function('document.querySelectorAll("#assets .asset").length===1')
  pin=page.locator('#assets .asset');pin.click(button='right');page.locator('[data-design-asset-action=add]').click();page.wait_for_function('SceneForgeEditor.getState().items.some(i=>String(i.assetId).startsWith("pinned_"))')
  # Actual PCM meter must light on playback, and go silent after pausing.
  page.evaluate('SceneForgeEditor.seek(0)');page.locator('#play').click();page.wait_for_function('parseFloat(document.querySelector("#designMasterMeter").style.getPropertyValue("--meter-level"))>10')
  page.locator('#play').click();page.wait_for_function('document.querySelector("#designMasterMeter output").textContent==="−∞"')
  # The new export-name field controls the actual downloaded file, not just its label.
  page.locator('#export').click();page.locator('#editorExportName').fill('Ban dung thu.mp4');page.locator('#exportSize').select_option('720');
  with page.expect_download(timeout=20000) as download:page.locator('#realExport').click()
  assert download.value.suggested_filename in ['Ban dung thu.mp4','Ban dung thu.webm'],download.value.suggested_filename
  assert Path(download.value.path()).stat().st_size>1000
  page.locator('#closeExport').click();page.screenshot(path='/tmp/sceneforge-design-panels-tested.png')
  assert not errors,errors
  print('PASS: two-tier inspector; transform/alignment/reset, warm/cool and apply-all, .8x speed/undo, widened ruler alignment, persisted real WAV shared library/add, real PCM meter/silence, actual custom export filename.')
  b.close()
finally:server.shutdown()
