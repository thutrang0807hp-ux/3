"""Real pointer drag: continuous ghost, stable capture, transactional row cleanup."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import json,math,time,io
from PIL import Image
root=Path(__file__).resolve().parents[2]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1366,'height':900});page.set_default_timeout(8000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()));page.goto('http://demo.test/');state=lambda:page.evaluate('SceneForgeEditor.getState()')
 assert all(not page.locator(sel).is_visible() for sel in ['#miniAudioControls','#miniAudioOptions','#timelineEditMode','#newTrack'])
 source=state();template=source['items'][0]
 def fixture(extra=False):
  model=dict(source,format='sceneforge-timeline',version=1)
  model['tracks']=[{'id':'upper','kind':'video','name':'Trên'},{'id':'lower','kind':'video','name':'Dưới'},{'id':'empty','kind':'text','name':'Trống'}]
  model['items']=[dict(template,id='a',trackId='upper',assetId='sample0',start=0,duration=4,mediaIn=0),dict(template,id='b',trackId='lower',assetId='sample1',start=0,duration=4,mediaIn=0),dict(template,id='c',trackId='lower',assetId='sample2',start=4,duration=4,mediaIn=0)]
  if extra:
   model['tracks'] += [{'id':'audio','kind':'audio','name':'Nhạc'}]
   model['items'] += [dict(template,id='subtitle',kind='text',trackId='empty',assetId=None,start=0,duration=8,text='Phụ đề đang dùng'),dict(template,id='music',kind='audio',trackId='audio',assetId='music',start=0,duration=8)]
  page.locator('#projectFile').set_input_files({'name':'drag.json','mimeType':'application/json','buffer':json.dumps(model).encode()});page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.id==="a")')
  page.locator('#timelineScroll').evaluate('(n)=>{n.scrollTop=0;n.scrollLeft=0}')
  page.wait_for_timeout(40)
  return state()
 def start(id):
  r=page.locator('[data-item="'+id+'"]').bounding_box();x=r['x']+30;y=r['y']+25;page.mouse.move(x,y);page.mouse.down();return r,x,y
 def no_overlap():
  s=state()
  for t in s['tracks']:
   clips=sorted([i for i in s['items'] if i['trackId']==t['id']],key=lambda i:i['start'])
   assert all(a['start']+a['duration']<=c['start']+.001 for a,c in zip(clips,clips[1:])),clips
 # Move back and forth across row boundaries; the original element is never reparented.
 initial=fixture();page.evaluate('window.captureLosses=0;document.querySelector("#timelineScroll").addEventListener("lostpointercapture",()=>captureLosses++)')
 r,x,y=start('a');lane=page.locator('[data-lane=lower]').bounding_box();xx=lane['x']+270;yy=lane['y']+25
 follow=[]
 for n in range(36):
  px=xx+50*math.sin(n/5);py=yy if n%12<8 else y
  page.mouse.move(px,py);page.wait_for_timeout(19)
  ghost=page.locator('[data-drag-ghost=a]').bounding_box();follow.append(max(abs(ghost['x']-(px-30)),abs(ghost['y']-(py-25))))
  assert page.locator('[data-item=a]').evaluate('(n)=>n.parentElement.dataset.lane')=='upper'
  assert state()['items']==initial['items']
 assert max(follow)<1.2,follow
 assert page.evaluate('captureLosses')==0
 page.mouse.move(xx,yy);page.wait_for_timeout(25);page.mouse.up();page.wait_for_timeout(40)
 s=state();assert len(s['tracks'])==1 and s['tracks'][0]['id']=='lower',s['tracks']
 assert {i['id'] for i in s['items']}=={'a','b','c'};no_overlap();assert not page.locator('#clipDragOverlay').count()
 page.locator('#undo').click();assert state()['items']==initial['items'] and state()['tracks']==initial['tracks']
 page.locator('#redo').click();assert len(state()['tracks'])==1;page.locator('#undo').click()
 # Escape cancels visual previews and retains the exact row layout and redo history.
 before=state();r,x,y=start('a');page.mouse.move(xx,yy,steps=10);page.wait_for_timeout(40);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(40)
 assert state()['items']==before['items'] and state()['tracks']==before['tracks'];assert not page.locator('#clipDragOverlay').count()
 page.locator('#redo').click();assert len(state()['tracks'])==1
 # Lifting still creates a new row; returning it removes the now-vacant source row.
 initial=fixture();r,x,y=start('a');top=page.locator('#tracks>.trackRow').first.bounding_box();page.mouse.move(x,top['y']-1,steps=12);page.wait_for_timeout(30);expect(page.locator('#newTrackIndicator')).to_be_visible();page.mouse.up();page.wait_for_timeout(40)
 s=state();assert len(s['tracks'])==2 and all(any(i['trackId']==t['id'] for i in s['items']) for t in s['tracks'])
 r,x,y=start('a');lane=page.locator('[data-lane=lower]').bounding_box();page.mouse.move(lane['x']+270,lane['y']+25,steps=16);page.mouse.up();page.wait_for_timeout(40);assert len(state()['tracks'])==1;no_overlap()
 # Dropping below all rows makes a bottom row (not a jump back to the top).
 initial=fixture();r,x,y=start('a');viewport=page.locator('#timelineScroll').bounding_box();page.mouse.move(x,viewport['y']+viewport['height']-7,steps=15);page.wait_for_timeout(220);drop=page.locator('#newLayerDrop').bounding_box();page.mouse.move(drop['x']+80,min(drop['y']+drop['height']/2,viewport['y']+viewport['height']-7),steps=10);page.mouse.up();page.wait_for_timeout(40)
 s=state();assert len(s['tracks'])==2 and s['tracks'][0]['id']=='lower' and s['tracks'][-1]['id']==next(i['trackId'] for i in s['items'] if i['id']=='a'),s['tracks']
 # A same-row selected group can move into another compatible existing row.
 initial=fixture();page.locator('[data-item=b]').click();page.locator('[data-item=c]').click(modifiers=['Shift']);assert set(state()['selectedIds'])=={'b','c'}
 r,x,y=start('b');upper=page.locator('[data-lane=upper]').bounding_box();page.mouse.move(upper['x']+340,upper['y']+25,steps=18);page.mouse.up();page.wait_for_timeout(40)
 s=state();assert len(s['tracks'])==1 and {i['trackId'] for i in s['items']}=={'upper'};no_overlap()
 page.locator('#undo').click();assert state()['items']==initial['items'] and state()['tracks']==initial['tracks']
 # A populated subtitle/music row must be preserved, with its timing unchanged.
 initial=fixture(True);r,x,y=start('a');lane=page.locator('[data-lane=lower]').bounding_box();page.mouse.move(lane['x']+270,lane['y']+25,steps=14);page.mouse.up();page.wait_for_timeout(40)
 assert len(state()['tracks'])==3
 for id in ['subtitle','music']:assert next(i for i in state()['items'] if i['id']==id)==next(i for i in initial['items'] if i['id']==id)
 # Dragging a real library card also compacts empty rows in the same undo operation.
 initial=fixture();model=dict(initial,format='sceneforge-timeline',version=1);model['items']=[i for i in model['items'] if i['id']=='b'];page.locator('#projectFile').set_input_files({'name':'drop.json','mimeType':'application/json','buffer':json.dumps(model).encode()});page.wait_for_function('SceneForgeEditor.getState().items.length===1')
 initial=state();page.locator('[data-asset=sample0]').drag_to(page.locator('[data-lane=lower]'),target_position={'x':310,'y':25});page.wait_for_function('SceneForgeEditor.getState().items.length===2');assert len(state()['tracks'])==1;no_overlap()
 page.locator('#undo').click();assert state()['items']==initial['items'] and state()['tracks']==initial['tracks']
 # Deletion also removes vacant rows; an entirely empty project retains one usable row.
 initial=fixture();page.locator('[data-item=a]').click();page.locator('#delete').click();assert len(state()['tracks'])==1 and {i['id'] for i in state()['items']}=={'b','c'}
 page.locator('#undo').click();assert state()['items']==initial['items'] and state()['tracks']==initial['tracks']
 page.keyboard.press('Control+a');page.keyboard.press('Delete');assert not state()['items'] and len(state()['tracks'])==1
 page.locator('#undo').click();assert state()['items']==initial['items'] and state()['tracks']==initial['tracks']
 # Import completing while a drag is held cancels the stale preview before inserting.
 initial=fixture();r,x,y=start('a');page.mouse.move(x+120,y,steps=10);page.wait_for_timeout(30);raw=io.BytesIO();Image.new('RGB',(18,32),(20,100,120)).save(raw,format='PNG')
 page.locator('#file').set_input_files({'name':'during-drag.png','mimeType':'image/png','buffer':raw.getvalue()});page.wait_for_function('SceneForgeEditor.getState().items.length===4');page.mouse.up()
 assert {'a','b','c'}.issubset({i['id'] for i in state()['items']});assert not page.locator('#clipDragOverlay').count()
 page.locator('#undo').click();assert state()['items']==initial['items'] and state()['tracks']==initial['tracks']
 # A drop outside the viewport is cancelled, not silently inserted elsewhere.
 initial=fixture();r,x,y=start('a');page.mouse.move(x,100,steps=15);page.mouse.up();page.wait_for_timeout(40);assert state()['items']==initial['items'] and state()['tracks']==initial['tracks']
 page.screenshot(path='/tmp/sceneforge-smooth-clip-drag.png');assert not errors,errors
 print('PASS: hidden timeline controls; pointer-follow error <1.2px across 36 row changes; no capture loss/reparent/model mutations mid-drag; occupied rows only after move/library drop, single undo/redo; Esc and outside-drop restore; lift creates rows, return removes them; subtitle/music timing intact.')
 b.close()
