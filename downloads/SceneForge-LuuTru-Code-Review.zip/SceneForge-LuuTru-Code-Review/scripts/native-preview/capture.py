"""Capture real upstream Concat panels and a short desktop demonstration."""
from pathlib import Path
import ctypes as c,subprocess,os,time,json
from PIL import Image
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent/'assets';out.mkdir(parents=True,exist_ok=True)
x=c.CDLL('libX11.so.6');x.XOpenDisplay.argtypes=[c.c_char_p];x.XOpenDisplay.restype=c.c_void_p
x.XDefaultRootWindow.argtypes=[c.c_void_p];x.XDefaultRootWindow.restype=c.c_ulong
class XImage(c.Structure):
 _fields_=[('width',c.c_int),('height',c.c_int),('xoffset',c.c_int),('format',c.c_int),('data',c.c_void_p),('order',c.c_int),('unit',c.c_int),('bitorder',c.c_int),('pad',c.c_int),('depth',c.c_int),('stride',c.c_int),('bpp',c.c_int)]
x.XGetImage.argtypes=[c.c_void_p,c.c_ulong,c.c_int,c.c_int,c.c_uint,c.c_uint,c.c_ulong,c.c_int];x.XGetImage.restype=c.POINTER(XImage)
x.XDestroyImage.argtypes=[c.POINTER(XImage)];x.XCloseDisplay.argtypes=[c.c_void_p]
display=x.XOpenDisplay(b':87');assert display
window=int(subprocess.check_output(['/workspace/3/.native-deps/sysroot/usr/bin/xdotool','search','--name','^Concat$'],env={**os.environ,'DISPLAY':':87'}).splitlines()[-1])
def click(px,py):
 subprocess.run(['/workspace/3/.native-deps/sysroot/usr/bin/xdotool','mousemove','--window',str(window),str(px),str(py),'click','1'],env={**os.environ,'DISPLAY':':87','LD_LIBRARY_PATH':'/workspace/3/.native-deps/sysroot/usr/lib/x86_64-linux-gnu'},check=True)
def image():
 raw=x.XGetImage(display,x.XDefaultRootWindow(display),0,0,1440,1000,c.c_ulong(-1),2);assert raw
 try:
  im=raw.contents;assert im.bpp==32
  return Image.frombytes('RGB',(im.width,im.height),c.string_at(im.data,im.stride*im.height),'raw','BGRX',im.stride)
 finally:x.XDestroyImage(raw)
shots=[('media','Tư liệu',40,65),('text','Văn bản',82,65),('stickers','Nhãn dán',128,65),('transitions','Chuyển cảnh',192,65),('effects','Hiệu ứng',250,65),('filters','Bộ lọc',300,65),('templates','Mẫu dựng',357,65)]
# Sampling by XGetImage avoids restricted MIT-SHM in the cloud.
video=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','1440x1000','-framerate','8','-i','pipe:0','-an','-c:v','libx264','-threads','2','-preset','veryfast','-crf','25','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'native-walkthrough.mp4')],stdin=subprocess.PIPE)
def hold(seconds):
 for _ in range(round(seconds*8)):
  start=time.monotonic();video.stdin.write(image().tobytes());time.sleep(max(0,.125-(time.monotonic()-start)))
try:
 for key,label,px,py in shots:
  click(px,py);hold(1.4);image().save(out/(key+'.webp'),quality=90)
 click(40,65);click(235,955);hold(1.5);image().save(out/'video-inspector.webp',quality=90)
 click(230,894);hold(1.5);image().save(out/'text-inspector.webp',quality=90)
 click(290,825);hold(1.5);image().save(out/'audio-inspector.webp',quality=90)
 click(1250,16);hold(1.5);image().save(out/'export.webp',quality=90)
 subprocess.run(['/workspace/3/.native-deps/sysroot/usr/bin/xdotool','key','--window',str(window),'Escape'],env={**os.environ,'DISPLAY':':87'},check=True)
 click(40,65);hold(.5)
finally:
 video.stdin.close();assert video.wait()==0;x.XCloseDisplay(display)
(out/'capture-info.json').write_text(json.dumps({'upstream':'jub0t/concat','version':'0.2.7','commit':'14b5998d793d90858ac982926374044bba4bf39f','source':'Real Linux window built from upstream source; Xvfb, software renderer','shots':[s[0] for s in shots]+['video-inspector','text-inspector','audio-inspector','export']},indent=2))
print('Captured native panels and real desktop walkthrough:',out)
