"""Real browser export + sidecar; defaults do not override a user's manual choices."""
from pathlib import Path
from functools import partial
import http.server,threading,sys,tempfile,json,subprocess
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/demo-lite'))
from browser_controls import controls
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1000});errors=[];downloads=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('download',lambda d:downloads.append(d));page.goto(f'http://127.0.0.1:{server.server_port}/native/index.html');page.wait_for_function('!!window.SceneForgeEditor');q=controls(page)
  page.evaluate("window.postMessage({type:'sceneforge:preferences',settings:{resolution:720,fps:60,sidecarSrt:true}},location.origin)");page.wait_for_timeout(100);expect(page.locator('#exportSize')).to_have_value('720');expect(page.locator('#exportFrameRate')).to_have_value('60')
  state=lambda:page.evaluate('SceneForgeEditor.getState()');first=state()['items'][0]['id']
  for i in state()['items'][1:]:page.locator('[data-item="'+i['id']+'"]').click();page.locator('#delete').click()
  page.locator('[data-item="'+first+'"]').click();q('#prop-duration').fill('1.2');q('#prop-duration').press('Tab');page.locator('[data-library=captions]').click();page.locator('[data-shared-caption=add]').click();assert any(i.get('subtitle')for i in state()['items'])
  page.locator('#export').click();page.locator('#exportFrameRate').select_option('30');page.evaluate("window.postMessage({type:'sceneforge:preferences',settings:{resolution:1080,fps:60,sidecarSrt:true}},location.origin)");page.wait_for_timeout(100);expect(page.locator('#exportFrameRate')).to_have_value('30');expect(page.locator('#exportSize')).to_have_value('720');page.locator('#realExport').click();page.wait_for_function('document.querySelector("#exportProgress").value===100',timeout=30000);page.wait_for_timeout(250);assert len(downloads)==2,[d.suggested_filename for d in downloads]
  with tempfile.TemporaryDirectory()as td:
   for dl in downloads:dl.save_as(str(Path(td)/dl.suggested_filename))
   srt=next(Path(td).glob('*.srt')).read_text('utf-8-sig');assert '-->'in srt;video=next(d for d in downloads if not d.suggested_filename.endswith('.srt'));path=Path(td)/video.suggested_filename;meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(path)]));stream=next(s for s in meta['streams']if s['codec_type']=='video');assert stream['height']==1280,stream
  assert not errors,errors;b.close()
 print('PASS: live preferences set 720p/60 fps request, manual 30 fps survives later settings, actual short video + timestamped SRT downloaded and video probed at 720×1280. No live APIs.')
finally:server.shutdown()
