"""Build the static native UI preview from recorded upstream assets."""
from pathlib import Path
import shutil
import hashlib
source = Path(__file__).resolve().parent
target = source.parents[1] / "dist/web-demo/native"
target.mkdir(parents=True, exist_ok=True)
for name in ("index.html", "style.css", "app.js", "subtitles.css", "subtitles.js", "workspace.css", "workspace-tools.js", "reference.html", "reference.js", "reference-subtitles.js"):
    shutil.copy2(source / name, target / name)
for page in ("index.html", "reference.html"):
    html=(target / page).read_text().replace("<!-- SUBTITLES -->", (source / "subtitles.html").read_text())
    for name in ("style.css", "app.js", "subtitles.css", "subtitles.js", "workspace.css", "workspace-tools.js", "reference.js", "reference-subtitles.js"):
        digest=hashlib.sha256((source / name).read_bytes()).hexdigest()[:12]
        html=html.replace(f'./{name}"', f'./{name}?v={digest}"')
    (target / page).write_text(html)
shutil.copytree(source / "assets", target / "assets", dirs_exist_ok=True)
import runpy
runpy.run_path(str(source / 'build_full_editor.py'), run_name='__main__')
print(target)
