// Shared timeline gestures: marquee selection and editable joins.
let selectedJoin=null;
function joinAfter(a){return items.find(b=>b.id!==a.id&&b.trackId===a.trackId&&['video','image'].includes(b.kind)&&Math.abs(b.start-end(a))<.001);}
function joinLimit(a,b){return Math.max(.1,Math.min(5,a.duration,b.duration));}
function paintJoinBlocks(){
 if(selectedJoin!==selection||!items.some(i=>i.id===selectedJoin&&joinAfter(i)))selectedJoin=null;
 const existing=new Map($$('.timelineJoin').map(n=>[n.dataset.join,n])),retained=new Set(),lanes=new Map();
 for(const i of items)if(['video','image'].includes(i.kind)){if(!lanes.has(i.trackId))lanes.set(i.trackId,[]);lanes.get(i.trackId).push(i);}
 for(const row of lanes.values()){
  row.sort((a,b)=>a.start-b.start);
  const lane=$('[data-lane="'+row[0]?.trackId+'"]');if(!lane)continue;
  for(let index=0;index<row.length-1;index++){
   const a=row[index],b=row[index+1];if(Math.abs(b.start-end(a))>=.001)continue;
   const enabled=a.transition!=='none',duration=Math.min(a.transitionDuration,joinLimit(a,b)),width=enabled?Math.max(4,duration*px):22;
   let n=existing.get(a.id);if(!n){n=document.createElement('button');n.dataset.join=a.id;}
   retained.add(a.id);n.className='timelineJoin'+(enabled?' enabled joinRegion':'')+(selectedJoin===a.id?' chosen':'');
   n.style.left=(end(a)*px-width/2)+'px';n.style.width=width+'px';
   n.title=enabled?'Chuyển cảnh '+duration.toFixed(2)+' giây · kéo mép để chỉnh · Delete để bỏ':'Thêm chuyển cảnh tại điểm nối';n.setAttribute('aria-label',n.title);
   const shape=enabled?'region':'add';if(n.dataset.shape!==shape){n.innerHTML=enabled?'<i data-join-edge="left"></i><span class="joinLabel"></span><i data-join-edge="right"></i>':'+';n.dataset.shape=shape;}
   if(enabled)n.querySelector('.joinLabel').textContent='◇ '+duration.toFixed(2)+'s';
   if(n.parentElement!==lane)lane.append(n);
  }
 }
 for(const [id,n]of existing)if(!retained.has(id))n.remove();
}
const timelineBeforeJoins=timeline;
timeline=function(){timelineBeforeJoins();paintJoinBlocks();};
function selectJoin(id){selectedJoin=id;chooseBeforeLinks(id);switchInspectorTab('transition');paintJoinBlocks();}
function applyJoin(id,type){const a=items.find(i=>i.id===id),b=a&&joinAfter(a);if(!a||!b||getTrack(a.trackId).locked){notify('Chọn điểm nối giữa hai clip trên track đã mở khóa.');return false;}
 transact(()=>{a.transition=type;a.transitionDuration=Math.min(a.transitionDuration,joinLimit(a,b));});selectJoin(id);return true;}
// Clicking a palette card is validated against a real neighbour, not an orphan effect.
$('#creativeLibrary').addEventListener('click',e=>{const card=e.target.closest('[data-palette-transition]');if(!card)return;e.preventDefault();e.stopImmediatePropagation();const a=selectedJoin?items.find(i=>i.id===selectedJoin):selected();if(!a||!joinAfter(a)){notify('Chọn clip có cảnh nối phía sau, hoặc kéo mẫu vào dấu + trên timeline.');return;}applyJoin(a.id,card.dataset.paletteTransition);},true);
const libraryBeforeJoins=showLibrary;
showLibrary=function(kind){libraryBeforeJoins(kind);if(kind==='transitions'){
 const intro=$('#creativeLibrary .paletteIntro p');if(intro)intro.textContent='Kéo mẫu vào điểm nối giữa hai clip. Kéo mép khối chuyển cảnh để chỉnh thời lượng.';
 $$('[data-palette-transition]').forEach(n=>n.draggable=true);
}};
$('#creativeLibrary').addEventListener('dragstart',e=>{const card=e.target.closest('[data-palette-transition]');if(card){e.dataTransfer.setData('application/x-sceneforge-transition',card.dataset.paletteTransition);e.dataTransfer.effectAllowed='copy';e.stopPropagation();}});
function joinAtPointer(e){const block=e.target.closest('[data-join]');if(block)return block.dataset.join;const lane=e.target.closest('[data-lane]');if(!lane)return null;const at=(e.clientX-lane.getBoundingClientRect().left)/px;return items.find(i=>i.trackId===lane.dataset.lane&&joinAfter(i)&&Math.abs(end(i)-at)*px<24)?.id;}
for(const type of ['dragover','drop'])$('#tracks').addEventListener(type,e=>{if(![...e.dataTransfer.types].includes('application/x-sceneforge-transition'))return;e.preventDefault();e.stopImmediatePropagation();const id=joinAtPointer(e);$$('.timelineJoin').forEach(n=>n.classList.toggle('dropTarget',n.dataset.join===id));if(type==='drop'){if(id)applyJoin(id,e.dataTransfer.getData('application/x-sceneforge-transition'));else notify('Thả mẫu sát điểm nối giữa hai clip liền nhau.');$$('.dropTarget').forEach(n=>n.classList.remove('dropTarget'));}},true);
let cancelTimelineGesture=null;
function trackGestureCancel(e){if(!cancelTimelineGesture)return;if(e.type==='blur'||e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();cancelTimelineGesture();}}
window.addEventListener('keydown',trackGestureCancel,true);window.addEventListener('blur',trackGestureCancel);
window.addEventListener('keydown',e=>{if(!selectedJoin||!['Delete','Backspace'].includes(e.key)||['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)||$('dialog[open]'))return;e.preventDefault();e.stopImmediatePropagation();applyJoin(selectedJoin,'none');selectedJoin=null;paintJoinBlocks();},true);
$('#tracks').addEventListener('click',e=>{if(e.target.closest('[data-join]')){e.stopImmediatePropagation();e.preventDefault();}},true);
$('#tracks').addEventListener('pointerdown',e=>{
 if(e.button!==0)return;
 const block=e.target.closest('[data-join]');if(!block){if(e.target.closest('[data-item]'))selectedJoin=null;return;}
 e.preventDefault();e.stopImmediatePropagation();pause();
 const a=items.find(i=>i.id===block.dataset.join),b=a&&joinAfter(a);if(!a||!b||getTrack(a.trackId).locked){notify('Mở khóa track để chỉnh chuyển cảnh.');return;}
 if(a.transition==='none'){applyJoin(a.id,'dissolve');return;}
 selectJoin(a.id);
 const edge=e.target.dataset.joinEdge;if(!edge)return;
 const before=clone(items),priorRedo=redo.slice(),initial=a.transitionDuration,x=e.clientX,scroll=$('#timelineScroll'),initialScroll=scroll.scrollLeft;
 let changed=false,frame=0,pending=null;const captured=e.currentTarget;captured.setPointerCapture(e.pointerId);
 const paint=(v,scrollAtEdge=true)=>{
  const bounds=scroll.getBoundingClientRect();if(scrollAtEdge){if(v.clientX>bounds.right-24)scroll.scrollLeft+=12;else if(v.clientX<bounds.left+140)scroll.scrollLeft-=12;}
  const diff=(v.clientX-x+scroll.scrollLeft-initialScroll)/px*(edge==='left'?-2:2);let value=clamp(initial+diff,.1,joinLimit(a,b));
  // Whole frames are visible marks when snapping; Shift temporarily releases them.
  if(snap&&!v.shiftKey)value=clamp(Math.round(value*24)/24,.1,joinLimit(a,b));
  value=Math.round(value*1000)/1000;if(Math.abs(value-a.transitionDuration)<.00001)return;
  if(!changed){remember();changed=true;}a.transitionDuration=value;paintJoinBlocks();
  const number=$('#prop-transitionDuration'),slider=$('#joinDurationSlider');if(number)number.value=value.toFixed(3);if(slider)slider.value=value;
  updateStage(true);
 };
 const step=()=>{frame=0;if(!pending)return;paint(pending);const b=scroll.getBoundingClientRect();if(pending.clientX>b.right-24||pending.clientX<b.left+140)frame=requestAnimationFrame(step);};
 const move=v=>{pending={clientX:v.clientX,shiftKey:v.shiftKey};if(!frame)frame=requestAnimationFrame(step);};
 const finish=v=>{
  cancelAnimationFrame(frame);if(pending&&v.type!=='pointercancel')paint(pending,false);pending=null;
  captured.removeEventListener('pointermove',move);captured.removeEventListener('pointerup',finish);captured.removeEventListener('pointercancel',finish);cancelTimelineGesture=null;
  if(v.type==='pointercancel'&&changed){items=before;undo.pop();redo=priorRedo;}
  else if(changed&&Math.abs(a.transitionDuration-initial)<.00001){undo.pop();redo=priorRedo;}
  render();switchInspectorTab('transition');
 };
 cancelTimelineGesture=()=>finish({type:'pointercancel'});
 captured.addEventListener('pointermove',move);captured.addEventListener('pointerup',finish);captured.addEventListener('pointercancel',finish);
},true);
// Start selection only from empty lane space; ordinary clip drags retain their tools.
$('#tracks').addEventListener('pointerdown',e=>{
 if(e.button!==0||e.target.closest('[data-item],[data-join],button,.trackTitle')||!e.target.closest('[data-lane]'))return;
 const scroll=$('#timelineScroll'),original=new Set(selectedIds),originalPrimary=selection;
 const point=v=>{const b=scroll.getBoundingClientRect();return{x:v.clientX-b.left+scroll.scrollLeft,y:v.clientY-b.top+scroll.scrollTop};},start=point(e);
 let moved=false,frame=0,pointer={clientX:e.clientX,clientY:e.clientY};
 const rect=document.createElement('div');rect.className='timelineMarquee';document.body.append(rect);
 const target=e.currentTarget;target.setPointerCapture(e.pointerId);pause();
 const draw=()=>{frame=0;const bounds=scroll.getBoundingClientRect();if(moved){if(pointer.clientX>bounds.right-24)scroll.scrollLeft+=12;else if(pointer.clientX<bounds.left+140)scroll.scrollLeft-=12;if(pointer.clientY>bounds.bottom-18)scroll.scrollTop+=10;else if(pointer.clientY<bounds.top+18)scroll.scrollTop-=10;}
  const p=point(pointer),box={left:Math.min(start.x,p.x),right:Math.max(start.x,p.x),top:Math.min(start.y,p.y),bottom:Math.max(start.y,p.y)};
  if(!moved&&Math.abs(p.x-start.x)+Math.abs(p.y-start.y)<4)return;moved=true;suppressClick=true;
  Object.assign(rect.style,{display:'block',left:(bounds.left+box.left-scroll.scrollLeft)+'px',top:(bounds.top+box.top-scroll.scrollTop)+'px',width:(box.right-box.left)+'px',height:(box.bottom-box.top)+'px',clipPath:`inset(${Math.max(0,scroll.scrollTop-box.top)}px ${Math.max(0,box.right-scroll.scrollLeft-bounds.width)}px ${Math.max(0,box.bottom-scroll.scrollTop-bounds.height)}px ${Math.max(0,scroll.scrollLeft-box.left)}px)`});
  const hit=new Set();for(const n of $$('.timelineItem')){const item=items.find(i=>i.id===n.dataset.item);if(!item||getTrack(item.trackId).locked)continue;const r=n.getBoundingClientRect(),left=r.left-bounds.left+scroll.scrollLeft,top=r.top-bounds.top+scroll.scrollTop;if(left<box.right&&left+r.width>box.left&&top<box.bottom&&top+r.height>box.top)hit.add(item.id);}
  selectedIds=e.shiftKey?new Set([...original].filter(id=>!hit.has(id)).concat([...hit].filter(id=>!original.has(id)))):hit;
  selection=[...selectedIds][0]||null;$$('.timelineItem').forEach(n=>n.classList.toggle('selected',selectedIds.has(n.dataset.item)));updateSelectionSummary();
  if(pointer.clientX>bounds.right-24||pointer.clientX<bounds.left+140||pointer.clientY>bounds.bottom-18||pointer.clientY<bounds.top+18)frame=requestAnimationFrame(draw);
 };
 const move=v=>{pointer={clientX:v.clientX,clientY:v.clientY};if(!frame)frame=requestAnimationFrame(draw);};
 const finish=v=>{cancelAnimationFrame(frame);if(v.type!=='pointercancel')draw();cancelAnimationFrame(frame);rect.remove();cancelTimelineGesture=null;target.removeEventListener('pointermove',move);target.removeEventListener('pointerup',finish);target.removeEventListener('pointercancel',finish);if(v.type==='pointercancel'){selectedIds=original;selection=originalPrimary;$$('.timelineItem').forEach(n=>n.classList.toggle('selected',selectedIds.has(n.dataset.item)));}if(moved){selectedJoin=null;inspector();updateSelectionSummary();setTimeout(()=>suppressClick=false,30);}};
 cancelTimelineGesture=()=>finish({type:'pointercancel'});target.addEventListener('pointermove',move);target.addEventListener('pointerup',finish);target.addEventListener('pointercancel',finish);
},true);
// Rolling trim changes the shared cut while keeping the whole sequence length.
let rollingTrim=false;
const rollingButton=document.createElement('button');rollingButton.id='rollingTrim';rollingButton.textContent='↔';rollingButton.title='Cắt điểm nối: kéo mép để dài clip trước, ngắn clip sau; giữ tổng thời lượng';rollingButton.setAttribute('aria-label',rollingButton.title);rollingButton.setAttribute('aria-pressed','false');$('#split').after(rollingButton);
rollingButton.onclick=()=>{rollingTrim=!rollingTrim;rollingButton.setAttribute('aria-pressed',String(rollingTrim));rollingButton.classList.toggle('active',rollingTrim);notify(rollingTrim?'Cắt điểm nối: kéo mép hai clip liền nhau; giữ tổng thời lượng.':'Đã về chế độ cắt mép thông thường.');};
$('#tracks').addEventListener('pointerdown',e=>{
 if(!rollingTrim||e.button!==0||!e.target.dataset.edge)return;
 e.preventDefault();e.stopImmediatePropagation();
 const item=items.find(i=>i.id===e.target.closest('[data-item]')?.dataset.item);if(!item||!['video','image'].includes(item.kind))return;
 if(item.linkGroup&&linkedPicking){notify('Tắt cắt điểm nối để cắt đồng bộ hình–tiếng, hoặc bỏ liên kết trước.');return;}
 const a=e.target.dataset.edge==='right'?item:items.find(i=>i.trackId===item.trackId&&Math.abs(end(i)-item.start)<.001),b=a&&joinAfter(a);
 if(!a||!b||getTrack(a.trackId).locked){notify('Cần hai clip liền nhau trên track đã mở khóa.');return;}
 if(linkedPicking&&(a.linkGroup||b.linkGroup)){notify('Bỏ liên kết hình–tiếng trước khi cắt điểm nối, hoặc dùng cắt mép đồng bộ.');return;}
 pause();choose(item.id);const baseline=clone(items),oldA=clone(a),oldB=clone(b),priorRedo=redo.slice(),x=e.clientX,scroll=$('#timelineScroll'),initialScroll=scroll.scrollLeft;
 const lower=Math.max(.2-a.duration,b.kind==='image'?-Infinity:-b.mediaIn/b.speed),upper=Math.min(b.duration-.2,a.kind==='image'?Infinity:(getAsset(a.assetId).duration-a.mediaIn)/a.speed-a.duration);
 let changed=false;const target=e.currentTarget;target.setPointerCapture(e.pointerId);
 const move=v=>{let delta=(v.clientX-x+scroll.scrollLeft-initialScroll)/px;if(snap)delta=snapped(end(oldA)+delta,a.id)-end(oldA);delta=clamp(delta,lower,upper);if(Math.abs(delta)<.0001&&!changed)return;if(!changed){remember();changed=true;}a.duration=oldA.duration+delta;b.start=oldB.start+delta;b.duration=oldB.duration-delta;if(b.kind!=='image')b.mediaIn=oldB.mediaIn+delta*b.speed;retimeTrimmedKeyframes(a,oldA,0);retimeTrimmedKeyframes(b,oldB,delta);for(const i of [a,b]){i.fadeIn=Math.min(i.fadeIn,i.duration);i.fadeOut=Math.min(i.fadeOut,i.duration);i.transitionDuration=Math.min(i.transitionDuration,i.duration);}for(const i of [a,b]){const n=$('[data-item="'+i.id+'"]');n.style.left=i.start*px+'px';n.style.width=i.duration*px+'px';}paintJoinBlocks();showDropGuide(end(a),'Cắt điểm nối · giữ tổng thời lượng');updateStage(true);};
 const finish=v=>{target.removeEventListener('pointermove',move);target.removeEventListener('pointerup',finish);target.removeEventListener('pointercancel',finish);cancelTimelineGesture=null;hideDropGuide();if(v.type==='pointercancel'&&changed){items=baseline;undo.pop();redo=priorRedo;}suppressClick=true;render();setTimeout(()=>suppressClick=false,30);};
 cancelTimelineGesture=()=>finish({type:'pointercancel'});target.addEventListener('pointermove',move);target.addEventListener('pointerup',finish);target.addEventListener('pointercancel',finish);
},true);
const shortcut=$('.shortcutHint');if(shortcut)shortcut.textContent='Kéo vùng trống: chọn nhiều · Shift: thêm/bớt · Esc: hủy kéo · +: chuyển cảnh';
// Linked picture/audio: select, move, trim and split together; explicit unlink.
let linkedPicking=true;
const linkedButton=document.createElement('button');linkedButton.id='linkedPicking';linkedButton.textContent='⛓';linkedButton.title='Chọn cùng hình–tiếng đã liên kết (bật/tắt)';linkedButton.setAttribute('aria-label',linkedButton.title);linkedButton.setAttribute('aria-pressed','true');linkedButton.classList.add('active');rollingButton.after(linkedButton);
const unlinkButton=document.createElement('button');unlinkButton.id='unlinkClips';unlinkButton.textContent='⛓−';unlinkButton.title='Bỏ liên kết hình–tiếng đang chọn';unlinkButton.setAttribute('aria-label',unlinkButton.title);linkedButton.after(unlinkButton);
linkedButton.onclick=()=>{linkedPicking=!linkedPicking;linkedButton.setAttribute('aria-pressed',String(linkedPicking));linkedButton.classList.toggle('active',linkedPicking);notify(linkedPicking?'Chọn cùng hình–tiếng: bật.':'Có thể chọn và sửa từng phần hình hoặc tiếng riêng.');};
unlinkButton.onclick=()=>{const groups=new Set(items.filter(i=>selectedIds.has(i.id)&&i.linkGroup).map(i=>i.linkGroup));if(!groups.size){notify('Chọn clip đã liên kết trước.');return;}if(items.some(i=>groups.has(i.linkGroup)&&getTrack(i.trackId).locked)){notify('Mở khóa các track liên kết trước.');return;}transact(()=>{items.filter(i=>groups.has(i.linkGroup)).forEach(i=>i.linkGroup='');});notify('Đã bỏ liên kết; có thể hoàn tác.');};
const chooseBeforeLinks=choose;
choose=function(id,seek=false,add=false,preserve=false){chooseBeforeLinks(id,seek,add,preserve);if(!linkedPicking||!id)return;const groups=new Set(items.filter(i=>selectedIds.has(i.id)&&i.linkGroup).map(i=>i.linkGroup));if(!groups.size)return;items.filter(i=>groups.has(i.linkGroup)).forEach(i=>selectedIds.add(i.id));$$('.timelineItem').forEach(n=>n.classList.toggle('selected',selectedIds.has(n.dataset.item)));inspector();updateSelectionSummary();};
const trimBeforeLinks=planTrim;
planTrim=function(baseline,baseTracks,id,edge,delta){
 const source=baseline.find(i=>i.id===id),group=linkedPicking&&source?.linkGroup?baseline.filter(i=>i.linkGroup===source.linkGroup):[];
 if(group.length<2)return trimBeforeLinks(baseline,baseTracks,id,edge,delta);
 if(group.some(i=>baseTracks.find(t=>t.id===i.trackId).locked))return{valid:false,reason:'Mở khóa các track hình–tiếng liên kết trước.'};
 const draft=group.map(i=>trimBeforeLinks(baseline,baseTracks,i.id,edge,delta));if(draft.some(p=>!p.valid))return draft.find(p=>!p.valid);
 const amounts=draft.map((p,n)=>{const i=p.items.find(i=>i.id===group[n].id);return edge==='left'?i.start-group[n].start:i.duration-group[n].duration;}),shared=delta>=0?Math.min(delta,...amounts):Math.max(delta,...amounts);
 const plans=group.map(i=>trimBeforeLinks(baseline,baseTracks,i.id,edge,shared));if(plans.some(p=>!p.valid))return plans.find(p=>!p.valid);
 const result=clone(baseline);for(let n=0;n<group.length;n++)for(const i of plans[n].items.filter(i=>i.trackId===group[n].trackId)){const index=result.findIndex(x=>x.id===i.id);if(index>=0)result[index]=i;}
 return{valid:true,items:result,tracks:clone(baseTracks),guide:edge==='left'?source.start+shared:end(source)+shared,description:'Cắt hình–tiếng liên kết · giữ đồng bộ'};
};
function separateNewLinkGroups(before){const newGroups=new Map();let changed=false;for(const i of items){if(before.has(i.id)||!i.linkGroup)continue;if(!newGroups.has(i.linkGroup))newGroups.set(i.linkGroup,uid());i.linkGroup=newGroups.get(i.linkGroup);changed=true;}if(changed)render();}
const batchBeforeLinks=batchCommand;
batchCommand=function(action){const before=new Set(items.map(i=>i.id));batchBeforeLinks(action);if(['split','duplicate'].includes(action))separateNewLinkGroups(before);};
// Assemble existing clips in a reviewable order, without calling any generation API.
const assembleButton=document.createElement('button');assembleButton.id='autoAssemble';assembleButton.textContent='▥';assembleButton.title='Xếp clip nối tiếp: chọn thứ tự và chuyển cảnh';assembleButton.setAttribute('aria-label',assembleButton.title);unlinkButton.after(assembleButton);
const assembleDialog=document.createElement('dialog');assembleDialog.id='assembleDialog';document.body.append(assembleDialog);let assemblyOrder=[];
function drawAssemblyDialog(){assembleDialog.innerHTML='<h3>Xếp clip thành bản dựng</h3><p>Sắp thứ tự cảnh trước khi ghép. Clip được chuyển vào một track; giữ nguyên chỉnh màu và hiệu ứng.</p><ol class="assemblyList">'+assemblyOrder.map((id,n)=>{const i=items.find(i=>i.id===id);return'<li><b>'+String(n+1).padStart(2,'0')+'</b><span>'+esc(i.name)+'<small>'+i.duration.toFixed(2)+' giây</small></span><button data-assembly-up="'+n+'" '+(!n?'disabled':'')+' aria-label="Đưa cảnh lên">↑</button><button data-assembly-down="'+n+'" '+(n===assemblyOrder.length-1?'disabled':'')+' aria-label="Đưa cảnh xuống">↓</button></li>';}).join('')+'</ol><label>Chuyển cảnh <select id="assemblyTransition"><option value="none">Cắt thẳng</option><option value="dissolve" selected>Hòa hai hình</option><option value="fade">Mờ qua đen</option><option value="slide">Trượt ngang</option><option value="wipe">Quét khung</option></select></label><label>Thời lượng <input id="assemblyDuration" type="number" min="0.1" max="5" step="0.1" value="0.5"> giây</label><p class="hint">Nhạc và phụ đề hiện có giữ nguyên thời gian. Hình–tiếng đã liên kết được di chuyển cùng nhau. Có thể hoàn tác cả lần ghép.</p><div class="assemblyActions"><button data-assembly-cancel>Hủy</button><button data-assembly-apply>Xếp '+assemblyOrder.length+' clip</button></div>';}
assembleButton.onclick=()=>{let candidates=items.filter(i=>selectedIds.has(i.id)&&['video','image'].includes(i.kind));if(candidates.length<2)candidates=items.filter(i=>['video','image'].includes(i.kind));if(candidates.length<2){notify('Cần ít nhất hai clip video hoặc ảnh trên timeline.');return;}assemblyOrder=candidates.sort((a,b)=>a.start-b.start||tracks.findIndex(t=>t.id===a.trackId)-tracks.findIndex(t=>t.id===b.trackId)).map(i=>i.id);drawAssemblyDialog();assembleDialog.showModal();};
assembleDialog.onclick=e=>{
 const up=e.target.closest('[data-assembly-up]'),down=e.target.closest('[data-assembly-down]');if(up||down){const n=Number(up?up.dataset.assemblyUp:down.dataset.assemblyDown),m=n+(up?-1:1),type=$('#assemblyTransition').value,duration=$('#assemblyDuration').value;if(m<0||m>=assemblyOrder.length)return;[assemblyOrder[n],assemblyOrder[m]]=[assemblyOrder[m],assemblyOrder[n]];drawAssemblyDialog();$('#assemblyTransition').value=type;$('#assemblyDuration').value=duration;return;}
 if(e.target.closest('[data-assembly-cancel]'))assembleDialog.close();
 if(!e.target.closest('[data-assembly-apply]'))return;
 const type=$('#assemblyTransition').value,duration=Number($('#assemblyDuration').value),members=assemblyOrder.map(id=>items.find(i=>i.id===id));if(!Number.isFinite(duration)||duration<.1||duration>5){notify('Thời lượng chuyển cảnh từ 0,1 đến 5 giây.');return;}
 const groups=new Set(members.map(i=>i.linkGroup).filter(Boolean)),linked=items.filter(i=>groups.has(i.linkGroup)&&!members.includes(i));
 if([...members,...linked].some(i=>getTrack(i.trackId).locked)){notify('Mở khóa các track được ghép trước.');return;}
 // Reject ambiguous links rather than shifting a companion more than once.
 if([...groups].some(g=>members.filter(i=>i.linkGroup===g).length>1)){notify('Mỗi nhóm liên kết chỉ nên có một clip hình. Bỏ liên kết để xếp riêng.');return;}
 pause();transact(()=>{
  const track=makeMediaTrack('video');track.name='Bản ghép';addTrackInFront(track,tracks);let at=0;
  // Audio companions each get an independent lane to avoid overwriting unrelated sound.
  for(let n=0;n<members.length;n++){const i=members[n],offset=at-i.start;i.start=at;i.trackId=track.id;i.transition=n===members.length-1?'none':type;i.transitionDuration=n===members.length-1?duration:Math.min(duration,i.duration,members[n+1].duration);for(const other of linked.filter(x=>x.linkGroup===i.linkGroup)){const t=makeMediaTrack(other.kind);tracks.push(t);other.trackId=t.id;other.start+=offset;}at+=i.duration;}
  selectedIds=new Set([...members,...linked].map(i=>i.id));selection=members[0].id;
 });assembleDialog.close();$('#fitTimeline').click();notify('Đã xếp '+members.length+' clip nối tiếp, có thể hoàn tác.');
};

// Keep speed editing in step with the same explicit linked-selection toggle.
speedEditMembers=function(item,list){return linkedPicking&&item.linkGroup?list.filter(i=>i.linkGroup===item.linkGroup):[item];};
