"""Regression for the archived single-video authoring prototype."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading,tempfile
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist')))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1440,'height':1000});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}/web-demo/native/single-video.html',wait_until='networkidle')
  page.locator('#captionToolsToggle').click()
  expect(page.locator('#subtitles')).to_be_visible()
  assert page.locator('#viewer #subtitles').count()==1
  assert page.locator('[role=tab][data-mode=subtitles]').count()==0
  assert page.locator('#screenImage').count()==0
  page.evaluate('window.originalEditorVideo=document.querySelector("#captionVideo")')
  page.wait_for_function('document.querySelector("#captionVideo").duration===12')
  expect(page.locator('#captionLive')).to_have_text('Một hành trình mới bắt đầu.')
  for preset in ['bold','box','minimal','clean']:
   page.locator(f'[data-caption-preset="{preset}"]').click()
   expect(page.locator('#captionOverlay')).to_have_class('caption-overlay preset-'+preset)
  page.locator('#captionSubtitleTrack button[data-cue="1"]').click()
  page.wait_for_function('document.querySelector("#captionVideo").currentTime===4')
  page.locator('#captionTimelineZoom').evaluate('(input)=>{input.value=2;input.dispatchEvent(new Event("input"));}')
  assert page.locator('#captionTimelineScroll').evaluate('(e)=>e.scrollWidth>e.clientWidth')
  page.locator('#captionTimelineZoom').evaluate('(input)=>{input.value=1;input.dispatchEvent(new Event("input"));}')
  page.get_by_role('button',name='Xem câu 2',exact=True).click()
  expect(page.locator('#captionLive')).to_have_text('Đi chậm lại, ngắm nhìn nhiều hơn.')
  text=page.get_by_role('textbox',name='Nội dung câu 2',exact=True)
  text.fill('Phụ đề tiếng Việt: đẹp quá!');text.press('Tab')
  expect(page.locator('#captionLive')).to_have_text('Phụ đề tiếng Việt: đẹp quá!')
  page.get_by_role('button',name='Hoàn tác phụ đề',exact=True).click()
  expect(text).to_have_value('Đi chậm lại, ngắm nhìn nhiều hơn.')
  page.get_by_role('button',name='Làm lại phụ đề',exact=True).click()
  expect(text).to_have_value('Phụ đề tiếng Việt: đẹp quá!')
  end=page.get_by_role('spinbutton',name='Kết thúc câu 2',exact=True)
  end.fill('3');end.press('Tab')
  expect(page.locator('#captionExportSrt')).to_be_disabled()
  expect(page.locator('#captionFeedback')).to_contain_text('kết thúc phải lớn hơn')
  end.fill('7.5');end.press('Tab')
  expect(page.locator('#captionExportSrt')).to_be_enabled()
  with page.expect_download() as download:page.locator('#captionExportSrt').click()
  assert 'Phụ đề tiếng Việt: đẹp quá!' in Path(download.value.path()).read_text(encoding='utf-8-sig')
  with page.expect_download() as download:page.locator('#captionExportAss').click()
  ass=Path(download.value.path()).read_text(encoding='utf-8-sig')
  assert 'PlayResX: 1080' in ass and 'PlayResY: 1920' in ass and 'Phụ đề tiếng Việt: đẹp quá!' in ass
  Path('/tmp/sceneforge-subtitle-test.ass').write_text(ass)
  # Reject invalid imports atomically, leaving the existing work intact.
  page.locator('#captionTextFile').set_input_files({'name':'invalid.srt','mimeType':'text/plain','buffer':b'1\n00:00:03,000 --> 00:00:01,000\nInvalid'})
  expect(page.locator('#captionFeedback')).to_contain_text('kết thúc phải lớn hơn')
  expect(text).to_have_value('Phụ đề tiếng Việt: đẹp quá!')
  vtt='WEBVTT\n\n00:00.000 --> 00:01.500 align:middle\n<b>Chào bạn</b>\n'
  page.locator('#captionTextFile').set_input_files({'name':'captions.vtt','mimeType':'text/vtt','buffer':vtt.encode()})
  expect(page.get_by_role('textbox',name='Nội dung câu 1',exact=True)).to_have_value('Chào bạn')
  srt='1\n00:00:00,000 --> 00:00:01,500\nXin chào Việt Nam\n\n2\n00:00:02,000 --> 00:00:04,000\nDòng thứ hai\n'
  page.locator('#captionTextFile').set_input_files({'name':'captions.srt','mimeType':'text/plain','buffer':srt.encode()})
  expect(page.locator('#captionCount')).to_have_text('2')
  page.get_by_role('button',name='Xem câu 1',exact=True).click()
  expect(page.locator('#captionLive')).to_have_text('Xin chào Việt Nam')
  page.locator('#captionVideoFile').set_input_files(str(root/'scripts/native-preview/assets/concat-native-9x16.mp4'))
  expect(page.locator('#captionSource')).to_have_text('concat-native-9x16.mp4')
  page.wait_for_function('document.querySelector("#captionVideo").duration===12')
  page.locator('#captionVideoFile').set_input_files(str(root/'scripts/native-preview/assets/native-walkthrough.mp4'))
  expect(page.locator('#captionFeedback')).to_contain_text('Chọn video dọc 9:16')
  expect(page.locator('#captionSource')).to_have_text('concat-native-9x16.mp4')
  page.locator('#captionVideo').evaluate('(v)=>v.currentTime=1.7')
  page.wait_for_function('document.querySelector("#captionVideo").currentTime===1.7')
  page.locator('#captionAdd').click();expect(page.locator('#captionCount')).to_have_text('3')
  # No room inside another cue, so adding does not introduce overlaps.
  page.locator('#captionAdd').click();expect(page.locator('#captionCount')).to_have_text('3')
  expect(page.locator('#captionFeedback')).to_contain_text('đã có phụ đề')
  page.locator('#captionVideo').evaluate('(v)=>v.play()')
  before=page.locator('#captionVideo').evaluate('(v)=>v.currentTime')
  page.locator('[data-workspace-tool=media]').click()
  page.locator('#captionMediaCard').click()
  expect(page.locator('#subtitles')).to_be_visible()
  expect(page.locator('#captionInspector')).to_be_hidden()
  expect(page.locator('#clipInspector')).to_be_visible()
  assert not page.locator('#captionVideo').evaluate('(v)=>v.paused')
  assert page.locator('#captionVideo').evaluate('(v)=>v.currentTime')>=before
  page.locator('#captionToolsToggle').click()
  assert page.evaluate('window.originalEditorVideo===document.querySelector("#captionVideo")')
  assert not page.locator('#captionVideo').evaluate('(v)=>v.paused')
  page.locator('#captionVideo').evaluate('(v)=>v.pause()')
  page.locator('#captionVideo').evaluate('(v)=>v.currentTime=0')
  page.locator('[data-caption-preset="bold"]').click()
  page.screenshot(path='/tmp/sceneforge-subtitles-desktop.png',full_page=True)
  page.wait_for_timeout(400)
  page.reload(wait_until='networkidle');expect(page.locator('#subtitles')).to_be_visible()
  expect(page.locator('#captionCount')).to_have_text('3')
  expect(page.locator('[data-caption-preset="bold"]')).to_have_attribute('aria-pressed','true')
  page.set_viewport_size({'width':390,'height':844})
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  page.wait_for_function('document.querySelector("#captionVideo").readyState>=2')
  page.screenshot(path='/tmp/sceneforge-subtitles-mobile.png',full_page=True)
  page.goto(f'http://127.0.0.1:{server.server_port}/web-demo/?tool=subtitles#editor',wait_until='networkidle')
  expect(page.frame_locator('#standaloneEditorDemo').locator('#stage')).to_be_visible()
  page.set_viewport_size({'width':1536,'height':1024})
  page.screenshot(path='/tmp/sceneforge-captions-in-editor.png',full_page=True)
  assert not errors,errors
  browser.close()
 print('PASS: four styles, timed text preview, Vietnamese editing, undo/redo, invalid timing, SRT/ASS downloads, atomic import errors, SRT import, local video, gap insertion, pause on leave, restored draft, mobile width.')
finally:server.shutdown();server.server_close();thread.join()
