// Interior panels follow the supplied SceneForge drawings. Existing model/commands stay authoritative.
const designPaneChoice={},designClosedSections=new Set();
function designSection(name,children,reset=''){
 const section=document.createElement('section');section.className='designSection';section.dataset.section=name;
 const head=document.createElement('div');head.className='designSectionHead';const toggle=document.createElement('button');toggle.className='designSectionToggle';toggle.textContent=name;toggle.setAttribute('aria-expanded',String(!designClosedSections.has(name)));
 const body=document.createElement('div');body.className='designSectionBody';body.hidden=designClosedSections.has(name);for(const child of children.filter(Boolean))body.append(child);
 toggle.onclick=()=>{body.hidden=!body.hidden;toggle.setAttribute('aria-expanded',String(!body.hidden));if(body.hidden)designClosedSections.add(name);else designClosedSections.delete(name);};head.append(toggle);
 if(reset){const button=document.createElement('button');button.className='designReset';button.dataset.designReset=reset;button.title='Đặt lại '+name.toLowerCase();button.setAttribute('aria-label',button.title);button.textContent='↺';head.append(button);}
 section.append(head,body);return section;
}
function designNode(html){const node=document.createElement('div');node.innerHTML=html;return node.firstElementChild;}
function designProp(source,key){return source.querySelector('#prop-'+key)?.closest('.field');}
function designPair(...children){const box=document.createElement('div');box.className='designPositionPair';for(const child of children.filter(Boolean))box.append(child);return box;}
function designTab(key,label,primary=false){const button=document.createElement('button');button.dataset.inspectorTab=key;button.id='property-tab-'+key;button.setAttribute('role','tab');button.setAttribute('aria-controls','property-pane-'+key);button.textContent=label;button.onclick=()=>switchInspectorTab(key);if(primary)button.dataset.primaryPane='true';return button;}
organizeInspector=function(){
 const box=$('#inspector'),item=selected();if(!item)return;
 const raw=document.createElement('div');raw.append(...box.childNodes);const field=key=>designProp(raw,key),isVisual=['video','image'].includes(item.kind),isAudio=['audio','video'].includes(item.kind);
 const heading=document.createElement('div');heading.className='selectionHeader';heading.innerHTML='<div><h3>'+esc(item.kind==='text'?item.name||'Văn bản':item.name)+'</h3><div class="inspectorType">'+({video:'VIDEO',image:'ẢNH',audio:'ÂM THANH',text:item.subtitle?'PHỤ ĐỀ':'VĂN BẢN'}[item.kind])+' · '+esc(getTrack(item.trackId).name)+'</div></div>';box.append(heading);
 const primary=document.createElement('div');primary.className='propertyTabs designPrimaryTabs';primary.setAttribute('role','tablist');primary.setAttribute('aria-label','Thuộc tính clip');
 const secondary=document.createElement('div');secondary.className='designSecondaryTabs';secondary.setAttribute('role','tablist');secondary.setAttribute('aria-label','Chỉnh hình');
 const panes={};for(const key of ['basic','color','audio','style','speed','animation','transition']){const pane=document.createElement('section');pane.className='propertyPane';pane.dataset.inspectorPane=key;pane.id='property-pane-'+key;pane.setAttribute('role','tabpanel');pane.setAttribute('aria-labelledby','property-tab-'+key);panes[key]=pane;}
 if(isVisual){
  primary.append(designTab('basic','Video',true));if(isAudio)primary.append(designTab('audio','Âm thanh',true));if(item.kind==='video')primary.append(designTab('speed','Tốc độ',true));
  secondary.append(designTab('basic-sub','Cơ bản'),designTab('color','Màu'));secondary.firstChild.dataset.inspectorTab='basic';secondary.firstChild.removeAttribute('id');secondary.firstChild.setAttribute('aria-controls','property-pane-basic');secondary.firstChild.onclick=()=>switchInspectorTab('basic');
  const flips=designPair(...['flipX','flipY'].map(key=>raw.querySelector('#prop-'+key)?.closest('label')));flips.classList.add('designFlipControls');
  const align=designNode('<div class="designAlign"><span>Căn nhanh</span><div>'+[['left','⊢','Sát trái'],['center','⊕','Giữa khung'],['right','⊣','Sát phải'],['top','⊤','Sát trên'],['bottom','⊥','Sát dưới']].map(([id,icon,label])=>'<button data-design-align="'+id+'" title="'+label+'" aria-label="'+label+'">'+icon+'</button>').join('')+'</div></div>');
  panes.basic.append(designSection('Biến đổi',[field('scale'),designPair(field('x'),field('y')),field('rotation'),flips,align],'transform'),designSection('Độ hiện rõ',[field('opacity')],'opacity'),designSection('Lấp khung',[field('fit')]));
  const presets=raw.querySelector('.presetGrid');const temp=designNode('<div class="field"><label>Nhiệt độ màu · lạnh ↔ ấm</label><input type="number" id="prop-temperature" data-prop="temperature" min="-100" max="100" step="1" value="'+(item.temperature||0)+'"></div>');
  panes.color.append(designSection('Điều chỉnh màu',[field('brightness'),field('contrast'),field('saturation'),temp,designNode('<button id="applyColorAll" class="wide">Áp màu này cho tất cả clip</button>')],'color'));
  const more=designNode('<details class="designMore"><summary>Bộ màu & làm mờ toàn khung</summary></details>');if(presets)more.append(presets);const blur=field('blur');if(blur)more.append(blur);panes.color.append(more);
 }
 if(item.kind==='text'){
  primary.append(designTab('basic',item.subtitle?'Phụ đề':'Văn bản',true),designTab('style','Kiểu chữ',true));
  const textGroup=[field('text'),field('fontSize'),field('color'),field('align')];const bold=raw.querySelector('[data-prop=bold]')?.closest('label');if(bold)textGroup.push(bold);
  panes.basic.append(designSection('Nội dung',textGroup),designSection('Vị trí trên khung',[designPair(field('textX'),field('textY')),field('opacity')],'opacity'));
  const bg=raw.querySelector('[data-prop=textBg]')?.closest('label');panes.style.append(designSection('Phông & viền chữ',[field('fontFamily'),field('outline'),field('outlineColor'),field('letterSpacing')],'textstyle'),designSection('Nền chữ',[bg,field('background')]));
 }
 if(isAudio){
  if(item.kind==='audio')primary.append(designTab('audio','Cơ bản',true),designTab('speed','Tốc độ',true));
  panes.audio.append(field('volume'),field('fadeIn'),field('fadeOut'));const extract=raw.querySelector('#extractAudio');if(extract)panes.audio.append(extract);
 }
 if(item.kind==='video'||item.kind==='audio'){
  const speed=field('speed');panes.speed.append(designSection('Tốc độ',[designNode('<div class="designSpeedPresets">'+[.5,.8,1,1.2,1.5,2].map(n=>'<button data-design-speed="'+n+'" aria-pressed="'+(item.speed===n)+'">'+n+'×</button>').join('')+'</div>'),speed],'speed'),designNode('<p class="designNote">Thay đổi độ dài clip, giữ đồng bộ hình–tiếng đã liên kết.</p>'));
 }
 const timing=designNode('<details class="designMore"><summary>Thời gian chính xác</summary></details>');for(const key of ['start','duration','mediaIn']){const control=field(key);if(control)timing.append(control);}panes[item.kind==='audio'?'speed':'basic'].append(timing);
 // Existing keyframes remain available in an advanced tab, not mixed into basic transforms.
 const animation=[...raw.querySelectorAll('details')].find(n=>n.querySelector('#addKeyframe'));if(animation)panes.animation.append(animation);
 if(item.kind==='text'){for(const key of ['textAnimation','animationDuration']){const f=field(key);if(f)panes.animation.append(f);}}
 const advanced=document.createElement('div');advanced.className='designAdvancedTabs';advanced.append(designTab('animation','Chuyển động'));
 if(isVisual){advanced.append(designTab('transition','Chuyển cảnh'));panes.transition.append(designNode('<div class="contextTip">Chọn điểm nối giữa hai clip để chỉnh chuyển cảnh.</div>'));}
 box.append(primary);if(isVisual)box.append(secondary);for(const pane of Object.values(panes))if(pane.childNodes.length)box.append(pane);box.append(advanced);
 const footer=document.createElement('div');footer.className='inspectorFooter';for(const key of ['copySettings','pasteSettings']){const button=raw.querySelector('#'+key);if(button)footer.append(button);}box.append(footer);
 addVisualPropertyControls();
 for(const key of ['x','y','textX','textY','temperature','outline','letterSpacing']){
  const input=$('#prop-'+key);if(!input||input.parentElement.querySelector('input[type=range]'))continue;const bounds={x:[-100,100],y:[-100,100],textX:[0,100],textY:[0,100],temperature:[-100,100],outline:[0,12],letterSpacing:[0,25]}[key];
  const slider=document.createElement('input');slider.type='range';slider.min=bounds[0];slider.max=bounds[1];slider.step=key==='outline'?'.5':'1';slider.value=input.value;slider.className='propertySlider';slider.setAttribute('aria-label',input.closest('.field').querySelector('label').textContent);let begun=false;
  slider.oninput=()=>{const i=selected();if(!i||!allowEdit())return;if(!begun){remember();begun=true;}input.value=slider.value;i[key]=Number(slider.value);updateKeyframedProp(i,key,i[key]);updateStage(true);};slider.onchange=()=>{begun=false;scheduleDraft();};input.after(slider);
 }
 if(getTrack(item.trackId).locked||recording)box.querySelectorAll('input,textarea,select,.designReset,[data-design-align],[data-design-speed],#applyColorAll').forEach(n=>n.disabled=true);
 switchInspectorTab(designPaneChoice[item.kind]|| (item.kind==='audio'?'audio':'basic'));
};
// The former decorator inserted an extra heading around every field; the new sections own that job.
decorateReferenceInspector=function(){$('#inspector').dataset.selectedKind=selected()?.kind||'none';};
switchInspectorTab=function(key){
 const pane=$('[data-inspector-pane="'+key+'"]');if(!pane)return;
 const i=selected();if(i){inspectorChoice[i.kind]=key;designPaneChoice[i.kind]=key;}
 $$('[data-inspector-pane]').forEach(n=>n.hidden=n!==pane);
 const visual=['basic','color'].includes(key);const secondary=$('.designSecondaryTabs');if(secondary)secondary.hidden=!visual;
 $$('[data-inspector-tab]').forEach(b=>{const active=b.dataset.inspectorTab===key||(b.dataset.primaryPane&&b.dataset.inspectorTab==='basic'&&key==='color');b.classList.toggle('active',!!active);b.setAttribute('aria-selected',String(!!active));});$('#inspector').scrollTop=0;
};
const designDefaults={transform:{scale:1,x:0,y:0,rotation:0,flipX:false,flipY:false},opacity:{opacity:1},color:{brightness:100,contrast:100,saturation:100,temperature:0,look:'none',blur:0},audio:{volume:1,audioMuted:false},fade:{fadeIn:0,fadeOut:0},speed:{speed:1},textstyle:{fontFamily:'system-ui',outline:0,outlineColor:'#000000',letterSpacing:0}};
$('#inspector').addEventListener('click',e=>{
 const reset=e.target.closest('[data-design-reset]'),align=e.target.closest('[data-design-align]'),speed=e.target.closest('[data-design-speed]');if(!reset&&!align&&!speed&&!e.target.closest('#applyColorAll'))return;if(!allowEdit())return;const i=selected();
 if(speed){applyPlaybackSpeed(i,Number(speed.dataset.designSpeed));return;}
 if(reset?.dataset.designReset==='speed'){applyPlaybackSpeed(i,1);return;}
 if(reset){const values=designDefaults[reset.dataset.designReset];if(values)transact(()=>{Object.assign(i,values);for(const frame of i.keyframes||[])for(const [key,value]of Object.entries(values))if(key in frame.values)frame.values[key]=value;});}
 if(align)transact(()=>{const mode=align.dataset.designAlign,key=['top','bottom'].includes(mode)?'y':'x',stage=$('#stage'),node=mediaNode(i),w=stage.clientWidth,h=stage.clientHeight,sw=node.videoWidth||node.naturalWidth||w,sh=node.videoHeight||node.naturalHeight||h,factor=(i.fit==='cover'?Math.max(w/sw,h/sh):Math.min(w/sw,h/sh))*i.scale,radians=i.rotation*Math.PI/180,bw=(Math.abs(sw*Math.cos(radians))+Math.abs(sh*Math.sin(radians)))*factor,bh=(Math.abs(sw*Math.sin(radians))+Math.abs(sh*Math.cos(radians)))*factor,value=mode==='center'?0:clamp(((key==='x'?bw-w:bh-h)/(key==='x'?w:h))*50*(['left','top'].includes(mode)?1:-1),-100,100);i[key]=value;if(mode==='center')i.y=0;updateKeyframedProp(i,key,value);if(mode==='center')updateKeyframedProp(i,'y',0);});
 if(e.target.closest('#applyColorAll')){const targets=items.filter(n=>['video','image'].includes(n.kind));if(targets.some(n=>getTrack(n.trackId).locked)){notify('Mở khóa các hàng video/ảnh trước khi áp màu cho tất cả.');return;}transact(()=>{for(const n of targets)for(const key of ['brightness','contrast','saturation','temperature','look','blur'])n[key]=i[key]??designDefaults.color[key];});notify('Đã áp màu cho '+targets.length+' clip.');}
});
const designInspectorBase=inspector;
inspector=function(){designInspectorBase();const i=selected();document.body.classList.toggle('designLinkedSelection',!!i?.linkGroup);if(!i)return;const basic=$('#audioBasicControls');
 if(basic){
  const gain=basic.querySelector('.gainDbField'),oldVolume=basic.querySelector('#prop-volume')?.closest('.field'),fades=['fadeIn','fadeOut'].map(key=>basic.querySelector('#prop-'+key)?.closest('.field')),extract=basic.querySelector('#extractAudio');
  const audioSection=designSection(i.kind==='video'?'Tiếng gốc':'Âm lượng',[gain,oldVolume],'audio'),fadeSection=designSection('Rõ dần / mờ dần',fades,'fade');if(oldVolume)oldVolume.hidden=true;
  for(const [index,f]of fades.entries())if(f){const label=f.querySelector('label');if(label)label.textContent=index?'Mờ dần (s)':'Rõ dần (s)';}
  basic.replaceChildren(audioSection,fadeSection);if(extract)basic.append(extract);
 }
 for(const [key,label]of [['scale','Kích thước (%)'],['x','Vị trí X'],['y','Vị trí Y'],['rotation','Xoay (°)'],['opacity','Độ hiện rõ (%)']]){const n=$('#prop-'+key)?.closest('.field')?.querySelector('label');if(n)n.textContent=label;}
 // Put quick fields and numeric values on the same row as in the design.
 for(const field of $$('#inspector .field'))if(field.querySelector('input[type=number]')&&field.querySelector('input[type=range]'))field.classList.add('designSliderField');
 const title=$('#inspectorPanel>.panelHead b');if(title)title.textContent=i.kind==='text'?(i.subtitle?'Chỉnh phụ đề':'Chỉnh văn bản'):i.kind==='audio'?'Chỉnh âm thanh':'Chỉnh clip';
};
// Search remains available from the header and Ctrl+K; the media pane no longer has two search rows.
const designSearch=$('.toolSearchWrap');$('header>.actions').prepend(designSearch);designSearch.querySelector('input').placeholder='Tìm công cụ…';
const collapse=$('#collapseMedia');$('#mediaPanel').append(collapse);collapse.classList.add('designCollapseHandle');
const sourceRow=$('.sourceActionRow');sourceRow.insertBefore($('.assetSearch'),$('#assetOrder'));sourceRow.after($('#mediaTabs'));
const drop=document.createElement('button');drop.id='designImportDrop';drop.textContent='Kéo tệp video, ảnh, âm thanh vào đây';drop.onclick=()=>$('#file').click();$('#mediaTabs').after(drop);
const librarySummary=document.createElement('div');librarySummary.id='designLibrarySummary';librarySummary.innerHTML='<span></span><button id="designRemoveUnused">Xóa mục chưa dùng</button>';$('#sourceLibrary').append(librarySummary);
$('#designRemoveUnused').onclick=()=>{const unused=assets.filter(a=>!a.builtin&&!a.id.startsWith('pinned_')&&!items.some(i=>i.assetId===a.id));if(!unused.length){notify('Không có tư liệu chưa dùng để dọn.');return;}transact(()=>{const ids=new Set(unused.map(a=>a.id));assets=assets.filter(a=>!ids.has(a.id));});notify('Đã bỏ '+unused.length+' mục khỏi kho. Tệp trên máy giữ nguyên.');};
const assetsBeforeDesign=renderAssets;
renderAssets=function(){assetsBeforeDesign();const cards=$$('#assets>.asset');const sections=[['video','Video'],['image','Ảnh'],['audio','Âm thanh']];for(const [kind,label]of sections){const members=cards.filter(card=>getAsset(card.dataset.asset)?.kind===kind);if(!members.length)continue;const title=document.createElement('h4');title.className='designAssetGroup';title.innerHTML=label+' <span>'+members.length+'</span>';$('#assets').append(title,...members);}
 for(const card of cards){const a=getAsset(card.dataset.asset),media=card.firstElementChild;const stamp=document.createElement('span');stamp.className='designAssetDuration';stamp.textContent=a.kind==='image'?'Ảnh':fmt(a.sampleDuration||a.duration).replace(/^0/,'').replace(/\.\d$/,'');media.append(stamp);card.querySelector('small').textContent=a.missing?'Mất tệp · nhập lại để nối':a.builtin?'Tư liệu mẫu':items.some(i=>i.assetId===a.id)?'Đã dùng trong bản dựng':'Tư liệu trên máy';if(a.missing){const relink=document.createElement('button');relink.className='designRelink';relink.textContent='Tìm lại';relink.onclick=()=>$('#file').click();media.append(relink);}}
 $('#designLibrarySummary>span').textContent=cards.length+' mục · '+cards.filter(n=>items.some(i=>i.assetId===n.dataset.asset)).length+' đang dùng';
};
$('#assetOrder').onchange=renderAssets;
// Portrait preview follows the reference's clock / centred play / right-hand tools.
$('.previewHead>span').textContent='Trình phát';
$('.transport').prepend($('#clock'));const transportRight=document.createElement('div');transportRight.className='designTransportRight';transportRight.append($('#tiktokPreview'),$('#fullscreen'),$('#keyboardHelp'));$('.transport').append(transportRight);
// Reflow the existing export controls rather than presenting unsupported FFmpeg options.
const exportDialog=$('#exportDialog'),exportSettings=document.createElement('div');exportSettings.id='designExportSettings';
const exportName=designNode('<label class="designExportRow"><span>Tên video</span><input id="editorExportName" maxlength="100" value="'+esc(workbenchPrefs.name)+'" aria-label="Tên tệp video xuất"></label>');
const formatPair=$('#exportSize').closest('.pair');for(const child of [...exportDialog.children])if(!child.matches('h2,.actions'))exportSettings.append(child);exportDialog.insertBefore(exportSettings,exportDialog.querySelector('.actions'));exportSettings.prepend(exportName);
for(const id of ['exportSize','exportFormat']){const el=$('#'+id),row=el.closest('.field');row.classList.add('designExportRow');}
const exportOpenDesign=$('#export').onclick;$('#export').onclick=()=>{if(!$('#editorExportName').dataset.edited)$('#editorExportName').value=$('#editorProjectName').value;exportOpenDesign();};$('#editorExportName').oninput=e=>e.target.dataset.edited='true';
// The channel meter uses the real mixed PCM signal, never a decorative animation.
const meter=document.createElement('aside');meter.id='designMasterMeter';meter.setAttribute('aria-label','Âm lượng tổng');meter.innerHTML='<span>dB</span><div class="designMeterScale"><i></i><b>0<br>−6<br>−12<br>−24<br>−48</b><em></em></div><output>−∞</output>';$('#timeline').append(meter);
let designMeterSamples,designAnalyser,designMeterSource,designMeterContext,designMeterRAF=0,designPeak=0,designPeakUntil=0;
const audioPrepareBeforeDesign=prepareExportAudio;
prepareExportAudio=async function(){const result=await audioPrepareBeforeDesign();if(exportAudioContext&&exportDestination&&designMeterContext!==exportAudioContext){designMeterContext=exportAudioContext;designMeterSource=exportAudioContext.createMediaStreamSource(exportDestination.stream);designAnalyser=exportAudioContext.createAnalyser();designAnalyser.fftSize=512;designMeterSamples=new Float32Array(512);designMeterSource.connect(designAnalyser);}if(!designMeterRAF)designMeterRAF=requestAnimationFrame(paintDesignMeter);return result;};
function paintDesignMeter(){designMeterRAF=0;let peak=0;if(playing&&designAnalyser){designAnalyser.getFloatTimeDomainData(designMeterSamples);for(const value of designMeterSamples)peak=Math.max(peak,Math.abs(value));}const db=peak>1e-5?20*Math.log10(peak):-Infinity,level=Number.isFinite(db)?clamp((db+48)/48,0,1):0,now=performance.now();
 if(level>designPeak||now>designPeakUntil){designPeak=level;designPeakUntil=now+800;}meter.style.setProperty('--meter-level',(level*100)+'%');meter.style.setProperty('--meter-peak',(designPeak*100)+'%');meter.classList.toggle('clipping',peak>=.999);meter.querySelector('output').textContent=peak>=.999?'RÈ':Number.isFinite(db)?Math.round(db):'−∞';if(playing)designMeterRAF=requestAnimationFrame(paintDesignMeter);
}
timelineHeaderWidth=184;
// Shared media is an actual local IndexedDB library, scoped to this browser/device.
let designLibraryScope='project',designPinned=[],designPinsReady=false;
const scopes=document.createElement('div');scopes.id='designScopes';scopes.innerHTML='<button data-design-scope="project" class="active">Dự án này</button><button data-design-scope="shared">♧ Dùng chung</button>';$('#sourceLibrary').prepend(scopes);
function designPinsIO(mode,value){return editorDB().then(db=>new Promise((resolve,reject)=>{const tx=db.transaction('drafts',mode),r=mode==='readonly'?tx.objectStore('drafts').get('pinned-library'):tx.objectStore('drafts').put(value,'pinned-library');tx.oncomplete=()=>resolve(r.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);}));}
async function loadDesignPins(){try{const entries=await designPinsIO('readonly');for(const entry of entries||[]){if(!(entry.file instanceof Blob)||typeof entry.id!=='string'||!/^pinned_[\w-]+$/.test(entry.id)||!['video','audio','image'].includes(entry.kind))continue;const url=URL.createObjectURL(entry.file);designPinned.push({...entry,url,poster:entry.kind==='image'?url:entry.poster});}designPinsReady=true;renderAssets();}catch{designPinsReady=true;}}
function keepDesignPins(){return designPinsIO('readwrite',designPinned.map(({url,...entry})=>entry));}
const renderBeforeScopes=renderAssets;
renderAssets=function(){
 for(const a of designPinned)if(!assets.some(n=>n.id===a.id))assets.push({...a});const all=assets,sharedIds=new Set(designPinned.map(a=>a.id));
 const pool=all.filter(a=>designLibraryScope==='shared'?sharedIds.has(a.id):!a.id.startsWith('pinned_')||items.some(i=>i.assetId===a.id));
 try{assets=pool;renderBeforeScopes();}finally{assets=all;}
 if(designLibraryScope==='shared'&&!pool.length)$('#assets').innerHTML='<p class="designEmptyLibrary">Chưa ghim tư liệu.<br><small>Chuột phải vào một thẻ trong Dự án này → Ghim vào Dùng chung. Tư liệu lưu trên trình duyệt này.</small></p>';
};
scopes.onclick=e=>{const b=e.target.closest('[data-design-scope]');if(!b)return;designLibraryScope=b.dataset.designScope;scopes.querySelectorAll('button').forEach(n=>n.classList.toggle('active',n===b));renderAssets();};
const assetMenu=document.createElement('div');assetMenu.id='designAssetMenu';assetMenu.hidden=true;document.body.append(assetMenu);
$('#assets').addEventListener('contextmenu',e=>{const card=e.target.closest('[data-asset]');if(!card)return;e.preventDefault();const a=getAsset(card.dataset.asset);if(!a)return;const pinned=designPinned.some(n=>n.id===a.id);assetMenu.dataset.asset=a.id;assetMenu.innerHTML='<button data-design-asset-action="add">Thêm vào vạch phát</button><button data-design-asset-action="pin">'+(pinned?'Bỏ ghim khỏi Dùng chung':'Ghim vào Dùng chung')+'</button><button data-design-asset-action="rename">Đổi tên trong kho</button><button data-design-asset-action="remove">Xóa khỏi kho</button>';assetMenu.hidden=false;assetMenu.style.left=clamp(e.clientX,4,innerWidth-205)+'px';assetMenu.style.top=clamp(e.clientY,4,innerHeight-155)+'px';});
assetMenu.onclick=async e=>{
 const action=e.target.closest('[data-design-asset-action]')?.dataset.designAssetAction,a=getAsset(assetMenu.dataset.asset);assetMenu.hidden=true;if(!action||!a)return;
 if(action==='add'){addAsset(a.id,undefined,time);return;}
 if(action==='rename'){const name=prompt('Tên tư liệu',a.name);if(name?.trim()){a.name=name.trim().slice(0,150);const pin=designPinned.find(n=>n.id===a.id);if(pin){pin.name=a.name;await keepDesignPins();}renderAssets();scheduleDraft();}return;}
 if(action==='pin'){
  const beforePins=designPinned.slice();try{const index=designPinned.findIndex(n=>n.id===a.id);if(index>=0){designPinned.splice(index,1);await keepDesignPins();renderAssets();notify('Đã bỏ ghim. Clip trên timeline được giữ nguyên.');return;}
   if(!a.url||a.missing){notify('Chọn lại tệp bị mất trước khi ghim.');return;}const response=await fetch(a.url);if(!response.ok)throw Error();const file=await response.blob(),id='pinned_'+crypto.randomUUID();designPinned.push({id,name:a.name,kind:a.kind,duration:a.duration,sampleDuration:a.sampleDuration,sourceIn:a.sourceIn,file,url:URL.createObjectURL(file),poster:a.poster});await keepDesignPins();renderAssets();notify('Đã ghim vào Dùng chung trên máy này.');
  }catch{designPinned=beforePins;renderAssets();notify('Chưa ghim được. Kiểm tra dung lượng lưu trữ của trình duyệt.');}return;
 }
 if(action==='remove'){
  if(items.some(i=>i.assetId===a.id)){notify('Tư liệu đang dùng trong timeline. Xóa clip trên timeline trước khi bỏ khỏi kho.');return;}
  if(designPinned.some(n=>n.id===a.id)){designPinned=designPinned.filter(n=>n.id!==a.id);await keepDesignPins();}assets=assets.filter(n=>n.id!==a.id);renderAssets();scheduleDraft();notify('Đã bỏ khỏi kho, giữ nguyên tệp trên máy.');
 }
};
document.addEventListener('pointerdown',e=>{if(!e.target.closest('#designAssetMenu'))assetMenu.hidden=true;});document.addEventListener('keydown',e=>{if(e.key==='Escape')assetMenu.hidden=true;});
const bootBeforeDesign=bootSharedEditor;bootSharedEditor=function(){bootBeforeDesign();loadDesignPins();};
function paintDesignAudioCards(){for(const card of $$('#assets [data-asset]')){const asset=getAsset(card.dataset.asset);if(asset?.kind!=='audio')continue;const data=cachedArtwork(asset);if(!data?.peaks)continue;const icon=card.querySelector('.assetIcon');if(!icon)continue;let canvas=icon.querySelector('canvas');if(!canvas){canvas=document.createElement('canvas');canvas.width=160;canvas.height=100;canvas.setAttribute('aria-label','Sóng âm từ tệp');icon.append(canvas);}const ctx=canvas.getContext('2d');ctx.clearRect(0,0,160,100);const peak=Math.max(.01,...data.peaks);ctx.fillStyle='#24c3b7';for(let x=0;x<160;x+=3){const value=data.peaks[Math.min(data.peaks.length-1,Math.floor(x/160*data.peaks.length))],h=Math.max(1,value/peak*54);ctx.fillRect(x,(100-h)/2,1.5,h);}}}
const artworkBeforeDesign=paintTimelineArtwork;paintTimelineArtwork=function(){artworkBeforeDesign();paintDesignAudioCards();};
const renderAssetsBeforeWaveCards=renderAssets;renderAssets=function(){renderAssetsBeforeWaveCards();paintDesignAudioCards();};

$('#exportSize').value='1080';
const timelineCardsBeforePoster=timeline;
timeline=function(){timelineCardsBeforePoster();for(const el of $$('.timelineItem.video')){const i=items.find(n=>n.id===el.dataset.item),poster=getAsset(i?.assetId)?.poster;if(poster&&!el.querySelector('.clipArtwork[data-ready=frames]')){el.style.backgroundImage='url("'+poster.replace(/"/g,'%22')+'")';el.style.backgroundSize='auto calc(100% - 19px)';el.style.backgroundPosition='left bottom';el.style.backgroundRepeat='repeat-x';}}};
// Hidden drop-mode controls never silently restore a destructive overwrite mode.
const bootBeforeAutomaticRows=bootSharedEditor;bootSharedEditor=function(){bootBeforeAutomaticRows();timelineEditMode='insert';$('#timelineEditMode').value='insert';};
const loadBeforeAutomaticRows=$('#projectFile').onchange;$('#projectFile').onchange=async function(event){await loadBeforeAutomaticRows(event);timelineEditMode='insert';$('#timelineEditMode').value='insert';};
