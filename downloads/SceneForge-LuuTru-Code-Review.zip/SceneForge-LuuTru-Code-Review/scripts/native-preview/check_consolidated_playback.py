"""Continuous three-cut playback while changing retained editor layouts."""
from pathlib import Path
from functools import partial
import http.server,threading,json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=s.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1366,'height':768});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{s.server_port}/native/index.html');page.wait_for_function('window.SceneForgeEditor');model=page.evaluate('SceneForgeEditor.getState()');model.update(format='sceneforge-timeline',version=1)
  for i in model['items'][:-1]:i.update(transition='dissolve',transitionDuration=.6,audioMuted=True)
  page.locator('#projectFile').set_input_files({'name':'playback.json','mimeType':'application/json','buffer':json.dumps(model).encode()});page.wait_for_function('Array.from(document.querySelectorAll("#stageLayers video")).some(v=>v.readyState>=2)')
  page.evaluate('''()=>{window.playbackSamples=[];window.playbackSampling=true;const tick=()=>{const s=SceneForgeEditor.getState();if(s.time>.1&&s.time<11.9){const active=[...document.querySelectorAll('#stageLayers video')].filter(v=>v.style.display!=='none');playbackSamples.push({t:s.time,ready:active.some(v=>v.readyState>=2),count:active.length});}if(playbackSampling)requestAnimationFrame(tick);};requestAnimationFrame(tick);}''');page.locator('#play').click();page.wait_for_function('SceneForgeEditor.getState().time>1')
  for layout in ['left','right','tall','default']:
   page.locator('#editorLayoutButton').click();page.locator('[data-editor-layout='+layout+']').click();assert page.evaluate('SceneForgeEditor.isPlaying()');page.wait_for_timeout(350)
  page.wait_for_function('!SceneForgeEditor.isPlaying()&&SceneForgeEditor.getState().time>=11.9',timeout=20000)
  samples=page.evaluate('()=>{playbackSampling=false;return playbackSamples}');missing=[x for x in samples if not x['ready']];joins=[x for x in samples if 3.75<x['t']<4.25 or 7.75<x['t']<8.25];assert len(samples)>100 and len(joins)>10,(len(samples),len(joins));assert not missing,missing[:8];assert any(x['count']==2 for x in joins),joins
  assert not errors,errors;print('PASS: 12s continuous three-clip playback, two-source transitions, all four layouts changed during playback at 1366×768; no sampled frame lacked a ready visible video. Synthetic bundled source, not a Windows/heavy-video certification.');b.close()
finally:s.shutdown()
