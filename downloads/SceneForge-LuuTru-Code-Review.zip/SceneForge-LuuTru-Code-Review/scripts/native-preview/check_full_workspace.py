"""Check the published multi-track editor's visual effects and merged captions."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist')))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1536,'height':1024});errors=[]
  page.on('pageerror',lambda error:errors.append(str(error)))
  base=f'http://127.0.0.1:{server.server_port}/web-demo/native/'
  page.goto(base,wait_until='networkidle')
  state=lambda:page.evaluate('SceneForgeEditor.getState()')
  assert len(state()['items'])==3 and len(state()['tracks'])==3
  assert page.locator('#creativeToolbar [data-library]:visible').count()==4
  first=state()['items'][0]['id']
  page.locator('#toolSearch').fill('Hiệu ứng chuyển động');page.locator('#toolSearchResults [data-command-index]').first.click()
  assert page.locator('[data-rich-effect]').count()==9
  assert page.locator('.effectCompare img').count()==18
  page.locator('[data-effect-group=image]').click();assert page.locator('[data-rich-effect]').count()==3
  page.locator('#richEffectSearch').fill('Sáng dịu');assert page.locator('[data-rich-effect]').count()==1
  page.locator('[data-rich-effect=bright]').click()
  assert next(i for i in state()['items'] if i['id']==first)['brightness']==115
  expect(page.locator('#richEffectDetail')).to_contain_text('Sáng 115%')
  expect(page.locator('#prop-brightness')).to_be_visible()
  page.locator('#prop-brightness').fill('132');page.locator('#prop-brightness').press('Tab')
  assert next(i for i in state()['items'] if i['id']==first)['brightness']==132
  page.locator('#undo').click();assert next(i for i in state()['items'] if i['id']==first)['brightness']==115
  page.locator('#richEffectSearch').fill('');page.locator('[data-effect-group=motion]').click()
  page.locator('[data-rich-effect=zoom]').click()
  clip=next(i for i in state()['items'] if i['id']==first)
  assert len(clip['keyframes'])==2 and clip['keyframes'][-1]['values']['scale']==1.15
  expect(page.locator('[data-inspector-pane=animation]')).to_be_visible()
  page.locator('[data-rich-keyframe]').fill('135');page.locator('[data-rich-keyframe]').press('Tab')
  assert next(i for i in state()['items'] if i['id']==first)['keyframes'][-1]['values']['scale']==1.35
  page.locator('[data-rich-action=preview]').click()
  page.wait_for_function('SceneForgeEditor.isPlaying()&&SceneForgeEditor.getState().time>.2')
  page.locator('#play').click()
  page.screenshot(path='/tmp/sceneforge-detailed-effects.png',full_page=True)
  page.locator('[data-library=transitions]').click()
  page.locator('[data-palette-transition=fade]').click()
  page.locator('#prop-transitionDuration').fill('1.1');page.locator('#prop-transitionDuration').press('Tab')
  assert next(i for i in state()['items'] if i['id']==first)['transitionDuration']==1.1
  page.evaluate('SceneForgeEditor.seek(3.8)')
  assert float(page.locator('#stageLayers video').first.evaluate('(v)=>v.style.opacity'))<1
  page.locator('[data-library=captions]').click()
  assert page.locator('[data-shared-style]').count()==4
  vtt='WEBVTT\n\n00:00.000 --> 00:02.000\nXin chào Việt Nam\n\n00:03.000 --> 00:05.000\nCùng bắt đầu nhé\n'
  page.locator('#srtFile').set_input_files({'name':'captions.vtt','mimeType':'text/vtt','buffer':vtt.encode()})
  page.wait_for_function('SceneForgeEditor.getState().items.filter(i=>i.subtitle).length===2')
  page.locator('[data-shared-style=bold]').click()
  assert next(i for i in state()['items'] if i['id']==state()['selectedIds'][0])['color']=='#ffdc45'
  # Styling the imported text leaves video items intact.
  assert len([i for i in state()['items'] if i['kind']=='video'])==3
  with page.expect_download() as d:page.locator('[data-shared-caption=srt]').click()
  assert 'Xin chào Việt Nam' in Path(d.value.path()).read_text(encoding='utf-8-sig')
  with page.expect_download() as d:page.locator('[data-shared-caption=ass]').click()
  ass=Path(d.value.path()).read_text(encoding='utf-8-sig');assert 'PlayResX: 1080' in ass and 'Xin chào Việt Nam' in ass
  Path('/tmp/sceneforge-multitrack-captions.ass').write_text(ass)
  before=[i for i in state()['items'] if i.get('subtitle')]
  bad='1\n00:00:00,000 --> 00:00:04,000\nMột\n\n2\n00:00:02,000 --> 00:00:05,000\nHai\n'
  page.locator('#srtFile').set_input_files({'name':'bad.srt','mimeType':'text/plain','buffer':bad.encode()})
  expect(page.locator('#toast')).to_contain_text('chồng thời gian')
  assert before==[i for i in state()['items'] if i.get('subtitle')]
  # Verify the previous shared subtitle draft is retained on upgrade.
  migration=browser.new_page(viewport={'width':1440,'height':1000})
  migration.add_init_script('''localStorage.removeItem('sceneforge-editor-draft-v2');localStorage.setItem('sceneforge.subtitle-draft.v1',JSON.stringify({cues:[{start:0,end:2,text:'Bản chữ đã lưu'}],preset:'bold',size:76,position:20}));''')
  migration.goto(base,wait_until='networkidle')
  migrated=migration.evaluate('SceneForgeEditor.getState().items.filter(i=>i.subtitle)')
  assert len(migrated)==1 and migrated[0]['text']=='Bản chữ đã lưu' and migrated[0]['color']=='#ffdc45'
  assert migration.evaluate('!!localStorage.getItem("sceneforge.subtitle-draft.v1")')
  migration.close()
  assert not errors,errors
  browser.close()
 print('PASS: nine before/after effect cards, categories/search, actual clip properties and keyframes, preview, undo; merged captions with four styles, VTT import, SRT/ASS export, atomic overlap rejection and previous draft migration.')
finally:server.shutdown();server.server_close();thread.join()
