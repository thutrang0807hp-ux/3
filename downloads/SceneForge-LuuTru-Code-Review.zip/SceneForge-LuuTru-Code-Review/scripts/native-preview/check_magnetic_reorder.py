"""Magnetic reorder from real pointer gestures, with source/audio preservation."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1800,'height':1000});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()))
 page.goto('http://demo.test/');state=lambda:page.evaluate('SceneForgeEditor.getState()');source=state();template=source['items'][0]
 def fixture(linked=False):
  model=dict(source,format='sceneforge-timeline',version=1)
  model['tracks']=[{'id':'v','kind':'video','name':'Video'},{'id':'m','kind':'audio','name':'Nhạc'},{'id':'t','kind':'text','name':'Phụ đề'}]
  model['items']=[dict(template,id=id,trackId='v',assetId='sample'+str(n),start=start,duration=duration,mediaIn=n,linkGroup=('link'+id if linked else None)) for n,(id,start,duration) in enumerate([('a',0,4),('b',4,3),('c',16,2)])]
  model['items'] += [dict(template,id='music',kind='audio',assetId='music',trackId='m',start=1,duration=10),dict(template,id='text',kind='text',assetId=None,trackId='t',start=2,duration=5,text='Giữ thời gian')]
  if linked:
   model['tracks'].append({'id':'dialogue','kind':'audio','name':'Tiếng clip'})
   model['items'] += [dict(i,id='sound'+i['id'],kind='audio',trackId='dialogue') for i in model['items'][:3]]
  page.locator('#projectFile').set_input_files({'name':'magnetic.json','mimeType':'application/json','buffer':json.dumps(model).encode()})
  page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.id==="c"&&i.start===16)');page.wait_for_timeout(80)
  return state()
 def drag(id,at,grip=30):
  before=state();r=page.locator('[data-item='+id+']').bounding_box();lane=page.locator('[data-lane=v]').bounding_box();scale=r['width']/next(i['duration'] for i in before['items'] if i['id']==id)
  page.mouse.move(r['x']+grip,r['y']+25);page.mouse.down();page.mouse.move(lane['x']+at*scale,r['y']+25,steps=18);page.wait_for_timeout(35)
  assert state()['items']==before['items'],'Preview must not mutate the model'
  page.mouse.up();page.wait_for_timeout(60)
 def check(order,before):
  result=state();videos=sorted([i for i in result['items'] if i['trackId']=='v'],key=lambda i:i['start']);assert [i['id'] for i in videos]==order,videos
  cursor=0
  for item in videos:
   assert abs(item['start']-cursor)<.001,item;cursor+=item['duration']
   old=next(i for i in before['items'] if i['id']==item['id'])
   assert {k:v for k,v in item.items() if k not in ['start','trackId']}=={k:v for k,v in old.items() if k not in ['start','trackId']}
  assert len(result['items'])==len(before['items'])
  for id in ['music','text']:assert next(i for i in result['items'] if i['id']==id)==next(i for i in before['items'] if i['id']==id)
  for video in videos:
   if video.get('linkGroup'):
    audio=next(i for i in result['items'] if i['id']=='sound'+video['id']);assert audio['start']==video['start'] and audio['duration']==video['duration']
  return result
 # Clip 3 starts far away: insert it at the 1/2 boundary, exactly 1 → 3 → 2.
 before=fixture();drag('c',4.1);after=check(['a','c','b'],before)
 page.locator('#undo').click();assert state()['items']==before['items'];page.locator('#redo').click();assert state()['items']==after['items']
 # Move the first clip after the second; retain the third clip's chronological slot.
 before=fixture();drag('a',6.7);check(['b','a','c'],before)
 # Far-right empty space means append, rather than create a giant blank interval.
 before=fixture();drag('a',20);check(['b','c','a'],before)
 # Grab near the right edge: insertion uses the cursor/slot rather than the clip's left edge.
 before=fixture();drag('c',1,grip=100);check(['c','a','b'],before)
 # A discontiguous group is inserted as an ordered block, packed without its old gap.
 before=fixture();page.locator('[data-item=b]').click();page.locator('[data-item=c]').click(modifiers=['Shift']);drag('b',.5);check(['b','c','a'],before)
 # Both selected and displaced extracted dialogue follow their picture, music stays fixed.
 before=fixture(True);drag('c',4.1);check(['a','c','b'],before)
 page.screenshot(path='/tmp/sceneforge-magnetic-reorder.png')
 assert not errors,errors
 print('PASS: 1→3→2, move-first, far-right append, grip offset, group reorder; contiguous varied durations, unchanged sources/music/captions, all linked dialogue synchronized, model unchanged during drag, exact undo/redo.')
 b.close()
