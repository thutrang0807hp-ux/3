"""Verify compact controls, real >100% gain, local level points and visible join regions."""
from pathlib import Path
import sys,json,io,wave,subprocess
import numpy as np
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/demo-lite'))
from browser_controls import controls
rate=48000;t=np.arange(round(rate*1.2))/rate;raw=io.BytesIO()
with wave.open(raw,'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes((.002*np.sin(2*np.pi*440*t)*32767).astype('<i2').tobytes())
with sync_playwright()as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000},accept_downloads=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()));page.goto('http://demo.test/')
 state=lambda:page.evaluate('SceneForgeEditor.getState()');q=controls(page)
 assert page.locator('[data-audio-preset]').count()==3
 # A real-time-sized transition region spans both neighbours, retaining clip trim access.
 first=state()['items'][0]['id'];page.locator('[data-join="'+first+'"]').click();region=page.locator('[data-join="'+first+'"]');box=region.bounding_box();clip=page.locator('[data-item="'+first+'"]').bounding_box();assert abs(box['height']-clip['height'])<2,(box,clip)
 assert abs(box['width']-state()['items'][0]['transitionDuration']*62)<2
 page.locator('#prop-transitionDuration').fill('1.5');page.locator('#prop-transitionDuration').press('Tab');assert abs(region.bounding_box()['width']-93)<2
 handle=region.locator('[data-join-edge=right]').bounding_box();page.mouse.move(handle['x']+3,handle['y']+20);page.mouse.down();page.mouse.move(handle['x']+23,handle['y']+20,steps=8);page.mouse.up();assert state()['items'][0]['transitionDuration']>1.5;page.locator('#undo').click();assert state()['items'][0]['transitionDuration']==1.5
 page.screenshot(path='/tmp/sceneforge-transition-region.png',full_page=True)
 # Keep one short source video then attach genuinely quiet sound.
 for i in state()['items'][1:]:page.locator('[data-item="'+i['id']+'"]').click();page.locator('#delete').click()
 page.locator('[data-item="'+first+'"]').click();q('#prop-duration').fill('1.2');q('#prop-duration').press('Tab')
 page.locator('#file').set_input_files({'name':'quiet.wav','mimeType':'audio/wav','buffer':raw.getvalue()});page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.kind==="audio")')
 audio=next(i for i in state()['items']if i['kind']=='audio');page.locator('[data-item="'+audio['id']+'"]').click()
 expect(page.locator('#miniAudioControls')).to_be_visible();expect(page.locator('#inspectorPanel')).to_be_visible()
 assert page.locator('#miniAudioControls').evaluate('(n)=>!!n.closest(".sequenceHead")')
 def level(percent):page.locator('#miniVolume').fill(str(percent));page.locator('#miniVolume').press('Tab')
 def export(name):
  page.locator('#export').click()
  with page.expect_download(timeout=20000)as dl:page.locator('#realExport').click()
  target=Path('/tmp/'+name+'.webm');dl.value.save_as(str(target));page.locator('#closeExport').click()
  samples=subprocess.check_output(['ffmpeg','-v','error','-i',str(target),'-map','0:a:0','-ar','48000','-ac','1','-f','f32le','-']);a=np.frombuffer(samples,dtype='<f4')[8000:40000];return float(np.sqrt(np.mean(a*a)))
 baseline=export('sceneforge-quiet-100');level(1000);assert next(i for i in state()['items']if i['id']==audio['id'])['volume']==10
 loud=export('sceneforge-quiet-1000');assert 8<loud/baseline<12,(baseline,loud,loud/baseline)
 level(2000);assert next(i for i in state()['items']if i['id']==audio['id'])['volume']==20
 loudest=export('sceneforge-quiet-2000');assert 18<loudest/baseline<22,(baseline,loudest)
 page.screenshot(path='/tmp/sceneforge-audio-mini-live.png',full_page=True)
 page.locator('#miniMute').click();assert next(i for i in state()['items']if i['id']==audio['id'])['audioMuted'];page.locator('#miniMute').click();assert next(i for i in state()['items']if i['id']==audio['id'])['volume']==20
 page.locator('#miniAudioMore').click();page.locator('#miniFadeIn').fill('.1');page.locator('#miniFadeIn').press('Tab');assert next(i for i in state()['items']if i['id']==audio['id'])['fadeIn']==.1
 page.locator('#miniSpeed').select_option('2');assert next(i for i in state()['items']if i['id']==audio['id'])['duration']<.61
 page.locator('#undo').click();assert next(i for i in state()['items']if i['id']==audio['id'])['speed']==1
 # Keyframed boost survives saved projects; volume automation permits values above 1.
 page.evaluate('SceneForgeEditor.seek(.6)');page.locator('#miniAudioMore').click();page.locator('#miniVolumeKeyframe').click();level(500);item=next(i for i in state()['items']if i['id']==audio['id']);assert any(abs(k['at']-.6)<.01 and k['values']['volume']==5 for k in item['keyframes'])
 with page.expect_download()as dl:page.locator('#saveProject').click()
 saved=Path(dl.value.path()).read_bytes();page.locator('#projectFile').set_input_files({'name':'saved.json','mimeType':'application/json','buffer':saved});page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.keyframes.length===3)')
 item=next(i for i in state()['items']if i['id']==audio['id']);assert max(k['values']['volume']for k in item['keyframes'])==20
 # Existing EQ/gain settings now remain editable through the restored inspector.
 model=json.loads(saved);item=next(i for i in model['items']if i['id']==audio['id']);item.update(volume=1,keyframes=[],audioPreset='phone',audioBypass=False,audioGainDb=6,audioBass=-12,audioPan=-100)
 page.locator('#projectFile').set_input_files({'name':'legacy.json','mimeType':'application/json','buffer':json.dumps(model).encode()});page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.kind==="audio"&&i.audioGainDb===6&&i.volume===1)')
 item=next(i for i in state()['items']if i['id']==audio['id']);assert not item['audioBypass'] and item['audioBass']==-12 and item['audioPan']==-100
 page.locator('[data-item="'+audio['id']+'"]').click();page.screenshot(path='/tmp/sceneforge-audio-mini.png',full_page=True)
 assert not errors,errors
 print('PASS: restored audio inspector and miniature header controls, actual 10x exported RMS for quiet audio, 2000% volume, mute preserves gain, fade and >100% volume keyframes survive JSON, old EQ/gain retained and editable, full-height accurate-duration join region and resize/undo.')
 browser.close()
