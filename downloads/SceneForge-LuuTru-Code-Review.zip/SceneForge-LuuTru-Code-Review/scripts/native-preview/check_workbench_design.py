"""Real browser checks for the supplied workbench layout and media-inclusive draft."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import io,threading,wave,math,struct,subprocess,tempfile
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')))
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1366,'height':768});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}/native/');state=lambda:page.evaluate('SceneForgeEditor.getState()')
  assert page.locator('#creativeToolbar [data-library]:visible').count()==4
  assert page.locator('#timelineEditMode option:not([disabled])').all_text_contents()==['Chèn','Ghi đè']
  assert not page.locator('#projectAspect').is_visible() and not page.locator('#addMarker').is_visible()
  # Move only panels, retaining the exact playing video element and project model.
  page.evaluate('window.keptVideo=document.querySelector("#stageLayers video")');before=state()['items']
  page.locator('#play').click();page.wait_for_function('SceneForgeEditor.isPlaying()')
  for layout in ['left','right','tall','default']:
   page.locator('#editorLayoutButton').click();page.locator('[data-editor-layout='+layout+']').click();page.wait_for_timeout(120)
   assert page.evaluate('window.keptVideo===document.querySelector("#stageLayers video")')
   assert page.evaluate('SceneForgeEditor.isPlaying()')
   assert state()['items']==before
   rects={k:page.locator(sel).bounding_box() for k,sel in [('media','#mediaPanel'),('preview','.preview'),('inspector','#inspectorPanel'),('timeline','#timeline')]}
   for r in rects.values():assert r and r['width']>=30 and r['height']>=30 and r['x']>=0 and r['x']+r['width']<=1367 and r['y']+r['height']<=769,(layout,rects)
   a=rects['preview'];t=rects['timeline']
   assert a['y']+a['height']<=t['y']+1 or a['x']>=t['x']+t['width']-1,(layout,rects)
   if layout=='tall':assert a['height']>600
  page.locator('#play').click()
  # Pointer resizing does not recreate media or lose its width on collapse.
  handle=page.locator('[data-resize=media]');r=handle.bounding_box();old=page.locator('#mediaPanel').bounding_box()['width'];page.mouse.move(r['x']+2,r['y']+60);page.mouse.down();page.mouse.move(r['x']+42,r['y']+60,steps=10);page.mouse.up()
  width=page.locator('#mediaPanel').bounding_box()['width'];assert width>old+25
  page.locator('#collapseMedia').click();assert page.locator('#mediaPanel').bounding_box()['width']<45
  page.locator('#collapseMedia').click();assert abs(page.locator('#mediaPanel').bounding_box()['width']-width)<2
  # Static sales text is an editable real item, captions stay in the same editor.
  page.locator('[data-library=text]').click();page.locator('[data-sales-text=price]').click();assert state()['items'][-1]['text']=='CHỈ 99K'
  page.locator('[data-library=captions]').click();page.locator('[data-shared-caption=add]').click();assert any(i.get('subtitle') for i in state()['items'])
  page.locator('#tiktokPreview').click();assert page.locator('#tiktokOverlay').is_visible();assert 'tiktok' not in str(state()).lower()
  # A real local image and WAV must survive page closure/reopening with fresh blob URLs.
  raw=io.BytesIO();Image.new('RGB',(90,160),(140,20,100)).save(raw,format='PNG')
  page.locator('#file').set_input_files({'name':'saved-frame.png','mimeType':'image/png','buffer':raw.getvalue()})
  buf=io.BytesIO()
  with wave.open(buf,'wb') as wav:
   wav.setparams((1,2,48000,0,'NONE','not compressed'));wav.writeframes(b''.join(struct.pack('<h',int(800*math.sin(n*math.tau*440/48000))) for n in range(48000)))
  page.locator('#file').set_input_files({'name':'saved-audio.wav','mimeType':'audio/wav','buffer':buf.getvalue()})
  page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name==="saved-audio.wav")')
  with tempfile.TemporaryDirectory() as temp:
   fixture=Path(temp)/'saved-video.mp4'
   subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=teal:s=180x320:r=24:d=1','-c:v','libx264','-pix_fmt','yuv420p',str(fixture)],check=True)
   page.locator('#file').set_input_files({'name':fixture.name,'mimeType':'video/mp4','buffer':fixture.read_bytes()})
   page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name==="saved-video.mp4")')
  audio=next(a for a in state()['assets'] if a['name']=='saved-audio.wav');item=next(i for i in state()['items'] if i.get('assetId')==audio['id'])
  page.locator('[data-item="'+item['id']+'"]').click();page.locator('[data-inspector-tab=audio]').click();page.locator('#editorGainDb').fill('20');page.locator('#editorGainDb').press('Tab')
  assert abs(next(i for i in state()['items'] if i['id']==item['id'])['volume']-10)<.001
  page.locator('[data-audio-view=effects]').click();assert page.locator('#audioEffectsControls').is_visible()
  page.locator('[data-audio-view=basic]').click();assert page.locator('#editorGainDb').is_visible()
  try:page.wait_for_function('document.querySelector("#editorSaveStatus").dataset.state==="saved"')
  except Exception:
   print('DRAFT DIAGNOSTIC',page.locator('#editorSaveStatus').inner_text(),page.locator('#editorSaveStatus').get_attribute('title'),[{k:a.get(k) for k in ['id','name','missing']} for a in state()['assets']],errors,flush=True);raise
  before=state()['items'];page.screenshot(path='/tmp/sceneforge-workbench-audio.png')
  # Do not leave a dirty beforeunload prompt while restoring.
  page.reload();page.locator('#restoreDraft').click();page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name==="saved-audio.wav"&&!a.missing)')
  assert state()['items']==before
  media=page.evaluate('''async()=>{const assets=SceneForgeEditor.getState().assets;const image=[...document.querySelectorAll('#stageLayers img')].find(n=>n.src.startsWith('blob:'));const audio=[...document.querySelectorAll('#stageLayers audio')].find(n=>n.src.startsWith('blob:'));await Promise.all([image.decode(),new Promise((res,rej)=>{if(audio.readyState>=1)return res();audio.addEventListener('loadedmetadata',res,{once:true});audio.addEventListener('error',rej,{once:true})})]);const video=[...document.querySelectorAll('#stageLayers video')].find(n=>n.src.startsWith('blob:'));await new Promise((res,rej)=>{if(video.readyState>=2)return res();video.addEventListener('loadeddata',res,{once:true});video.addEventListener('error',rej,{once:true})});return{imageWidth:image.naturalWidth,audioDuration:audio.duration,videoWidth:video.videoWidth,videoDuration:video.duration};}''')
  assert media['imageWidth']==90 and .99<media['audioDuration']<1.01 and media['videoWidth']==180 and .99<media['videoDuration']<1.01,media
  page.locator('#editorLayoutButton').click();page.locator('#resetEditorLayout').click();page.screenshot(path='/tmp/sceneforge-workbench-design.png')
  assert not errors,errors
  print('PASS: four layouts retain live video/model; laptop bounds, pointer resizing/collapse, four libraries, real sales text/captions, preview-only TikTok, +20dB gain and retained EQ, atomic IndexedDB roundtrip with decodable video/image/WAV.')
  b.close()
finally:server.shutdown()
