"""Publish the existing multi-track browser editor with shared caption/effect tools."""
from pathlib import Path
import json
import shutil
root=Path(__file__).resolve().parents[2]
source=Path(__file__).resolve().parent
legacy=root/'scripts/demo-lite'
out=root/'dist/web-demo/native'
preview=(root/'preview.html').read_text()
marker='const DEMO_FRAMES='
frames,_=json.JSONDecoder().raw_decode(preview[preview.index(marker)+len(marker):])
marker='const DEMO_VIDEO='
video,_=json.JSONDecoder().raw_decode(preview[preview.index(marker)+len(marker):])
app=(legacy/'app.js').read_text()
extensions='\n'.join((legacy/name).read_text() for name in ['enhancements.js','timeline_modes.js','interface.js','workstation.js','studio_panels.js','reference_chrome.js'])
extensions=extensions.replace('return { linkGroup:"",','return { subtitle:false,effectTag:"",linkGroup:"",',1)
extensions+='\n'+(source/'editor-integration.js').read_text()+'\n'+(source/'timeline-interactions.js').read_text()+'\n'+(source/'editing-controls.js').read_text()+'\n'+(source/'workflow-import.js').read_text()+'\n'+(source/'editor-storage.js').read_text()+'\n'+(source/'editor-workbench.js').read_text()+'\n'+(source/'editor-design-panels.js').read_text()+'\n'+(source/'room-shell.js').read_text()+'\n'+(source/'package5.js').read_text()+'\n'+(source/'ffmpeg-export.js').read_text()+'\n'+(source/'timeline-export.js').read_text()
# Await local finishing before publishing the final file to the room/download hooks.
export_line=next(line for line in extensions.splitlines()if 'downloadBlob((($("#editorExportName")'in line)
name_expr=export_line.strip()[len('downloadBlob('):-len(', blob);')]
extensions=extensions.replace(export_line,'    const finished=await completeExportFile('+name_expr+',blob);blob=finished.blob;downloadBlob(finished.name,blob);')
extensions=extensions.replace('    await settleMedia();','    await settleMedia();\n    await document.fonts.ready;')
extensions=extensions.replace('c.captureStream(24)','c.captureStream(Number($("#exportFrameRate")?.value)||30)')
extensions=extensions.replace('if (recording && document.hidden)', 'if (recording && !timelineExportBusy && document.hidden)')
app=app.replace('/*__EXTENSIONS__*/',extensions).replace('localStorage.getItem("sceneforge-editor-draft-v2")','localStorage.getItem(editorDraftMetaKey())').replace('localStorage.setItem("sceneforge-editor-draft-v2",','localStorage.setItem(editorDraftMetaKey(),').replace('  detectDraft();','  detectDraft();\n  bootSharedEditor();')
css='\n'.join((legacy/name).read_text() for name in ['style.css','reference_skin.css','screenshot_skin.css'])+'\n'+(source/'editor-integration.css').read_text()+'\n'+(source/'editor-workbench.css').read_text()+'\n'+(source/'editor-design-panels.css').read_text()
font_out=root/'dist/web-demo/fonts';font_out.mkdir(exist_ok=True)
for name in ('SceneForgeSans.ttf','LICENSE.txt'):shutil.copy2(root/'editor/public/fonts'/name,font_out/name)
css+='\n@font-face{font-family:SceneForgeSans;src:url(../fonts/SceneForgeSans.ttf) format("truetype");font-display:swap}'
html=(legacy/'template.html').read_text().replace('__FRAMES__',json.dumps(frames)).replace('__VIDEO__',json.dumps(video)).replace('__CSS__',css).replace('__JS__',app)
# Preserve the former single-video prototype as a non-default diagnostic artifact.
if (out/'index.html').exists():(out/'single-video.html').write_bytes((out/'index.html').read_bytes())
(out/'index.html').write_text(html)
print('Built multi-track workspace:',out/'index.html')
