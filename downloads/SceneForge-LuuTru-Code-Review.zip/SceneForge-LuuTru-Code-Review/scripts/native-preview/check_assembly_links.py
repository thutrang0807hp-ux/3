"""Check linked media edits and reversible assembly using actual UI gestures."""
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/demo-lite'))
from browser_controls import controls
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1536,'height':1040});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()));page.goto('http://demo.test/')
 q=controls(page);state=lambda:page.evaluate('SceneForgeEditor.getState()')
 first=state()['items'][0];q('#extractAudio').click();s=state();video=next(i for i in s['items'] if i['id']==first['id']);audio=next(i for i in s['items'] if i['kind']=='audio')
 assert video['linkGroup']==audio['linkGroup'] and video['linkGroup'] and video['volume']==0 and audio['volume']==1
 page.locator('[data-item="'+video['id']+'"]').click();assert set(state()['selectedIds'])=={video['id'],audio['id']}
 r=page.locator('[data-item="'+video['id']+'"]').bounding_box()
 page.mouse.move(r['x']+30,r['y']+35);page.mouse.down();page.mouse.move(r['x']+r['width']*1.8,r['y']+35,steps=12);page.mouse.up()
 moved=[i for i in state()['items'] if i['id'] in [video['id'],audio['id']]];assert all(i['start']==4 for i in moved) and abs(moved[0]['start']-moved[1]['start'])<.001
 q('#undo').click()
 # Trim one visible edge changes both sources by the same amount.
 r=page.locator('[data-item="'+video['id']+'"]').bounding_box();page.mouse.move(r['x']+r['width']-3,r['y']+r['height']-10);page.mouse.down();page.mouse.move(r['x']+r['width']-34,r['y']+r['height']-10,steps=10);page.mouse.up()
 pair=[i for i in state()['items'] if i['linkGroup']==video['linkGroup']];assert len(pair)==2 and all(i['duration']<4 for i in pair) and abs(pair[0]['duration']-pair[1]['duration'])<.001
 q('#undo').click()
 page.evaluate('SceneForgeEditor.seek(2)');page.locator('[data-item="'+video['id']+'"]').click();q('#split').click()
 pairs={}
 for i in state()['items']:
  if i['linkGroup']:pairs.setdefault(i['linkGroup'],[]).append(i)
 assert len(pairs)==2 and all(len(v)==2 for v in pairs.values())
 assert all(v[0]['start']==v[1]['start'] and v[0]['duration']==v[1]['duration'] for v in pairs.values())
 q('#undo').click();page.locator('[data-item="'+video['id']+'"]').click();page.locator('#unlinkClips').click();assert all(not i['linkGroup'] for i in state()['items'])
 q('#undo').click()
 # Assembly order is reviewed in a dialog and the linked sound follows its picture.
 before=state();page.locator('#autoAssemble').click();page.locator('[data-assembly-down="0"]').click();page.locator('#assemblyDuration').fill('0.8');page.locator('[data-assembly-apply]').click()
 s=state();videos=sorted([i for i in s['items'] if i['kind']=='video'],key=lambda i:i['start']);assert len({i['trackId'] for i in videos})==1 and videos[1]['id']==first['id']
 assert [i['start'] for i in videos]==[0,4,8] and videos[-1]['transition']=='none' and all(i['transition']=='dissolve' for i in videos[:-1])
 audio=next(i for i in s['items'] if i['kind']=='audio');assert audio['start']==4 and audio['linkGroup']==videos[1]['linkGroup']
 q('#undo').click();assert state()['items']==before['items'] and state()['tracks']==before['tracks']
 assert not errors,errors
 print('PASS: extracted sound linked, grouped selection/move/trim, independent link groups after splitting, unlink/undo, reorder-and-assemble with linked audio, single undo restores all source tracks.')
 b.close()
