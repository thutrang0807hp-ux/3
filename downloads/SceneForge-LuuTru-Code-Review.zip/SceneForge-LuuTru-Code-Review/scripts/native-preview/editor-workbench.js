// SceneForge workbench, independently implemented from the supplied design brief.
const workbenchLayouts=[['default','Mặc định'],['left','Khung xem bên trái'],['right','Khung xem bên phải'],['tall','Khung xem cao hết']];
let workbenchPrefs={layout:'default',name:'Bản dựng của tôi'};
try{Object.assign(workbenchPrefs,JSON.parse(localStorage.getItem('sceneforge-workbench-v1')||'{}'));}catch{}
if(!workbenchLayouts.some(([key])=>key===workbenchPrefs.layout))workbenchPrefs.layout='default';
function saveWorkbenchPrefs(){try{localStorage.setItem('sceneforge-workbench-v1',JSON.stringify(workbenchPrefs));}catch{}}
const brand=document.createElement('div');brand.id='editorBrand';brand.innerHTML='<button id="editorStudioHome" title="Về tổng quan">SceneForge</button><nav aria-label="Không gian làm việc"><button id="backToCreate">Tạo video</button><button class="active" aria-current="page">Dựng</button></nav>';
$('header').prepend(brand);
$('#editorStudioHome').onclick=()=>{pause();if(parent!==window)parent.postMessage({type:'sceneforge:editor-navigate',view:'overview'},location.origin);else location.href='../#overview';};
$('#backToCreate').onclick=()=>{pause();if(parent!==window)parent.postMessage({type:'sceneforge:editor-navigate',view:'analysis'},location.origin);else location.href='../#analysis';};
const projectTitle=document.createElement('div');projectTitle.id='editorProjectTitle';projectTitle.innerHTML='<input id="editorProjectName" maxlength="80" aria-label="Tên bản dựng"><span id="editorSaveStatus" role="status" data-state="idle">Chưa có thay đổi</span>';$('header').append(projectTitle);
$('#editorProjectName').value=workbenchPrefs.name;$('#editorProjectName').onchange=e=>{workbenchPrefs.name=e.target.value.trim()||'Bản dựng của tôi';e.target.value=workbenchPrefs.name;saveWorkbenchPrefs();};
const layoutButton=document.createElement('button');layoutButton.id='editorLayoutButton';layoutButton.innerHTML=uiIcon('grid')+'<span>Bố cục</span>';layoutButton.setAttribute('aria-expanded','false');$('.actions').insertBefore(layoutButton,$('#export'));
const layoutMenu=document.createElement('div');layoutMenu.id='editorLayoutMenu';layoutMenu.hidden=true;layoutMenu.innerHTML='<b>Bố cục làm việc</b><div class="layoutChoices">'+workbenchLayouts.map(([key,name])=>'<button data-editor-layout="'+key+'"><span class="layoutDiagram '+key+'"><i></i><i></i><i></i><i></i></span><span>'+name+'</span></button>').join('')+'</div><button id="resetEditorLayout">↺ Đặt lại kích thước các vùng</button>';document.body.append(layoutMenu);
function applyWorkbenchLayout(key){document.body.dataset.editorLayout=key;document.body.dataset.panelOrder='left';document.body.dataset.workspaceView='balanced';workbenchPrefs.layout=key;saveWorkbenchPrefs();$$('[data-editor-layout]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.editorLayout===key)));requestAnimationFrame(fitStage);}
layoutButton.onclick=()=>{layoutMenu.hidden=!layoutMenu.hidden;layoutButton.setAttribute('aria-expanded',String(!layoutMenu.hidden));};
layoutMenu.onclick=e=>{const b=e.target.closest('[data-editor-layout]');if(b){applyWorkbenchLayout(b.dataset.editorLayout);layoutMenu.hidden=true;layoutButton.setAttribute('aria-expanded','false');}};
$('#resetEditorLayout').onclick=()=>{for(const key of ['media','inspector','timeline'])document.body.style.removeProperty('--'+key);document.body.classList.remove('media-collapsed','inspector-collapsed');applyWorkbenchLayout('default');saveWorkspacePreferences();layoutMenu.hidden=true;layoutButton.setAttribute('aria-expanded','false');};
document.addEventListener('pointerdown',e=>{if(!e.target.closest('#editorLayoutMenu,#editorLayoutButton')){layoutMenu.hidden=true;layoutButton.setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){layoutMenu.hidden=true;layoutButton.setAttribute('aria-expanded','false');}});
applyWorkbenchLayout(workbenchPrefs.layout);
// Four visible library groups; all editing remains in this one workspace.
const captionsTool=document.createElement('button');captionsTool.dataset.library='captions';captionsTool.innerHTML=uiIcon('captions')+'<small>Phụ đề</small>';captionsTool.setAttribute('aria-label','Phụ đề');$('#creativeToolbar nav').append(captionsTool);
for(const [key,name]of [['media','Tư liệu'],['text','Chữ'],['transitions','Chuyển cảnh']])$('[data-library="'+key+'"] small').textContent=name;
const salesTextPresets=[['price','Giá tiền','CHỈ 99K','#ffdc45',88],['sale','Giảm giá','GIẢM 30%','#ff625d',80],['cta','Mua ngay','MUA NGAY','#ffffff',68],['shipping','Freeship','MIỄN PHÍ VẬN CHUYỂN','#a5f3d7',48],['flash','Flash sale','FLASH SALE','#ffdc45',76],['limited','Số lượng có hạn','CHỈ CÒN 10 SUẤT','#ffffff',60],['basket','Bấm giỏ hàng','BẤM GIỎ HÀNG ↓','#ffffff',56]];
const showBeforeWorkbench=showLibrary;
showLibrary=function(kind){
 if(kind==='text'){
  showSharedLibrary('text');$('#creativeLibrary').innerHTML='<div class="paletteIntro"><b>Chữ cho video của bạn</b><p>Thêm vào vạch phát, rồi sửa trực tiếp ở bảng bên phải.</p></div><button id="palettePlainText" class="largeAddText">'+uiIcon('text')+' Thêm văn bản</button><h4 class="librarySectionTitle">Mẫu bán hàng</h4><div class="salesTextGrid">'+salesTextPresets.map(([id,name,text,color])=>'<button data-sales-text="'+id+'"><span style="color:'+color+'">'+text+'</span><small>'+name+'</small></button>').join('')+'</div>';return;
 }
 showBeforeWorkbench(kind==='captions'?'text':kind);
 if(kind==='captions'){libraryTab='captions';$$('[data-library]').forEach(b=>b.classList.toggle('active',b.dataset.library==='captions'));$('#creativeLibrary .paletteIntro b').textContent='Phụ đề trên timeline';$('#creativeLibrary .paletteIntro p').textContent='Nhập SRT/VTT hoặc thêm từng câu. Tất cả nằm chung với video và âm thanh.';$('#palettePlainText')?.remove();}
};
$('#creativeLibrary').addEventListener('click',e=>{const b=e.target.closest('[data-sales-text]');if(!b)return;const p=salesTextPresets.find(p=>p[0]===b.dataset.salesText);if(!p)return;addText();Object.assign(selected(),{text:p[2],name:p[1],color:p[3],fontSize:p[4],bold:true,textY:72,textBg:['cta','limited','basket'].includes(p[0]),background:'#172025',outline:2});render();switchInspectorTab('style');});
// Keep type filters beside the content rather than a second navigation rail.
const mediaFilters=$('#mediaTabs');$('.assetSearch').after(mediaFilters);
const mediaRenderBeforeWorkbench=renderAssets;
renderAssets=function(){mediaRenderBeforeWorkbench();for(const card of $$('#assets [data-asset]')){const a=getAsset(card.dataset.asset);if(items.some(i=>i.assetId===a.id)){const used=document.createElement('span');used.className='assetUsed';used.textContent='✓';used.title='Đã dùng trong timeline';card.append(used);}card.classList.toggle('missingAsset',!!a.missing);}};
const timelineBeforeWorkbench=timeline;
timeline=function(){timelineBeforeWorkbench();for(const row of $$('#tracks>.trackRow')){const track=getTrack(row.dataset.track),content=items.filter(i=>i.trackId===track.id);row.dataset.role=track.kind==='text'?(content.some(i=>i.subtitle)?'captions':'text'):track.kind==='audio'?(/giọng|voice/i.test(track.name)?'voice':'music'):'video';if(!track.height)row.style.setProperty('--lane-height',({video:68,text:45,audio:54}[track.kind])+'px');}for(const card of $$('#assets [data-asset]'))card.classList.toggle('inTimeline',items.some(i=>i.assetId===card.dataset.asset));};
// Thin timeline toolbar. Hidden modes remain readable in old projects.
for(const option of $$('#timelineEditMode option'))if(!['insert','overwrite'].includes(option.value)){option.hidden=true;option.disabled=true;}
const timelineDecorateBeforeWorkbench=decorateTimelineControls;
decorateTimelineControls=function(){timelineDecorateBeforeWorkbench();decorateButton('split','split','Tách clip · Ctrl+B');};
const mode=$('#timelineEditMode');$('.toolbar .grow').after(mode);$('#newTrack').before($('#snap'),$('#autoAssemble'));
const sequenceLabel=$('.sequenceHead>span:nth-child(2)');if(sequenceLabel)sequenceLabel.textContent='Kéo clip lên khoảng trống để thêm hàng';
const transportDecorateBeforeWorkbench=decorateTransport;
decorateTransport=function(){decorateButton('play',playing?'pause':'play',playing?'Tạm dừng · Space':'Phát video · Space');};
// Preview-only social safe zones. Canvas export reads the media model, never this DOM.
const socialToggle=document.createElement('button');socialToggle.id='tiktokPreview';socialToggle.textContent='TikTok';socialToggle.title='Xem vùng bị che bởi giao diện TikTok (không xuất vào video)';socialToggle.setAttribute('aria-pressed','false');$('.transport').insertBefore(socialToggle,$('#fullscreen'));
const socialOverlay=document.createElement('div');socialOverlay.id='tiktokOverlay';socialOverlay.hidden=true;socialOverlay.innerHTML='<div class="socialTop">Dành cho bạn</div><div class="socialSide">♡<small>Thích</small>☏<small>Bình luận</small>↗<small>Chia sẻ</small></div><div class="socialBottom"><b>@video_cua_ban</b><p>Chú thích video hiển thị ở đây…</p><span>Trang chủ　 Bạn bè　 ＋　 Hộp thư</span></div>';$('#stage').append(socialOverlay);
socialToggle.onclick=()=>{socialOverlay.hidden=!socialOverlay.hidden;socialToggle.setAttribute('aria-pressed',String(!socialOverlay.hidden));};
$('#stageLayers').addEventListener('click',e=>{if(e.target.closest('[data-text-item]'))return;const candidate=[...items].reverse().find(i=>['video','image'].includes(i.kind)&&clipActive(i)&&!getTrack(i.trackId).hidden);if(candidate)choose(candidate.id);});
// Resize uses one paint per display frame and never recreates a media element.
for(const handle of $$('[data-resize],#timelineResize'))handle.addEventListener('pointerdown',e=>{
 if(e.button!==0)return;e.preventDefault();e.stopImmediatePropagation();const rect=(handle.id==='timelineResize'?$('#timeline'):$(handle.dataset.resize==='media'?'#mediaPanel':'#inspectorPanel')).getBoundingClientRect();
 const key=handle.id==='timelineResize'?'timeline':handle.dataset.resize,initial=key==='timeline'?rect.height:rect.width,x=e.clientX,y=e.clientY;let frame=0,pending=null;
 const paint=()=>{frame=0;if(!pending)return;let value;if(key==='timeline')value=clamp(initial+y-pending.clientY,200,innerHeight*.62);else{const reverse=key==='inspector'||(key==='media'&&workbenchPrefs.layout==='left');value=clamp(initial+(pending.clientX-x)*(reverse?-1:1),key==='media'?210:245,Math.min(460,innerWidth*.36));}document.body.style.setProperty('--'+key,value+'px');};
 const move=v=>{pending=v;if(!frame)frame=requestAnimationFrame(paint);};
 const finish=()=>{if(frame){cancelAnimationFrame(frame);paint();}handle.removeEventListener('pointermove',move);handle.removeEventListener('pointerup',finish);handle.removeEventListener('pointercancel',finish);saveWorkspacePreferences();};
 handle.setPointerCapture(e.pointerId);handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',finish);handle.addEventListener('pointercancel',finish);
},true);
// Audio retains its existing effects panel; essentials open first.
const inspectorBeforeWorkbench=inspector;
inspector=function(){inspectorBeforeWorkbench();const i=selected();if(!i)return;const pane=$('[data-inspector-pane=audio]');if(!pane)return;const fx=pane.querySelector('[data-audio-view=effects]');if(fx)fx.textContent='EQ & nâng cao';const basic=pane.querySelector('#audioBasicControls');if(basic&&['audio','video'].includes(i.kind)){
 const field=document.createElement('label');field.className='gainDbField';field.innerHTML='<span>Âm lượng <small>dB</small></span><input id="editorGainRange" aria-label="Âm lượng dB" type="range" min="-60" max="26" step="0.5"><input id="editorGainDb" aria-label="Giá trị âm lượng dB" type="number" min="-60" max="26" step="0.5"><button id="editorGainReset" title="Đặt lại âm lượng">↺</button>';
 const db=i.volume>0?Math.max(-60,20*Math.log10(i.volume)):-60;for(const n of field.querySelectorAll('input'))n.value=db.toFixed(1);const old=basic.querySelector('#prop-volume')?.closest('.field');if(old)old.hidden=true;basic.prepend(field);
 let begun=false;const change=e=>{if(getTrack(i.trackId).locked||recording)return;if(!begun){remember();begun=true;}const db=clamp(Number(e.target.value)||0,-60,26);i.volume=db<=-60?0:Math.min(20,10**(db/20));updateKeyframedProp(i,'volume',i.volume);for(const n of field.querySelectorAll('input'))if(n!==e.target)n.value=db.toFixed(1);updateStage();updateMiniAudio();};
 for(const n of field.querySelectorAll('input')){n.oninput=change;n.onchange=()=>{begun=false;scheduleDraft();};n.disabled=!!getTrack(i.trackId).locked;}
 field.querySelector('button').onclick=()=>{if(!allowEdit())return;transact(()=>i.volume=1);};
 }};
// Portrait-only deliverable. Keep old aspect code out of the visible flow.
const bootBeforeWorkbench=bootSharedEditor;
bootSharedEditor=function(){bootBeforeWorkbench();showLibrary('media');decorateTimelineControls();decorateTransport();if(draftCandidate)$('#restoreDraft').hidden=false;};
const importBeforeWorkbench=importFile;
importFile=async function(...args){const asset=await importBeforeWorkbench(...args);if(asset)scheduleDraft();return asset;};
// Keep precise timing available below the everyday framing controls.
for(const kind of ['video','image','audio','text'])collapsedInspectorGroups.add(kind+':Thời gian');
const inspectorWorkbenchFinal=inspector;
inspector=function(){inspectorWorkbenchFinal();const pane=$('[data-inspector-pane=basic]');if(!pane||selected()?.kind==='text')return;for(const label of ['Tốc độ','Thời gian']){const title=[...pane.querySelectorAll('.referenceGroupToggle')].find(n=>n.textContent===label);if(!title)continue;const heading=title.closest('.referenceSection'),group=heading.nextElementSibling;if(group?.classList.contains('referenceGroup'))pane.append(heading,group);}};
const miniBeforeWorkbench=updateMiniAudio;
updateMiniAudio=function(){miniBeforeWorkbench();const i=selected();if(!i)return;const db=i.volume>0?Math.max(-60,20*Math.log10(i.volume)):-60;for(const input of $$('#editorGainRange,#editorGainDb'))if(document.activeElement!==input)input.value=db.toFixed(1);};
validFrame=function(){return{width:1080,height:1920};};
