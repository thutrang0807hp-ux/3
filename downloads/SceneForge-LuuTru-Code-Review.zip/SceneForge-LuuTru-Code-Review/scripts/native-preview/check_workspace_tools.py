"""Regression for the archived single-video tools; current editor uses check_full_workspace.py."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist')))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1536,'height':1024});errors=[]
  page.on('pageerror',lambda error:errors.append(str(error)))
  page.goto(f'http://127.0.0.1:{server.server_port}/web-demo/native/single-video.html',wait_until='networkidle')
  page.wait_for_function('document.querySelector("#captionVideo").readyState>=2')
  page.evaluate('window.toolVideo=document.querySelector("#captionVideo");window.toolTimeline=document.querySelector("#captionTimeline");window.toolVideo.play()')
  for key in ['media','text','stickers','transitions','effects','filters','templates','audio']:
   page.locator(f'[data-workspace-tool={key}]').click()
   expect(page.locator(f'[data-tool-panel={key}]')).to_be_visible()
   assert page.evaluate('window.toolVideo===document.querySelector("#captionVideo")&&window.toolTimeline===document.querySelector("#captionTimeline")&&!window.toolVideo.paused')
  page.locator('#toolAudioVolume').evaluate('(i)=>{i.value=35;i.dispatchEvent(new Event("input"));}')
  assert page.locator('#captionVideo').evaluate('(v)=>v.volume')==.35
  page.locator('#toolAudioMuted').check();assert page.locator('#captionVideo').evaluate('(v)=>v.muted')
  page.locator('#toolPlaybackRate').select_option('1.5');assert page.locator('#captionVideo').evaluate('(v)=>v.playbackRate')==1.5
  page.locator('#captionVideo').evaluate('(v)=>v.pause()')
  page.locator('[data-workspace-tool=filters]').click();page.locator('[data-preview-filter=mono]').click()
  assert 'grayscale(1)' in page.locator('#captionVideo').evaluate('(v)=>v.style.filter')
  page.locator('[data-workspace-tool=effects]').click();page.locator('#effectBrightness').evaluate('(i)=>{i.value=150;i.dispatchEvent(new Event("input"));}')
  assert 'brightness(1.5)' in page.locator('#captionVideo').evaluate('(v)=>v.style.filter')
  page.locator('[data-workspace-tool=stickers]').click();page.locator('[data-sticker="⭐"]').click()
  expect(page.locator('#previewSticker')).to_be_visible();expect(page.locator('#previewSticker')).to_have_text('⭐')
  page.locator('[data-sticker=""]').click();expect(page.locator('#previewSticker')).to_be_hidden()
  page.locator('[data-workspace-tool=transitions]').click();page.locator('[data-transition-demo=fade]').click()
  expect(page.locator('#captionFeedback')).to_contain_text('chưa áp dụng')
  page.locator('[data-workspace-tool=templates]').click();page.locator('[data-caption-template=bold]').click()
  expect(page.locator('[data-caption-preset=bold]')).to_have_attribute('aria-pressed','true')
  page.locator('#captionSubtitleTrack button[data-cue="0"]').click()
  page.locator('#captionVideo').evaluate('(v)=>v.currentTime=1')
  expect(page.locator('#timelineSplit')).to_be_enabled();page.locator('#timelineSplit').click()
  expect(page.locator('#captionCount')).to_have_text('4')
  expect(page.get_by_role('spinbutton',name='Kết thúc câu 1',exact=True)).to_have_value('1')
  expect(page.get_by_role('spinbutton',name='Bắt đầu câu 2',exact=True)).to_have_value('1')
  page.locator('#timelineUndo').click();expect(page.locator('#captionCount')).to_have_text('3')
  page.locator('#timelineRedo').click();expect(page.locator('#captionCount')).to_have_text('4')
  page.locator('#timelineDelete').click();expect(page.locator('#captionCount')).to_have_text('3')
  page.locator('#timelineUndo').click();expect(page.locator('#captionCount')).to_have_text('4')
  srt='1\n00:00:00,000 --> 00:00:01,000\nMột\n\n2\n00:00:04,000 --> 00:00:05,000\nHai\n'
  page.locator('#captionTextFile').set_input_files({'name':'gap.srt','mimeType':'text/plain','buffer':srt.encode()})
  page.locator('#captionSubtitleTrack button[data-cue="0"]').click();page.locator('#timelineDuplicate').click()
  expect(page.locator('#captionCount')).to_have_text('3')
  expect(page.get_by_role('spinbutton',name='Bắt đầu câu 2',exact=True)).to_have_value('1')
  page.locator('#captionTimelineZoom').evaluate('(i)=>{i.value=3;i.dispatchEvent(new Event("input"));}')
  page.locator('#timelineFit').click();expect(page.locator('#captionTimelineZoom')).to_have_value('1')
  page.screenshot(path='/tmp/sceneforge-restored-tools.png',full_page=True)
  page.set_viewport_size({'width':390,'height':844})
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  page.locator('[data-workspace-tool=audio]').click();expect(page.locator('[data-tool-panel=audio]')).to_be_visible()
  assert not errors,errors
  browser.close()
 print('PASS: all eight tools keep the same playing video/timeline; audio, filters, effects, sticker preview, transition sample, text templates; caption split/undo/redo/delete/duplicate and fit; mobile width.')
finally:server.shutdown();server.server_close();thread.join()
