"""Exercise real pointer gestures and verify dissolve pixels in preview/export."""
from pathlib import Path
import sys,json,io,subprocess
from PIL import Image
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/demo-lite'))
from browser_controls import controls
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1536,'height':1040},accept_downloads=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()))
 page.goto('http://demo.test/');q=controls(page);state=lambda:page.evaluate('SceneForgeEditor.getState()')
 clips=state()['items'];boxes=[page.locator('[data-item="'+i['id']+'"]').bounding_box() for i in clips]
 def marquee(x,y,xx,yy,shift=False):
  if shift:page.keyboard.down('Shift')
  page.mouse.move(x,y);page.mouse.down();page.mouse.move(xx,yy,steps=12);page.wait_for_timeout(50);page.mouse.up();page.wait_for_timeout(60)
  if shift:page.keyboard.up('Shift')
 a,z=boxes[0],boxes[2]
 marquee(z['x']+z['width']+20,z['y']+z['height']+4,a['x']+15,a['y']+30)
 assert set(state()['selectedIds'])=={i['id'] for i in clips},state()['selectedIds']
 # Shift toggles just the third clip out of the selected rectangle.
 marquee(z['x']+z['width']+15,z['y']+z['height']+4,z['x']+20,z['y']+30,True)
 assert set(state()['selectedIds'])=={i['id'] for i in clips[:2]}
 before=state();r=page.locator('[data-item="'+clips[0]['id']+'"]').bounding_box()
 page.mouse.move(r['x']+30,r['y']+35);page.mouse.down();page.mouse.move(r['x']+100,r['y']+35,steps=8);page.wait_for_timeout(50);page.keyboard.press('Escape');page.mouse.up()
 assert state()['items']==before['items'] and state()['tracks']==before['tracks']
 # Lock excludes items from region selection.
 page.locator('[data-track-action=lock][data-id=v1]').click()
 marquee(z['x']+z['width']+20,z['y']+z['height']+4,a['x']+15,a['y']+30)
 assert not state()['selectedIds']
 page.locator('[data-track-action=lock][data-id=v1]').click()
 # Click + creates an actual dissolve at a real cut.
 page.locator('[data-join="'+clips[0]['id']+'"]').click()
 assert state()['items'][0]['transition']=='dissolve'
 block=page.locator('[data-join="'+clips[0]['id']+'"]').bounding_box();initial=state()['items'][0]['transitionDuration']
 page.mouse.move(block['x']+block['width']-2,block['y']+12);page.mouse.down();page.mouse.move(block['x']+block['width']+25,block['y']+12,steps=10);page.mouse.up()
 assert state()['items'][0]['transitionDuration']>initial
 page.locator('#undo').click();assert state()['items'][0]['transitionDuration']==initial
 page.locator('[data-join="'+clips[0]['id']+'"] .joinLabel').click();page.keyboard.press('Delete');assert state()['items'][0]['transition']=='none' and len(state()['items'])==3
 page.locator('#undo').click();assert state()['items'][0]['transition']=='dissolve'
 # Drag a palette template into the second cut.
 page.locator('[data-library=transitions]').click()
 page.locator('[data-palette-transition=wipe]').drag_to(page.locator('[data-join="'+clips[1]['id']+'"]'))
 assert state()['items'][1]['transition']=='wipe'
 # Rolling trim keeps the end of the second clip fixed and advances source-in.
 page.evaluate("document.querySelector('#rollingTrim').click()");left=state()['items'][0];right=state()['items'][1]
 r=page.locator('[data-item="'+left['id']+'"]').bounding_box()
 page.mouse.move(r['x']+r['width']-3,r['y']+r['height']-12);page.mouse.down();page.mouse.move(r['x']+r['width']+28,r['y']+r['height']-12,steps=10);page.mouse.up()
 aa=next(i for i in state()['items'] if i['id']==left['id']);bb=next(i for i in state()['items'] if i['id']==right['id'])
 assert aa['duration']>left['duration'] and abs(aa['start']+aa['duration']-bb['start'])<.001
 assert abs(bb['start']+bb['duration']-right['start']-right['duration'])<.001 and bb['mediaIn']>right['mediaIn']
 page.locator('#undo').click();page.evaluate("document.querySelector('#rollingTrim').click()")
 # Edge scrolling continues while the pointer is stationary; Escape restores the project.
 page.locator('#zoom').evaluate('(n)=>{n.value=160;n.dispatchEvent(new Event("input"))}')
 before=state();r=page.locator('[data-item="'+clips[0]['id']+'"]').bounding_box();bounds=page.locator('#timelineScroll').bounding_box()
 page.mouse.move(r['x']+30,r['y']+35);page.mouse.down();page.mouse.move(bounds['x']+bounds['width']-5,r['y']+35,steps=6)
 page.wait_for_timeout(80);scroll1=page.locator('#timelineScroll').evaluate('(n)=>n.scrollLeft');page.wait_for_timeout(150);scroll2=page.locator('#timelineScroll').evaluate('(n)=>n.scrollLeft');assert scroll2>scroll1,(scroll1,scroll2)
 page.keyboard.press('Escape');page.mouse.up();assert state()['items']==before['items']
 page.locator('#zoom').evaluate('(n)=>{n.value=62;n.dispatchEvent(new Event("input"))}');page.locator('#timelineScroll').evaluate('(n)=>n.scrollLeft=0')
 # Persist dissolve through a project round-trip; image sources make pixel evidence unambiguous.
 model=state();first=model['items'][0]
 model.update(format='sceneforge-timeline',version=1,tracks=[model['tracks'][0]],assets=[{'id':name,'name':name+'.png','kind':'image','duration':5}for name in ['red','blue']],items=[dict(first,id=name,assetId=name,kind='image',name=name,start=n*2,duration=2,mediaIn=0,transition='dissolve' if n==0 else 'none',transitionDuration=.8)for n,name in enumerate(['red','blue'])])
 page.locator('#projectFile').set_input_files({'name':'dissolve.json','mimeType':'application/json','buffer':json.dumps(model).encode()})
 page.wait_for_function('SceneForgeEditor.getState().items.length===2')
 for name,color in [('red',(255,0,0)),('blue',(0,0,255))]:
  buf=io.BytesIO();Image.new('RGB',(90,160),color).save(buf,format='PNG')
  page.locator('#file').set_input_files({'name':name+'.png','mimeType':'image/png','buffer':buf.getvalue()})
  page.wait_for_function('(id)=>!SceneForgeEditor.getState().assets.find(a=>a.id===id).missing',arg=name)
 page.evaluate('SceneForgeEditor.seek(2)');page.wait_for_timeout(120)
 assert page.locator('#stageLayers img').evaluate_all('(nodes)=>nodes.filter(n=>n.style.display!=="none").length')==2
 stage=Image.open(io.BytesIO(page.locator('#stage').screenshot())).convert('RGB');r,g,blue=stage.getpixel((stage.width//2,stage.height//2));assert r>100 and blue>100 and g<20,(r,g,blue)
 # Canvas PNG uses the same compositor as recording, and must contain both sources.
 with page.expect_download() as dl:page.evaluate("document.querySelector('#captureFrame').click()")
 png=Image.open(dl.value.path()).convert('RGB');r,g,blue=png.getpixel((png.width//2,png.height//2));assert r>100 and blue>100 and g<20,(r,g,blue)
 page.locator('#export').click()
 try:
  with page.expect_download(timeout=20000) as dl:page.locator('#realExport').click()
 except Exception:
  print('EXPORT DIAGNOSTIC:',page.locator('#exportStatus').inner_text(),errors,flush=True);raise
 out=Path('/tmp/sceneforge-dissolve.webm');dl.value.save_as(str(out));assert out.stat().st_size>2000
 # Decode an exported frame near the join: no dip to black, both inputs present.
 raw=subprocess.check_output(['ffmpeg','-v','error','-ss','2','-i',str(out),'-frames:v','1','-vf','scale=1:1','-f','rawvideo','-pix_fmt','rgb24','-'])
 r,g,blue=raw[:3];assert r>65 and blue>65 and g<25,(r,g,blue)
 page.locator('#closeExport').click();page.screenshot(path='/tmp/sceneforge-timeline-joins.png',full_page=True)
 assert not errors,errors
 print('PASS: rectangle/Shift selection, locked-track exclusion, Esc restores group drag, join add/resize/undo/delete, palette drop, project roundtrip, two visible sources and blended PNG/WebM pixels (no black dip).')
 b.close()
