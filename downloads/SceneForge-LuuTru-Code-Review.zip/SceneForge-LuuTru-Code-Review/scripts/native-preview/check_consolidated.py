"""Live local engine UI: FFmpeg, no MediaRecorder, captions, background, media restore."""
import json,os,socket,subprocess,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-consolidated-ui-')as td:
 with socket.socket()as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port)],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':td},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  for _ in range(100):
   try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/status');break
   except Exception:time.sleep(.1)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1366,'height':900},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{port}/native/index.html');page.wait_for_function('window.SceneForgeEditor?.getExportReadiness().directFfmpeg');
   source=page.evaluate('SceneForgeEditor.getState()');model={**source,'format':'sceneforge-timeline','version':1};model['items']=source['items'][:2]
   for n,row in enumerate(model['items']):row.update(start=n*1.2,duration=1.2,transition='dissolve'if n==0 else'none',transitionDuration=.5,audioMuted=True)
   template=dict(model['items'][0]);template.update(id='caption-test',kind='text',trackId='t1',text='Xin chào Việt Nam',subtitle=True,name='Phụ đề',start=0,duration=2.4,textAnimation='none',transition='none',textY=50,fontSize=80,fontFamily='SceneForgeSans');model['items'].append(template)
   music=dict(model['items'][0]);music.update(id='music-test',kind='audio',assetId='music',trackId='a1',start=0,duration=2.4,transition='none',audioMuted=False,volume=.5,mediaIn=0);model['items'].append(music)
   page.locator('#projectFile').set_input_files({'name':'timeline.json','mimeType':'application/json','buffer':json.dumps(model).encode()});page.wait_for_function('SceneForgeEditor.getState().items.length===4');page.wait_for_timeout(900)
   # If the renderer accidentally calls the browser recording path this test fails.
   page.evaluate("()=>{const supported=MediaRecorder.isTypeSupported.bind(MediaRecorder);window.MediaRecorder=class{static isTypeSupported(m){return supported(m)}constructor(){throw Error('TEST: browser recording forbidden')}};HTMLCanvasElement.prototype.captureStream=()=>{throw Error('TEST: canvas recording forbidden')}}")
   page.locator('#export').click();expect(page.locator('#timelineExportEngine')).to_have_value('ffmpeg');page.locator('#exportSize').select_option('720');page.locator('#exportSidecarSrt').check();page.screenshot(path='/tmp/sceneforge-consolidated-export.png',full_page=True)
   downloads=[];page.on('download',lambda d:downloads.append(d));page.locator('#realExport').click();page.wait_for_function('!!SceneForgeEditor.getExportReadiness().job',timeout=15000)
   page.locator('#closeExport').click();assert not page.locator('#exportDialog').is_visible();expect(page.locator('#timelineExportDock')).to_be_visible()
   page.evaluate("Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'))")
   page.wait_for_function('document.querySelector("#exportProgress").value===100',timeout=60000);page.wait_for_timeout(300)
   assert len(downloads)==2,[d.suggested_filename for d in downloads];mp4=next(d for d in downloads if d.suggested_filename.endswith('.mp4'));out=Path(td)/'ui.mp4';mp4.save_as(out)
   meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(out)]));v=next(s for s in meta['streams']if s['codec_type']=='video');assert (v['width'],v['height'])==(720,1280)and v['codec_name']=='h264';assert abs(float(meta['format']['duration'])-2.4)<.1;assert any(s['codec_name']=='aac'for s in meta['streams'])
   srt=next(d for d in downloads if d.suggested_filename.endswith('.srt'));assert 'Xin chào Việt Nam'in Path(srt.path()).read_text('utf-8-sig')
   # A genuinely imported source survives the atomic IndexedDB save/reload cycle.
   page.evaluate("delete document.hidden");page.locator('#file').set_input_files(str(out));page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name==="ui.mp4")');page.wait_for_function('document.querySelector("#editorSaveStatus").dataset.state==="saved"',timeout=15000)
   page.reload();page.wait_for_function('window.SceneForgeEditor');page.locator('#restoreDraft').click();page.wait_for_function('SceneForgeEditor.getState().assets.some(a=>a.name==="ui.mp4"&&!a.missing)')
   imported=next(i for i in page.evaluate('SceneForgeEditor.getState().items')if i['name']=='ui.mp4');page.evaluate('(t)=>SceneForgeEditor.seek(t)',imported['start']+.3);page.wait_for_function('Array.from(document.querySelectorAll("#stageLayers video")).some(v=>v.readyState>=2&&v.videoWidth===720)',timeout=15000)
   assert not errors,errors;b.close()
   print('PASS: live offline MP4 720×1280/H264/AAC + VI SRT; MediaRecorder/captureStream forbidden; close dialog/hidden page continues; imported media bytes restored and decoded after reload.')
 finally:proc.terminate();proc.wait(timeout=15)
