"""Reproducible pointer/RAF measurement, separate from correctness tests."""
from pathlib import Path
from functools import partial
import http.server,threading,json,time
from playwright.sync_api import sync_playwright
from fontTools.ttLib import TTFont
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start();results=[]
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1700,'height':1000});page.goto(f'http://127.0.0.1:{server.server_port}/native/index.html');page.wait_for_function('!!window.SceneForgeEditor');source=page.evaluate('SceneForgeEditor.getState()');template=source['items'][0]
  font=TTFont(root/'editor/public/fonts/SceneForgeSans.ttf');cmap=font.getBestCmap();assert all(ord(c)in cmap for c in 'Ữ ặ ỡ ợ ẫ')
  loaded=page.evaluate('''async()=>{await document.fonts.load('32px SceneForgeSans','Ữ ặ ỡ ợ ẫ');return document.fonts.check('32px SceneForgeSans','Ữ ặ ỡ ợ ẫ');}''');assert loaded
  for count in [3,30,100]:
   model=dict(source,format='sceneforge-timeline',version=1);model['tracks']=[{'id':'v1','kind':'video','name':'Video 1'},{'id':'v2','kind':'video','name':'Video 2'}];model['items']=[dict(template,id='bench-'+str(n),trackId='v1',start=n*2,duration=2,mediaIn=0,transition='none')for n in range(count)]
   page.locator('#projectFile').set_input_files({'name':'benchmark.json','mimeType':'application/json','buffer':json.dumps(model).encode()});page.wait_for_function('(n)=>SceneForgeEditor.getState().items.length===n',arg=count);page.wait_for_timeout(100)
   page.evaluate('''()=>{window.benchFrames=[];window.benchLong=[];window.benchOn=true;let last;const tick=t=>{if(last)benchFrames.push(t-last);last=t;if(benchOn)requestAnimationFrame(tick)};requestAnimationFrame(tick);window.benchObserver=new PerformanceObserver(l=>{for(const e of l.getEntries())benchLong.push(e.duration)});benchObserver.observe({entryTypes:['longtask']});}''')
   r=page.locator('[data-item=bench-0]').bounding_box();lane=page.locator('[data-lane=v2]').bounding_box();start=time.perf_counter();page.mouse.move(r['x']+25,r['y']+20);page.mouse.down()
   for step in range(48):page.mouse.move(r['x']+25+(step%12)*3,lane['y']+lane['height']/2 if step%16>7 else r['y']+20);page.wait_for_timeout(8)
   page.mouse.move(r['x']+25,lane['y']+lane['height']/2);page.mouse.up();elapsed=time.perf_counter()-start;page.wait_for_timeout(80)
   data=page.evaluate('''()=>{benchOn=false;benchObserver.disconnect();const a=benchFrames.sort((a,b)=>a-b);return{samples:a.length,median_ms:a[Math.floor(a.length/2)],p95_ms:a[Math.floor(a.length*.95)],max_ms:a.at(-1),longtasks:benchLong.length,max_longtask_ms:Math.max(0,...benchLong),track:SceneForgeEditor.getState().items.find(i=>i.id==='bench-0').trackId}}''');assert data.pop('track')=='v2',data;data.update(clips=count,gesture_seconds=round(elapsed,3));results.append(data)
  b.close()
 report={'environment':'Linux Chromium headless; synthetic pointer drag across two tracks; same sample assets. Not a Windows or heavy-source-video benchmark.','font':'Bundled DejaVu Sans: actual font loaded in browser; cmap covers Ữ ặ ỡ ợ ẫ. Other OS fallback fonts not certified.','measurements':results};(root/'docs/timeline-measurements.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
finally:server.shutdown()
