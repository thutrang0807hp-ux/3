"""Regression checks with slow and failing asset requests, using a real browser."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
from collections import Counter
import threading,time
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
requests=Counter()
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  path=self.path.split('?')[0];requests[path]+=1
  if path.endswith('transitions.webp'):time.sleep(.8)
  if path.endswith('effects.webp'):time.sleep(.15)
  if path.endswith('audio-inspector.webp') and requests[path]==1:
   self.send_error(503);return
  super().do_GET()
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(root/'dist')))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1440,'height':1000});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}/web-demo/native/reference.html',wait_until='networkidle')
  expect(page.locator('#screenTitle')).to_have_text('Tư liệu')
  assert not any(path.endswith('.mp4') for path in requests),'Videos loaded before opening a video tab'
  page.evaluate('''()=>{const s=document.querySelector('#screen');s.value='transitions';s.dispatchEvent(new Event('change'));s.value='effects';s.dispatchEvent(new Event('change'));}''')
  # Keep the original decoded picture while the next one loads.
  assert page.locator('#screenImage').get_attribute('src').endswith('/media.webp')
  expect(page.locator('#screenTitle')).to_have_text('Hiệu ứng')
  page.wait_for_timeout(1000)
  expect(page.locator('#screenTitle')).to_have_text('Hiệu ứng')
  assert page.locator('#screenImage').get_attribute('src').endswith('/effects.webp')
  before=requests['/web-demo/native/assets/effects.webp']
  page.locator('#screen').select_option('media')
  expect(page.locator('#screenTitle')).to_have_text('Tư liệu')
  page.locator('#screen').select_option('effects')
  expect(page.locator('#screenTitle')).to_have_text('Hiệu ứng')
  assert requests['/web-demo/native/assets/effects.webp']==before,'Revisit fetched the cached picture again'
  page.locator('#screen').select_option('audio-inspector')
  expect(page.locator('#screenStatus')).to_be_visible()
  expect(page.locator('#screenTitle')).to_have_text('Hiệu ứng')
  assert page.locator('#screenImage').get_attribute('src').endswith('/effects.webp')
  page.get_by_role('button',name='Thử lại',exact=True).click()
  expect(page.locator('#screenTitle')).to_have_text('Thuộc tính âm thanh')
  expect(page.locator('#screenStatus')).to_be_hidden()
  page.get_by_role('tab',name='Video thao tác',exact=True).click()
  page.locator('#desktopVideo').evaluate('(v)=>v.play()')
  page.wait_for_function('document.querySelector("#desktopVideo").currentTime>.2')
  page.get_by_role('tab',name='Video thao tác',exact=True).click()
  assert not page.locator('#desktopVideo').evaluate('(v)=>v.paused'),'Clicking the active tab interrupted playback'
  assert not any(path.endswith('concat-native-9x16.mp4') for path in requests)
  page.get_by_role('tab',name='Video đã xuất',exact=True).click()
  assert page.locator('#desktopVideo').evaluate('(v)=>v.paused')
  page.locator('#resultVideo').evaluate('(v)=>v.play()')
  page.wait_for_function('document.querySelector("#resultVideo").currentTime>.2')
  page.get_by_role('tab',name='Khám phá giao diện',exact=True).click()
  assert page.locator('#resultVideo').evaluate('(v)=>v.paused')
  assert not errors,errors
  browser.close()
 print('PASS: no initial MP4 requests; decoded image retained on slow loads; latest rapid selection wins; cached revisit; failed asset retry; active video tab does not pause; inactive video pauses.')
finally:server.shutdown();server.server_close();thread.join()
