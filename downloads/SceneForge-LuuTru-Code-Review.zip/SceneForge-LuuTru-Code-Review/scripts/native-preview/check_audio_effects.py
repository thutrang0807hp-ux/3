"""Exercise restored sound inspector and measure real exported filter processing."""
from pathlib import Path
import sys,io,wave,subprocess,json
import numpy as np
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/demo-lite'))
from browser_controls import controls
rate=48000;t=np.arange(int(rate*1.2))/rate;raw=io.BytesIO()
with wave.open(raw,'wb') as w:
 w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate)
 w.writeframes((.03*(np.sin(2*np.pi*200*t)+np.sin(2*np.pi*6000*t))*32767).astype('<i2').tobytes())
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1600,'height':1000},accept_downloads=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()));page.goto('http://demo.test/')
 state=lambda:page.evaluate('SceneForgeEditor.getState()');q=controls(page)
 first=state()['items'][0];q('#extractAudio').click();page.locator('[data-item="'+first['id']+'"]').click()
 page.locator('#miniAudioEffects').click();expect(page.locator('#audioEffectsControls')).to_be_visible();expect(page.locator('#inspectorPanel')).to_be_visible()
 assert len(state()['selectedIds'])==2 # restoring the panel must retain linked selection
 page.locator('[data-audio-preset=clear]').click();item=next(i for i in state()['items'] if i['id']==first['id']);assert not item['audioBypass'] and item['audioHighpass']==85
 page.locator('#undo').click();assert next(i for i in state()['items'] if i['id']==first['id'])['audioBypass']
 page.locator('[data-audio-preset=warm]').click();page.locator('[data-sound-bypass]').click();assert next(i for i in state()['items'] if i['id']==first['id'])['audioBypass']
 page.locator('[data-sound-bypass]').click();assert not next(i for i in state()['items'] if i['id']==first['id'])['audioBypass']
 page.reload()
 for item in state()['items'][1:]:page.locator('[data-item="'+item['id']+'"]').click();q('#delete').click()
 page.locator('[data-item="'+state()['items'][0]['id']+'"]').click();q('#prop-duration').fill('1.2');q('#prop-duration').press('Tab')
 page.locator('#file').set_input_files({'name':'two-tones.wav','mimeType':'audio/wav','buffer':raw.getvalue()});page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.kind==="audio")')
 audio=next(i for i in state()['items'] if i['kind']=='audio');page.locator('[data-item="'+audio['id']+'"]').click();page.locator('#miniAudioEffects').click()
 def export_ratio():
  page.locator('#export').click()
  with page.expect_download(timeout=20000) as dl:page.locator('#realExport').click()
  data=subprocess.check_output(['ffmpeg','-v','error','-i',dl.value.path(),'-map','0:a:0','-ar',str(rate),'-ac','1','-f','f32le','-'])
  x=np.frombuffer(data,dtype='<f4')[12000:36000];spec=np.abs(np.fft.rfft(x*np.hanning(len(x))));freq=np.fft.rfftfreq(len(x),1/rate)
  ratio=spec[(freq>5980)&(freq<6020)].sum()/spec[(freq>180)&(freq<220)].sum()
  page.locator('#closeExport').click();return ratio
 dry=export_ratio()
 page.locator('.soundSection').filter(has=page.locator('[data-sound-number=audioLowpass]')).locator('summary').click()
 n=page.locator('[data-sound-number=audioLowpass]');n.fill('1000');n.press('Tab')
 assert next(i for i in state()['items'] if i['id']==audio['id'])['audioLowpass']==1000
 wet=export_ratio();assert wet<dry*.1,(dry,wet)
 page.locator('[data-sound-bypass]').click();bypass=export_ratio();assert .7<bypass/dry<1.3,(dry,bypass)
 page.locator('[data-sound-bypass]').click()
 with page.expect_download() as dl:page.locator('#saveProject').click()
 project=Path(dl.value.path()).read_bytes();page.locator('#projectFile').set_input_files({'name':'effects.json','mimeType':'application/json','buffer':project})
 page.wait_for_function('SceneForgeEditor.getState().items.some(i=>i.audioLowpass===1000&&!i.audioBypass)')
 page.locator('[data-item="'+audio['id']+'"]').click();page.locator('#miniAudioEffects').click()
 page.screenshot(path='/tmp/sceneforge-restored-audio-effects.png',full_page=True)
 page.locator('[data-sound-reset]').click();item=next(i for i in state()['items'] if i['id']==audio['id']);assert item['audioBypass'] and item['audioLowpass']==20000 and item['volume']==1
 assert not errors,errors
 print('PASS: sound panel restored, mini shortcut, linked selection preserved, presets/bypass/undo/reset/JSON; decoded WebM lowpass suppresses 6kHz >20dB and bypass restores original ratio.',dry,wet,bypass)
 b.close()
