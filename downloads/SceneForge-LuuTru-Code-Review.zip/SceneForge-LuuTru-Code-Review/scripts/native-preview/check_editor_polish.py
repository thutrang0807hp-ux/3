"""Regression checks for linked retiming and cancellable audio/join gestures."""
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'scripts/demo-lite'))
from browser_controls import controls
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1536,'height':1040});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()))
 page.goto('http://demo.test/');q=controls(page);state=lambda:page.evaluate('SceneForgeEditor.getState()')
 first=state()['items'][0];q('#extractAudio').click();before=state()['items']
 q('#prop-speed').select_option('2');after=state()['items']
 pair=[i for i in after if i.get('linkGroup')]
 assert len(pair)==2 and all(i['speed']==2 and i['duration']==2 for i in pair),pair
 assert sorted(i['start'] for i in after if i['kind']=='video')==[0,2,6]
 q('#undo').click();assert state()['items']==before
 q('#redo').click();assert state()['items']==after
 q('#undo').click();q('#prop-speed').select_option('0.5')
 assert all(i['duration']==8 for i in state()['items'] if i.get('linkGroup'))
 assert sorted(i['start'] for i in state()['items'] if i['kind']=='video')==[0,8,12]
 q('#undo').click();assert state()['items']==before
 # Locked companions and crowded tracks reject the entire edit.
 video_track=first['trackId']
 lock=page.locator('[data-track-action="lock"][data-track="'+video_track+'"]')
 if not lock.count():
  lock=page.locator('[data-track="'+video_track+'"] [data-track-action="lock"]')
 lock.click();locked=state()['items'];assert q('#prop-speed').is_disabled();q('#prop-speed').evaluate("n=>{n.value='2';n.dispatchEvent(new Event('change',{bubbles:true}))}")
 assert state()['items']==locked and page.locator('#miniSpeed').input_value()=='1'
 lock.click();before=state()['items']
 page.locator('#timelineEditMode').select_option('overwrite');q('#prop-speed').select_option('0.5')
 assert state()['items']==before and page.locator('#miniSpeed').input_value()=='1'
 page.locator('#timelineEditMode').select_option('insert')
 q('#prop-speed').select_option('0.5');q('#undo').click();assert state()['items']==before
 # Cancel a real fader pointer gesture without consuming a prior redo.
 slider=page.locator('#miniVolumeSlider');r=slider.bounding_box()
 page.mouse.move(r['x']+r['width']*.4,r['y']+r['height']/2);page.mouse.down()
 page.mouse.move(r['x']+r['width']*.8,r['y']+r['height']/2,steps=8)
 assert state()['items']!=before
 page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(100)
 assert state()['items']==before
 page.locator('#miniVolumeSlider').blur();q('#redo').click()
 assert all(i['duration']==8 for i in state()['items'] if i.get('linkGroup'))
 q('#undo').click()
 # Commit another gesture and undo it in a single step.
 r=slider.bounding_box();page.mouse.click(r['x']+r['width']*.8,r['y']+r['height']/2)
 page.wait_for_timeout(100);assert state()['items']!=before
 slider.blur();q('#undo').click();assert state()['items']==before
 page.locator('#miniAudioMore').click();assert page.locator('#miniAudioOptions').is_visible()
 page.keyboard.press('Escape');assert not page.locator('#miniAudioOptions').is_visible()
 page.locator('#miniAudioMore').click();page.locator('#ruler').click(position={'x':300,'y':8})
 assert not page.locator('#miniAudioOptions').is_visible()
 # Resize join while retaining its DOM node, then cancel and restore duration.
 page.locator('[data-join="'+first['id']+'"]').click()
 join=page.locator('[data-join="'+first['id']+'"]')
 initial=next(i for i in state()['items'] if i['id']==first['id'])['transitionDuration']
 page.evaluate('(id)=>window.polishJoin=document.querySelector(`[data-join="${id}"]`)',first['id'])
 h=join.locator('[data-join-edge=right]').bounding_box()
 page.mouse.move(h['x']+h['width']/2,h['y']+h['height']/2);page.mouse.down()
 page.mouse.move(h['x']+24,h['y']+h['height']/2,steps=15);page.wait_for_timeout(100)
 assert page.evaluate('(id)=>window.polishJoin===document.querySelector(`[data-join="${id}"]`)',first['id'])
 value=next(i for i in state()['items'] if i['id']==first['id'])['transitionDuration']
 assert value!=initial and abs(value*24-round(value*24))<.02,value
 page.keyboard.press('Escape');page.mouse.up()
 assert next(i for i in state()['items'] if i['id']==first['id'])['transitionDuration']==initial
 assert not errors,errors
 print('PASS: linked speed/ripple and undo/redo; fader Escape preserves redo, one-step undo; popover dismiss; stable join DOM, frame snap and Escape restoration.')
 b.close()
