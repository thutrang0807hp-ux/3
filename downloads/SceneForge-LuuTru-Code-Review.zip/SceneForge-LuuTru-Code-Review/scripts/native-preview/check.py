"""Check the published static-site layout and actual video playback locally."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist')))
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1440,'height':1120});errors=[];failures=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:failures.append(r.url) if r.status>=400 and 'favicon' not in r.url else None)
  page.goto(f'http://127.0.0.1:{server.server_port}/web-demo/native/reference.html',wait_until='networkidle')
  expect(page.get_by_role('heading',name='Xem thử trình dựng Concat gốc')).to_be_visible()
  ids=['media','text','stickers','transitions','effects','filters','templates','video-inspector','text-inspector','audio-inspector','export']
  for key in ids:
   page.locator('#screen').select_option(key)
   page.wait_for_function('(key)=>{const i=document.querySelector("#screenImage");return i.complete&&i.naturalWidth===1440&&i.src.endsWith("/"+key+".webp")}',arg=key)
   assert page.url.endswith('#'+key)
  page.get_by_role('button',name='Xem MP4 mẫu đã xuất',exact=True).click()
  expect(page.locator('#output')).to_be_visible()
  page.evaluate('document.querySelector("#resultVideo").play()')
  page.wait_for_function('document.querySelector("#resultVideo").currentTime>.2')
  assert page.evaluate('document.querySelector("#resultVideo").videoHeight')==1920
  page.get_by_role('tab',name='Video thao tác',exact=True).click()
  assert page.evaluate('document.querySelector("#resultVideo").paused')
  page.evaluate('document.querySelector("#desktopVideo").play()')
  page.wait_for_function('document.querySelector("#desktopVideo").currentTime>.2')
  page.get_by_role('tab',name='Khám phá giao diện',exact=True).click()
  page.locator('#screen').select_option('media')
  page.get_by_role('button',name='Xem Hiệu ứng',exact=True).click()
  expect(page.locator('#screenTitle')).to_have_text('Hiệu ứng')
  page.locator('#guides').uncheck();expect(page.locator('#viewer')).not_to_have_class(__import__('re').compile('guided'))
  page.screenshot(path='/tmp/concat-native-web-preview.png',full_page=True)
  page.set_viewport_size({'width':390,'height':844})
  page.locator('#screen').select_option('text-inspector')
  expect(page.locator('#screenTitle')).to_have_text('Thuộc tính chữ')
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  page.screenshot(path='/tmp/concat-native-web-mobile.png',full_page=True)
  assert not errors,errors
  assert not failures,failures
  browser.close()
 print('PASS: all 11 native screens, clickable hotspots, real desktop recording and portrait MP4 playback, mode pause, subpath routing and mobile layout.')
finally:server.shutdown();server.server_close();thread.join()
