"""Check retained frame geometry and keyboard commands after simplifying sound UI."""
from pathlib import Path
import sys,json,subprocess
from PIL import Image
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/demo-lite'))
from browser_controls import controls
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1536,'height':1040},accept_downloads=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.route('http://demo.test/**',lambda r:r.fulfill(content_type='text/html',body=(root/'dist/web-demo/native/index.html').read_text()));page.goto('http://demo.test/')
 q=controls(page);state=lambda:page.evaluate('SceneForgeEditor.getState()')
 expect(page.locator('#split')).to_contain_text('Cắt');expect(page.locator('#play')).to_contain_text('Phát')
 page.locator('#stage').click();page.keyboard.press('Space');page.wait_for_function('SceneForgeEditor.getState().time>.15');page.keyboard.press('Space');assert not page.evaluate('SceneForgeEditor.isPlaying()')
 page.evaluate('SceneForgeEditor.seek(1)');page.keyboard.press('ArrowRight');assert abs(state()['time']-1-1/24)<.001
 page.keyboard.press('Shift+ArrowLeft');assert abs(state()['time']-1/24)<.001
 page.keyboard.press('Home');assert state()['time']==0
 page.evaluate('SceneForgeEditor.seek(2)');page.keyboard.press('Control+b');assert len(state()['items'])==4;page.keyboard.press('Control+z');assert len(state()['items'])==3
 page.locator('#keyboardHelp').click();expect(page.locator('#keyboardDialog')).to_be_visible();page.locator('#closeKeyboard').click()
 q('#newText').click();q('#prop-text').fill('Ngang dọc');q('#prop-text').press('Space');assert not page.evaluate('SceneForgeEditor.isPlaying()');q('#delete').click()
 page.locator('#projectAspect').select_option('16:9');assert state()['frame']=={'width':1920,'height':1080};page.wait_for_timeout(80);r=page.locator('#stage').bounding_box();assert abs(r['width']/r['height']-16/9)<.01
 page.locator('#undo').click();assert state()['frame']=={'width':1080,'height':1920};page.locator('#redo').click();assert state()['frame']['width']==1920
 for i in state()['items'][1:]:page.locator('[data-item="'+i['id']+'"]').click();q('#delete').click()
 page.locator('[data-item]').click();q('#prop-duration').fill('1.2');q('#prop-duration').press('Tab')
 for aspect,expected in [('16:9',(1280,720)),('1:1',(720,720))]:
  page.locator('#projectAspect').select_option(aspect);page.locator('#export').click()
  with page.expect_download(timeout=20000)as dl:page.locator('#realExport').click()
  probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height','-of','json',dl.value.path()]));assert any((s.get('width'),s.get('height'))==expected for s in probe['streams'])
  page.locator('#closeExport').click()
 with page.expect_download()as dl:page.keyboard.press('Control+s')
 project=Path(dl.value.path()).read_bytes();assert json.loads(project)['frame']=={'width':1080,'height':1080}
 page.locator('#projectAspect').select_option('custom');page.locator('#frameWidth').fill('100');page.locator('#applyFrame').click();expect(page.locator('#frameError')).to_contain_text('240');assert state()['frame']['width']==1080
 page.locator('#frameWidth').fill('1000');page.locator('#frameHeight').fill('700');page.locator('#applyFrame').click();assert state()['frame']=={'width':1000,'height':700}
 with page.expect_download()as dl:page.locator('#captureFrame').click()
 assert Image.open(dl.value.path()).size==(1000,700)
 page.locator('#projectFile').set_input_files({'name':'saved.json','mimeType':'application/json','buffer':project});page.wait_for_function('SceneForgeEditor.getState().frame.width===1080&&SceneForgeEditor.getState().frame.height===1080')
 assert not errors,errors
 print('PASS: visible Cut/Play, keyboard/typing guard, landscape/square encoded dimensions, custom PNG and geometry undo/JSON retained with mini audio controls.')
 b.close()
