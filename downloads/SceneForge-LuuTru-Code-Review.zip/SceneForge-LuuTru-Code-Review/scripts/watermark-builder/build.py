"""Build local engine and publish matching third-party source/license archives."""
from pathlib import Path
import subprocess,zipfile
here=Path(__file__).resolve().parent
subprocess.run(['node',str(here/'build.mjs')],check=True)
out=here.parents[1]/'dist/web-demo/watermark'
for label,src,files in [
 ('gwr-source',here.parent/'workflow/vendor/gwr',None),
 ('mediabunny-1.46.0-source',here/'node_modules/mediabunny',['src','LICENSE','package.json','README.md'])]:
 with zipfile.ZipFile(out/(label+'.zip'),'w',compression=zipfile.ZIP_DEFLATED)as z:
  if files is None:paths=sorted(p for p in src.rglob('*')if p.is_file())
  else:paths=[p for f in files for p in ((src/f).rglob('*')if(src/f).is_dir()else[src/f])if p.is_file()]
  for p in paths:z.write(p,arcname=label+'/'+str(p.relative_to(src)))
