// Original SceneForge adapter; removal algorithms are vendored under MIT.
import { detectGeminiVideoWatermark, removeGeminiVideoWatermark } from '../workflow/vendor/gwr/src/video/videoExport.js';
import { Input, BlobSource, ALL_FORMATS, Mp4OutputFormat } from 'mediabunny';
export { getEmbeddedAlphaMap } from '../workflow/vendor/gwr/src/core/embeddedAlphaMaps.js';
export const upstreamCommit='dcf688f34f4d05cc1c33236d104b4624314748ed';
export async function processWatermark(file,{signal,onProgress=()=>{}}={}){
 if(!globalThis.VideoDecoder||!globalThis.VideoEncoder)throw new Error('Cần Chrome hoặc Edge bản mới có WebCodecs để xử lý video.');
 if(!(file instanceof Blob)||file.size===0)throw new Error('Không đọc được tệp video gốc.');
 const input=new Input({source:new BlobSource(file),formats:ALL_FORMATS});let audioExpected=false;
 try{const track=await input.getPrimaryAudioTrack();if(track){audioExpected=true;const codec=await track.getCodec();if(!new Mp4OutputFormat().getSupportedAudioCodecs().includes(codec))throw new Error('Định dạng tiếng này chưa giữ được khi xuất MP4. Bản gốc được giữ nguyên.');}}finally{input.dispose();}
 const options={signal,onProgress,yieldToMainThread:()=>new Promise(resolve=>setTimeout(resolve,0)),preserveAudio:true};
 const detection=await detectGeminiVideoWatermark(file,options);
 signal?.throwIfAborted();
 if(!detection.detection.isConfident)return {status:'not-found',message:'Chưa nhận diện được mẫu watermark phù hợp. Giữ bản gốc; không xử lý ép.',metadata:detection.metadata};
 const result=await removeGeminiVideoWatermark(file,{...options,detection});
 if(audioExpected&&!result.audioCopied)throw new Error('Chưa giữ được tiếng của clip. Đã bỏ kết quả, bản gốc vẫn được giữ.');
 if(!result.processedFrames||result.processedFrames===result.skippedFrames)return {status:'not-found',message:'Chưa có khung hình đủ chắc chắn để xử lý. Giữ bản gốc.',metadata:result.metadata};
 return {status:'processed',...result};
}
