from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'review/manifest.json').read_text())
for item in m['files']:
 raw=(root/item['path']).read_bytes()
 assert len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256'],item['path']
print('PASS:',len(m['files']),'files match manifest; no data cleanup or provider calls')
