"""M2M100 contracts and offline installer safety. Model transport is fixture only."""
import tempfile,json
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from fastapi.testclient import TestClient
from fastapi import FastAPI
from .local_translation import install_local_translation,translation_status
from .work_budget import WorkBudget
from .translation_worker import translate,normalize_language,LANGUAGES,MODEL_FILES
from .prepare_translation import install
lines=[{'id':'a','original':'你好。'},{'id':'b','original':'这是产品。'}]
assert len(LANGUAGES)==100 and 'it' in LANGUAGES and 'vi' in LANGUAGES
assert normalize_language('jw')=='jv'
class Tokenizer:
 def encode(self,text,out_type=str):return list(text)
 def decode_pieces(self,tokens):return ''.join(tokens)
class Engine:
 def __init__(self):self.calls=[];self.unloaded=False
 def translate_batch(self,batch,**options):
  assert batch[0][0] in ('__zh__','__it__') and batch[0][-1]=='</s>'
  assert options['target_prefix']==[['__vi__']] and options['max_input_length']==0
  self.calls.append(batch[0]);return [SimpleNamespace(hypotheses=[['__vi__','Bản dịch thử','</s>']])]
 def unload_model(self):self.unloaded=True
for source in ['zh','it']:
 engine=Engine()
 with patch('local_engine.translation_worker.load_model',return_value=(engine,Tokenizer())):
  result=translate('/unused',[{'id':'long','original':'x'*500}],source)
  assert len(engine.calls)==3 and sum(len(c)-2 for c in engine.calls)==500 and engine.unloaded
  assert result['pivot'] is None and result['source_language']==source and result['provider']=='local-m2m100-ct2'
with tempfile.TemporaryDirectory() as temporary:
 data=Path(temporary);app=FastAPI();install_local_translation(app,data,WorkBudget().lane('translation',20))
 with TestClient(app) as c:
  assert not c.get('/local-api/translation/local/status').json()['available']
  assert c.post('/local-api/translation/local',json={'lines':lines,'source_language':'it'}).status_code==409
  assert c.post('/local-api/translation/local',json={'lines':lines,'source_language':'made-up'}).status_code==400
  assert c.post('/local-api/translation/local',json={'lines':lines*2}).status_code==400
  async def worker(*args,**kwargs):
   source=Path(args[args.index('--input')+1]);out=Path(args[args.index('--output')+1]);body=json.loads(source.read_text());out.write_text(json.dumps({'provider':'local-m2m100-ct2','lines':[dict(r,translation='Bản dịch kiểm thử') for r in body['lines']],'provider_requests':0}));return 0,'',''
  with patch('local_engine.local_translation.translation_status',return_value={'available':True}),patch('local_engine.local_translation.run_command',side_effect=worker):
   result=c.post('/local-api/translation/local',json={'lines':lines}).json();assert result['lines'][0]['id']=='a' and result['provider_requests']==0
   assert not list(data.glob('translation-*'))
  async def broken(*args,**kwargs):
   Path(args[args.index('--output')+1]).write_text(json.dumps({'lines':[{'id':'wrong','translation':'x'}]}));return 0,'',''
  with patch('local_engine.local_translation.translation_status',return_value={'available':True}),patch('local_engine.local_translation.run_command',side_effect=broken):assert c.post('/local-api/translation/local',json={'lines':lines}).status_code==502
  assert not list(data.glob('translation-*'))
 # Import from a separate CT2 bundle; setup marker only after two language probes.
 bundle=data/'bundle';bundle.mkdir()
 for name in MODEL_FILES:(bundle/name).write_bytes(b'fixture-only')
 def probe(root,rows,source):return {'lines':[{'translation':'Bản dịch '+source}]}
 with patch('local_engine.prepare_translation.translate',side_effect=probe):
  installed=install(data/'installed',source=bundle);assert installed['ready'] and set(installed['samples'])=={'zh','it'}
  before=(data/'installed/model.bin').read_bytes();(bundle/'model.bin').write_bytes(b'different')
  try:install(data/'installed',source=bundle)
  except ValueError:pass
  else:raise AssertionError('Different model overwritten')
  assert (data/'installed/model.bin').read_bytes()==before
 print('PASS 100-language map, direct Chinese/Italian tags, no silent truncation, engine unload, missing-model block/no paid fallback, isolated output contract, cleanup, verified imports/no overwrite. Model/tokenizer fixtures only.')
