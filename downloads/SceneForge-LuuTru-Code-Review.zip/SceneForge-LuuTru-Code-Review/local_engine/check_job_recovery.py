"""Actual MP4 jobs across server restarts; durable CPU status; deterministic budget."""
import asyncio,base64,hashlib,json,os,socket,subprocess,sys,tempfile,time
from pathlib import Path
import httpx
from local_engine.local_jobs import LocalJobs,JobRegistry
from local_engine.work_budget import WorkBudget
async def budget_check():
 budget=WorkBudget();events=[];release=asyncio.Event();entered=asyncio.Event()
 async def first():
  async with budget.lane('analysis',10):events.append('first');entered.set();await release.wait()
 async def next_job(name,priority):
  async with budget.lane(name,priority):events.append(name)
 a=asyncio.create_task(first());await entered.wait();b=asyncio.create_task(next_job('analysis2',10));c=asyncio.create_task(next_job('export',0));await asyncio.sleep(.01)
 assert budget.status()['active']=='analysis';release.set();await asyncio.gather(a,b,c);assert events==['first','export','analysis2'],events
 async with budget.lane('held',10):
  cancelled=asyncio.create_task(next_job('cancelled',0));await asyncio.sleep(.01);cancelled.cancel()
  try:await cancelled
  except asyncio.CancelledError:pass
 assert not budget.status()['waiting']and budget.status()['active']is None
 async with budget.lane('still works',0):pass
asyncio.run(budget_check())
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='Phục hồi video ',dir='/tmp')as tmp:
 data=Path(tmp);source=data/'source.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=240x426:r=30:d=1','-c:v','libx264','-pix_fmt','yuv420p','-y',str(source)],check=True)
 raw=source.read_bytes();env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp};processes=[]
 def start():
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  p=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);processes.append(p)
  c=httpx.Client(base_url=f'http://127.0.0.1:{port}',timeout=30)
  for _ in range(120):
   try:
    if c.get('/local-api/health').status_code==200:break
   except httpx.HTTPError:pass
   if p.poll()is not None:raise AssertionError(p.stderr.read().decode())
   time.sleep(.1)
  else:raise AssertionError('server not ready')
  assert c.get('/').status_code==200;return p,c
 def stop(p,c):c.close();p.terminate();p.wait(timeout=15)
 H={'X-SceneForge-Local':'1'}
 def wait(c,path):
  for _ in range(600):
   result=c.get(path).json()
   if result['state']in ('done','error','cancelled'):return result
   time.sleep(.05)
  raise AssertionError('job timed out')
 try:
  p,c=start()
  r=c.post('/local-api/export/mp4?fps=30&normalize=false&duration=1&room_id=recover-room',headers=H,content=raw);assert r.status_code==200,r.text;finishing=r.json()['id']
  model={'room_id':'recover-room','width':240,'height':426,'fps':30,'normalize':False,'clips':[{'asset':'source','bytes':len(raw),'kind':'video','track':'v','start':0,'duration':1,'muted':True}]}
  r=c.post('/local-api/export/timeline',headers=H,json=model);assert r.status_code==200,r.text;timeline=r.json()['id']
  assert c.put(f'/local-api/export/timeline/{timeline}/assets/source',headers=H,content=raw).status_code==200
  assert c.post(f'/local-api/export/timeline/{timeline}/start',headers=H).status_code==200
  assert wait(c,'/local-api/export/jobs/'+finishing)['state']=='done'
  assert wait(c,'/local-api/export/timeline/'+timeline)['state']=='done'
  paths=[f'/local-api/export/jobs/{finishing}',f'/local-api/export/timeline/{timeline}'];digests=[hashlib.sha256(c.get(path+'/file').content).hexdigest()for path in paths]
  # Leave an upload unfinished. Graceful shutdown must report the interruption.
  pending=c.post('/local-api/export/timeline',headers=H,json=model).json()['id']
  stop(p,c)
  store=LocalJobs(data);cpu=JobRegistry(store,'analysis');cpu.create({'id':'aabbcc','state':'done','result':{'source_sha256':'saved','scenes':[{'start':0,'end':1}]},'at':time.time(),'room_id':'recover-room'})
  cpu.create({'id':'ddeeff','state':'running','progress':42,'at':time.time(),'room_id':'recover-room'})
  p,c=start()
  for path,digest in zip(paths,digests):
   assert c.get(path).json()['state']=='done'
   assert hashlib.sha256(c.get(path+'/file').content).hexdigest()==digest
  cpu_result=c.get('/local-api/analysis/local/jobs/aabbcc').json();assert cpu_result['result']['source_sha256']=='saved'
  interrupted=c.get('/local-api/analysis/local/jobs/ddeeff').json();assert interrupted['state']=='error'and 'Không tự'in interrupted['error']
  assert c.get('/local-api/export/timeline/'+pending).json()['state']=='error'
  assert c.post('/local-api/export/timeline/'+pending+'/start',headers=H).status_code==409
  history=c.get('/local-api/local-jobs').json();assert all('result'not in j for j in history['jobs']);assert history['resources']['active']is None
  assert any(j['id']=='ddeeff'and j['recovered']for j in history['jobs'])
  # Missing output is reported safely; it never causes a new render.
  (data/'exports'/(finishing+'.mp4')).unlink();assert c.get(paths[0]+'/file').status_code==410
  stop(p,c)
  print('PASS actual H.264 finishing/timeline results survive restart byte-for-byte; CPU result/status persisted; unfinished upload and interrupted analysis never rerun; missing MP4 gives 410; export priority and cancelled waiters release shared budget. No providers invoked.')
 finally:
  for p in processes:
   if p.poll()is None:p.kill();p.wait()
