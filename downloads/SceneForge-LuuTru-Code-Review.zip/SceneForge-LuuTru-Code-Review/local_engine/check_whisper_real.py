"""Opt-in real model integration test. No downloads, provider calls or paid services."""
import os,tempfile,subprocess,json,base64,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=Path(os.environ.get('SCENEFORGE_WHISPER_MODEL','/workspace/engines/cpu-ready/models/faster-whisper'))
if not (source/'model.bin').is_file():raise SystemExit('Set SCENEFORGE_WHISPER_MODEL to a complete local model.')
with tempfile.TemporaryDirectory(prefix='sf-whisper-real-') as temporary:
 data=Path(temporary);(data/'models').mkdir();(data/'models/faster-whisper').symlink_to(source,target_is_directory=True)
 os.environ['SCENEFORGE_LOCAL_DATA']=str(data);os.environ['HF_HUB_OFFLINE']='1'
 from fastapi.testclient import TestClient
 from local_engine import server
 video=data/'speech.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=navy:s=360x640:r=25','-i',str(root/'artifacts/voices/SceneForge-HaiDang-CPU.wav'),'-c:v','libx264','-preset','ultrafast','-c:a','aac','-shortest','-y',str(video)],check=True)
 duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(video)]).decode().split('"duration": "')[1].split('"')[0])
 with TestClient(server.app) as client:
  client.get('/');caps=client.get('/local-api/analysis/local/capabilities').json();assert caps['whisper_model'] and caps['whisper'],caps
  response=client.post('/local-api/analysis/local/jobs',headers={'X-SceneForge-Local':'1'},json={'video_data':base64.b64encode(video.read_bytes()).decode(),'mime_type':'video/mp4','duration':duration,'transcribe':True,'language':'vi','ocr':False});assert response.status_code==200,response.text
  job_id=response.json()['id'];deadline=time.monotonic()+180
  while time.monotonic()<deadline:
   job=client.get('/local-api/analysis/local/jobs/'+job_id).json()
   if job['state'] in ('done','error','cancelled'):break
   time.sleep(.15)
  assert job['state']=='done',job
  result=job['result'];assert result['speech']['state']=='transcribed' and result['speech']['language']=='vi'
  assert result['transcript'] and any(s['words'] for s in result['transcript'])
  assert result['provider_requests']==0 and not list((data/'cpu-analysis').glob('job-*'))
  for s in result['transcript']:assert 0<=s['start']<s['end']<=duration
  (root/'artifacts/whisper-api-real-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
  print('PASS real video -> local analysis API -> isolated CPU int8 Whisper -> Vietnamese transcript + word timestamps; no downloads/provider requests; temp files cleaned.')
  for s in result['transcript']:print(round(s['start'],2),round(s['end'],2),s['original'])
