"""Recovery downloads only: original account/session, real media, zero generation POST."""
import asyncio,hashlib,json,subprocess,tempfile,uuid
from pathlib import Path
import httpx
from .flow_provider import FlowProvider
from .muse_provider import MuseProvider
from .request_ledger import RequestLedger
from .vault import Vault

async def main():
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);video=root/'fixture.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=90x160:r=10:d=0.2','-c:v','libx264',str(video)],check=True)
  for name in ('flow','muse'):
   work=root/name;work.mkdir();vault=Vault(work);ledger=RequestLedger(work);rid=name+'-'+str(uuid.uuid4());ledger.claim(rid,{'original':'sent'});ledger.finish(rid,'unknown');calls=[]
   if name=='flow':
    async def transport(request):
     assert request.method=='GET';calls.append(request.url.path)
     if request.url.path.startswith('/sceneforge/tasks/'):return httpx.Response(200,json={'state':'done','account_id':4,'response':{'url':'http://127.0.0.1:8766/result'}})
     return httpx.Response(200,content=video.read_bytes(),headers={'content-type':'video/mp4'})
    service=FlowProvider(vault,work,ledger,lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)));service.configure({'url':'http://127.0.0.1:8766','key':'fixture-key-private'})
    config=service.config();ledger.set_metadata(rid,{'provider':'flow','engine_id':4,'account_id':'A','model':'fixture-video','kind':'video','room_id':'room','scene_id':'scene','engine_instance':hashlib.sha256((config['url']+config['key']).encode()).hexdigest()})
   else:
    async def runner(body):
     calls.append(body['operation']);assert body['operation']=='reconcile'and body['session_id']=='original-session';Path(body['output']).write_bytes(video.read_bytes());return {'ok':True}
    service=MuseProvider(vault,work,ledger,runner);vault.put('accounts',{'id':'A','service':'muse','name':'A','enabled':True,'session_verified':True,'state':'ready','active':True});vault.set_secret('muse-session:A',{'identity':'original'})
    ledger.set_metadata(rid,{'account_id':'A','room_id':'room','scene_id':'scene'});(service.journal/(rid+'.json')).write_text(json.dumps({'request_id':rid,'account_id':'A','session_id':'original-session'}))
   result=await service.reconcile(rid);assert result['state']=='done',result
   assert result['result']['account_id']=='A'and result['result']['room_id']=='room'
   before=len(calls);await service.reconcile(rid);assert len(calls)==before
   print('PASS:',name,'unknown -> read-only reconcile -> validated video on original account/scene; repeated lookup makes no generation or duplicate download.')

if __name__=='__main__':asyncio.run(main())
