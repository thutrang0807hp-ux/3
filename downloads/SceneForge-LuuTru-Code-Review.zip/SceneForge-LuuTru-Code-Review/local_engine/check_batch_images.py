"""No paid calls: transport fixtures exercise real adapter and durable claims."""
import asyncio,base64,io,tempfile,uuid,json
from pathlib import Path
from PIL import Image
import httpx
from fastapi import HTTPException
from local_engine.batch_images import BatchImages
from local_engine.request_ledger import RequestLedger
from local_engine.vault import Vault
async def main():
 with tempfile.TemporaryDirectory(dir='/tmp')as tmp:
  root=Path(tmp);vault=Vault(root);vault.set_secret('gemini','test-private-key-never-in-logs');ledger=RequestLedger(root);png=io.BytesIO();Image.new('RGB',(90,160),'#c25a73').save(png,format='PNG');encoded=base64.b64encode(png.getvalue()).decode();posts=[];mode='success';gate=asyncio.Event();gate.set()
  async def transport(request):
   nonlocal mode
   if request.method=='GET':return httpx.Response(200,json={'models':[{'name':'models/gemini-test-image','supportedGenerationMethods':['generateContent']},{'name':'models/gemini-text','supportedGenerationMethods':['generateContent']}]})
   posts.append(json.loads(request.content));await gate.wait()
   assert request.headers['x-goog-api-key']=='test-private-key-never-in-logs'
   if mode=='timeout':raise httpx.ReadTimeout('secret URL? test-private-key-never-in-logs',request=request)
   if mode=='429':return httpx.Response(429,json={'error':{'message':'private key'}})
   return httpx.Response(200,json={'candidates':[{'content':{'parts':[{'inlineData':{'mimeType':'image/png','data':encoded}}]}}],'usageMetadata':{'candidatesTokenCount':10}})
  service=BatchImages(vault,root,ledger,lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)))
  assert (await service.discover())['models']==['gemini-test-image'];assert not posts
  def body():return {'request_id':'batch-image-'+str(uuid.uuid4()),'prompt':'Nội dung riêng tư không được log','model':'gemini-test-image','aspect':'9:16','references':[{'mime_type':'image/png','data':encoded}],'confirm_send':True,'product_id':'product-test'}
  b=body();bad={**b,'confirm_send':False}
  try:await service.submit(bad);raise AssertionError('confirmation missing')
  except HTTPException as e:assert e.status_code==409
  assert not posts
  gate.clear();await service.submit(b);await asyncio.sleep(.02)
  try:await service.submit(b);raise AssertionError('duplicate accepted')
  except HTTPException as e:assert e.status_code==409
  assert len(posts)==1;gate.set();await asyncio.gather(*list(service.tasks.values()));record=service.lookup(b['request_id']);assert record['state']=='done';assert service.file(b['request_id']).path.read_bytes()==png.getvalue();await service.submit(b);assert len(posts)==1
  assert posts[0]['contents'][0]['parts'][1]['inline_data']['data']==encoded;assert posts[0]['generationConfig']['imageConfig']['aspectRatio']=='9:16'
  mode='timeout';unknown=body();await service.submit(unknown);await asyncio.gather(*list(service.tasks.values()));assert service.lookup(unknown['request_id'])['state']=='unknown';before=len(posts)
  reloaded=BatchImages(vault,root,RequestLedger(root),service.client_factory)
  try:await reloaded.submit(unknown);raise AssertionError('unknown resubmitted')
  except HTTPException as e:assert e.status_code==409
  assert len(posts)==before
  mode='429';limited=body();await service.submit(limited);await asyncio.gather(*list(service.tasks.values()));assert service.lookup(limited['request_id'])['state']=='failed';assert len(posts)==before+1
  malformed=body();malformed['references']=[{'mime_type':'image/png','data':'not base64'}]
  try:await service.submit(malformed);raise AssertionError('bad image accepted')
  except HTTPException as e:assert e.status_code==400
  logs=json.dumps(vault.rows('logs'));assert 'test-private-key'not in logs and 'Nội dung riêng tư'not in logs and encoded not in logs
  assert service.lookup(b['request_id'])['result']['sha256'];await service.close()
 print('PASS actual Gemini adapter with mock transport: model discovery, explicit send, reference payload, original image bytes, duplicate/restart protection, unknown/429 no retry, invalid refs blocked, metadata-only logs. No external AI calls.')
asyncio.run(main())
