"""Exercise real adapter with transport fixtures, not paid/provider certification."""
import asyncio, base64, io, json, subprocess, tempfile, uuid
from pathlib import Path
import httpx
from PIL import Image
from fastapi import HTTPException
from .flow_provider import FlowProvider, local_url
from .request_ledger import RequestLedger
from .vault import Vault


async def main():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        vault, ledger = Vault(root), RequestLedger(root)
        picture = io.BytesIO()
        Image.new('RGB', (90, 160), '#a95769').save(picture, format='PNG')
        encoded = base64.b64encode(picture.getvalue()).decode()
        video = root / 'fixture.mp4'
        subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'color=blue:s=90x160:r=10:d=0.5', '-c:v', 'libx264', '-y', str(video)], check=True)
        posts, downloads = [], []
        active = maximum = 0
        gate = asyncio.Event()
        mode = 'image'

        async def transport(request):
            nonlocal active, maximum
            if request.url.path == '/v1/models':
                assert request.headers['authorization'] == 'Bearer LOCAL_PRIVATE_KEY_12345'
                return httpx.Response(200, json={'data': [{'id': 'fixture-image'}, {'id': 'fixture-video'}]})
            if request.method == 'POST':
                posts.append(json.loads(request.content))
                active += 1
                maximum = max(active, maximum)
                try:
                    await gate.wait()
                    if mode == 'timeout':
                        raise httpx.ReadTimeout('private prompt/token should not enter logs')
                    url = 'http://169.254.169.254/private' if mode == 'unsafe' else 'http://127.0.0.1:8766/result.' + ('mp4' if mode == 'video' else 'png')
                    return httpx.Response(200, json={'choices': [{'message': {'content': '<video src="'+url+'"></video>' if mode == 'video' else '![]('+url+')'}}]})
                finally:
                    active -= 1
            downloads.append(str(request.url))
            assert 'authorization' not in request.headers
            return httpx.Response(200, content=video.read_bytes() if mode == 'video' else picture.getvalue(), headers={'content-type': 'video/mp4' if mode == 'video' else 'image/png'})

        factory = lambda: httpx.AsyncClient(transport=httpx.MockTransport(transport))
        service = FlowProvider(vault, root, ledger, factory)
        for url in ['https://example.com', 'http://localhost:8766', 'http://127.0.0.1:8766/private', 'http://user:pass@127.0.0.1:8766']:
            try:
                local_url(url)
                raise AssertionError('bad endpoint accepted')
            except HTTPException:
                pass
        service.configure({'url': 'http://127.0.0.1:8766', 'key': 'LOCAL_PRIVATE_KEY_12345'})
        assert 'key' not in service.status()
        assert len((await service.discover())['models']) == 2 and not posts

        def body(kind='image'):
            return {'request_id': 'flow-'+str(uuid.uuid4()), 'kind': kind, 'model': 'fixture-'+kind, 'prompt': 'PRIVATE_PROMPT_NOT_LOGGED',
                    'references': [{'mime_type': 'image/png', 'data': encoded}], 'confirm_send': True}

        try:
            await service.submit({**body(), 'confirm_send': False})
            raise AssertionError('missing confirmation')
        except HTTPException as e:
            assert e.status_code == 409
        jobs = [body() for _ in range(5)]
        for job in jobs:
            await service.submit(job)
        await asyncio.sleep(.02)
        assert len(posts) == maximum == 3
        try:
            await service.submit(jobs[0])
            raise AssertionError('duplicate submission')
        except HTTPException as e:
            assert e.status_code == 409
        gate.set()
        await asyncio.gather(*list(service.tasks.values()))
        assert len(posts) == 5 and maximum == 3
        for job in jobs:
            assert service.lookup(job['request_id'])['state'] == 'done'
            assert service.file(job['request_id']).path.read_bytes() == picture.getvalue()
        assert posts[0]['messages'][0]['content'][1]['image_url']['url'].endswith(encoded)
        await service.submit(jobs[0])
        assert len(posts) == 5
        mode = 'video'
        job = body('video')
        await service.submit(job)
        await asyncio.gather(*list(service.tasks.values()))
        assert service.lookup(job['request_id'])['state'] == 'done'
        assert service.file(job['request_id']).path.read_bytes() == video.read_bytes()
        mode = 'unsafe'
        count = len(downloads)
        unsafe = body()
        await service.submit(unsafe)
        await asyncio.gather(*list(service.tasks.values()))
        assert service.lookup(unsafe['request_id'])['state'] == 'unknown' and len(downloads) == count
        mode = 'timeout'
        unknown = body()
        await service.submit(unknown)
        await asyncio.gather(*list(service.tasks.values()))
        restarted = FlowProvider(vault, root, RequestLedger(root), factory)
        before = len(posts)
        try:
            await restarted.submit(unknown)
            raise AssertionError('unknown request repeated')
        except HTTPException as e:
            assert e.status_code == 409
        assert len(posts) == before
        logs = json.dumps(vault.rows('logs'))
        assert 'PRIVATE_PROMPT' not in logs and 'LOCAL_PRIVATE_KEY' not in logs and encoded not in logs
        await service.close()
        await restarted.close()
    print('PASS Flow protocol adapter: 3 concurrent jobs, real image/video files and ffprobe, original references, encrypted config, no duplicate/restart retry, unsafe download blocked. Transport fixtures only; no real Flow generation certified.')


asyncio.run(main())
