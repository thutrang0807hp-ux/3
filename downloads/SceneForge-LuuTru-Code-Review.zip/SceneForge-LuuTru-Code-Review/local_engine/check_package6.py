"""Product suggestions: fake provider transport, real validation and protected local API."""
import os,tempfile,base64,io,json
from unittest.mock import patch
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-g6-api-')
import httpx
from fastapi.testclient import TestClient
from PIL import Image
from . import server
image=io.BytesIO();Image.new('RGB',(180,320),'red').save(image,format='JPEG');encoded='data:image/jpeg;base64,'+base64.b64encode(image.getvalue()).decode()
body={'files':[{'code':'F1','name':'sample.mp4','image':encoded}],'products':[{'code':'P1','name':'Son'}]}
server.VAULT.set_secret('gemini','fake-secret');server.VAULT.set_secret('gemini-models',{'main':'gemini-mock-flash'})
calls=[];wrong=False
async def provider(self,url,**kwargs):
 payload=kwargs['json'];assert all(not p.get('inline_data',{}).get('mime_type','').startswith('video/')for p in payload['contents'][0]['parts']);calls.append(payload)
 result={'assignments':{'F1':'P99'if wrong else'P1'}}
 return httpx.Response(200,json={'candidates':[{'content':{'parts':[{'text':json.dumps(result)}]}}]})
with TestClient(server.app)as c,patch.object(httpx.AsyncClient,'post',provider):
 c.get('/')  # obtain the document's loopback session cookie
 assert c.post('/local-api/ai/classify-products',json=body).status_code==403
 h={'X-SceneForge-Local':'1'};r=c.post('/local-api/ai/classify-products',json=body,headers=h);assert r.status_code==200,r.text
 assert r.json()['assignments']=={'F1':'P1'}and r.json()['needs_confirmation']and len(calls)==1
 wrong=True;r=c.post('/local-api/ai/classify-products',json=body,headers=h);assert r.status_code==502
 assert c.post('/local-api/ai/classify-products',json={**body,'files':body['files']*21},headers=h).status_code==400
 assert 'fake-secret'not in c.get('/local-api/ai/providers').text
print('PASS explicit product-suggestion route, frame-only payload, exact file/product code validation, invalid output blocked, 20-file bound, POST guard and secret redaction; provider transport mocked, no live call.')
