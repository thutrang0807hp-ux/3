"""Scope immediate retirement to older versions of explicitly approved prompt slots."""
import copy
from .storage_lifecycle import collect_strings

def prune_approved(records,room,targets):
 from .library import hashes
 if not isinstance(targets,list)or not targets or len(targets)>500:raise ValueError('Danh sách duyệt không hợp lệ.')
 if any(isinstance(t,dict)and t.get('scope')=='photo'for t in targets)and not all(isinstance(t,dict)and t.get('scope')=='photo'for t in targets):raise ValueError('Không trộn phạm vi duyệt.')
 if targets and all(t.get('scope')=='photo' for t in targets if isinstance(t,dict)):
  return prune_photo_approved(records,room,targets)
 workflow=next((r for r in records if r['db']=='sceneforge-workflows'and r['key']==room),None)
 if not workflow:raise ValueError('Không có workflow của dự án.')
 value=workflow['value'];entries=dict(value.get('assetEntries',[]))
 editor=next((r['value']for r in records if r['db']=='sceneforge-editor-local'and r['key']==room),{})
 payload=editor.get('payload')or{};used={i.get('assetId')for i in payload.get('items',[])}
 timeline=set(hashes(payload.get('items',[])))
 for media in editor.get('media',[]):
  if media.get('id')in used:timeline.update(hashes(media))
 timeline_ids=collect_strings(payload.get('items',[]))
 timeline_ids.update(a.get('workflowKey')for a in payload.get('assets',[])if a.get('id')in used)

 removed=[];retired_assets=set();seen=set()
 for target in targets:
  if not isinstance(target,dict):raise ValueError('Sai ô duyệt.')
  sid,kind,part,keep=target.get('sceneId'),target.get('kind'),target.get('part'),target.get('keepId')
  if kind not in ('frame','clip')or (sid,kind,part)in seen:raise ValueError('Ô duyệt trùng hoặc sai loại.')
  seen.add((sid,kind,part));scene=next((s for s in value.get('scenes',[])if s.get('id')==sid),None)
  if not scene:raise ValueError('Cảnh đã thay đổi.')
  key='frames'if kind=='frame'else'clips'
  versions=[v for v in scene.get(key,[])if kind=='frame'or v.get('part')==part]
  if not versions or versions[-1].get('id')!=keep:raise ValueError('Bản mới nhất đã thay đổi; chưa dọn.')
  latest=versions[-1]
  jobs=[j for j in value.get('cloudJobs',[])if j.get('sceneId')==sid and j.get('kind')==('image'if kind=='frame'else'video')and(kind=='frame'or j.get('part')==part)]
  if jobs and jobs[-1].get('state')not in ('imported','applied','discarded'):raise ValueError('Lượt tạo mới nhất chưa kết thúc/đối soát; chưa dọn.')
  if kind=='frame':
   if scene.get('approvedFrame')!=keep or latest.get('status')!='approved':raise ValueError('Chưa duyệt ảnh mới nhất.')
  elif (scene.get('chosen')or{}).get(part)!=keep or keep not in scene.get('receivedClipIds',[])or(latest.get('reviewDecision')or{}).get('status')!='accepted':raise ValueError('Chưa duyệt clip mới nhất.')
  if not set(hashes(latest))and not set(hashes(entries.get(latest.get('asset')))):raise ValueError('Bản duyệt chưa lưu đủ media vào kho.')
  if kind=='clip'and latest.get('frameId')and latest['frameId']!=scene.get('approvedFrame'):raise ValueError('Clip không khớp khung đã duyệt.')
  if kind=='clip'and scene.get('clipPlan',{}).get('parts'):
   planned=next((p for p in scene['clipPlan']['parts']if p.get('id')==part),None)
   if not planned:raise ValueError('Phần clip không còn trong cách chia hiện tại.')
   if latest.get('slotStart')is not None and(abs(latest['slotStart']-planned['start'])>.002 or abs(latest.get('slotEnd',-1)-planned['end'])>.002):raise ValueError('Clip được tạo theo mốc khác; chưa duyệt/dọn.')
  if kind=='clip'and latest.get('continuityFrom'):
   cursor=latest;visited=set()
   while cursor.get('continuityFrom'):
    prior_id=cursor['continuityFrom']
    if prior_id in visited:raise ValueError('Chuỗi nối clip không hợp lệ.')
    visited.add(prior_id)
    previous=next((c for c in scene.get('clips',[])if c.get('id')==prior_id),None)
    group=[c for c in scene.get('clips',[])if previous and c.get('part')==previous.get('part')]
    if not group or group[-1].get('id')!=prior_id or prior_id not in scene.get('receivedClipIds',[])or(previous.get('reviewDecision')or{}).get('status')!='accepted':raise ValueError('Phần trước đã đổi/chưa duyệt; cần nối lại clip trước khi duyệt.')
    cursor=previous
  protected_frames={c.get('frameId')for c in scene.get('clips',[])if c.get('id')in(scene.get('chosen')or{}).values()}
  kept=[]
  for v in scene.get(key,[]):
   matching=kind=='frame'or v.get('part')==part
   media=set(hashes(v))|set(hashes(entries.get(v.get('asset'))))|set(hashes(entries.get(v.get('originalAsset'))))
   protected=v.get('pinned')or v.get('id')in timeline_ids or bool(media&timeline)or kind=='frame'and v.get('id')in protected_frames
   if not matching or v.get('id')==keep or protected:kept.append(v);continue
   removed.append((kind,copy.deepcopy(v)))
   retired_assets.update(x for x in (v.get('asset'),v.get('originalAsset'))if x)
  scene[key]=kept
  if kind=='frame':scene['frameSelectionId']=keep
 # Keep lightweight provenance; retired image previews and video bytes must not remain
 # reachable through old structural snapshots or undo copies in this same workflow.
 ids={v['id']for _,v in removed}
 # Remove only unused editor-library alternatives and pending imports of retired IDs.
 retired_editor={a.get('id')for a in payload.get('assets',[])if a.get('workflowKey')in ids and a.get('id')not in used}
 if retired_editor:
  payload['assets']=[a for a in payload.get('assets',[])if a.get('id')not in retired_editor]
  editor['media']=[m for m in editor.get('media',[])if m.get('id')not in retired_editor]
 for row in records:
  if row['db']=='sceneforge-app-shell'and row['store']=='files'and row['key']==room+':pending'and isinstance(row['value'],list):row['value']=[c for c in row['value']if c.get('key')not in ids]

 def strip(v):
  if isinstance(v,list):return [strip(x)for x in v if not(isinstance(x,dict)and x.get('id')in ids)]
  if isinstance(v,dict):
   out={k:strip(x)for k,x in v.items()}
   for field in ('approvedFrame','frameSelectionId'):
    if out.get(field)in ids:out[field]=None
   if isinstance(out.get('chosen'),dict):out['chosen']={k:x for k,x in out['chosen'].items()if x not in ids}
   return out
  return v
 for key in ('localHistory','local','pendingAI'):
  if key in value:value[key]=strip(value[key])
 value.setdefault('retiredVersionLog',[]).extend({k:v.get(k)for k in ('id','part','version','requestId','prompt','model','name','createdAt')}|{'kind':kind}for kind,v in removed)
 value['retiredVersionLog']=value['retiredVersionLog'][-2000:]
 remaining=copy.deepcopy(value);remaining.pop('assetEntries',None);remaining.pop('retiredVersionLog',None);strings=collect_strings(remaining)
 value['assetEntries']=[[a,b]for a,b in value.get('assetEntries',[])if a not in retired_assets or a in strings or set(hashes(b))&timeline]
 value['approvalCleanupPending']=[t for t in value.get('approvalCleanupPending',[])if t not in targets]
 return len(removed)

def prune_photo_approved(records,room,targets):
 """Same immediate retirement policy for Photo Studio's per-prompt slots."""
 from .library import hashes
 shell=next((r for r in records if r['db']=='sceneforge-app-shell'and r['store']=='rooms'and r['key']==room),None)
 photo=shell and shell['value'].get('photoDraft')
 if not isinstance(photo,dict):raise ValueError('Không có dự án ảnh tĩnh.')
 files={r['key']:r['value']for r in records if r['db']=='sceneforge-app-shell'and r['store']=='files'}
 editor=next((r['value']for r in records if r['db']=='sceneforge-editor-local'and r['key']==room),{})
 payload=editor.get('payload')or{};used={i.get('assetId')for i in payload.get('items',[])}
 timeline=set(hashes(payload.get('items',[])))
 for media in editor.get('media',[]):
  if media.get('id')in used:timeline.update(hashes(media))
 protected=collect_strings(photo.get('plan',[]))|collect_strings(payload.get('items',[]))
 protected.update(a.get('workflowKey')for a in payload.get('assets',[])if a.get('id')in used)
 retired=set();removed=[];seen=set()
 for t in targets:
  if not isinstance(t,dict)or t.get('scope')!='photo':raise ValueError('Sai phạm vi duyệt ảnh tĩnh.')
  sid,kind,part,keep=t.get('sceneId'),t.get('kind'),t.get('part'),t.get('keepId')
  if kind not in ('clip','frame')or(sid,kind,part)in seen:raise ValueError('Ô duyệt trùng hoặc sai loại.')
  seen.add((sid,kind,part));beat=next((b for b in photo.get('beats',[])if b.get('id')==sid),None)
  if not beat:raise ValueError('Nhịp đã thay đổi.')
  key='clips'if kind=='clip'else'frames';versions=[v for v in beat.get(key,[])if kind=='frame'or v.get('part','a')==(part or'a')]
  if not versions or versions[-1].get('id')!=keep:raise ValueError('Bản mới nhất đã thay đổi; chưa dọn.')
  latest=versions[-1]
  pending=[j for j in photo.get('flowJobs',[])if kind=='clip'and j.get('beatId')==sid and j.get('part','a')==(part or'a')]
  if pending and pending[-1].get('state')not in ('imported','failed','not_submitted','discarded'):raise ValueError('Lượt tạo mới nhất chưa kết thúc/đối soát.')
  if not set(hashes(files.get(latest.get('key')))):raise ValueError('Bản duyệt chưa lưu đủ media.')
  if kind=='frame':
   if beat.get('approvedFrame')!=keep:raise ValueError('Chưa duyệt ảnh mới nhất.')
  else:
   chosen=(beat.get('chosenParts')or{}).get(part or'a')or beat.get('chosenClip')
   if chosen!=keep or(latest.get('reviewDecision')or{}).get('status')!='accepted':raise ValueError('Chưa duyệt clip mới nhất.')
   if latest.get('frameId')and latest['frameId']!=beat.get('approvedFrame'):raise ValueError('Ảnh khung đã đổi.')
   if beat.get('clipPlan')and beat['clipPlan'].get('seconds')!=beat.get('seconds'):raise ValueError('Thời lượng nhịp đã đổi; chưa duyệt/dọn.')
   parts=(beat.get('clipPlan')or{}).get('parts',[])
   planned=next((p for p in parts if p.get('id')==(part or'a')),None)
   if parts and not planned:raise ValueError('Phần clip không còn trong cách chia.')
   if planned and latest.get('slotStart')is not None and(abs(latest['slotStart']-planned['start'])>.002 or abs(latest.get('slotEnd',-1)-planned['end'])>.002):raise ValueError('Mốc clip đã đổi.')
   cursor=latest;visited=set()
   while cursor.get('continuityFrom'):
    previous=next((c for c in beat.get('clips',[])if c.get('id')==cursor['continuityFrom']),None)
    if not previous or previous['id']in visited:raise ValueError('Chuỗi nối clip không hợp lệ.')
    visited.add(previous['id']);group=[c for c in beat.get('clips',[])if c.get('part','a')==previous.get('part','a')]
    if group[-1]['id']!=previous['id']or(previous.get('reviewDecision')or{}).get('status')!='accepted':raise ValueError('Clip trước đã đổi/chưa duyệt.')
    cursor=previous
  protected_frames={c.get('frameId')for c in beat.get('clips',[])if c.get('id')in set((beat.get('chosenParts')or{}).values())|{beat.get('chosenClip')}}
  kept=[]
  for v in beat.get(key,[]):
   match=kind=='frame'or v.get('part','a')==(part or'a');file_key=v.get('key')
   safe=v.get('pinned')or v.get('id')in protected or file_key in protected or bool(set(hashes(files.get(file_key)))&timeline)or kind=='frame'and v.get('id')in protected_frames
   if not match or v.get('id')==keep or safe or not file_key:kept.append(v)
   else:retired.add(file_key);removed.append((kind,v))
  beat[key]=kept
 photo.setdefault('retiredVersionLog',[]).extend({k:v.get(k)for k in ('id','part','version','requestId','name','model')}|{'kind':kind}for kind,v in removed)
 photo['retiredVersionLog']=photo['retiredVersionLog'][-2000:]
 ids={v['id']for _,v in removed};retired_editor={a.get('id')for a in payload.get('assets',[])if a.get('id')not in used and a.get('workflowKey')in ids|retired}
 if retired_editor:
  payload['assets']=[a for a in payload.get('assets',[])if a.get('id')not in retired_editor];editor['media']=[m for m in editor.get('media',[])if m.get('id')not in retired_editor]
 # Only remove this project's file records; other projects/product banks retain shared keys.
 still=set()
 for row in records:
  if row['store']!='files':collect_strings(row['value'],still)
 records[:]=[r for r in records if not(r['db']=='sceneforge-app-shell'and r['store']=='files'and str(r['key']).startswith(room+':')and r['key']in retired-still)]
 return len(removed)
