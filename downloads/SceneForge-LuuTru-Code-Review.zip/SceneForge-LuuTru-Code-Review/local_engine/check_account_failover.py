"""Account failover fixtures: only confirmed rejections may move to B."""
import asyncio
import base64
import io
import json
import subprocess
import tempfile
import uuid
from pathlib import Path
import httpx
from PIL import Image
from fastapi import HTTPException
from .gemini_chat import GeminiChat, evidence_sheets
from .muse_provider import MuseProvider
from .account_pool import AccountPool
from .flow_provider import FlowProvider
from .flow_accounts import FlowAccounts
from .request_ledger import RequestLedger
from .vault import Vault


async def main():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        video = root / 'fixture.mp4'
        subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=90x160:r=10:d=0.4','-c:v','libx264',str(video)],check=True)
        picture = io.BytesIO()
        Image.new('RGB',(90,160),'red').save(picture,format='PNG')
        for service, cls, prefix in [('gemini_chat',GeminiChat,'gchat-'),('muse',MuseProvider,'muse-')]:
            work = root/service;work.mkdir()
            vault, ledger = Vault(work), RequestLedger(work)
            calls=[];failure='quota';kind='text' if service=='gemini_chat' else 'video'
            async def runner(body):
                aid=body['session']['identity'];calls.append(aid)
                if aid=='A':return {'ok':False,'accepted':True if failure=='partial' else None if failure=='network' else False,'reason':'quota'if failure=='partial'else failure}
                if body.get('kind')=='image':Path(body['output']).write_bytes(picture.getvalue())
                if service=='muse':Path(body['output']).write_bytes(video.read_bytes())
                return {'ok':True,'text':'{"value":"fixture"}'}
            provider=cls(vault,work,ledger,runner)
            pool=AccountPool(vault,service)
            for index,aid in enumerate(['A','B']):
                vault.put('accounts',{'id':aid,'service':service,'name':aid,'enabled':True,'state':'ready','session_verified':True,'active':aid=='A','priority':index})
                vault.set_secret(('gemini-chat-session:'if service=='gemini_chat'else'muse-session:')+aid,{'identity':aid})
            def reset():
                for row in pool.rows():row['state']='ready';vault.put('accounts',row)
                pool.select({'mode':'failover','account_id':'A'});calls.clear()
            def body():return {'request_id':prefix+str(uuid.uuid4()),'kind':kind,'prompt':'private prompt','references':[],'confirm_send':True,'selection_token':provider.selection()['token']}
            reset();job=body();await provider.submit(job);await asyncio.gather(*list(provider.tasks.values()))
            assert calls==['A','B'] and provider.lookup(job['request_id'])['result']['account_id']=='B'
            for failure in ('network','input','rate_limit','partial'):
                reset();job=body();await provider.submit(job);await asyncio.gather(*list(provider.tasks.values()))
                assert calls==['A'],(service,failure,calls)
                assert provider.lookup(job['request_id'])['state']!='done'
            failure='quota';reset();pool.select({'mode':'selected','account_id':'A'});job=body();await provider.submit(job);await asyncio.gather(*list(provider.tasks.values()));assert calls==['A']
            if service=='gemini_chat':
                reset();kind='image';job=body();await provider.submit(job);await asyncio.gather(*list(provider.tasks.values()));record=provider.lookup(job['request_id']);assert record['state']=='done' and Path(provider.file(job['request_id']).path).read_bytes()==picture.getvalue()
                reset();pool.select({'mode':'selected','account_id':'B'});kind='text'
                request={'request_id':str(uuid.uuid4()),'room_id':'fixture','value':1}
                result=await provider.execute_json(request,'Return JSON')
                n=len(calls);assert result=={'value':'fixture'} and await provider.execute_json(request,'Return JSON')==result and len(calls)==n
                try:await provider.execute_json({**request,'value':2},'Return JSON');raise AssertionError('ID content reuse')
                except HTTPException as e:assert e.status_code==409
            assert 'private prompt' not in json.dumps(vault.rows('logs'))
        frames=[('S'+str(i//3+1),base64.b64encode(picture.getvalue()).decode(),'image/png')for i in range(24)]
        sheets=evidence_sheets(frames);assert len(sheets)==6
        for sheet in sheets:
            with Image.open(io.BytesIO(base64.b64decode(sheet['data'])))as image:assert image.width==1280 and image.height<=2320
        # Actual Flow adapter plus account extension transport fixtures.
        work=root/'flow';work.mkdir();vault,ledger=Vault(work),RequestLedger(work);posts=[];checks=[];preflight_unknown=False
        async def transport(request):
            path=request.url.path
            if path=='/sceneforge/accounts':return httpx.Response(200,json={'protocol':'sceneforge-account-pin-v1','single_attempt':True,'accounts':[{'id':1,'name':'A','enabled':True},{'id':2,'name':'B','enabled':True}]})
            if path.endswith('/concurrency'):return httpx.Response(200,json={'per_account':json.loads(request.content)['per_account']})
            if path.endswith('/check'):
                aid=int(path.split('/')[-2]);checks.append(aid)
                return httpx.Response(200,json={'ok':False,'accepted':None,'reason':'unknown'}if preflight_unknown else{'ok':True,'credit':0 if aid==1 else 100})
            if path=='/v1/chat/completions':
                posts.append(request.headers['x-sceneforge-account']);return httpx.Response(200,json={'url':'http://127.0.0.1:8766/output'},headers={'x-sceneforge-account':posts[-1]})
            return httpx.Response(200,content=video.read_bytes(),headers={'content-type':'video/mp4'})
        flow=FlowProvider(vault,work,ledger,lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)))
        flow.configure({'url':'http://127.0.0.1:8766','key':'PRIVATE_ENGINE_KEY_123'})
        config=flow.config();config['models']=['fixture-video'];vault.set_secret('flow-engine',config)
        accounts=FlowAccounts(flow);flow.account_service=accounts
        await accounts.sync()
        for aid in ('flow-engine-1','flow-engine-2'):await accounts.check(aid)
        accounts.pool.select({'mode':'failover','account_id':'flow-engine-1'})
        job={'request_id':'flow-'+str(uuid.uuid4()),'model':'fixture-video','kind':'video','prompt':'private prompt','confirm_send':True,'selection_token':accounts.pool.status()['token']}
        await flow.submit(job);await asyncio.gather(*list(flow.tasks.values()));assert posts==['2'] and flow.lookup(job['request_id'])['result']['account_id']=='flow-engine-2'
        preflight_unknown=True;posts.clear();checks.clear()
        for row in accounts.pool.rows():row['state']='ready';vault.put('accounts',row)
        job.update(request_id='flow-'+str(uuid.uuid4()),selection_token=accounts.pool.status()['token'])
        await flow.submit(job);await asyncio.gather(*list(flow.tasks.values()));assert not posts and checks==[1]
        print('PASS: Gemini/Muse typed quota -> B; selected mode, generic 429, network, input and partial output never rotate. Gemini JSON replay/content conflict and real image verification; evidence sheets; Flow zero-credit preflight -> pinned B, unknown preflight stops. Fixtures only.')


if __name__=='__main__':asyncio.run(main())
