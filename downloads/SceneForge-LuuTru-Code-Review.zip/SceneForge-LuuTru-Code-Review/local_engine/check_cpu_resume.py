"""Real CPU/FFmpeg checkpoint, injected timeout, restart, explicit resume without redoing scene 1."""
import asyncio,json,tempfile,subprocess,time,hashlib
from pathlib import Path
from unittest.mock import patch
from fastapi import FastAPI
from fastapi.testclient import TestClient
from . import cpu_analysis,cpu_worker
from .local_jobs import LocalJobs

def main():
 with tempfile.TemporaryDirectory(prefix='sf-cpu-resume-')as t:
  data=Path(t);video=data/'fixture.mp4'
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=red:s=180x320:r=12:d=1','-f','lavfi','-i','color=blue:s=180x320:r=12:d=1','-filter_complex','[0:v][1:v]concat=n=2:v=1:a=0','-c:v','libx264','-y',str(video)],check=True)
  real_command=cpu_analysis.run_command;real_motion=cpu_worker.measure_motion;interrupted=False
  async def interrupt(*args,**kwargs):
   nonlocal interrupted
   if 'local_engine.cpu_worker'in args and not interrupted:
    interrupted=True;config=json.loads(Path(args[-1]).read_text());calls=0
    def motion(*a,**kw):
     nonlocal calls
     calls+=1
     if calls==2:raise RuntimeError('Interruption fixture after first committed scene')
     return real_motion(*a,**kw)
    def first_pass():
     with patch.object(cpu_worker,'measure_motion',motion):
      try:cpu_worker.analyze(config)
      except RuntimeError:pass
    await asyncio.to_thread(first_pass)
    assert(Path(config['work'])/'checkpoint/scene-0.json').is_file()
    raise asyncio.TimeoutError()
   return await real_command(*args,**kwargs)
  app=FastAPI();jobs=cpu_analysis.install_cpu_analysis(app,data)
  with patch.object(cpu_analysis,'run_command',interrupt),TestClient(app)as c:
   response=c.post('/local-api/analysis/local/upload?duration=2&threshold=27&min_scene=.12&room_id=r',content=video.read_bytes());assert response.status_code==200,response.text
   rid=response.json()['id']
   for _ in range(300):
    state=c.get('/local-api/analysis/local/jobs/'+rid).json()
    if state['state']=='paused':break
    time.sleep(.05)
   assert state['state']=='paused'and state['resumable'],state
  work=data/'cpu-analysis'/rid;checkpoint=work/'checkpoint/scene-0.json';original=checkpoint.read_bytes();mtime=checkpoint.stat().st_mtime_ns
  # Simulate app shutdown while state had still said running. Startup must offer resume,
  # not dispatch it, and retain the same source-bound checkpoint and request ID.
  saved=dict(jobs[rid]);saved['state']='running';LocalJobs(data).write('analysis',saved)
  app2=FastAPI();new_jobs=cpu_analysis.install_cpu_analysis(app2,data)
  assert new_jobs[rid]['state']=='paused'and new_jobs[rid]['recovered']
  with TestClient(app2)as c:
   assert c.post('/local-api/analysis/local/jobs/'+rid+'/resume',json={}).status_code==400
   assert c.post('/local-api/analysis/local/jobs/'+rid+'/resume',json={'confirm':True}).status_code==200
   for _ in range(600):
    state=c.get('/local-api/analysis/local/jobs/'+rid).json()
    if state['state']not in ('queued','running'):break
    # The already committed scene is never rewritten during resume.
    if checkpoint.exists():assert checkpoint.read_bytes()==original and checkpoint.stat().st_mtime_ns==mtime
    time.sleep(.05)
   assert state['state']=='done',state
   assert len(state['result']['scenes'])==2
   assert state['result']['source_sha256']==hashlib.sha256(video.read_bytes()).hexdigest()
   assert not work.exists(),'Successful completion must remove retained source/proxy/checkpoints'
 print('PASS actual CPU/FFmpeg first scene persisted; injected timeout pauses; restart offers explicit same-ID resume; saved scene unchanged, remaining scene measured; source hash matches; completed scratch removed. No model/provider requests.')
if __name__=='__main__':main()
