@echo off
cd /d "%~dp0.."
set "SCENEFORGE_VOICE_BUNDLE=%~1"
if "%SCENEFORGE_VOICE_BUNDLE%"=="" set "SCENEFORGE_VOICE_BUNDLE=%CD%\models\VieNeu-CPU-Offline.zip"
if not exist "%SCENEFORGE_VOICE_BUNDLE%" (
 echo Model ZIP not found. Drag VieNeu-CPU-Offline.zip onto this BAT, or use the full package containing models\VieNeu-CPU-Offline.zip.
 pause
 exit /b 1
)
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r local_engine\requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m local_engine.setup_optional_repos voice
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m local_engine.import_voice_bundle --bundle "%SCENEFORGE_VOICE_BUNDLE%"
if errorlevel 1 goto failed
echo Voice model installed from local ZIP and actual speech verified. No Hugging Face model download needed.
pause
exit /b 0
:failed
echo Voice setup did not finish. Read the error above; original model ZIP is unchanged.
pause
exit /b 1
