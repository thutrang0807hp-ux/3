@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r local_engine\requirements.txt -r local_engine\requirements-cpu.txt
if errorlevel 1 goto failed
if exist models\faster-whisper\model.bin (
 .venv\Scripts\python.exe -m local_engine.prepare_whisper --from-directory models\faster-whisper
 if errorlevel 1 goto failed
)
if exist models\VieNeu-CPU-Offline.zip (
 .venv\Scripts\python.exe -m local_engine.setup_optional_repos voice
 if errorlevel 1 goto failed
 .venv\Scripts\python.exe -m local_engine.import_voice_bundle --bundle models\VieNeu-CPU-Offline.zip
 if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -m local_engine.verify_local_runtime --probe-models
if errorlevel 1 goto failed
echo Local CPU tools and supplied models verified. Online accounts are not tested here.
echo Restart SceneForge. No model weights were downloaded by this script.
pause
exit /b 0
:failed
echo Setup or verification is incomplete. Read the missing component above.
echo If model files are absent, use your package containing the supplied models.
pause
exit /b 1
