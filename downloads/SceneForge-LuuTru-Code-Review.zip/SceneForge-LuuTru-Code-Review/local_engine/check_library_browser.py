"""Live companion + Chromium, real IndexedDB migration and filesystem assets; no AI calls."""
import os,sys,tempfile,subprocess,time,socket,json,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='sf-library-live-',dir='/tmp')as temp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp};proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 base=f'http://127.0.0.1:{port}'
 try:
  for _ in range(150):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=1);break
   except Exception:time.sleep(.1)
  else:raise AssertionError(proc.stderr.read().decode())
  with sync_playwright()as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);context=browser.new_context(viewport={'width':1400,'height':900},accept_downloads=True);page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   # Seed an old browser-only library. The disk library remains empty until reload.
   page.route('**/local-api/library/status',lambda r:r.fulfill(status=404,body='{}',content_type='application/json'));page.goto(base);page.wait_for_function('SceneForgeApp.getState().products.length===1')
   page.evaluate('''async()=>{const p=products[0],blob=new File(['original-media-bytes'],'source.mp4',{type:'video/mp4',lastModified:1234});p.name='Sản phẩm trước chuyển';await io('products','readwrite',p.id,p);const r={id:'migration-room',name:'Phòng cũ',mode:'reference',productId:p.id,stage:'editing',createdAt:Date.now(),refs:clone(p.refs),sceneStates:[]};rooms.push(r);await persistRoom(r);await io('files','readwrite',r.id+':source',blob);await io('files','readwrite','second-room:source',blob);await writeForeign('projects','sceneforge-workflows',r.id,{id:r.id,name:r.name,scenes:[],assetEntries:[['source-asset',blob]],script:[{original:'Lời cũ cần giữ'}]});await writeForeign('drafts','sceneforge-editor-local',r.id,{payload:{items:[{id:'item-1',start:1,duration:2}],custom:'timeline-keep'},media:[{id:'source-asset',file:blob}]});}''')
   page.unroute('**/local-api/library/status');page.reload();page.wait_for_function('SceneForgeStorage.state.active&&SceneForgeApp.getState().rooms.some(r=>r.id==="migration-room")',timeout=30000)
   status=page.evaluate('SceneForgeStorage.api("status")');assert status['assets']==1,status;assert status['assetBytes']==len(b'original-media-bytes');assert status['backups'];assert list((Path(temp)/'SceneForge/sao-luu').glob('trinh-duyet-*.zip'))
   snapshot=page.evaluate('SceneForgeStorage.api("snapshot")');assert any(r['store']=='drafts'for r in snapshot['records']);assert any(r['store']=='projects'for r in snapshot['records']);assert not errors,errors
   # Auto sync sees all host and nested child database writes.
   page.evaluate('''async()=>{const r=roomFor('migration-room');r.name='Đổi tên không đổi file';await persistRoom(r);await SceneForgeStorage.flush();}''');assert page.evaluate('SceneForgeStorage.api("status")')['assets']==1
   page.evaluate('g5OpenSettings("storage")');expect(page.locator('#libraryExport')).to_be_enabled();expect(page.locator('#librarySyncState')).to_contain_text('Đã đồng bộ');page.screenshot(path='/tmp/sceneforge-sqlite-settings.png')
   page.locator('#closeDialog').click();page.evaluate('roomFolder(roomFor("migration-room"))')
   with page.expect_download()as d:page.locator('#libraryRoomZip').click()
   archive=Path(temp)/'room.zip';d.value.save_as(archive);assert archive.stat().st_size>0
   page.locator('#closeDialog').click()
   # Compiled editor has no explicit head tag: its observer must still see native iframe writes.
   page.evaluate('''()=>{const f=document.createElement('iframe');f.id='libraryObserverTest';f.src='native/index.html?room=observer-check&host=1';document.body.append(f);}''');page.wait_for_function('document.querySelector("#libraryObserverTest")?.contentWindow?.IDBObjectStore?.prototype.__sfStorage===true')
   native=page.locator('#libraryObserverTest').element_handle().content_frame();native.evaluate('''async()=>{const db=await new Promise((ok,no)=>{const r=indexedDB.open('sceneforge-editor-local',1);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error);});await new Promise((ok,no)=>{const tx=db.transaction('drafts','readwrite');tx.objectStore('drafts').put({payload:{marker:'native-observed'},media:[]},'observer-check');tx.oncomplete=ok;tx.onerror=()=>no(tx.error);});db.close();}''');page.wait_for_function('SceneForgeStorage.state.dirty>0');page.evaluate('SceneForgeStorage.flush()');assert any(r['key']=='observer-check'for r in page.evaluate('SceneForgeStorage.api("snapshot")')['records']);page.locator('#libraryObserverTest').evaluate('(n)=>n.remove()')
   # A fresh browser profile restores metadata AND real files before app init.
   context.close();context=browser.new_context(viewport={'width':1400,'height':900});page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);page.wait_for_function('SceneForgeApp.getState().rooms.some(r=>r.id==="migration-room")',timeout=30000)
   actual=page.evaluate('''async()=>{const blob=await io('files','readonly','migration-room:source'),w=await workflowRecord('migration-room'),e=await readEditorDraft('migration-room');return{type:blob.type,name:blob.name,bytes:await blob.text(),script:w.script,timeline:e.payload,media:await e.media[0].file.text()};}''');assert actual['bytes']=='original-media-bytes'and actual['media']==actual['bytes'];assert actual['name']=='source.mp4';assert actual['script'][0]['original']=='Lời cũ cần giữ';assert actual['timeline']['custom']=='timeline-keep'
   # A failed disk save leaves dirty browser work recoverable on reload.
   page.route('**/local-api/library/snapshot',lambda r:r.abort()if r.request.method=='POST'else r.continue_());page.evaluate('''async()=>{const r=roomFor('migration-room');r.name='Sửa lúc mất kết nối';await persistRoom(r);try{await SceneForgeStorage.flush();}catch{};}''');assert page.evaluate('SceneForgeStorage.state.dirty')>0;page.unroute('**/local-api/library/snapshot');page.reload();page.wait_for_function('SceneForgeApp.getState().rooms.some(r=>r.name==="Sửa lúc mất kết nối")',timeout=30000);page.evaluate('SceneForgeStorage.flush()');snap=page.evaluate('SceneForgeStorage.api("snapshot")');assert next(r['value']['name']for r in snap['records']if r['store']=='rooms')=='Sửa lúc mất kết nối'
   # 200 metadata-only rooms: measure actual board/render + durable checkpoint on this machine.
   measured=page.evaluate('''async()=>{const start=performance.now(),p=products[0];for(let i=0;i<200;i++){const r={id:'load-'+i,name:'Video '+i,mode:'photos',productId:p.id,stage:'editing',createdAt:Date.now(),sceneStates:[],refs:clone(p.refs)};rooms.push(r);await io('rooms','readwrite',r.id,r);}render();await SceneForgeStorage.flush();return{ms:performance.now()-start,count:rooms.length};}''');assert measured['count']>=201;print('Measured 200 metadata rooms render + checkpoint:',round(measured['ms']),'ms')
   # Foreign writer changes revision. This browser must not overwrite it.
   page.evaluate('''async()=>{const s=await SceneForgeStorage.api('snapshot');await SceneForgeStorage.api('snapshot',{revision:s.revision,records:s.records});const r=roomFor('migration-room');r.name='Giữ riêng bản trình duyệt';await persistRoom(r);try{await SceneForgeStorage.flush();}catch{};}''');assert not page.evaluate('SceneForgeStorage.state.active');assert 'khác' in page.evaluate('SceneForgeStorage.state.error');assert page.evaluate('roomFor("migration-room").name')=='Giữ riêng bản trình duyệt'
   assert not errors,errors;context.close();browser.close()
  print('PASS live migration from browser-only data with full ZIP before checkpoint; actual byte dedup, settings controls and room ZIP; fresh-profile restore of File/transcript/timeline/media; offline dirty recovery; foreign-revision conflict preserves browser work. No provider calls.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
