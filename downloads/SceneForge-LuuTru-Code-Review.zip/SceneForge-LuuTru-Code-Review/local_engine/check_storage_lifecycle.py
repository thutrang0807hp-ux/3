"""Real SQLite/files: explicit purge, leases, shared refs, restore and interruption."""
import json,time,tempfile,os,subprocess
from pathlib import Path
from unittest.mock import patch
from .library import Library,Conflict

def main():
 with tempfile.TemporaryDirectory(prefix='sf-storage-lifecycle-')as t:
  root=Path(t);lib=Library(root)
  def asset(name,mime='video/mp4'):
   path=root/(name+'.bin')
   if name=='final':subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=90x160:r=10:d=0.3','-c:v','libx264','-f','mp4',str(path)],check=True)
   else:path.write_bytes((name+'-data').encode()*100)
   return lib.add_file(path,mime)['hash']
  def marker(h):return {'$sf':'blob','hash':h,'type':'video/mp4'}
  def room(r):return {'db':'sceneforge-app-shell','store':'rooms','key':r,'value':{'id':r,'name':r,'stage':'exported','exportedAt':123,'archivePolicy':{}}}
  def file(r,suffix,h):return {'db':'sceneforge-app-shell','store':'files','key':r+suffix,'value':marker(h)}
  source,final,shared=asset('source'),asset('final'),asset('shared')
  records=[room('r'),room('other'),file('r',':source',source),file('r',':export',final),file('other',':clip',shared),{'db':'sceneforge-workflows','store':'projects','key':'r','value':{'id':'r','script':[{'original':'source','translation':'dịch','newText':'kịch bản'}],'scenes':[],'assetEntries':[]}}]
  snap=lib.commit(records,0);backup=lib.backups()[0]['name']
  plan=lib.lifecycle.plan('r','compact',snap['revision'],0)
  try:lib.lifecycle.execute({**plan,'confirm':False});raise AssertionError('unconfirmed purge')
  except ValueError:pass
  result=lib.lifecycle.execute({**plan,'confirm':True})
  assert result['freed_bytes']>0 and not lib.asset_path(source).exists(),result
  assert lib.asset_path(final).is_file()and lib.asset_path(shared).is_file()
  assert any(r['value'].get('archiveText',{}).get('workflow',{}).get('script')for r in result['snapshot']['records']if r['store']=='rooms'and r['key']=='r')
  restored=lib.restore(backup,result['snapshot']['revision']);assert any(r['key']=='other'for r in restored['records']);assert any(r['value'].get('restoredReleased')for r in restored['records']if r['store']=='rooms')
  # Delete tombstone never resurrects the room from an older library backup.
  plan=lib.lifecycle.plan('r','delete',restored['revision'],0);deleted=lib.lifecycle.execute({**plan,'confirm':True});again=lib.restore(backup,deleted['snapshot']['revision'])
  assert not any(r['store']=='rooms'and r['key']=='r'for r in again['records'])
  assert any(r['key']=='other'for r in again['records'])
  # A repeated upload of an old deduplicated file refreshes protection.
  temp=asset('temp');snap=lib.commit([room('q'),file('q',':source',temp)],again['revision']);lib.add_file(root/'temp.bin')
  plan=lib.lifecycle.plan('q','delete',snap['revision'],0);held=lib.lifecycle.execute({**plan,'confirm':True});assert held['protected_files']and lib.asset_path(temp).exists()
  with lib.db()as db:db.execute('DELETE FROM upload_lease WHERE hash=?',(temp,))
  lib.lifecycle.process(held['op_id']);assert not lib.asset_path(temp).exists()
  # Quarantine is recoverable by a new committed reference, without a second upload.
  revival=asset('revival');snap=lib.commit([room('q2'),file('q2',':source',revival)],lib.snapshot()['revision'])
  plan=lib.lifecycle.plan('q2','delete',snap['revision'],7);waiting=lib.lifecycle.execute({**plan,'confirm':True});assert waiting['waiting_files']==1 and waiting['freed_bytes']==0
  assert lib.read_asset_path(revival).is_file()and not lib.asset_path(revival).exists()
  lib.commit([room('new'),file('new',':clip',revival)],waiting['snapshot']['revision']);assert lib.asset_path(revival).exists()
  # A shared hash and a key referenced by another room survive whole-room deletion.
  current=lib.snapshot();rows=current['records']+[room('d'),file('d',':shared',shared),{'db':'sceneforge-workflows','store':'projects','key':'new','value':{'id':'new','sharedKey':'d:shared'}}]
  snap=lib.commit(rows,current['revision']);plan=lib.lifecycle.plan('d','delete',snap['revision'],0);res=lib.lifecycle.execute({**plan,'confirm':True})
  assert lib.asset_path(shared).exists()and any(r['key']=='d:shared'for r in res['snapshot']['records'])
  # Crash between rename and metadata completion: resume removes once, no missing asset row.
  crash=asset('crash');snap=lib.commit([room('c'),file('c',':source',crash)],res['snapshot']['revision']);plan=lib.lifecycle.plan('c','delete',snap['revision'],0);original=os.replace
  def interrupted(a,b):original(a,b);raise OSError('simulated interruption after rename')
  with patch('local_engine.storage_lifecycle.os.replace',side_effect=interrupted):pending=lib.lifecycle.execute({**plan,'confirm':True})
  assert pending['errors']and lib.read_asset_path(crash).exists()
  resumed=lib.lifecycle.process(pending['op_id']);assert resumed['freed_bytes']>0 and not lib.asset_path(crash).exists()
  assert lib.lifecycle.process(pending['op_id'])['freed_bytes']==resumed['freed_bytes']
  # A waiting whole-project deletion can be cancelled atomically, retaining the same project ID.
  cancel=asset('cancel');snap=lib.commit([room('undo'),file('undo',':source',cancel)],lib.snapshot()['revision'])
  plan=lib.lifecycle.plan('undo','delete',snap['revision'],7);waiting=lib.lifecycle.execute({**plan,'confirm':True})
  restored=lib.lifecycle.cancel_delete(waiting['op_id'],True);assert any(r['key']=='undo'for r in restored['snapshot']['records'])and lib.asset_path(cancel).exists()
  with lib.db()as db:assert not db.execute('SELECT 1 FROM deleted_room WHERE room_id=?',('undo',)).fetchone()
  # Published exports remain by default; explicit selection deletes only registered, unchanged copies.
  published=asset('published');snap=lib.commit([room('pub'),file('pub',':export',published)],lib.snapshot()['revision'])
  output_files=list(lib.output_root().rglob('*.mp4'));assert output_files
  plan=lib.lifecycle.plan('pub','delete',snap['revision'],0,True);assert plan['published_files']
  selected=[Path(x['path'])if Path(x['path']).is_absolute()else lib.root/x['path']for x in plan['published_files']]
  res=lib.lifecycle.execute({**plan,'confirm':True});assert not any(p.exists()for p in selected)
  assert all(p.exists()for p in output_files if p not in selected)
  assert lib.status()['missingAssets']==0
  # Backup-only protection temporarily rehouses a quarantine file, then automatically retries after rotation.
  held_hash=asset('backup-held');snap=lib.commit([room('old-owner'),file('old-owner',':source',held_hash)],lib.snapshot()['revision']);held_backup=lib.backup()
  snap=lib.commit([room('release-owner'),file('release-owner',':source',held_hash)],snap['revision']);plan=lib.lifecycle.plan('release-owner','delete',snap['revision'],7);hold=lib.lifecycle.execute({**plan,'confirm':True})
  blocked=lib.lifecycle.expedite(hold['op_id'],True);assert blocked['protected_files']and lib.asset_path(held_hash).is_file()
  # Only this fixture backup contains old-owner's reference; simulate its retention rotation.
  (lib.root/'sao-luu'/held_backup).unlink();again=lib.lifecycle.process(hold['op_id']);assert not lib.asset_path(held_hash).exists()and again['freed_bytes']>0
  # Whole-library ZIP carries release/deletion policy to a fresh machine.
  try:lib.bundle();raise AssertionError('waiting restore data silently omitted from ZIP')
  except ValueError:pass
  with lib.db()as db:waiting_ids=[r[0]for r in db.execute("SELECT id FROM purge_op WHERE state!='cancelled' AND due>? AND restore_data!='{}'",(time.time(),))]
  for op in waiting_ids:lib.lifecycle.expedite(op,True)
  bundle=lib.bundle();newpc=Library(root/'new-pc');moved=newpc.import_bundle(bundle,0)
  assert moved['library_id']==lib.snapshot()['library_id']and moved['lifecycle']['deleted']==lib.snapshot()['lifecycle']['deleted']
  # Healthy rooms can be restored explicitly when an unrelated room has unexpected missing media.
  broken,healthy=asset('broken'),asset('healthy');snap=lib.commit([room('broken-room'),room('healthy-room'),file('broken-room',':source',broken),file('healthy-room',':source',healthy)],lib.snapshot()['revision']);backup_partial=lib.backup();lib.asset_path(broken).unlink()
  try:lib.restore(backup_partial,snap['revision']);raise AssertionError('silent partial restore')
  except ValueError:pass
  partial=lib.restore(backup_partial,snap['revision'],True);assert partial['restore_report']['skipped_rooms']==['broken-room']and any(r['key']=='healthy-room'for r in partial['records'])

 print('PASS: actual backup-protected media freed after explicit compact; final/text/shared preserved; deletion tombstone; fresh upload lease; quarantine revival; crash/retry idempotence; no missing asset metadata.')
if __name__=='__main__':main()
