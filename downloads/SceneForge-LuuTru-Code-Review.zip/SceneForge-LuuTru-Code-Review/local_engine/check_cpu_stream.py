"""Actual 200 MiB MP4 transport and proxy processing; not a PC benchmark."""
import hashlib,json,os,struct,subprocess,tempfile,time
from pathlib import Path

def main():
    with tempfile.TemporaryDirectory()as tmp:
        root=Path(tmp);os.environ['SCENEFORGE_LOCAL_DATA']=str(root/'data')
        from fastapi.testclient import TestClient
        from . import server
        source=root/'large.mp4'
        subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=1080x1920:r=30:d=0.5','-c:v','libx264','-preset','ultrafast',str(source)],check=True)
        # ISO BMFF permits free atoms. Padding tests the real byte path without
        # representing this short synthetic video as a realistic 200 MiB movie.
        extra=200*1024**2-source.stat().st_size
        with source.open('ab')as out:
            out.write(struct.pack('>I4s',extra,b'free'));remaining=extra-8
            while remaining:
                part=min(1024**2,remaining);out.write(b'\0'*part);remaining-=part
        with source.open('rb')as handle:digest=hashlib.file_digest(handle,'sha256').hexdigest()
        with TestClient(server.app)as client:
            client.get('/');h={'X-SceneForge-Local':'1','Content-Type':'application/octet-stream'}
            def chunks():
                with source.open('rb')as handle:
                    while block:=handle.read(1024**2):yield block
            response=client.post('/local-api/analysis/local/upload?duration=0.5&ocr=false&transcribe=false&room_id=stream-fixture',headers=h,content=chunks())
            assert response.status_code==200,response.text
            rid=response.json()['id'];deadline=time.monotonic()+120
            while time.monotonic()<deadline:
                job=client.get('/local-api/analysis/local/jobs/'+rid).json()
                if job['state']in ('done','error'):break
                time.sleep(.1)
            assert job['state']=='done',job
            result=job['result'];assert result['source_sha256']==digest and result['proxy']['fps']==24
            assert source.stat().st_size==200*1024**2 and not list((root/'data/cpu-analysis').glob('upload-*'))and not list((root/'data/cpu-analysis').glob('job-*'))
            Path('artifacts/cpu-stream-real-check.json').write_text(json.dumps({'upload_bytes':source.stat().st_size,'source_sha256':digest,'proxy':result['proxy'],'provider_requests':result['provider_requests'],'fixture':'0.5 second HD MP4 padded with ISO BMFF free atom; transport test only, not runtime benchmark'},indent=2))
            print('PASS: actual 200 MiB binary MP4 upload -> FFmpeg proxy -> local analysis, source checksum unchanged, all temp uploads/proxy removed. Padded synthetic transport fixture; no performance claim.')

if __name__=='__main__':main()
