"""A missing/stale/invalid job cannot block independent results; no auto POST."""
import base64,io,json
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from threading import Thread
from PIL import Image
from playwright.sync_api import sync_playwright

def main():
 class Quiet(SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 root=Path(__file__).resolve().parents[1];s=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=s.serve_forever,daemon=True).start()
 picture=io.BytesIO();Image.new('RGB',(90,160),'blue').save(picture,format='PNG');raw=picture.getvalue();image='data:image/png;base64,'+base64.b64encode(raw).decode();records={};writes=[]
 def route(r):
  path=r.request.url.split('/local-api/')[1]
  if path.startswith('requests/')and path.endswith('/correct-json'):
   writes.append(path);return r.fulfill(json={'saved':True})
  if path.endswith('/reconcile'):return r.fulfill(json={'state':'unknown','store_id':'fixture-store','reconciliation':'unknown'})
  if path.startswith('requests/')and path.endswith('/abandon'):writes.append(path);return r.fulfill(json={'released':True,'generation_requested':False})
  if '/jobs/'in path:
   row=records.get(path.split('/')[-1])
   if row is None:return r.fulfill(status=404,json={'detail':'not found'})
   return r.fulfill(json=row)
  if '/files/'in path:return r.fulfill(body=raw,content_type='image/png')
  if r.request.method=='POST':writes.append(path)
  return r.fulfill(json={})
 try:
  with sync_playwright()as pw:
   b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.route('**/local-api/**',route);p.on('dialog',lambda d:d.accept())
   p.goto(f'http://127.0.0.1:{s.server_port}/workflow.html');p.wait_for_function('!!window.SceneForgeWorkflow')
   rows=p.evaluate('''async image=>{project=blankProject();project.source={poster:image};project.scenes=[0,1,2].map(i=>sceneRecord(i,i+1,i,[image]));project.cloudJobs=[];for(const [i,s]of project.scenes.entries())project.cloudJobs.push({id:'job-'+i,provider:'gemini-chat',sceneId:s.id,part:'',kind:'image',state:'submitted',signature:await directSignature(s,'','image')});project.scenes[1].promptFrame.en='changed after send';render();return project.cloudJobs.map(j=>j.id);}''',image)
   for rid in rows[1:]:records[rid]={'state':'done','store_id':'fixture-store','result':{'mime_type':'image/png','account_id':'A'}}
   p.evaluate('directRecover()');assert p.evaluate('project.cloudJobs[0].state==="missing"&&project.cloudJobs[1].state==="stale"&&project.cloudJobs[2].state==="imported"&&project.scenes[2].frames.length===1')
   p.evaluate('directRecover()');assert not writes and p.evaluate('project.scenes[2].frames.length===1')
   p.evaluate('abandonWorkflowJob(project.cloudJobs[0])');assert p.evaluate('project.cloudJobs[0].state==="abandoned"&&project.jobAudit.length===1');assert writes==['requests/job-0/abandon']
   p.evaluate('''()=>{const j={id:'x',state:'prepared'};jobPostFailure(j,{detail:{submitted:false,request_id:'x',store_id:'store'},message:'queue full'});if(j.state!=='not_submitted')throw Error('receipt ignored');const k={id:'x'};jobPostFailure(k,{status:429,message:'uncertain'});if(k.state!=='unknown')throw Error('unsafe status inference');}''')
   rows=p.evaluate('''()=>{project.scenes=[0,1,2,3].map(i=>sceneRecord(i,i+1,i,['IMAGE']));project.referencePromptJobs=project.scenes.map((s,i)=>({id:'prompt-'+i,sceneId:s.id,stage:'image',state:'submitted',signature:referencePromptSignature(s,'image')}));return project.referencePromptJobs.map(j=>j.id);}''')
   records[rows[0]]={'state':'failed'};records[rows[1]]={'state':'done','result':{'text':'broken json'}}
   for rid in rows[2:]:records[rid]={'state':'done','result':{'text':'Here is JSON:\n'+json.dumps({'promptFrame':{'vi':'Khung thử','en':'Good frame'}})}}
   p.evaluate('recoverReferencePrompts()');assert p.evaluate('project.referencePromptJobs[0].state==="failed"&&project.referencePromptJobs[1].state==="invalid"&&project.referencePromptJobs[2].state==="done"&&project.referencePromptJobs[3].state==="done"')
   p.evaluate("recoverReferencePrompts('prompt-3')");p.locator('#applyReferencePrompt').click();p.wait_for_function('!document.querySelector("#modal").open');assert p.evaluate('project.scenes[3].promptFrame.en==="Good frame"&&!project.scenes[2].promptFrame.en')
   p.evaluate("recoverReferencePrompts('prompt-1')");p.locator('#referenceRawJson').fill(json.dumps({'promptFrame':{'vi':'Sửa tay','en':'Corrected without AI'}}));p.locator('#referenceSaveJson').click();p.locator('#applyReferencePrompt').click();p.wait_for_function('!document.querySelector("#modal").open');assert p.evaluate('project.scenes[1].promptFrame.en==="Corrected without AI"')
   assert writes==['requests/job-0/abandon']and not errors,(writes,errors)
   records['gchat-analysis-fixture']={'state':'done','result':{'kind':'text','text':'{"scenes": []}'}}
   p.evaluate('''()=>{project.cloudJobs=[{id:'flow-fixture',provider:'flow',kind:'video',state:'unknown'}];project.referencePromptJobs=[];project.analysis.aiRequest={batches:[{id:'gchat-analysis-fixture',source:'gemini_chat',state:'invalid'}]};workflowJobsDialog();}''')
   p.locator('[data-analysis-json="1"]').click();p.locator('#analysisRawJson').fill('{"scenes": []}');p.locator('#saveAnalysisJson').click();p.wait_for_function('!document.querySelector("#modal").open');assert p.evaluate('project.analysis.aiRequest.batches[0].state==="submitted"')
   p.evaluate('pollWorkflowResults()');assert p.evaluate('project.analysis.aiRequest.batches[0].state==="done"')
   p.evaluate('workflowJobsDialog()');p.locator('[data-reconcile-job="0"]').click();p.wait_for_timeout(100)
   assert writes==['requests/job-0/abandon','requests/gchat-analysis-fixture/correct-json']and not errors,(writes,errors);b.close()
   print('PASS: missing/stale first jobs do not block import; no inference from 429/404; manual release makes no generation; failed prompts synchronize; multiple ready results selectable; invalid JSON corrected/applied without a provider POST.')
 finally:s.shutdown()

if __name__=='__main__':main()
