"""Shared Muse account selection; provider runner is a fixture, never live."""
import asyncio
import json
import subprocess
import tempfile
import uuid
from pathlib import Path

import httpx
from fastapi import HTTPException
from .muse_provider import MuseProvider
from .request_ledger import RequestLedger
from .vault import Vault


async def main():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        video = root / 'fixture.mp4'
        subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'color=blue:s=90x160:r=10:d=0.5',
                        '-c:v', 'libx264', str(video)], check=True)
        vault, ledger = Vault(root), RequestLedger(root)
        for index in range(2):
            aid = 'account-' + str(index)
            vault.put('accounts', {'id': aid, 'service': 'muse', 'name': 'Fixture ' + str(index),
                      'enabled': True, 'session_verified': True, 'state': 'ready', 'active': index == 0})
            vault.set_secret('muse-session:' + aid, {'identity': aid})
        gate, calls = asyncio.Event(), []
        async def runner(body):
            calls.append(body['session']['identity'])
            await gate.wait()
            Path(body['output']).write_bytes(video.read_bytes())
            return {'ok': True}
        service = MuseProvider(vault, root, ledger, runner)
        def job(selection=None):
            return {'request_id': 'muse-' + str(uuid.uuid4()), 'prompt': 'scene fixture', 'kind': 'video',
                    'references': [], 'confirm_send': True, 'selection_token': (selection or service.selection())['token']}
        initial = service.selection()
        assert initial['account_id'] == 'account-0' and initial['mode'] == 'selected'
        first, queued = job(), job()
        await service.submit(first)
        await service.submit(queued)
        await asyncio.sleep(.02)
        assert calls == ['account-0']
        service.select({'mode': 'selected', 'account_id': 'account-1'})
        changed = service.status()['selection']
        assert changed['account_id'] == 'account-1' and changed['token'] != initial['token']
        for rejected in (job(initial), {**job(), 'account_id': 'account-0'}):
            try:
                await service.submit(rejected)
                raise AssertionError('stale review/per-room override accepted')
            except HTTPException as e:
                assert e.status_code == 409 and e.detail['submitted'] is False
            receipt=service.lookup(rejected['request_id'])
            assert receipt['state']=='not_submitted'and receipt['submitted'] is False
            assert rejected['request_id'] not in service.tasks
        second = job()
        await service.submit(second)
        await asyncio.sleep(.02)
        assert calls == ['account-0', 'account-1']
        gate.set()
        await asyncio.gather(*list(service.tasks.values()))
        assert service.lookup(first['request_id'])['result']['account_id'] == 'account-0'
        assert service.lookup(queued['request_id'])['result']['account_id'] == 'account-0'
        assert service.lookup(second['request_id'])['result']['account_id'] == 'account-1'
        # Disabled selected accounts never silently switch to another one.
        row = service.account('account-1')
        row['enabled'] = False
        vault.put('accounts', row)
        assert not service.status()['configured']
        try:
            await service.submit(job())
            raise AssertionError('disabled selected account fell back')
        except HTTPException as e:
            assert e.status_code == 409
        row['enabled'] = True
        vault.put('accounts', row)
        service.select({'mode': 'balanced'})
        assert (vault.secret('rotation') or {})['muse'] is True
        gate.clear()
        balanced = [job() for _ in range(4)]
        for body in balanced:
            await service.submit(body)
        assert set(service.phases.values()) == {'account-0', 'account-1'}
        gate.set()
        await asyncio.gather(*list(service.tasks.values()))
        service.select({'mode': 'selected', 'account_id': 'account-0'})
        assert (vault.secret('rotation') or {})['muse'] is False
        reopened = MuseProvider(Vault(root), root, RequestLedger(root), runner)
        assert reopened.selection() == service.selection()
        # Exercise the actual Settings routes against the same provider instance.
        import os
        os.environ['SCENEFORGE_LOCAL_DATA'] = str(root / 'server')
        from . import server
        original = server.MUSE_PROVIDER
        server.MUSE_PROVIDER = service
        # The top-level status also reads server.VAULT; point it at the fixture vault.
        previous_vault = server.VAULT
        server.VAULT = vault
        try:
            async with httpx.AsyncClient(transport=httpx.ASGITransport(server.app), base_url='http://testserver') as client:
                await client.get('/')
                headers = {'X-SceneForge-Local': '1'}
                response = await client.post('/local-api/accounts/use', headers=headers, json={'id': 'account-1'})
                assert response.status_code == 200, response.text
                assert service.status()['selection']['account_id'] == 'account-1'
                response = await client.post('/local-api/rotation', headers=headers, json={'service': 'muse', 'enabled': True})
                assert response.status_code == 200 and service.selection()['mode'] == 'balanced'
                response = await client.post('/local-api/rotation', headers=headers, json={'service': 'muse', 'enabled': False})
                assert response.status_code == 200 and service.selection()['mode'] == 'selected'
                assert service.selection()['account_id'] == 'account-1'
        finally:
            server.MUSE_PROVIDER, server.VAULT = original, previous_vault
        print('PASS: Settings account/mode controls actual dispatch; queued jobs stay pinned; stale reviews and room overrides rejected before claim; disabled account never falls back; balanced mode explicit; choice survives reopen. Fixtures only.')


if __name__ == '__main__':
    asyncio.run(main())
