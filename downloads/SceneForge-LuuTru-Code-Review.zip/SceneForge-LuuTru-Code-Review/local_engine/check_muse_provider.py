"""Transport fixtures only; no account login or real Muse generation."""
import asyncio
import base64
import io
import json
import subprocess
import tempfile
import uuid
from pathlib import Path

from fastapi import HTTPException
from PIL import Image
from .muse_provider import MuseProvider, install_muse_provider
from .request_ledger import RequestLedger
from .vault import Vault


async def main():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        fixture = root / 'fixture.mp4'
        subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i',
                        'color=blue:s=90x160:r=10:d=0.5', '-c:v', 'libx264', str(fixture)], check=True)
        vault, ledger = Vault(root), RequestLedger(root)
        active, maximum, calls = {}, 0, []
        gate = asyncio.Event()
        gate.set()
        mode = 'ok'
        async def runner(body):
            nonlocal maximum
            calls.append(body['operation'])
            op = body['operation']
            if op in ('login_start', 'import'):
                return {'ok': True, 'session': {'cookies.json': [{'name': 'private', 'value': 'COOKIE_SENTINEL'}],
                        **({'pending': {'csrf_token': 'PRIVATE_CSRF'}} if op == 'login_start' else {})}}
            if op == 'login_confirm':
                assert body['session']['pending']['csrf_token'] == 'PRIVATE_CSRF'
                return {'ok': True, 'authenticated': True, 'session': {'cookies.json': body['session']['cookies.json']}}
            if op == 'check':
                return {'ok': True}
            assert op == 'generate' and body['references'][0]['mime_type'] == 'image/png'
            account = body['session']['cookies.json'][0]['value']
            active[account] = active.get(account, 0) + 1
            assert active[account] == 1, 'same account overlapped'
            maximum = max(maximum, sum(active.values()))
            try:
                await gate.wait()
                if mode == 'timeout':
                    raise TimeoutError('PRIVATE_CSRF COOKIE_SENTINEL PRIVATE_PROMPT')
                Path(body['output']).write_bytes(b'not a video' if mode == 'invalid' else fixture.read_bytes())
                return {'ok': True, 'generated': True}
            finally:
                active[account] -= 1

        service = MuseProvider(vault, root, ledger, runner)
        r = await service.login({'email': 'fixture@example.com'})
        assert r['awaiting_otp']
        aid = r['id']
        await service.confirm({'id': aid, 'otp': '123456'})
        assert service.status()['configured'] and not service.status()['generation_verified']
        # Three accounts, including different encrypted cookie state per account.
        ids = [aid]
        for index in range(2):
            r = await service.login({'email': f'fixture{index}@example.com', 'cookies': [
                {'name': 'fixture', 'value': 'fixture-' + str(index), 'domain': '.muse.ai'}]})
            ids.append(r['id'])
            vault.set_secret('muse-session:' + r['id'], {'cookies.json': [{'name': 'x', 'value': 'fixture-' + str(index)}]})
        pic = io.BytesIO()
        Image.new('RGB', (12, 20)).save(pic, format='PNG')
        def body(account=None):
            return {'request_id': 'muse-' + str(uuid.uuid4()), 'kind': 'video', 'prompt': 'PRIVATE_PROMPT',
                    'account_id': account, 'selection_token': service.selection()['token'], 'room_id': 'room-fixture', 'scene_id': 'beat-fixture',
                    'references': [{'mime_type': 'image/png', 'data': base64.b64encode(pic.getvalue()).decode()}],
                    'confirm_send': True}
        for invalid in ({**body(), 'confirm_send': False}, {**body(), 'references': [{'mime_type': 'text/plain', 'data': 'AAAA'}]}):
            try:
                await service.submit(invalid)
                raise AssertionError('invalid input accepted')
            except HTTPException:
                pass
        gate.clear()
        jobs = []
        for account_id in (ids[0], ids[0], ids[1], ids[2]):
            service.select({'mode': 'selected', 'account_id': account_id})
            job = body()
            jobs.append(job)
            await service.submit(job)
        await asyncio.sleep(.04)
        assert maximum == 3 and calls.count('generate') == 3
        try:
            await service.submit(jobs[0])
            raise AssertionError('duplicate accepted')
        except HTTPException as e:
            assert e.status_code == 409
        try:
            service.remove(ids[0])
            raise AssertionError('removed running account')
        except HTTPException:
            pass
        gate.set()
        await asyncio.gather(*list(service.tasks.values()))
        for job in jobs:
            result = service.lookup(job['request_id'])
            assert result['state'] == 'done'
            assert result['result']['scene_id'] == 'beat-fixture'
            assert Path(service.file(job['request_id']).path).read_bytes() == fixture.read_bytes()
        count = calls.count('generate')
        service.select({'mode': 'selected', 'account_id': ids[0]})
        await service.submit(jobs[0])
        assert calls.count('generate') == count
        assert not list(service.root.glob('*.partial'))
        # Failed/ambiguous runs cannot replay the same request identifier.
        for failure in ('timeout', 'invalid'):
            mode = failure
            job = body(ids[0])
            await service.submit(job)
            await asyncio.gather(*list(service.tasks.values()))
            assert service.lookup(job['request_id'])['state'] == 'unknown'
            try:
                await service.submit(job)
                raise AssertionError('unknown request replayed')
            except HTTPException as e:
                assert e.status_code == 409
        for token in ('COOKIE_SENTINEL', 'PRIVATE_CSRF', 'PRIVATE_PROMPT'):
            assert token not in json.dumps(service.status()) + json.dumps(vault.rows('logs'))
        assert b'COOKIE_SENTINEL' not in vault.path.read_bytes()
        assert b'PRIVATE_CSRF' not in vault.path.read_bytes()
        # Interruption remains unknown after reopening the durable ledger.
        mode = 'ok'
        gate.clear()
        job = body(ids[0])
        await service.submit(job)
        await asyncio.sleep(.02)
        await service.close()
        recovered = MuseProvider(vault, root, RequestLedger(root), runner)
        assert recovered.lookup(job['request_id'])['state'] == 'unknown'
        service.remove(ids[0])
        assert vault.secret('muse-session:' + ids[0]) is None
        # FastAPI body binding: login/confirm must accept JSON rather than query strings.
        import httpx
        from fastapi import FastAPI
        app = FastAPI()
        api = install_muse_provider(app, vault, root, ledger)
        api.runner = runner
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url='http://testserver') as client:
            response = await client.post('/local-api/muse/login', json={'email': 'api@example.com'})
            assert response.status_code == 200, response.text
            response = await client.post('/local-api/muse/confirm', json={'id': response.json()['id'], 'otp': '123456'})
            assert response.status_code == 200, response.text
        print('PASS: encrypted OTP/cookies; JSON routes; refs; 1/account and 3 total; correct scene/file; no duplicate or timeout retry; invalid media rejected; interruption recovery. Fixtures only, no real Muse account requests.')


if __name__ == '__main__':
    asyncio.run(main())
