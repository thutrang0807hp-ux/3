"""Concurrent same-account jobs through actual adapters; no live service claims."""
import asyncio
import json
from pathlib import Path
import subprocess
import tempfile
import uuid
import httpx
from fastapi import HTTPException
from .vault import Vault
from .request_ledger import RequestLedger
from .muse_provider import MuseProvider
from .flow_provider import FlowProvider
from .flow_accounts import FlowAccounts


async def main():
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory);video=root/'fixture.mp4'
        subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=90x160:r=10:d=0.2','-c:v','libx264',str(video)],check=True)
        for name in ('muse','flow'):
            work=root/name;work.mkdir();vault=Vault(work);ledger=RequestLedger(work)
            active=0;peak=0;arrived=asyncio.Event();release=asyncio.Event();calls=[];engine_limits=[]
            async def overlap(identity):
                nonlocal active,peak
                calls.append(identity);active+=1;peak=max(peak,active)
                if active==7:arrived.set()
                try:await release.wait()
                finally:active-=1
            if name=='muse':
                async def runner(body):
                    await overlap(body['prompt']);Path(body['output']).write_bytes(video.read_bytes())
                    return {'ok':True,'session':{'changed':'do not overwrite shared credentials'}}
                provider=MuseProvider(vault,work,ledger,runner)
                vault.put('accounts',{'id':'A','name':'A','service':'muse','enabled':True,'session_verified':True,'state':'ready','active':True})
                vault.set_secret('muse-session:A',{'identity':'A'})
            else:
                async def transport(request):
                    if request.url.path.endswith('/concurrency'):
                        value=json.loads(request.content)['per_account'];engine_limits.append(value)
                        return httpx.Response(200,json={'per_account':value})
                    if request.url.path.endswith('/check'):return httpx.Response(200,json={'ok':True,'credit':1000})
                    if request.url.path=='/v1/chat/completions':
                        assert request.headers['x-sceneforge-account']=='1'
                        body=json.loads(request.content);await overlap(body['messages'][0]['content'][0]['text'] if isinstance(body['messages'][0]['content'],list)else body['messages'][0]['content'])
                        return httpx.Response(200,json={'url':'http://127.0.0.1:8766/output'},headers={'x-sceneforge-account':'1'})
                    return httpx.Response(200,content=video.read_bytes(),headers={'content-type':'video/mp4'})
                provider=FlowProvider(vault,work,ledger,lambda:httpx.AsyncClient(transport=httpx.MockTransport(transport)))
                provider.configure({'url':'http://127.0.0.1:8766','key':'fixture-key-private'})
                config=provider.config();config.update(models=['fixture-video'],account_binding=True);vault.set_secret('flow-engine',config)
                provider.account_service=FlowAccounts(provider)
                vault.put('accounts',{'id':'A','name':'A','service':'flow','engine_id':1,'enabled':True,'session_verified':True,'state':'ready','active':True})
            provider.video_slots.configure({'per_account':7})
            ids=[]
            for i in range(9):
                rid=name+'-'+str(uuid.uuid4());ids.append(rid)
                await provider.submit({'request_id':rid,'kind':'video','model':'fixture-video','prompt':'clip '+str(i),'references':[], 'confirm_send':True,'selection_token':provider.status()['selection']['token'],'room_id':'room','scene_id':'scene-'+str(i)})
            try:
                await asyncio.wait_for(arrived.wait(),5)
                assert peak==7 and len(calls)==7,(name,peak,calls)
                try:provider.video_slots.configure({'per_account':2},bool(provider.tasks));raise AssertionError('changed while queued')
                except HTTPException as e:assert e.status_code==409
            finally:release.set()
            await asyncio.gather(*list(provider.tasks.values()))
            assert len(calls)==9 and peak==7,(name,peak,len(calls))
            for rid in ids:assert provider.lookup(rid)['state']=='done',provider.lookup(rid)
            if name=='muse':assert vault.secret('muse-session:A')=={'identity':'A'}
            else:assert engine_limits==[7]*9
            # All results have an independent ID and one file each; querying never resends.
            for rid in ids:provider.lookup(rid);assert Path(provider.file(rid).path).is_file()
            assert len(calls)==9
            provider.video_slots.configure({'per_account':12});assert provider.status()['per_account']==12
            print('PASS:',name,'one account: 7 overlapping jobs, 2 queued, 9 distinct results, engine limit acknowledged, no resend, settings idle-only; supports >7. Fixtures only.')


if __name__=='__main__':asyncio.run(main())
