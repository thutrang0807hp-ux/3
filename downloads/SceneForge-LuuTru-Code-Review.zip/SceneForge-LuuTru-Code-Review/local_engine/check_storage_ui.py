"""Browser -> actual local API -> SQLite/files for compact and permanent project delete."""
import base64,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1];video=base64.b64encode((root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()).decode()
 with tempfile.TemporaryDirectory(prefix='sf-storage-ui-')as t:
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':t},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions');page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}")
    page.evaluate('''async raw=>{const media=new Blob([Uint8Array.from(atob(raw),c=>c.charCodeAt(0))],{type:'video/mp4'});for(const id of ['compact-fixture','delete-fixture']){const r={id,name:id,slug:id,productId:products[0].id,mode:'reference',stage:'exported',exportedAt:Date.now(),archived:true};rooms.push(r);await io('rooms','readwrite',id,r);await io('files','readwrite',id+':source',new Blob([id+'-intermediate']));await io('files','readwrite',id+':export',media);await writeForeign('projects','sceneforge-workflows',id,{id,scenes:[],script:[{original:'Original',translation:'Dịch',newText:'Giữ kịch bản'}],assetEntries:[]});}await SceneForgeStorage.flush();render();}''',video)
    page.evaluate("storageCleanupDialog('compact-fixture','compact')");page.locator('#storageDays').select_option('0');page.locator('#storagePreview').click();page.locator('#storageExecute').wait_for();page.locator('#storageExecute').click();assert page.locator('#storageExecuteError').inner_text()=='Cần xác nhận phạm vi trước.'
    page.locator('#storageConfirmRead').check();page.locator('#storageExecute').click();page.wait_for_function("roomFor('compact-fixture')?.archiveState==='final-only'&&SceneForgeStorage.state.active",timeout=60000)
    assert page.evaluate("async()=>!await io('files','readonly','compact-fixture:source')")
    assert page.evaluate("roomFor('compact-fixture').archiveText.workflow.script[0].newText")=='Giữ kịch bản'
    assert page.evaluate("async()=>!!await io('files','readonly','compact-fixture:export')")
    page.evaluate("storageCleanupDialog('delete-fixture','delete')");page.locator('#storageDays').select_option('0');page.locator('#storagePreview').click();page.locator('#storageConfirmRead').check();page.locator('#storageExecute').click();page.wait_for_function("!roomFor('delete-fixture')&&SceneForgeStorage.state.active",timeout=60000)
    assert page.evaluate("async()=>!await io('files','readonly','delete-fixture:export')")
    assert page.evaluate("roomFor('compact-fixture').archiveState")=='final-only'
    # Hash worker and binary persistence use bounded bytes, preserving exact contents.
    binary=page.evaluate('''async()=>{const file=new Blob(['x'.repeat(9*1024*1024)]);const digest=await SceneForgePortable.fingerprintWorker(file);await io('files','readwrite','worker-fixture',file);await io('prefs','readwrite','binary-fixture',new Uint32Array([3,7,4294967295]));await SceneForgeStorage.flush();const snap=await SceneForgeStorage.api('snapshot'),row=snap.records.find(r=>r.store==='prefs'&&r.key==='binary-fixture'),decoded=await SceneForgeStorage.decode(row.value);return {hash:digest.hash,type:row.value.$sf,values:Array.from(decoded)};}''')
    import hashlib
    assert binary['hash']==hashlib.sha256(b'x'*(9*1024*1024)).hexdigest()and binary['type']=='typed-asset'and binary['values']==[3,7,4294967295],binary
    # Working-project cleanup removes an unchosen version, keeps selected/timeline versions.
    page.evaluate('''async raw=>{const clip=new Blob([Uint8Array.from(atob(raw),c=>c.charCodeAt(0))],{type:'video/mp4'}),old=new Blob(['distinct old video fixture'],{type:'video/mp4'}),id='unused-fixture';rooms.push({id,name:id,slug:id,productId:products[0].id,mode:'reference',stage:'editing',archived:true});await io('rooms','readwrite',id,roomFor(id));await writeForeign('projects','sceneforge-workflows',id,{id,cloudJobs:[],script:[],scenes:[{id:'s',chosen:{a:'keep'},frames:[],clips:[{id:'keep',asset:'keep',part:'a'},{id:'old',asset:'old',part:'a'},{id:'timeline',asset:'timeline',part:'b'}]}],assetEntries:[['keep',clip],['old',old],['timeline',clip]]});await writeForeign('drafts','sceneforge-editor-local',id,{payload:{items:[]},media:[{id:'timeline',file:clip}]});await SceneForgeStorage.flush();}''',video)
    page.evaluate("storageCleanupDialog('unused-fixture','unused')");page.locator('#storageDays').select_option('0');page.locator('#storagePreview').click();page.locator('#storageConfirmRead').check()
    with page.expect_navigation(wait_until='domcontentloaded'):
     page.locator('#storageExecute').click()
    page.wait_for_function('SceneForgeStorage.state.active&&!!roomFor("unused-fixture")')
    page.wait_for_function('async()=>{const w=await workflowRecord("unused-fixture");return w?.scenes?.[0]?.clips?.length===2;}')
    versions=page.evaluate('async()=>{const w=await workflowRecord("unused-fixture");return w.scenes[0].clips.map(c=>c.id)}');assert versions==['keep','timeline'],versions
    # The bulk action processes only the selected projects and preserves the existing final.
    page.evaluate('''async()=>{for(const id of ['bulk-one','bulk-two']){rooms.push({id,name:id,slug:id,productId:products[0].id,mode:'reference',stage:'editing',archived:true});await io('rooms','readwrite',id,roomFor(id));await io('files','readwrite',id+':source',new Blob([id]));archiveSelection.add(id);}await SceneForgeStorage.flush();await storageBulk.onclick();}''')
    page.locator('#storageBulkMode').select_option('delete');page.locator('#storageBulkDays').select_option('0');page.locator('#storageBulkAccept').check();page.locator('#storageBulkPreview').click();page.locator('#storageBulkExecute').click();page.wait_for_function('!roomFor("bulk-one")&&!roomFor("bulk-two")&&SceneForgeStorage.state.active')
    assert page.evaluate("!!roomFor('compact-fixture')&&!!roomFor('unused-fixture')")
    page.evaluate("g5OpenSettings('storage')");page.wait_for_function('document.querySelector("#storageBudgetStatus")?.textContent.includes("Ổ còn")')
    page.locator('#storageMinFree').fill('512');page.locator('#storageTempBudget').fill('8192');page.locator('#saveStorageLimits').click();page.wait_for_function('async()=>{const l=await SceneForgeStorage.api("storage-limits");return l.minimum_free_mb===512&&l.temporary_budget_mb===8192;}')
    page.screenshot(path='/tmp/sceneforge-storage-settings-v2.png')
    assert not errors,errors
    browser.close();print('PASS: real browser/API/SQLite explicit confirmation, compact preserves final+script, permanent delete removes own room/files, unrelated final survives, selected/timeline versions protected, bulk action, worker hash/binary round trip, storage limits settings, canonical reload; no provider requests.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()
   err=proc.stderr.read().decode()
   if 'ERROR'in err:print(err[-2500:])
if __name__=='__main__':main()
