@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe (
 echo Run local_engine\start.bat once to create the app environment.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -c "import sys;sys.exit(0 if (3,10) <= sys.version_info[:2] < (3,13) else 1)"
if errorlevel 1 (
 echo Optional CPU tools require Python 3.10, 3.11 or 3.12. The main app is unchanged.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m pip install -r local_engine\requirements-cpu.txt
if errorlevel 1 (
 echo Installation failed. Existing app and files are unchanged.
 pause
 exit /b 1
)
echo CPU libraries installed. Restart SceneForge. Whisper model is NOT downloaded.
echo Optional model download: .venv\Scripts\python.exe -m local_engine.prepare_whisper --model base --download
pause
