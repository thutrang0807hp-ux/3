"""Real file retirement for Photo Studio; preserve timeline/shared/pinned/other slots."""
import tempfile,copy
from pathlib import Path
from .library import Library

def main():
 with tempfile.TemporaryDirectory(prefix='sf-photo-approval-')as tmp:
  lib=Library(Path(tmp));records=[];markers={}
  def media(name):
   path=Path(tmp)/name;path.write_bytes(('photo-fixture-'+name).encode());m={'$sf':'blob',**lib.add_file(path)};markers[name]=m
   key='r:photo-'+name;records.append({'db':'sceneforge-app-shell','store':'files','key':key,'value':m});return key
  clips=[{'id':'a'+str(n),'key':media('a'+str(n)),'part':'a','version':n,'pinned':n==3,'reviewDecision':{'status':'accepted'if n==15 else'rejected'}}for n in range(1,16)]
  clips.append({'id':'b1','key':media('b1'),'part':'b','version':1,'reviewDecision':{'status':'rejected'}})
  frames=[{'id':'f'+str(n),'key':media('f'+str(n)),'version':n}for n in range(1,4)]
  clips[-1]['frameId']='f1'
  beat={'id':'s','seconds':12,'frames':frames,'approvedFrame':'f3','clips':clips,'chosenParts':{'a':'a15','b':'b1'}}
  photo={'beats':[beat],'flowJobs':[],'plan':[]}
  records.append({'db':'sceneforge-app-shell','store':'rooms','key':'r','value':{'id':'r','photoDraft':photo}})
  records.append({'db':'sceneforge-editor-local','store':'drafts','key':'r','value':{'payload':{'items':[{'assetId':'ed1'}],'assets':[{'id':'ed1','workflowKey':'a1'},{'id':'ed2','workflowKey':'a4'}]},'media':[{'id':'ed1','file':markers['a1']},{'id':'ed2','file':markers['a4']}]}})
  records.append({'db':'sceneforge-app-shell','store':'products','key':'p','value':{'sceneBank':[{'id':'bank-shared','key':'r:photo-a2'}]}})
  snap=lib.commit(records,0);lib.backup(daily=False)
  target={'scope':'photo','sceneId':'s','kind':'clip','part':'a','keepId':'a15'}
  plan=lib.lifecycle.plan('r','approved',snap['revision'],0,False,[target]);result=lib.lifecycle.execute({**plan,'confirm':True})
  saved=next(r['value']['photoDraft']for r in result['snapshot']['records']if r['store']=='rooms'and r['key']=='r')
  assert [c['id']for c in saved['beats'][0]['clips']]==['a1','a3','a15','b1']
  for n in range(4,15):assert not lib.asset_path(markers['a'+str(n)]['hash']).exists(),n
  for name in ('a1','a2','a3','a15','b1','f1','f2','f3'):assert lib.asset_path(markers[name]['hash']).exists(),name
  t={'scope':'photo','sceneId':'s','kind':'frame','part':None,'keepId':'f3'}
  plan=lib.lifecycle.plan('r','approved',result['snapshot']['revision'],0,False,[t]);result=lib.lifecycle.execute({**plan,'confirm':True})
  assert not lib.asset_path(markers['f2']['hash']).exists()
  assert lib.asset_path(markers['f1']['hash']).exists() # used by a selected clip
  # The generic unused command must retain selected AND newest clip in every part.
  plan=lib.lifecycle.plan('r','unused',result['snapshot']['revision'],0)
  saved=next(r['value']['photoDraft']for r in plan['records']if r['store']=='rooms'and r['key']=='r')
  assert {'a15','b1'}<={c['id']for c in saved['beats'][0]['clips']}
  try:lib.lifecycle.plan('r','approved',result['snapshot']['revision'],0,False,[{**target,'keepId':'a1'}]);raise AssertionError('Stale approval accepted')
  except ValueError:pass
  try:lib.lifecycle.plan('r','approved',result['snapshot']['revision'],0,False,[target,{**t,'scope':None}]);raise AssertionError('Mixed scope accepted')
  except ValueError:pass
 print('PASS Photo approval: real 15-version retirement, timeline/shared/pinned and other part protected; selected-frame dependency kept; stale/mixed targets rejected; generic unused cleanup preserves every part latest/selected. No provider calls.')
if __name__=='__main__':main()
