@echo off
cd /d "%~dp0\.."
python -c "import sys; assert sys.version_info >= (3,11), 'Python 3.11+ required'"
if errorlevel 1 exit /b 1
python -m local_engine.setup_muse
if errorlevel 1 exit /b 1
echo Muse SDK installed. Open SceneForge locally, choose Video: Muse, then Connect Muse.
echo No real account or generation has been tested by this installer.
pause
