"""Real launcher: occupied port fallback, duplicate launch and stale-lock recovery."""
import json,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='SceneForge chạy thật ',dir='/tmp')as temp:
 env={**os.environ,'SCENEFORGE_LOCAL_DATA':temp,'SCENEFORGE_OPEN_BROWSER':'0'}
 occupied=socket.socket()
 try:occupied.bind(('127.0.0.1',8840));occupied.listen()
 except OSError:occupied.close();occupied=None
 processes=[]
 try:
  for launch in range(2):
   p=subprocess.Popen([sys.executable,'-m','local_engine'],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);processes.append(p)
   for _ in range(100):
    try:
     info=json.loads((Path(temp)/'instance.json').read_text());port=info['port']
     with urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2)as response:assert json.load(response)['service']=='sceneforge-local'
     if info['pid']==p.pid:break
    except (OSError,ValueError,KeyError):pass
    if p.poll()is not None:raise AssertionError(p.stderr.read().decode())
    time.sleep(.1)
   else:raise AssertionError('launcher not ready')
   if occupied:assert port!=8840
   other=subprocess.run([sys.executable,'-m','local_engine'],cwd=root,env=env,capture_output=True,text=True,timeout=12)
   assert other.returncode==0 and 'đang chạy'in other.stdout,(other.stdout,other.stderr)
   assert json.loads((Path(temp)/'instance.json').read_text())['pid']==p.pid
   p.terminate();p.wait(timeout=10)
  print('PASS actual loopback launcher with occupied port; second launch reuses live URL; shutdown releases OS lock despite leftover metadata; Unicode/space data path. No browser or provider opened.')
 finally:
  for p in processes:
   if p.poll()is None:p.kill();p.wait()
  if occupied:occupied.close()
