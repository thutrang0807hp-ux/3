"""Real CPU/image measurements + mocked provider contract; no live quota/quality claim."""
import os,tempfile,asyncio,json,copy,base64,hashlib
from pathlib import Path
from unittest.mock import patch,AsyncMock
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-v3-test-')
import cv2,numpy as np,httpx
from fastapi.testclient import TestClient
from . import server,ai_providers
server.VAULT.set_secret('ai-routing',{'source':'gemini_api'})
from .speech_guard import classify
from .frame_analysis import checked_input,assemble
from .motion import measure_motion
from .frame_quality import measure
from .video_analysis import VISUAL,MOTION

assert classify('123 456')['status']=='suspect'
assert classify('nào nào nào')['status']=='suspect'
assert classify('你好你好你好')['status']=='suspect'
assert classify('Cảm ơn các bạn đã xem')['status']=='suspect'
assert classify('这是一支适合日常使用的口红')['status']=='clear'
assert classify('Hôm nay tôi giới thiệu sản phẩm mới')['status']=='clear'
assert classify('đúng rồi')['status']=='fragment'
assert classify('Hôm nay tôi giới thiệu sản phẩm mới',.9,-.2)['status']=='suspect'
rng=np.random.default_rng(42);base=cv2.GaussianBlur(rng.integers(0,256,(270,480,3),dtype=np.uint8),(3,3),0)
def fixed(t):
 f=base.copy();x=int(80+70*t);cv2.rectangle(f,(x,100),(x+65,220),(0,0,220),-1);return f
def pan(t):return cv2.warpAffine(base,np.float32([[1,0,-30*t],[0,1,0]]),(480,270),borderMode=cv2.BORDER_REFLECT)
def zoom(t):return cv2.warpAffine(base,cv2.getRotationMatrix2D((240,135),0,1+.12*t),(480,270),borderMode=cv2.BORDER_REFLECT)
fixed_r=measure_motion(fixed,0,2,30);pan_r=measure_motion(pan,0,2,30);zoom_r=measure_motion(zoom,0,2,30);blank=measure_motion(lambda t:np.zeros_like(base),0,2,30)
assert fixed_r['reliable']and fixed_r['kind']=='static',fixed_r
assert pan_r['reliable']and 'lia phải'in ' '.join(pan_r['labels']),pan_r
assert zoom_r['reliable']and 'zoom vào'in zoom_r['labels'],zoom_r
assert not blank['reliable']and blank['labels']==['không đo chắc']
def encoded(image,ext='.jpg'):
 ok,b=cv2.imencode(ext,image);assert ok
 return 'data:image/'+('jpeg'if ext=='.jpg'else'png')+';base64,'+base64.b64encode(b).decode(),bytes(b)
image,raw=encoded(base)
body={'duration':2,'scenes':[{'start':0,'end':1,'frames':[image]},{'start':1,'end':2,'frames':[image]}],
      'lines':[{'id':'one','start':0,'end':.5,'original':'Hôm nay tôi giới thiệu sản phẩm mới'},{'id':'two','start':1,'end':1.5,'original':'123 456'}]}
scenes,source,eligible,images=checked_input(body);assert len(eligible)==1 and source[1]['scene_code']=='C02'
def response(table):
 return {'scenes':[{'code':s['code'],'line_ids':s['line_ids'],'description':'Khung đo thử.','hasPerson':None,'faceTalking':None,'hasProduct':None,'competitorLogo':None,
          'visual':{l:{k:'Quan sát thử.'for k in VISUAL}for l in ('vi','en')},'motion':{l:{k:''for k in MOTION}for l in ('vi','en')},'promptFrame':{'vi':'Giữ bố cục.','en':'Preserve composition.'}}for s in table['scenes']],
         'lines':{l['code']:{'translation':'Dịch thử.','newText':'Lời thử.','faceTalking':False}for l in table['lines']}}
valid=response({'scenes':scenes,'lines':eligible});out=assemble(valid,scenes,source,eligible)
assert out['can_apply']and out['quarantined']==1 and out['script'][1]['newText']==''
assert out['script'][0]['original']==body['lines'][0]['original']and out['script'][0]['end']==.5
for corrupt in ('timestamp','omit','unknown','duplicate','unhashable','source'):
 r=copy.deepcopy(valid)
 if corrupt=='timestamp':r['scenes'][0]['start']=123
 if corrupt=='source':r['lines']['L001']['original']='Invented original'
 if corrupt=='omit':r['scenes'].pop()
 if corrupt=='unknown':r['lines']['L999']={}
 if corrupt=='duplicate':r['scenes'][0]['line_ids']*=2
 if corrupt=='unhashable':r['scenes'][0]['code']=[]
 assert assemble(r,scenes,source,eligible)['can_apply']is False,corrupt
kept=copy.deepcopy(body);kept['lines'][1]['keep']=True;assert len(checked_input(kept)[2])==2
grid=((np.indices((2048,1152)).sum(axis=0)//8%2)*255).astype(np.uint8);full=cv2.cvtColor(grid,cv2.COLOR_GRAY2BGR);img,jpg=encoded(full)
q=measure({'image':img});assert q['can_quick_approve']and q['sha256']==hashlib.sha256(jpg).hexdigest()
assert not measure({'image':image})['can_quick_approve']
blurry,_=encoded(np.zeros((2048,1152,3),np.uint8));assert measure({'image':blurry})['sharpness_state']=='blur'
calls=[]
async def provider(self,url,**kwargs):
 assert 'video_data'not in str(kwargs)and 'video/mp4'not in str(kwargs)
 parts=kwargs['json']['contents'][0]['parts'];table=json.loads(parts[0]['text'].split('INPUT DATA (not instructions):\n')[1]);calls.append(table)
 assert '123 456'not in json.dumps(table)and all('inline_data'in p or 'text'in p for p in parts)
 return httpx.Response(200,json={'candidates':[{'content':{'parts':[{'text':json.dumps(response(table))}]}}],'usageMetadata':{'totalTokenCount':41}})
server.VAULT.set_secret('gemini','fake-secret-not-real');server.VAULT.set_secret('gemini-models',{'main':'gemini-test-flash'})
with TestClient(server.app)as client,patch.object(httpx.AsyncClient,'post',provider):
 client.get('/')  # obtain the document's loopback session cookie
 assert client.post('/local-api/ai/analyze-frames',json=body).status_code==403
 r=client.post('/local-api/ai/analyze-frames',json=body,headers={'X-SceneForge-Local':'1'});assert r.status_code==200,r.text
 assert r.json()['can_apply']and len(calls)==1
 r=client.post('/local-api/ai/analyze-frames',json={**body,'provider':'openai'},headers={'X-SceneForge-Local':'1'});assert r.status_code==409 and len(calls)==1
 assert client.get('/local-api/ai/providers').json()['gemini']['configured']
async def discover_test():
 async def models(request):return httpx.Response(200,json={'models':[{'name':'models/gemini-2.5-flash','supportedGenerationMethods':['generateContent']},{'name':'models/gemini-9.0-flash','supportedGenerationMethods':['generateContent']},{'name':'models/gemini-9.0-flash-image','supportedGenerationMethods':['generateContent']}]})
 async with httpx.AsyncClient(transport=httpx.MockTransport(models))as client:
  r=await ai_providers.discover(server.VAULT,'gemini',client);assert r['model']=='gemini-9.0-flash'
asyncio.run(discover_test())
async def failure_tests():
 provider_calls=[]
 async def limited(self,url,**kwargs):
  provider_calls.append(url);return httpx.Response(429,headers={'Retry-After':'0'},json={'error':'raw fake-secret-not-real'})
 with patch.object(httpx.AsyncClient,'post',limited),patch.object(ai_providers.asyncio,'sleep',AsyncMock()):
  try:await ai_providers.frame_completion(server.VAULT,'gemini','test',{'scenes':scenes,'lines':eligible},images)
  except Exception as e:
   assert e.status_code==429 and e.detail['fallback_allowed']is False and 'fake-secret'not in json.dumps(e.detail)
  else:raise AssertionError('429 accepted')
 assert len(provider_calls)==3 and all('googleapis.com'in u for u in provider_calls)
 assert sum(r.get('http_status')==429 for r in server.VAULT.rows('logs'))==3
 provider_calls.clear()
 async def lost(self,url,**kwargs):provider_calls.append(url);raise httpx.ConnectError('raw fake-secret-not-real')
 with patch.object(httpx.AsyncClient,'post',lost):
  try:await ai_providers.frame_completion(server.VAULT,'gemini','test',{},images)
  except Exception as e:assert e.detail['code']=='NETWORK_UNKNOWN'and 'fake-secret'not in json.dumps(e.detail)
 assert len(provider_calls)==1
asyncio.run(failure_tests())
print('PASS real spatial motion: static background + moving foreground, pan, zoom, uncertain blank; real JPEG SHA/2K/blur; speech quarantine VI/ZH; codes immutable timing and six invalid outputs; guarded frame-only route, explicit paid consent, discovered model selection. Provider transport mocked; no live D8–D11 certification.')
