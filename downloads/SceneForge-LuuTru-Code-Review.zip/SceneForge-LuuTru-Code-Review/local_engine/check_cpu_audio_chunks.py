"""Real FFmpeg chunk extraction with fixture ASR at an overlap boundary, plus cached resume."""
import hashlib,json,tempfile,subprocess,wave,types
from pathlib import Path
from unittest.mock import patch
from .cpu_worker import analyze

def main():
 with tempfile.TemporaryDirectory(prefix='sf-audio-chunks-')as t:
  work=Path(t);source=work/'source';proxy=work/'proxy.avi'
  subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=navy:s=90x160:r=4:d=36','-f','lavfi','-i','sine=frequency=220:duration=36','-c:v','libx264','-c:a','aac','-f','mp4','-y',str(source)],check=True)
  subprocess.run(['ffmpeg','-v','error','-i',str(source),'-an','-c:v','mjpeg','-y',str(proxy)],check=True)
  seen=[]
  class Model:
   def __init__(self,*a,**kw):pass
   def transcribe(self,path,**kw):
    index=int(Path(path).stem.split('-')[-1]);seen.append(index);offset=max(0,index*30-.5)
    with wave.open(path)as audio:duration=audio.getnframes()/audio.getframerate()
    words=[]
    for name,start,end in [('w0',.2,.5),('w1',29.8,30.1),('w2',30.2,30.5),('w3',35.5,35.8)]:
     if start>=offset and end<=offset+duration+.01:words.append(types.SimpleNamespace(start=start-offset,end=end-offset,word=' '+name,probability=.99))
    seg=types.SimpleNamespace(start=0,end=duration,text=' '.join(w.word for w in words),words=words,no_speech_prob=.01,avg_logprob=-.01)
    return iter([seg]),types.SimpleNamespace(language='vi')
  config={'work':str(work),'data':str(work),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fps':4,'duration':36.,'width':90,'height':160,'audio':True,'threshold':27,'min_scene':.12,'transcribe':True,'ocr':False,'language':'vi'}
  with patch('faster_whisper.WhisperModel',Model):analyze(config)
  result=json.loads((work/'result.json').read_text());words=[w for row in result['transcript']for w in row['words']]
  assert [w['text'].strip()for w in words]==['w0','w1','w2','w3'],words
  assert seen==[0,1]and all(0<=w['start']<w['end']<=36 for w in words)
  with patch('faster_whisper.WhisperModel',side_effect=AssertionError('Cached chunks must not rerun ASR')):analyze(config)
  assert json.loads((work/'result.json').read_text())['transcript']==result['transcript']
 print('PASS real FFmpeg 30s audio cores + context overlap, fixture words across boundary retained once with absolute timings; scene/audio checkpoints reused without reloading ASR. No downloads/providers.')
if __name__=='__main__':main()
