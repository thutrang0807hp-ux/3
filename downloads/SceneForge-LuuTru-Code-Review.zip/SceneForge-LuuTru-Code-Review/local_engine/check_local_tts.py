"""Actual isolated worker/PCM transport using a fake SDK, never fake certification."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import wave
from fastapi import HTTPException
from .local_tts import synthesize_isolated, tts_status
from .prepare_voice import prepare
from .voice_worker import validate_beats


async def main():
    with tempfile.TemporaryDirectory() as directory:
        data = Path(directory)
        engine = data / 'engines/vieneu'
        (engine / 'venv/bin').mkdir(parents=True)
        (engine / 'venv/bin/python').symlink_to(sys.executable)
        runtime = engine / 'runtime'
        runtime.mkdir()
        media = data / 'media'
        media.mkdir()
        beats = [{'id': 'a', 'text': 'Lời thử thứ nhất'}, {'id': 'b', 'text': 'Lời thử thứ hai'}]
        assert tts_status(data)['installed'] and not tts_status(data)['model_ready']
        try:
            await synthesize_isolated(data, media, beats)
            raise AssertionError('unprepared model accepted')
        except HTTPException as error:
            assert error.status_code == 409
        for invalid in [None, [], [{'id': 'a', 'text': ''}], beats + [beats[0]]]:
            try:
                validate_beats(invalid)
                raise AssertionError('invalid beats')
            except ValueError:
                pass
        sdk = data / 'fixture-sdk'
        sdk.mkdir()
        (sdk / 'vieneu.py').write_text('''import os,wave
class Vieneu:
 def __init__(self,**kwargs):
  assert kwargs['backend']=='onnx' and kwargs['device']=='cpu' and kwargs['threads']==2
  assert os.environ['HF_HUB_OFFLINE'] in ('0','1')
  self.sample_rate=16000
 def get_preset_voice(self,name=None):
  assert name in (None,'fixture')
  return {'selected':'fixture'}
 def infer(self,text,voice=None):
  assert voice=={'selected':'fixture'}
  return bytes([40,0])*8000
 def save(self,audio,path):
  with wave.open(path,'wb')as out:
   out.setparams((1,2,16000,0,'NONE','not compressed'));out.writeframes(audio)
 def list_preset_voices(self):return [('Fixture voice','fixture')]
''')
        old_path = os.environ.get('PYTHONPATH')
        os.environ['PYTHONPATH'] = str(sdk)
        try:
            # Runs both prepare and offline checks as separate actual processes.
            prepare(engine)
            state = tts_status(data)
            assert state['model_ready'] and state['voices'][0]['id'] == 'fixture'
            result = await synthesize_isolated(data, media, beats, 'fixture')
            assert result['duration'] == 1 and result['segments'] == [{'id': 'a', 'start': 0, 'end': .5}, {'id': 'b', 'start': .5, 'end': 1}]
            file = media / result['url'].split('/')[-1]
            with wave.open(str(file), 'rb') as audio:
                assert audio.getframerate() == 16000 and audio.getnframes() == 16000
            assert not list(data.glob('tts-*'))
            try:
                await synthesize_isolated(data, media, beats, 'unknown')
                raise AssertionError('unknown voice accepted')
            except HTTPException as error:
                assert error.status_code == 400
            (runtime / 'probe.wav').write_bytes(b'changed')
            assert not tts_status(data)['model_ready']
        finally:
            if old_path is None:
                os.environ.pop('PYTHONPATH', None)
            else:
                os.environ['PYTHONPATH'] = old_path
    print('PASS actual isolated worker, online/offline setup state, preset selection, PCM WAV merge/timing, missing/corrupted model guard and temp cleanup. SDK fixture only; real model/speech not certified.')


asyncio.run(main())
