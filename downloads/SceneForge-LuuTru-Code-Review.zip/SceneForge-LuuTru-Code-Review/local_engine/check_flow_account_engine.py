"""Run in Flow venv: actual ASGI pin middleware, fixture token manager only."""
import asyncio
from types import SimpleNamespace
from pathlib import Path
import importlib.util
import sys


async def main():
    import httpx
    from fastapi import FastAPI
    from src.core.auth import AuthManager
    spec=importlib.util.spec_from_file_location('owned_flow_extension',Path(__file__).with_name('flow_account_engine.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    rows=[SimpleNamespace(id=i,email='fixture'+str(i),name='',is_active=True)for i in(1,2)]
    class Manager:
        async def get_active_tokens(self):await asyncio.sleep(.01);return rows
        async def get_all_tokens(self):return rows
        async def get_token(self,aid):return next((r for r in rows if r.id==aid),None)
        async def update_token(self,aid,**kwargs):saved.update(kwargs)
    saved={};applied={}
    class Limits:
        async def reset_token(self,aid,**kwargs):applied.update(kwargs)
    engine=SimpleNamespace(app=FastAPI(),token_manager=Manager(),concurrency_manager=Limits())
    app=module.extend(engine)
    @app.post('/v1/chat/completions')
    async def generate():return {'ids':[r.id for r in await engine.token_manager.get_active_tokens()]}
    original=AuthManager.verify_api_key
    AuthManager.verify_api_key=staticmethod(lambda key:key=='fixture-engine-key')
    try:
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://testserver')as client:
            a,b=await asyncio.gather(*[client.post('/v1/chat/completions',headers={'x-sceneforge-account':str(i)})for i in(1,2)])
            assert a.json()['ids']==[1]and b.json()['ids']==[2]
            assert a.headers['x-sceneforge-account']=='1'and b.headers['x-sceneforge-account']=='2'
            assert (await client.post('/v1/chat/completions')).json()['ids']==[1,2]
            assert(await client.get('/sceneforge/accounts')).status_code in (401,403)
            response=await client.get('/sceneforge/accounts',headers={'Authorization':'Bearer fixture-engine-key'})
            assert response.status_code==200 and response.json()['protocol']=='sceneforge-account-pin-v1'
            assert 'st'not in response.json()['accounts'][0]
            h={'Authorization':'Bearer fixture-engine-key'}
            response=await client.post('/sceneforge/accounts/1/concurrency',headers=h,json={'per_account':12})
            assert response.json()=={'per_account':12}and saved['video_concurrency']==12 and applied['video_concurrency']==12
            assert(await client.post('/sceneforge/accounts/1/concurrency',headers=h,json={'per_account':99})).status_code==400
    finally:AuthManager.verify_api_key=original
    print('PASS: Flow ASGI pin middleware isolates concurrent account 1/2; scope resets; response attests pin; inventory requires engine key and excludes credentials. No real accounts or generation.')


if __name__=='__main__':
    source=Path(sys.argv[1])if len(sys.argv)>1 else Path('/workspace/engines/flow-managed/source')
    sys.path.insert(0,str(source));asyncio.run(main())
