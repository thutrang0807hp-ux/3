"""Negative receipts, atomic envelopes, JSON recovery and manual release. No providers."""
import asyncio,json,os,tempfile,uuid
from pathlib import Path
from fastapi import HTTPException
from .flow_provider import FlowProvider
from .request_ledger import RequestLedger,RequestConflict
from .vault import Vault
from .json_result import object_result

async def main():
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);vault=Vault(root);ledger=RequestLedger(root);flow=FlowProvider(vault,root,ledger)
  vault.set_secret('flow-engine',{'url':'http://127.0.0.1:9','key':'x'*16,'models':['veo-portrait']});flow.tasks={i:None for i in range(30)}
  rid='flow-'+str(uuid.uuid4());body={'confirm_send':True,'model':'veo-portrait','request_id':rid,'prompt':'fixture','kind':'video'}
  try:await flow.submit(body);raise AssertionError('queue accepted')
  except HTTPException as e:assert e.status_code==429 and e.detail['submitted']is False and e.detail['store_id']==ledger.store_id
  assert flow.lookup(rid)['state']=='not_submitted'
  old='flow-'+str(uuid.uuid4());ledger.claim(old,{'already':'sent'})
  try:await flow.submit({**body,'request_id':old});raise AssertionError()
  except HTTPException as e:assert e.detail['submitted']is None and flow.lookup(old)['state']=='submitted'
  ledger.claim('atomic-envelope-1',{'x':1},envelope='envelope-fixture')
  reopened=RequestLedger(root);assert reopened.envelope('atomic-envelope-1')=='envelope-fixture'and reopened.store_id==ledger.store_id
  assert reopened.receipt(old)['state']=='unknown'
  assert object_result('Here is JSON:\n```json\n{"s":"a { brace }", "x":{"y":1}}\n```')['x']['y']==1
  for invalid in ('{"a":1} and {"b":2}','{"incomplete":','no object'):
   try:object_result(invalid);raise AssertionError('invalid/ambiguous accepted')
   except ValueError:pass
 with tempfile.TemporaryDirectory()as tmp:
  os.environ['SCENEFORGE_LOCAL_DATA']=tmp
  from . import server
  import httpx
  async with httpx.AsyncClient(transport=httpx.ASGITransport(server.app),base_url='http://testserver')as client:
   await client.get('/');h={'X-SceneForge-Local':'1'};rid=str(uuid.uuid4())
   response=await client.post('/local-api/ai/analyze-frames',headers=h,json={'request_id':rid,'duration':-1})
   assert response.status_code==400,response.text
   assert response.json()['detail']['submitted']is False
   record=server.GEMINI_CHAT.lookup('gchat-'+rid);assert record['state']=='not_submitted'
   old='gchat-'+str(uuid.uuid4());server.REQUESTS.claim(old,{'fixture':True});server.REQUESTS.finish(old,'unknown')
   response=await client.post('/local-api/requests/'+old+'/abandon',headers=h,json={'confirm_history_checked':True,'room_id':'fixture'})
   assert response.status_code==200 and response.json()['generation_requested']is False
   assert server.GEMINI_CHAT.lookup(old)['state']=='unknown'and server.REQUESTS.metadata(old)['manual_release']['actor']=='local-user'
   rid='gchat-'+str(uuid.uuid4());server.REQUESTS.claim(rid,{'fixture':'json'});server.REQUESTS.finish(rid,'done',{'kind':'text','text':'bad JSON'})
   response=await client.post('/local-api/requests/'+rid+'/correct-json',headers=h,json={'confirm':True,'text':'{"scenes":[]}'})
   assert response.status_code==200,response.text
   assert server.GEMINI_CHAT.lookup(rid)['result']['text']=='bad JSON'
   assert server.REQUESTS.metadata(rid)['json_correction']['text']=='{"scenes":[]}'
   assert not server.GEMINI_CHAT.tasks
 print('PASS: queue rejection has durable not-submitted receipt; existing request never gets negative proof; restart identity/envelope retained; strict JSON extraction; validation receipt; manual release preserves original; correction makes zero provider calls.')

if __name__=='__main__':asyncio.run(main())
