import sys,os,tempfile,io,zipfile,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
with tempfile.TemporaryDirectory(dir='/tmp')as t:
 os.environ['SCENEFORGE_LOCAL_DATA']=t
 from fastapi.testclient import TestClient
 from local_engine import server
 h={'X-SceneForge-Local':'1'}
 with TestClient(server.app)as c:
  c.get('/')
  assert c.post('/local-api/library/backup').status_code==403
  assert c.post('/local-api/library/backup',headers={**h,'Origin':'https://untrusted.invalid'}).status_code==403
  assert c.get('/local-api/library/assets/not-a-hash').status_code==400
  data=b'actual same bytes';sha=hashlib.sha256(data).hexdigest()
  assert c.post('/local-api/library/assets',headers={**h,'X-Content-SHA256':'a'*64},content=data).status_code==400
  for _ in range(2):assert c.post('/local-api/library/assets',headers=h,content=data).json()['hash']==sha
  assert c.get('/local-api/library/status').json()['assets']==1
  rows=[{'db':'sceneforge-app-shell','store':'files','key':'r:source','value':{'$sf':'blob','hash':sha}}]
  assert c.post('/local-api/library/snapshot',headers=h,json={'records':rows,'revision':0}).status_code==200
  assert c.post('/local-api/library/snapshot',headers=h,json={'records':[],'revision':0}).status_code==409
  assert c.get('/local-api/library/assets/'+sha).content==data
  bad=io.BytesIO()
  with zipfile.ZipFile(bad,'w')as z:z.writestr('../escape','payload');z.writestr('du-an.json','{}')
  assert c.post('/local-api/library/import',headers={**h,'X-Library-Revision':'1'},content=bad.getvalue()).status_code==400
  assert c.get('/local-api/library/bundle?file=../vault.key').status_code==400
  secret=Path(t)/'vault.key';assert secret.exists();assert not list(Path(t).glob('escape'))
 print('PASS loopback/same-origin/write-header guards, expected-hash verification, binary dedup/download, CAS conflicts, invalid ZIP/path rejection; no vault access from library routes.')
