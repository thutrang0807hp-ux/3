"""Offline SDK compatibility checks. Fixtures only, never a real Gemini session."""
import asyncio,base64,inspect,json,tempfile
from pathlib import Path
from unittest.mock import AsyncMock,patch
from gemini_webapi import GeminiClient,GeneratedImage
from gemini_webapi.types import ModelOutput,Candidate
from curl_cffi.requests import AsyncSession

async def check():
    client=GeminiClient()  # No cookie discovery or init: account remains unverified.
    assert 'files' in inspect.signature(GeminiClient.generate_content).parameters
    assert inspect.iscoroutinefunction(GeneratedImage.save)
    chat=client.start_chat(metadata=['c_fixture','r_fixture','rc_fixture'])
    image=GeneratedImage(url='https://example.invalid/fixture.png',title='fixture',alt='fixture')
    output=ModelOutput(metadata=['c_fixture','r_next','rc_next'],candidates=[Candidate(rcid='rc_next',text='Fixture response',generated_images=[image])])
    with tempfile.TemporaryDirectory(prefix='sf-gemini-sdk-') as temporary:
        picture=Path(temporary)/'reference.png'
        picture.write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jVJkAAAAASUVORK5CYII='))
        # Never send the fixture prompt/files anywhere. Patch SDK transport boundary.
        with patch.object(AsyncSession,'request',side_effect=AssertionError('Unexpected network request')),patch.object(GeminiClient,'generate_content',new_callable=AsyncMock,return_value=output) as send:
            result=await chat.send_message('Fixture prompt, not sent',files=[picture])
            assert send.await_count==1 and send.await_args.kwargs['files']==[picture]
            assert send.await_args.kwargs['chat'] is chat
            assert result.text=='Fixture response' and isinstance(result.images[0],GeneratedImage)
            # Actual ChatSession setter updates resumable metadata from model output.
            chat.last_output=result
            saved=json.loads(json.dumps(chat.metadata))
            restored=client.start_chat(metadata=saved)
            assert restored.cid=='c_fixture' and restored.rid=='r_next' and restored.rcid=='rc_next'
    assert client.client is None
    print('PASS SDK import, file/chat argument contracts, generated-image type, session metadata round-trip. Fixtures only; no init/login/cookie import/browser/network; real generation unverified.')

if __name__=='__main__':asyncio.run(check())
