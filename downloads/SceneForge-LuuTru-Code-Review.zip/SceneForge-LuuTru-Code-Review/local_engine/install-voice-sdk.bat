@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe (
 echo Run local_engine\start.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m local_engine.setup_optional_repos voice
if errorlevel 1 (
 echo SDK installation did not complete. Read the error above.
 pause
 exit /b 1
)
echo SDK only. No voice model was downloaded or enabled in SceneForge.
pause
