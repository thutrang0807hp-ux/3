"""Approval retires only previous generations of confirmed slots, with actual file deletion."""
import tempfile,copy
from pathlib import Path
from .library import Library

def main():
 with tempfile.TemporaryDirectory(prefix='sf-approve-')as tmp:
  lib=Library(Path(tmp));entries=[];markers={}
  def asset(name):
   p=Path(tmp)/name;p.write_bytes(('fixture-'+name).encode());m={'$sf':'blob',**lib.add_file(p)};entries.append([name,m]);markers[name]=m;return name
  clips=[{'id':'a'+str(n),'part':'a','version':n,'asset':asset('a'+str(n)),'requestId':'request'+str(n),'reviewDecision':{'status':'accepted'if n==5 else'rejected'}}for n in range(1,6)]
  clips.append({'id':'b1','part':'b','version':1,'asset':asset('b1')})
  frames=[{'id':'f'+str(n),'version':n,'asset':asset('f'+str(n)),'image':{'$sf':'dataurl',**{k:v for k,v in markers['f'+str(n)].items()if k!='$sf'}},'status':'approved'if n==3 else'pending'}for n in range(1,4)]
  scene={'id':'s','frames':frames,'approvedFrame':'f3','frameSelectionId':'f1','clips':clips,'chosen':{'a':'a5','b':'b1'},'receivedClipIds':['a5']}
  workflow={'id':'r','scenes':[scene],'assetEntries':entries,'localHistory':[{'scenes':[copy.deepcopy(scene)]}],'approvalCleanupPending':[{'sceneId':'s','kind':'clip','part':'a','keepId':'a5'}]}
  room={'db':'sceneforge-app-shell','store':'rooms','key':'r','value':{'id':'r'}}
  w={'db':'sceneforge-workflows','store':'projects','key':'r','value':workflow}
  # a1 stays on timeline; a2 is merely an unused library alternative; a3 shared elsewhere.
  editor={'db':'sceneforge-editor-local','store':'drafts','key':'r','value':{'payload':{'items':[{'assetId':'ed1'}],'assets':[{'id':'ed1','workflowKey':'a1'},{'id':'ed2','workflowKey':'a2'}]},'media':[{'id':'ed1','file':markers['a1']},{'id':'ed2','file':markers['a2']}]}}
  other={'db':'sceneforge-workflows','store':'projects','key':'other','value':{'id':'other','assetEntries':[['shared',markers['a3']]]}}
  pending={'db':'sceneforge-app-shell','store':'files','key':'r:pending','value':[{'key':'a2','file':markers['a2']}]}
  snap=lib.commit([room,w,editor,other,pending],0);lib.backup(daily=False)
  target={'sceneId':'s','kind':'clip','part':'a','keepId':'a5'}
  plan=lib.lifecycle.plan('r','approved',snap['revision'],0,False,[target]);result=lib.lifecycle.execute({**plan,'confirm':True})
  saved=next(r['value']for r in result['snapshot']['records']if r['db']=='sceneforge-workflows'and r['key']=='r')
  assert [c['id']for c in saved['scenes'][0]['clips']]==['a1','a5','b1']
  for name in ('a2','a4'):assert not lib.asset_path(markers[name]['hash']).exists(),name
  for name in ('a1','a3','a5','b1','f1','f2','f3'):assert lib.asset_path(markers[name]['hash']).exists(),name
  assert saved['approvalCleanupPending']==[]and len(saved['retiredVersionLog'])==3
  assert all(c['id']!='a2'for c in saved['localHistory'][0]['scenes'][0]['clips'])
  ed=next(r['value']for r in result['snapshot']['records']if r['db']=='sceneforge-editor-local');assert len(ed['media'])==1
  # Approving images must not retire clips or other prompt slots.
  ft={'sceneId':'s','kind':'frame','part':None,'keepId':'f3'}
  plan=lib.lifecycle.plan('r','approved',result['snapshot']['revision'],0,False,[ft]);result=lib.lifecycle.execute({**plan,'confirm':True})
  for name in ('f1','f2'):assert not lib.asset_path(markers[name]['hash']).exists()
  assert lib.asset_path(markers['f3']['hash']).exists()
  restored=lib.lifecycle.restore_records(snap['records'])
  from .library import hashes
  assert not(set(hashes(restored))&{markers[n]['hash']for n in ('a2','a4','f1','f2')})
  try:lib.lifecycle.plan('r','approved',result['snapshot']['revision'],0,False,[{**ft,'keepId':'f1'}]);raise AssertionError('Stale approval accepted')
  except ValueError:pass
  reopened=Library(Path(tmp));assert reopened.asset_path(markers['a5']['hash']).exists()
 print('PASS approval: actual old clip/image files removed; selected/latest kept; timeline/shared protected; unused editor/pending copies retired; history/backup does not resurrect bytes; stale target rejected; restart works. No provider requests.')
if __name__=='__main__':main()
