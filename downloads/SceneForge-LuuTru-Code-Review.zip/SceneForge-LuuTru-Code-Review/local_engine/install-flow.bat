@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe (
 echo Run local_engine\start.bat once before installing Flow.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m local_engine.setup_flow --connect
if errorlevel 1 (
 echo Flow installation did not finish. Read the error above; no generation was sent.
 pause
 exit /b 1
)
echo Flow installed separately. Run local_engine\start-flow.bat for manual login.
pause
