"""Reproduce disk/job and mutation-ACK failures without any provider dispatch."""
import base64,errno,tempfile,shutil,uuid
from pathlib import Path
from unittest.mock import patch
from fastapi import HTTPException
from .library import Library,Conflict
from .request_ledger import RequestLedger
from .storage_jobs import StorageJobs

def main():
 with tempfile.TemporaryDirectory(prefix='sf-reference-fixes-')as t:
  root=Path(t);lib=Library(root);ledger=RequestLedger(root);bridge=StorageJobs(lib,ledger,root);ledger.storage=bridge
  rid='flow-'+str(uuid.uuid4())
  with patch.object(lib,'add_file',side_effect=OSError(errno.ENOSPC,'disk full fixture')):
   try:ledger.claim(rid,{'room_id':'r','kind':'video','references':[{'data':base64.b64encode(b'reference').decode(),'mime_type':'image/png'}]});raise AssertionError('Expected disk failure')
   except OSError:pass
  assert ledger.receipt(rid)['state']=='not_submitted'
  restart=RequestLedger(root);assert restart.receipt(rid)['submitted']is False
  # Actual provider admission must surface durable negative proof, without creating its task.
  import asyncio,io
  from PIL import Image
  from .flow_provider import FlowProvider
  from .vault import Vault
  vault=Vault(root);vault.set_secret('flow-engine',{'url':'http://127.0.0.1:8766','key':'LOCAL_FIXTURE_KEY_12345','models':['fixture-video']})
  provider=FlowProvider(vault,root,ledger);image=io.BytesIO();Image.new('RGB',(16,16)).save(image,format='PNG')
  async def submit_failed():
   with patch.object(lib,'add_file',side_effect=OSError(errno.ENOSPC,'disk full fixture')):
    try:await provider.submit({'request_id':'flow-'+str(uuid.uuid4()),'room_id':'r','kind':'video','model':'fixture-video','prompt':'fixture','confirm_send':True,'references':[{'data':base64.b64encode(image.getvalue()).decode(),'mime_type':'image/png'}]});raise AssertionError('Disk-full submission accepted')
    except HTTPException as e:assert e.status_code==507 and e.detail['submitted']is False
   assert not provider.tasks
  asyncio.run(submit_failed())

  with restart.connect()as db:db.execute("INSERT INTO request VALUES('preparing-crash','digest','preparing',NULL,0)")
  assert RequestLedger(root).receipt('preparing-crash')['state']=='not_submitted'
  with lib.db()as db:
   for n in range(30):db.execute("INSERT INTO generation_job(id,provider,room_id,kind,state,inputs,created) VALUES(?,'flow','r','video','unknown','[]',0)",('unknown-'+str(n),))
  with patch('local_engine.storage_jobs.shutil.disk_usage',return_value=shutil._ntuple_diskusage(20*1024**3,8*1024**3,12*1024**3)):bridge.reserve_local(1024**3)
  with lib.db()as db:db.execute("INSERT INTO generation_job(id,provider,room_id,kind,state,inputs,created) VALUES('active-video','flow','r','video','submitted','[]',0)")
  with patch('local_engine.storage_jobs.shutil.disk_usage',return_value=shutil._ntuple_diskusage(2*1024**3,900*1024**2,1100*1024**2)):
   try:bridge.reserve_local(1024**3);raise AssertionError('Active reservation ignored')
   except HTTPException as e:assert e.status_code==507 and 'active-video'in e.detail
  with patch('local_engine.storage_jobs.shutil.disk_usage',return_value=shutil._ntuple_diskusage(1024**3,900*1024**2,124*1024**2)):
   try:bridge.reserve_download('unknown-0',500*1024**2);raise AssertionError('Download ignored disk pressure')
   except HTTPException as e:assert e.status_code==507
  room={'db':'sceneforge-app-shell','store':'rooms','key':'r','value':{'id':'r'}}
  snap=lib.commit([room],0,mutation_id='checkpoint-proof')
  assert snap['mutations'][0]['id']=='checkpoint-proof'
  assert lib.commit([room],0,mutation_id='checkpoint-proof')['revision']==snap['revision']
  try:lib.commit([{**room,'value':{'id':'changed'}}],0,mutation_id='checkpoint-proof');raise AssertionError('ID collision accepted')
  except Conflict:pass
  # Failed, missing files must not inflate the freed byte count.
  p=root/'gone';p.write_bytes(b'gone');marker={'$sf':'blob',**lib.add_file(p)}
  snap=lib.commit([room,{'db':'sceneforge-app-shell','store':'files','key':'r:source','value':marker}],snap['revision'])
  with lib.db()as db:db.execute("UPDATE generation_job SET state='discarded'")
  lib.asset_path(marker['hash']).unlink()
  plan=lib.lifecycle.plan('r','delete',snap['revision'],0);result=lib.lifecycle.execute({**plan,'confirm':True})
  assert result['freed_bytes']==0
  assert lib.lifecycle.execute({**plan,'confirm':True})['snapshot']['revision']==result['snapshot']['revision']
 print('PASS disk-failure negative receipt incl preparing crash; 30 unknown jobs do not reserve disk; live jobs/downloads still checked; exact mutation replay idempotent, changed content rejected; missing bytes not counted. No provider requests.')
if __name__=='__main__':main()
