"""Real workflow script: speech/action boundaries, static tail, continuity, evidence and bounded hash."""
from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from threading import Thread
import hashlib
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1]
 class Quiet(SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
 try:
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html?demo=1');page.wait_for_function('!!window.SceneForgeWorkflow&&typeof planClipParts==="function"')
   result=page.evaluate('''()=>{project.script=[{start:0,end:4.8,newText:'Một câu'},{start:5,end:10,newText:'Câu tiếp'}];const s=sceneRecord(0,13,0);const balanced=planClipParts(s);if(balanced.length!==2||balanced[0].end!==5)throw Error('Speech boundary was cut');project.script=[];const action=planClipParts(sceneRecord(0,11,0),{actionCuts:[4,7]});if(![4,7].includes(action[0].end))throw Error('Action boundary ignored');const tail=planClipParts(sceneRecord(0,9,0),{holdTail:true});if(tail.length!==1||tail[0].holdTail!==1||tail[0].generationDuration!==8)throw Error('Static tail still spends a second job');project.script=[{start:8.2,end:8.8,newText:'Có lời'}];if(planClipParts(sceneRecord(0,9,0),{holdTail:true}).length!==2)throw Error('Speech silently frozen');project.script=[];s.clips=[{id:'old',part:'a'}];if(clipParts(s)[0].end!==8)throw Error('Existing part layout silently changed');return{balanced,action,tail};}''')
   page.route('**/local-api/flow/status',lambda route:route.fulfill(json={'selection':{'available':True,'mode':'selected','account_name':'fixture','token':'t'},'account_binding':True,'models':['veo-portrait']}))
   page.evaluate('''async()=>{const s=sceneRecord(0,12,0,[SAMPLE.frames[0]]);s.id='continuity';s.approvedFrame='source';s.clipPlanning={continuity:true};s.clipPlan={start:0,end:12,parts:planClipParts(s)};const tail=SAMPLE.frames[1];s.clips=[{id:'first',part:'a',asset:putAsset(new Blob(['fixture'],{type:'video/mp4'})),duration:6,tail,frameId:'source',reviewDecision:{status:'accepted'}}];s.receivedClipIds=['first'];project.scenes=[s];project.script=[];project.analysis.frameQualityRequired=false;if(clipStartImage(s,'b')!==tail)throw Error('Previous tail not used');s.receivedClipIds=[];let blocked=false;try{clipStartImage(s,'b')}catch{blocked=true}if(!blocked)throw Error('Unapproved predecessor accepted');s.receivedClipIds=['first'];await directDialog([s]);}''')
   page.locator('#directPrepare').click();page.locator('#directSend').wait_for();assert '1 yêu cầu'in page.locator('#directSend').inner_text()
   evidence=page.evaluate('''async()=>{const s=project.scenes[0],c=document.createElement('canvas');c.width=768;c.height=1024;c.getContext('2d').fillRect(0,0,768,1024);s.cpu={evidence_frames:[c.toDataURL()]};const files=await referencePromptFiles(s,'image'),b=await(await fetch('data:'+files[0].mime_type+';base64,'+files[0].data)).blob(),image=await createImageBitmap(b);return image.width;}''');assert evidence==768
   want=hashlib.sha256(b'x'*(20*1024**2)).hexdigest()
   page.evaluate('''async want=>{class NoWholeRead extends Blob{arrayBuffer(){throw Error('Whole-file allocation forbidden');}}const file=new NoWholeRead(['x'.repeat(20*1024*1024)]),source=putAsset(file);project.source={...project.source,asset:source};await cpuVerifyResult({scenes:[{}],transcript:[],source_sha256:want},{roomId:project.id,source});}''',want)
   browser.close()
  print('PASS actual workflow: minimum-count balanced split at speech/action boundaries; optional 1s tail avoids extra job but never freezes dialogue; old layout preserved; unapproved continuity blocked, approved previous tail used; only next eligible clip prepared; 768px evidence sent; 20MiB hash without whole-file arrayBuffer. No provider send.')
 finally:server.shutdown()
if __name__=='__main__':main()
