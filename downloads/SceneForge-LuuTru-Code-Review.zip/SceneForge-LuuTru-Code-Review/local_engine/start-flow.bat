@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe (
 echo Run local_engine\start.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m local_engine.setup_flow --connect --start
pause
