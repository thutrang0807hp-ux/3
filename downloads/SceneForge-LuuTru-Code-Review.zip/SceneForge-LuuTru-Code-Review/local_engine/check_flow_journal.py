"""Run with Flow venv. Durable engine response survives caller cancellation/restart."""
import asyncio,json,tempfile,sys
from pathlib import Path
from types import SimpleNamespace

async def main():
 import httpx
 from fastapi import FastAPI
 from src.core.auth import AuthManager
 from local_engine.flow_task_journal import install_journal,FlowJournal
 previous=AuthManager.verify_api_key;AuthManager.verify_api_key=staticmethod(lambda k:k=='fixture-key')
 try:
  with tempfile.TemporaryDirectory()as tmp:
   release=asyncio.Event();entered=asyncio.Event();posts=[];app=FastAPI();engine=SimpleNamespace(app=app)
   @app.post('/v1/chat/completions')
   async def generate():
    posts.append('generation');entered.set();await release.wait();return {'url':'http://127.0.0.1:8766/result'}
   path=Path(tmp)/'journal.sqlite';journal=install_journal(engine,path);rid='flow-12345678-1234-1234-1234-123456789abc';h={'Authorization':'Bearer fixture-key','X-SceneForge-Account':'7','X-SceneForge-Request':rid}
   async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://testserver')as client:
    request=asyncio.create_task(client.post('/v1/chat/completions',headers=h,json={'model':'fixture','messages':[]}));await entered.wait();request.cancel()
    try:await request
    except asyncio.CancelledError:pass
    assert rid in journal.tasks
    release.set();await asyncio.gather(*list(journal.tasks.values()))
    result=await client.get('/sceneforge/tasks/'+rid,headers={'Authorization':'Bearer fixture-key'})
    assert result.json()['state']=='done'and result.json()['account_id']==7 and posts==['generation']
    cached=await client.post('/v1/chat/completions',headers=h,json={'model':'fixture','messages':[]});assert cached.status_code==200 and posts==['generation']
    conflict=await client.post('/v1/chat/completions',headers=h,json={'model':'DIFFERENT'});assert conflict.status_code==409 and posts==['generation']
    assert(await client.get('/sceneforge/tasks/'+rid)).status_code in (401,403)
   reopened=FlowJournal(path);assert reopened.read(rid)['state']=='done'
   # Pending opaque operation IDs are also journaled for read-only upstream lookup.
   pending='flow-22345678-1234-1234-1234-123456789abc';reopened.claim(pending,7,'fixture');reopened.operations(pending,[{'operation':{'name':'upstream-task-id'}}]);again=FlowJournal(path)
   assert again.read(pending)['state']=='unknown'and json.loads(again.read(pending)['operations'])[0]['operation']['name']=='upstream-task-id'
   lookups=[]
   class Tokens:
    async def get_token(self,aid):
     assert aid==7;return SimpleNamespace(id=7,at='private-token')
    async def ensure_valid_token(self,actor):return actor
   class Flow:
    async def check_video_status(self,at,operations,**kwargs):
     assert at=='private-token'and operations[0]['operation']['name']=='upstream-task-id'
     lookups.append('status');return {'operations':[{'status':'MEDIA_GENERATION_STATUS_SUCCESSFUL'}]}
   class Generation:
    async def _resolve_video_asset(self,actor,operation):
     lookups.append('media');return {'video_url':'https://storage.googleapis.com/fixture/result.mp4'}
   resumed=SimpleNamespace(app=FastAPI(),flow_client=Flow(),token_manager=Tokens(),generation_handler=Generation())
   install_journal(resumed,path)
   async with httpx.AsyncClient(transport=httpx.ASGITransport(resumed.app),base_url='http://testserver')as client:
    result=await client.get('/sceneforge/tasks/'+pending,headers={'Authorization':'Bearer fixture-key'})
    assert result.json()['state']=='done'and result.json()['account_id']==7 and lookups==['status','media']and posts==['generation']
   print('PASS: engine request journal survives caller cancellation, completed response reusable after restart, duplicate/conflicting requests never generate again, auth required, opaque upstream IDs retained.')
 finally:AuthManager.verify_api_key=previous

if __name__=='__main__':
 sys.path.insert(0,str(Path('/workspace/engines/flow-managed/source')));asyncio.run(main())
