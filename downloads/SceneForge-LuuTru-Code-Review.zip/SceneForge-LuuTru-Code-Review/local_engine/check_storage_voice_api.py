"""Real local route/audio bytes; synthesis is a fixture, never a model/provider call."""
import os,tempfile,uuid,wave,hashlib
from pathlib import Path

def main():
 with tempfile.TemporaryDirectory(prefix='sf-voice-storage-')as t:
  os.environ['SCENEFORGE_LOCAL_DATA']=t
  from fastapi.testclient import TestClient
  from . import server
  original=server.synthesize_isolated;name=str(uuid.uuid4())+'.wav'
  async def synth(data,media,beats,voice):
   with wave.open(str(media/name),'wb')as out:out.setnchannels(1);out.setsampwidth(2);out.setframerate(8000);out.writeframes(b'\0\0'*8000)
   return {'url':'/local-api/media/'+name,'duration':1,'segments':[{'id':'voice','start':0,'end':1}]}
  server.synthesize_isolated=synth
  try:
   with TestClient(server.app)as c:
    c.get('/');headers={'X-SceneForge-Local':'1'}
    result=c.post('/local-api/tts',json={'room_id':'voice-room','beats':[{'id':'voice','text':'test'}]},headers=headers);assert result.status_code==200,result.text
    data=result.json();audio=c.get(data['url']);assert audio.status_code==200 and audio.content[:4]==b'RIFF'
    assert not(server.MEDIA/name).exists()
    h=hashlib.sha256(audio.content).hexdigest();assert server.STORAGE_JOBS.voice_file(name)==server.LIBRARY.asset_path(h)
    snap=server.LIBRARY.snapshot();records=[{'db':'sceneforge-app-shell','store':'rooms','key':'voice-room','value':{'id':'voice-room'}},{'db':'sceneforge-workflows','store':'projects','key':'voice-room','value':{'id':'voice-room','scenes':[],'voiceOver':{'versions':[{'requestId':data['request_id'],'assetId':'voice'}]},'assetEntries':[['voice',{'$sf':'blob','hash':h,'type':'audio/wav'}]]}}]
    snap=server.LIBRARY.commit(records,snap['revision'])
    plan=server.LIBRARY.lifecycle.plan('voice-room','delete',snap['revision'],0);server.LIBRARY.lifecycle.execute({**plan,'confirm':True})
    assert c.get(data['url']).status_code==404
    print('PASS: TTS route stores WAV in canonical hash store, durable filename alias serves exact bytes, exact voice job import acknowledged, deleting its project removes both canonical media and download availability. Fixture synthesis only.')
  finally:server.synthesize_isolated=original
if __name__=='__main__':main()
