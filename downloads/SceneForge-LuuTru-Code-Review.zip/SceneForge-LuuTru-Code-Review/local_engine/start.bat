@echo off
setlocal
cd /d "%~dp0.."
python -c "import sys; sys.exit(0 if (3,11) <= sys.version_info[:2] < (3,14) else 1)"
if errorlevel 1 (
 echo Install Python 3.11 or 3.12, enable Add Python to PATH, then retry.
 pause
 exit /b 1
)
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 exit /b 1
set "SCENEFORGE_SETUP_ARG="
if /I "%~1"=="repair" set "SCENEFORGE_SETUP_ARG=--repair"
.venv\Scripts\python.exe -m local_engine.setup_dependencies %SCENEFORGE_SETUP_ARG%
if errorlevel 1 (
 echo Dependency setup failed. App was not started. Run start.bat repair to retry.
 pause
 exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 echo FFmpeg is missing from PATH. CPU video analysis and local MP4 export need FFmpeg.
set SCENEFORGE_OPEN_BROWSER=1
.venv\Scripts\python.exe -m local_engine
pause
