"""Actual browser -> approval API -> canonical file cleanup, with fixture media only."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64,json
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1]
 raw=base64.b64encode((root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()).decode()
 with tempfile.TemporaryDirectory(prefix='sf-approval-ui-')as data:
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'approval-fixture',name:'approval fixture',mode:'reference',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    frame=page.frame_locator('#workflowFrame');wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('!!window.SceneForgeWorkflow?.flushRoom')
    info=wf.evaluate('''async raw=>{const s=sceneRecord(0,15,0,[]);s.id='s';project.scenes=[s];project.script=[];project.analysis.frameQualityRequired=false;const keys=[];
     for(let n=1;n<=3;n++){const c=document.createElement('canvas');c.width=90;c.height=160;const ctx=c.getContext('2d');ctx.fillStyle=['red','green','blue'][n-1];ctx.fillRect(0,0,90,160);const image=c.toDataURL(),file=await(await fetch(image)).blob(),asset=putAsset(file);keys.push(asset);s.frames.push({id:'f'+n,version:n,image,asset,sha256:'fixture'+n,status:'pending',quality:{can_quick_approve:true,sha256:'fixture'+n,expected_label:''}});}s.approvedFrame='f1';s.frameSelectionId='f1';
     const bytes=Uint8Array.from(atob(raw),c=>c.charCodeAt(0));for(let n=1;n<=5;n++){const file=new Blob([bytes,new Uint8Array([n,0,0,0])],{type:'video/mp4'}),asset=putAsset(file);keys.push(asset);s.clips.push({id:'a'+n,part:'a',version:n,asset,frameId:'f3',duration:8,tail:s.frames[2].image});}s.clips.push({id:'b1',part:'b',version:1,asset:putAsset(new Blob([bytes,new Uint8Array([8])],{type:'video/mp4'})),duration:7,frameId:'f3',reviewDecision:{status:'rejected'}});s.chosen={a:'a1',b:'b1'};s.thumbs=[s.frames[2].image];project.source={name:'fixture.mp4',poster:s.frames[2].image,duration:15,width:90,height:160,asset:putAsset(new Blob([bytes],{type:'video/mp4'}))};await storeProject();render();return{keys,image:s.frames[2].image};}''',raw)
    assert wf.evaluate("displayFrame(project.scenes[0])")==info['image']
    assert frame.locator('#node-videos .g6Tile').count()==2 # two prompt slots, not one scene tile
    frame.locator('#node-videos .g6Tile').first.click();assert frame.locator('.g6Compare figcaption').last.inner_text()=='Bản 5'
    assert frame.locator('.g6VersionChoices').count()==0
    frame.locator('#modalFooter button').click()
    page.evaluate('async()=>{await flushFrames();await new Promise(r=>setTimeout(r,150));await SceneForgeStorage.checkpoint();}')
    before=page.evaluate("async()=>await SceneForgeStorage.api('snapshot')")
    w=next(r['value']for r in before['records']if r['db']=='sceneforge-workflows'and r['key']=='approval-fixture');hashes={a:b['hash']for a,b in w['assetEntries']}
    frame.locator('#node-frames [data-g6-bulk="frame"]').click()
    wf.wait_for_function("!approvalBusy&&project.scenes[0].frames.length===1",timeout=60000)
    assert wf.evaluate('project.scenes[0].frames[0].id')=='f3'
    frame.locator('#node-videos [data-g6-bulk="clip"]').click()
    wf.wait_for_function("!approvalBusy&&project.scenes[0].clips.length===2",timeout=60000)
    assert wf.evaluate('project.scenes[0].clips.map(c=>c.id)')==['a5','b1']
    for asset in info['keys'][:2]+info['keys'][3:7]:
     response=page.request.get(f'http://127.0.0.1:{port}/local-api/library/assets/'+hashes[asset]);assert response.status==404,(asset,response.status)
    assert page.request.get(f'http://127.0.0.1:{port}/local-api/library/assets/'+hashes[info['keys'][7]]).status==200
    # Explicit regeneration retains the candidate and prepares exactly this part.
    page.route('**/local-api/flow/status',lambda route:route.fulfill(json={'selection':{'available':True,'mode':'selected','account_name':'fixture','token':'fixture'},'account_binding':True,'models':['veo-portrait'],'per_account':1}))
    frame.locator('#node-videos .g6Tile').first.click();frame.locator('[data-approval-regenerate]').click();frame.locator('#directPrepare').click();frame.locator('#directSend').wait_for();assert '1 yêu cầu'in frame.locator('#directSend').inner_text()
    assert wf.evaluate('project.scenes[0].clips.map(c=>c.id)')==['a5','b1']
    # Lose the response AFTER a real commit; the next boot must hydrate canonical data.
    wf.evaluate('closeModal()')
    def lose_ack(route):
     response=route.fetch();assert response.status==200;route.abort()
    page.route('**/local-api/library/lifecycle/approve',lose_ack,times=1)
    frame.locator('#node-videos [data-g6-bulk="clip"]').click()
    page.wait_for_function('!SceneForgeStorage.state.active',timeout=30000)
    page.reload();page.wait_for_function('SceneForgeStorage.state.active',timeout=30000)
    assert not errors,errors
    browser.close()
   print('PASS real browser: latest image/clip despite old selection; separate prompt slots; bulk approval deletes old files without cleanup dialog; rejected other part survives; regenerate prepares only targeted part without removing candidate; lost approval response recovers canonical state on reload. No provider sends.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()
if __name__=='__main__':main()
