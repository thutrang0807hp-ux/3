@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -c "import sys;sys.exit(0 if (3,10) <= sys.version_info[:2] < (3,13) else 1)"
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r local_engine\requirements.txt -r local_engine\requirements-cpu.txt
if errorlevel 1 goto failed
if exist models\faster-whisper\model.bin (
 .venv\Scripts\python.exe -m local_engine.prepare_whisper --from-directory models\faster-whisper
) else (
 .venv\Scripts\python.exe -m local_engine.prepare_whisper --model base --download
)
if errorlevel 1 goto failed
echo Whisper CPU model and offline audio pipeline verified. Restart SceneForge.
pause
exit /b 0
:failed
echo Transcription setup did not finish. Read the error above. Existing data is preserved.
pause
exit /b 1
