"""Run with the installed Gemini SDK venv; real SDK types, no live transport."""
import asyncio
import base64
from pathlib import Path
import socket
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
from gemini_webapi import GeminiClient, GeneratedImage
from gemini_webapi.types import ModelOutput, Candidate
from gemini_webapi.exceptions import APIError, AuthError, UsageLimitExceededError, TemporarilyBlockedError
from .gemini_chat_worker import execute, single_send_type

MODE='text'
CALLS=[]
class Fake(GeminiClient):
    async def init(self, **kwargs):
        assert kwargs['auto_refresh'] is False and kwargs['watchdog_timeout']>kwargs['timeout']
        self.access_token='fixture';self._running=True;self._cookie_source='Guest'if MODE=='guest'else'Base Cookies'
    def list_models(self):return [SimpleNamespace(model_name='fixture-model')]
    async def generate_content(self, prompt, **kwargs):
        CALLS.append(prompt)
        if MODE in ('quota','partial'):
            self._sf_received_output=MODE=='partial';raise UsageLimitExceededError('PRIVATE_DETAIL')
        if MODE=='blocked':raise TemporarilyBlockedError('PRIVATE_DETAIL')
        if MODE=='auth':raise AuthError('PRIVATE_DETAIL')
        images=[GeneratedImage(url='https://lh3.googleusercontent.com/fixture',title='fixture',alt='fixture')]if MODE=='image'else[]
        return ModelOutput(metadata=['c_fixture','r_fixture','rc_fixture'],candidates=[Candidate(rcid='rc_fixture',text='{"lines":[]}',generated_images=images)])
    async def close(self,*args,**kwargs):self._running=False


async def main():
    global MODE
    socket.socket.connect=lambda *a,**k: (_ for _ in ()).throw(AssertionError('network forbidden'))
    count=0
    async def raw(client,*args,**kwargs):
        nonlocal count
        count+=1
        if False:yield None
        raise APIError('fixture error')
    with patch.object(GeminiClient._generate,'__wrapped__',raw):
        c=single_send_type(GeminiClient)(secure_1psid='fixture')
        try:
            async for _ in c._generate():pass
        except APIError:pass
        assert count==1,'SDK retry decorator still active'
    async def save(image,path,filename,**kwargs):
        assert kwargs['full_size']is False
        output=Path(path)/filename
        output.write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jVJkAAAAASUVORK5CYII='))
        return str(output)
    with tempfile.TemporaryDirectory()as root,patch.object(GeneratedImage,'save',save):
        body={'_workspace':root,'operation':'generate','kind':'text','session':{'cookies':{'__Secure-1PSID':'PRIVATE_COOKIE'}},'prompt':'fixture prompt','model':'fixture-model','references':[],'output':str(Path(root)/'result')}
        result=await execute(body,Fake);assert result['ok']and result['text']=='{"lines":[]}'and result['session']['cookies']['__Secure-1PSID']=='PRIVATE_COOKIE'
        for MODE in ('quota','partial','blocked','auth','guest'):
            before=len(CALLS);result=await execute(body,Fake);assert result['ok']is False
            assert result['accepted']is False if MODE=='quota'else result['accepted']is not False or MODE=='guest'
            assert 'PRIVATE_DETAIL'not in str(result)
            assert len(CALLS)==before+(MODE!='guest')
        MODE='image';result=await execute({**body,'kind':'image'},Fake);assert result['ok']and Path(body['output']).is_file()
    print('PASS: actual SDK types, one-send generator, private-cookie session, guest denied, typed quota vs partial/block/auth distinctions, generated-image save. Fake init/transport only; no Google requests.')


if __name__=='__main__':asyncio.run(main())
