"""Run the actual companion and static app together; never login or call AI."""
import os,sys,subprocess,tempfile,time,socket
from pathlib import Path
import httpx
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='sceneforge-local-web-',dir='/tmp')as tmp:
 s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();env=dict(os.environ,SCENEFORGE_LOCAL_DATA=tmp)
 log=open(Path(tmp)/'server.log','w');proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--no-access-log'],cwd=root,env=env,stdout=log,stderr=log)
 try:
  base='http://127.0.0.1:'+str(port)
  for _ in range(100):
   try:
    if httpx.get(base+'/local-api/health').status_code==200:break
   except httpx.HTTPError:pass
   time.sleep(.1)
  else:raise RuntimeError('Local service did not start')
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1550,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);page.wait_for_function('SceneForgeApp.getState().products.length>0');page.locator('#openStorage').click();page.locator('#settingsAccounts').click();expect(page.locator('#connectAccount')).to_be_enabled();expect(page.locator('#rotateAccounts')).to_be_disabled();assert page.locator('.accountTable tbody tr').count()==0;page.locator('[data-account-service=muse]').click();expect(page.locator('#dialogBody')).to_contain_text('muse.ai');page.screenshot(path='/tmp/sceneforge-package4-accounts-local.png');page.locator('#accountDone').click()
   page.locator('#openStorage').click();page.locator('#settingsSpeech').click();page.locator('#geminiLocalKey').fill('TEST_KEY_NOT_A_REAL_CREDENTIAL');page.locator('#saveLocalKey').click();page.wait_for_function('document.querySelector("#geminiLocalKey").value===""');status=httpx.get(base+'/local-api/status').json();assert status['gemini_configured'];assert 'TEST_KEY'not in str(status);assert b'TEST_KEY'not in(Path(tmp)/'vault.sqlite').read_bytes();assert not status['engines']['flow']['generation'];assert not errors,errors
   b.close()
  print('PASS: actual localhost companion serves UI; accounts show no fabricated identities or quota; manual login enabled, unconnected rotation disabled; Muse domain warning; masked key saves encrypted and is never returned. No login, provider or model calls.')
 finally:
  proc.terminate();proc.wait(timeout=10);log.close()
