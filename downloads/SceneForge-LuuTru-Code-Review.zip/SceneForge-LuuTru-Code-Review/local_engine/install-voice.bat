@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe (
 echo Run local_engine\start.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m local_engine.setup_optional_repos voice
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m local_engine.prepare_voice
if errorlevel 1 goto failed
echo Voice model prepared and actual offline speech verified. Restart SceneForge.
pause
exit /b 0
:failed
echo Voice setup did not complete. No model-ready status was granted. Read the error above.
pause
exit /b 1
