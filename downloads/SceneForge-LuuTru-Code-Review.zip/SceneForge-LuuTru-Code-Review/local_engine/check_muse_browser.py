"""Chromium UI with service fixtures; no real account or generation."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
import subprocess,json,tempfile
from playwright.sync_api import sync_playwright
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
temporary=tempfile.TemporaryDirectory(prefix='muse-browser-fixture-')
fixture=Path(temporary.name)/'fixture.mp4'
subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:s=90x160:r=10:d=0.5','-c:v','libx264','-y',str(fixture)],check=True)
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(Path(__file__).resolve().parents[1]/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/local-api/muse/files/*',lambda route:route.fulfill(status=200,body=fixture.read_bytes(),content_type='video/mp4'))
 page.goto(f'http://127.0.0.1:{server.server_port}/photos.html')
 page.evaluate('''async()=>{
 window.fixtureCalls=[];window.fixtureFiles=new Map();window.fixtureAccount=false;window.fixtureSelection={mode:'selected',account_id:'account-fixture',account_name:'Fixture A',available:true,token:'selection-A'};
 window.SceneForgeApp={photoBridge:{listRecipes:async()=>[],saveDraft:async()=>{},getFile:async k=>fixtureFiles.get(k),putFile:async(k,f)=>fixtureFiles.set(k,f),engine:async(path,body)=>{
 fixtureCalls.push({path,body});if(path==='status')return {};
 if(path==='muse/status')return {installed:true,configured:fixtureAccount,selection:{...fixtureSelection},accounts:fixtureAccount?[{id:'account-fixture',name:'Fixture A',enabled:true,session_verified:true},{id:'account-B',name:'Fixture B',enabled:true,session_verified:true}]:[]};
 if(path==='muse/selection'){fixtureSelection={mode:body.mode,account_id:body.account_id,account_name:body.account_id==='account-B'?'Fixture B':'Fixture A',available:true,token:body.mode==='balanced'?'balanced':body.account_id==='account-B'?'selection-B':'selection-A'};return {selection:{...fixtureSelection}};}
 if(path==='muse/login')return {id:'account-fixture',awaiting_otp:true};
 if(path==='muse/confirm'){fixtureAccount=true;return {account:{id:'account-fixture'}};}
 if(path==='muse/jobs'){if(body.selection_token!==fixtureSelection.token)throw Error('stale selection accepted by UI');return {request_id:body.request_id,state:'submitted'};}
 if(path.startsWith('muse/jobs/'))return {state:'done',result:{mime_type:'video/mp4',account_id:fixtureSelection.account_id}};
 throw Error('Unexpected path '+path);
 }}};
 const refs=Object.fromEntries(['product','person','outfit','background'].map(k=>[k,{description:'',images:[]}]));
 await SceneForgeWorkflow.openRoom({id:'room-fixture',name:'Muse fixture',product:{id:'product-fixture',name:'Son',sceneBank:[]},refs});
 draft.beats=draft.beats.slice(0,1);Object.assign(draft.beats[0],{visualPrompt:'Product on table',motionPrompt:'Slow push in',chosenClip:null,clips:[]});draft.flowJobs=[];render();
 }''')
 page.locator('[data-photo-video=muse]').click();page.locator('#photoFlowConfig').click();page.locator('#photoMuseEmail').fill('fixture@example.com');page.locator('#photoMuseLogin').click();page.locator('#photoMuseConfirm').wait_for(state='visible');page.locator('#photoMuseOTP').fill('123456');page.locator('#photoMuseConfirm').click();page.wait_for_function('fixtureAccount && document.querySelector("#photoMuseAccount option[value=account-fixture]")');page.locator('#photoMuseUse').click()
 page.wait_for_function('document.querySelector("#photoMuseChoice").textContent.includes("Fixture A")')
 page.locator('#photoRunClips').click();page.locator('#photoConfirmFlow').wait_for();assert 'Fixture A' in page.locator('#photoDialogBody').inner_text()
 # Simulate Settings changing to B while a review of A is open.
 page.evaluate("async()=>{await bridge.engine('muse/selection',{mode:'selected',account_id:'account-B'});}")
 page.locator('#photoConfirmFlow').click();page.wait_for_function('document.querySelector("#photoToast").textContent.includes("Lựa chọn Muse")')
 assert page.evaluate('draft.flowJobs.length')==0
 assert page.evaluate('fixtureCalls.filter(c=>c.path==="muse/jobs").length')==0
 page.evaluate("document.querySelector('#photoDialog').close()")
 page.locator('#photoRunClips').click();page.locator('#photoConfirmFlow').wait_for();assert 'Fixture B' in page.locator('#photoDialogBody').inner_text();page.locator('#photoConfirmFlow').click();page.wait_for_function('draft.flowJobs.length===1 && draft.flowJobs[0].state==="submitted"');assert page.evaluate('fixtureCalls.filter(c=>c.path==="muse/jobs").length')==1
 page.locator('#photoRecoverFlow').click();page.wait_for_function('draft.flowJobs[0].state==="imported"');assert page.evaluate('draft.beats[0].clips[0].origin')=='muse';assert page.evaluate('draft.beats[0].chosenClip===draft.beats[0].clips[0].id');page.locator('#photoRecoverFlow').click();assert page.evaluate('draft.beats[0].clips.length')==1
 assert page.evaluate('draft.beats[0].clips[0].accountId')=='account-B'
 page.locator('#photoFlowConfig').click();assert page.locator('#photoMuseAccount').input_value()=='account-B';page.locator('#photoMuseAccount').select_option('_balanced');page.locator('#photoMuseUse').click();page.wait_for_function('fixtureSelection.mode==="balanced" && document.querySelector("#photoMuseChoice").textContent.includes("Chia việc")');assert page.evaluate('draft.providers.museAccount===undefined')
 page.screenshot(path='/tmp/sceneforge-muse-connected.png');assert not errors,errors
 print('PASS: actual browser toolbar Muse -> OTP dialog -> reviewed submission -> saved clip assigned to correct beat -> repeat recovery no duplicate. Shared account label, stale-review guard and shared mode selection verified. Fixture account/video only.')
 # Shell account entry uses the same new Muse login path.
 account_state={'connected':False,'active':'account-fixture','balanced':False}
 def account_route(route):
  path=route.request.url.split('/local-api/')[1]
  if path=='status':payload={'accounts':[{'id':i,'name':n,'service':'muse','enabled':True,'session_verified':True,'state':'ready','active':i==account_state['active'],'priority':j}for j,(i,n)in enumerate([('account-fixture','Fixture A'),('account-B','Fixture B')])]if account_state['connected']else[],'logs':[],'rotation':{'muse':account_state['balanced']},'engines':{'muse':{'generation':False,'selection':{'mode':'balanced'if account_state['balanced']else'selected','account_id':account_state['active']}}}}
  elif path=='logs':payload=[]
  elif path=='muse/status':payload={'installed':True,'configured':False,'accounts':[]}
  elif path=='muse/login':payload={'id':'account-fixture','awaiting_otp':True}
  elif path=='muse/confirm':
   account_state['connected']=True;payload={'account':{'id':'account-fixture'}}
  elif path=='accounts/use':
   account_state['active']=route.request.post_data_json['id'];account_state['balanced']=False;payload={}
  elif path=='muse/selection':
   account_state['balanced']=route.request.post_data_json['mode']!='selected';payload={}
  elif path=='rotation':
   account_state['balanced']=route.request.post_data_json['enabled'];payload={'rotation':{'muse':account_state['balanced']}}
  else:payload={}
  route.fulfill(status=200,content_type='application/json',body=json.dumps(payload))
 page.route('**/local-api/**',account_route)
 page.goto(f'http://127.0.0.1:{server.server_port}/');page.wait_for_function('SceneForgeApp.getState().products.length>0')
 page.evaluate("async()=>{history.replaceState(null,'','/');await accountScreen('muse');}")
 page.locator('#connectAccount').click(timeout=3000);page.locator('#museLoginEmail').fill('fixture@example.com');page.locator('#museLoginStart').click();page.locator('#museLoginConfirm').wait_for();page.locator('#museLoginOTP').fill('123456');page.locator('#museLoginConfirm').click();page.locator('#connectAccount').wait_for();assert not errors,errors
 page.locator('[data-use-account=account-B]').click();page.wait_for_function("document.querySelector('[data-account-row=account-B]').textContent.includes('Đang dùng')");assert account_state['active']=='account-B'
 assert page.locator('#accountDispatchMode').is_enabled();page.locator('#accountDispatchMode').select_option('balanced');page.wait_for_function("document.querySelector('.acctEngineMeta').textContent.includes('BẬT')");assert account_state['balanced']
 print('PASS: shell Settings > Accounts > Muse OTP, choose B and enable shared distribution even before real generation certification. Fixture API only.')
 browser.close()
server.shutdown()
temporary.cleanup()
