@echo off
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -c "import sys;sys.exit(0 if (3,10) <= sys.version_info[:2] < (3,13) else 1)"
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r local_engine\requirements.txt -r local_engine\requirements-translation.txt
if errorlevel 1 goto failed
if exist models\m2m100-418m-int8\model.bin goto offline
rem Check access before installing the larger, setup-only conversion environment.
.venv\Scripts\python.exe -m local_engine.prepare_translation --check-download
if errorlevel 1 goto failed
if not exist .venv-translation-setup\Scripts\python.exe python -m venv .venv-translation-setup
if errorlevel 1 goto failed
.venv-translation-setup\Scripts\python.exe -m pip install "torch>=2.6,<3" --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto failed
.venv-translation-setup\Scripts\python.exe -m pip install -r local_engine\requirements-translation-setup.txt
if errorlevel 1 goto failed
.venv-translation-setup\Scripts\python.exe -m local_engine.prepare_translation --download
if errorlevel 1 goto failed
goto done
:offline
.venv\Scripts\python.exe -m local_engine.prepare_translation --from-directory models\m2m100-418m-int8
if errorlevel 1 goto failed
:done
echo M2M100 multilingual CPU model verified. Restart SceneForge. No Argos or paid API is used.
pause
exit /b 0
:failed
echo M2M100 setup not complete. Existing data is preserved; no paid fallback.
pause
exit /b 1
