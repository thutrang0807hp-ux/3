@echo off
setlocal
if not exist "D:\4\SceneForge.exe" goto missing
if not exist "D:\4\runtime\python.exe" goto missing
echo Hay dong SceneForge truoc khi tiep tuc. Cong cu khong mo Chrome hoac dang nhap Google.
"D:\4\runtime\python.exe" -I -X utf8 "%~dp0update_runtime.py" --app "D:\4"
if exist "%~dp0SceneForge-Runtime-Result.txt" notepad "%~dp0SceneForge-Runtime-Result.txt"
pause
exit /b
:missing
echo Khong tim thay SceneForge va Python runtime tai D:\4. Khong thay doi gi.
pause
