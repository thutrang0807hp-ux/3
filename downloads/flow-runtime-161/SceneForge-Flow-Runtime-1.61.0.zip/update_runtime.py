"""Offline, reversible browser-library compatibility update for SceneForge.
Never opens a browser, signs in, reads a profile, or calls a provider.
"""
import argparse,asyncio,datetime,email,hashlib,importlib.metadata,json,os,shutil,stat,subprocess,sys,uuid,zipfile
from pathlib import Path,PurePosixPath

HERE=Path(__file__).resolve().parent
NAMES={'playwright','pyee','greenlet','typing-extensions'}
MODULES={'playwright','pyee','greenlet','typing_extensions.py'}

class UpdateError(Exception):pass

def write_json(path,value):
 temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,path)

def verified_manifest():
 manifest=json.loads((HERE/'manifest.json').read_text())
 for row in manifest['files']:
  relative=PurePosixPath(row['file'])
  if relative.is_absolute()or'..'in relative.parts or'\\'in row['file']:raise UpdateError('INVALID_MANIFEST_PATH')
  file=HERE.joinpath(*relative.parts)
  if hashlib.sha256(file.read_bytes()).hexdigest()!=row['sha256']:raise UpdateError('PACKAGE_CHECKSUM_FAILED')
 return manifest

def parser_support(manifest):
 helper=next(row for row in manifest['files']if row.get('role')=='parser')
 sys.path.insert(0,str(HERE/helper['file']))
 from packaging.requirements import Requirement
 from packaging.utils import canonicalize_name
 from packaging.version import Version
 return Requirement,canonicalize_name,Version

def inventory(site):
 found={}
 for dist in importlib.metadata.distributions(path=[str(site)]):
  name=(dist.metadata.get('Name')or'').lower().replace('_','-').replace('.','-')
  found[name]={'version':dist.version,'requires':dist.requires or[]}
 return found

def load_wheel(path,canonicalize):
 with zipfile.ZipFile(path)as archive:
  metaname=next(name for name in archive.namelist()if name.endswith('.dist-info/METADATA'))
  meta=email.message_from_bytes(archive.read(metaname))
  return {'name':canonicalize(meta['Name']),'version':meta['Version'],'requires':meta.get_all('Requires-Dist',[]),'path':path}

def make_plan(installed,wheels,Requirement,Version):
 current=installed.get('playwright',{}).get('version')
 if current and Version(current)>=Version('1.63.0'):raise UpdateError('NEWER_RUNTIME_NOT_IN_REVIEWED_CASE')
 planned={}
 target=wheels['playwright']
 if current!=target['version']:planned['playwright']=target
 # Satisfy the chosen driver's requirements, preserving compatible existing deps.
 pending=list(target['requires']);visited=set()
 while pending:
  raw=pending.pop();req=Requirement(raw);name=req.name.lower().replace('_','-').replace('.','-')
  if req.marker and not req.marker.evaluate({'extra':''}):continue
  if name not in NAMES:raise UpdateError('UNEXPECTED_DRIVER_DEPENDENCY')
  desired=planned.get(name)or installed.get(name)
  if desired and Version(desired['version'])in req.specifier:
   if name not in visited:pending.extend(desired.get('requires',[]));visited.add(name)
   continue
  if name not in wheels or Version(wheels[name]['version'])not in req.specifier:raise UpdateError('DEPENDENCY_WHEEL_MISSING')
  planned[name]=wheels[name]
  if name not in visited:pending.extend(wheels[name]['requires']);visited.add(name)
 # Do not break another installed package's declared requirement.
 versions={name:row['version']for name,row in installed.items()};versions.update({name:row['version']for name,row in planned.items()})
 for name,row in installed.items():
  if name in planned:continue
  for raw in row['requires']:
   req=Requirement(raw);dependency=req.name.lower().replace('_','-').replace('.','-')
   if dependency not in planned or req.marker and not req.marker.evaluate({'extra':''}):continue
   if req.url or Version(versions[dependency])not in req.specifier:raise UpdateError('EXISTING_DEPENDENCY_CONFLICT')
 return planned

def allowed_entry(name):
 import re
 if name in MODULES:return True
 return bool(re.fullmatch(r'(playwright|pyee|greenlet|typing_extensions)-[0-9A-Za-z_.+!-]+\.dist-info',name))

def extract_plan(planned,stage):
 entries=set()
 for row in planned.values():
  with zipfile.ZipFile(row['path'])as archive:
   if sum(item.file_size for item in archive.infolist())>512*1024**2:raise UpdateError('WHEEL_TOO_LARGE')
   for item in archive.infolist():
    relative=PurePosixPath(item.filename)
    if relative.is_absolute()or'..'in relative.parts or'\\'in item.filename or not relative.parts:raise UpdateError('UNSAFE_WHEEL_PATH')
    if stat.S_ISLNK(item.external_attr>>16):raise UpdateError('UNSAFE_WHEEL_LINK')
    if '.data'in relative.parts[0]:
     if len(relative.parts)>1 and relative.parts[1]=='headers':continue
     raise UpdateError('UNSUPPORTED_WHEEL_LAYOUT')
    if not allowed_entry(relative.parts[0]):raise UpdateError('UNEXPECTED_WHEEL_ENTRY')
    entries.add(relative.parts[0]);target=stage.joinpath(*relative.parts)
    if item.is_dir():target.mkdir(parents=True,exist_ok=True);continue
    target.parent.mkdir(parents=True,exist_ok=True)
    with archive.open(item)as source,target.open('wb')as destination:shutil.copyfileobj(source,destination)
 return sorted(entries)

def remove_entry(path):
 if path.is_symlink()or getattr(path,'is_junction',lambda:False)():raise UpdateError('LINKED_PACKAGE_NOT_SUPPORTED')
 if path.is_dir():shutil.rmtree(path)
 elif path.exists():path.unlink()

def restore(site,backup):
 journal=json.loads((backup/'journal.json').read_text())
 if any(not allowed_entry(name)for name in journal['old_entries']+journal['new_entries']):raise UpdateError('INVALID_ROLLBACK_JOURNAL')
 for name in journal['new_entries']:
  # If an old entry was not moved yet, never remove it during rollback.
  if name in journal['old_entries']and not(backup/'site'/name).exists():continue
  remove_entry(site/name)
 for name in journal['old_entries']:
  saved=backup/'site'/name
  if saved.exists():remove_entry(site/name);os.replace(saved,site/name)
 journal['state']='restored';write_json(backup/'journal.json',journal)

def transaction(site,planned,backup,smoke):
 stage=site.parent/('.flow-runtime-stage-'+uuid.uuid4().hex);stage.mkdir()
 try:
  new_entries=extract_plan(planned,stage)
  selected=set(planned)
  old_entries=[]
  for path in site.iterdir():
   normalized=path.name.lower().replace('_','-')
   module='typing-extensions'if path.name=='typing_extensions.py'else path.name
   if module in selected or path.name.endswith('.dist-info')and any(normalized.startswith(name+'-')for name in selected):
    if not allowed_entry(path.name)or path.is_symlink()or getattr(path,'is_junction',lambda:False)():raise UpdateError('UNSUPPORTED_INSTALLED_LAYOUT')
    old_entries.append(path.name)
  needed=sum(path.stat().st_size for path in stage.rglob('*')if path.is_file())+32*1024**2
  if shutil.disk_usage(site).free<needed:raise UpdateError('NOT_ENOUGH_DISK_SPACE')
  (backup/'site').mkdir(parents=True)
  journal={'state':'prepared','old_entries':old_entries,'new_entries':new_entries,'versions':{n:r['version']for n,r in planned.items()}}
  write_json(backup/'journal.json',journal)
  try:
   for name in old_entries:os.replace(site/name,backup/'site'/name)
   for name in new_entries:os.replace(stage/name,site/name)
   smoke()
   journal['state']='committed';write_json(backup/'journal.json',journal)
  except BaseException:
   restore(site,backup);raise
 finally:shutil.rmtree(stage,ignore_errors=True)

SMOKE=r'''
import asyncio,importlib.metadata,json
from playwright.async_api import async_playwright
async def main():
 p=await async_playwright().start()
 await p.stop()
 print(json.dumps({'playwright':importlib.metadata.version('playwright'),'driver_started':True,'browser_launched':False,'provider_requests':0}))
asyncio.run(main())
'''
def smoke_runtime(python):
 process=subprocess.Popen([str(python),'-I','-c',SMOKE],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:out,err=process.communicate(timeout=25)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  process.wait();raise UpdateError('DRIVER_SMOKE_TIMEOUT')from None
 if process.returncode:raise UpdateError('DRIVER_SMOKE_FAILED')
 try:result=json.loads(out.strip())
 except Exception:raise UpdateError('DRIVER_SMOKE_INVALID')from None
 if result.get('playwright')!='1.61.0'or not result.get('driver_started')or result.get('browser_launched')is not False:raise UpdateError('DRIVER_SMOKE_INVALID')
 return result

def app_running(root):
 script=r'''$ErrorActionPreference='Stop';$p=@(Get-CimInstance Win32_Process -Filter "Name='SceneForge.exe'");$blocked=$false;foreach($v in $p){if(!$v.ExecutablePath -or [string]::Equals($v.ExecutablePath,$env:SCENEFORGE_RUNTIME_APP_EXE,[StringComparison]::OrdinalIgnoreCase)){$blocked=$true}};if($blocked){'running'}else{'closed'}'''
 try:
  result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],env={**os.environ,'SCENEFORGE_RUNTIME_APP_EXE':str(root/'SceneForge.exe')},capture_output=True,text=True,timeout=15)
  if result.returncode or result.stdout.strip()not in ('running','closed'):raise UpdateError('APP_PROCESS_CHECK_UNAVAILABLE')
  return result.stdout.strip()=='running'
 except subprocess.TimeoutExpired:raise UpdateError('APP_PROCESS_CHECK_UNAVAILABLE')from None

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--app',default=r'D:\4');parser.add_argument('--restore-latest',action='store_true');args=parser.parse_args()
 report={'tool_version':1,'state':'starting','provider_requests':0,'browser_launched':False,'profiles_changed':False}
 try:
  root=Path(args.app).resolve();runtime=root/'runtime';python=runtime/'python.exe';site=runtime/'Lib/site-packages'
  if sys.platform!='win32'or sys.version_info[:2]!=(3,12)or __import__('struct').calcsize('P')!=8:raise UpdateError('WINDOWS_PYTHON312_X64_REQUIRED')
  if Path(sys.executable).resolve()!=python.resolve()or not(root/'SceneForge.exe').is_file()or not site.is_dir():raise UpdateError('NOT_SCENEFORGE_APP_RUNTIME')
  if app_running(root):raise UpdateError('CLOSE_SCENEFORGE_FIRST')
  import msvcrt
  lock=(root/'runtime-flow-driver.lock').open('a+b');locked=False
  if lock.tell()==0:lock.write(b'0');lock.flush()
  lock.seek(0)
  try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);locked=True
  except OSError:raise UpdateError('ANOTHER_UPDATER_RUNNING')from None
  manifest=verified_manifest();Requirement,canonicalize,Version=parser_support(manifest)
  installed=inventory(site);report['before']={n:installed.get(n,{}).get('version')for n in sorted(NAMES)}
  backups=root/'runtime-backups'
  if args.restore_latest:
   candidates=sorted(backups.glob('flow-driver-*/journal.json'),reverse=True)
   candidate=next((p.parent for p in candidates if json.loads(p.read_text()).get('state')in ('committed','prepared')),None)
   if not candidate:raise UpdateError('NO_COMMITTED_BACKUP')
   restore(site,candidate);report['state']='restored'
  else:
   if any(json.loads(path.read_text()).get('state')=='prepared'for path in backups.glob('flow-driver-*/journal.json')):raise UpdateError('RESTORE_INTERRUPTED_UPDATE_FIRST')
   wheels={}
   for row in manifest['files']:
    if row.get('role')!='runtime':continue
    wheel=load_wheel(HERE/row['file'],canonicalize);wheels[wheel['name']]=wheel
   planned=make_plan(installed,wheels,Requirement,Version)
   if not planned:report['state']='already_compatible'
   else:
    backup=backups/('flow-driver-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    transaction(site,planned,backup,lambda:smoke_runtime(python))
    report.update(state='updated',changed_packages={n:r['version']for n,r in planned.items()},rollback_available=True)
  report['after']={n:inventory(site).get(n,{}).get('version')for n in sorted(NAMES)}
 except UpdateError as exc:report.update(state='stopped',code=str(exc))
 except Exception:report.update(state='stopped',code='UPDATE_FAILED_CHECK_ROLLBACK')
 if 'site'in locals()and site.is_dir():
  try:report['after']={n:inventory(site).get(n,{}).get('version')for n in sorted(NAMES)}
  except Exception:pass
 if 'lock'in locals():
  try:
   if locked:lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
  finally:lock.close()
 try:write_json(HERE/'SceneForge-Runtime-Result.txt',report)
 except OSError:report['result_file_written']=False
 print(json.dumps(report,ensure_ascii=True,indent=2))
 return 0 if report['state']in ('updated','already_compatible','restored')else 1
if __name__=='__main__':sys.exit(main())
