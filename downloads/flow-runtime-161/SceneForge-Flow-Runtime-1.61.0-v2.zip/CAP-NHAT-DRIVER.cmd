@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0CHON-THU-MUC.ps1" -Mode Apply
pause
