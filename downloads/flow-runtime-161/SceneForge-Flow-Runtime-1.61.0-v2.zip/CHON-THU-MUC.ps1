param([ValidateSet('Apply','Restore')][string]$Mode='Apply')
$ErrorActionPreference='Stop'
try {
    $appRoot='D:\4'
    if (!(Test-Path -LiteralPath (Join-Path $appRoot 'SceneForge.exe') -PathType Leaf) -or !(Test-Path -LiteralPath (Join-Path $appRoot 'runtime\python.exe') -PathType Leaf)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog=New-Object System.Windows.Forms.OpenFileDialog
        $dialog.Title='Chon file SceneForge.exe trong thu muc cai dat phan mem'
        $dialog.Filter='SceneForge (SceneForge.exe)|SceneForge.exe'
        $dialog.CheckFileExists=$true
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            Write-Host 'Da huy. Khong thay doi gi.'
            exit 1
        }
        $appRoot=[System.IO.Path]::GetDirectoryName($dialog.FileName)
        $dialog.Dispose()
    }
    $python=Join-Path $appRoot 'runtime\python.exe'
    if (!(Test-Path -LiteralPath $python -PathType Leaf)) {
        Write-Host 'Thu muc da chon khong co runtime\python.exe. Khong thay doi gi.'
        exit 1
    }
    Write-Host ('Thu muc SceneForge: '+$appRoot)
    Write-Host 'Hay dong SceneForge truoc khi tiep tuc. Khong mo Chrome hay dang nhap Google.'
    $arguments=@('-I','-X','utf8',(Join-Path $PSScriptRoot 'update_runtime.py'),'--app',$appRoot)
    if ($Mode -eq 'Restore') { $arguments+='--restore-latest' }
    & $python @arguments
    $resultCode=$LASTEXITCODE
    $report=Join-Path $PSScriptRoot 'SceneForge-Runtime-Result.txt'
    if (Test-Path -LiteralPath $report -PathType Leaf) { & notepad.exe $report }
    exit $resultCode
} catch {
    Write-Host ('Khong the chay cong cu: '+$_.Exception.Message)
    Write-Host 'Chua xac nhan cap nhat thanh cong.'
    exit 1
}
