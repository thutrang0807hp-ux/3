"""Download VieNeu CPU weights and verify real synthesis online then offline."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time


def prepare(directory):
    root = Path(directory).resolve()
    python = root / 'venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not python.is_file():
        raise RuntimeError('Chạy bộ cài SDK VieNeu trước.')
    runtime = root / 'runtime'
    runtime.mkdir(parents=True, exist_ok=True, mode=0o700)
    marker = runtime / 'model-status.json'
    def status(**values):
        temp = marker.with_suffix('.tmp')
        temp.write_text(json.dumps({'at': time.time(), 'model': 'pnnbao-ump/VieNeu-TTS-v3-Turbo', 'backend': 'onnx-cpu-fp32', **values}, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temp, marker)
    status(model_ready=False, phase='downloading')
    worker = Path(__file__).with_name('voice_worker.py')
    result, output = runtime / 'probe.json', runtime / 'probe.wav'
    base = [str(python), str(worker), '--runtime', str(runtime), '--output', str(output), '--result', str(result)]
    try:
        subprocess.run([*base, '--prepare'], check=True)
        # Prove rendering can run without a model download, not just a cached import.
        subprocess.run(base, check=True)
        data = json.loads(result.read_text(encoding='utf-8'))
        if not output.is_file() or not data.get('duration', 0) > 0:
            raise ValueError('Chưa có WAV thử hợp lệ.')
        status(model_ready=True, phase='ready', voices=data['voices'], probe_sha256=data['sha256'], probe_seconds=data['duration'])
        print('READY: generated actual CPU speech and verified offline synthesis:', output)
    except (OSError, ValueError, subprocess.SubprocessError):
        status(model_ready=False, phase='failed', error='Chưa tải/khởi tạo/thử được model. Kiểm tra mạng tới Hugging Face, dung lượng và lỗi phía trên; không báo model đã sẵn sàng.')
        raise RuntimeError('Chưa hoàn tất model VieNeu. SDK và tệp model tải dở được giữ để thử tiếp.') from None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    default = Path(os.environ.get('SCENEFORGE_LOCAL_DATA', str(Path.home() / '.sceneforge-local'))) / 'engines/vieneu'
    parser.add_argument('--directory', type=Path, default=default)
    args = parser.parse_args()
    try:
        prepare(args.directory)
    except RuntimeError as error:
        raise SystemExit(str(error))


if __name__ == '__main__':
    main()
