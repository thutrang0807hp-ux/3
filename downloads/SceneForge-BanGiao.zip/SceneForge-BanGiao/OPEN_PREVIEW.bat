@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0open_preview.py"
) else (
  python "%~dp0open_preview.py"
)
pause
