# Ngữ cảnh và lịch sử yêu cầu

Tài liệu tổng hợp các yêu cầu xuyên suốt cuộc trò chuyện. Những điều ở giai đoạn sau thay thế thiết kế ở giai đoạn trước; không cộng tất cả thành danh sách tính năng bắt buộc phải giữ.

## 1. Mục tiêu ban đầu và chi phí

Người dùng yêu cầu thiết lập môi trường cloud cho repo thutrang0807hp-ux/3, ref main. Sau đó xác định muốn tự xây công cụ từ nguồn GitHub, hạn chế tiền SaaS, chủ yếu trả API. Ý tưởng trọng tâm không phải chỉ lập kịch bản mới: đưa video của người khác vào, phân tích thành prompt mô tả chi tiết, tách cảnh, tạo clip nhỏ hàng loạt rồi tự ghép thành video xuất được.

Có nhắc API ChatGPT/OpenAI, Veo và “Muse của Meta”. Muse chưa có nhà cung cấp/endpoint/quyền model được xác định. Không được diễn giải rằng một API key bất kỳ là đủ. Phân tích, viết prompt và tạo clip có yêu cầu model, quota và thanh toán riêng. Chưa dùng key thật để xác nhận luồng trả phí hoàn chỉnh.

## 2. SceneForge và các tab

Ban đầu có lỗi CSS/preview khiến web thành chữ thô; người dùng liên tục không mở được bản mô phỏng và muốn xem ngay trong web. Sau nhiều lần thiết kế lại, chốt shell SceneForge giữ các tab bên trái, không bỏ Tổng quan/Thư viện/Hàng đợi/Thiết lập chỉ để làm mỗi tab Phân tích.

Từng yêu cầu xóa logo nền tảng (TikTok/Douyin) và có UI khoanh vùng, nhưng sau đó yêu cầu bỏ mục Xóa logo. Không thêm lại chỉ vì mã backend cũ còn chức năng đó.

Thư viện cần vùng thêm video phía trên, danh sách các video từng thêm phía dưới, tìm tên video và mở phân tích. Không thích khối quá to, quá nhiều chữ, các phiên bản tối giản đến mất nút, hoặc trang khó thao tác. Có tham khảo phong cách UX/UI Hàn, sau cùng ưu tiên dễ dùng, gọn và nhìn rõ.

## 3. Phân tích và viết prompt

- Tách không gian phân tích ra một tab riêng.
- Dùng video mẫu để người dùng xem trạng thái sau upload, nhưng ghi rõ là minh họa.
- Video mặc định 9:16, tránh preview dọc quá lớn làm nghẹt cột chữ.
- Các cảnh dàn ngang thành card: nguồn và vị trí clip AI/kết quả; Visual Prompt, Motion & Script; cần chỉnh mới mở drawer/panel.
- Trợ lý prompt cần model/key tùy chỉnh, cách viết, nguồn tham khảo và khả năng đối chiếu nhiều AI. Các tên nhà cung cấp trong UI demo không đồng nghĩa đã gọi API thật.
- Người dùng yêu cầu tìm quy trình GitHub/nguồn khác để viết prompt tốt hơn. Đã có prompt_workflow.py, video_analysis.py, docs/prompt-workflow.md và UI quy trình.
- Mẫu do người dùng gửi là nội thất Mercedes-Benz, một nhân vật host Việt Nam, sản phẩm bình xịt GLYTWIN: mô tả đặc điểm, kích thước, quan hệ không gian và tính nhất quán rất chi tiết. Tệp gốc được giữ trong references.
- Không lấy mẫu ví dụ làm sự thật phân tích. Chỉ mô tả chuyển động/lời thoại khi có bằng chứng; yêu cầu sáng tạo phải ghi là biến thể.

## 4. Mong muốn editor tích hợp

Veo thường tạo clip ngắn; người dùng không muốn tải từng clip xuống ghép ở ứng dụng khác. Yêu cầu tab Dựng video nằm trong phần mềm, timeline giống CapCut, đủ thao tác thực tế, không bắt phải tự phát hiện từng tính năng rồi nhắc bổ sung.

Các yêu cầu liên tiếp: video/text/audio track, cắt/ghép, chuyển cảnh và thời lượng chỉnh được, properties panel, cửa sổ tư liệu tùy chỉnh, kéo clip giữa track, tự tạo dòng khi nhấc clip, tránh đè clip không chủ ý, timeline mượt và icon dễ nhận. Chỉ phần editor tối kiểu CapCut; giữ web cũ cho các tab khác.

## 5. Chọn Concat

Người dùng đưa concatenate.pages.dev, tệp Concat-0.2.7-windows-x86_64-setup.exe rồi GitHub jub0t/concat. Muốn giao diện sát Concat: menu trên, hàng công cụ Media/Text/Stickers/Transitions/Effects/Filters/Templates, tư liệu trái, preview giữa, inspector phải, timeline rộng bên dưới, filmstrip/waveform.

Đã có nhiều prototype nhỏ, ảnh cửa sổ native có hotspot và editor web trước đó (OpenVideo). Người dùng không hài lòng vì quá rút gọn, không chạy được, chỉ thấy mã HTML hoặc mất công cụ. Không được nhầm các trang đó với bản editor đa track mới nhất.

Nguồn Concat native v0.2.7 đã được lấy, build Linux và kiểm tra trong các lượt trước. Cửa sổ native được chụp làm reference; binary Windows người dùng gửi không cần giải mã khi đã có nguồn GitHub. Native Rust không chạy trực tiếp trong GitHub Pages.

## 6. Thu gọn đúng chỗ và phụ đề

Người dùng dừng để bàn lại sản phẩm: ưu tiên tự động ghép/xuất, vẫn chỉnh tay khi cần. Không muốn editor phình ra cho đủ checklist CapCut. Chọn bỏ phần ít cần, giữ thao tác dựng cơ bản chắc chắn.

Phụ đề rất quan trọng: yêu cầu mẫu phụ đề, nhập/sửa thời gian, chung preview/timeline. Không tách Text/Subtitles thành phần mềm hoặc tab cấp cao riêng; chính các bản phụ đề đơn lẻ thay thế editor đã khiến người dùng hỏi “mấy cái công cụ đâu rồi?”. Bản cuối đưa lại editor đa track và gộp phụ đề vào cùng workspace.

## 7. Đợt kiểm tra timeline và effects

Đã khôi phục browser engine đa track vốn có và kiểm tra nhập tệp, auto track, lift track, insert/swap/overwrite/layer, trim, batch operations, JSON, export thật. Thêm effect hình 9 thẻ before/after, nhóm/tìm kiếm, thông số và keyframe thật; không chỉ đổi text mẫu.

Sau khi đối chiếu Concat, bổ sung quét vùng chọn, Shift thêm/bớt, track khóa, tự cuộn biên khi kéo đứng yên, Esc cancel, chuyển cảnh có hai mép chỉnh trực tiếp, dissolve hai hình thực. Thêm rolling trim, liên kết hình–tiếng, xếp clip nối tiếp có thứ tự, một lần undo. Không coi toàn bộ CapCut đã hoàn thành, không báo % thiếu căn cứ.

## 8. Đợt mở rộng âm thanh, khung và phím tắt

Người dùng yêu cầu bảng effect âm thanh, nút cắt/phát dễ thấy, bàn phím và khung ngang/dọc. Đã làm UI EQ/presets/comp/pan; các effect thực sự có trong preview/export, đã đo tín hiệu. Thêm frame presets/custom, PNG/ASS/recording theo geometry dự án, lưu/undo frame. Thêm dedicated join inspector: ảnh hai clip, type/duration/direction/easing/preview/remove.

Từng gặp xung đột Esc do handler phím mới chặn handler cancel drag. Đã sửa: khi timeline-drag-active, để Esc đi tới cancel handler. Giữ bài kiểm tra hồi quy.

## 9. Quyết định cuối cùng — supersedes bảng âm thanh ở mục 8

Người dùng nói bảng âm thanh có quá nhiều effect không cần, muốn phần cốt lõi và minh họa rõ vị trí: một thanh mini ở phía trên timeline, bên phải. Âm lượng phải tăng được vượt 100% vì có các đoạn nguồn rất nhỏ. Bỏ tab Cơ bản/Chuyển động của audio và bảng audio lớn.

Đã thực hiện:
- Gỡ preset, EQ graph và audio effects panel khỏi DOM.
- Thanh mini cho âm lượng 0–2.000%, mute/bật tiếng; giữ gain khi mute.
- Nút nhỏ mở fade in/out, speed, reset 100%, tách tiếng, mốc volume.
- Sidebar ẩn khi chọn audio, khôi phục với video/chữ; không đổi trạng thái collapse người dùng đã chọn.
- Dùng Web Audio GainNode để khuếch đại, không gán HTMLMediaElement.volume > 1.
- Nới giới hạn volume/volume keyframe lên 20. Lưu JSON/restore không ép về 1.
- Bản nháp cũ bỏ DSP/preset ẩn, quy gain dB cũ về volume nhìn thấy.
- Xác minh bằng WAV nhỏ và WebM giải mã: mức 1.000% ~10x, 2.000% ~20x RMS so với 100%.

Với chuyển cảnh, người dùng khoanh vùng hình chữ nhật ở điểm nối: đã đổi từ huy hiệu nhỏ thành vùng trong suốt phủ chiều cao clip, rộng theo thời lượng, nhãn ◇ ở trên và handle hai mép. Phần nền overlay để click xuyên nhằm giữ trim/drag clip; nhãn và handle nhận chuột.

## 10. Trạng thái bàn giao

Bản cuối đã xuất bản thành công qua GitHub Pages commit 335c391, workflow run 39154035429 (success). URL có cache-buster trong START_HERE.

Yêu cầu cuối của người dùng: đóng gói ngữ cảnh cuộc trò chuyện và mã nguồn để chuyển sang nơi khác làm tiếp. Gói này không thực hiện thêm thay đổi sản phẩm nào ngoài việc lưu tài liệu/đóng gói.
