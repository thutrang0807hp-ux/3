# Trạng thái kỹ thuật và hướng tiếp tục

## Bản chính và các entry point

Trong gói, mã dự án nằm ở `source/`. Bản tĩnh có sẵn ở `preview/`.

### Bản web hiện dùng

```sh
cd source
python scripts/demo-web/build.py
python -m http.server 8765 --bind 127.0.0.1 --directory dist/web-demo
```

Mở `http://127.0.0.1:8765/#editor`. Đây là hướng tái tạo bản công khai hiện tại, không cần FastAPI, Node, Rust hay API key cho phần dựng browser.

Build sử dụng:

- `preview.html`: shell SceneForge và các tab.
- `scripts/demo-web/build.py`: build shell root index.html/studio.html, cache-bust iframe từ hash nội dung editor.
- `scripts/native-preview/build.py`: chuẩn bị static assets/reference, rồi gọi build_full_editor.py.
- `scripts/native-preview/build_full_editor.py`: ghép template/CSS/JS của browser engine thành `dist/web-demo/native/index.html` tự chứa.
- Iframe chính `/native/?embedded=1&v=...`: chỉ tạo một lần; đổi tab không hủy project/media, rời editor sẽ pause.

### File sửa editor thực tế

| File | Vai trò |
|---|---|
| scripts/demo-lite/app.js | Assets/tracks/items, media nodes, selection/history, playback, core transitions, geometry, drag, serialization |
| scripts/demo-lite/enhancements.js | Composition canvas, export MediaRecorder, audio routing/gain, keyframe, SRT, draft, batch commands |
| scripts/demo-lite/timeline_modes.js | Plan insert/swap/overwrite/layer, trim, group moves, boundary/new track/drop guides |
| scripts/demo-lite/interface.js | Tool palettes, icon/inspector tabs/sliders/search |
| scripts/demo-lite/workstation.js | Layout, media monitor, waveform/filmstrip, menus |
| scripts/demo-lite/studio_panels.js | Panels/templates/layout tools |
| scripts/native-preview/editor-integration.js | Shared text/subtitles, effect hình 9 mẫu, caption imports/exports/migration, shared editor boot |
| scripts/native-preview/timeline-interactions.js | Quét vùng, join blocks, resize/drop transitions, rolling trim, links, assembly dialog |
| scripts/native-preview/editing-controls.js | Dedicated transition inspector, labelled controls/keyboard, project ratio, compact audio strip |
| scripts/native-preview/editor-integration.css | Skin hiện tại, full editor layout, mini audio và join region |

Các script extension được chèn vào cùng closure engine, truy cập cùng model/history/compositor. Tránh thêm một model timeline thứ hai hoặc DOM video thứ hai chỉ để làm demo.

`window.SceneForgeEditor.getState()` trả bản clone gồm items, tracks, frame, time, mode, selectedIds và assets không có local URLs. Có seek(), isPlaying(), getReadiness(), getAudioStatus(). Không sửa state bằng cách thay clone trả về.

## Những trang cũ dễ sửa nhầm

- `scripts/native-preview/index.html`, subtitles.js/workspace-tools.js, `dist/web-demo/native/single-video.html`: bản một video + phụ đề trước đây, không phải editor mặc định hiện tại.
- `native/reference.html`: ảnh/video chụp Concat native có vùng khám phá công cụ, không phải timeline browser engine chính.
- `editor/`: OpenVideo/Next app trước đây; không phải iframe browser mới nhất trên Pages.
- `editor-demo.html`, `concat-demo.html`, `editor-native-demo.html` và nhiều root HTML: các giai đoạn prototype. Build chính có thể giữ một số trang để đối chiếu, không sử dụng làm tuyên bố về bản mặc định.
- README.md gốc chứa các hướng native/OpenVideo/web chồng lịch sử. Không dùng một dòng README cũ để kết luận entry point hiện tại.

## Model, audio và chuyển cảnh

Volume là gain tuyến tính: 1 = 100%, 10 = 1.000%, 20 = 2.000%.

- Không được gán HTMLMediaElement.volume > 1. Preview/export cần Web Audio route với gain >1; HTML volume vẫn được clamp hợp lệ.
- `extraDefaults()` có audioMuted, legacy audio fields, transitionDirection/Easing, keyframes. Build_full_editor thêm subtitle/effectTag vào defaults khi ghép.
- Audio presets/EQ đã bỏ khỏi UI theo yêu cầu cuối. Route legacy đang bypass; restore cũ quy gain dB về volume và reset effects để không có xử lý ẩn.
- Các giới hạn volume trong core setProp, restore, batch và keyframe sanitizer đều cần cho tới 20. Đừng sửa mỗi input max rồi tưởng đã khuếch đại thật.
- Mini nằm trong `.sequenceHead`; popover fade/speed ở `#timeline`. Audio selection có body.audio-mini-selected để tạm ẩn inspector. Khi đổi chọn cần khôi phục đúng workspace.
- Sửa riêng đoạn nhỏ bằng cắt clip hoặc automation volume. `updateKeyframedProp` dùng chung engine, không tạo audio giả.

Join region:

- `joinAfter()` yêu cầu hai clip hình liền nhau trên cùng track.
- `paintJoinBlocks()` tạo `.timelineJoin.joinRegion`, centered tại điểm nối, width theo transitionDuration * px, height theo clip.
- Nền region cho click xuyên; `.joinLabel` và hai `data-join-edge` nhận chuột. Bài test phải bấm nhãn khi region đã bật, không dùng force click vào nền.
- Kéo mép đối xứng quanh cut; duration clamp theo cả hai clip và tối đa 5 giây.
- Dissolve/push/wipe dùng cả hai nguồn hoạt động quanh cut; compositing của preview và canvas export cùng logic. Fade qua đen là lựa chọn khác.
- Hết source handles thì giữ khung biên; không phải optical flow.

## Geometry và phím

- projectFrame `{width,height}`, mặc định1080×1920; presets 1920×1080,1080×1080,1080×1350, custom240–3840 mỗi chiều.
- frame nằm trong snapshot/undo, JSON projectPayload và save/load. Tính viewport từ padding thực tế, không trừ một hằng số12px gây sai tỉ lệ khi preview có padding26px.
- Export video theo lựa chọn short-side720/1080 và aspect, giới hạn long-side3840. PNG dùng kích thước project; ASS dùng PlayRes và vị trí theo frame.
- Keyboard chính tại editing-controls.js; parent preview.html chỉ forward từ shell khi editor đang mở, cùng origin.
- Không ăn phím khi nhập text/number/select/contenteditable hoặc dialog. Esc khi timeline-drag-active phải tới handler cancel đang kéo; đừng stopImmediatePropagation trước nó.

## Backend và native là luồng khác

Backend: app.py, video_analysis.py, prompt_workflow.py, video_editor.py, concat_bridge.py, concat_routes.py, openvideo_bridge.py, static/, tests/.

Python requirements đã pin trong requirements.txt/requirements.lock. `python run.py` mặc định hướng native (cần FFmpeg/ffprobe và Concat build), không phải lệnh chạy bản Pages. `--web-editor` dùng OpenVideo cũ và cần Node22+/pnpm10.19.0. Xem code và docs để khởi động đúng luồng, không xóa backend chỉ vì phần preview tĩnh chạy độc lập.

Nguồn Concat trong `concat-native/`, pin v0.2.7 / 14b5998d793d90858ac982926374044bba4bf39f. Có scripts/concat-native/setup.py, env.sh, upstream.json, checksum/dependency pins. Rust target/toolchains/native deps không đi kèm ZIP. Native đã build/test trước đó trên Linux; không có xác nhận fresh install Windows mới trong gói này.

Backend có OpenAI và Google Veo code; chưa dùng key thật xác nhận luồng trả phí. Meta Muse chưa tích hợp. Mẫu UI multi-AI chưa đồng nghĩa backend đủ OpenAI/Gemini/Claude/custom.

## Kiểm chứng đã thực hiện trước khi đóng gói

Bản được kiểm tra là artifact `dist/web-demo/native/index.html`, không phải editor-demo cũ.

Các kiểm tra mới nhất đã qua:

- `python scripts/native-preview/check_audio_core.py`: mini/no presets, gain100/1000/2000 thực qua WebM/RMS, mute, fades, speed+undo, volume keys >1 giữ quaJSON, migration oldDSP, region full-height resize/undo.
- `python scripts/native-preview/check_audio_frame_controls.py`: nhãn Cut/Play, phím và typing guard, export ngang/vuông, custom PNG, frame undo/JSON. Tên script giữ từ giai đoạn trước, nội dung hiện đã bỏ test EQ cũ.
- `python scripts/native-preview/check_timeline_interactions.py`: marquee/Shift/locks/Esc/group drag, auto-scroll, region/drop/resize/remove/undo, rolling trim, blended PNG/WebM.
- `python scripts/native-preview/check_transition_details.py`: dedicated join inspector, direction/easing, upward push/right wipe pixel evidence, clamp duration.
- `python scripts/native-preview/check_assembly_links.py`: audio extraction/links, move/trim/split, independent groups aftersplit, unlink, reorder assembly +sound, undo.
- `python scripts/native-preview/check_full_workspace.py`: visual effect cards/parameters/keyframes, captions/import/export/migration.
- `python scripts/demo-web/check_integrated.py`: all navigation, parent/iframe shortcuts, preserve media, pause onleave, layout/mobile and missing-assets errors.
- `SCENEFORGE_EDITOR_PREVIEW=dist/web-demo/native/index.html python scripts/demo-lite/check_export.py`: WebM có tiếng và chữ, FFmpeg decode, cancel/reimport.
- `SCENEFORGE_EDITOR_PREVIEW=dist/web-demo/native/index.html python scripts/demo-lite/check_timeline_modes.py`: insert/swap/overwrite/layer/edge trim.

Ngoài ra các lượt trước đã kiểm check_lift_track.py, check_batch.py, check_auto_import.py, check_media.py, check_enhancements.py và native/backend suites. Những kết quả lịch sử không được coi là đã chạy lại sau mọi thay đổi; đọc audit và chạy lại phần ảnh hưởng.

Browser tests cần Playwright, Chromium, FFmpeg/ffprobe, Pillow và NumPy cho test đo tín hiệu. Scripts hiện thường hardcode `/usr/bin/chromium`; bên Windows/macOS phải đổi executable_path phù hợp hoặc dùng Chromium của Playwright. Các dependency/cache của môi trường cloud đã bị loại khỏi gói.

## Hướng tiếp tục đúng phạm vi

Giữ bản UI này làm nền. Những việc còn đáng làm sau khi trao đổi với người dùng:

1. Nối backend/queue thực với timeline browser bằng một manifest scene/clip có ID ổn định, tách các bản AI rerender và giữ lựa chọn người dùng.
2. Tự ghép chính xác thứ tự, quyết định nguồn âm, độ dài, handles/chuyển cảnh, phụ đề rồi cho duyệt trước render; retry/hủy có trạng thái thật, không tự gọi lại paidAPI ngầm.
3. Render MP4 H.264/AAC bằng FFmpeg/native backend có progress, cancel, reconnect và checksum; giữ edit decisions trên web, không ép mọi thứ vào MediaRecorder.
4. Proxy/predecode/thumbnails/waveforms cho clip lớn và timeline nhiều items; đo hiệu năng thực, không hứa60fps chỉ vì dùng rAF.
5. Phân tích cảnh tốt hơn (scene boundaries, sampling theo nhịp, audio/transcript khi được phép), prompt bám bằng chứng, nhất quán nhân vật/sản phẩm theo mẫu người dùng.
6. Whisper/local captions nếu phù hợp chi phí; không đưa lại effect âm thanh không cần vào UI chỉ để giống fullCapCut.

Không tự làm thêm các mục này trong bước đóng gói. Người nhận tiếp tục theo yêu cầu mới.

## Xuất bản và tình trạng Git

Bản static công khai nằm gh-pages của repo người dùng, commit cuối335c39137d35726c53cf87ea8db5d6c38dd0d587. Workflow pages build and deployment run39154035429 đã SUCCESS.

Workspace nguồn gốc `/workspace/3` có nhiều file untracked và branch work chưa có commit. Lượt trước dùng checkout staging riêng `/tmp/sceneforge-pages-integrated` để push các output static, không push cả source workspace lên main. Gói source là snapshot tệp hiện có, không có lịch sử.git. Đừng tự force-push main hay coi gh-pages chứa toàn bộ source.

Khi triển khai tiếp, xác định remote/branch và quyền của người dùng trong môi trường mới, build/test trước rồi publish trong phạm vi họ yêu cầu. Không có GitHub auth/secret trong gói.

## Nguồn và giấy phép

Giữ nguyên LICENSE/NOTICE của các thư mục bên thứ ba. Concat có GNU AGPLv3 và LICENSE-EXCEPTIONS.md; OpenVideo có LICENSE riêng. Không gọi tất cả là MIT hoặc gán lại bản quyền. Bản browser SceneForge và nguồn native được phân biệt rõ ở trên.
