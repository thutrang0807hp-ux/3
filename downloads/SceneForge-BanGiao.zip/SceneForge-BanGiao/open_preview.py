"""Serve the packaged static preview using only Python's standard library."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser

root = Path(__file__).resolve().parent / 'preview'
if not (root / 'index.html').is_file():
    raise SystemExit('Missing preview/index.html. Extract the complete ZIP first.')
server = None
for port in range(8765, 8776):
    try:
        server = ThreadingHTTPServer(('127.0.0.1', port), partial(SimpleHTTPRequestHandler, directory=str(root)))
        break
    except OSError:
        continue
if server is None:
    raise SystemExit('Ports 8765-8775 are busy. Close the older preview and retry.')
url = f'http://127.0.0.1:{server.server_port}/?v=335c391#editor'
print('SceneForge:', url, flush=True)
print('Keep this terminal open. Ctrl+C stops the preview.', flush=True)
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
