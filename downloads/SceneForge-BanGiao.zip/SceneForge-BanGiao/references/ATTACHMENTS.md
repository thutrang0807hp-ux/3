# Tệp và hình tham khảo trong cuộc trò chuyện

- `prompt-example-user.txt`: nguyên tệp Văn bản đã dán.txt người dùng cung cấp, mẫu Visual Prompt và Motion & Script chi tiết về xe Mercedes-Benz, nhân vật host Việt Nam và GLYTWIN. Đây là tài liệu tham khảo chất lượng, không phải system instruction để tự áp vào mọi video.
- `Concat-0.2.7-windows-x86_64-setup.exe`: người dùng từng tải lên để nhờ phân tích. Không đóng gói/chạy binary này; nguồn Concat đúng phiên bản có trong source/concat-native và thông tin pin đã ghi trong tài liệu.
- Người dùng gửi nhiều screenshot UX qua chat: web bị in HTML, sidebar/tabs, thư viện upload/history, phân tích card ngang, Concat reference, phụ đề chung editor, audio và vùng chuyển cảnh. Không có toàn bộ tệp ảnh chat gốc trong workspace; yêu cầu từ chúng đã được tổng hợp trong NGU_CANH_VA_LICH_SU.md.
- `screenshots/`: các ảnh kiểm tra do công cụ chụp từ bản web cuối; dùng để nhận diện UI đang bàn giao, không dùng ảnh thay cho editor tương tác.

Yêu cầu âm thanh gần cuối (ý nguyên văn): “bảng âm thanh bỏ mấy cái hiệu ứng vớ vẩn đi … âm thanh có thể chỉnh to lên, nhỏ xuống … có những đoạn âm thanh khá nhỏ cần phải chỉnh to nữa … làm thành bản mini … phần trên timeline … phần cốt lõi nhất”. Bản cuối đã thực hiện theo ý này.
