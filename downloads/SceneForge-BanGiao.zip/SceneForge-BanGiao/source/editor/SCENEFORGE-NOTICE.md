# SceneForge adaptation

Upstream: https://github.com/designcombo/react-video-editor
Pinned source commit: 9a8c5296da4b258f66dfb7ad73de96be62478bca

This directory vendors OpenVideo Editor. Preserve LICENSE and upstream attribution.
Its source-available license permits personal customization but restricts resale of
derivative editors. It is not MIT. See LICENSE for full terms.

SceneForge changes: /editor base path and same-origin loopback proxy, local file
upload/media instead of R2, generated-clip import, persistent local project, portrait
workspace, and a bundled DejaVu font (license in public/fonts/LICENSE.txt).
Optional API integrations (transcription, stock media) are not required for core editing.
