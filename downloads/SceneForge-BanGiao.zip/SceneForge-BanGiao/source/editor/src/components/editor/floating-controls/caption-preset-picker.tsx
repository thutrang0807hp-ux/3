"use client";
import { useEffect, useRef } from "react";
import { RiProhibitedLine, RiCloseLine } from "@remixicon/react";
import useLayoutStore from "../store/use-layout-store";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ICaptionsControlProps } from "../interface/captions";
import { NONE_PRESET, CAPTION_PRESETS } from "../constants/caption";

import { useStudioStore } from "@/stores/studio-store";
import { fontManager } from "@openvideo/engine-pixi";
import { regenerateCaptionClips } from "@/lib/caption-utils";

const CaptionPresetPicker = () => {
  const { setFloatingControl } = useLayoutStore();
  const { studio, selectedClips } = useStudioStore();
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setFloatingControl("");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [setFloatingControl]);

  const handleApplyPreset = async (preset: ICaptionsControlProps) => {
    // Filter for Captions
    const captionClips = selectedClips.filter((c) => c.type === "Caption");
    if (captionClips.length === 0) return;
    if (preset.fontFamily === undefined) {
      preset.fontFamily = "Bangers-Regular";
    }
    if (preset.fontUrl === undefined) {
      preset.fontUrl = "/editor/fonts/SceneForgeSans.ttf";
    }
    if (preset.boxShadow === undefined) {
      preset.boxShadow = { color: "transparent", x: 0, y: 0, blur: 0 };
    }
    if (preset.textTransform === undefined) {
      preset.textTransform = "none";
    }
    if (preset.textAlign === undefined) {
      preset.textAlign = "center";
    }
    if (preset.isKeywordColor === undefined) {
      preset.isKeywordColor = "transparent";
    }

    if (preset.preservedColorKeyWord === undefined) {
      preset.preservedColorKeyWord = false;
    }

    if (preset.fontSize === undefined) {
      preset.fontSize = 64;
    }

    // Load fonts if needed
    if (preset.fontFamily && preset.fontUrl) {
      await fontManager.addFont({
        name: preset.fontFamily,
        url: preset.fontUrl,
      });
    }
    const x = preset.boxShadow?.x ?? 4;
    const y = preset.boxShadow?.y ?? 0;

    // Map ICaptionsControlProps to ICaptionOpts
    const styleUpdate: any = {
      fill: preset.color,
      strokeWidth: preset.borderWidth,
      stroke: preset.borderColor,
      fontFamily: preset.fontFamily,
      fontUrl: preset.fontUrl,
      fontSize: preset.fontSize,
      align: preset.textAlign as any,
      caption: {
        colors: {
          active: { color: preset.activeColor, background: preset.activeFillColor },
          future: { color: preset.appearedColor },
          keyword: {
            color: preset.isKeywordColor ?? "transparent",
            preserveAfterSpoken: preset.preservedColorKeyWord ?? false,
          },
        },
      },
      animation: preset.animation || "undefined",
      textCase: preset.textTransform || "normal",
      dropShadow: {
        color: preset.boxShadow?.color ?? "transparent",
        alpha: 0.5,
        blur: preset.boxShadow?.blur ?? 4,
        distance: Math.sqrt(x * x + y * y) ?? 4,
        angle: Math.PI / 4,
      },
      wordAnimation: preset.wordAnimation,
      textBoxStyle: preset.textBoxStyle,
    };

    // Apply to all selected caption clips and other clips with the same mediaId
    const mediaIds = new Set<string>();
    for (const clip of captionClips) {
      if ((clip as any).mediaId) {
        mediaIds.add((clip as any).mediaId);
      }
    }

    const allCaptionClips = studio?.clips.filter((c) => c.type === "Caption") || [];

    if (preset.type === "word") {
      for (const clip of allCaptionClips) {
        await regenerateCaptionClips({
          captionClip: clip,
          mode: "single",
          fontSize:
            preset.fontSize === undefined ? (clip as any).originalOpts?.fontSize : preset.fontSize,
          fontFamily: preset.fontFamily,
          fontUrl: preset.fontUrl,
          styleUpdate: styleUpdate,
        });
      }
    } else {
      for (const clip of allCaptionClips) {
        await regenerateCaptionClips({
          captionClip: clip,
          mode: "multiple",
          fontSize:
            preset.fontSize === undefined ? (clip as any).originalOpts?.fontSize : preset.fontSize,
          fontFamily: preset.fontFamily,
          fontUrl: preset.fontUrl,
          styleUpdate: styleUpdate,
        });
      }
    }
  };

  const PresetGrid = ({ presets }: { presets: ICaptionsControlProps[] }) => (
    <div className="grid grid-cols-2 gap-2 p-4">
      <div
        className="flex h-[70px] cursor-pointer items-center justify-center bg-secondary rounded-lg hover:bg-secondary/80 transition-colors"
        onClick={() => {
          handleApplyPreset(NONE_PRESET);
        }}
      >
        <RiProhibitedLine />
      </div>

      {presets.map((preset, index) => (
        <div
          key={index}
          className="text-md flex h-[70px] cursor-pointer items-center justify-center bg-secondary overflow-hidden rounded-lg hover:ring-2 hover:ring-primary transition-all"
          onClick={() => handleApplyPreset(preset)}
        >
          {preset.previewUrl ? (
            <video
              src={preset.previewUrl}
              autoPlay
              loop
              muted
              playsInline
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="text-[10px] text-muted-foreground uppercase">Preset {index + 1}</div>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <div
      ref={containerRef}
      className="absolute left-[calc(100%+8px)] top-0 z-[200] w-64 border bg-background rounded-xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-left-2 duration-200"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b">
        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Presets</p>
        <button onClick={() => setFloatingControl("")}>
          <RiCloseLine className="h-4 w-4 cursor-pointer text-muted-foreground hover:text-white transition-colors" />
        </button>
      </div>
      <ScrollArea className="h-[400px]">
        <PresetGrid presets={CAPTION_PRESETS} />
      </ScrollArea>
    </div>
  );
};

export default CaptionPresetPicker;
