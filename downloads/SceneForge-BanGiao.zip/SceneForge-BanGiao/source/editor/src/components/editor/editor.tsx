"use client";
import { useState, useEffect } from "react";
import { Resizable } from "@/components/editor/resizable-panel";
import { useParams } from "next/navigation";
import { MediaPanel } from "@/components/editor/media-panel";
import { CanvasPanel } from "@/components/editor/canvas-panel";
import Timeline from "@/components/editor/timeline";
import { usePanelStore } from "@/stores/panel-store";
import { Loading } from "@/components/editor/loading";
import FloatingControl from "@/components/editor/floating-controls/floating-control";
import { Compositor } from "@openvideo/engine-pixi";
import { WebCodecsUnsupportedModal } from "@/components/editor/webcodecs-unsupported-modal";
import { RightPanel } from "./right-panel";
import { core } from "@/lib/project";
import { IProject } from "@openvideo/core";
import { useProjectStore } from "@/stores/project-store";
import Header from "./header";
import SceneForgeBridge, { initializeSceneForge } from "./sceneforge-bridge";
import { PreviewTransport } from "./preview-transport";
import { SequenceTabs } from "./sequence-tabs";

export default function Editor({
  initialDesign,
}: {
  isDataLoading?: boolean;
  initialDesign?: IProject;
}) {
  const resetProject = useProjectStore((state) => state.resetProject);
  const { editorMode, showLeftPanel, showRightPanel, showTimeline } = usePanelStore();

  const [isReady, setIsReady] = useState(false);
  const [isWebCodecsSupported, setIsWebCodecsSupported] = useState(true);

  useEffect(() => { initializeSceneForge().catch(console.error); }, []);

  useEffect(() => {
    const checkSupport = async () => {
      const isSupported = await Compositor.isSupported();
      setIsWebCodecsSupported(isSupported);
    };
    checkSupport();
  }, []);

  // Clear loading screen for non-editor modes (CanvasPanel doesn't mount, onReady never fires)
  useEffect(() => {
    if (editorMode !== "editor") {
      setIsReady(true);
    }
  }, [editorMode]);

  return (
    <div className="sceneforge-workspace h-screen w-screen flex flex-col bg-background overflow-hidden">
      {!isReady && (
        <div className="absolute inset-0 z-100">
          <Loading />
        </div>
      )}

      {/* Header — full width */}
      <Header />
      <SceneForgeBridge />

      {/* Main content row: left sidebar + center + right sidebar */}
      <div className="sceneforge-panes flex-1 min-h-0 flex flex-row overflow-hidden">
        {/* Left Sidebar: Media Panel */}
        {showLeftPanel && (
          <Resizable orientation="horizontal" initialSize={340} min={210} max={520} direction="right" className="sceneforge-media-pane">
            <MediaPanel />
          </Resizable>
        )}

        {/* The timeline spans all panes below, as in the Concat reference. */}
        <div className="sceneforge-preview-pane flex-1 min-w-0 h-full flex flex-col overflow-hidden">
          <div className="sceneforge-pane-title"><b>Xem trước</b><span>1080 × 1920 · 9:16</span></div>
          <div className="flex-1 min-h-0 overflow-visible">
            <CanvasPanel onReady={() => setIsReady(true)} />
          </div>
          <PreviewTransport />
        </div>

        {showRightPanel && (
          <Resizable
            orientation="horizontal"
            initialSize={290}
            min={230}
            max={520}
            direction="left"
            className="right-resizable-panel"
          >
            <RightPanel />
          </Resizable>
        )}
      </div>
      {showTimeline && (
        <Resizable orientation="vertical" initialSize={300} min={190} max={560} direction="up" className="sceneforge-timeline-pane">
          <SequenceTabs />
          <div className="sceneforge-timeline-content"><Timeline /></div>
        </Resizable>
      )}

      {/* Floating Controls like Caption / Animation pickers */}
      <FloatingControl />

      {/* WebCodecs Support Check Modal */}
      <WebCodecsUnsupportedModal open={!isWebCodecsSupported} />
    </div>
  );
}
