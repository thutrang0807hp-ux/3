"use client";

import { useStore } from "zustand";
import { core, projectStore } from "@/lib/project";
import { Button } from "@/components/ui/button";
import { RiPlayFill, RiPauseFill, RiSkipBackLine, RiSkipForwardLine, RiFullscreenLine } from "@remixicon/react";
import { frameToTimeString, timeToString } from "./utils/time";

export function PreviewTransport() {
  const currentTime = useStore(projectStore, (s) => s.currentTime);
  const duration = useStore(projectStore, (s) => s.settings.duration);
  const fps = useStore(projectStore, (s) => s.settings.fps);
  const playing = useStore(projectStore, (s) => s.isPlaying);
  const seek = (value: number) => { core.pause(); core.seek(Math.max(0, Math.min(duration, value))); };

  return <div className="sceneforge-preview-transport">
    <div className="sceneforge-preview-buttons">
      <span id="video-current-time" data-current-time={currentTime / 1e6}>
        {frameToTimeString({ frame: Math.floor(currentTime / 1e6 * fps) }, { fps })}
        <small> / {timeToString({ time: duration })}</small>
      </span>
      <div>
        <Button variant="ghost" size="icon" aria-label="Về đầu video" onClick={() => seek(0)}><RiSkipBackLine size={15} /></Button>
        <Button variant="ghost" size="icon" aria-label={playing ? "Tạm dừng" : "Phát video"} onClick={() => playing ? core.pause() : core.play()}>
          {playing ? <RiPauseFill size={17} /> : <RiPlayFill size={17} />}
        </Button>
        <Button variant="ghost" size="icon" aria-label="Đến cuối video" onClick={() => seek(duration)}><RiSkipForwardLine size={15} /></Button>
      </div>
      <Button variant="ghost" size="icon" aria-label="Toàn màn hình xem trước" onClick={(event) => {
        const pane = event.currentTarget.closest(".sceneforge-preview-pane");
        if (document.fullscreenElement) document.exitFullscreen().catch(console.error);
        else pane?.requestFullscreen().catch(console.error);
      }}><RiFullscreenLine size={15} /></Button>
    </div>
    <input type="range" min={0} max={Math.max(1, duration)} step={Math.max(1, Math.round(1e6 / fps))}
      value={Math.min(currentTime, duration)} aria-label="Tua video xem trước" onChange={(event) => seek(Number(event.target.value))} />
  </div>;
}
