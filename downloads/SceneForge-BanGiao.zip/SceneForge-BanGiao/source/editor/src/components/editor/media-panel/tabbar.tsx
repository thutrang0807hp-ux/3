"use client";

import { cn } from "@/lib/utils";
import { type Tab, tabs, useMediaPanelStore } from "./store";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export function TabBar() {
  const { activeTab, setActiveTab, isOpen, setIsOpen } = useMediaPanelStore();

  return (
    <div className="sceneforge-library-tabs relative flex items-center border-b bg-background shrink-0">
      <div className="flex items-center justify-center py-2 px-2 gap-1 w-full overflow-x-auto scrollbar-hidden">
        {(Object.keys(tabs) as Tab[]).map((tabKey) => {
          const tab = tabs[tabKey];
          const isActive = activeTab === tabKey && isOpen;
          return (
            <button
              type="button"
              className={cn(
                "sceneforge-library-tab flex flex-col items-center justify-center flex-1 cursor-pointer transition-all duration-200 gap-1",
                isActive
                  ? "bg-accent text-accent-foreground"
                  : "text-accent-foreground/80 hover:bg-accent hover:text-accent-foreground",
              )}
              onClick={() => {
                if (activeTab === tabKey && isOpen) {
                  setIsOpen(false);
                } else {
                  setActiveTab(tabKey);
                }
              }}
              key={tabKey}
              role="tab"
              tabIndex={0}
              aria-label={tab.label}
              aria-selected={isActive}
              data-openvideo-tab={tabKey}
            >
              <Tooltip delayDuration={10}>
                <TooltipTrigger asChild>
                  {isActive ? (
                    <tab.activeIcon className="size-[18px]" />
                  ) : (
                    <tab.icon className="size-[18px]" />
                  )}
                </TooltipTrigger>
                <TooltipContent side="bottom" align="center" sideOffset={8}>
                  {tab.label}
                </TooltipContent>
              </Tooltip>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
