"use client";

import { useState, useEffect } from "react";
import { useProjectStore } from "@/stores/project-store";
import { usePanelStore } from "@/stores/panel-store";
import { Button } from "@/components/ui/button";
import { ExportPopover } from "./export-popover";
import { TaskbarPopover } from "./taskbar-popover";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuPortal,
} from "@/components/ui/dropdown-menu";
import { useTheme } from "next-themes";
import {
  RiArchiveDrawerLine,
  RiSideBarLine,
  RiHomeLine,
  RiMenuLine,
  RiLayout3Line,
  RiMoonLine,
  RiSunLine,
  RiComputerLine,
} from "@remixicon/react";
import { RiLockLine, RiArrowDownSLine } from "@remixicon/react";
import { core } from "@/lib/project";
import { data } from "./data";
import { exportWorkspace, restoreWorkspace, sequenceWorkBlocked } from "@/lib/sequences";

export default function Header() {
  const { projectName, resetProject, setProjectName } = useProjectStore();
  const [isExportOpen, setIsExportOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const {
    showLeftPanel,
    showRightPanel,
    showTimeline,
    toggleLeftPanel,
    toggleRightPanel,
    toggleTimeline,
    resetLayout,
  } = usePanelStore();

  const handleNewProject = () => {
    if(sequenceWorkBlocked()){alert("Chờ nhập hoặc xuất video hoàn tất.");return;}
    resetProject();
    useProjectStore.getState().setSpaceId("sceneforge");
    core.project.new();
    core.store.getState().updateSettings({width:1080,height:1920});
    restoreWorkspace();
  };

  const handleExportJSON = () => {
    try {
      const projectData = exportWorkspace();
      const jsonString = JSON.stringify(projectData, null, 2);
      const blob = new Blob([jsonString], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${projectName || "project"}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Failed to export project:", err);
    }
  };

  const handleLoadJSON = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      try {
        if(sequenceWorkBlocked())throw Error("Chờ nhập hoặc xuất video hoàn tất.");
        if(file.size>8*1024*1024)throw Error("Tệp dự án vượt 8 MB.");
        const text = await file.text();
        const projectData = JSON.parse(text);

        const name = projectData.name || file.name.replace(/\.json$/i, "");
        restoreWorkspace(projectData);
        setProjectName(name);
      } catch (err) {
        console.error("Failed to load project JSON:", err);
        alert(err instanceof Error ? err.message : "Tệp dự án không hợp lệ.");
      }
    };
    input.click();
  };

  // Global keydown listener for Export (Ctrl+E / Cmd+E)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "e") {
        e.preventDefault();
        setIsExportOpen(true);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <div className="sceneforge-editor-header h-10 border-b shrink-0">
      <div className="h-full grid grid-cols-3 items-center px-4">
        {/* Left Column: Home, Menu, View */}
        <div className="flex items-center justify-start gap-0.5">
          {/* Home Icon */}
          <span className="sceneforge-window-dots" aria-hidden="true" />

          {/* Menu Icon with Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" aria-label="Tệp và dự án">Tệp</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56 text-xs">
              <DropdownMenuSub>
                <DropdownMenuSubTrigger className="text-xs">
                  <span className="flex-1">Theme</span>
                  {theme === "dark" ? (
                    <RiMoonLine className="size-4 text-muted-foreground" />
                  ) : theme === "light" ? (
                    <RiSunLine className="size-4 text-muted-foreground" />
                  ) : (
                    <RiComputerLine className="size-4 text-muted-foreground" />
                  )}
                </DropdownMenuSubTrigger>
                <DropdownMenuPortal>
                  <DropdownMenuSubContent className="w-36 text-xs">
                    <DropdownMenuItem className="text-xs" onClick={() => setTheme("light")}>
                      <RiSunLine className="mr-2 size-4" />
                      <span className="flex-1">Light</span>
                      {theme === "light" && <span className="text-xs">✓</span>}
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-xs" onClick={() => setTheme("dark")}>
                      <RiMoonLine className="mr-2 size-4" />
                      <span className="flex-1">Dark</span>
                      {theme === "dark" && <span className="text-xs">✓</span>}
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-xs" onClick={() => setTheme("system")}>
                      <RiComputerLine className="mr-2 size-4" />
                      <span className="flex-1">System</span>
                      {theme === "system" && <span className="text-xs">✓</span>}
                    </DropdownMenuItem>
                  </DropdownMenuSubContent>
                </DropdownMenuPortal>
              </DropdownMenuSub>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs" onClick={handleNewProject}>
                <span>Dự án mới</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs" onClick={handleLoadJSON}>
                <span>Mở dự án JSON</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs" onClick={handleExportJSON}>
                <span>Lưu toàn bộ bản dựng JSON</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* View Menu with Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-xs flex items-center gap-1">
                <RiLayout3Line className="size-4" />
                <span>Hiển thị</span>
                <RiArrowDownSLine className="size-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56 text-xs">
              <DropdownMenuItem className="text-xs" onClick={toggleLeftPanel}>
                <span className="flex-1">Kho tư liệu</span>
                {showLeftPanel && <span className="text-xs">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs" onClick={toggleRightPanel}>
                <span className="flex-1">Bảng thuộc tính</span>
                {showRightPanel && <span className="text-xs">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs" onClick={toggleTimeline}>
                <span className="flex-1">Timeline</span>
                {showTimeline && <span className="text-xs">✓</span>}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs" onClick={resetLayout}>
                <span>Khôi phục bố cục</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

        </div>


        {/* Center Column: Project Space & Details */}
        <div className="flex items-center justify-center gap-1.5 text-xs font-semibold">
          <span className="text-foreground truncate max-w-[200px]">
            {projectName || "Untitled video"}
          </span>
          <small className="text-muted-foreground">9:16</small>
        </div>

        {/* Right Column: Aspect Ratio and Export Button */}
        <div className="flex items-center justify-end gap-2">
          {/* Taskbar Button */}
          <TaskbarPopover>
            <RiArchiveDrawerLine className="size-4" />
            <span className="sr-only">Tasks</span>
          </TaskbarPopover>

          {/* Export Button */}
          <ExportPopover open={isExportOpen} onOpenChange={setIsExportOpen}>
            <Button className="h-7 text-xs font-semibold px-3 rounded-md flex items-center gap-2">
              <span>Xuất video</span>
            </Button>
          </ExportPopover>
        </div>
      </div>
    </div>
  );
}
