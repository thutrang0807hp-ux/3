export const SECONDARY_FONT_URL = "/editor/fonts/SceneForgeSans.ttf";
export const SECONDARY_FONT = "geist-regular";

export const editorFont = {
  fontFamily: SECONDARY_FONT,
  fontUrl: SECONDARY_FONT_URL,
};
