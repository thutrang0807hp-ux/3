import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import "./globals.css";
import "./sceneforge-workspace.css";
export const metadata = { title: "SceneForge · OpenVideo" };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="vi" suppressHydrationWarning><body className="antialiased"><ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}><TooltipProvider>{children}</TooltipProvider><Toaster /></ThemeProvider></body></html>;
}
