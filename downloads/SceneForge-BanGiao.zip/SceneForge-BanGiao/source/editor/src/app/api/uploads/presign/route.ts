export async function POST(){return Response.json({error:"Dùng lưu trữ cục bộ SceneForge."},{status:410});}
export const DELETE=POST;
