import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  reactStrictMode: false,
  basePath: "/editor",
  devIndicators: false,
};
export default nextConfig;
