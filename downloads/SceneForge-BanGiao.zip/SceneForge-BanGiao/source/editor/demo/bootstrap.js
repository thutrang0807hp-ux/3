(()=>{
 const videos=__DEMO_VIDEOS__,fontData=__DEMO_FONT_DATA__;
 const memory=new Map();let nativeStorage;
 try{nativeStorage=window.localStorage;nativeStorage.setItem('__demo_probe','1');nativeStorage.removeItem('__demo_probe');}catch{nativeStorage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,String(v)),removeItem:k=>memory.delete(k),key:i=>[...memory.keys()][i],get length(){return memory.size;}};}
 const prefix='sceneforge-interactive-demo:';
 const storage={getItem:k=>nativeStorage.getItem(prefix+k),setItem:(k,v)=>nativeStorage.setItem(prefix+k,String(v)),removeItem:k=>nativeStorage.removeItem(prefix+k),clear:()=>{const keys=[];for(let i=0;i<nativeStorage.length;i++){const key=nativeStorage.key(i);if(key?.startsWith(prefix))keys.push(key);}keys.forEach(k=>nativeStorage.removeItem(k));},key:i=>{const keys=[];for(let j=0;j<nativeStorage.length;j++){const k=nativeStorage.key(j);if(k?.startsWith(prefix))keys.push(k.slice(prefix.length));}return keys[i]||null;},get length(){let n=0;for(let j=0;j<nativeStorage.length;j++)if(nativeStorage.key(j)?.startsWith(prefix))n++;return n;}};
 Object.defineProperty(window,'localStorage',{value:storage});
 const decode=(b64,type)=>URL.createObjectURL(new Blob([Uint8Array.from(atob(b64),c=>c.charCodeAt(0))],{type}));
 const src=videos.map(v=>decode(v,'video/mp4'));
 const font=decode(fontData,'font/ttf');globalThis.__SCENEFORGE_DEMO_FONT__=font;
 // Original, synthesized music sample: no remote assets or third-party recording.
 const rate=16000,seconds=12,buffer=new ArrayBuffer(44+rate*seconds*2),view=new DataView(buffer);
 const str=(p,s)=>{for(let i=0;i<s.length;i++)view.setUint8(p+i,s.charCodeAt(i));};
 str(0,'RIFF');view.setUint32(4,buffer.byteLength-8,true);str(8,'WAVE');str(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,rate,true);view.setUint32(28,rate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);str(36,'data');view.setUint32(40,rate*seconds*2,true);
 const notes=[261.63,329.63,392,329.63,293.66,349.23,440,349.23];
 for(let i=0;i<rate*seconds;i++){const t=i/rate,note=notes[Math.floor(t*2)%notes.length],phase=(t*2)%1,envelope=Math.sin(phase*Math.PI)**2;view.setInt16(44+i*2,Math.sin(t*note*Math.PI*2)*envelope*800,true);}
 const audio=URL.createObjectURL(new Blob([buffer],{type:'audio/wav'}));
 const nowUrls=[...src,audio,font];
 // Demo assets belong to the library, not to one clip instance. The engine may
 // revoke a borrowed blob URL when disposing a sequence's clips; retain only
 // library-owned sources until the document is actually discarded.
 const retainedSources=new Set(nowUrls),revokeURL=URL.revokeObjectURL.bind(URL);
 const retainSource=url=>{retainedSources.add(url);return url;};
 URL.revokeObjectURL=url=>{if(!retainedSources.has(url))revokeURL(url);};
 window.addEventListener('pagehide',event=>{if(!event.persisted)retainedSources.forEach(url=>revokeURL(url));});
 let oldUrls=[];try{oldUrls=JSON.parse(storage.getItem('source-urls')||'[]');}catch{}
 function rebind(value){let text=JSON.stringify(value);oldUrls.forEach((old,i)=>{if(old&&nowUrls[i])text=text.replaceAll(old,nowUrls[i]);});return JSON.parse(text);}
 for(const key of ['project','ov_assets_sceneforge']){try{const data=storage.getItem(key);if(data)storage.setItem(key,JSON.stringify(rebind(JSON.parse(data))));}catch{storage.removeItem(key);}}
 storage.setItem('source-urls',JSON.stringify(nowUrls));
 const timing=(start,duration)=>({display:{from:start,to:start+duration},trim:{from:0,to:duration},duration,playbackRate:1,fadeIn:null,fadeOut:null});
 const transform={x:0,y:0,width:1080,height:1920,angle:0,opacity:1,zIndex:10,flip:{x:false,y:false}};
 const clips={},names=['Toàn cảnh bình minh','Nhân vật trên đường mòn','Toàn cảnh kết'];
 src.forEach((url,i)=>{clips['demo-v'+i]={id:'demo-v'+i,type:'Video',name:names[i],src:url,timing:timing(i*4e6,4e6),style:{},locked:false,effects:[],animations:[],transform:{...transform}};});
 clips['demo-title']={id:'demo-title',type:'Text',name:'Bình minh trên đồi',text:'Bình minh trên đồi',timing:timing(0,5e6),style:{fontFamily:'geist-regular',fontSize:80,fontWeight:'normal',fontStyle:'normal',fontUrl:font,color:'#ffffff',align:'center',wordWrap:true,wordWrapWidth:840},transform:{...transform,x:120,y:1420,width:840,height:200,zIndex:20},effects:[],animations:[],locked:false};
 clips['demo-music']={id:'demo-music',type:'Audio',name:'Nhạc minh họa nhẹ',src:audio,timing:timing(0,12e6),volume:.7,effects:[],animations:[],locked:false};
 const project={settings:{width:1080,height:1920,fps:30,duration:12e6,backgroundColor:'#17171b'},tracks:[{id:'demo-t',name:'Chữ',type:'text',clipIds:['demo-title'],accepts:['text']},{id:'demo-v',name:'Video',type:'video',clipIds:['demo-v0','demo-v1','demo-v2'],accepts:['video','image']},{id:'demo-a',name:'Nhạc nền',type:'audio',clipIds:['demo-music'],accepts:['audio']}],clips};
 const queue=src.map((url,i)=>({id:'demo-source-'+i,name:names[i],url,duration:4}));
 const date=new Date().toISOString();
 if(!storage.getItem('ov_assets_sceneforge'))storage.setItem('ov_assets_sceneforge',JSON.stringify([{id:'demo-audio-source',name:'Nhạc minh họa nhẹ.wav',spaceId:'sceneforge',type:'audio',src:audio,duration:12,createdAt:date,updatedAt:date}]));
 const realFetch=window.fetch.bind(window);
 window.fetch=async(input,init={})=>{
  const raw=typeof input==='string'?input:input instanceof URL?input.href:input.url;
  if(raw.startsWith('blob:')||raw.startsWith('data:'))return realFetch(input,init);
  const url=new URL(raw,['file:','about:'].includes(location.protocol)?'https://sceneforge-demo.local/':location.href),method=(init.method||input?.method||'GET').toUpperCase();
  if(url.pathname==='/api/openvideo/project'){
   if(method==='PUT'){storage.setItem('project',init.body);return Response.json({saved:true});}
   return Response.json(storage.getItem('project')?JSON.parse(storage.getItem('project')):{name:'Bình minh · bản dựng mẫu',project});
  }
  if(url.pathname==='/api/editor/clips')return Response.json(queue);
  return Response.json({error:'Bản mô phỏng không kết nối dịch vụ bên ngoài.',detail:'Chức năng này cần ứng dụng chạy thật và cấu hình dịch vụ.'},{status:503});
 };
 globalThis.__SCENEFORGE_DEMO__={project,queue,retainSource};
})();
