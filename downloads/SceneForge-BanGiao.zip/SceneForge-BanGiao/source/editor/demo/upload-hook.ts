import {useState} from 'react';
import {toast} from 'sonner';
import {useAssetsStore} from '@/stores/assets-store';
export type MediaType='image'|'video'|'audio';
export function useAssetUpload({spaceId,onComplete}:{spaceId:string|null;onComplete?:()=>void}){
 const [isUploading,setUploading]=useState(false);
 const uploadFiles=async(files:FileList|null)=>{
  if(!files)return;setUploading(true);const store=useAssetsStore.getState(),added:any[]=[];
  try{for(const file of Array.from(files)){
   const src=URL.createObjectURL(file),type:MediaType=file.type.startsWith('video/')?'video':file.type.startsWith('audio/')?'audio':'image';
   (globalThis as any).__SCENEFORGE_DEMO__?.retainSource(src);
   let duration:number|undefined,width:number|undefined,height:number|undefined;
   if(type==='video'||type==='audio')await new Promise<void>((resolve)=>{const media=document.createElement(type==='video'?'video':'audio');const timer=setTimeout(()=>resolve(),8000);media.onloadedmetadata=()=>{duration=media.duration;if(media instanceof HTMLVideoElement){width=media.videoWidth;height=media.videoHeight;}clearTimeout(timer);media.removeAttribute('src');media.load();resolve();};media.onerror=()=>{clearTimeout(timer);resolve();};media.src=src;});
   const asset={id:crypto.randomUUID(),spaceId:spaceId||'sceneforge',name:file.name,type,src,duration,width,height,size:file.size,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),uploadProgress:null};
   added.push(asset);
  }
  store.addFiles(added);toast.info('Tệp vừa thêm chỉ dùng trong phiên mô phỏng này.');const key='ov_assets_'+(spaceId||'sceneforge');localStorage.setItem(key,JSON.stringify([...JSON.parse(localStorage.getItem(key)||'[]'),...added]));onComplete?.();return added.map(a=>({success:true,fileName:a.name}));
  }finally{setUploading(false);}
 };
 return {isUploading,uploadFiles};
}
