import React from 'react';
import {createRoot} from 'react-dom/client';
import Editor from '@/components/editor/editor';
import {ThemeProvider} from '@/components/theme-provider';
import {TooltipProvider} from '@/components/ui/tooltip';
import {Toaster} from '@/components/ui/sonner';
import {useStudioStore} from '@/stores/studio-store';
import {initializeSceneForge} from '@/components/editor/sceneforge-bridge';
import {core,projectStore} from '@/lib/project';
import {useStore} from 'zustand';
import {useSequenceStore} from '@/stores/sequence-store';
import {addSequenceClip,createSequence,sequenceWorkBlocked,exportWorkspace} from '@/lib/sequences';
import {RiPlayFill,RiPauseFill,RiText,RiFileCopyLine,RiQuestionLine,RiRestartLine} from '@remixicon/react';
function DemoApp(){
 const studio=useStudioStore(s=>s.studio);
 const activeId=useSequenceStore(s=>s.activeId),busy=useSequenceStore(s=>s.busy);
 const playing=useStore(projectStore,s=>s.isPlaying);
 const [phase,setPhase]=React.useState('loading'),[message,setMessage]=React.useState('Đang mở dự án mẫu…');
 React.useEffect(()=>{
  let active=true,poll:ReturnType<typeof setInterval>|undefined;
  setPhase('loading');setMessage('Đang chuẩn bị bản dựng…');
  const deadline=setTimeout(()=>{if(active){setPhase('delayed');setMessage('Mở dự án lâu hơn dự kiến. Bạn có thể nạp lại hoặc khôi phục mẫu.');}},15000);
  const fail=(e:unknown)=>{if(active){clearTimeout(deadline);setPhase('error');setMessage('Không mở được bản dựng: '+String(e));}};
  initializeSceneForge().then(()=>{
   if(!active||!studio)return;
   const ids=Object.keys(core.project.export().clips);
   poll=setInterval(()=>{
    const clips=ids.map(id=>studio.clips.find((c:any)=>c.id===id));
    if(clips.every(Boolean)){clearInterval(poll);Promise.all(clips.map((c:any)=>c.ready)).then(()=>{if(active){clearTimeout(deadline);setPhase('ready');setMessage('Sẵn sàng · video dọc 9:16');}}).catch(fail);}
   },150);
  }).catch(fail);
  return()=>{active=false;clearTimeout(deadline);if(poll)clearInterval(poll);};
 },[studio,activeId]);
 const [help,setHelp]=React.useState(false),[exporting,setExporting]=React.useState(false),[progress,setProgress]=React.useState(0);
 const reset=()=>{if(confirm('Khôi phục bản dựng mẫu? Thay đổi trong mô phỏng sẽ được xóa.')){localStorage.clear();location.reload();}};
 const [actionBusy,setActionBusy]=React.useState(false);
 const run=async(action:()=>unknown)=>{setActionBusy(true);try{await action();}catch(e){setMessage(String(e));}finally{setActionBusy(false);}};
 const addTitle=async()=>{
  if(sequenceWorkBlocked())return;
  core.pause();const start=core.store.getState().currentTime,preset=(globalThis as any).__SCENEFORGE_DEMO__.project.clips['demo-title'];
  await addSequenceClip({type:'Text',name:'Tiêu đề của bạn',text:'CÂU CHUYỆN CỦA BẠN',timing:{...preset.timing,display:{from:start,to:start+4000000},trim:{from:0,to:4000000},duration:4000000},style:{...preset.style,fontSize:70,wordWrapWidth:850},transform:{...preset.transform,x:115,y:1250,width:850,height:180}});
  const ids=Object.keys(core.project.export().clips);
  await new Promise<void>((resolve,reject)=>{const until=Date.now()+10000;const poll=setInterval(()=>{if(ids.every(id=>studio?.clips.some((c:any)=>c.id===id))){clearInterval(poll);Promise.all(studio!.clips.map((c:any)=>c.ready)).then(()=>setTimeout(resolve,200)).catch(reject);}else if(Date.now()>until){clearInterval(poll);reject(Error('Chưa tải xong lớp chữ. Chờ thêm trước khi đổi bản dựng.'));}},100);});
 };
 const disabled=phase!=='ready'||busy>0||actionBusy;
 React.useEffect(()=>{const open=()=>{setExporting(true);setProgress(0);};window.addEventListener('sceneforge:demo-export',open);return()=>window.removeEventListener('sceneforge:demo-export',open);},[]);
 React.useEffect(()=>{if(!exporting)return;const timer=setInterval(()=>setProgress(p=>Math.min(100,p+10)),130);return()=>clearInterval(timer);},[exporting]);
 return <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}><TooltipProvider>
  <div className="demo-banner">
   <div className="demo-brand"><span className="demo-mark">S</span><div><strong>SceneForge Studio</strong><small>BẢN MÔ PHỎNG TƯƠNG TÁC</small></div></div>
   <span className="demo-status" role="status" data-phase={phase}><i/>{message}</span>
   <div className="demo-actions">
    <button disabled={disabled} onClick={()=>run(()=>playing?core.pause():core.play())}>{playing?<RiPauseFill size={15}/>:<RiPlayFill size={15}/>} {playing?'Dừng thử':'Thử phát'}</button>
    <button disabled={disabled} onClick={()=>run(addTitle)}><RiText size={15}/>Thêm tiêu đề</button>
    <button disabled={disabled} onClick={()=>run(()=>{createSequence(true);localStorage.setItem('project',JSON.stringify(exportWorkspace()));location.reload();})}><RiFileCopyLine size={15}/>Thử bản khác</button>
    <button onClick={()=>setHelp(!help)} aria-expanded={help}><RiQuestionLine size={15}/>Cách thử</button>
    <button onClick={reset} title="Xóa thay đổi của bản mô phỏng và mở lại dự án mẫu"><RiRestartLine size={15}/>Khôi phục mẫu</button>
   </div>
  </div>
  {(phase==='error'||phase==='delayed')&&<div className="demo-recovery" role="alert"><span>{message}</span><button onClick={()=>location.reload()}>Nạp lại trang</button><button onClick={reset}>Khôi phục dự án mẫu</button></div>}
  {help&&<aside className="demo-help" role="dialog" aria-label="Cách thử bản mô phỏng"><button onClick={()=>setHelp(false)} aria-label="Ẩn hướng dẫn">✕</button><h2>Thử dựng một video</h2><ol><li><b>Nhấn Thử phát</b> để xem 3 cảnh mẫu, tiêu đề và nhạc nền.</li><li><b>Chọn clip trên timeline</b> để sửa ở bảng bên phải. Kéo mép clip để cắt ngắn.</li><li><b>Thử bản khác</b> tạo bản sao để chỉnh riêng; dấu ＋ tạo bản dựng trống.</li><li><b>Tự lưu trên trình duyệt.</b> Dùng Tệp → Lưu toàn bộ bản dựng JSON để giữ dự án.</li></ol><p>Không gọi API. Xuất video chỉ mô phỏng quy trình. Video tự nhập cần chọn lại khi mở phiên mới.</p></aside>}
  <div className="demo-editor" data-ready={phase==='ready'}><Editor /></div>
  {exporting&&<div className="demo-modal-backdrop"><section className="demo-modal" role="dialog" aria-label="Mô phỏng xuất video"><small>MÔ PHỎNG QUY TRÌNH</small><h2>{progress<100?'Đang mô phỏng bước xuất…':'Đã xem xong bước xuất'}</h2><p>Ứng dụng thật sẽ dựng các lớp và tạo một MP4 9:16 ở bước này. Bản mô phỏng không render hoặc tải MP4.</p><progress max="100" value={progress}/><p>{progress}% · không gửi dữ liệu tới API</p><button onClick={()=>setExporting(false)}>Quay lại chỉnh sửa</button></section></div>}
  <Toaster />
 </TooltipProvider></ThemeProvider>;
}
createRoot(document.getElementById('demo-root')!).render(<DemoApp />);
