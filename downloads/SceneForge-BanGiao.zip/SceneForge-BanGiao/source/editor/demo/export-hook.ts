import {toast} from 'sonner';
export interface ExportSettings {includeVideo:boolean;videoCodec:string;quality:string;format:string;fps:string;resolution:string;includeAudio:boolean;audioCodec:string;audioSampleRate:string;}
export function formatBytes(n?:number){return n?`${(n/1024/1024).toFixed(1)} MB`:'—';}
export function handleDownload(){toast.info('Đây là bản mô phỏng. Xuất MP4 trong ứng dụng chạy thật.');}
export function useExport(){return {startExport:async()=>{window.dispatchEvent(new CustomEvent('sceneforge:demo-export'));}};}
