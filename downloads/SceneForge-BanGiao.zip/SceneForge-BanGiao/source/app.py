"""Local-first video reference analysis and bounded video generation queue."""
import asyncio
import base64
import json
import math
import os
import shutil
import sqlite3
import subprocess
import time
import tempfile
import uuid
from video_analysis import detect_shots, plan_samples
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field
from prompt_workflow import ANALYSIS_INSTRUCTION, WORKFLOW_VERSION, PromptPreferences, ShotSpec, audit_candidate, rewrite_instruction

ROOT = Path(__file__).resolve().parent
# Minimal dotenv loader: existing process bindings always win.
if (ROOT / '.env').exists():
    for line in (ROOT / '.env').read_text().splitlines():
        if line.strip() and not line.lstrip().startswith('#') and '=' in line:
            key, value = line.split('=', 1)
            os.environ.setdefault(key.strip(), value.strip().strip('\"').strip("'"))
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
DB = DATA / 'app.sqlite'
OPENAI_URL = 'https://api.openai.com/v1/chat/completions'
GOOGLE_URL = 'https://generativelanguage.googleapis.com/v1beta'
CONCURRENCY = max(1, min(4, int(os.getenv('VIDEO_CONCURRENCY', '1'))))
SAMPLES = max(4, min(64, int(os.getenv('MAX_SAMPLE_FRAMES', '24'))))


def connect():
    db = sqlite3.connect(DB, timeout=30)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, name TEXT, duration REAL, status TEXT, analysis TEXT, error TEXT, created REAL)')
        db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, project_id TEXT, scene INTEGER, prompt TEXT, status TEXT, operation TEXT, error TEXT, created REAL)')
        db.execute('CREATE TABLE IF NOT EXISTS clean_jobs (id TEXT PRIMARY KEY, project_id TEXT, status TEXT, settings TEXT, error TEXT, created REAL)')
        db.execute("UPDATE clean_jobs SET status='error', error='Xử lý cục bộ bị gián đoạn; có thể tạo bản mới.' WHERE status='running'")
        db.execute('CREATE TABLE IF NOT EXISTS edits (id TEXT PRIMARY KEY, status TEXT, timeline TEXT, progress INTEGER, error TEXT, created REAL, reserved TEXT)')
        db.execute("UPDATE edits SET status='error', error='Xuất bị gián đoạn; có thể xuất lại từ timeline.' WHERE status='running'")
        # An interrupted analysis is not automatically billed again.
        db.execute("UPDATE projects SET status='error', error='Phân tích bị gián đoạn. Có thể bấm phân tích lại.' WHERE status='analyzing'")
        # Resume submitted Google operations; never resubmit ambiguous requests.
        db.execute("UPDATE jobs SET status='queued' WHERE status='running' AND operation IS NOT NULL")
        db.execute("UPDATE jobs SET status='error', error='Yêu cầu bị gián đoạn trước khi lưu mã tác vụ. Kiểm tra nhà cung cấp trước khi thử lại để tránh tính phí hai lần.' WHERE status='running' AND operation IS NULL")
        db.execute("UPDATE projects SET status=CASE WHEN analysis IS NULL THEN 'uploaded' ELSE 'analyzed' END, error='Ghép bị gián đoạn; có thể ghép lại.' WHERE status='merging'")


def project(pid):
    with connect() as db:
        row = db.execute('SELECT * FROM projects WHERE id=?', (pid,)).fetchone()
    if row is None:
        raise HTTPException(404, 'Không tìm thấy video')
    return dict(row)


def update_project(pid, **fields):
    with connect() as db:
        db.execute('UPDATE projects SET ' + ','.join(f'{k}=?' for k in fields) + ' WHERE id=?', (*fields.values(), pid))


def update_job(jid, **fields):
    with connect() as db:
        db.execute('UPDATE jobs SET ' + ','.join(f'{k}=?' for k in fields) + ' WHERE id=?', (*fields.values(), jid))


async def command(*args, timeout=180):
    if args and str(args[0]) in ('ffmpeg', 'ffprobe'):
        args = (args[0], '-protocol_whitelist', 'file,pipe', *args[1:])
    proc = await asyncio.create_subprocess_exec(*map(str, args), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
    except BaseException:
        if proc.returncode is None:
            proc.kill()
        await proc.wait()
        raise
    if proc.returncode:
        # FFmpeg only processes local files, never URLs or secrets.
        raise RuntimeError(err.decode(errors='replace')[-1200:])
    return out


def key(name):
    value = os.getenv(name, '').strip()
    if not value:
        raise HTTPException(400, f'Thiếu {name}. Thêm vào .env rồi khởi động lại ứng dụng.')
    return value


def safe_error(exc):
    if isinstance(exc, HTTPException):
        return str(exc.detail)
    if isinstance(exc, httpx.HTTPStatusError):
        # Do not expose response bodies, signed URLs, headers or credentials.
        return f'API trả HTTP {exc.response.status_code}. Kiểm tra key, model, quyền truy cập và hạn mức nhà cung cấp.'
    if isinstance(exc, httpx.RequestError):
        return 'Không kết nối được API hoặc hết thời gian chờ. Kiểm tra mạng và trạng thái nhà cung cấp.'
    if isinstance(exc, (ValueError, KeyError, TypeError)):
        return 'Dữ liệu trả về không đúng cấu trúc hoặc thời gian cảnh không hợp lệ.'
    return str(exc)[:1200]


class Scene(BaseModel):
    model_config = ConfigDict(allow_inf_nan=False)
    start: float = Field(ge=0)
    end: float = Field(gt=0)
    description: str = Field(min_length=1, max_length=6000)
    prompt: str = Field(min_length=1, max_length=24000)
    negative_prompt: str = Field(default='', max_length=2000)
    visual_prompt: str | None = Field(default=None, max_length=12000)
    motion_prompt: str | None = Field(default=None, max_length=12000)
    spec: ShotSpec | None = None


class Analysis(BaseModel):
    summary: str = Field(max_length=6000)
    continuity: str = Field(max_length=6000)
    scenes: list[Scene] = Field(min_length=1, max_length=40)


def validate_timeline(analysis, duration):
    previous = 0
    for scene in analysis.scenes:
        if scene.end <= scene.start or scene.end > duration + .25 or scene.start < previous:
            raise ValueError('Invalid scene timeline')
        previous = scene.end


SYSTEM = ANALYSIS_INSTRUCTION


async def analyze(pid):
    folder = DATA / pid
    try:
        p = project(pid)
        duration = p['duration']
        shots = await detect_shots(folder / 'source', duration)
        count = min(SAMPLES, max(4, math.ceil(duration * 2), len(shots) * 3))
        samples = plan_samples(shots, count)
        content = [{'type': 'text', 'text': json.dumps({
            'duration': duration, 'detected_shots': shots,
            'sampling': 'shot-aware start/middle/end and additional frames',
            'limitations': 'Hard-cut detection is heuristic. Dissolves and fast action may be missed. Audio is not supplied.',
            'output': 'One scene per detected interval, exact supplied start/end. Separate observed spec from executable visual_prompt and motion_prompt. prompt combines the two.',
        })}]
        sampled_timestamps = []
        for i, (shot_index, stamp) in enumerate(samples):
            stamp = round(stamp, 6)
            sampled_timestamps.append(stamp)
            frame = folder / f'frame-{i:03}.jpg'
            await command('ffmpeg', '-v', 'error', '-y', '-ss', stamp, '-i', folder / 'source', '-frames:v', '1', '-vf', 'scale=768:768:force_original_aspect_ratio=decrease', frame)
            encoded = base64.b64encode(frame.read_bytes()).decode()
            content.extend([{'type': 'text', 'text': f'Shot {shot_index + 1}: Frame at {stamp:.6f}s'}, {'type': 'image_url', 'image_url': {'url': 'data:image/jpeg;base64,' + encoded, 'detail': 'high'}}])
        async with httpx.AsyncClient(timeout=240, follow_redirects=False) as client:
            response = await client.post(OPENAI_URL, headers={'Authorization': 'Bearer ' + key('OPENAI_API_KEY')}, json={
                'model': os.getenv('OPENAI_MODEL', 'gpt-4.1-mini'),
                'messages': [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': content}],
                'response_format': {'type': 'json_object'}, 'max_completion_tokens': 12000,
            })
            response.raise_for_status()
            result = Analysis.model_validate_json(response.json()['choices'][0]['message']['content'])
            validate_timeline(result, duration)
            if len(result.scenes) != len(shots):
                raise ValueError('AI changed detected shot count')
            for scene, (start, end) in zip(result.scenes, shots):
                if abs(scene.start - start) > .002 or abs(scene.end - end) > .002:
                    raise ValueError('AI changed detected boundaries')
                if not scene.visual_prompt or not scene.motion_prompt or not scene.spec or not scene.spec.evidence_timestamps:
                    raise ValueError('Missing structured prompt or observations')
                scene.prompt = scene.visual_prompt + '\n\n' + scene.motion_prompt
            for scene in result.scenes:
                if scene.spec:
                    for stamp in scene.spec.evidence_timestamps:
                        if not scene.start <= stamp <= scene.end or not any(abs(stamp - supplied) <= .002 for supplied in sampled_timestamps):
                            raise ValueError('Evidence timestamp not in supplied frames')
        update_project(pid, analysis=result.model_dump_json(exclude_none=True), status='analyzed', error=None)
    except Exception as exc:
        update_project(pid, status='error', error=safe_error(exc))


def valid_google_uri(uri):
    from urllib.parse import urlsplit
    u = urlsplit(uri)
    if u.scheme != 'https' or u.hostname != 'generativelanguage.googleapis.com' or u.username or u.password or u.port not in (None, 443):
        raise RuntimeError('API trả địa chỉ tải không nằm trên máy chủ Google được phép.')
    return uri


async def generate(job):
    jid, pid = job['id'], job['project_id']
    headers = {'x-goog-api-key': key('GEMINI_API_KEY')}
    model = os.getenv('VEO_MODEL', 'veo-3.0-generate-001')
    if not all(c.isalnum() or c in '.-' for c in model):
        raise RuntimeError('Tên VEO_MODEL không hợp lệ')
    async with httpx.AsyncClient(timeout=120, follow_redirects=False) as client:
        operation = job['operation']
        if not operation:
            r = await client.post(f'{GOOGLE_URL}/models/{model}:predictLongRunning', headers=headers, json={
                'instances': [{'prompt': job['prompt']}],
                'parameters': {'aspectRatio': '9:16', 'sampleCount': 1, 'durationSeconds': 8},
            })
            r.raise_for_status()
            operation = r.json()['name']
            update_job(jid, operation=operation)
        # Operation names must remain relative; never forward keys to arbitrary URLs.
        import re
        if not re.fullmatch(r'models/[A-Za-z0-9.\-]+/operations/[A-Za-z0-9_\-]+', operation):
            raise RuntimeError('Mã tác vụ Google không hợp lệ')
        deadline = time.monotonic() + 1800
        while time.monotonic() < deadline:
            r = await client.get(f'{GOOGLE_URL}/{operation}', headers=headers)
            r.raise_for_status()
            payload = r.json()
            if payload.get('done'):
                if payload.get('error'):
                    raise RuntimeError('Nhà cung cấp báo tác vụ thất bại. Kiểm tra bảng điều khiển Google.')
                videos = payload.get('response', {}).get('generateVideoResponse', {}).get('generatedSamples', [])
                if not videos:
                    raise RuntimeError('Không có video trả về; có thể bộ lọc nội dung đã chặn yêu cầu.')
                uri = valid_google_uri(videos[0]['video']['uri'])
                target = DATA / pid / f'{jid}.mp4'
                # First request authenticates only to Google's API. Redirect storage
                # downloads never receive the API key.
                async with client.stream('GET', uri, headers=headers) as download:
                    if download.status_code in (301, 302, 303, 307, 308):
                        location = download.headers.get('location', '')
                        from urllib.parse import urlsplit
                        parsed = urlsplit(location)
                        host = parsed.hostname or ''
                        if parsed.scheme != 'https' or not (host == 'storage.googleapis.com' or host.endswith('.googleusercontent.com')):
                            raise RuntimeError('Địa chỉ chuyển hướng tải video không được hỗ trợ.')
                        async with client.stream('GET', location) as storage:
                            storage.raise_for_status()
                            with target.with_suffix('.part').open('wb') as f:
                                async for chunk in storage.aiter_bytes():
                                    f.write(chunk)
                    else:
                        download.raise_for_status()
                        with target.with_suffix('.part').open('wb') as f:
                            async for chunk in download.aiter_bytes():
                                f.write(chunk)
                target.with_suffix('.part').replace(target)
                probe = json.loads(await command('ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name', '-of', 'json', target))
                if not probe.get('streams'):
                    raise RuntimeError('Tệp tải về không có luồng video hợp lệ.')
                update_job(jid, status='done', error=None)
                return
            await asyncio.sleep(10)
        raise RuntimeError('Đã chờ 30 phút. Tác vụ có thể vẫn chạy tại Google. Dùng Tiếp tục theo dõi, không tạo yêu cầu mới.')


async def worker():
    while True:
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            job = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
            if job:
                db.execute("UPDATE jobs SET status='running' WHERE id=?", (job['id'],))
        if job:
            try:
                await generate(dict(job))
            except Exception as exc:
                update_job(job['id'], status='error', error=safe_error(exc))
        else:
            await asyncio.sleep(1)


tasks = set()


def background(coro):
    task = asyncio.create_task(coro)
    tasks.add(task)
    task.add_done_callback(tasks.discard)


@asynccontextmanager
async def lifespan(app):
    init_db()
    workers = [asyncio.create_task(worker()) for _ in range(CONCURRENCY)]
    yield
    pending = workers + list(tasks)
    for task in pending:
        task.cancel()
    await asyncio.gather(*pending, return_exceptions=True)


app = FastAPI(title='SceneForge', lifespan=lifespan)


@app.middleware('http')
async def local_guard(request, call_next):
    # Intended for loopback use. Prevent browser-origin cross-site paid requests.
    from urllib.parse import urlsplit
    host = request.headers.get('host', '')
    if host.split(':')[0] not in ('127.0.0.1', 'localhost', 'testserver'):
        return __import__('fastapi').responses.JSONResponse({'detail': 'Chỉ hỗ trợ truy cập cục bộ.'}, status_code=403)
    origin = request.headers.get('origin')
    if origin and urlsplit(origin).netloc != host:
        return __import__('fastapi').responses.JSONResponse({'detail': 'Origin không được phép.'}, status_code=403)
    return await call_next(request)


@app.get('/api/status')
def status():
    return {'openai': bool(os.getenv('OPENAI_API_KEY')), 'veo': bool(os.getenv('GEMINI_API_KEY')), 'openai_model': os.getenv('OPENAI_MODEL', 'gpt-4.1-mini'), 'veo_model': os.getenv('VEO_MODEL', 'veo-3.0-generate-001'), 'ffmpeg': bool(shutil.which('ffmpeg') and shutil.which('ffprobe')), 'concurrency': CONCURRENCY, 'sample_frames': SAMPLES}


@app.get('/api/projects')
def projects():
    with connect() as db:
        rows = [dict(r) for r in db.execute('SELECT * FROM projects ORDER BY created DESC')]
        jobs = [dict(r) for r in db.execute('SELECT * FROM jobs ORDER BY created')]
        clean_jobs = [dict(r) for r in db.execute('SELECT * FROM clean_jobs ORDER BY created DESC')]
    for p in rows:
        p['analysis'] = json.loads(p['analysis']) if p['analysis'] else None
        p['jobs'] = [j for j in jobs if j['project_id'] == p['id']]
        p['merged'] = (DATA / p['id'] / 'merged.mp4').exists()
        p['clean_jobs'] = [j for j in clean_jobs if j['project_id'] == p['id']]
    return rows


@app.post('/api/projects')
async def upload(file: UploadFile):
    pid = uuid.uuid4().hex
    folder = DATA / pid
    folder.mkdir()
    try:
        size = 0
        with (folder / 'source').open('wb') as target:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > 500 * 1024 * 1024:
                    raise HTTPException(413, 'Video tối đa 500 MB')
                target.write(chunk)
        probe = json.loads(await command('ffprobe', '-v', 'error', '-show_entries', 'format=duration:stream=codec_type', '-of', 'json', folder / 'source', timeout=30))
        duration = float(probe['format']['duration'])
        if not math.isfinite(duration) or not 0 < duration <= 600 or not any(s.get('codec_type') == 'video' for s in probe['streams']):
            raise HTTPException(400, 'Cần video hợp lệ, thời lượng tối đa 10 phút')
        with connect() as db:
            db.execute('INSERT INTO projects VALUES (?,?,?,?,?,?,?)', (pid, (file.filename or 'Video')[:200], duration, 'uploaded', None, None, time.time()))
        return {'id': pid}
    except Exception as exc:
        shutil.rmtree(folder)
        if isinstance(exc, HTTPException):
            raise
        raise HTTPException(400, 'Không đọc được video. Kiểm tra định dạng và FFmpeg.') from None
    finally:
        await file.close()


@app.post('/api/projects/{pid}/analyze')
async def start_analysis(pid: str):
    key('OPENAI_API_KEY')
    project(pid)
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute("SELECT 1 FROM projects WHERE id=? AND status IN ('analyzing','merging')", (pid,)).fetchone():
            raise HTTPException(409, 'Video đang được xử lý')
        db.execute("UPDATE projects SET status='analyzing',error=NULL WHERE id=?", (pid,))
    background(analyze(pid))
    return {'status': 'analyzing'}


@app.get('/api/projects/{pid}/scenes/{index}/evidence')
async def scene_evidence(pid: str, index: int):
    p = project(pid)
    if not p['analysis']:
        raise HTTPException(409, 'Video chưa được phân tích.')
    analysis = Analysis.model_validate_json(p['analysis'])
    if index < 0 or index >= len(analysis.scenes):
        raise HTTPException(404, 'Không tìm thấy cảnh.')
    scene = analysis.scenes[index]
    # Read the exact images/times used by the model whenever they are available.
    evidence = sorted({t for t in scene.spec.evidence_timestamps if math.isfinite(t) and scene.start <= t < scene.end}) if scene.spec else []
    margin = min(.04, (scene.end - scene.start) / 10)
    times = ([evidence[0], evidence[len(evidence)//2], evidence[-1]] if len(evidence) >= 3
             else [scene.start + margin, (scene.start + scene.end) / 2, scene.end - margin])
    frames = []
    with tempfile.TemporaryDirectory(prefix='evidence-', dir=DATA / pid) as temp:
        for i, stamp in enumerate(times):
            frame = Path(temp) / f'{i}.jpg'
            await command('ffmpeg', '-v', 'error', '-y', '-ss', stamp, '-i', DATA / pid / 'source',
                          '-frames:v', '1', '-vf', 'scale=360:640:force_original_aspect_ratio=decrease', frame)
            frames.append({'timestamp': stamp, 'image': 'data:image/jpeg;base64,' + base64.b64encode(frame.read_bytes()).decode()})
    return {'frames': frames, 'basis': 'model_evidence' if len(evidence) >= 3 else 'source_preview',
            'description': scene.description, 'uncertainties': scene.spec.uncertainties if scene.spec else [],
            'audio_analyzed': False}


@app.put('/api/projects/{pid}/analysis')
def save_analysis(pid: str, body: Analysis):
    p = project(pid)
    if p['status'] in ('analyzing', 'merging'):
        raise HTTPException(409, 'Đợi xử lý hoàn tất trước khi sửa')
    try:
        validate_timeline(body, p['duration'])
    except ValueError:
        raise HTTPException(400, 'Thời gian cảnh không hợp lệ hoặc chồng nhau') from None
    update_project(pid, analysis=body.model_dump_json(exclude_none=True), status='analyzed', error=None)
    return {'saved': True}


class RewriteRequest(BaseModel):
    scenes: list[int] = Field(min_length=1, max_length=8)
    preferences: PromptPreferences = Field(default_factory=PromptPreferences)
    acknowledge_cost: bool = False


class PromptCandidate(BaseModel):
    scene: int = Field(ge=0)
    prompt: str = Field(min_length=1, max_length=24000)
    visual_prompt: str | None = Field(default=None, max_length=12000)
    motion_prompt: str | None = Field(default=None, max_length=12000)
    audio_prompt: str | None = Field(default=None, max_length=4000)
    dialogue: str | None = Field(default=None, max_length=5000)
    continuity_locks: list[str] = Field(default_factory=list, max_length=30)
    negative_prompt: str = Field(default='', max_length=2000)
    observed_facts: list[str] = Field(default_factory=list, max_length=30)
    requested_changes: list[str] = Field(default_factory=list, max_length=20)
    uncertainties: list[str] = Field(default_factory=list, max_length=20)
    reference_usage: list[str] = Field(default_factory=list, max_length=20)


class RewriteResult(BaseModel):
    candidates: list[PromptCandidate] = Field(min_length=1, max_length=8)


@app.post('/api/projects/{pid}/prompts/rewrite')
async def rewrite_prompts(pid: str, body: RewriteRequest):
    if not body.acknowledge_cost:
        raise HTTPException(400, 'Cần xác nhận phí trước khi gọi AI viết lại prompt.')
    api_key = key('OPENAI_API_KEY')
    p = project(pid)
    if p['status'] in ('analyzing', 'merging'):
        raise HTTPException(409, 'Đợi tác vụ hiện tại hoàn tất.')
    if not p['analysis']:
        raise HTTPException(400, 'Phân tích video trước khi viết lại prompt.')
    analysis = Analysis.model_validate_json(p['analysis'])
    indices = list(dict.fromkeys(body.scenes))
    if body.preferences.package == 'production' and len(indices) > 3:
        raise HTTPException(400, 'Bộ Visual + Motion tối đa 3 cảnh mỗi lượt để tránh cắt cụt đầu ra.')
    if any(i < 0 or i >= len(analysis.scenes) for i in indices):
        raise HTTPException(400, 'Cảnh không tồn tại.')
    content = [{'type': 'text', 'text': json.dumps({
        'workflow': WORKFLOW_VERSION,
        'preferences': body.preferences.model_dump(),
        'source_continuity_hypothesis': analysis.continuity,
        'scenes': [{'index': i, **analysis.scenes[i].model_dump(exclude_none=True)} for i in indices],
        'audio': 'not_analyzed',
    }, ensure_ascii=False)}]
    try:
        # Re-check the actual scene frames instead of rewriting an old paragraph
        # as if that previous model response were ground truth.
        for i in indices:
            scene = analysis.scenes[i]
            end_sample = max(scene.start, scene.end - .05)
            for n, stamp in enumerate([scene.start, (scene.start + end_sample) / 2, end_sample]):
                frame = DATA / pid / f'rewrite-{uuid.uuid4().hex}.jpg'
                try:
                    await command('ffmpeg', '-v', 'error', '-y', '-ss', stamp, '-i', DATA / pid / 'source', '-frames:v', '1', '-vf', 'scale=768:768:force_original_aspect_ratio=decrease', frame)
                    encoded = base64.b64encode(frame.read_bytes()).decode()
                finally:
                    frame.unlink(missing_ok=True)
                content += [{'type': 'text', 'text': f'Scene index {i}; source frame at {stamp:.3f}s; sample {n+1}/3.'}, {'type': 'image_url', 'image_url': {'url': 'data:image/jpeg;base64,' + encoded, 'detail': 'high'}}]
        async with httpx.AsyncClient(timeout=240, follow_redirects=False) as client:
            response = await client.post(OPENAI_URL, headers={'Authorization': 'Bearer ' + api_key}, json={
                'model': os.getenv('OPENAI_MODEL', 'gpt-4.1-mini'),
                'messages': [{'role': 'system', 'content': rewrite_instruction(body.preferences)}, {'role': 'user', 'content': content}],
                'response_format': {'type': 'json_object'}, 'max_completion_tokens': 12000,
            })
            response.raise_for_status()
            result = RewriteResult.model_validate_json(response.json()['choices'][0]['message']['content'])
        if sorted(c.scene for c in result.candidates) != sorted(indices):
            raise ValueError('Unexpected or duplicate scene indices')
        if body.preferences.package == 'production' and any(not (c.visual_prompt or '').strip() or not (c.motion_prompt or '').strip() for c in result.candidates):
            raise ValueError('Incomplete production package')
        return {'workflow': WORKFLOW_VERSION, 'provider': 'OpenAI', 'saved': False, 'audio_analyzed': False,
                'candidates': [{**c.model_dump(), 'warnings': audit_candidate(c.model_dump(), body.preferences)} for c in result.candidates]}
    except Exception as exc:
        raise HTTPException(502, safe_error(exc)) from None


class Batch(BaseModel):
    scenes: list[int] = Field(min_length=1, max_length=40)
    max_clips: int = Field(ge=1, le=40)
    acknowledge_cost: bool = False


@app.post('/api/projects/{pid}/generate')
def queue_generation(pid: str, body: Batch):
    key('GEMINI_API_KEY')
    p = project(pid)
    if not body.acknowledge_cost:
        raise HTTPException(400, 'Cần xác nhận số clip có tính phí')
    if p['status'] in ('analyzing', 'merging'):
        raise HTTPException(409, 'Video đang được xử lý')
    if not p['analysis']:
        raise HTTPException(400, 'Phân tích video trước')
    analysis = Analysis.model_validate_json(p['analysis'])
    indices = list(dict.fromkeys(body.scenes))
    if len(indices) > body.max_clips or any(i < 0 or i >= len(analysis.scenes) for i in indices):
        raise HTTPException(400, 'Số cảnh vượt giới hạn đã chọn hoặc cảnh không tồn tại')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute("SELECT 1 FROM jobs WHERE project_id=? AND status IN ('queued','running')", (pid,)).fetchone():
            raise HTTPException(409, 'Dự án đã có tác vụ đang chờ hoặc đang chạy')
        # Explicit batch limit; no automatic regeneration or paid retries.
        for i in indices:
            scene = analysis.scenes[i]
            prompt = scene.prompt + ('\nAvoid: ' + scene.negative_prompt if scene.negative_prompt else '')
            db.execute('INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?)', (uuid.uuid4().hex, pid, i, prompt, 'queued', None, None, time.time()))
    # Previous export no longer represents the current requested generation.
    (DATA / pid / 'merged.mp4').unlink(missing_ok=True)
    return {'queued': len(indices)}


@app.post('/api/jobs/{jid}/cancel')
def cancel(jid: str):
    with connect() as db:
        changed = db.execute("UPDATE jobs SET status='cancelled' WHERE id=? AND status='queued'", (jid,)).rowcount
    if not changed:
        raise HTTPException(409, 'Chỉ hủy được tác vụ chưa gửi. Tác vụ đã gửi có thể đã tính phí.')
    return {'cancelled': True}


@app.post('/api/jobs/{jid}/resume')
def resume(jid: str):
    key('GEMINI_API_KEY')
    with connect() as db:
        changed = db.execute("UPDATE jobs SET status='queued', error=NULL WHERE id=? AND status='error' AND operation IS NOT NULL", (jid,)).rowcount
    if not changed:
        raise HTTPException(409, 'Không có mã tác vụ để tiếp tục theo dõi')
    return {'resumed': True}


async def merge(pid, jobs):
    folder = DATA / pid
    try:
        normalized = []
        for i, job in enumerate(jobs):
            dest = folder / f'merge-{i}.mp4'
            # Normalize dimensions/fps; v1 exports visual track only. Do not mix
            # unrelated generated voices/music across scenes.
            await command('ffmpeg', '-v', 'error', '-y', '-i', folder / f"{job['id']}.mp4", '-vf', 'scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=24', '-an', '-c:v', 'libx264', '-threads', '2', '-preset', 'fast', '-pix_fmt', 'yuv420p', dest, timeout=600)
            normalized.append(dest)
        listing = folder / 'concat.txt'
        listing.write_text('\n'.join("file '" + f.name + "'" for f in normalized))
        await command('ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '1', '-i', listing, '-c', 'copy', '-movflags', '+faststart', folder / 'merged.tmp.mp4', timeout=600)
        (folder / 'merged.tmp.mp4').replace(folder / 'merged.mp4')
        update_project(pid, status='analyzed', error=None)
    except Exception as exc:
        update_project(pid, status='error', error=safe_error(exc))


@app.post('/api/projects/{pid}/merge')
async def start_merge(pid: str):
    p = project(pid)
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        current = db.execute('SELECT status FROM projects WHERE id=?', (pid,)).fetchone()
        if current['status'] in ('merging', 'analyzing'):
            raise HTTPException(409, 'Video đang được xử lý')
        all_jobs = [dict(r) for r in db.execute('SELECT * FROM jobs WHERE project_id=? ORDER BY created', (pid,))]
        if any(j['status'] in ('queued', 'running') for j in all_jobs):
            raise HTTPException(409, 'Đợi hàng đợi hoàn tất trước khi ghép')
        latest = {}
        for j in all_jobs:
            if j['status'] != 'cancelled':
                latest[j['scene']] = j
        count = len(json.loads(p['analysis'])['scenes']) if p['analysis'] else 0
        if not count or any(i not in latest or latest[i]['status'] != 'done' for i in range(count)):
            raise HTTPException(400, 'Cần clip thành công cho mọi cảnh; phiên bản mới nhất của mỗi cảnh phải hoàn tất')
        jobs = [latest[i] for i in range(count)]
        db.execute("UPDATE projects SET status='merging',error=NULL WHERE id=?", (pid,))
    background(merge(pid, jobs))
    return {'status': 'merging'}


@app.get('/api/projects/{pid}/export')
def export(pid: str):
    p = project(pid)
    if not p['analysis']:
        raise HTTPException(400, 'Chưa có prompt')
    from fastapi.responses import Response
    return Response(p['analysis'], media_type='application/json', headers={'Content-Disposition': 'attachment; filename="prompts.json"'})


@app.get('/api/projects/{pid}/media/{name}')
def media(pid: str, name: str):
    project(pid)
    import re
    if name not in ('source', 'merged.mp4') and not re.fullmatch(r'(?:clean-)?[a-f0-9]{32}\.mp4', name):
        raise HTTPException(404)
    path = DATA / pid / name
    if not path.is_file():
        raise HTTPException(404)
    return FileResponse(path, media_type='video/mp4', filename=name if name != 'source' else None)


class LogoRegion(BaseModel):
    model_config = ConfigDict(allow_inf_nan=False)
    x: float = Field(ge=0, lt=1)
    y: float = Field(ge=0, lt=1)
    width: float = Field(gt=0, le=1)
    height: float = Field(gt=0, le=1)
    start: float = Field(default=0, ge=0)
    end: float | None = Field(default=None, gt=0)


class CleanRequest(BaseModel):
    regions: list[LogoRegion] = Field(min_length=1, max_length=8)
    mode: str = Field(pattern='^(delogo|blur)$', default='delogo')


def update_clean(jid, **fields):
    with connect() as db:
        db.execute('UPDATE clean_jobs SET ' + ','.join(f'{k}=?' for k in fields) + ' WHERE id=?', (*fields.values(), jid))


async def clean_video(pid, jid, settings):
    folder = DATA / pid
    partial = folder / f'clean-{jid}.tmp.mp4'
    try:
        probe = json.loads(await command('ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height:stream_tags=rotate:stream_side_data=rotation', '-of', 'json', folder / 'source'))
        stream = probe['streams'][0]
        width, height = stream['width'], stream['height']
        rotation = float(stream.get('tags', {}).get('rotate', 0))
        for side in stream.get('side_data_list', []):
            rotation = float(side.get('rotation', rotation))
        if round(rotation) % 180:
            width, height = height, width
        if width < 16 or height < 16:
            raise RuntimeError('Video quá nhỏ để xử lý vùng logo.')
        filters = []
        current = '0:v:0'
        for i, region in enumerate(settings.regions):
            # delogo needs neighboring pixels, so reserve a two-pixel margin.
            x = max(2, min(width - 6, round(region.x * width)))
            y = max(2, min(height - 6, round(region.y * height)))
            w = max(2, min(width - x - 2, round(region.width * width)))
            h = max(2, min(height - y - 2, round(region.height * height)))
            end = region.end if region.end is not None else project(pid)['duration']
            enable = f"between(t,{region.start:.6f},{end:.6f})"
            out = f'out{i}'
            if settings.mode == 'delogo':
                filters.append(f"[{current}]delogo=x={x}:y={y}:w={w}:h={h}:enable='{enable}'[{out}]")
            else:
                radius = max(1, min(12, (min(w, h) - 1) // 4))
                # yuv444p avoids crop rounding on odd chroma coordinates.
                filters.extend([
                    f'[{current}]format=yuv444p,split=2[base{i}][patch{i}]',
                    f'[patch{i}]crop={w}:{h}:{x}:{y},boxblur=luma_radius={radius}:luma_power=3:chroma_radius={radius}:chroma_power=3[blur{i}]',
                    f"[base{i}][blur{i}]overlay={x}:{y}:enable='{enable}'[{out}]",
                ])
            current = out
        await command('ffmpeg', '-v', 'error', '-y', '-i', folder / 'source', '-filter_complex_threads', '1', '-filter_complex', ';'.join(filters), '-map', f'[{current}]', '-map', '0:a:0?', '-c:v', 'libx264', '-threads', '2', '-preset', 'fast', '-crf', '19', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', partial, timeout=1800)
        partial.replace(folder / f'clean-{jid}.mp4')
        update_clean(jid, status='done', error=None)
    except Exception as exc:
        partial.unlink(missing_ok=True)
        update_clean(jid, status='error', error=safe_error(exc))


@app.post('/api/projects/{pid}/clean')
async def start_clean(pid: str, settings: CleanRequest):
    p = project(pid)
    for region in settings.regions:
        end = region.end if region.end is not None else p['duration']
        if region.x + region.width > 1.000001 or region.y + region.height > 1.000001 or not region.start < end <= p['duration'] + .01:
            raise HTTPException(400, 'Vùng chọn hoặc khoảng thời gian nằm ngoài video.')
    jid = uuid.uuid4().hex
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute("SELECT 1 FROM clean_jobs WHERE status='running'").fetchone():
            raise HTTPException(409, 'Đang xử lý một video. Đợi hoàn tất để tránh quá tải máy.')
        db.execute('INSERT INTO clean_jobs VALUES (?,?,?,?,?,?)', (jid, pid, 'running', settings.model_dump_json(), None, time.time()))
    background(clean_video(pid, jid, settings))
    return {'id': jid, 'status': 'running'}


@app.get('/', response_class=HTMLResponse)
@app.get('/index.html', response_class=HTMLResponse, include_in_schema=False)
def homepage():
    # Ship CSS and JS with the document: no separate stylesheet request to fail
    # when served through a path-prefix proxy or a cached preview.
    html = (ROOT / 'static' / 'index.html').read_text()
    html = html.replace('<link rel="stylesheet" href="./style.css">', '<style>' + (ROOT / 'static' / 'style.css').read_text() + (ROOT / 'static' / 'editor.css').read_text() + (ROOT / 'static' / 'timeline.css').read_text() + '</style>')
    html = html.replace('<script src="./app.js"></script>', '<script>' + (ROOT / 'static' / 'timeline.js').read_text() + '\n' + (ROOT / 'static' / 'editor.js').read_text() + '\n' + (ROOT / 'static' / 'app.js').read_text() + '</script>')
    return HTMLResponse(html, headers={'Cache-Control': 'no-store'})




from video_editor import register_editor
register_editor(app, lambda: DATA, connect, command, lambda coro: background(coro), safe_error)

from openvideo_bridge import register_openvideo
register_openvideo(app, lambda: DATA)

from concat_routes import register_concat
register_concat(app, ROOT, DATA, connect)

app.mount('/', StaticFiles(directory=ROOT / 'static', html=True), name='static')
