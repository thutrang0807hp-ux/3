# Quy trình viết prompt dựa trên bằng chứng

Nghiên cứu ngày 15/10/2026. Đọc mã/tài liệu trực tiếp từ các URL dưới đây, không chỉ README. Không cài hay chạy skill bên ngoài, không sao chép nguyên văn mã hoặc bộ chỉ dẫn của các repo.

| Nguồn đã đọc | Ý tưởng sử dụng | Điều chỉnh cho ứng dụng |
| --- | --- | --- |
| [imooooc/video-to-prompt: prompt-template.ts](https://github.com/imooooc/video-to-prompt/blob/main/app/lib/prompt-template.ts) | Nhịp hành động theo thời gian, ngôn ngữ đạo diễn, tránh kể lại chung chung | Không ép mọi cảnh thành 3–6 nhịp hoặc làm tròn ranh giới; đầu vào ảnh không được giả vờ đã nghe âm thanh |
| [LunarXuan: analysis-contract](https://github.com/LunarXuan/video-prompt-reverse/blob/main/references/analysis-contract.md) | Trạng thái đầu/cuối, tách chuyển động chủ thể/máy, khung bằng chứng, bất biến và điều chưa biết | Hợp đồng nhỏ gọn theo từng cảnh; không tự bịa tiêu cự hoặc suy luận từ một ảnh |
| [LunarXuan: model-adapters](https://github.com/LunarXuan/video-prompt-reverse/blob/main/references/model-adapters.md) | Cách trình bày theo model; giữ prompt độc lập với tham số API | Profile chỉ là hướng dẫn viết. Không coi thông tin phiên bản/khả năng API trong repo là tài liệu chính thức hiện hành |
| [zhengzhentao86: prompt-framework](https://github.com/zhengzhentao86/reverse-video-prompt/blob/main/references/prompt-framework.md) | Khóa số chủ thể, vai trò máy, trạng thái đồ vật, thứ tự và tiếp xúc vật lý; học cách viết từ prompt tham khảo | Nhánh bán hàng chỉ dùng khi chọn rõ; không ép cảnh đời thường thành quảng cáo, không tự thêm hook/lời thoại/chứng minh công dụng |

## Luồng chuẩn

Đầu ra của không gian này cố định **9:16** theo yêu cầu người dùng. `PromptPreferences.aspect_ratio` chỉ chấp nhận `9:16`; trình tạo Veo và bộ ghép cũng dùng khung dọc. Nếu nguồn khác tỉ lệ, việc bố cục lại phải được ghi nhận, không giả vờ giữ nguyên mọi chi tiết khung nguồn.

1. **Bằng chứng:** trích khung hình có timestamp, phân biệt dữ kiện nhìn thấy và suy đoán. Lấy mẫu có thể bỏ sót động tác/cắt cảnh.
2. **Khóa cảnh:** số người/vật, vị trí, trang phục, bối cảnh và chi tiết phải giữ xuyên cảnh.
3. **Diễn tiến:** trạng thái đầu → hành động/đường đi → trạng thái cuối. Tách chuyển động người/vật, chuyển động máy và chuyển cảnh. Cảnh tĩnh không cần bịa hành động.
4. **Biên soạn:** chọn bám gốc/biến thể/quảng cáo, cấu trúc nhịp thời gian/đoạn văn/khối, ngôn ngữ, độ dài, model đích. Chỉ áp dụng thay đổi được người dùng yêu cầu.
5. **Rà soát:** đối chiếu dữ kiện gốc, mâu thuẫn, thay đổi ngoài yêu cầu, mức chắc chắn và negative prompt có mục đích. Không dùng điểm “giống 95%” giả.
6. **Duyệt:** bản mới là ứng viên; không tự ghi đè prompt đang dùng. Với nhiều AI, dùng cùng hợp đồng đầu vào, so sánh sự khác biệt và cảnh báo trước khi chọn. Số AI tăng thì số yêu cầu API tăng.

## Trong mã và bản xem trước

### Hồ sơ bộ sản xuất Visual + Motion

Theo cấu trúc mẫu do người dùng cung cấp, `PromptPreferences.package="production"` yêu cầu các trường riêng: `visual_prompt`, `motion_prompt`, `audio_prompt`, `dialogue`, `continuity_locks`, cùng bản gộp để sao chép. Cho phép mô tả dài khi cần khóa danh tính, vật liệu, trạng thái sản phẩm, kích thước tương đối, vị trí tay, vùng nhãn không bị che, bề mặt tiếp xúc và phần được phép chuyển động. Lặp lại các khóa thiết yếu trong từng cảnh độc lập; không chỉ ghi “giống cảnh trước”.

Có thể cung cấp `character_bible`, `environment_bible`, `product_bible`, `audio_direction` và `dialogue`. Đây là yêu cầu sản xuất người dùng nhập, không tự coi là dữ kiện đã quan sát. Các màu/phiên bản theo cảnh phải được ghi rõ; mâu thuẫn cần rà soát. Không suy ra kích thước thật/tiêu cự từ ảnh nếu chưa có cơ sở, không tự sinh lời thoại vì đầu vào phân tích chưa có âm thanh. Audio/Dialogue được bỏ trống nếu chưa có dữ liệu.

Tham chiếu sản phẩm trong văn bản không có nghĩa là ảnh đã được đính kèm hoặc API đã khóa được nhãn từng pixel. Chữ 8k hoặc cờ `--ar 916` không bảo đảm độ phân giải hay khả năng của API khác. Giới hạn bộ sản xuất: 3 cảnh mỗi lượt viết lại để giảm nguy cơ đầu ra bị cắt cụt. Bản xem trước minh họa cấu trúc bằng dữ liệu phong cảnh có sẵn, chưa gọi AI viết hoặc kết nối tài sản tham chiếu thật.

- `prompt_workflow.py` chứa hợp đồng `ShotSpec`, thiết lập có kiểm tra kiểu và chỉ dẫn phân tích/viết lại dùng cho backend.
- API phân tích hiện yêu cầu mô tả có cấu trúc và timestamp bằng chứng. Dữ liệu cũ chưa có `spec` vẫn đọc được.
- API viết lại nhận xác nhận phí và chỉ hỗ trợ OpenAI trực tiếp ở bản hiện tại. Kết quả trả về chưa tự lưu; Gemini/Claude trong bản xem trước vẫn là mô phỏng.
- Tab **Quy trình viết** trong `preview.html` giải thích từng bước và cho xem hợp đồng đầu vào đã chọn. Ví dụ biên soạn cục bộ minh họa quy trình; không phải mô hình suy luận, không đo chất lượng thực tế.
- Link người dùng dán chỉ là ghi chú. Muốn học nội dung cụ thể phải dán nội dung; không khẳng định đã đọc một trang chưa truy cập.
- API chưa thử bằng key thật; chất lượng viết cần đánh giá bằng clip thực tế. Quy trình và mẫu tốt hơn không bảo đảm video tạo ra giống nguyên bản.

## Shot-aware analysis (v2)

The live `/api/projects/{id}/analyze` flow now uses FFmpeg's scene-change score
(threshold 0.30, scaled to 160px wide) before selecting frames. This is a local
alternative to adding PySceneDetect/OpenCV; PySceneDetect, Qwen and VideoLLaMA
are **not** installed or integrated. Hard cuts are heuristic: dissolves, camera
flashes, very short shots and fast motion can be misclassified. Audio is not read.

Each detected interval gets at least three frames near its start, middle and end;
remaining frame slots favor longer intervals. `MAX_SAMPLE_FRAMES` remains the
hard image budget (default 24, maximum 64). If all intervals cannot be covered,
analysis stops before the paid API request and asks for a shorter source or a
larger budget. No shot is silently discarded. There is one OpenAI request per
analysis and no automatic paid retry. Image detail and output length affect cost.

The model returns observed `spec` plus separate `visual_prompt` and `motion_prompt`.
The server validates interval count/boundaries and supplied evidence timestamps,
then combines the two prompt blocks into the editable generation `prompt`.
Analyst uncertainty belongs in `spec.uncertainties`, not in generation prose.
The live page shows observations separately from prompts; older saved projects
remain compatible. Structural validation is not a guarantee of visual accuracy.

`preview.html` remains a standalone UI mock. It shows an expandable sample
observation section and cleaner sample Motion prose; uploaded preview videos do
not invoke this backend. Run the FastAPI application for actual API analysis.

## Practical review controls

The live app now exposes `GET /api/projects/{id}/scenes/{index}/evidence` and a
per-scene comparison button. It extracts JPEG frames locally without an API call.
When at least three valid model evidence timestamps exist, those timestamps are
used; otherwise it explicitly labels the frames as source previews near the
start/middle/end. Temporary JPEGs are removed after the response. Returned model
uncertainties stay separate from the positive generation prompt.

The standalone preview adds a collapsed review section and on-demand comparison
of actual frames from the sample video. Its compact shared-description dialog
stores only character/product/environment text in localStorage, with a session
fallback when storage fails. Saving preserves current drafts. Opening the writing
assistant passes the descriptions into the existing production-bible fields;
faithful-mode conflict handling still applies. These controls do not imply that
preview uploads have been analyzed or that an API has been called.
