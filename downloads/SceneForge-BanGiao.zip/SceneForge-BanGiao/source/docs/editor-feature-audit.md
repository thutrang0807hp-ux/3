# Kiểm tra phần dựng video

Bản web hiện dùng timeline đa lớp của dự án, thay cho trang một video + track phụ đề. Đây là trình dựng web của SceneForge, không phải Concat native chạy trong trình duyệt.

| Yêu cầu | Kết quả kiểm tra | Bằng chứng |
|---|---|---|
| Kéo tư liệu / tệp vào timeline | Qua: thêm đúng một lần, chèn không chồng clip | check_auto_import.py |
| Nhập nhiều video tự có track riêng | Qua: hai video, gồm tệp 35 giây, giữ đủ thời lượng | check_auto_import.py |
| Nhấc clip lên hoặc vào khe giữa các track | Qua: tạo track đúng vị trí, giữ thời gian, hoàn tác và hủy kéo | check_lift_track.py |
| Chèn / đổi chỗ / ghi đè / lớp riêng | Qua: không đè ngầm ở chế độ chèn; ghi đè giữ các phần nguồn còn lại | check_timeline_modes.py |
| Kéo mép cắt clip | Qua: giới hạn nguồn, tránh chồng, đẩy clip sau khi chọn chèn | check_timeline_modes.py |
| Chọn nhiều và sửa nhóm | Qua: Shift, Ctrl+A/Esc, di chuyển, kéo nhóm, tách, nhân đôi, xóa và undo | check_batch.py |
| Hình/tiếng/chữ tách track | Qua: nhập video, ảnh, audio, sửa chữ, phát tiếng thật | check_media.py |
| Bảng effect dễ nhìn | Qua: 9 thẻ trước/sau, nhóm, tìm kiếm, clip đích, mô tả, số và thanh trượt | check_full_workspace.py |
| Effect gắn vào clip | Qua: độ sáng 115→132%, undo; zoom tạo 2 keyframe, chỉnh mức cuối 135% | check_full_workspace.py |
| Keyframe và màu | Qua: nội suy, giữ keyframe khi tách, lật, kiểu chữ, PNG ghép thật | check_enhancements.py |
| Quét vùng chọn | Qua: kéo vùng trống, Shift thêm/bớt, bỏ qua track khóa, Esc hủy kéo nhóm | check_timeline_interactions.py |
| Kéo clip theo khung hình | Qua: gộp pointer events bằng rAF, tự cuộn khi giữ chuột sát biên, Esc phục hồi | check_timeline_interactions.py |
| Khối chuyển cảnh trên timeline | Qua: dấu + tại điểm nối, kéo mẫu vào, kéo mép đổi thời lượng, Delete/undo | check_timeline_interactions.py |
| Hòa hai hình thật | Qua: hai nguồn cùng hiện, điểm giữa có cả đỏ và xanh trong preview, PNG và WebM giải mã | check_timeline_interactions.py |
| Cắt điểm nối | Qua: dài clip trước/ngắn clip sau, giữ tổng thời lượng, đổi đúng source-in | check_timeline_interactions.py |
| Hình–tiếng liên kết | Qua: tách tiếng tự liên kết; chọn, kéo, cắt mép, tách cùng nhau; bỏ liên kết/undo | check_assembly_links.py |
| Xếp clip nối tiếp | Qua: xem/sửa thứ tự trong hộp thoại, đặt chuyển cảnh, di chuyển tiếng đi cùng, undo cả lần | check_assembly_links.py |
| Thanh âm thanh mini | Qua: nằm trên timeline; 0–2.000%, mute; vào/ra dần và tốc độ trong nút mở nhỏ; bỏ preset/EQ và sidebar âm thanh | check_audio_core.py |
| Khuếch đại âm thanh nhỏ thật | Qua: WAV nhỏ xuất ở 100%, 1.000%, 2.000%; RMS giải mã tăng khoảng 10 và 20 lần; gain/keyframe >100% giữ qua JSON | check_audio_core.py |
| Vùng chuyển cảnh theo hình yêu cầu | Qua: phủ chiều cao clip, rộng theo thời lượng, có nhãn và hai tay nắm; vẫn cắt được mép clip | check_audio_core.py, check_timeline_interactions.py |
| Khung ngang / dọc / vuông / tùy chỉnh | Qua: preview theo tỉ lệ; xuất 1280×720, 720×720, PNG 1000×700; undo và JSON giữ khung | check_audio_frame_controls.py |
| Nút và bàn phím | Qua: nhãn Cắt/Phát, Space, Ctrl+B, Ctrl+Z, tua từng frame; bảo vệ ô nhập; chuyển phím từ sidebar vào iframe | check_audio_frame_controls.py, scripts/demo-web/check_integrated.py |
| Bảng chuyển cảnh chi tiết | Qua: ảnh hai clip, type/duration/direction/easing, xem điểm nối, bỏ/undo; PNG kiểm chứng push dọc và wipe ngang | check_transition_details.py |
| Chuyển cảnh cơ bản | Qua: áp fade vào clip, chỉnh 1,1 giây, kiểm tra opacity ở điểm nối | check_full_workspace.py |
| Phụ đề trong cùng trình dựng | Qua: 4 kiểu, VTT/SRT, ASS, chặn thời gian chồng, giữ bản chữ cũ | check_full_workspace.py |
| Lưu / mở dự án | Qua: JSON không ghi URL tệp cục bộ; chọn lại tệp gốc để nối media | check_media.py, check_auto_import.py |
| Xuất video thật | Qua: WebM 720×1280, âm thanh có tín hiệu, chữ vàng đã burn-in; hủy và nhập lại | check_export.py |
| Tích hợp SceneForge | Qua: giữ dự án khi đổi tab, dừng phát khi rời dựng, desktop đầy khung và mobile không tràn ngang | scripts/demo-web/check_integrated.py |

## Phần chưa coi là hoàn thiện

- Chưa tự nhận giọng nói; chưa chạy chuỗi API phân tích → tạo clip → tự ghép trong trang tĩnh.
- MP4 phụ thuộc codec trình duyệt. Lượt kiểm tra thực tế chỉ hỗ trợ WebM VP9/VP8 + Opus; cần backend/native để bảo đảm MP4.
- Xuất qua trình duyệt theo thời gian thực, cần giữ trang ở phía trước; chưa có render nền nhanh bằng native engine.
- Chưa có tracking, mask chuyên sâu, tách nền AI, speech/TTS hoặc toàn bộ bộ chuyển cảnh của Concat/CapCut.
- Theo yêu cầu mới, preset/EQ/đổi màu âm thanh đã bỏ khỏi UI và tắt khi đọc bản nháp cũ. Gain cũ được quy về phần trăm âm lượng hiển thị; giữ mute, fade, speed và mốc âm lượng.
- Tăng âm lượng là khuếch đại, không phục hồi nội dung lời nói đã mất. Chưa có khử nhiễu AI hay voice cloning. Giữ cao độ khi đổi tốc độ phụ thuộc hỗ trợ của trình duyệt.
- Xuất web vẫn ở 24 fps. Khung tùy chỉnh mỗi chiều từ 240 đến 3840 px; xuất video theo lựa chọn độ phân giải và giữ tỉ lệ, PNG dùng đúng kích thước dự án.
- Hòa hình dùng phần nguồn ngoài mép cắt khi có; nếu hết nguồn thì giữ khung biên. Đây chưa phải optical flow.
- Cắt điểm nối chưa áp dụng đồng thời cho các cặp hình–tiếng đã liên kết; cần dùng cắt mép đồng bộ hoặc bỏ liên kết.
- Liên kết hiện tự tạo khi tách âm thanh; chưa có liên kết tùy ý mọi loại clip.
- Xếp clip nối tiếp xử lý clip đã có trên timeline, chưa tự nhận kết quả từ hàng đợi API. Nhạc/phụ đề giữ nguyên thời gian và cần duyệt lại sau khi đổi thứ tự cảnh.
- Chưa có proxy tự động trong bản web; chỉ tối ưu cập nhật thao tác kéo và tính các cặp hòa hình một lần mỗi khung.
- Mở lại dự án chứa tệp trên máy cần chọn lại đúng tệp nguồn.

## Tái kiểm tra bản sẽ xuất bản

Build: `python scripts/demo-web/build.py`.

Với từng test trong `scripts/demo-lite/` nêu trên, đặt `SCENEFORGE_EDITOR_PREVIEW=dist/web-demo/native/index.html` để kiểm chính artifact sẽ xuất bản thay vì bản cũ. Các test chính gồm `check_lift_track.py`, `check_timeline_modes.py`, `check_auto_import.py`, `check_batch.py`, `check_media.py`, `check_enhancements.py`, `check_export.py`. Chạy thêm `python scripts/native-preview/check_audio_core.py`, `python scripts/native-preview/check_audio_frame_controls.py`, `python scripts/native-preview/check_transition_details.py`, `python scripts/native-preview/check_timeline_interactions.py`, `python scripts/native-preview/check_assembly_links.py`, `python scripts/native-preview/check_full_workspace.py` và `python scripts/demo-web/check_integrated.py`.

Các check `check_subtitles.py`, `check_workspace_tools.py` cũ hiện nhắm trang lưu trữ `single-video.html`, không được dùng để tuyên bố tính năng của timeline đa lớp.
