# OpenVideo integration

The live SceneForge **Dựng video** tab now embeds the vendored OpenVideo application,
not the custom prototype timeline. Upstream source/commit/license are recorded in
`editor/SCENEFORGE-NOTICE.md`. The original license is retained in `editor/LICENSE`.
It permits personal customization; this is source-available, not an MIT component.

## Concat reference layout in the running editor

The native-engine web editor now uses the supplied Concat reference arrangement:
media / preview / properties across the top and a resizable timeline spanning the
entire bottom. The playback controls and scrubber sit below the preview and remain
available when the timeline is hidden. The existing View menu hides/restores panes.
Library tabs are keyboard-accessible buttons with Vietnamese icon labels; changing
the library tab preserves the current clip selection and its properties. Charcoal
panes, cyan actions, pink text clips, green audio clips and a red playhead match the
reference. Output stays 1080×1920; the rendering, project and export engine remains
OpenVideo. Concat Rust/Slint source is not incorporated.

The dependency-free `preview.html` and `concat-demo.html` retain their separate
prototype engine. Their inspector groups can be collapsed without altering clip
data. Changes to a prototype are not automatically changes to the native engine;
the layout described above was implemented separately in its React components.

Validation: production Next build and TypeScript; `scripts/check_native_layout.py`
checks the running editor with local API fixtures for queue import, saved/reloaded
portrait projects, adding text, selection persistence, playback/scrubbing and pane
hide/reset. Start Next on loopback port 3100 (or set `SCENEFORGE_EDITOR_URL`) before
running the check. It does not write backend project data or call AI providers.

## Run

Install Python 3.11+, FFmpeg and Node.js 22 LTS or newer. Run `python run.py` (or
`start.bat`/`start.sh`). On first launch the launcher installs the pinned editor
lockfile using pnpm 10.19.0 and builds it. Later launches reuse dependencies/builds
unless their inputs change. It starts the Next editor on loopback, then FastAPI;
Ctrl+C stops both processes. `--port` and `--editor-port` select unused ports.
`python run.py --check` checks prerequisite availability without installing.

Use **Hàng đợi → Đưa vào Dựng video** on a completed clip. Import uses the existing
local media URL with the actual generated duration. Later imports append to the
same project, and switching tabs preserves the iframe session. Other finished clips
are available through **Clip từ Hàng đợi** in the editor toolbar and the asset bin.

## Storage and APIs

Media uploads are local, capped at 500 MB, under `data/openvideo/`; no R2/S3 account
is required. Projects autosave to `data/openvideo/project.json`, including layer
structure and stable source URLs. The active sequence and the other sequences are
restored together; JSON import/export saves the whole workspace. Media-library metadata
is also held in browser storage. Uploaded source files are not embedded in exported
project JSON and must remain on the machine. Queue originals are never deleted
through the editor's local-asset deletion endpoint.

## Multiple sequences

The native editor and `editor-native-demo.html` provide independent sequence tabs
above the timeline. Use **＋** for an empty sequence and **Quản lý bản dựng** for
duplicate, rename or delete. Each sequence stores a separate 9:16 edit graph; all
sequences share the media library. Duplicating does not duplicate media bytes.
Deleting needs confirmation, keeps at least one sequence and preserves source media.
Sequence deletion/renaming is not part of clip Undo history.

Clip Undo/Redo history stays separate per sequence in the current session, and
does not survive a page reload. Switching pauses playback, clears selection and
resets the playhead to zero. Switching is blocked while adding clips or while an
export job is pending/processing. These are independent cuts, not nested sequences.

Autosave/JSON use `format: sceneforge-sequences`, version 1, with an active sequence
id, all snapshots, and a top-level `project` for the existing backend contract.
Legacy single-project JSON still opens. Maximum 12 sequences; the backend's 8 MiB
project limit still applies. Legacy consumers that only understand one graph can
use the top-level `project` field. Original source files must remain available.

`scripts/check_native_sequences.py` exercises edit isolation, separate Undo/Redo,
duplicate/rename, delete confirmation, autosave/reload and full JSON roundtrip with
local API fixtures. The standalone native demo embeds sample media and browser-local
API/storage adapters. Its export step is explicitly simulated; the running app
retains actual video export.

The active canvas is portrait 9:16. The existing OpenVideo tools handle independent
video/audio/image/text layers, transforms, timeline editing, transitions/effects and
preview/export. These are upstream engine tools, not newly re-created controls.
Some upstream tools, presets and labels remain in English.

Base editing uses no paid API. Stock-media and automatic-transcription integrations
remain optional upstream services; automatic captions need a configured provider
and are not claimed to be free or verified. Local manual text and audio work without
them. External catalog/preset preview images may be unavailable offline.

## Export

The engine composes the actual layer/effect graph in the browser using WebCodecs
and PixiJS. Use a recent Chrome/Edge browser; available codecs depend on the browser
and device. If AAC encoding is unavailable, the browser renders with Opus and the
local FFmpeg finalizer converts only the audio to AAC while copying the video.
Encoder errors and empty blobs now fail explicitly instead of downloading a 0-byte
file. Finalizer temporary files are removed after the response.

## Validation performed

- Frozen dependency installation, production Next build, and TypeScript check.
- Actual loopback proxy and editor startup through `run.start_editor`.
- Browser UI: queue clip import; Add Text; local WAV upload; independent Audio clip;
  project autosave and restoration after reload; real MP4 download.
- ffprobe confirmed downloaded export: 720×1280, audio present, approximately 5.03s.
- Backend tests cover local media/range delivery, project persistence, safe deletion,
  and Opus-to-AAC finalization with video copied.
- An upstream OPFS-cache contention warning can appear when a resource is decoded
  concurrently; the tested source load, saved project and export completed through
  the engine fallback. Some external preset-thumbnail requests failed in this cloud
  environment; local text rendering and export passed.

## Lightweight interactive preview

Open `preview.html` for the original studio interface and sidebar. Only Dựng video
uses the dark editor. `editor-demo.html` is that editor pane alone, with no duplicate
application navigation. It is self-contained and has no package or network dependency.

The preview now uses independent video/image, text and audio items with their own
start times, source in-points and durations. Add or remove tracks, lock/hide/mute
tracks, drag assets into matching tracks, move items between compatible tracks,
trim edges, split, duplicate with insertion, ripple delete, snap, zoom and undo/redo.
Video and audio use native browser playback; text overlays can be dragged on canvas.

The inspector edits speed, fit, position, rotation, scale, opacity, audio volume and
fade times, or text content/size/color/alignment/background/position. Fade through
black, slide and wipe previews apply at adjacent cuts with editable durations;
a button applies the setting to all adjacent cuts on the same track. This does not
provide overlapping cross-dissolve transitions or parity with CapCut.

The asset bin supports grid/list and collapse. Drag panel borders to resize the bin,
inspector or timeline. Import local video/audio/image files. Generated sample audio
is an actual local WAV. No analysis, AI generation or paid API calls run here.

Save/open project downloads and reads a JSON edit plan. Built-in samples reconnect
automatically. User media bytes and blob URLs are excluded; reimport files with their
original names to reconnect sources. Switching to other studio tabs pauses playback and preserves the editor iframe and edit state. A local JSON draft can now be recovered on the next visit when browser storage is available; source files still need reconnecting.
The preview now also exports real browser-recorded video with composited visuals, text and mixed audio. Available MP4 or WebM formats depend on MediaRecorder support; this environment verified WebM VP9/Opus, including finite duration metadata and reimport. Export is real-time, limited to 120 seconds and 24 fps. The separate workflow-simulation button still creates no file. See [feature inventory](editor-features.md) for exact capabilities, missing features and validation. The normal launcher continues to use the separate full OpenVideo application.

Sources: `scripts/demo-lite/template.html`, `style.css`, `app.js`, `enhancements.js`,
`timeline_modes.js`, `interface.js`, `workstation.js`, `studio_panels.js`,
`reference_chrome.js`, `reference_skin.css`, `screenshot_skin.css`. Rebuild standalone
and studio embed with `python scripts/demo-lite/build.py`. With Playwright and
Chromium installed, run `python scripts/demo-lite/check_demo.py` for the interaction
smoke check. `python scripts/demo-lite/check_media.py` also checks native local-media playback, media reconnect and text undo. These checks use real browser interactions without paid APIs or a server.

The optional native-engine demo bundle can be generated separately with
`node scripts/demo-builder/build.mjs` after installing its dependencies and building
Next CSS. It writes `SceneForge-Demo.html` and the compatible `editor-native-demo.html` without replacing the lightweight preview.
The compact demo toolbar provides play/pause, a portrait-safe title preset, duplicate
sequence, optional help and a scoped sample reset. It starts with sample video,
text and audio. Readiness follows the active sequence; delayed or failed loading
shows recovery actions without an extra full-screen demo overlay. Export remains
explicitly simulated in these standalone files.

Standalone demo checks: `python scripts/demo-builder/check_demo.py`,
`python scripts/demo-builder/check_quick_actions.py`, and
`python scripts/demo-builder/check_recovery.py` use Chromium/Playwright with no API.
The demo toolbar's duplicate action saves the new workspace and reloads it to
avoid reusing renderer clip instances while copying a populated sequence.

### Compatible design preview

Build `SceneForge-XemThu.html` and `SceneForge-XemThu.zip` with
`python scripts/demo-builder/build_compatible.py` after generating both editor
bundles. It starts with the existing DOM-based Concat-style prototype and embeds
the native editor as an opt-in mode, preserving the other app files. Mode changes
do not transfer projects. The native mode checks WebCodecs/WebGL2 and falls back
after a startup timeout. The default prototype needs neither API.

The ZIP includes a Python 3 standard-library launcher, a Windows batch entry and
Vietnamese instructions. Extract first; run `python run_demo.py` or `MO_DEMO.bat`
(Windows with Python 3). It binds only 127.0.0.1 on an available port, opens the
browser and serves only the preview, without exposing the repository.
`python scripts/demo-builder/check_compatible.py` exercises this HTTP handler
with WebGL disabled and VideoDecoder absent: sample playback, text, split/undo,
JSON download and unsupported-native mode feedback. Direct file navigation cannot
be verified here because the environment browser blocks file:// by policy.

### Executable Windows simulation

`SceneForge-MoPhong-Windows.zip` contains `Mo-SceneForge.exe`, built for
Windows 10/11 x86-64 with Go's standard library. It embeds the existing lightweight
Concat-style editor, the full SceneForge prototype and a small mode switcher.
It serves only these pages on loopback and opens the default browser; no Python,
Node, API keys or internet are needed at runtime. Port 43927 is preferred; an
available port is used if occupied. Keep its console open during use. Both
workspaces stay mounted when switching modes. AI analysis/generation is simulated.

Source: `scripts/demo-desktop/`. Build with a real Go compiler (not the GNU Go
game executable also named `go`) using
`SCENEFORGE_GO=/path/to/go python scripts/demo-desktop/build.py`. This creates
a Linux test executable and Windows executable from the same embedded sources.
`python scripts/demo-desktop/check.py` tests the compiled Linux server over actual
HTTP: HTML MIME type, playback, edit/split/undo/save, all six app tabs and retained
state across modes. Windows PE format/architecture was verified; Windows startup
and default-browser integration have not been executed in this Linux environment.
The Windows application is unsigned. No Concat or OpenVideo engine code is included
in this executable; the existing native demo remains separate.

### Published interactive preview

URL: https://thutrang0807hp-ux.github.io/3/
Source branch: `gh-pages` of `thutrang0807hp-ux/3`; the development checkout and
its current branch were not committed or pushed. The first Pages build/deployment
was reported successful by GitHub Actions:
https://github.com/thutrang0807hp-ux/3/actions/runs/39030609343

Regenerate the static folder with `python scripts/demo-web/build.py`. It contains
only the preview shell, DOM editor, full studio prototype, `.nojekyll` and a short
README. Routes are relative so the app works under the repository subpath.
Validation used a real local HTTP server under `/web-demo/`, testing playback,
studio navigation and return to the existing editor session. Direct requests to
the public github.io domain are blocked from this execution environment; the
public deployment URL and successful status were verified through GitHub's run
page. AI operations remain simulated; no backend or API credentials are published.
