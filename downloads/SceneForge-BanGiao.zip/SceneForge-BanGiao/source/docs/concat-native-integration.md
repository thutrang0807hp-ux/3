# Concat gốc trong SceneForge

Đây là tích hợp với mã nguồn và engine Concat thật, không phải bản dựng lại bằng HTML.

- Upstream: https://github.com/jub0t/concat
- Tag: `v0.2.7`
- Commit: `14b5998d793d90858ac982926374044bba4bf39f`
- Mã nguồn tại `concat-native/`, hiện không có sửa đổi so với upstream.
- Giấy phép AGPL-3.0-or-later và plugin exception được giữ trong cây nguồn.
- `concat_bridge.py` chỉ dùng API JSON-RPC công khai. Không sao chép các thành phần trình dựng vào bridge.

## Đã chạy và kiểm tra

Trên môi trường Linux hiện tại:

- Build thành công `concat-cli` và cửa sổ `concat` từ chính mã nguồn upstream, Rust 1.93.1, Cargo.lock giữ nguyên.
- Bản chính thức được tải để đối chiếu, xác minh SHA-256 theo release gốc.
- Cả bản chính thức và bản tự build vượt qua `--version`, `--smoke` với Xvfb + renderer software.
- Cửa sổ tự build mở dự án dọc, có 3 video, chữ, âm thanh và timeline thật.
- API nhập clip, đặt nối tiếp đúng thời lượng, tách clip, undo và render ảnh xem trước.
- Xuất thật MP4 H.264 + AAC, 1080×1920, dài 12 giây; ffprobe xác nhận thông số.
- 49 test concat-core, 114 test concat-project và 2 doctest đã qua (165 tổng cộng).
- `scripts/concat-native/check_bridge.py` dùng engine vừa compile để kiểm tra đường nối HTTP: chỉ clip done, ID hợp lệ, thứ tự, 9:16, split/undo, PNG thật, không ghi đè dự án cũ và dọn dự án mới khi nhập lỗi.
- 19 test backend Python cũ cũng đã qua sau khi thêm native routes.
- `check_ui.py` kiểm tra nút chuyển clip từ UI, nút mở ứng dụng và chuyển tab; lớp HTTP trong test UI dùng fixture, việc nhập engine thật được kiểm tra riêng ở check_bridge.py.

## Cài đặt lại và chạy trong cloud này

Helper `python3 scripts/concat-native/setup.py --build` đã được chạy lại thành công với cache hiện tại: kiểm tra pin upstream và checksum, tái tạo dependency prefix khi cần và build bằng Cargo.lock. Cài từ máy sạch hoàn toàn chưa được kiểm chứng trong một môi trường mới. Bản nháp cấu hình môi trường đã lưu cả `install_script` và `start_skill`; cần review/save và Publish trong Environment Settings để áp dụng cho các phiên sau.

## Chạy lại trong cloud này

```sh
cd /workspace/3
. scripts/concat-native/env.sh
cd concat-native/src
cargo +1.93.1 build --locked -p concat-cli -p concat
cargo +1.93.1 test --locked -p concat-core -p concat-project
```

Các thư viện native được tải qua chỉ mục Debian có chữ ký và giải nén vào `.native-deps/sysroot`, không cài đè thư viện hệ thống. Rust nằm trong `.toolchains`. Bản ghi các gói và SHA-256: `scripts/concat-native/debian-packages.json`. Cấu hình môi trường đầy đủ tại `env.sh`. Sherpa được xác minh bằng script `scripts/ci/fetch.sh` và `deps.lock` của upstream; ONNX Runtime lấy từ gói Concat chính thức đã xác minh.

Cửa sổ cần một display thật. Ở cloud không có màn hình, khởi động Xvfb (chỉ làm nếu display chưa tồn tại):

```sh
. /workspace/3/scripts/concat-native/env.sh
Xvfb :87 -screen 0 1440x1000x24 -nolisten tcp -ac -fp built-ins
```

Trong một shell khác:

```sh
. /workspace/3/scripts/concat-native/env.sh
/workspace/3/concat-native/src/target/debug/concat --project /workspace/3/data/Concat-Native-9x16
```

Có thể chụp đúng cửa sổ đang chạy bằng `python scripts/concat-native/snapshot.py /tmp/concat.png`. Display này chỉ dùng nội bộ để kiểm chứng, không phải link web công khai.

## Đường nối vào ứng dụng

`python run.py` hiện mặc định không khởi động Next/OpenVideo. Không cần Node cho luồng native. Tab Dựng video gọi:

- `GET /api/concat/status`: kiểm tra engine thực sự khởi động được và trả version.
- `POST /api/concat/launch`: gửi lệnh mở Concat để tự nhập video.
- `POST /api/concat/projects`: nhận `job_ids`, chỉ đọc tệp cục bộ của các tác vụ đã done, tạo dự án riêng 1080×1920 và mở bằng Concat. Thứ tự trong danh sách là thứ tự clip trên timeline.

Ví dụ body: `{"job_ids":["<id-32-hex>"],"open_editor":true}`. Mỗi lần tạo là dự án mới, không ghi vào bản đang chỉnh. Bridge dùng một tiến trình `concat-cli api` riêng và đóng sau khi lưu. Không cần mở cổng API desktop hay truyền key nhà cung cấp AI vào Concat. Bước chuyển clip không phân tích/generate AI lại và không phát sinh lượt API.

Bản cũ OpenVideo vẫn còn tại `/editor` khi chạy `python run.py --web-editor`, dành cho đối chiếu, không còn là trình dựng mặc định.

## Chạy trên máy cá nhân và phần còn lại

Cần build/cài engine và cửa sổ đúng hệ điều hành. Đặt `CONCAT_CLI_BIN` và `CONCAT_EDITOR_BIN` bằng đường dẫn executable khi chúng không ở PATH hoặc `concat-native/src/target/<profile>/`. Thư viện DLL/dylib phải đi cùng bản build theo hướng dẫn upstream. Các biến này không phải API key.

**Chưa build/kiểm tra gói Windows mới.** Binary tạo trong phiên này là Linux. Chưa đóng gói trình cài đặt SceneForge + Concat cho Windows. Gói `.exe` mô phỏng cũ không phải bản native này. Các bước Windows chính xác của upstream nằm trong `.github/workflows/build-app.yml`; không thể đổi tên binary Linux thành .exe để sử dụng.

Chưa nhúng các nút phân tích/prompt vào UI Slint. Hiện chúng ở SceneForge, kết quả hàng đợi được chuyển sang Concat qua API. Chưa thực hiện lượt OpenAI/Veo có tính phí trong các kiểm tra này. Chưa tải hoặc kiểm tra model Whisper/TTS/cutout; các chức năng và màn hình gốc của chúng vẫn được giữ nguyên trong source.

Cửa sổ desktop không chạy trên GitHub Pages. Link xem thử đã công bố trước đây vẫn là prototype web cũ. Để tương tác với bản gốc, cần chạy ứng dụng native trên máy hoặc một dịch vụ desktop từ xa; chưa triển khai dịch vụ đó.

Nếu phân phối Concat đã sửa mã nguồn, giữ nghĩa vụ AGPL, cung cấp source tương ứng và đổi tên/icon theo TRADEMARK.md. Bản đang dùng không sửa UI/engine nên không tự nhận là phiên bản Concat mới.


## Bản xem thử giao diện native trên web

Trang `https://thutrang0807hp-ux.github.io/3/native/` chứa 11 ảnh chụp cửa sổ Concat 0.2.7 được build từ source gốc, các vùng bấm để chuyển bảng, video thao tác desktop thật và MP4 xuất bằng engine native (1080×1920, H.264/AAC). Đây là bản xem bố cục và video; không nhập hoặc sửa clip trực tiếp trong trang.

Tạo lại trang bằng `python scripts/native-preview/build.py`; kiểm tra HTTP, vùng bấm, phát video và màn hình điện thoại bằng `python scripts/native-preview/check.py`. `capture.py` chỉ dùng khi ứng dụng native và dự án mẫu đã mở trên display :87; ảnh/video đã chụp được giữ tại `scripts/native-preview/assets/`.


### SceneForge web và Concat cùng một trang

Trang gốc GitHub Pages hiện dùng giao diện SceneForge với thanh bên đầy đủ. Tab Dựng video (`/#editor`) nhúng bản xem thử native qua `native/?embedded=1`; các tab còn lại giữ bản mô phỏng thư viện, prompt, hàng đợi và thiết lập. Cửa sổ xem thử được giữ khi đổi tab; video tự dừng khi rời tab. Không có chuyển clip sang engine thật trên trang tĩnh. Luồng native thực tế vẫn dùng backend/desktop được mô tả ở trên.

Build: `python scripts/demo-web/build.py`. Kiểm tra tích hợp: `python scripts/demo-web/check_integrated.py`.


### Tải giao diện và video

Bản xem thử native chỉ tải MP4 khi mở chế độ video tương ứng. Ảnh được giải mã trước khi hiển thị; thao tác đổi bảng nhanh chỉ áp dụng lựa chọn cuối. Bộ nhớ ảnh được giới hạn 2 ảnh trên màn hình nhỏ và 4 ảnh trên máy tính, có nạp trước một bảng kế tiếp khi nhàn rỗi (bỏ qua khi tiết kiệm dữ liệu hoặc mạng 2G). Khi tải lỗi, giữ hình cũ và cho thử lại. Video dừng khi rời tab hoặc ẩn trang, bấm lại tab video đang mở không dừng phát. Asset JS/CSS và iframe dùng phiên bản theo nội dung để hạn chế chạy mã cũ sau cập nhật.

Kiểm tra mạng chậm/lỗi và tải video theo nhu cầu: `python scripts/native-preview/check_loading.py`. Đây là tối ưu bản xem giao diện, không phải kiểm chứng hiệu năng kéo clip trong engine desktop.


### Phụ đề trong bản web

Tab Dựng video có mục Phụ đề thao tác được, tách khỏi ảnh giao diện native: bốn preset (trắng viền, vàng, nền tối, tối giản), cỡ/vị trí chữ cho 9:16, danh sách câu, sửa nội dung/thời gian, thêm trong khoảng trống, xóa, hoàn tác/làm lại và lưu bản chữ cục bộ. Nhập SRT/VTT có kiểm tra thời gian, chồng lấn và thời lượng. Video dọc do người dùng chọn được mở qua object URL, không tải lên máy chủ; tối đa 500 MB/10 phút.

Xuất SRT UTF-8 hoặc ASS với PlayRes 1080×1920. SRT không chứa kiểu chữ; ASS chưa phải MP4 đã gắn chữ. Cần FFmpeg/libass hoặc trình dựng để burn-in. Các preset CSS xem trước và renderer ASS có thể khác nhau về font fallback và xuống dòng. Tự nhận giọng nói và xuất MP4 có phụ đề trên trang tĩnh chưa được kết nối. Nội dung mặc định là minh họa, không phải transcript của nhạc/video mẫu. Video mẫu riêng được chuẩn bị từ các clip fixture và nhạc, không có tiêu đề native đè lên phụ đề.

Mở trực tiếp: `/?tool=subtitles#editor`. Chạy `python scripts/native-preview/check_subtitles.py` để kiểm tra sửa tiếng Việt, 4 preset, đồng bộ thời gian, nhập tệp, lưu/hoàn tác, SRT/ASS, video cục bộ và giao diện nhỏ. Đã kiểm tra libass đọc ASS xuất từ trình duyệt và render video H.264 1080×1920 cục bộ; đó không phải endpoint xuất trên web.


### Phụ đề nằm trong khung dựng

Phụ đề không còn là mode/tab cấp trên riêng. Nút Chữ & phụ đề trong khung dựng (hoặc hotspot chữ của ảnh Concat) mở workspace web ngay bên trong `#viewer`. Workspace dùng bố cục ba bảng: mẫu chữ bên trái, video ở giữa, chỉnh câu bên phải; phía dưới có track video và track phụ đề cùng thước thời gian, playhead và thu phóng. Bấm đoạn phụ đề để chọn/tua tới câu; sửa thời gian cập nhật vị trí/độ dài đoạn ngay. Đây là timeline phụ đề web, chưa phải native engine và chưa hỗ trợ kéo/cắt clip video trong trình duyệt. Chuyển Tư liệu/Âm thanh/Chuyển cảnh quay về bảng ảnh gốc, giữ bản chữ và dừng video.


### Màn dựng chung, chiếm toàn bộ vùng làm việc

Trang `/native/` hiện luôn dùng một workspace web duy nhất: tư liệu bên trái, video ở giữa, thuộc tính ở bên phải và timeline ở dưới. Chọn video hiển thị thông tin/âm lượng; chọn chữ chỉ đổi bảng thuộc tính sang danh sách câu. Video, vị trí tua, timeline và node media không được thay thế hoặc tự dừng khi đổi bảng. Phụ đề không có route hoặc tab workspace riêng. Kiểu chữ là một nhóm thu gọn trong thư viện tư liệu.

Đã bỏ tiêu đề hướng dẫn lớn, bộ chọn Đang xem và chuyển mode ảnh/video ở màn dựng chính. Workspace lấp đầy iframe; thanh bên SceneForge thu gọn còn 76px trong chế độ dựng và trở về bình thường ở tab khác. Có fullscreen, thu gọn tư liệu, và bảng chỉnh nổi trên màn hình nhỏ. Âm lượng/tắt tiếng là điều chỉnh xem trước, chưa phải tham số xuất video. Bản web vẫn chỉ có một video nguồn đang mở cùng track phụ đề; chưa có engine cắt ghép nhiều clip/MP4 hoặc nhận giọng nói.

Ảnh cửa sổ Concat gốc và video đối chiếu được giữ tại `/native/reference.html`, có link trong mục thông tin, không phải màn dựng mặc định. Source native không đổi. Các check ảnh cũ chuyển sang trang đối chiếu; `check_subtitles.py` và `scripts/demo-web/check_integrated.py` kiểm tra màn chung, chỉnh chữ, bảo toàn media khi chọn công cụ, chiều rộng viewport và timeline luôn hiện.


### Thanh công cụ được giữ trong workspace

Đã khôi phục các nhóm Tư liệu, Chữ, Nhãn dán, Chuyển cảnh, Hiệu ứng, Bộ lọc, Mẫu và Âm thanh. Các nút chỉ thay nội dung bảng trái, giữ nguyên video và timeline đang phát. Các nhóm không còn bị thay bằng một trang phụ đề riêng.

Phạm vi bản web: bộ lọc/độ sáng/tương phản/mờ, một nhãn dán emoji và mẫu chuyển cảnh chỉ để xem trước; chưa được ghi vào MP4. Chuyển cảnh là demo animation, chưa áp vào điểm nối clip. Mẫu là preset chữ của track phụ đề. Âm thanh điều chỉnh volume/mute/tốc độ phát của video nguồn.

Thanh timeline có phát/dừng, hoàn tác/làm lại, tách/nhân đôi/xóa câu phụ đề, vừa timeline và thu phóng. Tách/xóa/nhân đôi chỉ hoạt động khi chọn câu chữ, không cắt video nguồn. Nhân đôi kiểm tra khoảng trống sau câu để tránh chồng lấn. Undo hiện quản lý dữ liệu chữ/phụ đề, không quản lý CSS hiệu ứng xem trước.

Kiểm tra: `python scripts/native-preview/check_workspace_tools.py` xác minh cả 8 nhóm giữ cùng node video/timeline và không ngắt phát, kiểm tra audio/filter/effect/sticker/template, demo transition và các lệnh timeline phụ đề.


### Timeline đa lớp và bảng hiệu ứng đã nối lại

Workspace mặc định hiện build từ renderer/timeline đa lớp có sẵn ở `scripts/demo-lite/`, với adapter `scripts/native-preview/editor-integration.js`. Nó hỗ trợ kéo tư liệu/tệp vào track, tự tạo track khi nhập, nhấc clip vào khoảng trống, bốn chế độ đặt clip, cắt/tách và nhóm chọn. Không còn dùng trang một video + phụ đề làm màn dựng mặc định. Bản một video được giữ ở `native/single-video.html` để đối chiếu; đó không phải tab người dùng cần chuyển sang.

Adapter hợp nhất chữ/phụ đề trong cùng kho công cụ, giữ 4 preset, nhận SRT/VTT, xuất SRT/ASS, chuyển bản chữ lưu ở `sceneforge.subtitle-draft.v1` khi chưa có bản nháp timeline cần bảo toàn. Giới hạn hiện tại: 250 câu/tệp, 500 ký tự/câu, 300 mục/dự án, tối thiểu 0,2 giây cho một mục. Không tự nhận giọng nói.

Bảng hiệu ứng có 9 thẻ trước/sau, nhóm/tìm kiếm, ghi clip đang chọn, tham số màu và zoom cuối clip. Màu gắn vào properties, chuyển động tạo keyframe có thể sửa và undo. Chuyển cảnh cơ bản gắn vào clip và thời lượng; xuất dùng bộ ghi trình duyệt, đã kiểm chứng WebM có chữ và âm thanh, chưa bảo đảm MP4. Nút giả lập xuất được ẩn khi có xuất thật.

Bảng kiểm đầy đủ ở `docs/editor-feature-audit.md`. Source Concat native và đường nối desktop không bị thay đổi; đây là renderer web riêng của SceneForge.
