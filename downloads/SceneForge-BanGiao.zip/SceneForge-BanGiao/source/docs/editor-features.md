# Tính năng Dựng video — bản web xem thử

Mở `preview.html` → **Dựng video**. Giao diện web và các tab khác giữ nguyên.
Nút **Tính năng** ngay trong trình dựng cũng có bảng tóm tắt đã có/còn thiếu.
Không có lời gọi API tính phí trong các chức năng dưới đây.

## Bố cục tham khảo Concat

Giao diện dựng hiện theo ảnh Concat người dùng cung cấp: thanh menu gọn và tên
dự án ở giữa; nền xám đen; màu nhấn xanh cyan; kho tư liệu dạng lưới ba cột trên
desktop; inspector có thanh tiêu đề từng nhóm; timeline dùng xanh dương cho
video, hồng cho chữ, xanh lá cho audio và playhead đỏ. Giữ video 9:16 và các tab
SceneForge bên ngoài. Có thanh kéo fade và tốc độ ngay trong tab Âm thanh khi
chọn nguồn audio. Không có điều khiển giả cho pitch hoặc tính năng chưa hỗ trợ.
Các nhóm thuộc tính trong bản mô phỏng có thể bấm tiêu đề để thu gọn/mở lại;
trạng thái nhóm được giữ trong phiên theo loại clip, không thay thông số dự án.
Giao diện tương ứng cũng đã được tích hợp riêng vào bản chạy thật dùng OpenVideo:
timeline chạy ngang dưới cả ba bảng và cụm phát/tua nằm dưới khung xem. Xem
`docs/openvideo-integration.md` để phân biệt chức năng của hai bản.

**Checklist bản mô phỏng nhẹ:** 10/12 mục giao diện và 14/20 nhóm thao tác.
Đã bỏ nhãn phần trăm vì đây không phải phép đối chiếu toàn bộ repo Concat.
Nút **Phạm vi** liệt kê các mục đã có/còn thiếu của riêng bản HTML nhẹ.
`editor-native-demo.html` là bản mô phỏng engine OpenVideo riêng, đã có nhiều bản
dựng giống bản chạy thật; danh sách phía dưới chủ yếu mô tả `concat-demo.html`.

Các mục giao diện còn thiếu trong checklist: dock kéo thả tùy vị trí và đồ thị
keyframe tương tác. Các nhóm quy trình còn thiếu trong bản nhẹ: nhiều sequence, speed ramp,
Bezier, nhận dạng giọng nói, tách nền AI, mask/tracking nâng cao. Các nhóm đã có
vẫn có giới hạn chi tiết được nêu bên dưới.

Bản xem thử dùng ba bảng tư liệu / khung xem dọc / thuộc tính, với timeline phía
dưới, nền xám đậm và điểm nhấn xanh cyan. Các tab ngoài trình dựng vẫn giữ nguyên.
Thanh trên có **Mặc định / Khung xem / Timeline** để đổi không gian làm việc;
đổi bố cục không sửa dự án. Đây là giao diện tự viết của SceneForge, không phải
engine Concat được nhúng vào web. Có thể mở riêng `editor-demo.html` trong trình
duyệt, không cần cài Node hoặc nhập API key.

`concat-demo.html` mở sẵn bản dựng có ba cảnh, tiêu đề, nhạc và một chuyển cảnh.
Trong bản thông thường có nút **Mở bản dựng mẫu** để thêm chữ/nhạc vào dự án đang
xem; phần thêm là một bước hoàn tác. Không gọi nhà cung cấp AI.

Đã bổ sung vào bố cục làm việc:

- Thanh loại công cụ nằm trong kho tư liệu; cột lọc Video / Âm thanh / Hình ảnh,
  tìm kiếm và sắp xếp. Bấm đúp tư liệu mở cửa sổ xem nguồn với nút thêm vào dựng.
- Menu **Tệp / Chỉnh sửa / Hiển thị** gọi lệnh thật, không phải nút trang trí.
- Chuột phải clip: cắt, nhân đôi, đưa lên lớp riêng, xóa, tách âm thanh; chuột
  phải track: khóa và chọn chiều cao. Chỉnh chiều cao hỗ trợ hoàn tác và lưu JSON.
- Filmstrip lấy tối đa tám khung hình giải mã cho mỗi tệp video; chọn hình gần
  nhất theo điểm vào, tốc độ và thời gian của clip. Đây là dải hình lấy mẫu, không
  phải khung hình chính xác cho mọi pixel timeline. Có cache, xử lý lần lượt,
  giới hạn 24 nguồn trong phiên. Tệp không giải mã được vẫn chỉnh bằng nhãn clip.
- Waveform từ dữ liệu âm thanh giải mã của nguồn audio, tối đa 32 MiB cho tác vụ
  phân tích sóng; chưa tính waveform cho âm thanh nằm trong nguồn video. Bộ đệm
  sóng 600 điểm, vẽ lại theo đoạn cắt/tốc độ. Không dùng sóng ngẫu nhiên.
- Chiều cao track tự động theo loại hoặc Gọn / Vừa / Lớn. Nhấc clip tạo dòng mới
  vẫn hoạt động khi đổi chiều cao; kéo sát mép timeline có cuộn theo con trỏ.
- Khung xem có Vừa khung / 125% / 150% / 200%, chỉ đổi màn xem, không đổi đầu ra.
- Kho có thêm **Hiệu ứng** với bốn preset chuyển động: zoom chậm, trượt nhẹ,
  hiện dần, nhịp zoom. Chúng tạo keyframe tuyến tính thật, thay bộ keyframe hiện
  tại, có hoàn tác; không phải bộ shader/effect của Concat.
- **Mẫu** gồm mở đầu, lời kể và kết thúc, thêm một lớp chữ sửa được tại vạch
  phát. Mỗi lần áp dụng hoàn tác trong một bước; không thay video hiện có.
- Nút đổi phía kho tư liệu/thuộc tính cùng menu khôi phục bố cục. Kích thước,
  phía bảng và chế độ xem được lưu cục bộ nếu trình duyệt cho phép. Kéo đổi chiều
  rộng hoạt động cả khi đã đổi phía bảng. Đây là hai cách sắp xếp, chưa phải dock
  kéo thả tự do.

Chưa mô phỏng đủ mọi phần Concat: nhiều sequence độc lập trong một dự án, dock
kéo thả tự do, đồ thị easing Bezier, bộ hiệu ứng shader của Concat, phụ đề Whisper,
TTS và xóa nền AI. Những mục này không được đưa thành nút giả trong bản hiện tại.

## Nhập video và chế độ timeline

Video tải lên mặc định tự tạo một clip trên **lớp riêng**, không cần bấm thêm lớp.
Có thể đổi ngay tại kho tư liệu sang **Nối cuối track** hoặc **Chỉ lưu trong kho**.
Video giữ đủ thời lượng nguồn, có thumbnail tự lấy từ tệp; nhập nhiều tệp tạo từng
clip tương ứng. Nối lại tệp bị thiếu trong dự án không tạo thêm clip trùng.
Thả tệp trực tiếp vào timeline chỉ thêm một lần. Vùng nét đứt dưới các track cho
phép thả để tạo lớp mới; thả âm thanh vào track video cũng tự tạo lớp đúng loại.

| Chế độ kéo | Hành vi |
|---|---|
| **Chèn** (mặc định) | Chèn ở mép clip đang thả vào, dời các clip sau nhường chỗ; chuyển clip khỏi track nguồn sẽ khép khoảng clip đó. Không hủy tư liệu. |
| **Đổi chỗ** | Hoán đổi hai clip trên cùng track, sắp lại các clip trong đoạn giữa để không chồng. Áp dụng khi chọn một clip. |
| **Ghi đè** | Chỉ khi chủ động chọn: cắt phần clip bị phủ, giữ các mảnh bên trái/phải với điểm nguồn và keyframe tương ứng. Có thể hoàn tác. |
| **Lớp riêng** | Chuyển mục đang kéo sang lớp mới tại thời điểm thả. Các clip không còn chung một hàng. Đây là di chuyển, không nhân đôi clip nguồn. |

**Nhấc clip lên để tạo dòng mới:** kéo thân clip vào khoảng trống trên dòng đầu
hoặc giữa hai dòng. Vùng xanh báo vị trí; thả chuột tạo đúng một track tại đó,
không cần đổi chế độ hoặc bấm thêm lớp. Áp dụng cả nhóm chọn; giữ thời điểm
ngang nếu chỉ kéo theo chiều dọc. Hủy kéo không để lại track mới; hoàn tác trả
clip và các dòng về trước thao tác. Kéo mép vẫn là cắt, không tự tạo dòng.

Khi kéo có vạch và nhãn xem trước vị trí/chế độ. Thả ngoài vị trí hợp lệ hoặc vào
track khóa sẽ hủy thao tác, giữ nội dung trước đó. Các chế độ cũng áp dụng cho
thao tác nhập vị trí/độ dài bằng số; kéo mép phải trong Chèn sẽ đẩy hoặc kéo theo
clip phía sau. Với nhóm chọn, Chèn giữ khoảng cách nội bộ và đẩy các mục vướng;
Đổi chỗ chỉ dành cho một clip. Các track cũ đã chồng từ dự án trước cần dùng Lớp
riêng để tách trước khi Chèn/Đổi chỗ.

Lớp video ở trên có ưu tiên hiển thị cao hơn lớp video ở dưới; chữ vẫn nằm trên
các lớp hình. Lựa chọn chế độ/nhập tệp được lưu cùng JSON và bản nháp. Chưa có
ripple/slip/slide/roll edit chuyên dụng đầy đủ hoặc liên kết nhiều track tự động.

## Giao diện trực quan mới

- Thanh công cụ riêng có 7 nhóm biểu tượng + nhãn: Tư liệu, Âm thanh, Văn bản,
  Nhãn dán, Chuyển cảnh, Bộ lọc, Phụ đề. Giao diện web bên ngoài giữ nguyên.
- Mẫu chữ, bộ lọc màu, nhãn dán và chuyển cảnh dùng các thẻ có hình xem trước;
  bấm để thêm/áp dụng vào mô hình timeline thật. Rê chuyển cảnh có minh họa chuyển động.
- Ô **Tìm công cụ** hỗ trợ có/không dấu, Ctrl/Cmd+K, phím lên/xuống và Enter.
  Ô **Tìm tư liệu** lọc theo tên tệp trong kho.
- Bảng thuộc tính chia tab theo mục đang chọn; chỉ hiện nhóm chỉnh đang dùng.
  Các giá trị hay dùng có thanh kéo kèm ô nhập số chính xác. Chọn nhiều mở bảng sửa hàng loạt.
- Thanh timeline dùng biểu tượng có tên truy cập và chú thích khi rê chuột.
  Chế độ hít mốc/lấp khoảng trống được thể hiện bằng trạng thái bật/tắt.
- Không thêm thư viện hay yêu cầu mạng. UI tham khảo bố cục dựng video desktop,
  không sử dụng thương hiệu, tài sản hoặc mã nguồn CapCut.

## Điều chỉnh bổ sung sau khi rà soát

- **Chọn nhiều:** Shift + bấm để thêm mục; Ctrl/Cmd+A chọn tất cả; Esc bỏ chọn.
- **Sửa hàng loạt:** di chuyển bằng kéo hoặc nhập thời điểm nhóm, đặt âm lượng, nhân đôi, xóa và tách những mục giao vạch phát. Khóa track chặn sửa nhóm để tránh thay đổi một phần ngoài ý muốn.
- **Giữ cấu trúc:** kéo nhóm giữ khoảng cách và track; nhân đôi chèn một khoảng bằng độ dài nhóm. Nếu một mục khác cắt ngang điểm chèn, cần tách mục đó trước. Đây là nhóm chọn tạm thời, chưa phải group liên kết/compound clip.
- **Marker:** thêm tại vạch phát bằng nút Mốc/phím M; đặt tên, đổi màu, sửa thời điểm hoặc xóa; lưu cùng JSON/bản nháp; hít mốc cũng xét các marker.
- **Điểm cắt:** phím ↑ về điểm cắt trước, ↓ tới điểm tiếp theo; Ctrl/Cmd+D nhân đôi.
- **Sửa lỗi đặt lại:** bộ mở rộng chỉ khởi tạo một lần; đặt lại mẫu không gắn thêm các bộ xử lý sự kiện. Builder kiểm tra điều kiện này để tránh tái phát.

## Những gì đã thêm trong đợt trước

| Nhóm | Chức năng đã hoạt động | Giới hạn cụ thể |
|---|---|---|
| Chỉnh màu | Sáng, tương phản, bão hòa, làm mờ; Gốc/Ấm/Lạnh/Đen trắng/Điện ảnh/Cổ điển; đặt lại màu | Bộ lọc cơ bản của trình duyệt, chưa có curves hay LUT |
| Biến đổi | Lật ngang/dọc, cùng vị trí, xoay, zoom và độ trong suốt đã có | Chưa có tracking hoặc biến đổi phối cảnh |
| Keyframe | Thêm mốc tại vạch phát, tự thêm mốc khi chỉnh thuộc tính ở thời điểm khác; nội suy vị trí/zoom/xoay/độ trong/âm lượng | Nội suy tuyến tính; chưa có đường cong/easing/graph editor |
| Cắt keyframe | Tách clip và cắt mép giữ được các giá trị chuyển động tại điểm cắt; lưu/mở JSON giữ mốc | Chưa kéo mốc trực tiếp để đổi thời gian; bấm mốc để tua, xóa toàn bộ bằng nút |
| Văn bản | Năm lựa chọn phông hệ thống, viền/màu viền, giãn chữ | Phông thực tế tùy thiết bị, chưa nhập font riêng |
| Mẫu chữ | Tiêu đề, phụ đề, nhãn | Mẫu được tạo cục bộ, không phải thư viện mẫu CapCut |
| Hiệu ứng chữ | Hiện dần, trượt lên, gõ chữ; chỉnh thời lượng | Hiệu ứng vào; chưa có hiệu ứng ra/vòng lặp và hoạt họa từng từ |
| Nhãn dán | Thêm ngôi sao như một lớp chữ, đổi nội dung/ký tự/màu/cỡ/vị trí | Chưa có thư viện sticker động hoặc emoji nhất quán giữa thiết bị |
| Phụ đề | Nhập SRT thành các đoạn chữ trên timeline; sửa chữ/thời gian; xuất chữ thành SRT | SRT xuất là tất cả mục chữ, không lưu kiểu chữ; không tự nhận dạng giọng nói |
| Track | Đổi tên bằng bấm đúp; đổi thứ tự lên/xuống; Solo theo loại track | Các lớp chữ luôn nằm trên các lớp hình; chưa có điều phối lớp tự do kiểu compositing đầy đủ |
| Khoảng trống | Xếp liền các mục trên track đang chọn | Không di chuyển các track khác theo; có thể đưa các mục đang chồng nhau thành chuỗi |
| Thuộc tính | Sao chép/dán thuộc tính chỉnh sửa cơ bản giữa các mục cùng loại | Không sao chép tư liệu, thời gian hoặc keyframe |
| Cửa sổ xem | Toàn màn hình và vùng an toàn 9:16 | Toàn màn hình phụ thuộc trình duyệt/khung nhúng |
| Ảnh khung hình | Tải PNG 1080×1920, gồm chữ, chỉnh màu, lớp hình và chuyển cảnh hiện tại | Không xuất thành video từ nút này |
| Lưu nháp | Tự lưu JSON vào localStorage; nút khôi phục khi mở lại | Trình duyệt phải cho dùng lưu trữ; tệp media từ máy cần chọn lại để nối |
| Xuất video thật | Ghép các lớp lên canvas và ghi bằng MediaRecorder; gồm màu, chữ, keyframe, chuyển cảnh và âm thanh | Theo thời gian thực, tối đa 2 phút/lần, 24 fps; cần giữ tab ở trước; phụ thuộc hiệu năng máy |
| Codec xuất | Chỉ liệt kê MP4/H.264/AAC hoặc WebM/VP9/VP8/Opus khi trình duyệt báo hỗ trợ | Môi trường kiểm tra chỉ hỗ trợ WebM; MP4 chưa được kiểm tra tại đây |
| WebM | Thêm metadata thời lượng vào tệp ghi; tải xuống và nhập lại làm tư liệu | Chưa tạo chỉ mục Cues chuyên dụng; chưa có bộ remux/chuyển mã nền trong bản xem thử |
| Hủy xuất | Dừng ghi, không tải tệp dở dang; khôi phục vị trí xem | Rời tab/ẩn cửa sổ trong lúc ghi có thể làm hủy hoặc ngắt xuất |
| Bảng báo tính năng | Nút Tính năng nêu rõ đã có, giới hạn, chưa có | Không tuyên bố tương đương toàn bộ CapCut |

## Các tính năng đã có trước và vẫn giữ

- Nhiều track video/ảnh, chữ, âm thanh; nhập tệp từ máy, kéo từ kho hoặc thả tệp vào track.
- Mỗi mục có thời điểm bắt đầu, độ dài, điểm vào tư liệu riêng; chỉnh số hoặc kéo trực tiếp.
- Di chuyển giữa các track tương thích; cắt mép, tách, nhân đôi có chèn, xóa và lấp chỗ trống khi xóa.
- Khóa/ẩn/tắt âm track; hít mốc, thu phóng, vừa khung timeline, hoàn tác/làm lại.
- Tốc độ phát cố định 0,25×–3×; fit/cover khung dọc, vị trí/zoom/xoay/độ trong suốt.
- Âm lượng, vào/ra dần; tách âm thanh video sang track riêng.
- Chuyển cảnh mờ qua đen, trượt, quét; chỉnh thời lượng hoặc áp dụng các điểm cắt cùng track.
- Chữ có nội dung, vị trí, màu, cỡ, nền, in đậm, căn dòng; kéo chữ trên khung xem.
- Kho tư liệu lưới/danh sách, thu gọn; thay đổi kích thước kho, bảng chỉnh và timeline.
- Lưu/mở dự án JSON; nối lại tệp gốc bằng cách nhập tệp cùng tên.
- Chuyển sang tab khác giữ dự án đang dựng và tạm dừng phát.

## Còn thiếu so với CapCut

| Nhóm | Chưa triển khai trong bản web xem thử |
|---|---|
| Thao tác hàng loạt | Gom nhóm/ungroup liên kết lâu dài, compound clip, liên kết âm-hình, copy/paste cả clip qua clipboard |
| Timeline nâng cao | Ripple/slip/slide/roll edit đầy đủ, nested sequence, multicam, chapter xuất vào tệp, đồng bộ đa track theo âm thanh |
| Chuyển động | Graph editor, easing, speed ramp/optical flow, đảo ngược video, chống rung |
| Hình ảnh | Mask, chroma key, blend mode, tracking, motion blur, curves/HSL/LUT, scopes, tách nền |
| Hiệu ứng | Thư viện hiệu ứng/transition/sticker động đầy đủ, cross dissolve có chồng thời gian đúng nghĩa, preset nhập từ CapCut |
| Âm thanh | Waveform phân tích từ tệp, EQ/compressor/reverb, khử nhiễu, tách giọng/nhạc, tự giảm nhạc theo lời nói, phát hiện nhịp, effects đổi giọng |
| Phụ đề/AI | Tự phiên âm, phụ đề từng từ/karaoke, dịch phụ đề, text-to-speech, AI chỉnh cảnh, AI tự dựng, AI xóa vật thể |
| Dự án | Đóng gói media kèm dự án, proxy/cache cho tệp lớn, lịch sử phiên bản, cộng tác, đồng bộ đám mây, đa sequence |
| Xuất | Render nền/offline nhanh hơn thời gian thực, bảo đảm MP4 trên mọi máy, nhiều mức FPS/bitrate/codec, batch export, xuất không giới hạn 2 phút |
| Tư liệu | Kho stock/nhạc/mẫu bản quyền và tích hợp nguồn bên ngoài |
| Giao diện | Kéo dock tách cửa sổ tùy ý, workspace đa màn hình, toàn bộ phím tắt và hành vi giống CapCut |

Ứng dụng đầy đủ chạy qua launcher có trình dựng OpenVideo riêng. Bảng này mô tả
chính xác **bản web xem thử độc lập**, không suy diễn những tính năng của thư viện
khác thành tính năng đã tích hợp.

## Kiểm tra đã thực hiện

- Các kiểm tra trình duyệt cũ: timeline, cắt/tách/track, chữ, âm, JSON, nối media.
- Kiểm tra bổ sung: bộ lọc/lật, nội suy và chia keyframe, kiểu chữ/hiệu ứng, nhập/xuất SRT,
  PNG ghép lớp, Solo và khôi phục bản nháp có keyframe.
- Xuất thật video WebM 720×1280 dài 1,5 giây; giải mã bằng FFmpeg và kiểm tra codec VP9/Opus,
  thời lượng hữu hạn, âm thanh có tín hiệu và chữ vàng đã nằm trong hình video.
- Hủy xuất và nhập lại WebM đã tải xuống làm tư liệu.
- Không dùng API trả phí; chưa kiểm tra xuất MP4 trên thiết bị người dùng, video dài 2 phút,
  hiệu năng di động hoặc dự án nặng hàng trăm lớp.

Tái tạo bản xem thử: `python scripts/demo-lite/build.py`.
Các kiểm tra tùy chọn yêu cầu Playwright, Chromium; kiểm tra tệp xuất còn cần FFmpeg/ffprobe và Pillow:

```sh
python scripts/demo-lite/check_demo.py
python scripts/demo-lite/check_media.py
python scripts/demo-lite/check_enhancements.py
python scripts/demo-lite/check_export.py
python scripts/demo-lite/check_batch.py
python scripts/demo-lite/check_interface.py
python scripts/demo-lite/check_timeline_modes.py
python scripts/demo-lite/check_auto_import.py
python scripts/demo-lite/check_lift_track.py
```
