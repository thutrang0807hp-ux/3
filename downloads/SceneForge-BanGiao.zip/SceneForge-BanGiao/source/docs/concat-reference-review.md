# Đối chiếu Concat 0.2.7 với SceneForge

Nguồn: https://github.com/jub0t/concat — tag `v0.2.7`, commit
`14b5998d793d90858ac982926374044bba4bf39f`.
Đã tải mã nguồn và đọc các phần dưới đây; chưa build hoặc chạy ứng dụng native.
Không chạy hoặc phân rã bộ cài Windows. Mã nguồn tham khảo nằm ngoài sản phẩm,
tại `/tmp/concat-source` (thư mục tạm, không được coi là bản lưu lâu dài).

## Những gì đã xác minh trong nguồn

| Phần | Bằng chứng trong repo | Ý nghĩa với SceneForge |
|---|---|---|
| Bố cục tư liệu / preview / inspector / timeline | `assets/editor.png`, `src/crates/concat/src/dock.rs` | Tham khảo tổ chức không gian; giữ khung web SceneForge và đầu ra 9:16. |
| Cửa sổ có thể chia và thay đổi kích thước | `dock.rs`: cây `Dock::Split`, `split_leaf` | Có thể phát triển bố cục tập trung preview hoặc timeline; không cần luôn mở mọi bảng. |
| Thumbnail liên tiếp và waveform trên clip | `src/crates/concat/ui/timeline/lanes.slint` | Hữu ích hơn thêm nút: nhận diện đoạn hình và điểm âm thanh ngay trên timeline. |
| Kéo clip có xem trước, snap, xử lý va chạm | `src/crates/concat/src/studio.rs`: `clip_dragged`; `src/crates/concat-project/src/placement.rs`: `resolve_moves` | Vị trí xem trước phải tuân cùng quy tắc với kết quả thả, tránh clip bất ngờ nhảy hoặc đè nhau. |
| Trim magnetic, split, ripple delete, di chuyển nhóm thành một bước undo | `src/crates/concat-project/src/commands/mod.rs`, `commands/clips.rs` | Cần phân biệt chế độ kéo, chế độ trim và liên kết track; không gọi mọi hành vi là magnetic. |
| API chỉnh dự án và xuất video thành tác vụ | `src/crates/concat-api/src/message.rs`, `src/README.md` | Có đường điều khiển engine qua JSON-RPC; cần adapter và kiểm thử trước khi dùng thật. |

**Giới hạn đáng chú ý:** đường `clip_dragged` được đọc trong bản này tính dòng
đích rồi clamp vào `0..count-1`. Không có tạo track trong đường di chuyển đó.
Không nên hứa rằng lấy Concat sẽ tự có thao tác nhấc clip tạo dòng mới. Giữ thao
tác đã làm riêng trong SceneForge. Đây là kết luận về đường code đã kiểm tra,
không phải khẳng định đã thử mọi cách kéo trong ứng dụng Concat.

## Có nhúng nguyên ứng dụng vào tab web được không?

Không phải frontend React để chép vào iframe. Concat dùng Rust, Slint, wgpu và
FFmpeg. API của nó có CLI/stdin, TCP/Unix socket và gRPC tùy cấu hình; trình duyệt
không tự nói trực tiếp với TCP JSON-RPC. Muốn dùng engine cần bridge phía server,
đổi định dạng dự án và đường dẫn tư liệu, ánh xạ tiến trình xuất cùng hủy/lỗi.
Không thay engine hiện có chỉ vì ảnh giao diện giống mong muốn.

Nguồn dùng **AGPL-3.0-or-later**. `LICENSE-EXCEPTIONS.md` cho phép module độc lập
giao tiếp qua API/IPC/định dạng được tài liệu hóa giữ giấy phép riêng nếu không
chứa hoặc phái sinh từ mã Concat. Ngoại lệ không bao gồm việc chép mã nội bộ.
Không có mã Concat được đưa vào SceneForge trong đợt đối chiếu này.

## Thứ tự cải thiện có ích

1. Filmstrip theo thời gian nguồn và waveform, có cache; tránh giải mã toàn bộ
   tệp liên tục khi kéo hoặc zoom.
2. Tự cuộn timeline khi kéo sát mép, đồng thời giữ mốc thời gian dưới con trỏ.
3. Chiều cao từng track có lựa chọn gọn / vừa / lớn; lưu bố cục làm việc.
4. Bảng chỉnh chỉ hiện nhóm phù hợp với loại mục đang chọn; cho thu gọn để
   preview dọc 9:16 đủ lớn.
5. Chỉ thử engine Concat qua API sau khi kiểm chứng build, import/export và
   chuyển dự án tối thiểu. Phụ đề/TTS/xóa nền được README giới thiệu nhưng chưa
   được kiểm thử ở đây; không tính là tính năng đã thêm vào SceneForge.

Đây là hồ sơ nghiên cứu và kế hoạch áp dụng, không phải thông báo đã tích hợp
Concat hoặc đã bổ sung các mục ưu tiên trên vào giao diện.
