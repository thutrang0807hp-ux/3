# Existing editor evaluation

Inspected GitHub checkouts on 2026-10-16; this is source inspection, not runtime validation.

## OpenVideo Editor (designcombo/react-video-editor)

Repository: https://github.com/designcombo/react-video-editor
Inspected HEAD: 9a8c5296da4b258f66dfb7ad73de96be62478bca

README describes an existing multi-track video/audio/image timeline, canvas transforms,
shader transitions/effects and local MP4 export through WebCodecs/PixiJS. Source also
contains text and caption panels, caption styling controls, transition duration controls
and export UI. This is substantially closer to a complete editor than the custom
SceneForge timeline. It uses Next/React and @openvideo packages, so replacing only a
few HTML controls will not integrate it correctly.

License is source-available, not MIT: free personal/nonprofit use and organizations
up to three employees, with restrictions on selling/licensing derivative editors.
A larger company requires a company license. Individual private customization fits
the stated license use case. R2/S3, Deepgram transcription and Pexels are integrations;
cloud uploads, captions via transcription and stock content must not be presented as
unconditionally free/offline. Browser export support and performance require validation
on target devices. No installation or runtime export test has been performed here.

## OpenCut / OpenCut Classic

https://github.com/OpenCut-app/OpenCut
HEAD: e668010778568641babef2cc40be4703ae6916d6
README states a rewrite is underway and points to Classic for the previous editor.

https://github.com/opencut-app/opencut-classic
Classic README explicitly says archived and no longer maintained. Its MIT license is
permissive. Inspected source includes audio separation, text/stickers, speed/retiming,
keyframes, effect commands, caption/transcription and export/render components. These
files establish existing scope, not that every feature is production-ready or parity
with CapCut. Its Next/Bun stack and runtime requirements need a separate integration.

## Recommendation for this user's private, low-cost workflow

Evaluate running OpenVideo as the complete editing module rather than adding more
isolated controls to the custom timeline. Keep SceneForge upload/analysis/prompts/API
queue and bridge successful clip files directly into the existing editor's asset store.
Use the engine's native project format, preview and export together. Preserve the current
editor until the replacement has been tested with generated clips, including 9:16 MP4,
independent audio/text layers, transitions, saved projects and reload/import/export.

Core acceptance scope should be owned by implementation: multitrack, trim/split/reorder,
snapping, undo/redo, text and manual captions, independent audio/volume/fades, canvas
position/scale/rotation, speed, transitions/effects, persistent projects and MP4 export.
AI captions and provider-specific features are additional integrations with explicit costs.
Do not claim all CapCut features, free AI services, or an integrated OpenVideo editor
before actually installing, adapting and validating it.
