> **Trình dựng hiện tại đã chuyển sang Concat gốc:** mã nguồn 0.2.7 tại `concat-native/`; đã build và chạy engine/cửa sổ trên Linux. Tab Dựng video chuyển clip hàng đợi vào dự án Concat 9:16. Xem [cách chạy và các giới hạn hiện tại](docs/concat-native-integration.md). Các gói HTML/EXE mô phỏng bên dưới là bản cũ, không phải bản native mới.
> **Xem thử trực tuyến:** https://thutrang0807hp-ux.github.io/3/ — bản mô phỏng tương tác, xuất bản từ nhánh `gh-pages`; không cần tải ứng dụng.
> **Bản mô phỏng Windows:** tải [SceneForge-MoPhong-Windows.zip](SceneForge-MoPhong-Windows.zip), giải nén và chạy `Mo-SceneForge.exe` (Windows 10/11 64-bit). Tự mở trình duyệt, có cả trình dựng và toàn bộ tab ứng dụng; không cần Python hoặc API key.
> **Nếu bản mô phỏng không mở được:** thử [SceneForge-XemThu.html](SceneForge-XemThu.html), mặc định dùng giao diện tương thích không cần WebGL/WebCodecs. [Gói ZIP](SceneForge-XemThu.zip) có cách chạy bằng Python 3 trên máy bạn; xem hướng dẫn bên trong.
> **Trình dựng hiện tại:** tab Dựng video dùng engine OpenVideo. Chạy `python run.py`
> (cần Node.js 22+ ngoài Python và FFmpeg); xem [hướng dẫn tích hợp](docs/openvideo-integration.md).
> Bản chạy thật đã áp dụng bố cục tham khảo Concat: ba bảng tư liệu / preview /
> thuộc tính phía trên, timeline toàn chiều ngang phía dưới; thanh phát và tua ở
> dưới preview, giữ lựa chọn clip khi đổi thư viện và đầu ra 9:16.
> **Bản mô phỏng mới:** [SceneForge-Demo.html](SceneForge-Demo.html) dùng cùng
> UI và engine: tạo bản trống, nhân bản, đổi tên, đổi tab, tự lưu toàn bộ trong trình
> duyệt, lưu/mở JSON. Có sẵn video, chữ và nhạc mẫu; không cần API key. Bước xuất
> của file mô phỏng này không tạo MP4; bản chạy thật có xuất video.
> Mở `preview.html` để xem giao diện web SceneForge cũ với thanh tab bên cạnh. Chỉ tab **Dựng video** dùng bố cục tối kiểu CapCut; các tab khác giữ giao diện cũ. `editor-demo.html` là phần dựng nhúng riêng, không phải toàn bộ website. Bản xem thử không cần API key; đã có xuất video thật trong trình duyệt (WebM/MP4 tùy codec, tối đa 2 phút, 24 fps). Xem [tính năng đã có và còn thiếu](docs/editor-features.md).
> **Mở mẫu dựng ngay:** [concat-demo.html](concat-demo.html) là file HTML độc lập,
> có sẵn ba cảnh, chữ, nhạc và chuyển cảnh để thao tác. Bố cục tham khảo Concat,
> gồm kho tư liệu có cột lọc, màn xem 9:16, inspector, filmstrip/waveform,
> menu chuột phải và chiều cao track. Không cần cài thêm gói hoặc nhập API key;
> không phải engine Concat. Xem [đối chiếu nguồn](docs/concat-reference-review.md).

# SceneForge

Ứng dụng web chạy cục bộ: **video tham khảo → prompt từng cảnh → hàng đợi tạo video → ghép MP4**.

Giao diện sáng có ba khu vực: Tổng quan, Xóa logo và Hàng đợi. HTML do máy chủ trả về đã nhúng CSS/JS, không cần tải stylesheet riêng hoặc phông chữ từ bên ngoài. Luôn mở bằng máy chủ Python, không mở tệp HTML để dùng các chức năng API.

Bản thiết kế độc lập `preview.html` dùng **thẻ cảnh xếp ngang**: mỗi thẻ có video gốc/kết quả đặt cạnh nhau, đều 9:16, cùng trích đoạn Visual/Motion. Trình sửa chỉ mở khi bấm bút/Chỉnh sửa, trong bảng trượt bên phải (điện thoại là bảng toàn màn hình), với tab Hình ảnh/Chuyển động/Âm thanh. Đóng/đổi cảnh vẫn giữ bản nháp trong bộ nhớ phiên; xuất JSON để lưu lại. Video minh họa nhúng có kích thước 540×960. Có thể tạo từng cảnh hoặc chọn nhiều cảnh vào hàng đợi mẫu. Ô kết quả là placeholder; mọi thao tác AI vẫn là mô phỏng, chưa kết nối với backend. Không nhập key thật vào bản thiết kế. Trên điện thoại, cuộn ngang các thẻ để xem tiếp.

Bản xem trước mở mặc định ở **Tổng quan**, có thống kê mẫu, lối vào công cụ và video gần đây. Thanh điều hướng có năm mục riêng: Tổng quan, Thư viện, Phân tích video, Hàng đợi và Thiết lập; mục Xóa logo đã được bỏ khỏi bản thiết kế theo yêu cầu. Thanh tab nằm dọc bên trái; trên điện thoại thu gọn thành biểu tượng có nhãn, vẫn giữ đủ năm mục. Chuyển trang không xóa bản nháp hay hàng đợi trong phiên.

Thư viện trong bản xem trước có ô chọn/kéo thả nhiều video ở trên và lịch sử mới nhất trước ở dưới. Tệp thực được kiểm tra tỉ lệ 9:16, tối đa 500 MB và 10 phút; có ảnh đại diện, thời điểm thêm, tìm theo tên và mở xem. Lưu tệp/metadata bằng IndexedDB trên thiết bị, không gửi lên máy chủ. Nếu trình duyệt không hỗ trợ hoặc hết dung lượng, ghi rõ chỉ giữ trong phiên. Dữ liệu trình duyệt bị xóa thì mất lịch sử; tệp gốc trên máy không bị đổi. Chỉ video mẫu có kết quả phân tích minh họa; các tệp mới chưa được phân tích AI.

## Xử lý logo trên video đã tải về

Không cần khóa API hoặc GPU. Áp dụng cho tệp video có logo nền tảng như TikTok/Douyin đã lưu trên máy; **chưa tải video từ đường dẫn**, chưa tự nhận diện hoặc bám theo logo.

1. Thêm video, bấm **Xóa logo** trên thẻ video.
2. Kéo trên khung hình để chọn vùng, hoặc thêm gợi ý hai góc TikTok/Douyin. Gợi ý chỉ là tọa độ có sẵn, phải kiểm tra với video thực tế.
3. Chọn tối đa 8 vùng, đặt thời gian bắt đầu/kết thúc cho từng vùng nếu logo đổi vị trí. Có nút phát và thanh tua để kiểm tra video.
4. Chọn **Xóa bằng nội suy nền** (`delogo`) hoặc **Làm mờ vùng logo**. Không phải AI inpainting; nền phức tạp có thể nhòe, và logo sát mép có thể còn một dải nhỏ do bộ lọc cần pixel lân cận.
5. Bấm **Xử lý & tạo bản sao**, tải MP4 trong cửa sổ hoặc xem lại kết quả tại thư viện/hàng đợi. Bản gốc luôn giữ nguyên; bản xử lý giữ âm thanh nếu có, mã hóa H.264/AAC. Thời gian xử lý phụ thuộc độ dài, độ phân giải và CPU.

Mỗi lần chỉ chạy một tác vụ xử lý logo để hạn chế tải máy. Khởi động lại sẽ đánh dấu tác vụ đang xử lý là gián đoạn; có thể tạo bản mới, không cần dùng API. Trình duyệt phải đọc được định dạng nguồn để khoanh vùng; ưu tiên MP4 H.264. Công cụ không bảo đảm loại bỏ sạch logo trên mọi nền.

## Chạy ứng dụng

### Mở trên máy cá nhân

Máy cần Python 3.11+ và FFmpeg/ffprobe trong PATH. Windows: mở `start.bat`. macOS/Linux: chạy `sh start.sh` trong thư mục dự án. Trình khởi động tạo môi trường Python, cài phụ thuộc lần đầu, tạo `.env` trống nếu chưa có, rồi tự mở trình duyệt khi máy chủ sẵn sàng. Giữ cửa sổ lệnh mở trong khi sử dụng. Lần đầu cần Internet để cài gói.

Ứng dụng chạy trên máy nơi thực thi lệnh. Máy chủ chạy trong môi trường Codex không tự trở thành website công khai để điện thoại hoặc máy khác truy cập. Link ảnh chụp giao diện chỉ là ảnh. Phiên onboarding này không cung cấp đường dẫn web xem trước. Không dùng `start.bat` từ trong tệp ZIP: cần giải nén trước.

### Chạy thủ công trong môi trường phát triển

Yêu cầu Python 3.11+, FFmpeg và ffprobe trên PATH. Ví dụ trên Ubuntu: cài gói `ffmpeg` bằng trình quản lý gói hệ thống nếu chưa có.

```bash
cd /workspace/3
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
cp .env.example .env
# Điền key trong .env bằng trình soạn thảo; không đưa key vào Git.
.venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port 8000
```

Trên máy cá nhân, dùng đường dẫn checkout của bạn thay `/workspace/3`, rồi mở trình duyệt tại cổng 8000 của máy. Chỉ chạy một tiến trình Uvicorn, không dùng `--workers` hoặc `--reload` khi có tác vụ đang chạy. Không triển khai công khai: bản này chưa có đăng nhập, phân quyền hoặc giới hạn tài nguyên cho nhiều người dùng.

Không cần key để tải video, xử lý vùng logo, xem giao diện, sửa/xuất prompt có sẵn hoặc ghép clip đã tạo. Cần key thực để phân tích và tạo clip.

## Quy trình viết prompt

Xem [nguồn nghiên cứu và cách áp dụng](docs/prompt-workflow.md). Backend phân tích dùng hợp đồng chủ thể/bối cảnh/trạng thái đầu/hành động/trạng thái cuối/máy quay/phong cách/bằng chứng. Không tự mặc định mọi nguồn là cảnh điện ảnh hoặc đã được nghe âm thanh.

`POST /api/projects/{id}/prompts/rewrite` nhận `{ "scenes": [0], "acknowledge_cost": true, "preferences": { "mode": "faithful", "target": "veo", "language": "en", "structure": "beats" } }`. Cần OpenAI key trên máy chủ. Tối đa 8 cảnh/lượt; mỗi cảnh trích lại 3 khung ảnh thực để đối chiếu. Trả ứng viên, sự kiện quan sát được, thay đổi đã yêu cầu, điều chưa biết, cách dùng tham khảo và cảnh báo cấu trúc. Không tự ghi đè prompt đã lưu. Prompt tham khảo là dữ liệu; link không được tự tải. API này chưa được nối với trợ lý trong bản xem trước, chưa thử bằng API thật; backend hiện chỉ có kết nối viết lại OpenAI.

`preview.html` là bản mô phỏng độc lập: tab **Quy trình viết** có chế độ bám gốc/biến thể/sản phẩm, cấu trúc nhịp thời gian/đoạn văn/khối, nguồn GitHub và hợp đồng yêu cầu. Các ví dụ được biên soạn cục bộ từ dữ kiện mẫu. Không diễn giải prompt tham khảo bằng AI, không chạy nhiều model, không chấm điểm chất lượng thật. Tùy chọn đổi chủ thể/phong cách/máy bị khóa khi bám gốc. Nút tổng hợp hiện giải thích cần AI rà soát, không giả vờ nối chuỗi là tổng hợp thông minh.

## Các kết nối

- **OpenAI API:** `OPENAI_API_KEY`, `OPENAI_MODEL` là model hỗ trợ ảnh và JSON mode. Mặc định `gpt-4.1-mini`. Phí API riêng với gói ChatGPT.
- **Google Gemini API / Veo:** `GEMINI_API_KEY`, `VEO_MODEL`. Mặc định `veo-3.0-generate-001`; cần quyền dùng model và thanh toán của Google. Bộ kết nối dùng `predictLongRunning`, theo dõi operation rồi tải video. Khóa của đại lý, Vertex AI và API Meta không dùng thay thế trực tiếp được.
- **Muse / Meta:** chưa tích hợp vì chưa có endpoint/tài liệu API xác định. Không mô phỏng kết quả hoặc dùng tự động hóa trình duyệt thay API.
- Khóa chỉ được đọc phía máy chủ. Trang cấu hình chỉ báo có/không có biến, không xác nhận key hoạt động. Không ghi khóa vào SQLite hoặc trả khóa về trình duyệt.
- Đích mạng khi sử dụng thực: `api.openai.com`, `generativelanguage.googleapis.com`; tải video có thể qua `storage.googleapis.com`, `*.googleusercontent.com`. Mạng giới hạn cần cho phép các đích này.

## Cách sử dụng

1. Chọn hoặc kéo thả nhiều video. Mỗi video tối đa 500 MB, 10 phút.
2. Bấm **Phân tích** và xác nhận gửi khung hình tới OpenAI. Thao tác này có tính phí API. Ứng dụng lấy tối đa 24 ảnh có mốc thời gian, không gửi toàn bộ tệp video.
3. Mở phần prompt, kiểm tra mô tả và sửa prompt tiếng Anh. Bấm lưu hoặc xuất JSON.
4. Chọn cảnh rồi bấm **Tạo các cảnh đã chọn**. Xác nhận số clip tối đa và phí trước khi gửi. Mỗi cảnh tạo một clip dọc 9:16, 8 giây qua Veo. Thời lượng này không khớp tự động thời lượng cảnh nguồn. Tạo lại cùng cảnh sẽ tạo tác vụ có tính phí mới.
5. Có thể xử lý nhiều dự án trong hàng đợi. `VIDEO_CONCURRENCY` từ 1–4 (mặc định 1) giới hạn số clip gửi đồng thời cho cả ứng dụng, vẫn chịu quota Google. Hủy chỉ áp dụng tác vụ chưa gửi. Không tự gửi lại yêu cầu thất bại.
6. Khi mỗi cảnh có kết quả thành công, bấm ghép. Bản đầu xuất hình ảnh 720×1280/24fps **không có âm thanh**; có thể tải clip gốc riêng để giữ âm thanh do nhà cung cấp trả về.

## Giới hạn cần biết

- Đây là phân tích khung hình bằng model nhìn ảnh, chưa phải đọc video/âm thanh liên tục. Có thể bỏ lỡ hành động nhanh hoặc chuyển cảnh giữa các mẫu. Có thể tăng `MAX_SAMPLE_FRAMES` tới 64, đồng thời tăng phí phân tích.
- Chưa nhận dạng lời thoại, phân tích nhạc, viết kịch bản mới, gửi ảnh tham chiếu sang Veo hoặc tự chấm chất lượng kết quả. Text-to-video không bảo đảm giữ nhân vật hoặc tái dựng chính xác video gốc.
- Chất lượng prompt và giá cần đánh giá với video thực và model của bạn. Chưa kiểm chứng API có tính phí bằng key thật. Kiểm thử dùng phản hồi API giả lập rõ ràng, kết hợp FFmpeg thật.
- Dữ liệu cục bộ trong `data/` không tự xóa. Khung hình gửi OpenAI, prompt gửi Google theo chính sách từng nhà cung cấp. Chỉ xử lý tư liệu bạn có quyền sử dụng.
- Hàng đợi lưu SQLite. Sau khởi động lại, các operation đã lưu sẽ tiếp tục được theo dõi. Nếu bị ngắt giữa lúc gửi yêu cầu và lưu operation, ứng dụng đánh dấu cần kiểm tra thay vì tự gửi lại. Không bảo đảm đúng một lần tại ranh giới mạng đó.
- Hết thời gian theo dõi hoặc lỗi tải có thể tiếp tục theo dõi operation đã có. Kiểm tra Google trước khi chủ động tạo mới để tránh trả phí trùng. Model bị chặn nội dung hoặc không còn hỗ trợ sẽ hiển thị lỗi.
- Không có giá tiền cố định trong giao diện: giới hạn số clip là giới hạn số yêu cầu, không phải ngân sách USD. Kiểm tra giá model và hạn mức tài khoản trước khi xác nhận.

## Kiểm thử không tốn API

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Kiểm tra tải video thật, dữ liệu prompt, chặn yêu cầu chưa xác nhận phí, chống gửi trùng khi đang chạy, khôi phục hàng đợi, trích ảnh thật, giao thức OpenAI/Veo qua HTTP mock và ghép MP4 bằng FFmpeg thật. Không kiểm chứng chất lượng mô hình hoặc tính tương thích API trực tiếp.

Kiểm thử logo sử dụng video tổng hợp có vùng màu và âm thanh: xác minh vùng màu được nội suy đúng khoảng thời gian, âm thanh còn trong đầu ra, bản nguồn không đổi, bộ lọc blur chạy được và vùng ngoài video bị từ chối. Kiểm tra HTML có CSS/JS nhúng để tránh lặp lại lỗi tải giao diện.

## Nguồn tham khảo

Ý tưởng khảo sát từ [video-to-prompt](https://github.com/imooooc/video-to-prompt) và [video-prompt-reverse](https://github.com/LunarXuan/video-prompt-reverse). Bản này triển khai độc lập, chưa cài skill ngoài và không chạy script của các repo đó.

### Dựng video ngay trong ứng dụng

Trong Hàng đợi, bấm **Đưa vào Dựng video** ở clip đã hoàn tất. Tab **Dựng video**
cũng liệt kê các clip thành công để thêm trực tiếp, kể cả clip từ nhiều dự án.
Thời lượng được đọc từ tệp kết quả thực tế, không giả định mọi clip dài 5 hay 8 giây.

- Đổi thứ tự bằng nút trái/phải; cắt đầu/cuối bằng thời gian tính theo giây.
- Xem toàn bộ phát lần lượt các khoảng đã cắt. Đây là xem thử nối tiếp; có thể có
  một khoảng chờ tải giữa clip. Bản xuất MP4 được ghép bằng FFmpeg.
- Xuất MP4 720×1280, 24 fps; giữ âm thanh clip nếu có, thêm đoạn âm thanh trống
  cho clip không có tiếng hoặc chọn tắt âm thanh toàn bộ. Không có crossfade.
- Tối đa 40 clip, 10 phút/timeline; một bản xuất chạy tại một thời điểm.
- Timeline chạy thật lưu ID clip và khoảng cắt trong trình duyệt. Bản xuất gần đây
  lưu ở backend và có liên kết tải khi quay lại tab. Tệp gốc không bị thay đổi.
- Xuất không gọi API AI. Nếu tiến trình bị dừng, bản xuất được báo gián đoạn và
  có thể xuất lại; không tự khởi chạy lại tác vụ.

`preview.html` có tab dựng thử bằng video mẫu hoặc video đã thêm cục bộ. Việc xuất
MP4 chỉ hoạt động khi chạy ứng dụng Python; nút xuất trong preview được vô hiệu.

Tham khảo GitHub: [ffmpeg.wasm](https://github.com/ffmpegwasm/ffmpeg.wasm) là một
cổng WebAssembly/JavaScript của FFmpeg cho trình duyệt. Đã đọc README của repo;
phiên bản này dùng FFmpeg native đã cài trong backend và UI timeline tự viết,
không nhúng ffmpeg.wasm hay sao chép một trình biên tập bên ngoài.

Timeline có giao diện dựng kiểu desktop: thước thời gian theo giây, playhead kéo
được (hỗ trợ phím trái/phải), thumbnail đại diện clip, kéo mép để cắt, kéo thả đổi
thứ tự, tách tại playhead, xóa clip đang chọn và zoom. Phần nhập thời gian chính
xác nằm trong mục thu gọn. Hai hàng video/âm thanh cùng một thứ tự; âm thanh hiện
đi kèm video, chưa hỗ trợ nhạc nền riêng, chồng nhiều lớp video hoặc hiệu ứng chữ.
Ảnh thumbnail được lặp từ ảnh đại diện clip, không phải mọi khung hình theo thời gian;
hàng âm thanh không hiển thị waveform giả.

Đã đọc README [OpenCut](https://github.com/OpenCut-app/OpenCut) và
[OpenCut Classic](https://github.com/opencut-app/opencut-classic) để tham khảo.
OpenCut đang viết lại; Classic tự ghi là archived, không còn được duy trì. UI và
logic timeline ở đây được viết riêng, không tích hợp hoặc phụ thuộc các repo này.

Chuyển cảnh: chọn Cắt thẳng, Hòa tan, Mờ qua đen, Quét sang trái hoặc Trượt sang
trái. Hiệu ứng hiện áp dụng đồng loạt cho mọi điểm nối. Thời gian chuyển từ 0,1
đến 1,5 giây; mỗi clip cần dài ít nhất hai lần thời gian chuyển cộng 0,05 giây.
Chuyển cảnh chồng phần cuối/đầu clip nên bản xuất ngắn hơn tổng độ dài các clip;
giao diện hiển thị thời lượng xuất ước tính, có sai số làm tròn theo 24 fps.
FFmpeg xfade và acrossfade tạo chuyển cảnh hình/tiếng trong MP4 thực tế. Phát thử
trên timeline vẫn nối tiếp bằng video nguồn; xem hiệu ứng hoàn chỉnh trong video
kết quả xuất ngay trên trang. Không có mô phỏng waveform hoặc hiệu ứng giả.

Thanh công cụ có nhân đôi, tách, xóa và hoàn tác/làm lại tối đa 30 thay đổi trong
phiên dựng đang mở, bao gồm khoảng cắt, thứ tự và thiết lập chuyển cảnh. Timeline
và thiết lập chuyển cảnh lưu cục bộ; lịch sử hoàn tác chưa lưu qua lần mở tab mới.
