"""Local SceneForge → genuine Concat projects; no AI requests or web emulation."""
import re
import subprocess
import time
import uuid
from pathlib import Path
from fastapi import HTTPException
from pydantic import BaseModel, Field
from concat_bridge import ConcatError, ConcatProcess, create_native_project, native_binary, native_runtime_env


class NativeProjectRequest(BaseModel):
    job_ids: list[str] = Field(min_length=1, max_length=40)
    open_editor: bool = True


def register_concat(app, root, data, connect):
    def launch_editor(project=None):
        editor = native_binary(root, 'concat')
        if not editor:
            raise ConcatError('Chưa tìm thấy Concat. Cấu hình CONCAT_EDITOR_BIN để mở.')
        logdir = data / 'concat-logs'
        logdir.mkdir(exist_ok=True)
        name = 'launch-' + uuid.uuid4().hex
        args = [str(editor)] + (['--project', str(project)] if project else [])
        with (logdir / (name + '.log')).open('ab') as log:
            child = subprocess.Popen(args, env=native_runtime_env(root), stdout=log, stderr=log)
        try:
            code = child.wait(timeout=1)
            raise ConcatError(f'Ứng dụng thoát lúc mở (mã {code}). Kiểm tra nhật ký Concat.')
        except subprocess.TimeoutExpired:
            return True

    @app.post('/api/concat/launch')
    def launch():
        try:
            return {'launched': launch_editor()}
        except (OSError, ConcatError) as error:
            raise HTTPException(503, str(error)) from None

    @app.get('/api/concat/status')
    def status():
        engine, editor = native_binary(root, 'concat-cli'), native_binary(root, 'concat')
        result = {'engine_available': bool(engine), 'editor_available': bool(editor), 'native': True}
        if engine:
            try:
                with ConcatProcess(engine, env=native_runtime_env(root), timeout=10) as client:
                    result['version'] = client.call('version')['concat']
            except (OSError, RuntimeError, TimeoutError) as error:
                result['engine_available'] = False
                result['error'] = str(error)
        return result

    @app.post('/api/concat/projects')
    def create(body: NativeProjectRequest):
        if len(set(body.job_ids)) != len(body.job_ids) or any(not re.fullmatch('[a-f0-9]{32}', jid) for jid in body.job_ids):
            raise HTTPException(422, 'Danh sách clip không hợp lệ hoặc có clip trùng.')
        sources = []
        with connect() as db:
            for jid in body.job_ids:
                row = db.execute('SELECT project_id,status FROM jobs WHERE id=?', (jid,)).fetchone()
                if not row or row['status'] != 'done':
                    raise HTTPException(400, 'Chỉ chọn clip đã tạo thành công.')
                source = (data / row['project_id'] / (jid + '.mp4')).resolve()
                if not source.is_relative_to(data.resolve()) or not source.is_file():
                    raise HTTPException(404, 'Không còn tệp video của clip đã chọn.')
                sources.append(source)
        name = 'SceneForge-' + time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
        try:
            result = create_native_project(root, sources, name)
        except (ConcatError, OSError, TimeoutError) as error:
            raise HTTPException(503, str(error)) from None
        result['opened'] = False
        if body.open_editor:
            try:
                result['opened'] = launch_editor(result['path'])
            except (OSError, ConcatError) as error:
                result['open_error'] = 'Đã lưu dự án. ' + str(error)
        return result
