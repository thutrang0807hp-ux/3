// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2026 Jareer and Concat contributors

//! Titles and shapes, rendered and remembered.
//!
//! The flattener leaves text and shape clips out on purpose: the compositor
//! only knows pictures. This is where a title or a shape becomes one. Each
//! clip's style is painted by `concat-text` onto a frame-sized transparent
//! PNG in the app's data directory, and the clip rejoins the flattened list
//! as an image clip pointing at that file, carrying the clip's timing,
//! transform and opacity. The monitor, playback prefetch and the exporter
//! then treat it as any other still.
//!
//! The file is keyed by everything that changes the pixels - the style, the
//! frame size, the fonts the project carries - so a title that has not
//! changed is never painted twice, across sessions included. What a title
//! does *not* key on is where it sits or when it plays: moving one is free.
//! A shape is a title with no words, as far as this file is concerned.

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use concat_core::frame::Frame;
use concat_core::shader::RevealMap;

use concat_export::{ClipKind, ExportClip};
use concat_project::model::{
    ClipKind as ModelClipKind, Project, ShapeKind, ShapeStyle, TextAlign, TextStyle,
};
use concat_text::{Align, Figure, Fonts, TitleStyle, WordRect};

use crate::dirs::AppDirs;

/// One title or shape, ready for the compositor.
#[derive(Clone)]
pub struct TitleClip {
    /// The text or shape clip this was painted from.
    pub clip_id: String,
    /// The image clip that stands in for it.
    pub clip: ExportClip,
    /// The painted block's size in frame pixels, for an outline on a monitor.
    pub block: (u32, u32),
    /// Where that block's centre is, as an offset in frame pixels from the
    /// clip's own centre: zero for a centred title, half a block to the
    /// right for a left-aligned one, whose block starts at the clip's
    /// position. See `concat_text::Align`.
    pub offset: (i32, i32),
    /// The pixels, when the title was painted live rather than to disk:
    /// what the monitor is to show under `clip.path`, a name no file has.
    /// See [`Titles::clips_live`].
    pub frame: Option<Arc<Frame>>,
}

/// What is painted: a title's words or a shape's figure. One painter for
/// both, since they are cached, keyed and handed on the same way.
#[derive(Clone, Copy)]
enum Painting<'a> {
    Title(&'a TextStyle),
    Shape(&'a ShapeStyle),
}

/// What one render left behind.
#[derive(Clone, Debug)]
struct Art {
    block: (u32, u32),
    offset: (i32, i32),
    /// The title's per-word reveal order, baked once here rather than on
    /// every clip build - see `concat_core::RevealMap`.
    reveal: Arc<RevealMap>,
}

/// The title painter and its cache.
pub struct Titles {
    dir: PathBuf,
    /// The system's faces plus the project's files, loaded once each.
    fonts: Mutex<Option<Fonts>>,
    loaded_files: Mutex<HashSet<String>>,
    /// What is known to be on disk, by key.
    memo: Mutex<HashMap<u64, Art>>,
    /// Titles painted live, by key: every title on the timeline, and the
    /// most recently asked for of the rest, so a width dragged back and
    /// forth over the same values paints each once.
    live: Mutex<LivePaintings>,
}

/// The live paintings kept, in bytes of pixels, beyond the ones the
/// timeline is showing; see [`LivePaintings`]. Each is a picture the
/// frame's size - 8 MB at 1080p, 33 MB at 4K - so a count cost four times
/// as much on a 4K timeline as on an HD one. 128 MB keeps sixteen HD
/// paintings or four 4K ones.
const LIVE_BYTES: usize = 128 * 1024 * 1024;

/// The most the paintings of the titles on the timeline may hold between
/// them, in bytes of pixels: 64 HD titles, or 256 at the monitor's half
/// size. Past it the first painted are kept and the rest painted again
/// each time; see [`LivePaintings::keep`].
const LIVE_CEILING: usize = 512 * 1024 * 1024;

/// One live painting, and the pass that last asked for it.
struct LivePainting {
    art: Art,
    frame: Arc<Frame>,
    used: u64,
}

/// The titles painted live, by key, least recently used out first.
///
/// Every live ask paints every title on the timeline in turn, the same
/// order each time. Kept first in, first out - and a hit not counting as a
/// use - past 64 half-size portrait titles each one asked for was the one
/// thrown out the step before, so every title was painted again on every
/// change, and the editor lagged (#261). Now what the pass in hand has
/// asked for is never thrown out for the byte budget: the floor is every
/// title on the timeline, up to [`LIVE_CEILING`].
struct LivePaintings {
    kept: HashMap<u64, LivePainting>,
    /// Which pass over the timeline this is; see [`LivePaintings::begin`].
    pass: u64,
    /// Bytes of pixels held.
    bytes: usize,
    /// What the paintings past passes asked for may hold.
    budget: usize,
    /// What all of them may hold.
    ceiling: usize,
}

impl LivePaintings {
    fn new(budget: usize, ceiling: usize) -> Self {
        LivePaintings {
            kept: HashMap::new(),
            pass: 0,
            bytes: 0,
            budget,
            ceiling,
        }
    }

    /// Starts a pass over the timeline: what it asks for is held whatever
    /// the budget.
    fn begin(&mut self) {
        self.pass += 1;
    }

    /// The painting under `key`, now the most recently used.
    fn get(&mut self, key: u64) -> Option<(Art, Arc<Frame>)> {
        let pass = self.pass;
        self.kept.get_mut(&key).map(|painting| {
            painting.used = pass;
            (painting.art.clone(), Arc::clone(&painting.frame))
        })
    }

    /// Keeps a painting under `key`. Over the budget, the least recently
    /// used go first, never one this pass has asked for. Over the ceiling
    /// with nothing else left, the one just painted is not kept: the ones
    /// painted before it stay for the next pass, rather than each pushing
    /// out the one it will want next. The newest is always kept alone.
    fn keep(&mut self, key: u64, art: Art, frame: Arc<Frame>) {
        let size = frame.pixels().len();
        let painting = LivePainting {
            art,
            frame,
            used: self.pass,
        };
        if let Some(old) = self.kept.insert(key, painting) {
            self.bytes -= old.frame.pixels().len();
        }
        self.bytes += size;
        while self.bytes > self.budget {
            let oldest = self
                .kept
                .iter()
                .filter(|(_, painting)| painting.used < self.pass)
                .min_by_key(|(_, painting)| painting.used)
                .map(|(key, _)| *key);
            let Some(oldest) = oldest else { break };
            self.drop_key(oldest);
        }
        if self.bytes > self.ceiling && self.kept.len() > 1 {
            self.drop_key(key);
        }
    }

    fn drop_key(&mut self, key: u64) {
        if let Some(gone) = self.kept.remove(&key) {
            self.bytes -= gone.frame.pixels().len();
        }
    }
}

impl Titles {
    /// A painter that caches under the app's data directory.
    pub fn new(dirs: &AppDirs) -> Titles {
        let dir = dirs.data.join("titles");
        sweep(&dir, TITLES_KEPT);
        Titles {
            dir,
            fonts: Mutex::new(None),
            loaded_files: Mutex::new(HashSet::new()),
            memo: Mutex::new(HashMap::new()),
            live: Mutex::new(LivePaintings::new(LIVE_BYTES, LIVE_CEILING)),
        }
    }

    /// Every text and shape clip on the active timeline, as an image clip
    /// each, for a `width` × `height` frame. One that fails to paint is left
    /// out and said once on stderr; the rest of the edit still renders.
    pub fn clips(&self, project: &Project, width: u32, height: u32) -> Vec<TitleClip> {
        self.clips_with(project, width, height, false)
    }

    /// [`Titles::clips`] for a monitor showing a change as it is made:
    /// every title is painted in memory at `width` by `height` - the
    /// monitor's own size, not the output's - and comes back with its
    /// pixels under a name no file has, for the monitor to hold. Nothing
    /// touches the disk, which is what makes a drag smooth: a PNG per
    /// pointer step, encoded, written and decoded again, was the lag.
    pub fn clips_live(&self, project: &Project, width: u32, height: u32) -> Vec<TitleClip> {
        self.clips_with(project, width, height, true)
    }

    fn clips_with(&self, project: &Project, width: u32, height: u32, live: bool) -> Vec<TitleClip> {
        if live {
            self.live.lock().unwrap_or_else(|e| e.into_inner()).begin();
        }
        let timeline = project.active();
        let mut out = Vec::new();
        for clip in &timeline.clips {
            let (text, shape);
            let painting = match clip.kind {
                ModelClipKind::Text => {
                    text = clip.text.clone().unwrap_or_default();
                    Painting::Title(&text)
                }
                ModelClipKind::Shape => {
                    shape = clip.shape.clone().unwrap_or_default();
                    Painting::Shape(&shape)
                }
                _ => continue,
            };
            let Some(index) = timeline
                .tracks
                .iter()
                .position(|track| track.id == clip.track_id)
            else {
                continue;
            };
            let track = &timeline.tracks[index];
            let painted = if live {
                self.painted_live(project, painting, width, height)
                    .map(|(path, art, frame)| (path, art, Some(frame)))
            } else {
                self.painted(project, painting, width, height)
                    .map(|(path, art)| (path, art, None))
            };
            let (path, art, frame) = match painted {
                Ok(art) => art,
                Err(error) => {
                    log::warn!("title {}: {error}", clip.id);
                    continue;
                }
            };
            out.push(TitleClip {
                clip_id: clip.id.clone(),
                clip: ExportClip {
                    path: path.to_string_lossy().into_owned(),
                    hidden: !track.visible,
                    muted: true,
                    volume: 0.0,
                    animation: concat_export::flatten::export_keys(clip),
                    flip_h: clip.flip_h,
                    flip_v: clip.flip_v,
                    blend: clip.blend.clone(),
                    effects: clip.video_effects.clone(),
                    scale: clip.scale,
                    offset_x: clip.offset_x,
                    offset_y: clip.offset_y,
                    rotation: clip.rotation,
                    // A title is never pulled along an axis: its box is
                    // sized by the style, and its glyphs keep their shape.
                    // 0.2.2's side grips wrote a stretch onto title clips
                    // to make a long caption fit, and honouring it here
                    // kept those captions squashed after the wrap arrived.
                    // https://github.com/jub0t/Concat/issues/119
                    // A shape is pulled: that is how a square becomes
                    // the rectangle that was wanted.
                    stretch_x: match painting {
                        Painting::Title(_) => 1.0,
                        Painting::Shape(_) => clip.stretch_x,
                    },
                    stretch_y: match painting {
                        Painting::Title(_) => 1.0,
                        Painting::Shape(_) => clip.stretch_y,
                    },
                    // The style's own opacity multiplies the clip's: a
                    // half-transparent title fades to half, not to solid.
                    opacity: match painting {
                        Painting::Title(text) => (clip.opacity * text.opacity).clamp(0.0, 1.0),
                        Painting::Shape(_) => clip.opacity.clamp(0.0, 1.0),
                    },
                    media_width: Some(width),
                    media_height: Some(height),
                    has_audio: Some(false),
                    // A shape has no words to reveal one at a time.
                    reveal_map: match painting {
                        Painting::Title(_) => Some(Arc::clone(&art.reveal)),
                        Painting::Shape(_) => None,
                    },
                    ..ExportClip::blank(ClipKind::Image, clip.start, clip.duration, index)
                },
                block: art.block,
                offset: art.offset,
                frame,
            });
        }
        out
    }

    /// One style at one size, painted in memory: the name the monitor is
    /// to hold the pixels under, the block, and the pixels.
    fn painted_live(
        &self,
        project: &Project,
        painting: Painting<'_>,
        width: u32,
        height: u32,
    ) -> Result<(PathBuf, Art, Arc<Frame>), String> {
        let key = key_of(project, painting, width, height);
        let path = PathBuf::from(format!("memory://titles/{key:016x}"));
        if let Some((art, frame)) = self.live.lock().unwrap_or_else(|e| e.into_inner()).get(key) {
            return Ok((path, art, frame));
        }
        let rendered = match painting {
            Painting::Title(style) => {
                let title = title_style(style);
                let mut fonts = self.fonts.lock().unwrap_or_else(|e| e.into_inner());
                let fonts = self.fonts_for(project, &mut fonts);
                concat_text::render_frame(fonts, &title, width, height)
                    .map_err(|error| error.to_string())?
            }
            Painting::Shape(style) => {
                concat_text::render_shape_frame(&shape_style(style), width, height)
                    .map_err(|error| error.to_string())?
            }
        };
        let art = Art {
            block: (rendered.block_width, rendered.block_height),
            offset: (rendered.block_dx, rendered.block_dy),
            reveal: reveal_of(&rendered.words, width, height),
        };
        let frame = Arc::new(
            Frame::from_rgba(rendered.width, rendered.height, rendered.rgba)
                .ok_or_else(|| "the painter returned a frame of the wrong size".to_owned())?,
        );
        self.live.lock().unwrap_or_else(|e| e.into_inner()).keep(
            key,
            art.clone(),
            Arc::clone(&frame),
        );
        Ok((path, art, frame))
    }

    /// The PNG for one style at one frame size, painted if it is not on disk
    /// yet, and the block it holds.
    fn painted(
        &self,
        project: &Project,
        painting: Painting<'_>,
        width: u32,
        height: u32,
    ) -> Result<(PathBuf, Art), String> {
        let key = key_of(project, painting, width, height);
        let png = self.dir.join(format!("{key:016x}.png"));
        let side = self.dir.join(format!("{key:016x}.json"));

        if let Some(art) = self
            .memo
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .get(&key)
            && png.is_file()
        {
            return Ok((png, art.clone()));
        }
        // On disk from an earlier session: the sidecar says how big the
        // block was and where, and which words it held, which the PNG
        // alone cannot.
        if png.is_file()
            && let Some(art) = read_block(&side, width, height)
        {
            self.remember(key, art.clone());
            return Ok((png, art));
        }

        let rendered = match painting {
            Painting::Title(style) => {
                let title = title_style(style);
                let mut fonts = self.fonts.lock().unwrap_or_else(|e| e.into_inner());
                let fonts = self.fonts_for(project, &mut fonts);
                concat_text::render(fonts, &title, width, height)
                    .map_err(|error| error.to_string())?
            }
            Painting::Shape(style) => concat_text::render_shape(&shape_style(style), width, height)
                .map_err(|error| error.to_string())?,
        };
        std::fs::create_dir_all(&self.dir).map_err(|error| error.to_string())?;
        std::fs::write(&png, &rendered.png).map_err(|error| error.to_string())?;
        let art = Art {
            block: (rendered.block_width, rendered.block_height),
            offset: (rendered.block_dx, rendered.block_dy),
            reveal: reveal_of(&rendered.words, width, height),
        };
        let words: Vec<String> = rendered
            .words
            .iter()
            .map(|w| format!("[{},{},{},{}]", w.x, w.y, w.width, w.height))
            .collect();
        let _ = std::fs::write(
            &side,
            format!(
                "{{\"w\":{},\"h\":{},\"x\":{},\"y\":{},\"words\":[{}]}}",
                art.block.0,
                art.block.1,
                art.offset.0,
                art.offset.1,
                words.join(",")
            ),
        );
        self.remember(key, art.clone());
        Ok((png, art))
    }

    /// The faces, loaded once, with the project's own files added - each
    /// loaded once for the process.
    fn fonts_for<'a>(&self, project: &Project, held: &'a mut Option<Fonts>) -> &'a Fonts {
        let fonts = held.get_or_insert_with(Fonts::new);
        let mut loaded = self.loaded_files.lock().unwrap_or_else(|e| e.into_inner());
        for font in &project.fonts {
            if !font.path.is_empty() && loaded.insert(font.path.clone()) {
                fonts.add_file(Path::new(&font.path));
            }
        }
        fonts
    }

    fn remember(&self, key: u64, art: Art) {
        self.memo
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .insert(key, art);
    }
}

/// Everything the pixels depend on, hashed. Placement and timing are left
/// out on purpose; see the module docs.
///
/// FNV-1a over the bytes, as the other caches on disk are keyed, because a
/// file's name has to mean the same thing after a toolchain upgrade and the
/// standard hasher makes no such promise.
fn key_of(project: &Project, painting: Painting<'_>, width: u32, height: u32) -> u64 {
    let mut bytes = Vec::new();
    // The style as JSON: every field, in a stable order, with no need to
    // keep a serialiser in step with the struct. A shape's is prefixed, so
    // it can never collide with a title's.
    match painting {
        Painting::Title(style) => {
            bytes.extend_from_slice(serde_json::to_string(style).unwrap_or_default().as_bytes());
        }
        Painting::Shape(style) => {
            bytes.extend_from_slice(b"shape:");
            bytes.extend_from_slice(serde_json::to_string(style).unwrap_or_default().as_bytes());
        }
    }
    bytes.push(0);
    bytes.extend_from_slice(&width.to_le_bytes());
    bytes.extend_from_slice(&height.to_le_bytes());
    for font in &project.fonts {
        bytes.extend_from_slice(font.family.as_bytes());
        bytes.push(0);
        bytes.extend_from_slice(font.path.as_bytes());
        bytes.push(0);
    }
    // Bumped when the painter's output changes for the same input, so stale
    // files are not mistaken for current ones. 3: left- and right-aligned
    // blocks moved to their anchors. 4: the sidecar gained each word's box,
    // for a per-word reveal effect to read back.
    bytes.extend_from_slice(&4u32.to_le_bytes());
    crate::media::fnv1a(&bytes)
}

/// How many painted titles the directory keeps. Each is a frame-sized PNG,
/// mostly transparent, so this is tens of megabytes at most; above it the
/// oldest go, and a title that is still in use paints again.
const TITLES_KEPT: usize = 400;

/// Removes the oldest painted titles until `keep` remain. Sidecars go with
/// their PNGs. Best effort throughout: a file that will not go is left.
fn sweep(dir: &Path, keep: usize) {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return;
    };
    let mut pngs: Vec<(std::time::SystemTime, PathBuf)> = entries
        .flatten()
        .map(|entry| entry.path())
        .filter(|path| path.extension().is_some_and(|ext| ext == "png"))
        .filter_map(|path| {
            let modified = std::fs::metadata(&path).ok()?.modified().ok()?;
            Some((modified, path))
        })
        .collect();
    if pngs.len() <= keep {
        return;
    }
    pngs.sort();
    for (_, png) in pngs.iter().take(pngs.len() - keep) {
        let _ = std::fs::remove_file(png);
        let _ = std::fs::remove_file(png.with_extension("json"));
    }
}

fn read_block(side: &Path, width: u32, height: u32) -> Option<Art> {
    let text = std::fs::read_to_string(side).ok()?;
    let value: serde_json::Value = serde_json::from_str(&text).ok()?;
    let offset = |name: &str| value.get(name).and_then(|v| v.as_i64()).unwrap_or(0) as i32;
    let rects: Vec<(i32, i32, u32, u32)> = value
        .get("words")
        .and_then(|v| v.as_array())
        .into_iter()
        .flatten()
        .filter_map(|word| {
            let word = word.as_array()?;
            Some((
                word.first()?.as_i64()? as i32,
                word.get(1)?.as_i64()? as i32,
                word.get(2)?.as_u64()? as u32,
                word.get(3)?.as_u64()? as u32,
            ))
        })
        .collect();
    Some(Art {
        block: (
            value.get("w")?.as_u64()? as u32,
            value.get("h")?.as_u64()? as u32,
        ),
        offset: (offset("x"), offset("y")),
        reveal: Arc::new(RevealMap::from_rects(width, height, &rects)),
    })
}

/// A title's per-word reveal map, baked from the boxes its layout left
/// behind - a byproduct `concat-text` already computed, not new work.
fn reveal_of(words: &[WordRect], width: u32, height: u32) -> Arc<RevealMap> {
    let rects: Vec<(i32, i32, u32, u32)> = words
        .iter()
        .map(|w| (w.x, w.y, w.width, w.height))
        .collect();
    Arc::new(RevealMap::from_rects(width, height, &rects))
}

/// The document's style, field for field, in the painter's terms.
fn title_style(style: &TextStyle) -> TitleStyle {
    TitleStyle {
        content: style.content.clone(),
        font_family: style.font_family.clone(),
        font_size: style.font_size,
        font_weight: style.font_weight,
        italic: style.italic,
        color: style.color.clone(),
        align: match style.align {
            TextAlign::Left => Align::Left,
            TextAlign::Center => Align::Center,
            TextAlign::Right => Align::Right,
        },
        stroke_width: style.stroke_width,
        stroke_color: style.stroke_color.clone(),
        shadow: style.shadow,
        background: style.background.clone(),
        background_radius: style.background_radius,
        background_padding_x: style.background_padding_x,
        background_padding_y: style.background_padding_y,
        line_height: style.line_height,
        max_width: style.max_width,
        max_height: style.max_height,
        tracking: style.tracking,
    }
}

/// The document's shape, in the painter's terms.
fn shape_style(style: &ShapeStyle) -> concat_text::ShapeStyle {
    concat_text::ShapeStyle {
        figure: match style.kind {
            ShapeKind::Square => Figure::Square,
            ShapeKind::Circle => Figure::Circle,
            ShapeKind::Triangle => Figure::Triangle,
            ShapeKind::Parallelogram => Figure::Parallelogram,
            ShapeKind::Trapezoid => Figure::Trapezoid,
            ShapeKind::Line => Figure::Line,
            ShapeKind::Arrow => Figure::Arrow,
        },
        size: style.size,
        fill: style.fill.clone(),
        stroke: style.stroke.clone(),
        stroke_width: style.stroke_width,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use concat_project::{Command, Editor};

    fn scratch(name: &str) -> AppDirs {
        let dir =
            std::env::temp_dir().join(format!("concat-titles-test-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        AppDirs {
            config: dir.join("config"),
            data: dir.join("data"),
        }
    }

    /// A title clip carrying a stretch - what 0.2.2's side grips wrote to
    /// make a long caption fit - comes back unstretched: the words wrap
    /// now, and a squashed glyph was never wanted.
    /// https://github.com/jub0t/Concat/issues/119
    #[test]
    fn a_title_is_never_stretched_whatever_its_clip_says() {
        let dirs = scratch("title");
        let mut editor = Editor::new();
        let id = editor
            .apply(Command::AddTextClip {
                above: false,
                track_id: None,
                start: 0.0,
                style: None,
                duration: Some(3.0),
                offset_y: None,
            })
            .expect("a title is added")
            .created_id
            .expect("with an id");
        editor
            .apply(Command::SetClipTransform {
                clip_id: id.clone(),
                scale: Some(1.03),
                offset_x: None,
                offset_y: None,
                rotation: None,
                stretch_x: Some(0.46),
                stretch_y: Some(2.2),
            })
            .expect("the stretch a 0.2.2 grip left behind");
        let clip = editor.project().active().clip(&id).expect("kept");
        assert_eq!(
            (clip.stretch_x, clip.stretch_y),
            (0.46, 2.2),
            "it is on the clip"
        );

        let out = Titles::new(&dirs).clips(editor.project(), 640, 360);
        assert_eq!((out[0].clip.stretch_x, out[0].clip.stretch_y), (1.0, 1.0));
        assert_eq!(
            out[0].clip.scale, 1.03,
            "the scale is honoured; only the stretch is not"
        );
    }

    /// A text clip comes back as an image clip on its own track, pointing
    /// at a PNG on disk that is the frame's size, and a second ask for the
    /// same title paints nothing new.
    #[test]
    fn a_title_rejoins_as_a_still() {
        let dirs = scratch("a_title_rejo");
        let mut editor = Editor::new();
        let id = editor
            .apply(Command::AddTextClip {
                above: false,
                track_id: None,
                start: 2.0,
                style: None,
                duration: Some(3.0),
                offset_y: Some(0.3),
            })
            .expect("a title is added")
            .created_id
            .expect("with an id");

        let titles = Titles::new(&dirs);
        let out = titles.clips(editor.project(), 640, 360);
        assert_eq!(out.len(), 1);
        let title = &out[0];
        assert_eq!(title.clip_id, id);
        assert!(matches!(title.clip.kind, ClipKind::Image));
        assert_eq!((title.clip.start, title.clip.duration), (2.0, 3.0));
        assert_eq!(title.clip.offset_y, 0.3);
        assert_eq!(title.clip.media_width, Some(640));
        assert!(title.block.0 > 0 && title.block.1 > 0);
        assert_eq!(
            title.offset,
            (0, 0),
            "a centred title's block is on the clip"
        );
        // "Your text": two words, so their reveal order spans 0 to 255.
        let reveal = title.clip.reveal_map.as_ref().expect("a title reveals");
        assert_eq!((reveal.width, reveal.height), (640, 360));
        assert!(reveal.gray.contains(&0));
        assert!(reveal.gray.contains(&255), "a second word reaches the top");
        let painted = Path::new(&title.clip.path);
        assert!(painted.is_file(), "the PNG is on disk");
        let stamp = std::fs::metadata(painted).and_then(|m| m.modified()).ok();

        // Same words, same frame: same file, untouched.
        let again = titles.clips(editor.project(), 640, 360);
        assert_eq!(again[0].clip.path, title.clip.path);
        assert_eq!(
            std::fs::metadata(painted).and_then(|m| m.modified()).ok(),
            stamp
        );

        // A different frame is a different picture.
        let wide = titles.clips(editor.project(), 1280, 720);
        assert_ne!(wide[0].clip.path, title.clip.path);

        // Aligned left, the block starts at the clip's position and its
        // centre is reported half a block to the right - and a second
        // painter, reading the sidecar cold, says the same.
        let style = concat_project::model::TextStyle {
            align: concat_project::model::TextAlign::Left,
            ..Default::default()
        };
        editor
            .apply(Command::UpdateClip {
                clip_id: id.clone(),
                patch: concat_project::commands::ClipPatch {
                    text: Some(Some(style)),
                    ..Default::default()
                },
            })
            .expect("aligns");
        let left = titles.clips(editor.project(), 640, 360);
        assert!(left[0].offset.0 > 0);
        assert!((left[0].offset.0 as u32).abs_diff(left[0].block.0 / 2) <= 1);
        let cold = Titles::new(&dirs).clips(editor.project(), 640, 360);
        assert_eq!(cold[0].offset, left[0].offset);
        assert_eq!(cold[0].block, left[0].block);
        // The sidecar carries the words too, so a cold read reveals the
        // same order as the one that painted them.
        assert_eq!(
            cold[0].clip.reveal_map.as_ref().map(|r| &*r.gray),
            left[0].clip.reveal_map.as_ref().map(|r| &*r.gray)
        );
        let _ = std::fs::remove_dir_all(dirs.data.parent().unwrap());
    }

    /// More titles than the byte budget holds are all kept while the
    /// timeline shows them: a second live pass paints none of them again.
    /// Kept first in, first out, each was thrown out just before it was
    /// wanted, and every pass painted them all (#261).
    #[test]
    fn a_timeline_of_titles_past_the_budget_is_painted_once() {
        let dirs = scratch("live_many");
        let mut editor = Editor::new();
        // Four megabytes a painting at 1024 square: 40 is more than the
        // 128 MB budget holds.
        let count = LIVE_BYTES / (1024 * 1024 * 4) + 8;
        for index in 0..count {
            editor
                .apply(Command::AddShapeClip {
                    above: false,
                    track_id: None,
                    start: index as f64,
                    style: Some(concat_project::model::ShapeStyle {
                        size: 0.1 + index as f64 * 0.001,
                        ..Default::default()
                    }),
                    duration: Some(1.0),
                    name: format!("Shape {index}"),
                })
                .expect("a shape is added");
        }
        let titles = Titles::new(&dirs);
        let first = titles.clips_live(editor.project(), 1024, 1024);
        assert_eq!(first.len(), count);
        let second = titles.clips_live(editor.project(), 1024, 1024);
        let repainted = first
            .iter()
            .zip(&second)
            .filter(|(before, after)| {
                !Arc::ptr_eq(
                    before.frame.as_ref().expect("live"),
                    after.frame.as_ref().expect("live"),
                )
            })
            .count();
        assert_eq!(repainted, 0, "of {count}");
    }

    /// A painting asked for again is the most recently used, and outlives
    /// one asked for less recently; past the ceiling the first painted
    /// stay and the newest is not kept.
    #[test]
    fn live_paintings_go_least_recently_used_first() {
        let art = || Art {
            block: (1, 1),
            offset: (0, 0),
            reveal: Arc::new(RevealMap::from_rects(1, 1, &[])),
        };
        let frame = || Arc::new(Frame::transparent(4, 4));
        let size = frame().pixels().len();
        let mut live = LivePaintings::new(2 * size, 3 * size);

        live.begin();
        live.keep(1, art(), frame());
        live.keep(2, art(), frame());
        live.begin();
        assert!(live.get(1).is_some(), "1 is used again");
        live.begin();
        live.keep(3, art(), frame());
        assert!(live.get(1).is_some(), "the recently used stays");
        assert!(live.get(2).is_none(), "the least recently used goes");

        // One pass asking for more than the budget keeps them all, to the
        // ceiling; past it, the newest is the one not kept.
        live.begin();
        for key in 10..14 {
            live.keep(key, art(), frame());
        }
        assert!(live.get(10).is_some() && live.get(11).is_some() && live.get(12).is_some());
        assert!(live.get(13).is_none());
        assert!(live.bytes <= 3 * size);
    }

    /// A shape clip rejoins the flattened list as a still at its clip's
    /// stretch - that is how a square becomes a rectangle - with the
    /// figure's box reported and no words to reveal.
    #[test]
    fn a_shape_rejoins_as_a_still_and_keeps_its_stretch() {
        let dirs = scratch("shape");
        let mut editor = Editor::new();
        let id = editor
            .apply(Command::AddShapeClip {
                above: true,
                track_id: None,
                start: 0.0,
                style: None,
                duration: Some(3.0),
                name: "Square".to_owned(),
            })
            .expect("a shape is added")
            .created_id
            .expect("with an id");
        editor
            .apply(Command::SetClipTransform {
                clip_id: id.clone(),
                scale: None,
                offset_x: None,
                offset_y: None,
                rotation: None,
                stretch_x: Some(2.0),
                stretch_y: Some(0.5),
            })
            .expect("pulled wide");

        let out = Titles::new(&dirs).clips(editor.project(), 640, 360);
        assert_eq!(out.len(), 1);
        assert_eq!(out[0].clip_id, id);
        assert!(matches!(out[0].clip.kind, ClipKind::Image));
        assert_eq!((out[0].clip.stretch_x, out[0].clip.stretch_y), (2.0, 0.5));
        assert_eq!(out[0].block, (126, 126), "35 % of 360, squared");
        assert_eq!(out[0].offset, (0, 0));
        assert!(out[0].clip.reveal_map.is_none());
        assert!(
            Path::new(&out[0].clip.path).is_file(),
            "painted to disk like a title"
        );
    }
}
