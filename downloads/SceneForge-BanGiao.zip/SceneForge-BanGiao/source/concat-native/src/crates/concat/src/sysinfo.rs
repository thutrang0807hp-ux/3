// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2026 Jareer and Concat contributors

//! What Settings > About reports about this machine and this build.

use crate::i18n::t;

pub fn os_description() -> String {
    #[cfg(target_os = "macos")]
    {
        // Bare `sw_vers` prints all three lines at once, so this is one
        // process rather than the three the flags would cost.
        let fields = std::process::Command::new("sw_vers")
            .output()
            .ok()
            .filter(|out| out.status.success())
            .map(|out| String::from_utf8_lossy(&out.stdout).into_owned())
            .unwrap_or_default();
        let field = |key: &str| {
            fields
                .lines()
                .find_map(|line| line.strip_prefix(key)?.split(':').nth(1))
                .map(str::trim)
                .filter(|value| !value.is_empty())
                .map(str::to_owned)
        };
        let name = field("ProductName").unwrap_or_else(|| "macOS".into());
        match (field("ProductVersion"), field("BuildVersion")) {
            (Some(version), Some(build)) => format!("{name} {version} ({build})"),
            (Some(version), None) => format!("{name} {version}"),
            _ => name,
        }
    }
    #[cfg(target_os = "linux")]
    {
        // The distribution's own name for itself, which is what a report
        // wants; the kernel version is the next question, not the first.
        let pretty = std::fs::read_to_string("/etc/os-release")
            .ok()
            .and_then(|release| {
                release
                    .lines()
                    .find_map(|line| line.strip_prefix("PRETTY_NAME="))
                    .map(|value| value.trim_matches('"').to_owned())
            })
            .filter(|value| !value.is_empty());
        pretty.unwrap_or_else(|| "Linux".into())
    }
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        // CREATE_NO_WINDOW: the app is a GUI-subsystem binary with no
        // console to lend, so cmd would open one of its own and it would
        // flash up over Settings for the moment `ver` takes.
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        std::process::Command::new("cmd")
            .args(["/c", "ver"])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
            .ok()
            .filter(|out| out.status.success())
            .map(|out| String::from_utf8_lossy(&out.stdout).trim().to_owned())
            .filter(|value| !value.is_empty())
            .unwrap_or_else(|| "Windows".into())
    }
    #[cfg(not(any(target_os = "macos", target_os = "linux", target_os = "windows")))]
    {
        std::env::consts::OS.to_owned()
    }
}

/// What Settings > About shows under "System information", and what its copy
/// button puts on the clipboard.
///
/// One list, read twice: the rows on screen and the block that is copied are
/// built from the same pairs, so a fact cannot be on the page and missing
/// from the report. Gathered once — every line of it is fixed for the life of
/// the process — and handed over as a model that is never replaced.
pub fn system_facts() -> Vec<(String, String)> {
    vec![
        (
            t("sysinfo.application"),
            format!("Concat {}", env!("CARGO_PKG_VERSION")),
        ),
        (
            t("sysinfo.build"),
            format!("{} · {}", env!("BUILD_PROFILE"), env!("BUILD_TARGET")),
        ),
        // The renderer, the first question to ask about anything that looks
        // wrong on screen. One now, but a bug report outlives the build it
        // came from, and an older one may have drawn with FemtoVG.
        (t("sysinfo.renderer"), "Skia".into()),
        // The adapter the window and the monitor draw on, and whether it is
        // a GPU at all. A machine that fell back to WARP looks like any
        // other in the window, and the difference was the whole story of
        // https://github.com/jub0t/Concat/issues/135
        (
            t("sysinfo.graphics"),
            crate::gpu::adapter_description().unwrap_or("none").into(),
        ),
        (
            t("sysinfo.engine"),
            format!("concat-engine · FFmpeg {}", concat_media::linked_version()),
        ),
        (t("sysinfo.operatingSystem"), os_description()),
        (
            t("sysinfo.processor"),
            format!(
                "{} · {} threads",
                std::env::consts::ARCH,
                std::thread::available_parallelism().map_or(0, |count| count.get())
            ),
        ),
        (t("sysinfo.toolchain"), env!("BUILD_RUSTC").into()),
    ]
}
