"""SceneForge adapter to Concat's public JSON-RPC API (no copied editor code)."""
from collections import deque
import json
import socket
import time
import subprocess
import queue
import threading
import os
from pathlib import Path


class ConcatError(RuntimeError):
    pass


class ConcatClient:
    def __init__(self, token: str, host='127.0.0.1', port=7420, timeout=30):
        if host not in ('127.0.0.1', '::1', 'localhost'):
            raise ValueError('Native Concat connection must use loopback.')
        self.socket = socket.create_connection((host, port), timeout=timeout)
        self.stream = self.socket.makefile('rwb')
        self.events = deque()
        self.counter = 0
        try:
            self.call('auth', token=token)
        except Exception:
            self.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def close(self):
        self.stream.close()
        self.socket.close()

    def _read(self):
        line = self.stream.readline(32 * 1024 * 1024 + 1)
        if not line:
            raise ConcatError('Concat disconnected.')
        if len(line) > 32 * 1024 * 1024:
            raise ConcatError('Concat response exceeds the supported limit.')
        return json.loads(line)

    def call(self, method, **params):
        self.counter += 1
        request_id = self.counter
        request = {'jsonrpc': '2.0', 'id': request_id, 'method': method, 'params': params}
        self.stream.write((json.dumps(request) + '\n').encode())
        self.stream.flush()
        while True:
            reply = self._read()
            if 'method' in reply:
                self.events.append(reply)
                continue
            if reply.get('id') != request_id:
                raise ConcatError('Unexpected Concat response ID.')
            if 'error' in reply:
                error = reply['error']
                raise ConcatError(f"{method}: {error.get('message', 'Request failed')}")
            return reply['result']

    def _get_timeout(self):
        return self.socket.gettimeout()

    def _set_timeout(self, seconds):
        self.socket.settimeout(seconds)

    def export(self, path, output, timeout=180):
        job = self.call('export.run', path=str(path), output=str(output))['job']
        deadline = time.monotonic() + timeout
        previous = self._get_timeout()
        try:
            while time.monotonic() < deadline:
                self._set_timeout(max(.1, deadline - time.monotonic()))
                event = self.events.popleft() if self.events else self._read()
                if event.get('params', {}).get('job') != job:
                    continue
                if event.get('method') == 'export.failed':
                    raise ConcatError(str(event.get('params', {}).get('error', 'Export failed')))
                if event.get('method') == 'export.done':
                    return event['params']
            raise TimeoutError('Concat export timed out; check the job in Concat before retrying.')
        finally:
            self._set_timeout(previous)

    def create_portrait(self, location, name):
        return self.call('project.create', location=str(location), name=name,
                         video={'width': 1080, 'height': 1920, 'rateNum': 30, 'rateDen': 1})

    def append_video(self, project_path, source_path):
        """Import real media and append after the active timeline's content."""
        imported = self.call('media.import', path=str(project_path), file=str(source_path))
        # IDs and timing are read from the engine's current view, never invented.
        project = imported['project']
        media = next(item for item in project['media'] if item['path'] == str(source_path))
        timeline = next(t for t in project['timelines'] if t['id'] == project['activeTimelineId'])
        start = max((clip['start'] + clip['duration'] for clip in timeline['clips']), default=0)
        return self.call('edit.apply', path=str(project_path),
                         command={'op': 'addClipAtFirstFree', 'mediaId': media['id'], 'start': start})


class ConcatProcess(ConcatClient):
    """A private native-engine process using the documented stdin API."""
    def __init__(self, binary, env=None, timeout=30):
        self.process = subprocess.Popen([str(binary), 'api'], stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env)
        self.stream = self.process.stdin
        self.events, self.counter, self.timeout = deque(), 0, timeout
        self.inbox = queue.Queue(maxsize=1024)
        def read():
            try:
                while True:
                    line = self.process.stdout.readline(32 * 1024 * 1024 + 1)
                    if not line:
                        self.inbox.put(ConcatError('Native Concat process disconnected.'))
                        return
                    if len(line) > 32 * 1024 * 1024:
                        raise ConcatError('Native response exceeds the supported limit.')
                    self.inbox.put(json.loads(line))
            except Exception as error:
                self.inbox.put(error)
        self.reader = threading.Thread(target=read, daemon=True)
        self.reader.start()

    def _read(self):
        try:
            item = self.inbox.get(timeout=self.timeout)
        except queue.Empty:
            raise TimeoutError('Native Concat request timed out.') from None
        if isinstance(item, Exception):
            raise item
        return item

    def _get_timeout(self):
        return self.timeout

    def _set_timeout(self, seconds):
        self.timeout = seconds

    def close(self):
        self.stream.close()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.process.stdout.close()
        self.reader.join(timeout=1)


def native_binary(root, name):
    import shutil
    configured = os.getenv('CONCAT_CLI_BIN' if name == 'concat-cli' else 'CONCAT_EDITOR_BIN')
    if configured:
        path = Path(configured).expanduser()
        return path if path.is_file() else None
    suffix = '.exe' if os.name == 'nt' else ''
    candidates = [root / 'concat-native/src/target' / profile / (name + suffix)
                  for profile in ('debug', 'quick', 'app', 'release')]
    if name == 'concat':
        candidates.append(root / '.native-deps/concat-official/opt/concat/concat')
    return next((p for p in candidates if p.is_file()), None) or (Path(shutil.which(name)) if shutil.which(name) else None)


def native_runtime_env(root):
    env = os.environ.copy()
    local = [root / '.native-deps/sysroot/usr/lib/x86_64-linux-gnu',
             root / '.native-deps/concat-official/opt/concat/lib']
    if os.name != 'nt' and any(p.is_dir() for p in local):
        env['LD_LIBRARY_PATH'] = ':'.join(item for item in [*(str(p) for p in local if p.is_dir()), env.get('LD_LIBRARY_PATH', '')] if item)
    return env


def create_native_project(root, sources, name):
    """Create a separate real Concat project; existing edits are never overwritten."""
    binary = native_binary(root, 'concat-cli')
    if not binary:
        raise ConcatError('Chưa có concat-cli. Build mã nguồn hoặc cấu hình CONCAT_CLI_BIN.')
    location = root / 'data/concat-projects'
    location.mkdir(parents=True, exist_ok=True)
    if Path(name).name != name or name in ('', '.', '..'):
        raise ValueError('Invalid native project name.')
    project = location / name
    if project.exists():
        raise FileExistsError('Native project already exists; choose a new name.')
    try:
        with ConcatProcess(binary, env=native_runtime_env(root)) as client:
            version = client.call('version')
            if version.get('apiVersion') != '0.2':
                raise ConcatError('Phiên bản Concat API chưa được hỗ trợ.')
            client.create_portrait(location, name)
            for source in sources:
                source = Path(source).resolve(strict=True)
                probe = client.call('media.probe', path=str(source))
                video = probe.get('video') or {}
                width, height = video.get('width'), video.get('height')
                if not width or not height or abs(width / height - 9 / 16) > .015:
                    raise ConcatError('Chỉ đưa video dọc 9:16 vào bản dựng này.')
                client.append_video(project, source)
            client.call('project.save', path=str(project))
            client.call('project.close', path=str(project), save=True)
        return {'path': str(project), 'name': name, 'width': 1080, 'height': 1920,
                'clip_count': len(sources), 'engine': 'Concat', 'version': version['concat']}
    except Exception:
        # Only the newly reserved output is cleaned; source clips remain untouched.
        import shutil
        if project.exists():
            shutil.rmtree(project)
        raise
