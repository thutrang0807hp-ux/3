"""Real browser worker against intercepted provider pages, no online accounts/sends."""
import asyncio,base64,io,json,tempfile,uuid
from pathlib import Path
from PIL import Image
from fastapi import HTTPException
from .web_images import WebImages,SITES
from .vault import Vault
from .request_ledger import RequestLedger
from .account_pool import AccountPool

async def main():
 with tempfile.TemporaryDirectory(prefix='sf-web-images-')as tmp:
  root=Path(tmp);vault=Vault(root);ledger=RequestLedger(root);raw=io.BytesIO();Image.new('RGB',(256,256),'blue').save(raw,format='PNG');png=raw.getvalue();url='data:image/png;base64,'+base64.b64encode(png).decode();clicks=[]
  sites={k:{**v,'editor':'#prompt','send':'#send','images':'img.generated'}for k,v in SITES.items()}
  service=WebImages(vault,root,ledger,sites=sites)
  async def browser(headless=False):
   from playwright.async_api import async_playwright
   pw=await async_playwright().start();b=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);original=b.new_context
   async def context(**kw):
    c=await original(**kw)
    async def route(r):
     if r.request.resource_type!='document':return await r.abort()
     await r.fulfill(content_type='text/html',body='<textarea id="prompt"></textarea><input type="file" multiple><button id="send">Send</button><script>document.querySelector("#send").onclick=()=>{const i=new Image();i.className="generated";i.src='+json.dumps(url)+';document.body.append(i);fetch("/fixture-sent",{method:"POST"});};</script>')
    async def sent(r):clicks.append(r.request.url);await r.fulfill(body='ok')
    await c.route('**/*',route);await c.route('**/fixture-sent',sent);return c
   b.new_context=context;return pw,b
  service.new_browser=browser
  for source in SITES:
   login=await service.login(source,'Fixture '+source);entry=service.logins[login['login_id']]
   try:await service.save_login(login['login_id']);raise AssertionError('Guest login saved')
   except HTTPException as e:assert e.status_code==409
   await entry['context'].add_cookies([{'name':'session_token','value':'PRIVATE_SESSION_'+source,'url':SITES[source]['url']}])
   account=await service.save_login(login['login_id']);aid=account['id'];assert not service.logins
   assert 'PRIVATE_SESSION'not in vault.path.read_bytes().decode('latin1')
   body={'request_id':'webimage-'+str(uuid.uuid4()),'source':source,'kind':'image','prompt':'A blue product','aspect':'9:16','references':[{'mime_type':'image/png','data':base64.b64encode(png).decode()}],'confirm_send':True,'selection_token':service.status(source)['selection']['token']}
   stale={**body,'request_id':'webimage-'+str(uuid.uuid4()),'selection_token':'old'}
   try:await service.submit(stale);raise AssertionError('Stale token sent')
   except HTTPException as e:assert e.status_code==409 and e.detail['submitted']is False
   await service.submit(body);await asyncio.gather(*list(service.tasks.values()));record=service.lookup(body['request_id']);assert record['state']=='done',record
   assert record['result']['account_id']==aid and record['result']['origin']==source and service.file(body['request_id']).path.read_bytes()==png
   before=len(clicks);await service.submit(body);assert len(clicks)==before
  assert len(clicks)==3,clicks
  # A worker failure after a click is ambiguous forever, never silently resent.
  async def uncertain(rid,payload,path,sent):sent();raise OSError('fixture dropped response')
  service.runner=uncertain;source='chatgpt';body={**body,'request_id':'webimage-'+str(uuid.uuid4()),'source':source,'selection_token':service.status(source)['selection']['token']}
  await service.submit(body);await asyncio.gather(*list(service.tasks.values()));assert service.lookup(body['request_id'])['state']=='unknown'
  try:await service.submit(body);raise AssertionError('Unknown replayed')
  except HTTPException as e:assert e.status_code==409
  assert 'PRIVATE_SESSION'not in json.dumps(vault.rows('logs'))
  await service.close()
 print('PASS web images: actual Playwright login/guest rejection, encrypted isolated sessions, upload/send/new-image binding/download for ChatGPT/Grok/Meta intercepted pages, original PNG, selected account tokens, duplicate/unknown no replay; no online provider generation.')

if __name__=='__main__':asyncio.run(main())
