const SFRecipes = (() => {
 const colors={question:'#f0645a',solution:'#3cc8e0',benefit:'#a98bf5',trial:'#fa9b58',proof:'#f5b544',close:'#d4f53c'};
 const labels={question:'Hỏi / Vấn đề',solution:'Giải pháp',benefit:'Lợi ích',trial:'Dùng thử',proof:'Bằng chứng',close:'Chốt'};
 const shots={orbit:'Cận cảnh xoay',detail:'Chi tiết',use:'Trong bối cảnh dùng',hands:'Tay thao tác',problem:'Vấn đề',result:'Kết quả',wide:'Toàn cảnh',cta:'Kêu gọi mua'};
 const industries=['Chung','Đồ xe','Mỹ phẩm','Đồ bếp','Khác'];
 function seed(id,name,parts){let at=0;return{id,name,industry:'Chung',videoType:'Show sản phẩm',source:'starter',tips:'Thay lời theo thông tin thực tế của sản phẩm. Kiểm tra công dụng trước khi xuất.',beats:parts.map(([name,role,type,seconds,purpose])=>{const b={name,role,type,start:at,end:at+seconds,purpose,example:''};at+=seconds;return b;})};}
 const starters=[seed('problem-solution','Hỏi → Giải pháp → Lợi ích → Chốt',[
 ['Hỏi','question','problem',4,'Gợi nhu cầu của người xem'],['Giải pháp','solution','use',5,'Giới thiệu sản phẩm trong bối cảnh sử dụng'],['Lợi ích','benefit','detail',6,'Một điểm khác biệt đã được xác minh'],['Dùng thử','trial','hands',5,'Thao tác rõ ràng, đúng hướng dẫn'],['Chốt','close','cta',4,'Mời xem thêm thông tin']]),
 seed('honest-review','Review · trải nghiệm',[
 ['Mở đầu','question','wide',4,'Giới thiệu nhu cầu'],['Chi tiết','benefit','detail',5,'Chỉ rõ đặc điểm sản phẩm'],['Dùng thử','trial','hands',6,'Minh họa thao tác'],['Nhận xét','proof','result',5,'Chỉ dùng nhận xét có căn cứ'],['Kết','close','cta',4,'Lời mời tìm hiểu']]),
 seed('show-product','Show sản phẩm · không lời',[
 ['Toàn cảnh','solution','wide',4,'Giới thiệu bố cục'],['Xoay','benefit','orbit',5,'Thấy hình dáng thật'],['Chi tiết','trial','detail',5,'Xem chất liệu và nhãn'],['Kết','close','cta',4,'Chừa chỗ cho thông tin sản phẩm']])];
 function validate(raw){
  if(!raw||!String(raw.name||'').trim()||!Array.isArray(raw.beats)||!raw.beats.length||raw.beats.length>60)throw Error('Công thức cần tên và từ 1 đến 60 nhịp.');
  let at=0;const beats=raw.beats.map(b=>{const start=Number(b.start),end=Number(b.end);if(!Number.isFinite(start)||!Number.isFinite(end)||Math.abs(start-at)>.02||end-start<.2||end>600)throw Error('Mốc giây phải liên tục từ 0; mỗi nhịp ≥ 0,2s và tổng ≤ 600s.');if(!Object.hasOwn(shots,b.type)||!Object.hasOwn(colors,b.role))throw Error('Chọn kiểu cảnh và loại nhịp hợp lệ.');at=end;return{name:String(b.name||labels[b.role]).slice(0,120),role:b.role,type:b.type,start,end,purpose:String(b.purpose||'').slice(0,1000),example:String(b.example||'').slice(0,1000),angle:String(b.angle||'').slice(0,300),movement:String(b.movement||'').slice(0,300),onScreen:String(b.onScreen||'').slice(0,500)};});
  if(raw.scriptBody!==undefined&&(!Array.isArray(raw.scriptBody)||raw.scriptBody.length!==beats.length||raw.scriptBody.some(b=>!b||typeof b.text!=='string'||b.text.length>5000)))throw Error('Bản lời kịch bản không hợp lệ.');
  return{...raw,id:String(raw.id||crypto.randomUUID()),name:String(raw.name).trim().slice(0,160),industry:String(raw.industry||'Chung').slice(0,80),videoType:String(raw.videoType||'Show sản phẩm').slice(0,80),tips:String(raw.tips||'').slice(0,3000),beats,hook:String(raw.hook||'').slice(0,160),metrics:metrics(raw.metrics)};
 }
 function metrics(raw={}){const out={};for(const k of ['likes','ctr']){const n=raw?.[k];if(n===undefined||n===null||n==='')continue;const v=Number(n);if(!Number.isFinite(v)||v<0||(k==='ctr'&&v>100)||(k==='likes'&&!Number.isSafeInteger(v)))throw Error('Chỉ số phải không âm; CTR từ 0–100%, lượt thích là số nguyên.');out[k]=v;}return out;}
 function rank(r){return (Number(r.up||0)-Number(r.down||0))*100+(Math.min(100,Number(r.metrics?.ctr||0))/10)+(Math.min(10,Math.log10(1+Number(r.metrics?.likes||0))));}
 function strip(r){return{id:r.id,name:r.name,industry:r.industry,videoType:r.videoType,source:r.source,sourceName:r.sourceName,scriptBody:r.scriptBody,hook:r.hook,beats:r.beats,tips:r.tips};}
 function duration(r){return r.beats.at(-1)?.end||0;}
 function bar(r){return '<div class="recipeBar" aria-label="Các nhịp theo thời lượng">'+r.beats.map(b=>'<i title="'+b.start+'–'+b.end+'s" style="flex:'+(b.end-b.start)+';background:'+colors[b.role]+'"></i>').join('')+'</div>';}
 return{colors,labels,shots,industries,starters,validate,strip,duration,bar,metrics,rank};
})();
