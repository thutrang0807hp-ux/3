"""Read-only source snapshot focused on Settings and its account/job consumers."""
from pathlib import Path
import hashlib,json,zipfile,tempfile,subprocess,os,ast
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'artifacts/SceneForge-CaiDat-CodeGon.zip';PREFIX='SceneForge-CaiDat-CodeGon/';files={}
def add(path):
 p=ROOT/path
 if not p.is_file():raise FileNotFoundError(p)
 files[path]=p.read_bytes()
# Keep backend modules intact so reviewers can follow imports and actual routes.
for p in (ROOT/'local_engine').iterdir():
 if p.is_file()and(p.suffix=='.py'and not p.name.startswith('check_')or p.suffix in ('.bat','.sh','.txt')or p.name=='speech_guard.json'):add(p.relative_to(ROOT).as_posix())
for n in ['storage-hub.js','storage-hub.css','home-archive.js','home-archive.css','archive-lifecycle.js','check_storage_hub.py','check_storage_hub_local.py','home-dashboard.js','home-dashboard.css','cost-monitor.js','settings-redesign.js','monitor-settings.css','check_monitor_settings.py','check_settings_live.py','template.html','app.js','package4.js','package5.js','package5.css','package6.js','accounts-dashboard.js','accounts-dashboard.css','account-dispatch.js','analysis-v3-settings.js','machine-checks.js','machine-checks.css','library-runtime.js','library-portable.js','library-panel.js','storage-actions.js','recovery.js','batch-studio.js','batch-studio.css','check_accounts_dashboard.py','check_batch_multisource.py']:
 add('scripts/app-shell/'+n)
for n in ['scripts/demo-web/build.py','scripts/shared/provider-receipts.js','scripts/settings-review/package_settings_review.py','scripts/workflow/direct-providers.js','scripts/workflow/gemini-chat.js','scripts/photo-studio/providers.js','scripts/photo-studio/gemini-chat.js','scripts/photo-studio/clip-flow.js']:
 if (ROOT/n).exists():add(n)
for n in ['check_monitoring','check_verify_save','check_web_image_reliability','check_account_settings','check_account_failover','check_gemini_chat_routes','check_web_images','check_web_images_api','check_flow_provider','check_flow_account_engine','check_muse_selection','check_video_concurrency','check_package5','check_machine_checks']:
 add('local_engine/'+n+'.py')
for n in ['storage-hub-redesign.md','monitor-settings-redesign.md','chat-source-reliability.md','accounts-settings-implementation.md','accounts-dashboard-implementation.md','settings-scroll-implementation.md','multi-account-dispatch.md','gemini-web-installation.md','flow-installation-status.md','video-same-account-concurrency.md','batch-multisource.md']:
 add('docs/'+n)
for p in (ROOT/'docs/engine-audit').iterdir():
 if p.is_file()and p.suffix in ('.json','.md'):add(p.relative_to(ROOT).as_posix())
for n in ['check_account_settings.log','check_web_images.log','check_web_images_api.log','check_flow_provider.log','check_flow_account_engine-venv.log','check_dashboard-final.log','check_multisource-final.log','check_clean_package-final.log']:
 files['review/logs/'+n]=(ROOT/'artifacts/batch-multisource-tests'/n).read_bytes()
files['review/CHAT_RELIABILITY_CHECKS.json']=(ROOT/'artifacts/chat-reliability-checks.json').read_bytes()
for log in (ROOT/'artifacts/chat-reliability-tests').glob('*.log'):files['review/current-logs/'+log.name]=log.read_bytes()
files['review/EXISTING_CHECKS.json']=(ROOT/'artifacts/batch-multisource-checks.json').read_bytes()
files['review/MONITOR_SETTINGS_CHECKS.json']=(ROOT/'artifacts/monitor-settings-checks.json').read_bytes()
for log in (ROOT/'artifacts/monitor-settings-tests').glob('*.log'):files['review/monitor-settings-logs/'+log.name]=log.read_bytes()
files['review/STORAGE_HUB_CHECKS.json']=(ROOT/'artifacts/storage-hub-checks.json').read_bytes()
for log in (ROOT/'artifacts/storage-hub-tests').glob('*.log'):files['review/storage-hub-logs/'+log.name]=log.read_bytes()
# Introspect the actual app with an empty disposable vault; no real account data.
with tempfile.TemporaryDirectory(prefix='sf-settings-routes-')as tmp:
 code="from local_engine.server import app;import json;print(json.dumps([{'path':r.path,'methods':sorted(r.methods),'endpoint_module':r.endpoint.__module__,'endpoint_name':r.endpoint.__name__}for r in app.routes if r.path.startswith('/local-api/')and hasattr(r,'methods')],ensure_ascii=False))"
 r=subprocess.run(['python','-c',code],cwd=ROOT,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp},capture_output=True,text=True,check=True)
 routes=json.loads(r.stdout.strip().splitlines()[-1]);files['review/ROUTES.json']=(json.dumps(routes,ensure_ascii=False,indent=2)+'\n').encode()
files['DOC_TRUOC.md']='''# Code Cài đặt — SceneForge

Snapshot code 27/10/2026: storage-hub-20261027, sau bản Chi phí/Cài đặt `e48f0f6`.
Đọc docs/storage-hub-redesign.md và review/STORAGE_HUB_CHECKS.json trước.
Lớp UI cuối là storage-hub.js, gộp điểm vào Lưu trữ và Thùng rác; đọc sau settings-redesign.js.
Bản này bổ sung Tổng quan, Chi phí, đo dung lượng, verify-save nguyên tử.
Đọc settings-redesign.js và cost-monitor.js sau các wrapper cũ; chúng là lớp UI cuối.
Đây là gói ĐỌC/ĐÁNH GIÁ CODE, không phải bộ cài hay mô phỏng độc lập.
Không sửa runtime khi đóng gói. Mọi file nguồn giữ nguyên byte, có manifest hash.
Không chứa model, ảnh/video dự án, database, cookie, mật khẩu, API key thật,
node_modules, venv, app.asar hoặc code/bộ cài Phoma. Test có tài khoản/key GIẢ ghi rõ.

## Phạm vi

Toàn bộ giao diện Cài đặt: Tài khoản, Phân tích AI, giọng, thư mục/kho lưu,
đầu ra và các mục engine/chẩn đoán có trong `g5Tabs`.
Kèm backend nguyên module để theo đường import; có endpoint ngoài Cài đặt vì
chúng dùng chung server/kho/ledger. Consumer Batch/Video mẫu/Ảnh chỉ kèm file
liên quan để truy vết lựa chọn tài khoản, không kèm toàn bộ hai workflow.
Thiếu các file build/UI ngoài phạm vi là chủ đích; KHÔNG chạy build từ gói này.
Không chứa SDK Flow/Muse/Gemini web bên thứ ba đã cài ngoài repo; xem setup và
`docs/engine-audit` để biết nguồn/revision, không suy rằng SDK đã được kèm gói.

## Đọc theo thứ tự

1. `scripts/demo-web/build.py`: thứ tự nạp. Các hàm được bọc/định nghĩa lại ở file
   sau; phải đọc hết `package5` → `accounts-dashboard` → `analysis-v3-settings`
   → `account-dispatch` → `storage-actions`, không chỉ đọc định nghĩa đầu.
2. `scripts/app-shell/package5.js`: g5Tabs, g5Content, g5BindSettings, prefs,
   engineRequest, lưu key, kiểm máy, lưu cài đặt. `app.js/package4.js/package6.js`
   cung cấp nền shell, lưu prefs, mở phòng và truyền cài đặt.
3. `accounts-dashboard.js`: đọc trạng thái, chọn đúng service, kết nối/kiểm/gỡ,
   sửa tên/bật/tắt/sắp thứ tự, đăng nhập các nguồn mới. `account-dispatch.js`:
   chế độ dùng riêng/chia việc/dự phòng, model Gemini theo nhiệm vụ, giới hạn clip.
4. `local_engine/server.py`, `account_settings.py`, `account_pool.py`, `vault.py`,
   `policy.py`, `schema.py`: trạng thái/routes, cấu hình dùng chung, phiên mã hóa,
   tính sẵn sàng của tài khoản; `review/ROUTES.json` lấy từ app thật với kho rỗng.
5. `flow_accounts.py`, `flow_provider.py`, `flow_account_engine.py`: đồng bộ/pin
   tài khoản engine Flow. `gemini_chat.py/gemini_chat_worker.py`: Gemini Chat.
   `muse_provider.py`: Muse cũ (muse.ai). `web_images.py`: ChatGPT/Grok/Meta AI.
6. `batch-studio.js`, workflow `direct-providers.js`, photo `providers.js` và
   `gemini-chat.js`: lựa chọn trong Cài đặt có đến đúng công việc không.
7. `request_ledger.py`, `admission.py`, `storage_jobs.py`, `library*`,
   `runtime_safety.py`: request chống trùng, bảo vệ kho và file/kết quả.
8. `package5.py`, `machine_checks.py`, setup/install scripts: cài dependency,
   kiểm trạng thái, logging, giới hạn và chẩn đoán. Không chạy setup để đọc code.

## Đề bài cho bên đánh giá

- Tài khoản chọn trong Cài đặt có được ghim đúng vào job của từng nguồn không?
- Dùng riêng, chia việc, dự phòng có ý nghĩa nhất quán giữa UI và backend không?
- Đổi tài khoản, tắt tài khoản hoặc đổi kho sau khi rà/trước gửi có bị chặn đúng?
- Restart có giữ lựa chọn/phiên, xử lý job chưa rõ mà không gửi trùng không?
- Đăng nhập thành công, session_verified, configured, generation_verified có
  đang bị UI đánh đồng? Kiểm phiên có thực sự chứng minh khả năng tạo ảnh không?
- Key/cookie có bị lộ trong status/log/export, và file vault/permissions thế nào?
- Mỗi cài đặt (giọng, model theo role, chất lượng xuất, thư mục/quota, retry...)
  có consumer thực dùng hay chỉ lưu giá trị? Truy từ nút → API/prefs → consumer.
- Các giới hạn worker/tab/tài khoản/engine có khớp nhau, có gây kẹt hoặc gửi thừa?
- Đánh dấu lỗi tái hiện, rủi ro đọc code, và tính năng chưa triển khai riêng biệt.

## Chứng cứ và giới hạn

`review/EXISTING_CHECKS.json` và logs là kết quả đợt kiểm trước khi đóng gói,
KHÔNG phải toàn bộ test trong gói vừa được chạy lại. Playwright/HTTP/SQLite thật
nhưng trang/provider/runner giả. Flow account-engine test cần đúng venv engine;
không coi thiếu dependency khi chạy bằng Python khác là đã kiểm engine thật.
Các bài mới của đợt này nằm trong MONITOR_SETTINGS_CHECKS.json và monitor-settings-logs.
Kiểm local UI/SQLite thật, model discovery dùng fixture; không gen online.

CHƯA kiểm tài khoản online thật hoặc Windows. Grok/ChatGPT/Meta có adapter
trình duyệt mới, selector chưa được xác nhận trên website thật. `muse.ai` cũ và
`meta.ai` mới là hai dịch vụ khác nhau. Không hứa không giới hạn/quota miễn phí.
Batch chưa có lô riêng, Đóng & dọn lô hoặc TTL 24h; không đánh đồng với cài đặt
lưu trữ chung. Bản web không thực hiện đăng nhập/cài engine local.

Kiểm gói an toàn: `python review/verify_package.py` — chỉ đọc file/hash,
không import app, đăng nhập, cài model hay gửi AI.
'''.encode()
files['review/verify_package.py']=b'''from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'manifest.json').read_text())
for row in m['files']:
 p=root/row['path'];assert p.is_file() and p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS',len(m['files']),'files; source hashes only, no app/API/model executed')
'''
for n,b in files.items():
 if n.startswith('local_engine/')and n.endswith('.py'):ast.parse(b,filename=n)
files['manifest.json']=(json.dumps({'scope':'Settings/account/source/storage configuration source audit, not standalone app','snapshot_runtime':'storage-hub-20261027','runtime_modified':False,'online_accounts_tested':False,'models_bundled':False,'routes_count':len(routes),'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(files.items())]},ensure_ascii=False,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,b in sorted(files.items()):z.writestr(PREFIX+n,b)
with zipfile.ZipFile(OUT)as z:
 assert z.testzip()is None
 for n in files:
  if n.startswith(('local_engine/','scripts/','docs/')):assert z.read(PREFIX+n)==(ROOT/n).read_bytes()
 with tempfile.TemporaryDirectory(prefix='sf-settings-verify-')as tmp:
  z.extractall(tmp);subprocess.run(['python','review/verify_package.py'],cwd=Path(tmp)/PREFIX,check=True)
OUT.with_suffix('.zip.sha256').write_text(hashlib.sha256(OUT.read_bytes()).hexdigest()+'  '+OUT.name+'\n')
print(OUT,OUT.stat().st_size,'bytes',len(files),'files',len(routes),'routes')
