"""Home actions persist through the actual SQLite library across fresh browser profiles."""
import os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-home-local-')as tmp:
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(100):
   try:urllib.request.urlopen(base+'/local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as p:
   b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);context=b.new_context();page=context.new_page();errors=[];provider=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:provider.append(r.url)if any(x in r.url for x in ['/web-images/jobs','/flow/jobs','/gemini-chat/jobs'])else None);page.goto(base);page.wait_for_function('!!window.SceneForgeApp&&SceneForgeStorage.state.managed&&SceneForgeStorage.state.active');page.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();}''')
   rid=page.evaluate('''async()=>{const product=products.find(p=>!p.trashedAt),r={id:uid(),name:'Local export fixture',slug:'local-export',productId:product.id,stage:'editing',mode:'photos',createdAt:Date.now(),updatedAt:Date.now(),refs:structuredClone(product.refs),sceneStates:[],photoDraft:{beats:[]}};rooms.push(r);await io('rooms','readwrite',r.id,r);await io('files','readwrite',r.id+':export',new Blob(['LOCAL_EXPORT_PRESERVED'],{type:'video/mp4'}));prefs.product=product.id;await savePrefs();render();await SceneForgeStorage.flush();return r.id;}''')
   page.locator('[data-home-delete="'+rid+'"]').click();page.locator('#homeActionConfirm').click();page.wait_for_function('(id)=>!!roomFor(id).trashedAt',arg=rid);page.wait_for_function('!SceneForgeStorage.state.dirty&&!SceneForgeStorage.state.busy');snapshot=page.evaluate('SceneForgeStorage.api("snapshot")');record=next(r['value']for r in snapshot['records']if r['store']=='rooms'and r['key']==rid);assert record['trashedAt']and record['homeTrashedAt'];assert not provider
   context.close();context=b.new_context();page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);page.wait_for_function('(id)=>!!roomFor(id)?.homeTrashedAt',arg=rid);assert page.evaluate('async id=>(await io("files","readonly",id+":export")).size',rid)==22
   page.locator('#archiveProduct').click();page.locator('[data-hub-tab=trash]').click();page.locator('[data-hub-restore="room:'+rid+'"]').click();page.wait_for_function('(id)=>!roomFor(id).trashedAt',arg=rid);page.wait_for_function('!SceneForgeStorage.state.dirty&&!SceneForgeStorage.state.busy');assert page.evaluate('async id=>(await io("files","readonly",id+":export")).size',rid)==22
   # New unified page connects to the actual lifecycle plan/execute/cancel flow.
   page.evaluate('async id=>{await homeWriteRooms([id],"trash");await SceneForgeApp.storageHub.open("trash");}',rid)
   expect(page.locator('[data-hub-row="room:'+rid+'"]')).to_be_visible();page.locator('[data-hub-action="room:'+rid+'"]').click();expect(page.locator('#storageMode')).to_have_value('delete');page.locator('#storagePreview').click();expect(page.locator('#storageConfirmRead')).to_be_visible();page.locator('#storageConfirmRead').check();page.locator('#storageExecute').click();page.wait_for_function('SceneForgeStorage.state.active&&!SceneForgeStorage.state.dirty');page.wait_for_function('(id)=>!roomFor(id)',arg=rid)
   expect(page.locator('#storageHub')).to_be_visible();page.wait_for_function('hubOps.some(o=>o.mode==="delete")');op=page.evaluate('hubOps.find(o=>o.mode==="delete").op_id');expect(page.locator('[data-hub-row="operation:'+op+'"]')).to_be_visible();page.once('dialog',lambda dialog:dialog.accept());page.locator('[data-hub-restore="operation:'+op+'"]').click();page.wait_for_function('(id)=>!!roomFor(id)',arg=rid);assert page.evaluate('async id=>(await io("files","readonly",id+":export")).size',rid)==22
   assert not errors,errors;assert not provider;context.close();b.close()
  print('PASS unified storage hub: actual SQLite across fresh browser profile, soft-trash/restore, actual lifecycle delete preview/execute with 7-day quarantine, pending operation shown after reload, restore from quarantine with exported bytes intact; no provider submissions.')
 finally:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
