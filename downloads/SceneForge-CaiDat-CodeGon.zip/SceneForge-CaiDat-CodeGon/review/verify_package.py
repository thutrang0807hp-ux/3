from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'manifest.json').read_text())
for row in m['files']:
 p=root/row['path'];assert p.is_file() and p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS',len(m['files']),'files; source hashes only, no app/API/model executed')
