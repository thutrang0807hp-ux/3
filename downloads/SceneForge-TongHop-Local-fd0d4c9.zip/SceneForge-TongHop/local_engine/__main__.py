import os,threading,time,webbrowser
from urllib.request import urlopen
import uvicorn

def open_when_ready():
 for _ in range(100):
  try:
   with urlopen('http://127.0.0.1:8840/local-api/health',timeout=1) as r:
    if r.status==200:webbrowser.open('http://127.0.0.1:8840/');return
  except OSError:pass
  time.sleep(.2)

if os.environ.get('SCENEFORGE_OPEN_BROWSER')=='1':threading.Thread(target=open_when_ready,daemon=True).start()
print('SceneForge: http://127.0.0.1:8840/')
# Loopback binding is intentional; do not publish this service on a public interface.
uvicorn.run('local_engine.server:app',host='127.0.0.1',port=8840,access_log=False)
