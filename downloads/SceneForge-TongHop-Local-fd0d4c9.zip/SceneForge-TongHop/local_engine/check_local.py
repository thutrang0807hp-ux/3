"""No live providers: encryption, account policy, same-origin API and local media contract."""
import os,tempfile,sys,json,wave,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from local_engine.vault import Vault
from local_engine.policy import apply_probe,record_failure,next_account,may_submit,should_refresh
with tempfile.TemporaryDirectory(prefix='sceneforge-vault-',dir='/tmp')as temp:
 v=Vault(Path(temp)/'vault');secret={'cookies':[{'name':'session','value':'PRIVATE_SENTINEL_3f4e','domain':'.muse.ai'}]};v.set_secret('account:a',secret);assert v.secret('account:a')==secret;assert b'PRIVATE_SENTINEL' not in v.path.read_bytes();assert v.secret('other')is None
 again=Vault(Path(temp)/'vault');assert again.secret('account:a')==secret;assert os.stat(v.root/'vault.key').st_mode&0o777==0o600
 ready={'id':'a','state':'ready','credit':18,'credit_at':123,'enabled':True,'priority':1}
 assert apply_probe(ready,401)['state']=='expired'
 for status in [403,429,500,504,0]:
  result=apply_probe(ready,status);assert result['state']=='ready'and result['credit']==18 and result['credit_at']==123
 assert apply_probe(ready,200,0)['credit']==0;assert apply_probe(ready,403,verification=True)['state']=='verification'
 a=ready
 for _ in range(3):a=record_failure(a,'network',now=100)
 assert a['state']=='cooldown' and a['cooldown_until']==400
 assert next_account([ready],{'id':'old','state':'verification'},True)is None
 assert next_account([ready],{'id':'old','state':'exhausted'},False)is None
 assert next_account([ready],{'id':'old','state':'exhausted'},True)['id']=='a'
 assert should_refresh({'expires_at':1500},now=1000)and not should_refresh({'expires_at':10000},now=1000)
 assert may_submit({'state':'waiting'})and not may_submit({'state':'unknown'})and not may_submit({'state':'waiting','provider_task_id':'remote-1'})
 os.environ['SCENEFORGE_LOCAL_DATA']=str(Path(temp)/'service')
 from fastapi.testclient import TestClient
 from local_engine import server
 with TestClient(server.app)as client:
  assert client.get('/local-api/status').status_code==200
  assert client.post('/local-api/rotation',json={'service':'flow','enabled':True}).status_code==403
  headers={'X-SceneForge-Local':'1'}
  assert client.post('/local-api/rotation',headers={**headers,'Origin':'https://evil.example'},json={'service':'flow'}).status_code==403
  assert client.get('/local-api/status',headers={'Host':'evil.example'}).status_code==403
  response=client.post('/local-api/settings/secret',headers=headers,json={'name':'gemini','value':'KEY_SENTINEL_NOT_REAL'});assert response.status_code==200
  status=client.get('/local-api/status').json();assert status['gemini_configured']and not status['engines']['flow']['generation'];assert 'KEY_SENTINEL'not in json.dumps(status)
  assert client.post('/local-api/rotation',headers=headers,json={'service':'muse','enabled':False}).json()['rotation']['muse']is False
  a={'id':'test-a','name':'My account','service':'muse','state':'unverified','active':False,'enabled':True,'credit':12,'credit_at':123,'successes':0,'failures':0};server.VAULT.put('accounts',a);server.VAULT.set_secret('account:test-a',secret)
  assert client.post('/local-api/accounts/use',headers=headers,json={'id':'test-a'}).status_code==409
  assert client.post('/local-api/accounts/check',headers=headers,json={'id':'test-a'}).status_code==503
  assert client.get('/local-api/status').json()['accounts'][0]['credit']==12
  assert b'PRIVATE_SENTINEL'not in client.get('/local-api/status').content
  assert client.post('/local-api/accounts/remove',headers=headers,json={'id':'test-a'}).status_code==200
  assert not server.VAULT.secret('account:test-a')
  name=str(uuid.uuid4())+'.wav'
  with wave.open(str(server.MEDIA/name),'wb')as w:w.setparams((1,2,16000,0,'NONE','not compressed'));w.writeframes(bytes(32000))
  assert len(client.get('/local-api/media/'+name).content)>32000
  assert client.get('/local-api/media/not-a-real-file.wav').status_code==404
  assert client.get('/local-api/health').json()['paid_captcha']is False
 print('PASS: AES-GCM ciphertext/reopen/key permissions; 401/403/429 preserving prior credit; verification stops rotation; 3-error cooldown and no resubmit; loopback/Origin/custom-header guards; secret never returned; unverified account cannot be activated; real WAV transport. No provider, login or TTS model invoked.')
