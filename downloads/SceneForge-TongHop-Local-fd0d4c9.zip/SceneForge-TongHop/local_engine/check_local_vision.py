"""Ollama request contracts only: no model installed/downloaded and no live inference claimed."""
import os,tempfile,base64,io,json
from unittest.mock import patch,AsyncMock
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-vl-test-')
import httpx
from PIL import Image
from fastapi.testclient import TestClient
from local_engine import server
H={'X-SceneForge-Local':'1'}
image=Image.new('RGB',(90,160),'blue');stream=io.BytesIO();image.save(stream,format='JPEG');data='data:image/jpeg;base64,'+base64.b64encode(stream.getvalue()).decode()
def response(value):return httpx.Response(200,json=value,request=httpx.Request('GET','http://127.0.0.1:11434/api/tags'))
with TestClient(server.app)as client:
 status=client.get('/local-api/vision/status').json();assert status['model_pulled']is False
 body={'mode':'review','model':'vision:test','images':[data,data]}
 assert client.post('/local-api/vision/inspect',json=body).status_code==403
 assert client.post('/local-api/vision/inspect',json={**body,'images':['bad','bad']},headers=H).status_code==400
 assert client.post('/local-api/vision/inspect',json={**body,'mode':[]},headers=H).status_code==400
 assert client.post('/local-api/vision/inspect',json={**body,'roles':[{},'generated_frame']},headers=H).status_code==400
 output={'summary':'Cần xem lại chữ trong mẫu.','findings':[{'category':'label','message':'Chữ mờ ở khung 2.','frames':[2]}],'unverified':['Danh tính người','Nhãn qua toàn video']}
 with patch.object(httpx.AsyncClient,'get',AsyncMock(return_value=response({'models':[{'name':'vision:test','size':2000000000}]})))as get,patch.object(httpx.AsyncClient,'post',AsyncMock(side_effect=[response({'capabilities':['vision','completion']}),response({'message':{'content':json.dumps(output)}})]))as post:
  r=client.post('/local-api/vision/inspect',json=body,headers=H);assert r.status_code==200,r.text;r=r.json();assert r['result']['identity_verified']is False and r['result']['human_review_required']is True;assert post.await_count==2
  calls=[str(c.args[0])for c in post.await_args_list];assert calls==['http://127.0.0.1:11434/api/show','http://127.0.0.1:11434/api/chat'];assert post.await_args_list[-1].kwargs['json']['stream']is False
 with patch.object(httpx.AsyncClient,'get',AsyncMock(return_value=response({'models':[]}))),patch.object(httpx.AsyncClient,'post',AsyncMock())as post:
  assert client.post('/local-api/vision/inspect',json=body,headers=H).status_code==409;assert post.await_count==0
 with patch.object(httpx.AsyncClient,'get',AsyncMock(return_value=response({'models':[{'name':'vision:test','size':2000000000}]}))),patch.object(httpx.AsyncClient,'post',AsyncMock(return_value=response({'capabilities':['completion']}))):assert client.post('/local-api/vision/inspect',json=body,headers=H).status_code==409
 with patch.object(httpx.AsyncClient,'get',AsyncMock(return_value=response({'models':[{'name':'vision:test','size':2000000000}]}))),patch.object(httpx.AsyncClient,'post',AsyncMock(side_effect=[response({'capabilities':['vision']}),response({'message':{'content':'not json'}})])):assert client.post('/local-api/vision/inspect',json=body,headers=H).status_code==502
 desc={k:'Quan sát khung nguồn.'for k in ('description','person','product','outfit','background','composition','lighting','promptFrameVi','promptFrameEn')};desc.update(hasPerson=None,hasProduct=None,competitorLogo=None,visualEn={k:'Source observation.'for k in ('person','product','composition','background','lighting')},uncertainties=['Chưa chắc chủ thể.'])
 with patch.object(httpx.AsyncClient,'get',AsyncMock(return_value=response({'models':[{'name':'vision:test','size':2000000000}]}))),patch.object(httpx.AsyncClient,'post',AsyncMock(side_effect=[response({'capabilities':['vision']}),response({'message':{'content':json.dumps(desc)}})])):
  r=client.post('/local-api/vision/inspect',json={**body,'mode':'describe'},headers=H);assert r.status_code==200,r.text;assert r.json()['result']['visualEn']['person']=='Source observation.'
 with patch.object(httpx.AsyncClient,'get',AsyncMock(return_value=response({'models':[{'name':'vision:test','size':2000000000}]}))),patch.object(httpx.AsyncClient,'post',AsyncMock(return_value=response({'capabilities':['vision'],'remote_host':'https://ollama.com'})))as post:
  assert client.post('/local-api/vision/inspect',json=body,headers=H).status_code==409;assert post.await_count==1
 with patch.object(httpx.AsyncClient,'get',AsyncMock(return_value=response({'models':[{'name':'vision:test-cloud','size':2000000000}]}))),patch.object(httpx.AsyncClient,'post',AsyncMock())as post:
  assert client.post('/local-api/vision/inspect',json={**body,'model':'vision:test-cloud'},headers=H).status_code==409;assert post.await_count==0
print('PASS fixed-loopback Ollama transport contract, model must already exist and support vision, no pull/cloud fallback, image/schema/POST guards, bilingual description and explicitly unverified review. Actual vision-model quality not tested.')
