"""Recipe API contracts using mocked Gemini transport, no network/provider usage."""
import os,sys,tempfile,base64
from pathlib import Path
from unittest.mock import AsyncMock,patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
with tempfile.TemporaryDirectory(prefix='sceneforge-recipes-',dir='/tmp')as temp:
 os.environ['SCENEFORGE_LOCAL_DATA']=temp
 from fastapi.testclient import TestClient
 from local_engine import server
 recipe={'name':'Hỏi rồi giới thiệu','industry':'Chung','videoType':'Show sản phẩm','tips':'Dùng lời mới','beats':[{'name':'Hỏi','role':'question','type':'problem','start':0,'end':4,'purpose':'Gợi nhu cầu','example':'Bạn đang tìm [sản phẩm] nào?'}]}
 headers={'X-SceneForge-Local':'1'}
 with TestClient(server.app)as client:
  mock=AsyncMock(return_value=recipe)
  with patch.object(server,'gemini',mock):
   response=client.post('/local-api/ai/recipe',headers=headers,json={'lines':[{'text':'Lời nguồn đã được cung cấp.','start':0,'end':4}]});assert response.status_code==200,response.text;assert response.json()['beats'][0]['end']==4;assert mock.await_count==1
   assert client.post('/local-api/ai/recipe',headers=headers,json={'lines':[{}]}).status_code==400
   assert client.post('/local-api/ai/recipe-video',headers=headers,json={'video_data':'not base64','mime_type':'video/mp4'}).status_code==400
   data=base64.b64encode(b'\x00\x00\x00\x18ftypisom'+b'\x00'*16).decode()
   response=client.post('/local-api/ai/recipe-video',headers=headers,json={'video_data':data,'mime_type':'video/mp4','source_name':'fixture.mp4'});assert response.status_code==200
   args=mock.await_args;assert 'video_data'not in args.args[0]and args.kwargs['media']['data']==data
  for bad in [dict(recipe,beats=[dict(recipe['beats'][0],end=-1)]),dict(recipe,beats=[dict(recipe['beats'][0],role='invented')]),dict(recipe,beats=[dict(recipe['beats'][0],example='Đây là lời nguồn rất riêng không được sao chép nguyên văn.')])]:
   with patch.object(server,'gemini',AsyncMock(return_value=bad))as mock:
    r=client.post('/local-api/ai/recipe',headers=headers,json={'lines':[{'text':'Đây là lời nguồn rất riêng không được sao chép nguyên văn.'}]});assert r.status_code==502;assert mock.await_count==1
  with patch.object(server,'gemini',AsyncMock(return_value={'ids':['does-not-exist']}))as mock:
   assert client.post('/local-api/ai/recommend-recipes',headers=headers,json={'recipes':[{'id':'one'}]}).status_code==502;assert mock.await_count==1
  with patch.object(server,'gemini',AsyncMock(return_value={'ids':['one']})):
   assert client.post('/local-api/ai/recommend-recipes',headers=headers,json={'recipes':[{'id':'one'}]}).json()=={'ids':['one']}
 print('PASS: recipe text/video/recommendation routes, malformed input/time/role/ID rejection, exact-copy rejection, one provider submission only, video content excluded from text/log body. Mocked Gemini; no live API calls.')
