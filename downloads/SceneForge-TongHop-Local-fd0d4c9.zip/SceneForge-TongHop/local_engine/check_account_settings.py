import os,tempfile
os.environ['SCENEFORGE_LOCAL_DATA']=tempfile.mkdtemp(prefix='sf-acct-check-')
from fastapi.testclient import TestClient
from local_engine import server
H={'X-SceneForge-Local':'1'}
rows=[{'id':'a','service':'flow','name':'A','state':'ready','active':True,'enabled':True,'credit':50,'priority':0},{'id':'b','service':'flow','name':'B','state':'unverified','active':False,'enabled':True,'credit':None,'priority':1},{'id':'c','service':'muse','name':'C','state':'ready','active':True,'enabled':True,'credit':99,'priority':0}]
for r in rows:server.VAULT.put('accounts',r)
with TestClient(server.app)as c:
 assert c.post('/local-api/accounts/update',json={'id':'a','name':'New'}).status_code==403
 r=c.post('/local-api/accounts/update',json={'id':'a','name':'Phiên chính','note':'Dùng khi dựng','enabled':False},headers=H);assert r.status_code==200,r.text;a=r.json()['account'];assert not a['active']and a['credit']==50 and a['name']=='Phiên chính'
 assert c.post('/local-api/accounts/update',json={'id':'a','credit':99999},headers=H).status_code==400
 assert c.post('/local-api/accounts/update',json={'id':'a','enabled':'yes'},headers=H).status_code==400
 assert c.post('/local-api/accounts/update',json={'id':'b','enabled':True},headers=H).json()['account']['state']=='unverified'
 assert c.post('/local-api/accounts/use',json={'id':'b'},headers=H).status_code==409
 assert c.post('/local-api/accounts/order',json={'service':'flow','ids':['b','a']},headers=H).status_code==200
 state={a['id']:a for a in c.get('/local-api/status').json()['accounts']};assert state['b']['priority']==0 and state['a']['priority']==1 and state['c']['priority']==0
 for ids in [['a'],['a','a'],['a','c']]:assert c.post('/local-api/accounts/order',json={'service':'flow','ids':ids},headers=H).status_code in (400,409)
 for r in [{'id':'f','service':'flow','at':0},{'id':'m','service':'muse','at':0},{'id':'g','kind':'Gemini','at':0}]:server.VAULT.put('logs',r)
 assert c.post('/local-api/logs/clear-service',json={'service':'flow'},headers=H).json()['deleted']==1
 assert {r['id']for r in server.VAULT.rows('logs')}=={'m','g'}
print('PASS validated account metadata/order, disabling does not rotate, enabling never verifies, cross-service priorities intact, credit/state cannot be forged, service-only log clear and POST guards. No provider calls.')
