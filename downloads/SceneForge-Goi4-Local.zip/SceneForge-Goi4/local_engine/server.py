"""Loopback-only companion: encrypted accounts, manual login, local TTS and optional Gemini.
Provider engine generation remains disabled until audited adapters are connected.
"""
from pathlib import Path
import asyncio,importlib.util,json,os,secrets,time,uuid,wave
from urllib.parse import urlparse
from contextlib import asynccontextmanager
import httpx
from fastapi import FastAPI,HTTPException,Request
from fastapi.responses import FileResponse,JSONResponse
from fastapi.staticfiles import StaticFiles
from .vault import Vault
from .policy import apply_probe
ROOT=Path(__file__).resolve().parents[1]
DATA=Path(os.environ.get('SCENEFORGE_LOCAL_DATA',str(Path.home()/'.sceneforge-local')))
VAULT=Vault(DATA);MEDIA=DATA/'media';MEDIA.mkdir(exist_ok=True);LOGINS={};tts_lock=asyncio.Lock();tts_model=None

def account(id):
 row=next((a for a in VAULT.rows('accounts') if a['id']==id),None)
 if not row:raise HTTPException(404,'Không có tài khoản.')
 return row

def log(kind,state,body,started,cost=None):
 row={'id':str(uuid.uuid4()),'kind':kind,'state':state,'prompt_excerpt':str(body.get('idea','') or ' '.join(b.get('text','') for b in body.get('beats',[])))[:100],'room_id':body.get('room_id'),'product_id':body.get('product_id'),'duration':round(time.monotonic()-started,3),'cost':cost,'at':time.time()};VAULT.put('logs',row);return row

@asynccontextmanager
async def lifespan(app):
 for a in VAULT.rows('accounts'):
  if a['state'] in {'active','awaiting_login'}:a['state']='unverified';a['active']=False;VAULT.put('accounts',a)
 yield
 for login in LOGINS.values():
  await login['browser'].close();await login['playwright'].stop()

app=FastAPI(lifespan=lifespan,docs_url=None,redoc_url=None)
@app.middleware('http')
async def local_only(request:Request,call_next):
 host=request.headers.get('host','').split(':')[0]
 if host not in {'localhost','127.0.0.1','testserver'}:return JSONResponse({'detail':'Chỉ truy cập qua 127.0.0.1.'},403)
 if request.url.path.startswith('/local-api/'):
  origin=request.headers.get('origin');expected=request.headers.get('host')
  if origin and urlparse(origin).netloc!=expected:return JSONResponse({'detail':'Origin không được phép.'},403)
  if request.method!='GET' and request.headers.get('x-sceneforge-local')!='1':return JSONResponse({'detail':'Thiếu yêu cầu cùng ứng dụng.'},403)
 return await call_next(request)

@app.get('/local-api/status')
async def status():
 return {'connected':True,'accounts':sorted(VAULT.rows('accounts'),key=lambda a:a.get('priority',0)),'logs':sorted(VAULT.rows('logs'),key=lambda l:l['at'],reverse=True)[:20],'rotation':VAULT.secret('rotation')or{'flow':False,'muse':False},'tts':{'installed':importlib.util.find_spec('vieneu') is not None},'gemini_configured':bool(VAULT.secret('gemini')),'active':{s:next((a for a in VAULT.rows('accounts')if a['service']==s and a.get('active')),None)for s in ['flow','muse']},'engines':{'flow':{'generation':False,'reason':'Chưa nối bản flow2api đã sửa và kiểm chứng.'},'muse':{'generation':False,'reason':'Chưa nối bản muse2api đã sửa và kiểm chứng.'}}}

@app.get('/local-api/logs')
async def logs():return sorted(VAULT.rows('logs'),key=lambda l:l['at'],reverse=True)
@app.post('/local-api/logs/clear')
async def clear_logs():
 for l in VAULT.rows('logs'):VAULT.delete('logs',l['id'])
 return {'ok':True}
@app.post('/local-api/settings/secret')
async def save_secret(body:dict):
 if body.get('name')!='gemini' or not isinstance(body.get('value'),str) or not 10<len(body['value'])<500:raise HTTPException(400,'Key không hợp lệ.')
 VAULT.set_secret('gemini',body['value']);return {'saved':True}
@app.post('/local-api/rotation')
async def rotation(body:dict):
 if body.get('service')not in {'flow','muse'}:raise HTTPException(400,'Dịch vụ không hợp lệ.')
 state=VAULT.secret('rotation')or{'flow':False,'muse':False};state[body['service']]=bool(body.get('enabled'));VAULT.set_secret('rotation',state);return {'rotation':state}
@app.post('/local-api/accounts/connect')
async def connect_account(body:dict):
 service=body.get('service')
 if service not in {'flow','muse'}:raise HTTPException(400,'Dịch vụ không hợp lệ.')
 from playwright.async_api import async_playwright
 pw=await async_playwright().start()
 try:
  executable=os.environ.get('SCENEFORGE_BROWSER')
  browser=await pw.chromium.launch(headless=False,**({'executable_path':executable} if executable else {}))
  context=await browser.new_context();page=await context.new_page();await page.goto('https://flow.google.com/'if service=='flow'else'https://muse.ai/',wait_until='domcontentloaded',timeout=45000)
 except Exception:
  await pw.stop();raise HTTPException(503,'Chưa mở được trình duyệt có cửa sổ. Cài Chromium bằng python -m playwright install chromium trên máy của bạn.')
 id=str(uuid.uuid4());a={'id':id,'service':service,'name':('Flow'if service=='flow'else'Muse')+' '+str(1+len([a for a in VAULT.rows('accounts')if a['service']==service])),'state':'awaiting_login','enabled':True,'active':False,'priority':len(VAULT.rows('accounts')),'credit':None,'credit_at':None,'successes':0,'failures':0,'created_at':time.time()};VAULT.put('accounts',a);LOGINS[id]={'browser':browser,'context':context,'playwright':pw}
 return {'id':id,'message':'Tự đăng nhập và xác minh trong cửa sổ vừa mở, rồi bấm “Lưu phiên đăng nhập”. App không đọc mật khẩu.'}
@app.post('/local-api/accounts/save-login')
async def save_login(body:dict):
 a=account(body.get('id'));login=LOGINS.get(a['id'])
 if not login:raise HTTPException(409,'Không còn cửa sổ đăng nhập. Kết nối lại.')
 suffix='google.com'if a['service']=='flow'else'muse.ai';cookies=[c for c in await login['context'].cookies()if c['domain'].lstrip('.')==suffix or c['domain'].lstrip('.').endswith('.'+suffix)]
 if not cookies:raise HTTPException(400,'Chưa có cookie của đúng dịch vụ. Hoàn tất đăng nhập trước.')
 VAULT.set_secret('account:'+a['id'],{'cookies':cookies});exp=[c['expires']for c in cookies if c.get('expires',-1)>0];a.update(state='unverified',cookie_expires_at=min(exp)if exp else None,expires_at=None);VAULT.put('accounts',a);await login['browser'].close();await login['playwright'].stop();del LOGINS[a['id']];return {'saved':True,'message':'Phiên đã mã hóa. Chưa xác minh quota hoặc khả năng tạo.'}
@app.post('/local-api/accounts/use')
async def use_account(body:dict):
 a=account(body.get('id'))
 if not a.get('enabled')or a['state']not in {'ready','active'}:raise HTTPException(409,'Phiên chưa được kiểm chứng với động cơ. Không đổi sang tài khoản này để tạo.')
 for row in VAULT.rows('accounts'):
  if row['service']==a['service']:row['active']=row['id']==a['id'];VAULT.put('accounts',row)
 return {'ok':True}
@app.post('/local-api/accounts/check')
async def check_account(body:dict):
 a=account(body.get('id'));a['checked_at']=time.time();a['check_note']='Chưa có adapter kiểm chứng phiên/credit. Giữ số cũ, không suy 403 là hết hạn.';VAULT.put('accounts',a)
 raise HTTPException(503,'Đã giữ nguyên trạng thái và số dư cũ. Chưa nối adapter Flow/Muse để kiểm tra phiên thật.')
@app.post('/local-api/accounts/remove')
async def remove_account(body:dict):
 a=account(body.get('id'));login=LOGINS.pop(a['id'],None)
 if login:await login['browser'].close();await login['playwright'].stop()
 VAULT.delete_secret('account:'+a['id']);VAULT.delete('accounts',a['id']);return {'ok':True}

async def gemini(body,instruction):
 key=VAULT.secret('gemini')
 if not key:raise HTTPException(409,'Chưa có Gemini key được lưu trên máy.')
 model=os.environ.get('SCENEFORGE_GEMINI_MODEL','gemini-2.5-flash');started=time.monotonic()
 async with httpx.AsyncClient(timeout=90)as client:
  # One submission only. Network failures are not retried as another billable request.
  try:r=await client.post('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',headers={'x-goog-api-key':key},json={'contents':[{'parts':[{'text':instruction+'\n'+json.dumps(body,ensure_ascii=False)}]}],'generationConfig':{'responseMimeType':'application/json'}})
  except httpx.HTTPError:log('Gemini','unknown',body,started);raise HTTPException(502,'Mất kết nối. Không tự gửi lại yêu cầu AI.')
  if r.status_code!=200:log('Gemini','failed',body,started);raise HTTPException(r.status_code,'Gemini từ chối hoặc hết hạn mức. Không tự gọi lại.')
 data=r.json()
 try:out=json.loads(data['candidates'][0]['content']['parts'][0]['text'])
 except (KeyError,IndexError,ValueError):raise HTTPException(502,'Kết quả AI không có JSON hợp lệ.')
 row=log('Gemini','done',body,started);row['usage']=data.get('usageMetadata');row['cost_note']='Chưa có bảng giá được xác minh; không quy đổi ra tiền.';VAULT.put('logs',row);return out
@app.post('/local-api/ai/script')
async def script(body:dict):
 if not isinstance(body.get('beats'),list)or not 0<len(body['beats'])<=60:raise HTTPException(400,'Nhịp không hợp lệ.')
 return await gemini(body,'Write Vietnamese narration only from supplied facts, no unsupported efficacy/claims. Return JSON {"beats":[{"text":"..."}]} with exactly one entry for each input beat, same order. Do not add video generation requests.')
@app.post('/local-api/ai/director')
async def director(body:dict):return await gemini(body,'Choose a useful clip preference order from supplied clip metadata. Read only text, no video. Return {"order":[clip ids]} containing only actual input clip ids, no duplicates. Missing shot types must not trigger generation.')
@app.post('/local-api/tts')
async def tts(body:dict):
 if importlib.util.find_spec('vieneu')is None:raise HTTPException(409,'Chưa cài VieNeu-TTS. Đọc README để cài trên máy.')
 beats=body.get('beats',[])
 if not isinstance(beats,list)or not 0<len(beats)<=60 or sum(len(str(b.get('text','')))for b in beats)>15000:raise HTTPException(400,'Lời quá dài hoặc nhịp không hợp lệ.')
 if not any(str(b.get('text','')).strip()for b in beats):raise HTTPException(400,'Chưa có lời đọc.')
 started=time.monotonic()
 async with tts_lock:
  try:result=await asyncio.to_thread(synthesize,beats,body.get('voice'))
  except Exception:raise HTTPException(503,'Không tạo được giọng VieNeu. Kiểm tra mô hình, SDK và bộ nhớ máy; không dùng V4 trả phí thay thế.')
 row=log('VieNeu v3','done',body,started,cost=0);row['cost_unit']='VND';VAULT.put('logs',row)
 return result

def synthesize(beats,voice):
 global tts_model
 from vieneu import Vieneu
 if tts_model is None:tts_model=Vieneu(backend='onnx')
 parts=[];segments=[];cursor=0;params=None
 for beat in beats:
  text=str(beat.get('text','')).strip()
  if not text:raise ValueError('Nhịp chưa có lời.')
  tmp=MEDIA/(str(uuid.uuid4())+'.wav');audio=tts_model.infer(text,**({'voice':voice}if voice else {}));tts_model.save(audio,str(tmp))
  with wave.open(str(tmp),'rb')as w:
   p=(w.getnchannels(),w.getsampwidth(),w.getframerate());frames=w.readframes(w.getnframes());duration=w.getnframes()/w.getframerate()
  tmp.unlink(missing_ok=True)
  if params and params!=p:raise ValueError('Định dạng các nhịp khác nhau.')
  params=p;parts.append(frames);segments.append({'id':beat['id'],'start':cursor,'end':cursor+duration});cursor+=duration
 filename=str(uuid.uuid4())+'.wav'
 with wave.open(str(MEDIA/filename),'wb')as out:out.setparams((*params,0,'NONE','not compressed'));out.writeframes(b''.join(parts))
 return {'url':'/local-api/media/'+filename,'segments':segments,'duration':cursor,'cost':0,'cost_note':'Tạo cục bộ, không dùng dịch vụ tính phí.'}
@app.get('/local-api/media/{filename}')
async def media(filename:str):
 if not filename.endswith('.wav')or any(c not in '0123456789abcdef-.wav'for c in filename)or not(MEDIA/filename).is_file():raise HTTPException(404,'Không có tệp.')
 return FileResponse(MEDIA/filename,media_type='audio/wav')
@app.get('/local-api/health')
async def health():return {'service':'sceneforge-local','version':4,'loopback_only':True,'paid_captcha':False}

frontend=ROOT/'dist/web-demo'
if frontend.is_dir():app.mount('/',StaticFiles(directory=frontend,html=True),name='frontend')
