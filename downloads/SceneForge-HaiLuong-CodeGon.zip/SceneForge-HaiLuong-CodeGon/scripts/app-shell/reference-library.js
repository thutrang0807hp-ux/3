// Direct image entry into the product library; existing room snapshots are untouched.
const referenceGroups={person:'Người',outfit:'Trang phục',product:'Sản phẩm',background:'Bối cảnh'};
const referenceUploads=new Set();
function renderReferenceLibrary(product){
 const busy=[...referenceUploads].some(token=>token.startsWith(product.id+':'));
 stableHTML($('#productContent'),'<header class="sectionHeading"><div><h2>Bộ ảnh · '+esc(product.name)+'</h2><p>Thêm ảnh của bạn vào từng nhóm. Phòng mới lấy bản sao riêng; phòng đã có được giữ nguyên.</p></div><button id="editReferences" '+(busy?'disabled':'')+'>Chỉnh bộ ảnh</button></header><div class="referenceGrid directReferences">'+Object.entries(referenceGroups).map(([key,label])=>{const images=product.refs?.[key]?.images||[],busy=referenceUploads.has(product.id+':'+key);return '<article id="referenceGroup-'+key+'"><header><h3>'+label+'</h3><small>'+images.length+' ảnh</small></header><div class="referenceImages">'+images.map(im=>'<button class="referencePreview" data-reference-preview="'+esc(im.id)+'" data-reference-group="'+key+'" title="Xem '+esc(im.name||label)+'"><img src="'+esc(im.image)+'" alt="'+esc(im.name||label)+'" width="84" height="100"></button>').join('')+'</div><button class="referenceAdd" data-reference-add="'+key+'" '+(busy?'disabled':'')+'>'+(busy?'Đang lưu ảnh…':'＋ Thêm ảnh')+'</button><input type="file" id="referenceFile-'+key+'" data-reference-file="'+key+'" data-reference-product="'+product.id+'" accept="image/*" multiple hidden><p>'+esc(product.refs?.[key]?.description||'Chưa có mô tả')+'</p></article>';}).join('')+'</div>');
 $('#editReferences').onclick=()=>productDialog(productFor(product.id));
}
$('#productContent').addEventListener('click',e=>{
 const add=e.target.closest('[data-reference-add]');if(add){$('#referenceFile-'+add.dataset.referenceAdd)?.click();return;}
 const preview=e.target.closest('[data-reference-preview]');if(!preview)return;const product=productFor(prefs.product),image=product?.refs?.[preview.dataset.referenceGroup]?.images?.find(im=>im.id===preview.dataset.referencePreview);if(image)modal(image.name||referenceGroups[preview.dataset.referenceGroup],'<img class="referenceFullPreview" src="'+esc(image.image)+'" alt="'+esc(image.name||'Ảnh tham chiếu')+'">');
});
$('#productContent').addEventListener('change',async e=>{
 const input=e.target.closest('[data-reference-file]');if(!input)return;const files=[...input.files],key=input.dataset.referenceFile,id=input.dataset.referenceProduct,token=id+':'+key;input.value='';if(!files.length||referenceUploads.has(token))return;
 referenceUploads.add(token);if(prefs.product===id&&productTab==='references')renderReferenceLibrary(productFor(id));
 let count=0;const rejected=[];
 try{
  const added=[];for(const file of files){if(!file.type.startsWith('image/')||file.size>15*1024*1024){rejected.push(file.name+': cần ảnh dưới 15 MB');continue;}try{added.push({id:uid(),name:file.name,image:await imageData(file)});}catch{rejected.push(file.name+': không đọc được ảnh');}}
  if(added.length){let saved;await new Promise((resolve,reject)=>{const tx=db.transaction('products','readwrite'),store=tx.objectStore('products'),request=store.get(id);request.onsuccess=()=>{const product=request.result;if(!product||product.trashedAt){tx.abort();return;}product.refs??={};product.refs[key]??={images:[],description:''};product.refs[key].images??=[];product.refs[key].images.push(...added);product.updatedAt=Date.now();saved=product;store.put(product,id);};tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||Error('Chưa lưu được ảnh.'));tx.onabort=()=>reject(tx.error||Error('Sản phẩm không còn khả dụng.'));});const current=productFor(id);if(current)Object.assign(current,saved);count=added.length;}
 }catch(error){rejected.push(error.message);}
 finally{referenceUploads.delete(token);render();toast((count?'Đã thêm '+count+' ảnh vào '+referenceGroups[key]+'. ':'')+(rejected.length?rejected.join(' · '):''));}
});
