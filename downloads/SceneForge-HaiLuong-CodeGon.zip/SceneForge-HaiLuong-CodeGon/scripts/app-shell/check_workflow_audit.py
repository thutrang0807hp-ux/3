"""Actual shell: no hidden recipe generation, shared library and failed room save."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[2]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass

def main():
 server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
 try:
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();calls=[];errors=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   def route(r):
    calls.append(r.request.url);r.fulfill(json={'ai_configured':True,'gemini_configured':True,'ai_source':'gemini_api'})
   page.route('**/local-api/**',route)
   page.goto(f'http://127.0.0.1:{server.server_port}/?demo=1');page.wait_for_function('!!db&&rooms.length>0')
   result=page.evaluate('''async()=>{
    const settle=async()=>{for(let n=0;n<100&&recipeWork.has('audit-recipe');n++)await new Promise(r=>setTimeout(r,10));if(recipeWork.has('audit-recipe'))throw Error('Recipe sync did not settle');};
    const r={id:'audit-recipe',name:'Nguồn kiểm thử',mode:'reference',productId:products[0].id};rooms.push(r);await persistRoom(r);
    const w={id:r.id,analysis:{status:'done'},scenes:[{start:0,end:4}],script:[{original:'Private original transcript'}]};
    await writeForeign('projects','sceneforge-workflows',r.id,w);
    await Promise.all([extractReferenceRecipe(r.id),extractReferenceRecipe(r.id)]);await extractReferenceRecipe(r.id);await settle();
    const lib=await recipeLibrary(),id='source:'+r.id,local=structuredClone(lib.items.find(x=>x.id===id));
    w.analysis.semantic={provider:'gemini',recipe:{...structuredClone(SFRecipes.starters[0]),name:'Khung có sẵn trong phân tích'}};
    await writeForeign('projects','sceneforge-workflows',r.id,w);await extractReferenceRecipe(r.id);await settle();
    const richer=lib.items.find(x=>x.id===id).name;
    lib.items.find(x=>x.id===id).userEdited=true;lib.items.find(x=>x.id===id).name='User edit';w.scenes[0].end=5;
    await writeForeign('projects','sceneforge-workflows',r.id,w);await extractReferenceRecipe(r.id);await settle();
    const preserved=lib.items.find(x=>x.id===id).name;
    const oldPersist=persistRoom,before=rooms.length;persistRoom=async()=>{throw Error('fixture disk full');};
    try{await createWorkflowRoom('photos',products[0]);throw Error('save should fail');}catch(e){if(e.message!=='fixture disk full')throw e;}finally{persistRoom=oldPersist;}
    return {local,richer,preserved,noOrphan:before===rooms.length,library:JSON.stringify(lib)};
   }''')
   assert result['local']['beats'][0]['example']=='' and 'Private original transcript'not in result['library']
   assert result['richer']=='Khung có sẵn trong phân tích' and result['preserved']=='User edit' and result['noOrphan'],result
   assert not any('/ai/'in u or '/jobs'in u for u in calls),calls
   assert not errors,errors
   browser.close()
  print('PASS shell: one local recipe definition; existing lowercase Gemini recipe reused after local cut-only version; no cloud extraction/API gate; user edits retained; failed room save leaves no phantom room. Chromium/IndexedDB, provider network intercepted.')
 finally:server.shutdown()
if __name__=='__main__':main()
