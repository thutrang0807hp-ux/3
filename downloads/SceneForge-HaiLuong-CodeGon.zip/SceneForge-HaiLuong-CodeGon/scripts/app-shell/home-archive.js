// Preserve live cards, decoded images, focus and scroll instead of rebuilding the desk.
function stableHTML(parent,html){
 const t=document.createElement('template');t.innerHTML=html;
 const key=n=>n.nodeType===1?['id','data-room','data-stage','data-product','data-batch','data-archive-row'].map(a=>n.hasAttribute(a)?a+':'+n.getAttribute(a):'').find(Boolean)||'':'';
 function patch(host,fresh){
  const old=[...host.childNodes],keys=new Map(old.filter(n=>key(n)).map(n=>[key(n),n]));let cursor=host.firstChild;
  for(const next of [...fresh.childNodes]){
   const k=key(next);let node=k?keys.get(k):cursor&&!key(cursor)&&cursor.nodeType===next.nodeType&&cursor.nodeName===next.nodeName?cursor:null;
   if(!node||node.nodeName!==next.nodeName){node=next.cloneNode(true);host.insertBefore(node,cursor);}
   else{
    if(node!==cursor)host.insertBefore(node,cursor);
    if(node.nodeType===3){if(node.nodeValue!==next.nodeValue)node.nodeValue=next.nodeValue;}
    else if(node.nodeType===1&&!node.querySelector('.g6InlineRename:not([data-finished])')){
     for(const attr of [...node.attributes])if(!next.hasAttribute(attr.name))node.removeAttribute(attr.name);
     for(const attr of [...next.attributes])if(node.getAttribute(attr.name)!==attr.value)node.setAttribute(attr.name,attr.value);
     patch(node,next);
    }
   }
   cursor=node.nextSibling;
  }
  while(cursor){const remove=cursor;cursor=cursor.nextSibling;remove.remove();}
 }
 patch(parent,t.content);
}
function homeBoardMarkup(list){return g4Columns.map(([key,label,color])=>{
 const row=list.filter(r=>roomColumn(r)===key).sort((a,b)=>(!!b.error-!!a.error)||(key==='attention'?(b.pendingFrames||0)-(a.pendingFrames||0):0)||(a.demo&&b.demo?(a.demoOrder??0)-(b.demoOrder??0):0)||(key==='exported'?(b.exportedAt||0)-(a.exportedAt||0):a.createdAt-b.createdAt));
 const groups=new Map();if(key==='preparing')for(const r of row.filter(r=>r.batchId)){if(!groups.has(r.batchId))groups.set(r.batchId,[]);groups.get(r.batchId).push(r);}
 let batches='',grouped=new Set();for(const[id,batch]of groups){const total=rooms.filter(r=>r.batchId===id&&!r.trashedAt&&(prefs.product==='all'||r.productId===prefs.product)).length;if(total<2)continue;batches+='<section class="g6Batch" data-batch="'+esc(id)+'"><header>▣ '+total+' video vừa thả<small>Tối đa 2 phân tích cùng lúc</small></header>'+batch.map(r=>{grouped.add(r.id);return card(r,true);}).join('')+'</section>';}
 const large=list.length>12||row.length>3?(key==='exported'?2:1):row.length;
 return '<section class="stageColumn" data-stage="'+key+'"><header class="stageHeading"><b>'+row.length+'</b><i class="statusDot" style="background:'+color+'"></i>'+label+'</header><div class="columnCards">'+(row.length?batches+row.filter(r=>!grouped.has(r.id)).map((r,i)=>card(r,i>=large)).join(''):'<div class="emptyColumn">Chưa có video</div>')+'</div></section>';
}).join('');}
// A restored export must not immediately disappear again due to the old 7-day rule.
archivedRoom=r=>!!(r.archived||r.exportedAt&&Date.now()-r.exportedAt>7*86400000&&!(r.archiveRestoredAt>=r.exportedAt));
visibleRooms=function(){const archive=prefs.product==='archive';return rooms.filter(r=>!r.trashedAt&&!productFor(r.productId)?.trashedAt&&(archive?(archivedRoom(r)||productFor(r.productId)?.archived):(!archivedRoom(r)&&!productFor(r.productId)?.archived&&(prefs.product==='all'||r.productId===prefs.product)))&&r.name.toLocaleLowerCase('vi').includes(search));};
renderProducts=function(){
 const active=rooms.filter(r=>!r.trashedAt&&!archivedRoom(r)&&!productFor(r.productId)?.archived&&!productFor(r.productId)?.trashedAt),attention=attentionCount(active);
 stableHTML($('#productList'),'<button class="productRow '+(prefs.product==='all'?'active':'')+'" data-product="all"><span class="productName"><b>Tất cả</b><span class="'+(attention?'attentionBadge':'')+'">'+(attention?'● '+attention+' cần bạn':active.length)+'</span></span></button>'+products.filter(p=>!p.archived&&!p.trashedAt).map(p=>{
 const row=active.filter(r=>r.productId===p.id),n=attentionCount(row),errors=row.filter(r=>r.error).length;
 return '<button class="productRow g6ProductRow '+(prefs.product===p.id?'active':'')+'" data-product="'+p.id+'" title="'+esc(p.name)+'"><span class="g6ProductGrip" draggable="true" data-g6-drag-product="'+p.id+'" title="Kéo đổi thứ tự">⋮⋮</span><span class="productName"><i class="productDot" style="background:'+p.color+'"></i><b data-g6-rename="'+p.id+'">'+esc(p.name)+'</b><span class="'+(errors?'errorBadge':n?'attentionBadge':'')+'">'+(errors?'● '+errors+' lỗi':n?'● '+n:row.length)+'</span></span><span role="button" tabindex="0" class="g6ProductMore" data-g6-product-menu="'+p.id+'" aria-label="Tùy chỉnh '+esc(p.name)+'">⋯</span></button>';
 }).join(''));
 $('#archiveCount').textContent=archiveRooms().length;$('#archiveProduct').classList.toggle('active',prefs.product==='archive');
};
function archiveRooms(){return rooms.filter(r=>!r.trashedAt&&!productFor(r.productId)?.trashedAt&&(archivedRoom(r)||productFor(r.productId)?.archived));}
const archiveIcon=k=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+({box:'<path d="M4 8h16v13H4zM3 3h18v5H3zM9 12h6"/>',restore:'<path d="M4 10a8 8 0 1 1 0 6M4 4v6h6"/>',shield:'<path d="m12 3 8 3v6c0 4-4 7-8 9-4-2-8-5-8-9V6zM8 12l3 3 5-6"/>',clean:'<path d="m14 3-4 10M7 11l8 3-3 7H2l3-9zM6 17l-1 4m4-3-1 3M18 3v4m-2-2h4"/>',back:'<path d="M9 6 3 12l6 6M3 12h17"/>',search:deskIcon.reference}[k]||deskIcon[k])+'</svg>';
const archivePane=document.createElement('section');archivePane.id='archiveView';archivePane.hidden=true;archivePane.innerHTML='<div class="archiveSummary"><div><b id="archiveTotal">0</b><span>video lưu trữ</span></div><div><b id="archiveSize">—</b><span>tệp trong app</span></div><div class="archivePreserve">'+archiveIcon('shield')+'Giữ nguyên tư liệu và bản dựng</div></div><div class="archiveToolbar"><label class="search">'+$('#searchRooms').parentElement.querySelector('svg').outerHTML+'<input id="archiveSearch" placeholder="Tìm video đã lưu trữ…" aria-label="Tìm video đã lưu trữ"></label><select id="archiveFilter" aria-label="Sản phẩm trong lưu trữ"><option value="all">Tất cả sản phẩm</option></select><select id="archiveSort" aria-label="Sắp xếp lưu trữ"><option value="newest">Lưu trữ gần nhất</option><option value="oldest">Lưu trữ lâu nhất</option><option value="size">Dung lượng lớn nhất</option></select><button id="archiveRefresh" title="Đo lại dung lượng tệp trong app">Đo lại</button><span id="archiveShown"></span></div><div id="archiveRows"></div><div class="archiveFootnote">Khôi phục về đúng sản phẩm ban đầu. Dung lượng không tính thư mục máy và bộ dùng chung.</div><section class="archiveCleanup"><div class="archiveCleanupIcon">'+archiveIcon('clean')+'</div><div><b>Dọn tệp tạm</b><p>Chỉ dọn bộ nhớ đệm được đánh dấu. Giữ video mẫu, clip, ảnh và bản dựng.</p></div><button id="archiveClean" disabled>Đang kiểm tra…</button></section>';
$('.desk').append(archivePane);
const archiveBack=document.createElement('button');archiveBack.id='archiveBack';archiveBack.innerHTML=archiveIcon('back')+'Về sản phẩm';archiveBack.hidden=true;$('.deskActions').append(archiveBack);
const archiveProducts=document.createElement('button');archiveProducts.id='archiveProducts';archiveProducts.textContent='Sản phẩm lưu trữ & Thùng rác';archiveProducts.hidden=true;$('.deskActions').append(archiveProducts);archiveProducts.onclick=g6Trash;
let archiveReturnProduct='all',archiveQuery='',archiveFilter='all',archiveSort='newest',archiveSignature=null,archiveMeasureRun=0,archiveTemporary=[],deskLastKey='',deskPositions=new Map();
const archiveBytes=new Map();
const archiveDate=r=>r.archivedAt||r.updatedAt||r.exportedAt||r.createdAt;
const archiveFormat=n=>n>=1e9?(n/1e9).toLocaleString('vi-VN',{maximumFractionDigits:2})+' GB':n>=1e6?(n/1e6).toLocaleString('vi-VN',{maximumFractionDigits:1})+' MB':n>=1000?(n/1000).toLocaleString('vi-VN',{maximumFractionDigits:1})+' KB':n+' B';
function archivePaintRows(){
 const all=archiveRooms(),q=archiveQuery.toLocaleLowerCase('vi').trim(),list=all.filter(r=>(archiveFilter==='all'||r.productId===archiveFilter)&&(!q||(r.name+' '+(productFor(r.productId)?.name||'')).toLocaleLowerCase('vi').includes(q))).sort((a,b)=>archiveSort==='size'?(archiveBytes.get(b.id)||0)-(archiveBytes.get(a.id)||0):archiveSort==='oldest'?archiveDate(a)-archiveDate(b):archiveDate(b)-archiveDate(a));
 $('#archiveTotal').textContent=all.length;$('#archiveShown').textContent=list.length===all.length?list.length+' video':list.length+' / '+all.length+' video';
 const measured=all.every(r=>archiveBytes.has(r.id));$('#archiveSize').textContent=measured?archiveFormat(all.reduce((n,r)=>n+archiveBytes.get(r.id),0)):'Đang đo…';
 stableHTML($('#archiveRows'),list.length?'<div class="archiveList"><div class="archiveListHeader"><span>VIDEO</span><span>SẢN PHẨM</span><span>ĐÃ LƯU TRỮ</span><span>TỆP TRONG APP</span><span>THAO TÁC</span></div>'+list.map(r=>'<article class="archiveRow" data-archive-row="'+r.id+'"><div class="archiveIdentity">'+(r.poster?'<img src="'+esc(r.poster)+'" alt="" width="49" height="73">':'<div class="archivePoster">'+archiveIcon('box')+'</div>')+'<div><b>'+esc(r.name)+'</b><small>'+deskSvg(r.mode==='photos'?'photos':'reference')+(r.mode==='photos'?'Từ ảnh':'Video mẫu')+'</small>'+(typeof archivePolicyDescription==='function'?'<small class="archiveLifecycleStatus">'+esc(archivePolicyDescription(r))+'</small>':'')+'</div></div><div class="archiveProductPill">'+esc(productFor(r.productId)?.name||'Sản phẩm chưa xác định')+'</div><div class="archiveDate">'+(archiveDate(r)?new Date(archiveDate(r)).toLocaleDateString('vi-VN'):'—')+'</div><div class="archiveRowSize">'+(archiveBytes.has(r.id)?archiveFormat(archiveBytes.get(r.id)):'Đang đo…')+'</div><div class="archiveRowActions">'+(typeof archiveLifecycleActions==='function'?archiveLifecycleActions(r):'')+'<button data-archive-restore="'+r.id+'">'+archiveIcon('restore')+'Khôi phục</button><button data-archive-delete="'+r.id+'" aria-label="Xóa vĩnh viễn '+esc(r.name)+'">Xóa</button></div></article>').join('')+'</div>':'<div class="archiveEmpty"><div>'+archiveIcon('box')+'</div><h2>'+(all.length?'Không tìm thấy video':'Lưu trữ đang trống')+'</h2><p>'+(all.length?'Thử tên khác hoặc bỏ bộ lọc để xem video đã lưu trữ.':'Khi lưu trữ video trong trang sản phẩm, video sẽ xuất hiện ở đây để khôi phục hoặc dọn sau.')+'</p><button data-archive-empty="'+(all.length?'filters':'back')+'">'+(all.length?'Bỏ bộ lọc':'Về trang sản phẩm')+'</button></div>');
}
async function archiveMeasure(force=false){
 const all=archiveRooms(),signature=all.map(r=>r.id+':'+r.updatedAt+':'+r.workflowSavedAt).join('|');if(!force&&signature===archiveSignature)return;archiveSignature=signature;const run=++archiveMeasureRun;
 try{
  const files=await new Promise((resolve,reject)=>{const data=[];const tx=db.transaction('files');const request=tx.objectStore('files').openCursor();request.onsuccess=()=>{const c=request.result;if(c){data.push({key:String(c.key),size:c.value?.size||0});c.continue();}};tx.oncomplete=()=>resolve(data);tx.onerror=()=>reject(tx.error);});
  archiveTemporary=files.filter(f=>f.key.startsWith('cache:preview:')||f.key.startsWith('cache:thumbnail:'));
  for(const r of all){const [workflow,editor]=await Promise.all([workflowRecord(r.id),readEditorDraft(r.id)]);if(run!==archiveMeasureRun)return;archiveBytes.set(r.id,files.filter(f=>f.key.startsWith(r.id+':')).reduce((n,f)=>n+f.size,0)+(workflow?.assetEntries||[]).reduce((n,[,blob])=>n+(blob?.size||0),0)+(editor?.media||[]).reduce((n,m)=>n+(m.file?.size||0),0));}
  if(run!==archiveMeasureRun||prefs.product!=='archive')return;
  const bytes=archiveTemporary.reduce((n,f)=>n+f.size,0);$('#archiveClean').disabled=!bytes;$('#archiveClean').textContent=bytes?'Dọn tệp tạm · '+archiveFormat(bytes):'Chưa có tệp tạm';archivePaintRows();
 }catch(e){if(prefs.product==='archive'){$('#archiveSize').textContent='Chưa đo được';$('#archiveClean').textContent='Chưa kiểm tra được';$('#archiveClean').disabled=true;toast('Chưa đo được dung lượng: '+e.message);}}
}
function archiveRender(){
 $('#deskTitle').textContent='Lưu trữ';$('.deskHeader small').textContent='Thư viện';$('#deskSummary').textContent='Quản lý thành phẩm, tư liệu và lịch thu gọn.';
 const selected=$('#archiveFilter').value;stableHTML($('#archiveFilter'),'<option value="all">Tất cả sản phẩm</option>'+products.filter(p=>archiveRooms().some(r=>r.productId===p.id)).map(p=>'<option value="'+p.id+'">'+esc(p.name)+'</option>').join(''));$('#archiveFilter').value=selected; if(!$('#archiveFilter').value){archiveFilter='all';$('#archiveFilter').value='all';}
 archivePaintRows();archiveMeasure();
}
function deskScrollKey(){return prefs.product==='archive'?'archive':[prefs.product,productTab,boardLayout,methodFilter].join(':');}
function deskSaveScroll(){if(!deskLastKey)return;deskPositions.set(deskLastKey,{archive:archivePane.scrollTop,board:$('#board').scrollTop,left:$('#board').scrollLeft,content:$('#productContent').scrollTop,columns:$$('#board .columnCards').map(n=>n.scrollTop)});}
const renderBeforeArchive=render;render=function(){
 deskSaveScroll();const key=deskScrollKey(),archive=prefs.product==='archive';$('.desk').classList.toggle('archiveDesk',archive);
 if(archive){renderProducts();renderNotifications();archiveRender();}else{renderBeforeArchive();$('.deskHeader small').textContent='Sản phẩm';}
 archivePane.hidden=!archive;$('#archiveBack').hidden=!archive;$('#archiveProducts').hidden=!archive;$('#productTabs').hidden=archive;$('#newVideo').hidden=archive;$('.deskActions>.search').hidden=archive;$('#deskSummary').hidden=!archive;
 if(archive){$('#board').hidden=true;$('#productContent').hidden=true;$('#dropHint').hidden=true;}
 const pos=deskPositions.get(key)||{archive:0,board:0,left:0,content:0,columns:[]};archivePane.scrollTop=pos.archive;$('#board').scrollTop=pos.board;$('#board').scrollLeft=pos.left;$('#productContent').scrollTop=pos.content;$$('#board .columnCards').forEach((n,i)=>n.scrollTop=pos.columns[i]||0);deskLastKey=key;
};
async function archiveOpen(){g6LeaveRecipes();if(prefs.product!=='archive')archiveReturnProduct=prefs.product;prefs.product='archive';await savePrefs();render();}
$('#archiveProduct').onclick=()=>archiveOpen().catch(fail);
$('#archiveBack').onclick=async()=>{prefs.product=productFor(archiveReturnProduct)&&!productFor(archiveReturnProduct).archived?archiveReturnProduct:'all';await savePrefs();render();};
$('#archiveSearch').oninput=e=>{archiveQuery=e.target.value;archivePaintRows();};$('#archiveFilter').onchange=e=>{archiveFilter=e.target.value;archivePaintRows();};$('#archiveSort').onchange=e=>{archiveSort=e.target.value;archivePaintRows();};$('#archiveRefresh').onclick=()=>archiveMeasure(true);
async function archiveRestore(id){
 const r=roomFor(id),p=productFor(r?.productId);if(!r||r.trashedAt||p?.trashedAt)throw Error('Khôi phục sản phẩm từ Thùng rác trước.');
 const changed=[];if(p?.archived)for(const other of rooms.filter(x=>x.productId===p.id&&x.id!==r.id&&!x.trashedAt))changed.push({...other,archived:true,archivedAt:other.archivedAt||Date.now()});
 const restored={...r,archived:false,archiveRestoredAt:Date.now()};delete restored.archivedAt;changed.push(restored);const product=p?.archived?{...p,archived:false}:null;
 await new Promise((resolve,reject)=>{const tx=db.transaction(['rooms','products'],'readwrite');for(const room of changed)tx.objectStore('rooms').put(room,room.id);if(product)tx.objectStore('products').put(product,product.id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});
 for(const changedRoom of changed)Object.assign(roomFor(changedRoom.id),changedRoom);delete r.archivedAt;if(product)Object.assign(p,product);render();toast('Đã khôi phục “'+r.name+'” về '+(p?.name||'Tất cả')+'.');
}
function archiveDelete(id){
 const r=roomFor(id);if(!r)return;modal('Xóa vĩnh viễn video?','<p><b>'+esc(r.name)+'</b></p><p>Xóa phòng, tư liệu riêng và bản dựng đang lưu trong app. Bộ ảnh/bộ cảnh dùng chung của sản phẩm và tệp đã xuất ra thư mục máy được giữ.</p><p>Không thể hoàn tác.</p>','<button id="archiveCancelDelete">Hủy</button><button id="archiveConfirmDelete" class="errorButton">Xóa vĩnh viễn</button>');$('#archiveCancelDelete').onclick=()=>$('#shellDialog').close();$('#archiveConfirmDelete').onclick=async()=>{const button=$('#archiveConfirmDelete');button.disabled=true;try{
 if(activeWorkers.has(id)||jobs.some(j=>j.roomId===id&&['running','unknown'].includes(j.status)))throw Error('Chờ tác vụ đang chạy hoặc kiểm tra tác vụ chưa rõ kết quả trước khi xóa.');
 if(frameRoom===id){await flushFrames();$('#roomFrames').replaceChildren();frameRoom=null;currentRoom=null;}
 await deleteRoomState(id);
 await new Promise((resolve,reject)=>{const tx=db.transaction(['rooms','files','jobs'],'readwrite');tx.objectStore('rooms').delete(id);const cursor=tx.objectStore('files').openKeyCursor();cursor.onsuccess=()=>{const c=cursor.result;if(c){if(String(c.key).startsWith(id+':'))tx.objectStore('files').delete(c.key);c.continue();}};for(const j of jobs.filter(j=>j.roomId===id))tx.objectStore('jobs').delete(j.id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});
 rooms=rooms.filter(x=>x.id!==id);jobs=jobs.filter(j=>j.roomId!==id);if(prefs.lastRoom===id){prefs.lastRoom=rooms.find(x=>!x.trashedAt)?.id||null;await savePrefs();}archiveBytes.delete(id);$('#shellDialog').close();render();toast('Đã xóa video khỏi app. Tệp trong thư mục máy được giữ.');
 }catch(e){button.disabled=false;toast(e.message);}};
}
$('#archiveRows').onclick=e=>{const restore=e.target.closest('[data-archive-restore]'),remove=e.target.closest('[data-archive-delete]'),empty=e.target.closest('[data-archive-empty]');if(restore)archiveRestore(restore.dataset.archiveRestore).catch(fail);if(remove)archiveDelete(remove.dataset.archiveDelete);if(empty){if(empty.dataset.archiveEmpty==='back')$('#archiveBack').click();else{archiveQuery='';archiveFilter='all';$('#archiveSearch').value='';$('#archiveFilter').value='all';archivePaintRows();}}};
$('#archiveClean').onclick=()=>{const bytes=archiveTemporary.reduce((n,f)=>n+f.size,0);if(!bytes)return;modal('Dọn tệp tạm?','<p>'+archiveFormat(bytes)+' bộ nhớ đệm được đánh dấu, có thể tạo lại. Giữ video mẫu, clip, ảnh và bản dựng.</p>','<button id="archiveCancelClean">Hủy</button><button id="archiveConfirmClean" class="primary">Dọn tệp tạm</button>');$('#archiveCancelClean').onclick=()=>$('#shellDialog').close();$('#archiveConfirmClean').onclick=async()=>{const button=$('#archiveConfirmClean');button.disabled=true;try{await new Promise((resolve,reject)=>{const tx=db.transaction('files','readwrite');for(const f of archiveTemporary)tx.objectStore('files').delete(f.key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});$('#shellDialog').close();await archiveMeasure(true);toast('Đã dọn tệp tạm; tư liệu và bản dựng được giữ.');}catch(e){button.disabled=false;toast(e.message);}};};
window.SceneForgeApp.archive={open:archiveOpen};
