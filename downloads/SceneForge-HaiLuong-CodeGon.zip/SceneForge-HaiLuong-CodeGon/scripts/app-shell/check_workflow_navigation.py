"""Regression for the greyed-out branch and hidden legacy photo projects."""
from pathlib import Path
from functools import partial
import http.server,threading,json
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[2]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1700,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));base='http://localhost:'+str(server.server_port)
  page.goto(base+'/?demo=1');page.wait_for_function('SceneForgeApp.getState().rooms.length===7&&document.querySelectorAll(".stageColumn").length===4',timeout=60000);rooms=page.evaluate('SceneForgeApp.getState().rooms');reference=next(r['id']for r in rooms if r['mode']=='reference')
  page.evaluate('(id)=>SceneForgeApp.openRoom(id,"analysis")',reference);wf=page.frame_locator('#workflowFrame');expect(page.locator('[data-workflow-mode=photos]')).to_be_enabled();expect(wf.locator('.branchbar')).not_to_be_visible();expect(wf.locator('#workflowChooser')).not_to_be_visible();expect(wf.locator('#node-source')).to_be_visible();wf.locator('[data-ref-description=background]').fill('Bối cảnh riêng cần giữ nguyên');page.wait_for_timeout(350);page.screenshot(path='/tmp/sceneforge-restored-reference.png')
  # Both routes are directly reachable from the prominent selector.
  expect(page.locator('[data-workflow-mode=photos]')).to_be_visible();expect(page.locator('[data-workflow-mode=reference]')).to_have_attribute('aria-pressed','true');page.locator('[data-workflow-mode=photos]').click();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length===5');photo=page.evaluate('SceneForgeApp.getState().currentRoom');assert photo!=reference;expect(page.locator('[data-workflow-mode=photos]')).to_have_attribute('aria-pressed','true')
  ph=page.frame_locator('#workflowFrame');expect(page.locator('[data-workflow-mode=reference]')).to_be_enabled()
  # The two-row arrangement is the actual DOM, not a flattened screenshot.
  overlap=page.locator('#workflowFrame').evaluate('''f=>{const ns=[...f.contentDocument.querySelectorAll('.photoNode')].map(n=>({id:n.dataset.node,x:n.offsetLeft,y:n.offsetTop,r:n.offsetLeft+n.offsetWidth,b:n.offsetTop+n.offsetHeight}));return ns.flatMap((a,i)=>ns.slice(i+1).filter(b=>a.x<b.r&&a.r>b.x&&a.y<b.b&&a.b>b.y).map(b=>[a.id,b.id]));}''');assert not overlap,overlap
  ph.locator('#arrangePhoto').click();expect(ph.locator('#undoPhotoLayout')).to_be_visible();ph.locator('#undoPhotoLayout').click();page.screenshot(path='/tmp/sceneforge-restored-photos.png')
  page.locator('[data-workflow-mode=reference]').click();page.wait_for_function('(id)=>SceneForgeApp.getState().currentRoom===id',arg=reference);expect(page.frame_locator('#workflowFrame').locator('[data-ref-description=background]')).to_have_value('Bối cảnh riêng cần giữ nguyên')
  for width in [1700,1366,390]:
   page.set_viewport_size({'width':width,'height':950});page.wait_for_timeout(100)
   dims=page.locator('#workflowFrame').evaluate('''f=>{const d=f.contentDocument,headers=['.projectbar','#usageStrip'].map(s=>d.querySelector(s).getBoundingClientRect().bottom);return{top:d.querySelector('#viewport').getBoundingClientRect().top,bottom:Math.max(...headers)};}''');assert dims['top']>=dims['bottom'],(width,dims)
  page.set_viewport_size({'width':1700,'height':1100})
  # Store an actual old photo storyboard with a frame + clip Blob and a newer draft alongside it.
  legacy=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.photoProject(true)')
  legacy['id']='legacy-photo-test';legacy['name']='Ảnh cũ · phải giữ khung và clip';legacy['storyboard']['approved']=True;legacy['roomSeeded']=True
  page.evaluate('''async old=>{const image=showcaseSample.frames[0],file=await(await fetch(showcaseSample.video)).blob();old.scenes[0].frames=[{id:'frame-old',image,version:1}];old.scenes[0].approvedFrame='frame-old';old.scenes[0].clips=[{id:'clip-old',asset:'blob-old',part:'a',version:1,duration:12,name:'clip-cu.mp4'}];old.scenes[0].chosen={a:'clip-old'};old.assetEntries=[['blob-old',file]];await writeForeign('projects','sceneforge-workflows',old.id,old);const r={id:old.id,name:old.name,mode:'photos',productId:products[0].id,stage:'review',refs:clone(old.refs),createdAt:Date.now(),photoDraft:{...clone(rooms.find(r=>r.mode==='photos').photoDraft),migrationNotice:'Đã giữ lời cũ'}};rooms.push(r);await io('rooms','readwrite',r.id,r);}''',legacy)
  page.goto(base+'/?demo=1&restore=1#overview');page.wait_for_function('SceneForgeApp.getState().rooms.some(r=>r.id==="legacy-photo-test"&&r.photoWorkspace==="storyboard")');page.evaluate('SceneForgeApp.openRoom("legacy-photo-test","analysis")');page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().storyboard?.approved===true');old=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState()');assert old['scenes'][0]['clips'][0]['id']=='clip-old';assert old['scenes'][0]['approvedFrame']=='frame-old';assert old['script']==legacy['script'];expect(page.locator('#photoWorkspaceToggle')).to_be_visible()
  original=page.evaluate('workflowRecord("legacy-photo-test")');assert original['assetEntries'][0][0]=='blob-old'
  page.locator('#photoWorkspaceToggle').click();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().beats?.length===5');page.locator('#photoWorkspaceToggle').click();page.wait_for_function('document.querySelector("#workflowFrame")?.contentWindow?.SceneForgeWorkflow?.getState().storyboard?.approved===true');restored=page.locator('#workflowFrame').evaluate('(f)=>f.contentWindow.SceneForgeWorkflow.getState()');assert restored['scenes'][0]['clips']==old['scenes'][0]['clips'];assert restored['script']==old['script']
  assert not errors,errors;b.close()
 print('PASS: enabled two-way workflow tabs, separate remembered rooms, reference edits survive switch, eight nodes including Storyboard without overlap, arrange undo, measured headers at desktop/mobile; legacy script/approved frame/clip Blob preserved across opening both old/new photo workspaces. No APIs called.')
finally:server.shutdown()
