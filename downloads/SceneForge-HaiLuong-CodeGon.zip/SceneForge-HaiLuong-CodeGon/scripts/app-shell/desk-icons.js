// UI icons are SVG paths, not font glyphs (which varied or became boxes on other machines).
const deskIcon={
 reference:'<rect x="3" y="6" width="18" height="15" rx="2"/><path d="M3 11h18M3 6l2-4 17 2-1 4M8 3l2 4m4-3 2 4"/>',
 photos:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1.5"/><path d="m4 17 5-5 4 4 3-3 5 5"/>',
 board:'<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M9 3v18m6-18v18M3 9h18M3 15h18"/>',
 list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h1M3 12h1M3 18h1"/>',
 archive:'<rect x="6" y="2" width="12" height="20" rx="1"/><path d="M6 11h12M10 6h4m-4 10h4"/>'
};
function deskSvg(key){return '<svg viewBox="0 0 24 24" aria-hidden="true">'+deskIcon[key]+'</svg>';}
for(const key of ['reference','photos']){const b=$('[data-method='+key+']');b.innerHTML=deskSvg(key)+(key==='reference'?'Video mẫu':'Từ ảnh');}
for(const key of ['board','list']){const b=$('[data-board-layout='+key+']');b.innerHTML=deskSvg(key)+(key==='board'?'Bảng':'Danh sách');}
$('#newVideo').innerHTML='<span class="deskPlus" aria-hidden="true">+</span> Video mới <span class="deskChevron" aria-hidden="true"></span>';
for(const n of [...$('#archiveProduct').childNodes])if(n.nodeType===Node.TEXT_NODE)n.remove();$('#archiveProduct').insertAdjacentHTML('afterbegin',deskSvg('archive'));
