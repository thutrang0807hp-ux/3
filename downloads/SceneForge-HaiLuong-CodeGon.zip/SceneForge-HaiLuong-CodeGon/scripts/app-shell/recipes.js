// One library across products, stored independently of room cleanup/deletion.
let recipeCache=null,recipeLoading=null;
async function recipeLibrary(){
 if(recipeCache)return recipeCache;
 if(!recipeLoading)recipeLoading=(async()=>{const saved=await io('prefs','readonly','recipe-library');recipeCache=saved||{version:1,items:structuredClone(SFRecipes.starters),deleted:[],sources:{}};return recipeCache;})();
 return recipeLoading;
}
async function saveRecipeLibrary(){await io('prefs','readwrite','recipe-library',recipeCache);}
async function listRecipes(){const lib=await recipeLibrary();return lib.items.map(r=>{
 const usedRooms=rooms.filter(v=>v.photoDraft?.formula===r.id),uses=new Set([...usedRooms.map(v=>v.id),...Object.values(lib.usage||{}).filter(v=>v.formula===r.id).map(v=>v.roomId)]),feedback=Object.values(lib.feedback||{}).filter(v=>v.formula===r.id);for(const v of usedRooms.filter(v=>v.stage==='exported'&&v.recipeVote&&!lib.feedback?.[v.id]))feedback.push({vote:v.recipeVote});
 return{...clone(r),uses:uses.size,up:feedback.filter(v=>v.vote===1).length,down:feedback.filter(v=>v.vote===-1).length};
}).sort((a,b)=>SFRecipes.rank(b)-SFRecipes.rank(a)||a.name.localeCompare(b.name,'vi'));}
async function putRecipe(raw){const r=SFRecipes.validate(raw),lib=await recipeLibrary(),old=lib.items.find(x=>x.id===r.id);if(old)lib.items[lib.items.indexOf(old)]=r;else lib.items.push(r);await saveRecipeLibrary();return clone(r);}
async function removeRecipe(id){const lib=await recipeLibrary();lib.items=lib.items.filter(r=>r.id!==id);if(!lib.deleted.includes(id))lib.deleted.push(id);await saveRecipeLibrary();}
async function useRecipe(id,roomId){const lib=await recipeLibrary(),r=lib.items.find(r=>r.id===id),room=roomFor(roomId);if(!r||!room||room.mode!=='photos')throw Error('Công thức hoặc phòng không còn tồn tại.');room.recipeSnapshot=SFRecipes.strip(r);lib.usage??={};lib.usage[roomId+':'+id]={roomId,formula:id};await saveRecipeLibrary();await io('rooms','readwrite',room.id,room);return clone(r);}
Object.assign(window.SceneForgeApp.photoBridge,{listRecipes,putRecipe,removeRecipe,useRecipe});

const recipeWork=new Set();
// Store a structural recipe locally; never issue a second cloud request implicitly.
const g6RecipeReplay=new Set();
async function extractReferenceRecipe(roomId){if(recipeWork.has(roomId)){g6RecipeReplay.add(roomId);return;}recipeWork.add(roomId);try{const room=roomFor(roomId);if(!room||room.mode==='photos'||room.trashedAt)return;const w=await workflowRecord(roomId);if(!w?.scenes?.length||w.analysis?.pipeline6?.running||w.analysis?.status==='scanning')return;const lib=await recipeLibrary(),id='source:'+roomId,existing=lib.items.find(r=>r.id===id),signature=JSON.stringify([w.scenes.map(s=>[s.start,s.end]),w.analysis.semantic?.recipe||null]);if(lib.deleted.includes(id)||existing?.userEdited||lib.sources[roomId]?.signature===signature)return;
 let raw=w.analysis.semantic?.recipe;if(!raw){const scenes=w.scenes.slice(0,60);let at=0;raw={name:room.name+' · khung sườn',industry:'Chung',videoType:'Từ video mẫu',tips:'Khung nhịp rút từ mốc cảnh trên máy, chưa suy ra công dụng hay lời quảng cáo. Thay lời theo sản phẩm thực tế.',beats:scenes.map((s,i)=>{const seconds=s.end-s.start,role=i===0?'question':i===scenes.length-1?'close':'benefit',b={name:'Cảnh '+(i+1),role,type:s.hasPerson?'use':'detail',start:at,end:at+seconds,purpose:i===0?'Nhịp mở đầu':i===scenes.length-1?'Nhịp kết':'Nhịp nội dung',example:''};at+=seconds;return b;})};}
 await putRecipe({...raw,metrics:existing?.metrics||{},id,source:'reference',sourceRoomId:roomId,sourceName:room.name,sourcePoster:room.poster,createdAt:existing?.createdAt||Date.now()});lib.sources[roomId]={state:'done',signature,note:'Lưu khung sườn từ mốc đã có, không gọi thêm AI.'};await saveRecipeLibrary();room.referenceRecipeId=id;await io('rooms','readwrite',room.id,room);
 }catch(e){const lib=await recipeLibrary();lib.sources[roomId]={state:'failed',note:e.message};await saveRecipeLibrary();}finally{recipeWork.delete(roomId);if(g6RecipeReplay.delete(roomId))queueMicrotask(()=>extractReferenceRecipe(roomId));}}
const workflowBeforeRecipes=onWorkflowState;
onWorkflowState=async function(data){await workflowBeforeRecipes(data);if(data.mode!=='photos'&&!data.scanning)extractReferenceRecipe(data.roomId).catch(()=>{});};

const cardBeforeRecipes=card;
card=function(room,compact=false){
 const t=document.createElement('template');t.innerHTML=cardBeforeRecipes(room,compact);
 if(!compact){
  const cover=t.content.querySelector('.cover'),info=t.content.querySelector('.cardInfo');if(cover&&info)cover.append(info);const hook=t.content.querySelector('.coverTitle');if(hook&&room.hook)hook.textContent=room.hook;
  if(room.stage==='review'){const bottom=t.content.querySelector('.cardBottom');if(bottom?.querySelector('button')){for(const node of [...bottom.childNodes])if(node.nodeType===Node.TEXT_NODE)node.remove();}}
  const running=jobs.find(j=>j.roomId===room.id&&j.status==='running');
  if(running&&cover){const badge=document.createElement('span');badge.className='runningBadge';badge.textContent=(laneOf(running)==='muse'?'Muse':'Flow')+' đang chạy';cover.prepend(badge);}
 }
 if(room.stage==='exported'&&room.mode==='photos'&&room.photoDraft?.formula){
  const target=t.content.querySelector('.cardBottom,.compactCard>div'),row=document.createElement('div');row.className='recipeVotes';row.innerHTML=[['1','👍 Ra đơn'],['-1','👎 Không ăn thua']].map(([v,n])=>'<button data-recipe-vote="'+room.id+':'+v+'" aria-pressed="'+(room.recipeVote===Number(v))+'">'+n+'</button>').join('');target?.append(row);
 }
 return t.innerHTML;
};
$('#board').addEventListener('click',async e=>{
 const b=e.target.closest('[data-recipe-vote]');if(!b)return;
 e.stopPropagation();const[id,v]=b.dataset.recipeVote.split(':'),r=roomFor(id);if(!r)return;
 r.recipeVote=r.recipeVote===Number(v)?null:Number(v);const lib=await recipeLibrary();lib.feedback??={};lib.feedback[r.id]={formula:r.photoDraft.formula,vote:r.recipeVote};await saveRecipeLibrary();await persistRoom(r);toast('Đã lưu đánh giá cho công thức của video này.');
},true);

// Source words are read only on demand for similarity checks, never copied into a recipe/draft.
window.SceneForgeApp.photoBridge.recipeSourceText=async id=>{const lib=await recipeLibrary(),r=lib.items.find(x=>x.id===id);if(!r?.sourceRoomId)return '';const w=await workflowRecord(r.sourceRoomId);return (w?.script||[]).map(b=>b.original||'').join(' ').slice(0,100000);};
