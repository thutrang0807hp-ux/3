// User-owned media arrives from the local workflow; importing never calls Flow.
let importingWorkflow=false;
window.addEventListener('message',async event=>{
 if(event.origin!==location.origin||event.source!==parent||event.data?.type!=='sceneforge:workflow-import')return;
 const{id,payload}=event.data,ack=error=>parent.postMessage({type:'sceneforge:workflow-import-ack',id,error},location.origin);
 if(importingWorkflow||recording){ack('Đang xuất/nhập bản dựng khác.');return;}importingWorkflow=true;const addedUrls=[];
 try{
  if(editorRoomId&&payload.roomId!==editorRoomId)throw Error('Clip không thuộc phòng đang mở.');
  await window.SceneForgeEditor.roomReady;
  const library=payload.placement==='library',append=!!payload.appendOnly;
  if(!Array.isArray(payload?.clips)||payload.clips.length>300||(!library&&!payload.clips.length))throw Error('Danh sách clip không hợp lệ.');
  const newAssets=[],newItems=[],videoTrack={id:uid(),kind:'video',name:'Video từ Tạo video'},newTracks=[videoTrack];let at=0;
  const known=new Set(assets.map(a=>a.workflowKey).filter(Boolean));
  function assetFor(c,kind='video'){
   if(!(c.file instanceof Blob)||c.file.size===0)throw Error('Thiếu tệp clip.');
   if(append&&c.key&&known.has(c.key))return null;
   const url=URL.createObjectURL(c.file);addedUrls.push(url);const asset={id:uid(),kind,name:String(c.name||'Tư liệu').slice(0,250),duration:c.sourceDuration,url,poster:c.poster||FRAMES[0],workflowKey:c.key||null,workflowScene:c.sceneId||null,workflowPart:c.part||null,workflowSceneIndex:c.sceneIndex,workflowVersion:c.version,newVersion:append};if(append)asset.name+=' · bản mới';newAssets.push(asset);return asset;
  }
  for(const[index,c]of payload.clips.entries()){
   if(!Number.isFinite(c.duration)||c.duration<.2||c.duration>600||!Number.isFinite(c.sourceDuration)||c.sourceDuration<.2||!Number.isFinite(c.start)||c.start<0||(!library&&Math.abs(c.start-at)>.05))throw Error('Thời lượng/mốc clip không hợp lệ.');
   if(c.start+c.duration>3600)throw Error('Bản dựng tối đa 60 phút.');const asset=assetFor(c);if(!asset)continue;if(!library){const duration=Math.min(c.duration,c.sourceDuration);newItems.push({...defaults('video'),id:uid(),assetId:asset.id,trackId:videoTrack.id,kind:'video',name:asset.name,start:at,duration,volume:payload.muteClipSound?0:Number.isFinite(payload.clipVolume)?clamp(payload.clipVolume,0,1):1});const gap=c.duration-duration;if(gap>.0001){if(typeof c.tail!=='string'||!/^data:image\/(jpeg|png|webp);base64,/.test(c.tail))throw Error('Thiếu ảnh cuối cho clip ngắn.');const still={id:uid(),kind:'image',name:asset.name+' · giữ khung cuối',duration:gap,url:c.tail,poster:c.tail};newAssets.push(still);newItems.push({...defaults('image'),id:uid(),kind:'image',assetId:still.id,trackId:videoTrack.id,name:still.name,start:at+duration,duration:gap});}}at=Math.max(at,c.start+c.duration);
  }
  for(const c of payload.alternatives||[]){if(!Number.isFinite(c.sourceDuration)||c.sourceDuration<.2)throw Error('Bản phụ không có thời lượng hợp lệ.');assetFor(c);}
  for(const a of payload.audio||[]){if(!(a.file instanceof Blob))throw Error('Thiếu tệp âm thanh.');const asset=assetFor({...a,key:a.key||'audio:'+a.role,sourceDuration:1},'audio');if(!asset)continue;const audio=document.createElement('audio');try{await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Không đọc được âm thanh.')),15000);audio.onloadedmetadata=()=>{clearTimeout(timer);resolve();};audio.onerror=()=>{clearTimeout(timer);reject(Error('Không giải mã được âm thanh.'));};audio.src=asset.url;});asset.duration=audio.duration;if(!Number.isFinite(asset.duration)||asset.duration<=0)throw Error('Thời lượng âm thanh không hợp lệ.');}finally{audio.removeAttribute('src');audio.load();}if(a.place&&!append){const track={id:uid(),kind:'audio',name:a.role==='voice'?'Giọng đọc':'Nhạc nền'};newTracks.push(track);newItems.push({...defaults('audio'),id:uid(),assetId:asset.id,trackId:track.id,kind:'audio',name:asset.name,start:a.start||0,duration:a.role==='music'&&!library?Math.min(asset.duration,at):asset.duration,volume:a.role==='music'?clamp(Number.isFinite(a.volume)?a.volume:.15,0,1):1});}}
  if(Array.isArray(payload.captions)&&payload.captions.length&&!library){const track={id:uid(),kind:'text',name:'Phụ đề từ kịch bản'};newTracks.push(track);if(payload.captions.length>1000)throw Error('Quá nhiều câu phụ đề.');for(const c of payload.captions){if(!Number.isFinite(c.start)||!Number.isFinite(c.end)||c.start<0||c.end<=c.start||c.end>at+.05)throw Error('Mốc phụ đề vượt bản dựng.');newItems.push({...defaults('text'),subtitle:true,id:uid(),kind:'text',assetId:null,trackId:track.id,name:String(c.text).slice(0,50),text:String(c.text).slice(0,500),start:c.start,duration:c.end-c.start,fontSize:52,textY:82,textBg:true,outline:1,...(sharedCaptionStyles[payload.captionStyle]||sharedCaptionStyles.clean),fontSize:clamp(Number(payload.captionOptions?.fontSize)||64,28,100),textY:clamp(Number(payload.captionOptions?.textY)||80,10,90)});}}
  activeClipDrag?.cancel?.();pause();transact(()=>{assets.push(...newAssets);if(!append){tracks=newTracks;items=newItems;projectFrame={width:1080,height:1920};markers=[];selection=newItems[0]?.id||null;selectedIds=new Set(selection?[selection]:[]);time=0;}});
  if(!library)$('#fitTimeline')?.click();notify(append?'Đã thêm bản mới vào Kho. Timeline được giữ nguyên.':library?'Đã đưa clip vào Kho để tự ghép.':'Đã ghép clip đúng thứ tự; giữ tiếng Flow.');ack(null);
 }catch(error){for(const url of addedUrls)URL.revokeObjectURL(url);ack(error.message);}finally{importingWorkflow=false;}
});
