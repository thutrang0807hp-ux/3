// Shared workbench extensions. Runs inside the existing multi-track editor closure.
const sharedCaptionStyles={
 clean:{name:'Rõ nét',fontSize:64,bold:true,color:'#ffffff',outline:3,textBg:false,textY:80},
 bold:{name:'Nổi bật',fontSize:76,bold:true,color:'#ffdc45',outline:4,textBg:false,textY:80},
 box:{name:'Nền tối',fontSize:64,bold:true,color:'#ffffff',outline:0,textBg:true,background:'#101318',textY:80},
 minimal:{name:'Tối giản',fontSize:54,bold:false,color:'#ffffff',outline:0,textBg:false,textY:80}
};
const sharedEffects=[
 {id:'zoom',name:'Zoom chậm',group:'motion',description:'Phóng khung hình từ 100% lên 115% trong suốt clip.',filter:'',motion:'rich-zoom',tab:'animation'},
 {id:'slide',name:'Trượt nhẹ',group:'motion',description:'Dịch khung hình từ trái sang phải, giữ nguyên thời lượng.',filter:'',motion:'rich-slide',tab:'animation'},
 {id:'fade',name:'Hiện dần',group:'motion',description:'Tăng độ hiện từ 0 lên mức gốc ở đầu clip.',filter:'',motion:'rich-fade',tab:'animation'},
 {id:'pulse',name:'Nhịp zoom',group:'motion',description:'Phóng nhẹ ở giữa clip rồi trở về khung ban đầu.',filter:'',motion:'rich-pulse',tab:'animation'},
 {id:'bright',name:'Sáng dịu',group:'image',description:'Tăng độ sáng lên 115%, có thể chỉnh bằng thanh trượt.',patch:{brightness:115},filter:'brightness(115%)',tab:'color'},
 {id:'contrast',name:'Nét tương phản',group:'image',description:'Tăng tương phản lên 125%, làm vùng sáng tối rõ hơn.',patch:{contrast:125},filter:'contrast(125%)',tab:'color'},
 {id:'soft',name:'Mềm nhẹ',group:'image',description:'Làm mờ 2px ở khung 1080px, không đổi video gốc.',patch:{blur:2},filter:'blur(2px)',tab:'color'},
 {id:'color',name:'Màu sống động',group:'color',description:'Tăng bão hòa lên 135%. Phù hợp clip có màu nhạt.',patch:{saturation:135},filter:'saturate(135%)',tab:'color'},
 {id:'cinema',name:'Ấm điện ảnh',group:'color',description:'Áp dụng look điện ảnh, vẫn sửa được các thông số màu.',patch:{look:'cinema'},filter:visualFilter({...defaults('video'),look:'cinema'}),tab:'color'}
];
let effectCategory='all',effectQuery='',effectPreviewToken=0;
const baseShowLibrary=showLibrary;
function showSharedLibrary(kind){
 libraryTab=kind;$$('[data-library]').forEach(button=>button.classList.toggle('active',button.dataset.library===kind));
 $('#sourceLibrary').hidden=true;$('#creativeLibrary').hidden=false;$('.assetSearch').hidden=true;$('.mediaContent').classList.add('paletteMode');
}
showLibrary=function(kind){
 if(kind==='text'||kind==='captions'){showSharedLibrary('text');renderSharedCaptions();return;}
 if(kind==='effects'){showSharedLibrary(kind);renderSharedEffects();return;}
 baseShowLibrary(kind);
};
$('[data-library=captions]')?.remove();
const mergedTextTool=$('[data-library=text]');mergedTextTool.querySelector('small').innerHTML='Chữ<br>Phụ đề';mergedTextTool.setAttribute('aria-label','Chữ và phụ đề');
$('#srtFile').accept='.srt,.vtt,text/vtt,text/plain';
function captionItems(){return items.filter(item=>item.kind==='text'&&item.subtitle).sort((a,b)=>a.start-b.start);}
function renderSharedCaptions(){
 $('#mediaPanel .panelHead b').textContent='Chữ & phụ đề';
 $('#creativeLibrary').innerHTML='<div class="paletteIntro"><b>Chữ dùng chung timeline</b><p>Nhập SRT/VTT hoặc thêm câu, sau đó chọn đoạn chữ để sửa bên phải.</p></div><button id="palettePlainText" class="largeAddText">＋ Thêm tiêu đề / văn bản</button><div class="sharedCaptionActions"><button data-shared-caption="import">Nhập SRT / VTT</button><button data-shared-caption="add">＋ Thêm câu</button><button data-shared-caption="srt">Tải SRT</button><button data-shared-caption="ass">Tải ASS</button></div><div class="sharedCaptionPresets">'+Object.entries(sharedCaptionStyles).map(([id,preset])=>'<button data-shared-style="'+id+'"><span class="caption-sample-'+id+'">Một ngày thật đẹp</span><b>'+preset.name+'</b></button>').join('')+'</div><p class="sharedCaptionTip">Chọn câu để áp dụng riêng; chọn video để áp dụng kiểu cho tất cả phụ đề. Tiêu đề và nhãn dán được giữ nguyên.</p><div id="sharedCueList"></div><p class="unavailableFeature">Tự nhận giọng nói chưa được kết nối.</p>';
 updateSharedCueList();
}
function updateSharedCueList(){
 const box=$('#sharedCueList');if(!box)return;
 const cues=captionItems();box.innerHTML=cues.map((cue,index)=>'<button data-shared-cue="'+esc(cue.id)+'"><b>'+String(index+1).padStart(2,'0')+'</b><span>'+esc(cue.text)+'<small>'+fmt(cue.start)+' – '+fmt(end(cue))+'</small></span></button>').join('')||'<p class="hint">Chưa có câu phụ đề. Bấm Thêm câu hoặc nhập tệp.</p>';
}
function appendSharedCaption(){
 if(items.length>=300){notify('Tối đa 300 mục trong bản thử này.');return;}
 transact(()=>{let track=tracks.find(t=>t.kind==='text'&&!t.locked&&items.every(i=>i.trackId!==t.id||i.subtitle));const caption={...defaults('text'),...sharedCaptionStyles.clean,id:uid(),kind:'text',subtitle:true,name:'Phụ đề',text:'Nhập phụ đề của bạn',trackId:track?.id,start:time,duration:Math.min(4,Math.max(.2,total()-time))};if(!track||items.some(i=>i.trackId===track.id&&intervalsOverlap(i,caption))){track=makeMediaTrack('text');track.name='Phụ đề';addTrackInFront(track,tracks)}caption.trackId=track.id;items.push(caption);selection=caption.id;selectedIds=new Set([caption.id]);});switchInspectorTab('basic');
}
function applySharedCaptionStyle(key){
 let targets=selected()?.kind==='text'?[selected()]:captionItems();
 if(targets.some(item=>getTrack(item.trackId).locked)){notify('Mở khóa track chữ trước khi đổi kiểu.');return;}
 if(!targets.length){appendSharedCaption();targets=[selected()];}
 transact(()=>targets.forEach(item=>Object.assign(item,sharedCaptionStyles[key],{outlineColor:'#000000',subtitle:true})));
 if(selected()?.kind==='text')switchInspectorTab('style');notify('Đã áp dụng mẫu '+sharedCaptionStyles[key].name+' cho '+targets.length+' câu.');
}
function parseCaptionTime(value){const m=value.match(/^(?:(\d{1,2}):)?(\d{2}):(\d{2})[.,](\d{3})$/);if(!m||+m[2]>59||+m[3]>59)throw Error('Mốc thời gian không hợp lệ.');return +(m[1]||0)*3600+(+m[2])*60+(+m[3])+(+m[4])/1000;}
function parseSharedCaptions(text){
 const raw=text.replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n').trim(),vtt=/^WEBVTT(?:\s|$)/.test(raw),cues=[];
 for(const block of raw.split(/\n[ \t]*\n/)){
  const lines=block.split('\n');if(vtt&&/^(WEBVTT|NOTE(?:\s|$)|STYLE(?:\s|$)|REGION(?:\s|$))/.test(lines[0]))continue;
  const at=lines.findIndex(line=>line.includes('-->'));if(at<0||at>1)throw Error('Đoạn phụ đề thiếu mốc thời gian.');
  const match=lines[at].match(/^\s*(\S+)\s+-->\s+(\S+)(?:\s+.*)?$/);if(!match)throw Error('Mốc thời gian không hợp lệ.');
  const start=parseCaptionTime(match[1]),finish=parseCaptionTime(match[2]),text=lines.slice(at+1).join('\n').replace(/<[^>]*>/g,'').trim();
  if(finish-start<.2||finish>3600||!text||text.length>500)throw Error('Mỗi câu cần chữ, dài ít nhất 0,2 giây, tối đa 500 ký tự và nằm trong 60 phút.');
  cues.push({start,duration:finish-start,text});
 }
 cues.sort((a,b)=>a.start-b.start);
 if(!cues.length||cues.length>250)throw Error('Tệp cần từ 1 đến 250 câu.');
 if(cues.some((cue,index)=>index&&cue.start<end(cues[index-1])-.0001))throw Error('Có câu phụ đề chồng thời gian; bản cũ được giữ nguyên.');
 return cues;
}
function importSharedCues(cues,label='Phụ đề',style=sharedCaptionStyles.clean){
 let track=selected()?.subtitle?getTrack(selected().trackId):tracks.find(t=>items.some(i=>i.trackId===t.id&&i.subtitle));
 if(track?.locked)throw Error('Mở khóa track phụ đề trước khi nhập.');
 const replacing=track?items.filter(i=>i.trackId===track.id&&i.subtitle).length:0;
 if(items.length-replacing+cues.length>300)throw Error('Dự án vượt 300 mục; dữ liệu cũ được giữ nguyên.');
 transact(()=>{if(!track){track=makeMediaTrack('text');track.name=label;addTrackInFront(track,tracks)}items=items.filter(item=>!(item.trackId===track.id&&item.subtitle));
 for(const cue of cues)items.push({...defaults('text'),...style,...cue,id:uid(),kind:'text',subtitle:true,trackId:track.id,name:'Phụ đề'});
 selection=items.filter(i=>i.trackId===track.id&&i.subtitle)[0].id;selectedIds=new Set([selection]);});
}
$('#srtFile').onchange=async event=>{const file=event.target.files[0];event.target.value='';if(!file)return;try{if(file.size>1e6)throw Error('Tệp phụ đề tối đa 1 MB.');const cues=parseSharedCaptions(await file.text());importSharedCues(cues);showLibrary('captions');switchInspectorTab('basic');notify('Đã nhập '+cues.length+' câu vào timeline. Có thể hoàn tác.');}catch(error){notify(error.message);}};
$('#exportSrt').onclick=()=>{const cues=captionItems();if(!cues.length){notify('Chưa có phụ đề để xuất.');return;}downloadBlob('sceneforge-phu-de.srt',new Blob(['\uFEFF'+cues.map((cue,index)=>`${index+1}\n${toSrtTime(cue.start)} --> ${toSrtTime(end(cue))}\n${cue.text.trim().replace(/\n\s*\n/g,'\n')}\n`).join('\n')],{type:'application/x-subrip;charset=utf-8'}));};
function exportSharedAss(){
 const cues=captionItems();if(!cues.length){notify('Chưa có phụ đề để xuất.');return;}
 const color=value=>'&H00'+value.slice(5,7)+value.slice(3,5)+value.slice(1,3);
 let text='[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n';
 text=text.replace('PlayResX: 1080','PlayResX: '+projectFrame.width).replace('PlayResY: 1920','PlayResY: '+projectFrame.height);
 cues.forEach((cue,index)=>{text+=`Style: Cue${index},Arial,${cue.fontSize},${color(cue.color)},&H00FFFFFF,${color(cue.outlineColor||'#000000')},${color(cue.background||'#101318')},${cue.bold?-1:0},0,0,0,100,100,${cue.letterSpacing||0},0,${cue.textBg?3:1},${cue.textBg?9:cue.outline||0},0,5,0,0,0,1\n`;});
 text+='\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n';
 const stamp=value=>{const cs=Math.round(value*100);return Math.floor(cs/360000)+':'+String(Math.floor(cs/6000)%60).padStart(2,'0')+':'+String(Math.floor(cs/100)%60).padStart(2,'0')+'.'+String(cs%100).padStart(2,'0');};
 cues.forEach((cue,index)=>{text+=`Dialogue: 0,${stamp(cue.start)},${stamp(end(cue))},Cue${index},,0,0,0,,{\\pos(${Math.round(cue.textX*projectFrame.width/100)},${Math.round(cue.textY*projectFrame.height/100)})}`+cue.text.replace(/\\/g,'＼').replace(/{/g,'｛').replace(/}/g,'｝').replace(/\n/g,'\\N')+'\n';});
 downloadBlob('sceneforge-phu-de.ass',new Blob(['\uFEFF'+text],{type:'text/plain;charset=utf-8'}));notify('ASS giữ thời gian và kiểu chữ cơ bản; keyframe/hiệu ứng cần render trong trình dựng.');
}
let migrationAvailable=false;
function migrateSharedCaptionDraft(){try{const draft=JSON.parse(localStorage.getItem('sceneforge.subtitle-draft.v1')||'null');if(!draft||!Array.isArray(draft.cues)||!draft.cues.length)return false;
 const raw=draft.cues.map((cue,index)=>`${index+1}\n${toSrtTime(cue.start)} --> ${toSrtTime(cue.end)}\n${cue.text}`).join('\n\n');const cues=parseSharedCaptions(raw);
 const style={...(sharedCaptionStyles[draft.preset]||sharedCaptionStyles.clean),fontSize:clamp(Number(draft.size)||64,36,96),textY:[20,45,75].includes(draft.position)?100-draft.position:80};importSharedCues(cues,'Phụ đề đã lưu',style);notify('Đã giữ bản phụ đề từ giao diện trước trên timeline mới.');return true;}catch{notify('Bản phụ đề cũ vẫn được lưu trong trình duyệt; chưa nhập được vào timeline này.');return false;}}
function renderSharedEffects(){
 $('#mediaPanel .panelHead b').textContent='Hiệu ứng · xem trước / sau';
 $('#creativeLibrary').innerHTML='<div class="paletteIntro"><b>Chọn clip → chọn hiệu ứng → chỉnh thông số</b><p>Thay đổi gắn vào clip trên timeline. Mẫu chuyển động tạo keyframe; có thể hoàn tác.</p></div><label class="richEffectSearch">'+uiIcon('search')+'<input id="richEffectSearch" type="search" placeholder="Tìm zoom, sáng, màu…" aria-label="Tìm hiệu ứng"></label><div class="richEffectGroups" role="group" aria-label="Nhóm hiệu ứng">'+[['all','Tất cả'],['motion','Chuyển động'],['image','Chỉnh hình'],['color','Màu sắc']].map(([id,label])=>'<button data-effect-group="'+id+'" aria-pressed="'+(effectCategory===id)+'">'+label+'</button>').join('')+'</div><div id="richEffectDetail"></div><div id="richEffectCards" class="richEffectCards"></div>';
 $('#richEffectSearch').value=effectQuery;$('#richEffectSearch').oninput=event=>{effectQuery=event.target.value;renderSharedEffectCards();};renderSharedEffectCards();updateSharedEffectDetail();
}
function renderSharedEffectCards(){
 const box=$('#richEffectCards');if(!box)return;
 const item=selected(),poster=getAsset(item?.assetId)?.poster||FRAMES[0];
 const results=sharedEffects.filter(effect=>(effectCategory==='all'||effect.group===effectCategory)&&normalizeText(effect.name+' '+effect.description).includes(normalizeText(effectQuery)));
 box.innerHTML=results.map(effect=>'<button class="richEffectCard" data-rich-effect="'+effect.id+'" aria-pressed="'+(item?.effectTag===effect.id)+'"><span class="effectCompare"><span><img src="'+esc(poster)+'" alt="Trước hiệu ứng"><i>Trước</i></span><span class="'+effect.motion+'"><img src="'+esc(poster)+'" alt="Sau hiệu ứng minh họa" style="filter:'+effect.filter+'"><i>Sau</i></span></span><b>'+effect.name+'</b><small>'+effect.description+'</small><em>'+({motion:'Keyframe sửa được',image:'Thông số chỉnh được',color:'Màu gắn vào clip'}[effect.group])+'</em></button>').join('')||'<p class="hint">Không tìm thấy hiệu ứng phù hợp.</p>';
}
function updateSharedEffectDetail(){
 const detail=$('#richEffectDetail');if(!detail)return;
 const item=selected();
 if(!item||!['video','image'].includes(item.kind)){detail.innerHTML='<div class="effectSelectionHint">'+uiIcon('info')+' Chọn một clip video/ảnh trên timeline để áp dụng hiệu ứng.</div>';return;}
 const effect=sharedEffects.find(e=>e.id===item.effectTag);
 let parameter='';
 if(effect?.patch){const key=Object.keys(effect.patch).find(k=>['brightness','contrast','saturation','blur'].includes(k));if(key)parameter='<label class="effectParameter">'+({brightness:'Độ sáng (%)',contrast:'Tương phản (%)',saturation:'Bão hòa (%)',blur:'Làm mờ (px)'}[key])+'<input type="number" data-rich-param="'+key+'" min="0" max="'+(key==='blur'?20:key==='saturation'?300:200)+'" step="'+(key==='blur'?'.1':'1')+'" value="'+item[key]+'"></label>';}
 if(effect&&['zoom','pulse'].includes(effect.id)&&item.keyframes.length){const index=effect.id==='zoom'?item.keyframes.length-1:1;parameter='<label class="effectParameter">Mức phóng '+(effect.id==='zoom'?'cuối clip':'giữa clip')+' (%)<input type="number" data-rich-keyframe="'+index+'" min="10" max="400" value="'+Math.round(item.keyframes[index].values.scale*100)+'"></label>';}
 detail.innerHTML='<div class="effectSelectedClip"><span>Clip đang chọn</span><b>'+esc(item.name)+'</b><small>'+fmt(item.start)+' – '+fmt(end(item))+' · '+(getTrack(item.trackId).locked?'Đang khóa':'Có thể chỉnh')+'</small></div>'+(effect?'<div class="effectRecipe"><strong>'+effect.name+'</strong><p>'+effect.description+'</p><p>'+(effect.group==='motion'?'Có '+item.keyframes.length+' mốc chuyển động. Áp dụng mẫu sẽ thay bộ keyframe hiện có.':`Sáng ${item.brightness}% · Tương phản ${item.contrast}% · Bão hòa ${item.saturation}% · Mờ ${item.blur}px`)+'</p>'+parameter+'<div><button data-rich-action="preview">'+uiIcon('play')+' Xem đoạn này</button><button data-rich-action="adjust">'+uiIcon('sliders')+' Chỉnh chi tiết</button></div></div>':'<p class="sharedCaptionTip">Ảnh Trước/Sau là hình minh họa tĩnh. Bấm mẫu để áp dụng thật vào clip đang chọn, rồi xem ở khung giữa.</p>');
 for(const button of $$('[data-rich-effect]'))button.setAttribute('aria-pressed',String(button.dataset.richEffect===item.effectTag));
}
function applyRichEffect(key){
 const item=ensureVisualSelection(),effect=sharedEffects.find(e=>e.id===key);if(!item||!effect)return;
 transact(()=>{if(effect.patch)Object.assign(item,effect.patch);else{const base=Object.fromEntries(transformKeys.map(k=>[k,item[k]])),point=(at,patch)=>({at,values:{...base,...patch}}),duration=item.duration;
  if(key==='zoom')item.keyframes=[point(0,{}),point(duration,{scale:Math.min(4,base.scale*1.15)})];
  if(key==='slide')item.keyframes=[point(0,{x:base.x-5}),point(duration,{x:base.x+5})];
  if(key==='fade')item.keyframes=[point(0,{opacity:0}),point(Math.min(.8,duration/2),{opacity:base.opacity}),point(duration,{})];
  if(key==='pulse')item.keyframes=[point(0,{}),point(duration/2,{scale:Math.min(4,base.scale*1.12)}),point(duration,{})];
 }item.effectTag=key;});
 switchInspectorTab(effect.tab);updateSharedEffectDetail();notify('Đã áp dụng '+effect.name+' cho '+item.name+'. Chỉnh thanh trượt / keyframe ở bên phải.');
}
function previewEffectClip(){
 const item=selected();if(!item)return;pause();time=item.start;updateStage(true);togglePlay();const token=++effectPreviewToken,finish=end(item);
 function stopAtEnd(){if(token!==effectPreviewToken||!playing)return;if(time>=finish-.02){pause();time=finish;updateStage(true);return;}requestAnimationFrame(stopAtEnd);}requestAnimationFrame(stopAtEnd);
}
$('#creativeLibrary').addEventListener('click',event=>{
 const style=event.target.closest('[data-shared-style]');if(style){applySharedCaptionStyle(style.dataset.sharedStyle);return;}
 const caption=event.target.closest('[data-shared-caption]');if(caption){const action=caption.dataset.sharedCaption;if(action==='import')$('#srtFile').click();if(action==='add')appendSharedCaption();if(action==='srt')$('#exportSrt').click();if(action==='ass')exportSharedAss();if(action==='migrate')migrateSharedCaptionDraft();return;}
 const cue=event.target.closest('[data-shared-cue]');if(cue){choose(cue.dataset.sharedCue,true);switchInspectorTab('basic');return;}
 const group=event.target.closest('[data-effect-group]');if(group){effectCategory=group.dataset.effectGroup;$$('[data-effect-group]').forEach(button=>button.setAttribute('aria-pressed',String(button===group)));renderSharedEffectCards();return;}
 const effect=event.target.closest('[data-rich-effect]');if(effect){applyRichEffect(effect.dataset.richEffect);return;}
 const action=event.target.closest('[data-rich-action]');if(action){if(action.dataset.richAction==='preview')previewEffectClip();else{const item=selected(),effect=sharedEffects.find(e=>e.id===item?.effectTag);if(item&&effect)switchInspectorTab(effect.tab);}}
});
$('#creativeLibrary').addEventListener('change',event=>{
 const item=selected(),input=event.target;if(!item||getTrack(item.trackId).locked)return;
 if(input.dataset.richParam){const key=input.dataset.richParam,value=Number(input.value),limit=key==='blur'?20:key==='saturation'?300:200;if(!Number.isFinite(value)||value<0||value>limit){notify('Thông số nằm ngoài giới hạn.');updateSharedEffectDetail();return;}transact(()=>{item[key]=value;});}
 if(input.dataset.richKeyframe!==undefined){const index=Number(input.dataset.richKeyframe),value=Number(input.value);if(!item.keyframes[index]||!Number.isFinite(value)||value<10||value>400){notify('Mức phóng cần nằm trong 10–400%.');updateSharedEffectDetail();return;}transact(()=>{item.keyframes[index].values.scale=value/100;});}
});
const sharedDecorate=decorateEditorControls;
decorateEditorControls=function(){sharedDecorate();updateSharedCueList();updateSharedEffectDetail();};
// Disable position easing during pointer edits so clip feedback follows the pointer.
document.addEventListener('pointerdown',event=>{if(event.button===0&&event.target.closest('.timelineItem'))document.body.classList.add('timeline-drag-active');},true);
for(const eventName of ['pointerup','pointercancel'])document.addEventListener(eventName,()=>document.body.classList.remove('timeline-drag-active'),true);
window.addEventListener('blur',()=>document.body.classList.remove('timeline-drag-active'));
// Parent navigation pauses all tracks without replacing the project.
window.addEventListener('message',event=>{if(event.source===parent&&event.origin===location.origin&&event.data?.type==='sceneforge:pause-preview'){effectPreviewToken++;pause();}});
document.addEventListener('visibilitychange',()=>{if(document.hidden){effectPreviewToken++;pause();}});
function bootSharedEditor(){
 document.body.classList.add('shared-multitrack-editor');
 $('#startExport').hidden=true;
 const title=$('header strong');title.textContent='SceneForge · Dựng video 9:16';
 if(!draftCandidate)migrateSharedCaptionDraft();
 if(new URLSearchParams(location.search).get('tool')==='subtitles')showLibrary('text');
 // The old single-video page remains accessible for draft recovery, not a second editor mode.
 window.SceneForgeEditor.isPlaying=()=>playing;
 window.SceneForgeEditor.getReadiness=()=>({multitrack:true,captionFormats:['srt','vtt','ass'],speechRecognition:false,nativeConcat:false,workflowImport:true});
}
