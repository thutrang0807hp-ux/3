// Atomic local drafts include media bytes, not expiring blob URLs.
let editorDBPromise,editorSaveVersion=0,editorSavedVersion=0,editorSaveBusy=false,editorSaveTimer=0,editorRestoring=false;
const editorBlobCache=new Map();
const editorRoomId=new URLSearchParams(location.search).get('room');
function editorDraftMetaKey(){return 'sceneforge-editor-draft-v2'+(editorRoomId?':'+editorRoomId:'');}
function editorDB(){return editorDBPromise??=new Promise((resolve,reject)=>{const r=indexedDB.open('sceneforge-editor-local',1);r.onupgradeneeded=()=>r.result.createObjectStore('drafts');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function editorDraftIO(mode,value){const db=await editorDB();return new Promise((resolve,reject)=>{const tx=db.transaction('drafts',mode),store=tx.objectStore('drafts'),r=mode==='readonly'?store.get(editorRoomId||'current'):store.put(value,editorRoomId||'current');tx.oncomplete=()=>resolve(r.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});}
function setEditorSaveStatus(label,state){const n=$('#editorSaveStatus');if(n){n.textContent=label;n.dataset.state=state;}}
async function flushEditorDraft(){
 if(editorSaveBusy||editorRestoring||editorSavedVersion===editorSaveVersion)return;
 editorSaveBusy=true;const version=editorSaveVersion,payload=clone(projectPayload()),source=assets.map(a=>({...a}));setEditorSaveStatus('Đang lưu…','saving');
 try{
  const media=[];for(const a of source){if(['sample0','sample1','sample2','music'].includes(a.id)||!a.url||a.missing)continue;
   if(!/^(blob:|data:)/.test(a.url))throw Error('Tư liệu bên ngoài chưa thể lưu ngoại tuyến.');
   let file=editorBlobCache.get(a.url);if(!file){const response=await fetch(a.url);if(!response.ok)throw Error('Không đọc được '+a.name);file=await response.blob();editorBlobCache.set(a.url,file);}
   media.push({id:a.id,file,poster:a.poster||null});
  }
  await editorDraftIO('readwrite',{payload,media,savedAt:Date.now()});editorSavedVersion=version;
  if(editorRoomId)parent.postMessage({type:'sceneforge:room-editor-saved',roomId:editorRoomId,itemCount:items.length,assetCount:assets.length},location.origin);
  localStorage.setItem(editorDraftMetaKey(),JSON.stringify(payload));draftCandidate=JSON.stringify(payload);
  const missing=source.filter(a=>a.missing||!a.url).length;setEditorSaveStatus(missing?'Đã lưu · thiếu '+missing+' tệp':'✓ Đã lưu trên máy',missing?'error':'saved');
  const used=new Set(source.map(a=>a.url));for(const key of editorBlobCache.keys())if(!used.has(key))editorBlobCache.delete(key);
 }catch(error){setEditorSaveStatus('Chưa lưu được','error');const n=$('#editorSaveStatus');if(n)n.title=error?.name==='QuotaExceededError'?'Bộ nhớ trình duyệt đầy. Hãy giải phóng dung lượng.':String(error.message||error);}
 finally{editorSaveBusy=false;if(editorSaveVersion!==version)editorSaveTimer=setTimeout(flushEditorDraft,250);}
}
scheduleDraft=function(){if(booting||editorRestoring)return;editorSaveVersion++;clearTimeout(editorSaveTimer);setEditorSaveStatus('Chưa lưu thay đổi','pending');editorSaveTimer=setTimeout(flushEditorDraft,700);};
const metadataRestore=$('#restoreDraft').onclick;
$('#restoreDraft').onclick=async()=>{
 if(editorSaveBusy||recording){notify('Đợi thao tác lưu/xuất hoàn tất.');return;}
 let saved;try{saved=await editorDraftIO('readonly');}catch{}
 if(!saved?.payload){metadataRestore();return;}
 pause();editorRestoring=true;clearTimeout(editorSaveTimer);
 try{
  const json=JSON.stringify(saved.payload);await $('#projectFile').onchange({target:{files:[new File([json],'draft.json',{type:'application/json'})],value:''}});
  for(const entry of saved.media||[]){const asset=getAsset(entry.id);if(!asset)continue;const url=URL.createObjectURL(entry.file);Object.assign(asset,{url,poster:asset.kind==='image'?url:entry.poster,missing:false});editorBlobCache.set(url,entry.file);}
  nodes.forEach(n=>{releaseAudioRoute(n);n.remove();});nodes.clear();render();$('#restoreDraft').hidden=true;editorSavedVersion=editorSaveVersion;setEditorSaveStatus('✓ Đã khôi phục cả tư liệu','saved');notify('Đã khôi phục bản dựng và các tệp video/âm thanh lưu trên máy này.');
 }catch(error){setEditorSaveStatus('Khôi phục chưa thành công','error');notify(error.message||'Không đọc được bản dựng.');}
 finally{editorRestoring=false;}
};
document.addEventListener('visibilitychange',()=>{if(document.hidden){clearTimeout(editorSaveTimer);flushEditorDraft();}});
window.addEventListener('beforeunload',e=>{if(editorSavedVersion!==editorSaveVersion){e.preventDefault();e.returnValue='';}});
