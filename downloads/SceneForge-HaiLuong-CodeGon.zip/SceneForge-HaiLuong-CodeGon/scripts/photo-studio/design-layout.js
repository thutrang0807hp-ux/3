// Keep the supplied two-row diagram. Saved user positions are never reset automatically.
let selectedPhotoNode=null,photoLayoutUndo=null;
const selectBeforeDesign=selectNode;selectNode=function(n){selectedPhotoNode=n?.dataset.node||null;selectBeforeDesign(n);};
const renderBeforeDesignLayout=render;render=function(){
 renderBeforeDesignLayout();if(!loaded)return;
 const inputs=['refs','bank'].map(id=>$('[data-node='+id+']')).filter(Boolean);
 const row=Math.max(690,...inputs.map(n=>n.offsetTop+n.offsetHeight+75));
 for(const id of ['formula','script','voice'])if(!draft.positions[id]){const n=$('[data-node='+id+']');if(n)n.style.top=row+'px';}
 // Place only the new node in free space; never reset existing saved positions.
 if(!draft.positions.storyboard){const n=$('[data-node=storyboard]');if(n){let y=row;const x=positions.storyboard[0],gap=45,others=$$('.photoNode').filter(el=>el!==n);for(let i=0;i<others.length+1;i++){const hits=others.filter(el=>x<el.offsetLeft+el.offsetWidth+gap&&x+n.offsetWidth+gap>el.offsetLeft&&y<el.offsetTop+el.offsetHeight+gap&&y+n.offsetHeight+gap>el.offsetTop);if(!hits.length)break;y=Math.max(...hits.map(el=>el.offsetTop+el.offsetHeight+gap));}n.style.top=y+'px';}}
 if(selectedPhotoNode){const n=$('[data-node='+selectedPhotoNode+']');if(n)selectBeforeDesign(n);}
 requestAnimationFrame(drawWires);
};
const arrangePhoto=document.createElement('button');arrangePhoto.id='arrangePhoto';arrangePhoto.textContent='Xếp như mẫu';arrangePhoto.title='Xếp các node và Storyboard; có thể hoàn tác';$('#photoZoom').append(arrangePhoto);
const undoPhoto=document.createElement('button');undoPhoto.id='undoPhotoLayout';undoPhoto.textContent='↶';undoPhoto.title='Hoàn tác xếp node';undoPhoto.hidden=true;$('#photoZoom').append(undoPhoto);
arrangePhoto.onclick=()=>{photoLayoutUndo=structuredClone(draft.positions);draft.positions={};render();fit();scheduleSave();undoPhoto.hidden=false;};
undoPhoto.onclick=()=>{if(!photoLayoutUndo)return;draft.positions=photoLayoutUndo;photoLayoutUndo=null;render();fit();scheduleSave();undoPhoto.hidden=true;};
