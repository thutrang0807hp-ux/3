"""Read-only source audit of both workflows; no models, generated build or account data."""
from pathlib import Path
import difflib,hashlib,json,subprocess,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/SceneForge-HaiLuong-CodeGon.zip'
PREFIX='SceneForge-HaiLuong-CodeGon/'
BASELINE=ROOT/'artifacts/SceneForge-before-prompt-music-fix.zip'
files={}
def add(p):
 if isinstance(p,str):p=ROOT/p
 files[p.relative_to(ROOT).as_posix()]=p.read_bytes()
for folder in ['scripts/workflow','scripts/photo-studio','scripts/shared']:
 for p in (ROOT/folder).iterdir():
  if p.suffix in {'.js','.css','.html'}:add(p)
# Whole shell modules are required to see dispatch overrides and recipe reuse.
for p in (ROOT/'scripts/app-shell').glob('*.js'):add(p)
for name in ['app.js','workflow-import.js','timeline-export.js','ffmpeg-export.js','room-shell.js','editor-storage.js','editor-integration.js']:
 add('scripts/native-preview/'+name)
for p in (ROOT/'local_engine').glob('*.py'):
 if not p.name.startswith('check_'):add(p)
for name in ['scripts/demo-web/build.py','scripts/workflow/build.py',
 'scripts/workflow-review/package_two_flows.py','scripts/app-shell/check_workflow_audit.py','scripts/app-shell/check_workflow_navigation.py',
 'local_engine/check_direct_workflow.py','local_engine/check_reference_voice_ui.py','local_engine/check_analysis_batches.py','local_engine/check_analysis_batches_ui.py',
 'local_engine/check_gemini_chat_routes.py','local_engine/check_photo_prompt_resume.py','local_engine/check_photo_story_production.py','local_engine/check_photo_edit_safety.py',
 'local_engine/check_photo_toolbar.py','local_engine/check_photo_clip_flow.py','local_engine/check_photo_review_fixes.py','local_engine/check_library_ack_recovery_ui.py',
 'local_engine/check_prompt_repair_music.py','docs/prompt-music-repair.md','local_engine/speech_guard.json','docs/two-workflow-audit.md']:
 add(name)
files['review/CHECKS.json']=(ROOT/'artifacts/prompt-music-fix-checks.json').read_bytes()
for p in (ROOT/'artifacts/prompt-music-fix-tests').glob('*.log'):
 if p.name!='local_engine.log':files['review/logs/'+p.name]=p.read_bytes()
with zipfile.ZipFile(BASELINE)as z:
 assert z.testzip()is None
 old={n.split('/',1)[1]:z.read(n)for n in z.namelist()if'/'in n}
changes=[];patch=[]
for name,raw in sorted(files.items()):
 if not name.startswith(('scripts/','local_engine/'))or Path(name).suffix not in {'.js','.py','.css'}:continue
 before=old.get(name,b'')
 if before==raw:continue
 changes.append({'path':name,'kind':'modified'if name in old else'added','before_sha256':hashlib.sha256(before).hexdigest()if before else None,'after_sha256':hashlib.sha256(raw).hexdigest()})
 patch.extend(difflib.unified_diff(before.decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile='a/'+name if name in old else'/dev/null',tofile='b/'+name))
raw_patch=''.join(patch).encode()
# Verify actual patch application to the previous published source, not a prose diff.
with tempfile.TemporaryDirectory(prefix='sf-two-flow-review-')as tmp:
 base=Path(tmp)
 for row in changes:
  if row['path']in old:
   p=base/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(old[row['path']])
 p=base/'changes.patch';p.write_bytes(raw_patch)
 subprocess.run(['git','apply','--check',str(p)],cwd=base,check=True)
 subprocess.run(['git','apply',str(p)],cwd=base,check=True)
 for row in changes:assert(base/row['path']).read_bytes()==files[row['path']],row['path']
files['review/THAY_DOI.patch']=raw_patch
files['review/CHANGED_FILES.json']=(json.dumps({'baseline_source_archive_sha256':hashlib.sha256(BASELINE.read_bytes()).hexdigest(),'baseline_published_runtime':'18d0e4e','current_snapshot':'prompt-music-repair-20261026','patch_applied_and_verified':True,'changes':changes},ensure_ascii=False,indent=2)+'\n').encode()
files['START_HERE.md']='''# Rà hai luồng SceneForge — code gọn

Đọc `docs/prompt-music-repair.md` trước, sau đó `docs/two-workflow-audit.md`: luồng thực, việc giữ/bỏ/gom, lỗi đã sửa và giới hạn.
Sau đó đọc `review/CHECKS.json`, `review/CHANGED_FILES.json`, `review/THAY_DOI.patch`.
Patch đã áp thử trên mã nguồn gói phát hành trước và so byte với từng file hiện tại.

`workflow`: Video mẫu. `photo-studio`: Ảnh & ý tưởng. `shared`: hợp đồng chung.
Theo đúng thứ tự nạp trong `scripts/demo-web/build.py` và `scripts/workflow/build.py`;
đọc toàn bộ override trước khi kết luận hàm đầu tiên là hàm đang chạy.
Backend giữ nguyên module để truy vết tài khoản/ledger/storage/editor. Không minify code.

Gói này để đọc/đánh giá, KHÔNG phải bộ cài. Không có media, model, venv, SDK, mật khẩu,
cookie hoặc dự án. File không kèm do bỏ tài nguyên không phải lỗi app đầy đủ.
Các tests đã chạy trên app đầy đủ, cần Chromium/media/backend khi chạy lại.
Không chứng nhận Windows hoặc tài khoản thật. Muse hiện là muse.ai, chưa phải Meta AI.

Đề nghị đánh giá: ưu tiên lỗi tái hiện gửi trùng, gen thừa, nhận sai cảnh/khung/prompt,
trạng thái chưa rõ và mất dữ liệu. Phân biệt thiếu tích hợp thật với vấn đề trình bày.
Báo rõ file/hàm, đầu vào và tác động. Không thêm node/model thay cho kiểm luồng.

Kiểm gói: `python review/verify_package.py` chỉ đọc file và tính SHA-256.
'''.encode()
files['review/verify_package.py']=b'''from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
for row in json.loads((root/'manifest.json').read_text())['files']:
 p=root/row['path'];assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS source manifest; not a runnable application')
'''
manifest={'scope':'read-only audit of reference-video and photo/ideas workflows; not installer','date_local':'2026-10-26','live_provider_verified':False,'source_modified_by_packaging':False,'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(files.items())]}
files['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,b in sorted(files.items()):z.writestr(PREFIX+n,b)
with zipfile.ZipFile(OUT)as z:assert z.testzip()is None
OUT.with_suffix('.zip.sha256').write_text(hashlib.sha256(OUT.read_bytes()).hexdigest()+'  '+OUT.name+'\n')
print(OUT,OUT.stat().st_size,'bytes;',len(changes),'changed files; patch verified')
