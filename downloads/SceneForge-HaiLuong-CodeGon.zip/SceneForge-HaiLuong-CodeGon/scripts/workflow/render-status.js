// A visual-only error preview; never persisted as a real project error.
let errorPreview=new URLSearchParams(location.search).get('demoError')==='1';
function errorPreviewBox(){return '<div class="renderErrorBox errorPreview" role="status"><strong>⚠ Không tạo được video</strong><span>Kết nối bị gián đoạn. Vui lòng thử lại.</span><small>Lỗi minh họa · không gửi render</small><button class="plain" data-action="error-preview">Tắt minh họa</button></div>';}
function focusErrorPreview(){requestAnimationFrame(()=>requestAnimationFrame(()=>{const n=$('.errorPreview')?.closest('.node');if(!n)return;selectCanvasNode(n.id);view.z=Math.min(1,($('#viewport').clientWidth-44)/n.offsetWidth);view.x=($('#viewport').clientWidth-n.offsetWidth*view.z)/2-n.offsetLeft*view.z;view.y=34-n.offsetTop*view.z;applyView();}));}
actions['error-preview']=()=>{errorPreview=!errorPreview;render();if(errorPreview)focusErrorPreview();};
// Keep errors inline; old task records remain stored but have no management UI.
const renderErrorNames={network:'Lỗi kết nối',session:'Hết phiên đăng nhập',quota:'Hết hạn mức',rejected:'Yêu cầu bị từ chối',other:'Tạo clip bị lỗi'};
function renderStatus(s){const errors=[];
 if(s.renderError){const error=s.renderError;errors.push(typeof error==='string'?error:String(error.message||'Không tạo được clip.'));}
 for(const p of clipParts(s)){const t=s.renderTasks?.[p.id]?.at(-1);if(t?.status!=='error'||(s.clearedRenderErrors?.[p.id]??-1)>=(t.updatedAt||t.createdAt||0))continue;const label=clipParts(s).length>1?'Clip '+(s.index+1)+p.id+': ':'';errors.push(label+(t.message||renderErrorNames[t.errorCode]||'Không tạo được clip.'));}
 // Watermark failure is a non-blocking yellow retry on the affected clip.
 if(s.importError)errors.push('Không nhập được clip: '+s.importError.message);
 const preview=errorPreview&&s===project.scenes[0]?errorPreviewBox():'';
 if(!errors.length)return preview;
 return '<div class="renderErrorBox" role="alert"><strong>⚠ Video bị lỗi</strong>'+[...new Set(errors)].map(message=>'<span>'+esc(message)+'</span>').join('')+'</div>'+preview;
}
const clipWithoutStatus=clipNode;
clipNode=function(s,i,y){return clipWithoutStatus(s,i,y).replace('<div class="clipVersion">',renderStatus(s)+'<div class="clipVersion">');};
const completeWithoutStatus=completedNode;
completedNode=function(s,i,y){return completeWithoutStatus(s,i,y).replace('</article>',renderStatus(s)+'</article>');};
const importWithoutErrorClear=addClip;
addClip=async function(file,target){const projectId=project.id,s=project.scenes.find(s=>s.id===target?.id),before=s?.clips.length||0;await importWithoutErrorClear(file,target);if(project.id!==projectId||!s||s.clips.length===before)return;s.clearedRenderErrors??={};s.clearedRenderErrors[s.clips.at(-1).part]=Date.now();s.renderError=null;save();render();};
// User-entered account observations are shared locally, never treated as provider data.
const usageKey='sceneforge-manual-usage-v1';let usageRecord={flow:null,ai:null,aiUnit:'lượt',updatedAt:null};
try{const r=JSON.parse(localStorage.getItem(usageKey)||'null');if(r&&typeof r==='object')for(const k of ['flow','ai','updatedAt'])if(r[k]===null||typeof r[k]==='number'&&Number.isFinite(r[k])&&r[k]>=0)usageRecord[k]=r[k];}catch{}
function estimatedCredits(){let value=0,missing=false;for(const s of project.scenes){const count=clipParts(s).filter(p=>!chosenClip(s,p.id)).length;if(!count)continue;const cost=project.settings?.costs?.[s.model];if(typeof cost!=='number'||!Number.isFinite(cost)||cost<0)missing=true;else value+=cost*count;}return{value,missing};}
function updateUsage(){const e=estimatedCredits();$('#usageStrip').innerHTML='<button data-action="usage">Hạn mức ⌄</button><button class="plain" data-action="error-preview">'+(errorPreview?'Tắt lỗi mẫu':'Xem lỗi mẫu')+'</button><span>Flow: <b>'+ (usageRecord.flow===null?'chưa biết':esc(usageRecord.flow)+' credit · tự nhập')+'</b></span><span>AI phân tích: <b>'+(usageRecord.ai===null?'chưa biết':esc(usageRecord.ai)+' lượt · tự nhập')+'</b></span><small>'+ (usageRecord.updatedAt?'Tự cập nhật '+new Date(usageRecord.updatedAt).toLocaleString('vi-VN'):'Chưa kết nối · chưa xác minh')+'</small><button class="plain" data-action="costs">Dự kiến: '+(e.missing?'chưa đủ giá':e.value+' credit')+' ⓘ</button>';}
actions.usage=()=>{const e=estimatedCredits();modal('Hạn mức & credit','<div class="detailNotice">Flow và AI chưa kết nối. Chưa đọc được số dư, hạn mức thật, thời điểm reset hay phí của lần lỗi. Số bên dưới do bạn tự nhập, không được tự trừ khi chuẩn bị/thử lại.</div><label class="compactField">Flow · số credit còn lại tự kiểm tra<input id="usageFlow" type="number" min="0" step="any" placeholder="Chưa biết" value="'+(usageRecord.flow??'')+'"></label><label class="compactField">AI phân tích · số lượt còn lại tự kiểm tra<input id="usageAI" type="number" min="0" step="1" placeholder="Chưa biết" value="'+(usageRecord.ai??'')+'"></label><p>Chỉ nhập số lượt nếu nhà cung cấp có hiển thị. Hạn mức token/RPM/chi phí không tự quy đổi thành lượt.</p><p>Credit dự kiến cho các phần chưa có clip: <b>'+(e.missing?'Chưa đủ đơn giá':e.value+' credit')+'</b>. Dùng mức bạn nhập trong “Credit tham khảo”; không phải báo giá đã xác minh, không bao gồm lần thử lại hoặc tạo thêm phiên bản.</p><p>Ghi nhận gần nhất: '+(usageRecord.updatedAt?new Date(usageRecord.updatedAt).toLocaleString('vi-VN')+' · tự nhập':'chưa có')+'. Dữ liệu lưu cục bộ trên trình duyệt, dùng chung giữa các dự án.</p>','<button data-action="usage-clear">Xóa số tự nhập</button><button class="primary" data-action="usage-save">Lưu số tự nhập</button>');};
actions['usage-save']=()=>{const next={};for(const[key,id]of [['flow','usageFlow'],['ai','usageAI']]){const raw=$('#'+id).value.trim(),n=raw===''?null:Number(raw);if(n!==null&&(!Number.isFinite(n)||n<0||key==='ai'&&!Number.isInteger(n))){toast('Nhập số không âm; lượt AI phải là số nguyên, hoặc để trống.');return;}next[key]=n;}next.updatedAt=Date.now();try{localStorage.setItem(usageKey,JSON.stringify(next));}catch{toast('Trình duyệt không lưu được hạn mức; chưa áp dụng.');return;}usageRecord=next;closeModal();updateUsage();};
actions['usage-clear']=()=>{try{localStorage.removeItem(usageKey);}catch{toast('Không xóa được dữ liệu lưu.');return;}usageRecord={flow:null,ai:null,updatedAt:null};closeModal();updateUsage();};
const chromeWithoutUsage=updateChrome;updateChrome=function(){chromeWithoutUsage();updateUsage();};

const renderWithoutErrorPreview=render;
render=function(){renderWithoutErrorPreview();if(errorPreview&&!project.scenes.length)$('#empty-clips .nodeBody')?.insertAdjacentHTML('beforeend',errorPreviewBox());};
const initWithoutErrorPreview=init;
init=async function(){await initWithoutErrorPreview();if(errorPreview){$('#workflowChooser').hidden=true;document.body.classList.remove('choosing-workflow');render();focusErrorPreview();}};
