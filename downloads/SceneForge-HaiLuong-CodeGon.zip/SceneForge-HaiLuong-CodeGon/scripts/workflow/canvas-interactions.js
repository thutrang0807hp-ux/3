// Route speech along the nearest clear horizontal corridor, never the canvas bottom.
function voiceWireRoute(a,b){
 const x=a.offsetLeft+a.offsetWidth,y=a.offsetTop+a.offsetHeight/2,xx=b.offsetLeft,yy=b.offsetTop+b.offsetHeight/2;
 const left=x+18,right=xx-18,pad=12;
 const obstacles=$$('.node').filter(n=>n!==a&&n!==b).map(n=>({l:n.offsetLeft-pad,r:n.offsetLeft+n.offsetWidth+pad,t:n.offsetTop-pad,b:n.offsetTop+n.offsetHeight+pad}));
 const crosses=(x1,y1,x2,y2)=>obstacles.some(o=>x1===x2?x1>o.l&&x1<o.r&&Math.max(y1,y2)>o.t&&Math.min(y1,y2)<o.b:y1>o.t&&y1<o.b&&Math.max(x1,x2)>o.l&&Math.min(x1,x2)<o.r);
 const candidates=[y,yy,...obstacles.flatMap(o=>[o.t-2,o.b+2])].filter(v=>v>=24).sort((u,v)=>(Math.abs(y-u)+Math.abs(yy-u))-(Math.abs(y-v)+Math.abs(yy-v)));
 const clear=v=>!crosses(left,y,left,v)&&!crosses(left,v,right,v)&&!crosses(right,v,right,yy);
 const refTops=$$('.node[id^=ref-]').map(n=>n.offsetTop-pad);
 const topOfRefs=refTops.length?Math.min(...refTops):Infinity;
 const corridor=candidates.find(v=>v<=topOfRefs&&clear(v))??candidates.find(clear);
 if(corridor!==undefined)return 'M '+x+' '+y+' L '+left+' '+y+' L '+left+' '+corridor+' L '+right+' '+corridor+' L '+right+' '+yy+' L '+xx+' '+yy;
 // Cards may be placed arbitrarily: use a direct connector behind their opaque surfaces.
 const bend=Math.max(30,Math.abs(xx-x)*.4);return 'M '+x+' '+y+' C '+(x+bend)+' '+y+', '+(xx-bend)+' '+yy+', '+xx+' '+yy;
}

// Original canvas interactions. Node coordinates use world space, independent of zoom.
let nodeGesture=null,nodeDragFrame=0,canvasLayoutFrame=0,suppressNodeClickUntil=0;
function savedNodePositions(){if(!project.layout||typeof project.layout!=='object')project.layout={};if(!project.layout.nodes||typeof project.layout.nodes!=='object')project.layout.nodes={};return project.layout.nodes;}
function nodeRect(node,x=node.offsetLeft,y=node.offsetTop){return{x,y,width:node.offsetWidth,height:node.offsetHeight,id:node.id};}
function rectsTouch(a,b,gap=22){return a.x<b.x+b.width+gap&&a.x+a.width+gap>b.x&&a.y<b.y+b.height+gap&&a.y+a.height+gap>b.y;}
function nearestFree(node,x,y,obstacles){
 const origin={x:Math.max(24,Math.min(30000,x)),y:Math.max(34,Math.min(50000,y))},pending=[origin],seen=new Set();let count=0;
 while(pending.length&&count++<1500){pending.sort((a,b)=>((a.x-origin.x)**2+(a.y-origin.y)**2)-((b.x-origin.x)**2+(b.y-origin.y)**2));const p=pending.shift(),key=Math.round(p.x)+','+Math.round(p.y);if(seen.has(key))continue;seen.add(key);const rect=nodeRect(node,p.x,p.y),hits=obstacles.filter(o=>rectsTouch(rect,o));if(!hits.length)return p;
  for(const o of hits){for(const candidate of [{x:o.x-node.offsetWidth-24,y:p.y},{x:o.x+o.width+24,y:p.y},{x:p.x,y:o.y-node.offsetHeight-24},{x:p.x,y:o.y+o.height+24}])if(candidate.x>=24&&candidate.y>=34&&candidate.x<=30000&&candidate.y<=50000)pending.push(candidate);}
 }
 return{x:origin.x,y:Math.max(34,...obstacles.map(o=>o.y+o.height+28))};
}
function updateWorldBounds(){const list=$$('.node');worldWidth=Math.max(1720,...list.map(n=>n.offsetLeft+n.offsetWidth+60));worldHeight=Math.max(1360,...list.map(n=>n.offsetTop+n.offsetHeight+90));$('#world').style.width=worldWidth+'px';$('#world').style.height=worldHeight+'px';$('#wires').style.height=worldHeight+'px';$('#wires').setAttribute('height',worldHeight);}
const autoRowsBeforeMove=layoutRows;
layoutRows=function(){
 if(nodeGesture)return;
 for(const n of $$('.node')){if(n.dataset.autoX)n.style.left=n.dataset.autoX;if(n.dataset.autoY)n.style.top=n.dataset.autoY;}
 autoRowsBeforeMove();
 const saved=savedNodePositions(),nodes=$$('.node'),placed=[];
 // Respect manually placed cards first; automatic cards move aside when content grows.
 const order=[...nodes.filter(n=>saved[n.id]),...nodes.filter(n=>!saved[n.id])];
 for(const n of order){const p=saved[n.id],x=Number.isFinite(p?.x)?p.x:n.offsetLeft,y=Number.isFinite(p?.y)?p.y:n.offsetTop,point=nearestFree(n,x,y,placed);n.style.left=Math.round(point.x)+'px';n.style.top=Math.round(point.y)+'px';if(p&&(Math.abs(point.x-x)>.5||Math.abs(point.y-y)>.5))saved[n.id]={x:point.x,y:point.y};placed.push(nodeRect(n));}
 updateWorldBounds();
};
function requestCanvasLayout(){if(nodeGesture||canvasLayoutFrame)return;canvasLayoutFrame=requestAnimationFrame(()=>{canvasLayoutFrame=0;layoutRows();drawWires();paintMinimap();});}
const nodeResizeObserver=new ResizeObserver(()=>requestCanvasLayout());
function observeNodeSizes(){syncCanvasSelection();nodeResizeObserver.disconnect();for(const n of $$('.node')){n.tabIndex=0;n.dataset.autoX=n.style.left;n.dataset.autoY=n.style.top;nodeResizeObserver.observe(n);}}
const renderBeforeMoving=render;
render=function(){if(nodeGesture)finishNodeGesture(true);renderBeforeMoving();observeNodeSizes();};
function paintNodeGesture(){nodeDragFrame=0;const g=nodeGesture;if(!g||!g.moved)return;g.node.style.left=Math.round(g.target.x)+'px';g.node.style.top=Math.round(g.target.y)+'px';const obstacles=$$('.node').filter(n=>n!==g.node).map(n=>nodeRect(n));g.node.classList.toggle('nodeCollision',obstacles.some(r=>rectsTouch(nodeRect(g.node),r)));updateWorldBounds();drawWires();paintMinimap();}
function finishNodeGesture(cancel=false){
 const g=nodeGesture;if(!g)return;cancelAnimationFrame(nodeDragFrame);nodeDragFrame=0;
 if(!cancel&&g.moved)paintNodeGesture();
 nodeGesture=null;g.node.classList.remove('nodeMoving','nodeCollision');document.body.classList.remove('moving-node');
 if(cancel||!g.moved){g.node.style.left=g.left+'px';g.node.style.top=g.top+'px';}
 else{const obstacles=$$('.node').filter(n=>n!==g.node).map(n=>nodeRect(n)),p=nearestFree(g.node,g.target.x,g.target.y,obstacles);g.node.style.left=Math.round(p.x)+'px';g.node.style.top=Math.round(p.y)+'px';savedNodePositions()[g.node.id]={x:Math.round(p.x),y:Math.round(p.y)};save();if(Math.hypot(p.x-g.target.x,p.y-g.target.y)>4)toast('Đã đặt node vào vùng trống cạnh điểm thả để tránh đè nhau.');}
 if(g.moved)suppressNodeClickUntil=performance.now()+200;
 try{$('#viewport').releasePointerCapture(g.pointer);}catch{}
 updateWorldBounds();drawWires();paintMinimap();
}
$('#viewport').addEventListener('pointerdown',e=>{
 if(e.button===0&&!space){const card=e.target.closest('.node');selectCanvasNode(card?.id||null);}
 const node=e.target.closest('.node');if(!node||e.target.closest('button,input,textarea,select,a,video,audio,label,summary,[contenteditable=true],[role=button]')||space||e.button!==0)return;
 const scroll=e.target.closest('.scriptSummary,.sceneRows');if(scroll&&scroll.scrollHeight>scroll.clientHeight&&(e.pointerType==='touch'||e.clientX>=scroll.getBoundingClientRect().right-16))return;
 e.preventDefault();e.stopImmediatePropagation();
 nodeGesture={node,pointer:e.pointerId,x:e.clientX,y:e.clientY,left:node.offsetLeft,top:node.offsetTop,z:view.z,moved:false,target:{x:node.offsetLeft,y:node.offsetTop}};
 // Capture after the drag threshold, so normal body clicks still reach their actions.
},true);
$('#viewport').addEventListener('pointermove',e=>{const g=nodeGesture;if(!g||g.pointer!==e.pointerId)return;e.preventDefault();e.stopImmediatePropagation();const dx=e.clientX-g.x,dy=e.clientY-g.y;if(!g.moved&&Math.hypot(dx,dy)<4)return;if(!g.moved)$('#viewport').setPointerCapture(e.pointerId);g.moved=true;g.node.classList.add('nodeMoving');document.body.classList.add('moving-node');g.target={x:Math.max(24,Math.min(30000,g.left+dx/g.z)),y:Math.max(34,Math.min(50000,g.top+dy/g.z))};if(!nodeDragFrame)nodeDragFrame=requestAnimationFrame(paintNodeGesture);},true);
$('#viewport').addEventListener('pointerup',e=>{if(!nodeGesture)return;e.stopImmediatePropagation();finishNodeGesture(false);},true);
$('#viewport').addEventListener('pointercancel',e=>{if(!nodeGesture)return;e.stopImmediatePropagation();finishNodeGesture(true);},true);
$('#viewport').addEventListener('lostpointercapture',()=>{if(nodeGesture)finishNodeGesture(true);});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&nodeGesture){e.preventDefault();e.stopImmediatePropagation();finishNodeGesture(true);}},true);
window.addEventListener('blur',()=>finishNodeGesture(true));
document.addEventListener('click',e=>{if(performance.now()<suppressNodeClickUntil&&e.target.closest('#viewport')){e.preventDefault();e.stopImmediatePropagation();}},true);
$('#viewport').addEventListener('wheel',e=>{if(nodeGesture){e.preventDefault();e.stopImmediatePropagation();}},{capture:true,passive:false});
window.addEventListener('resize',requestCanvasLayout);
actions['arrange-nodes']=()=>{if(nodeGesture)finishNodeGesture(true);project.layout={nodes:{}};layoutRows();drawWires();paintMinimap();fit();save();toast('Đã xếp lại các node; không thay prompt, clip hay lời thoại.');};

// Selection is local UI state, independent of scene approval and saved positions.
let selectedCanvasNode=null,selectionProject=null;
function syncCanvasSelection(){if(selectionProject!==project.id){selectionProject=project.id;selectedCanvasNode=null;}if(selectedCanvasNode&&!document.getElementById(selectedCanvasNode))selectedCanvasNode=null;for(const n of $$('.node'))n.classList.toggle('nodeSelected',n.id===selectedCanvasNode);for(const marker of $$('#minimap i'))marker.classList.toggle('minimapSelected',marker.dataset.nodeId===selectedCanvasNode);for(const wire of $$('#wires .wire'))wire.classList.toggle('wireSelected',!!selectedCanvasNode&&(wire.dataset.from===selectedCanvasNode||wire.dataset.to===selectedCanvasNode));}
function selectCanvasNode(id){selectionProject=project.id;selectedCanvasNode=id;syncCanvasSelection();}
const drawWiresBeforeSelection=drawWires;
drawWires=function(){drawWiresBeforeSelection();syncCanvasSelection();};
$('#viewport').addEventListener('focusin',e=>{const n=e.target.closest('.node');if(n)selectCanvasNode(n.id);});
