"""Build the original node workflow; reference designs are not executable code."""
from pathlib import Path
import json
import subprocess
import hashlib
subprocess.run(['python', str(Path(__file__).resolve().parent.parent/'watermark-builder/build.py')],check=True)
root=Path(__file__).resolve().parents[2];here=Path(__file__).resolve().parent
preview=(root/'preview.html').read_text()
def literal(marker):
 at=preview.index(marker)+len(marker)
 return json.JSONDecoder().raw_decode(preview[at:])[0]
sample={'frames':literal('const DEMO_FRAMES='),'video':literal('const DEMO_VIDEO=')}
html=(here/'template.html').read_text().replace('__CSS__',(here/'style.css').read_text()+'\n'+(here/'package5.css').read_text()+'\n'+(here/'cpu-analysis.css').read_text()+'\n'+(here/'local-ai.css').read_text()+'\n'+(here/'package6.css').read_text()).replace('__SAMPLE__',json.dumps(sample)).replace('__JS__',(root/'scripts/shared/provider-receipts.js').read_text()+'\n'+(root/'scripts/shared/clip-planning.js').read_text()+'\n'+(root/'scripts/shared/image-quality.js').read_text()+'\n'+(root/'scripts/app-shell/library-portable.js').read_text()+'\n'+(here/'app.js').read_text().replace('init();\n', (here/'branches.js').read_text()+'\n'+(here/'voice-over.js').read_text()+'\n'+(here/'render-status.js').read_text()+'\n'+(here/'watermark.js').read_text().replace('__WATERMARK_HASH__',hashlib.sha256((root/'dist/web-demo/watermark/engine.js').read_bytes()).hexdigest()[:12])+'\n'+(here/'canvas-interactions.js').read_text()+'\n'+(here/'room-shell.js').read_text()+'\n'+(here/'package5.js').read_text()+'\n'+(here/'analysis-ai.js').read_text()+'\n'+(here/'cpu-analysis.js').read_text()+'\n'+(here/'local-ai.js').read_text()+'\n'+(here/'analysis-v3.js').read_text()+'\n'+(here/'frame-v3.js').read_text()+'\n'+(here/'package6.js').read_text()+'\n'+(here/'job-lifecycle.js').read_text()+'\n'+(here/'package6-analysis.js').read_text()+'\n'+(here/'reference-production.js').read_text()+'\n'+(here/'speech-captions.js').read_text()+'\n'+(here/'topbar.js').read_text()+'\n'+(here/'local-translation.js').read_text()+'\n'+(here/'chat-translation.js').read_text()+'\n'+(here/'direct-providers.js').read_text()+'\n'+(here/'reference-prompts.js').read_text()+'\n'+(here/'analysis-batches.js').read_text()+'\n'+(here/'latest-approval.js').read_text()+'\n'+(here/'clip-planning.js').read_text()+'\ninit();\n'))
(root/'dist/web-demo/workflow.html').write_text(html)
print('Built node workflow:',root/'dist/web-demo/workflow.html')
