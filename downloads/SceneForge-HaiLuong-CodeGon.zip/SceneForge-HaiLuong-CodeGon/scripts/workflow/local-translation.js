const m2mLanguageCodes='af am ar ast az ba be bg bn br bs ca ceb cs cy da de el en es et fa ff fi fr fy ga gd gl gu ha he hi hr ht hu hy id ig ilo is it ja jv ka kk km kn ko lb lg ln lo lt lv mg mk ml mn mr ms my ne nl no ns oc or pa pl ps pt ro ru sd si sk sl so sq sr ss su sv sw ta th tl tn tr uk ur uz vi wo xh yi yo zh zu'.split(' ');
const m2mLanguageName=code=>{try{return new Intl.DisplayNames(['vi'],{type:'language'}).of(code)||code;}catch{return code;}};
// Local translation preserves source lines, times, manual rewrites and generated clips.
let localTranslationBusy=false;
const scriptBeforeLocalTranslation=scriptDialog;
scriptDialog=function(){scriptBeforeLocalTranslation();const toolbar=$('.scriptToolbar');if(!toolbar)return;toolbar.insertAdjacentHTML('afterbegin','<button class="primary" data-action="local-translate" '+(!project.script.some(l=>l.original?.trim())||localTranslationBusy?'disabled':'')+'>Dịch Việt · local</button>');};
actions.script=()=>scriptDialog();
actions['local-translate']=async()=>{
 if(localTranslationBusy)return;
 const language=project.analysis.local?.result?.speech?.language||null;
 modal('Dịch lời sang tiếng Việt · CPU','<p>Model dịch local, không gọi Gemini hay API trả phí. M2M100 dùng một model, dịch thẳng từ ngôn ngữ nguồn sang Việt; cần rà lại tên sản phẩm và ý nghĩa.</p><label>Ngôn ngữ lời gốc<select id="localTranslateLanguage"><option value="auto">Tự lấy từ Whisper</option>'+m2mLanguageCodes.map(code=>'<option value="'+code+'">'+esc(m2mLanguageName(code))+'</option>').join('')+'</select></label><label class="checkLabel"><input id="localTranslateReplace" type="checkbox"> Dịch lại cả câu đã có bản dịch</label><p>Giữ lời gốc, mốc thời gian và lời mới mày đã sửa. Chỉ cập nhật cột Dịch sát sau khi xem và áp dụng.</p><p id="localTranslateStatus" role="status"></p>','<button data-action="close-modal">Để sau</button><button id="runLocalTranslate" class="primary">Dịch trên máy</button>');$('#localTranslateLanguage').value='auto';
 $('#runLocalTranslate').onclick=async()=>{
  const button=$('#runLocalTranslate'),message=$('#localTranslateStatus');
  try{
   const lines=project.script.filter(l=>l.original?.trim()&&($('#localTranslateReplace').checked||!l.translation?.trim())).map(l=>({id:l.id,original:l.original}));if(!lines.length)throw Error('Không có câu cần dịch. Chọn dịch lại nếu muốn thay bản dịch cũ.');
   const selectedLanguage=$('#localTranslateLanguage').value;const sourceLanguage=selectedLanguage==='auto'?language:selectedLanguage;if(!sourceLanguage)throw Error('Chưa có ngôn ngữ Whisper. Chọn ngôn ngữ lời gốc trong danh sách.');
   const status=await workflowLocalRequest('translation/local/status');if(!status.available)throw Error('Chưa cài/xác minh model M2M100. Chạy local_engine/install-translation.bat. Không dùng API thay thế.');
   const sourceId=project.id,asset=project.source?.asset,signature=JSON.stringify(project.script.map(l=>[l.id,l.original,l.start,l.end,l.translation]));localTranslationBusy=true;button.disabled=true;message.textContent='Đang chờ CPU / dịch trên máy…';
   const result=await workflowLocalRequest('translation/local',{source_language:sourceLanguage,lines});
   if(project.id!==sourceId||project.source?.asset!==asset||JSON.stringify(project.script.map(l=>[l.id,l.original,l.start,l.end,l.translation]))!==signature)throw Error('Bản lời đã thay đổi trong lúc dịch. Chưa áp dụng; chạy lại trên bản mới.');
   if(!Array.isArray(result.lines)||result.lines.length!==lines.length||result.lines.some((r,i)=>r.id!==lines[i].id||r.original!==lines[i].original||typeof r.translation!=='string'||!r.translation.trim()))throw Error('Kết quả dịch không khớp câu nguồn.');
   modal('Rà bản dịch local', '<p>Chưa đổi bản lời. M2M100 dịch trực tiếp sang Việt; nghe đối chiếu trước khi dùng.</p>'+result.lines.map(r=>'<section class="versionCard"><p>'+esc(r.original)+'</p><p>'+esc(r.translation)+'</p></section>').join(''),'<button data-action="close-modal">Chưa áp dụng</button><button id="applyLocalTranslate" class="primary">Áp dụng bản dịch</button>');
   $('#applyLocalTranslate').onclick=async()=>{if(project.id!==sourceId||project.source?.asset!==asset||JSON.stringify(project.script.map(l=>[l.id,l.original,l.start,l.end,l.translation]))!==signature)return toast('Nguồn đã thay đổi, chưa áp dụng bản dịch.');for(const r of result.lines){const line=project.script.find(l=>l.id===r.id);line.translation=r.translation;line.translationProvider='local-m2m100-ct2';}await storeProject();render();scriptDialog();toast('Đã lưu bản dịch local. Lời mới gửi Flow được giữ nguyên.');};
  }catch(error){if(message.isConnected)message.textContent=error.message;else toast(error.message);}finally{localTranslationBusy=false;if(button.isConnected)button.disabled=false;}
 };
};
