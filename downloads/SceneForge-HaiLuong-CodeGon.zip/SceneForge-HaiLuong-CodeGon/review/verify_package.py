from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
for row in json.loads((root/'manifest.json').read_text())['files']:
 p=root/row['path'];assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS source manifest; not a runnable application')
