"""Core dependency setup cache, tied to interpreter/platform and requirements."""
import hashlib,json,platform,subprocess,sys
from pathlib import Path

def main():
 if not (3,11)<=sys.version_info[:2]<(3,14):
  raise SystemExit('SceneForge core requires Python 3.11-3.13. Install Python 3.11 or 3.12, then run start.bat.')
 requirements=Path(__file__).with_name('requirements.txt')
 stamp=Path(sys.prefix)/'sceneforge-core-setup.json'
 identity={'requirements':hashlib.sha256(requirements.read_bytes()).hexdigest(),'python':sys.version,'platform':platform.platform(),'executable':sys.executable}
 repair='--repair'in sys.argv
 try:cached=json.loads(stamp.read_text())==identity
 except (OSError,ValueError):cached=False
 if cached and not repair:
  try:
   subprocess.run([sys.executable,'-c','import fastapi,uvicorn,httpx,cryptography,playwright,PIL,send2trash'],check=True)
   print('Core dependencies ready; skipped reinstall. Use start.bat repair to repair.')
   return
  except subprocess.CalledProcessError:pass
 subprocess.run([sys.executable,'-m','pip','install','-r',str(requirements)],check=True)
 subprocess.run([sys.executable,'-m','pip','check'],check=True)
 temporary=stamp.with_suffix('.tmp');temporary.write_text(json.dumps(identity));temporary.replace(stamp)
if __name__=='__main__':main()
