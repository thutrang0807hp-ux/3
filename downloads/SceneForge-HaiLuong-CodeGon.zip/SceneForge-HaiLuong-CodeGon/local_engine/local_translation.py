"""Local-only translation endpoint; missing models never trigger paid fallback."""
import asyncio,importlib.util,json,sys,tempfile
from pathlib import Path
from fastapi import HTTPException
from .machine_checks import run_command
from .translation_worker import validate_lines, normalize_language, LANGUAGES, MODEL_FOLDER, MODEL_FILES, MODEL_ID

def translation_status(data):
 root=Path(data)/'models/translation'/MODEL_FOLDER
 missing=[name for name in MODEL_FILES if not (root/name).is_file() or not (root/name).stat().st_size]
 installed=all(importlib.util.find_spec(n) is not None for n in ('ctranslate2','sentencepiece'))
 ready=False
 try:
  marker=json.loads((root/'setup-status.json').read_text(encoding='utf-8'))
  rows=marker.get('files',[])
  ready=marker.get('ready') is True and marker.get('model')==MODEL_ID and isinstance(rows,list) and len(rows)==len(MODEL_FILES) and {r['path'] for r in rows}==set(MODEL_FILES) and all(type(r.get('bytes')) is int and r['bytes']>0 and (root/r['path']).is_file() and (root/r['path']).stat().st_size==r['bytes'] for r in rows)
 except (OSError,ValueError,KeyError,TypeError):pass
 return {'available':installed and not missing and ready,'libraries':installed,'models_present':not missing,'verified':ready,'missing':missing,'languages':LANGUAGES,'engine':'M2M100 418M / CTranslate2 CPU int8','model':MODEL_ID,'route':'source → vi','pivot':None,'paid_fallback':False,'note':'Một model đa ngôn ngữ, dịch thẳng sang Việt. Cần rà bản dịch; không tự tải model.'}

def install_local_translation(app,data,lane):
 busy=False
 @app.get('/local-api/translation/local/status')
 async def status():return translation_status(data)
 @app.post('/local-api/translation/local')
 async def run(body:dict):
  nonlocal busy
  try:lines=validate_lines(body.get('lines'))
  except ValueError as error:raise HTTPException(400,str(error))
  try:source=normalize_language(body.get('source_language','zh'))
  except ValueError as error:raise HTTPException(400,str(error))
  if not translation_status(data)['available']:raise HTTPException(409,'Chưa cài/xác minh model M2M100. Chạy install-translation.bat. Không gọi API trả phí thay thế.')
  if busy:raise HTTPException(409,'Đang có lượt dịch local. Chờ lượt hiện tại hoàn tất.')
  busy=True
  try:
   async with lane:
    with tempfile.TemporaryDirectory(prefix='translation-',dir=data) as temporary:
     folder=Path(temporary);input_file=folder/'input.json';output=folder/'output.json'
     input_file.write_text(json.dumps({'lines':lines,'source_language':source},ensure_ascii=False),encoding='utf-8')
     code,_,_=await run_command(sys.executable,'-m','local_engine.translation_worker','--root',str(Path(data)/'models/translation'/MODEL_FOLDER),'--input',str(input_file),'--output',str(output),timeout=300,tree=True)
     if code or not output.is_file():raise HTTPException(503,'Không chạy được model dịch local. Bản lời cũ được giữ; không gọi dịch vụ khác.')
     try:result=json.loads(output.read_text(encoding='utf-8'));rows=result.get('lines',[])
     except (ValueError,AttributeError):raise HTTPException(502,'Đầu ra model không hợp lệ; giữ bản lời cũ.')
     if not isinstance(rows,list) or len(rows)!=len(lines) or any(not isinstance(r,dict) or r.get('id')!=old['id'] or r.get('original')!=old['original'] or not isinstance(r.get('translation'),str) or not 0<len(r['translation'])<=12000 for r,old in zip(rows,lines)):raise HTTPException(502,'Đầu ra dịch sai câu. Không thay bản lời cũ.')
     return result
  finally:busy=False
