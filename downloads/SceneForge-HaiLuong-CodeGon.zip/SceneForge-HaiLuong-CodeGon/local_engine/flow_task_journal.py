"""Owned Flow request journal. Reconnects/read recovery never invoke generation."""
import asyncio
from contextvars import ContextVar
from contextlib import contextmanager
import hashlib,json,os,re,sqlite3,time
from pathlib import Path

REQUEST=ContextVar('sceneforge_flow_request',default=None)

class FlowJournal:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True);self.tasks={}
        with self.db()as db:
            db.execute('CREATE TABLE IF NOT EXISTS task(id TEXT PRIMARY KEY,account INTEGER,fingerprint TEXT,state TEXT,response TEXT,operations TEXT,updated REAL)')
            db.execute("UPDATE task SET state='unknown' WHERE state='running'")
        if os.name!='nt':os.chmod(self.path,0o600)
    @contextmanager
    def db(self):
        db=sqlite3.connect(self.path,timeout=30);db.execute('PRAGMA synchronous=FULL')
        try:
            with db:yield db
        finally:db.close()
    def read(self,rid):
        with self.db()as db:
            db.row_factory=sqlite3.Row;row=db.execute('SELECT * FROM task WHERE id=?',(rid,)).fetchone()
        return dict(row)if row else None
    def claim(self,rid,account,fingerprint):
        with self.db()as db:
            db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT fingerprint,account FROM task WHERE id=?',(rid,)).fetchone()
            if row:
                if row!=(fingerprint,account):raise ValueError('Request identity conflict')
                return False
            db.execute('INSERT INTO task VALUES(?,?,?,?,?,?,?)',(rid,account,fingerprint,'running',None,None,time.time()));return True
    def operations(self,rid,operations):
        raw=json.dumps(operations)
        if len(raw)>256000:return
        with self.db()as db:db.execute('UPDATE task SET operations=?,updated=? WHERE id=?',(raw,time.time(),rid))
    def finish(self,rid,state,response=None):
        with self.db()as db:db.execute('UPDATE task SET state=?,response=?,updated=? WHERE id=?',(state,json.dumps(response)if response else None,time.time(),rid))

def install_journal(engine,path):
    from fastapi import Depends,HTTPException
    from starlette.responses import JSONResponse
    from src.core.auth import AuthManager,verify_api_key_header
    journal=FlowJournal(path)
    class JournalMiddleware:
        def __init__(self,app):self.app=app
        async def __call__(self,scope,receive,send):
            headers=dict(scope.get('headers',[]));raw=headers.get(b'x-sceneforge-request',b'').decode(errors='replace')
            if scope['type']!='http'or scope.get('path')!='/v1/chat/completions'or not raw:return await self.app(scope,receive,send)
            async def reply(data,status=200):await JSONResponse(data,status_code=status)(scope,receive,send)
            key=headers.get(b'authorization',b'').decode(errors='replace').removeprefix('Bearer ')
            if not AuthManager.verify_api_key(key):return await reply({'error':'Unauthorized'},401)
            actor=headers.get(b'x-sceneforge-account',b'')
            if not re.fullmatch(r'flow-[a-f0-9-]{36}',raw)or not actor.isdigit():return await reply({'error':'Request/account identity required'},400)
            body=bytearray()
            while True:
                event=await receive()
                if event['type']=='http.disconnect':return
                body.extend(event.get('body',b''))
                if len(body)>40*1024**2:return await reply({'error':'Request too large'},413)
                if not event.get('more_body'):break
            try:fresh=journal.claim(raw,int(actor),hashlib.sha256(body).hexdigest())
            except ValueError:return await reply({'error':'Request identity conflict'},409)
            async def work():
                token=REQUEST.set(raw);status=500;chunks=[];size=0;received=False
                async def saved_receive():
                    nonlocal received
                    if not received:received=True;return {'type':'http.request','body':bytes(body),'more_body':False}
                    await asyncio.Future()
                async def saved_send(event):
                    nonlocal status,size
                    if event['type']=='http.response.start':status=event['status']
                    if event['type']=='http.response.body':
                        size+=len(event.get('body',b''))
                        if size>2*1024**2:raise ValueError('Response too large')
                        chunks.append(event.get('body',b''))
                try:
                    await self.app(scope,saved_receive,saved_send)
                    payload=json.loads(b''.join(chunks))
                    journal.finish(raw,'done'if status==200 else'failed',payload if status==200 else None)
                except BaseException:journal.finish(raw,'unknown')
                finally:REQUEST.reset(token)
            if fresh:
                task=asyncio.create_task(work());journal.tasks[raw]=task;task.add_done_callback(lambda t:journal.tasks.pop(raw,None))
            task=journal.tasks.get(raw)
            if task:await asyncio.shield(task)
            row=journal.read(raw)
            if row['state']=='done':
                response=JSONResponse(json.loads(row['response']));response.headers['x-sceneforge-account']=str(row['account']);return await response(scope,receive,send)
            return await reply({'error':'Result unresolved; query /sceneforge/tasks/'+raw+'; no new generation submitted'},409)
    engine.app.add_middleware(JournalMiddleware)
    if hasattr(engine,'flow_client')and hasattr(engine.flow_client,'check_video_status'):
        original=engine.flow_client.check_video_status
        async def tracked(at,operations,*args,**kwargs):
            rid=REQUEST.get()
            if rid:journal.operations(rid,operations)
            return await original(at,operations,*args,**kwargs)
        engine.flow_client.check_video_status=tracked

    @engine.app.get('/sceneforge/tasks/{rid}')
    async def reconcile(rid:str,refresh_media:bool=False,key=Depends(verify_api_key_header)):
        row=journal.read(rid)
        if row is None:raise HTTPException(404,'Task not found in this engine journal')
        if row['state']=='done'and(not refresh_media or not row['operations']):return {'state':'done','account_id':row['account'],'response':json.loads(row['response'])}
        if rid in journal.tasks:return {'state':'running','account_id':row['account']}
        # Only status/media reads using the original account. Never call create/extend.
        if row['operations']and hasattr(engine,'flow_client')and hasattr(engine,'generation_handler'):
            try:
                actor=await engine.token_manager.get_token(row['account']);actor=await engine.token_manager.ensure_valid_token(actor)
                if not actor:raise ValueError('Session unavailable')
                result=await engine.flow_client.check_video_status(actor.at,json.loads(row['operations']),token_id=actor.id,google_cookies=getattr(actor,'google_cookies',None))
                for operation in result.get('operations',[]):
                    if operation.get('status')!='MEDIA_GENERATION_STATUS_SUCCESSFUL':continue
                    media=await engine.generation_handler._resolve_video_asset(actor,operation);url=media.get('video_url')
                    if not url:continue
                    from urllib.parse import urlsplit
                    parsed=urlsplit(url)
                    if parsed.scheme!='https'or parsed.hostname not in ('storage.googleapis.com','lh3.googleusercontent.com'):
                        # Authenticated media RPC, not an arbitrary URL fetch with cookies.
                        name=media.get('media_name')
                        if not name:continue
                        fetched=await engine.flow_client.get_media(actor.at,name,token_id=actor.id,google_cookies=getattr(actor,'google_cookies',None),project_id=operation.get('projectId'))
                        encoded=fetched.get('video',{}).get('encodedVideo','')
                        if not encoded or len(encoded)>700*1024**2:continue
                        filename=await engine.generation_handler.file_cache.cache_base64_video(encoded)
                        if '/'in filename or '..'in filename:raise ValueError('Invalid cached filename')
                        from src.core.config import config
                        url='http://127.0.0.1:'+str(config.server_port)+'/tmp/'+filename
                    payload={'url':url};journal.finish(rid,'done',payload)
                    return {'state':'done','account_id':actor.id,'response':payload,'reconciled':True}
            except Exception:return {'state':'unknown','account_id':row['account'],'code':'UPSTREAM_LOOKUP_UNAVAILABLE'}
        return {'state':row['state'],'account_id':row['account'],'code':'CHECK_SERVICE_HISTORY'}
    return journal
