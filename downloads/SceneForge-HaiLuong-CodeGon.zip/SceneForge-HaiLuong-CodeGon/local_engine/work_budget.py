"""One heavy local job at a time; queued exports take priority, no preemption."""
import asyncio,itertools
from contextlib import asynccontextmanager
class WorkBudget:
 def __init__(self):self.condition=asyncio.Condition();self.waiting=[];self.active=None;self.order=itertools.count()
 def lane(self,name,priority):return Lane(self,name,priority)
 @asynccontextmanager
 async def slot(self,name,priority):
  ticket=(priority,next(self.order),name)
  async with self.condition:
   self.waiting.append(ticket)
   try:
    await self.condition.wait_for(lambda:self.active is None and ticket==min(self.waiting))
    self.waiting.remove(ticket);self.active=ticket
   except BaseException:
    self.waiting.remove(ticket);self.condition.notify_all();raise
  try:yield
  finally:
   async with self.condition:self.active=None;self.condition.notify_all()
 def status(self):return {'active':self.active[2]if self.active else None,'waiting':[t[2]for t in sorted(self.waiting)],'heavy_limit':1,'export_priority':True}
class Lane:
 def __init__(self,budget,name,priority):self.budget=budget;self.name=name;self.priority=priority;self.entries={}
 async def __aenter__(self):
  context=self.budget.slot(self.name,self.priority);task=asyncio.current_task();self.entries[task]=context
  try:return await context.__aenter__()
  except BaseException:self.entries.pop(task,None);raise
 async def __aexit__(self,*args):return await self.entries.pop(asyncio.current_task()).__aexit__(*args)
