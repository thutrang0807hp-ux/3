import json,os,threading,time,webbrowser
from pathlib import Path
from urllib.request import urlopen
import uvicorn
from .instance import Instance,listen
from .library import atomic_json

def ready(url):
 try:
  with urlopen(url+'local-api/health',timeout=1)as r:return json.load(r).get('service')=='sceneforge-local'
 except (OSError,ValueError):return False

def open_when_ready(url):
 for _ in range(100):
  if ready(url):webbrowser.open(url);return
  time.sleep(.2)

def main():
 root=Path(os.environ.get('SCENEFORGE_LOCAL_DATA',str(Path.home()/'.sceneforge-local')))
 with Instance(root)as instance:
  if not instance.acquire():
   # First process may still be starting. Never terminate a port owner.
   for _ in range(30):
    try:
     port=json.loads((root/'instance.json').read_text())['port']
     if isinstance(port,int)and 0<port<65536:
      url='http://127.0.0.1:'+str(port)+'/'
      if ready(url):
       print('SceneForge đang chạy: '+url)
       if os.environ.get('SCENEFORGE_OPEN_BROWSER')=='1':webbrowser.open(url)
       return
    except (OSError,ValueError,KeyError):pass
    time.sleep(.2)
   raise SystemExit('SceneForge đang khởi động ở tiến trình khác. Thử mở lại sau vài giây.')
  sock=listen();port=sock.getsockname()[1];url='http://127.0.0.1:'+str(port)+'/'
  try:
   atomic_json(root/'instance.json',{'port':port,'pid':os.getpid()})
   if os.environ.get('SCENEFORGE_OPEN_BROWSER')=='1':threading.Thread(target=open_when_ready,args=(url,),daemon=True).start()
   print('SceneForge: '+url,flush=True)
   uvicorn.Server(uvicorn.Config('local_engine.server:app',host='127.0.0.1',port=port,access_log=False)).run(sockets=[sock])
  finally:sock.close()
if __name__=='__main__':main()
