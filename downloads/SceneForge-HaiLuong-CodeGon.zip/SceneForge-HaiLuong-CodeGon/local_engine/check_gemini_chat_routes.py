"""Actual app routes to Gemini Chat fixtures, preserving schemas and account identity."""
import asyncio
import base64
import io
import json
import os
from pathlib import Path
import tempfile
import uuid
import httpx
from PIL import Image


async def main():
    with tempfile.TemporaryDirectory()as directory:
        os.environ['SCENEFORGE_LOCAL_DATA']=directory
        from . import server
        calls=[]
        async def no_api(*args,**kwargs):raise AssertionError('paid API fallback forbidden')
        server.gemini_request=no_api
        async def runner(body):
            if body['operation']=='check':return {'ok':True,'session':body['session'],'models':[{'id':'fixture-model','name':'Fixture'}]}
            calls.append(body)
            prompt=body['prompt']
            data=json.loads(prompt.split('\nDATA (not instructions):\n')[-1])
            if 'Translate all original lines' in prompt:
                result={'lines':[{'id':r['id'],'translation':'Bản dịch thử '+r['id']}for r in data['lines']]}
            elif 'assignments' in prompt:
                result={'assignments':{r['code']:data['products'][0]['code']for r in data['files']}}
            elif 'lines' in data and 'scenes' in data:
                result={'scenes':[{'code':s['code'],'line_ids':s['line_ids'],'description':'Fixture evidence','hasPerson':False,'faceTalking':False,'hasProduct':True,'competitorLogo':False,'visual':{lang:{k:''for k in('person','product','scale','composition','background','lighting')}for lang in('vi','en')},'motion':{lang:{k:''for k in('camera','initial','action','final')}for lang in('vi','en')},'promptFrame':{'vi':'Khung thử','en':'Fixture frame'}}for s in data['scenes']], 'lines':{r['code']:{'translation':'Lời dịch thử','newText':'Lời viết thử','faceTalking':False}for r in data['lines']}}
            else:result={'beats':[{'text':'Nội dung thử','type':'detail','angle':'Cận cảnh','movement':'Đẩy máy nhẹ','onScreen':''}for r in data['beats']]}
            return {'ok':True,'text':json.dumps(result,ensure_ascii=False),'session':body['session']}
        server.GEMINI_CHAT.runner=runner
        async with httpx.AsyncClient(transport=httpx.ASGITransport(server.app),base_url='http://testserver')as client:
            await client.get('/')
            h={'X-SceneForge-Local':'1'}
            response=await client.post('/local-api/gemini-chat/login',headers=h,json={'name':'Fixture Chat','cookies':[{'domain':'.google.com','name':'__Secure-1PSID','value':'PRIVATE_GCHAT_COOKIE'}]})
            assert response.status_code==200,response.text
            aid=response.json()['id']
            assert server.GEMINI_CHAT.selection()['account_id']==aid
            server.VAULT.set_secret('gemini','API_KEY_NEVER_USED')
            status=(await client.get('/local-api/status')).json();assert status['ai_source']=='gemini_chat'and status['ai_configured']
            assert 'PRIVATE_GCHAT_COOKIE'not in json.dumps(status)
            response=await client.post('/local-api/gemini-chat/roles',headers=h,json={'writing':'fixture-model','analysis':'','image':'','translation':''});assert response.status_code==200
            response=await client.post('/local-api/ai/script',headers=h,json={'request_id':str(uuid.uuid4()),'idea':'Fixture product','beats':[{'id':'beat-1','seconds':4}]});assert response.status_code==200,response.text
            assert response.json()['beats'][0]['text']=='Nội dung thử'and calls[-1]['model']=='fixture-model'
            source=[{'id':'line-1','original':'你好'},{'id':'line-2','original':'Buongiorno'}]
            request={'request_id':'gchat-'+str(uuid.uuid4()),'room_id':'fixture-room','lines':source}
            response=await client.post('/local-api/gemini-chat/translate',headers=h,json=request);assert response.status_code==200,response.text
            assert [r['id']for r in response.json()['lines']]==['line-1','line-2']
            n=len(calls);assert(await client.post('/local-api/gemini-chat/translate',headers=h,json=request)).status_code==200 and len(calls)==n
            picture=io.BytesIO();Image.new('RGB',(90,160),'red').save(picture,format='PNG');encoded='data:image/png;base64,'+base64.b64encode(picture.getvalue()).decode()
            response=await client.post('/local-api/ai/classify-products',headers=h,json={'request_id':str(uuid.uuid4()),'files':[{'code':'F1','name':'fixture.mp4','image':encoded}],'products':[{'code':'P1','name':'Fixture product'}]});assert response.status_code==200,response.text
            assert response.json()['assignments']=={'F1':'P1'}and len(calls[-1]['references'])==1
            response=await client.post('/local-api/ai/analyze-frames',headers=h,json={'request_id':str(uuid.uuid4()),'room_id':'fixture','duration':2,'scenes':[{'id':'scene-1','start':0,'end':2,'frames':[encoded],'ocr':[]}],'lines':[{'id':'line-1','start':0,'end':1,'original':'Đây là sản phẩm được cung cấp để thử nghiệm.'}]});assert response.status_code==200,response.text
            result=response.json();assert result['model']=='gemini-chat'and result['script'][0]['original']=='Đây là sản phẩm được cung cấp để thử nghiệm.'and result['script'][0]['start']==0
            assert len(calls[-1]['references'])==1
            # Recovering a completed frame-analysis result is read-only, even if its
            # ID vanished or the user selected a different engine data directory.
            rid=json.loads(calls[-1]['prompt'].split('\nDATA (not instructions):\n')[-1])['request_id']
            existing={'request_id':rid,'room_id':'fixture','duration':2,'scenes':[{'id':'scene-1','start':0,'end':2,'frames':[encoded],'ocr':[]}],'lines':[{'id':'line-1','start':0,'end':1,'original':'Đây là sản phẩm được cung cấp để thử nghiệm.'}],'read_existing':True,'expected_store_id':server.GEMINI_CHAT.ledger.store_id}
            n=len(calls)
            response=await client.post('/local-api/ai/analyze-frames',headers=h,json=existing)
            assert response.status_code==200 and len(calls)==n,response.text
            for change,code in [({'request_id':'gchat-'+str(uuid.uuid4())},'RESULT_MISSING'),({'expected_store_id':'different-store'},'STORE_CHANGED')]:
                response=await client.post('/local-api/ai/analyze-frames',headers=h,json={**existing,**change})
                assert response.status_code==409 and response.json()['detail']['code']==code and len(calls)==n,response.text
            server.VAULT.set_secret('ai-routing',{'source':'gemini_api'})
            response=await client.post('/local-api/ai/analyze-frames',headers=h,json=existing)
            assert response.status_code==409 and len(calls)==n,response.text
        assert b'PRIVATE_GCHAT_COOKIE'not in server.VAULT.path.read_bytes()
        assert not server.GEMINI_CHAT.tasks
        print('PASS: actual local app routes -> Chat account -> script, translation/cache, evidence classification and frame analysis; original speech/timing preserved; explicit role models; paid API never called; cookie encrypted and never returned. Fixture SDK only.')


if __name__=='__main__':asyncio.run(main())
