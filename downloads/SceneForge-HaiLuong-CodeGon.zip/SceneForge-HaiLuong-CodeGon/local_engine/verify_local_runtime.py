"""Explicit local readiness report; presence is not a live provider test."""
import argparse,json,os,shutil,time
from pathlib import Path
from .cpu_analysis import capabilities
from .local_tts import tts_status

def verify(data,probe_models=False):
    cpu=capabilities(data);voice=tts_status(data)
    checks={name:bool(cpu[name])for name in ('ffmpeg','opencv','scenedetect','ocr','whisper','whisper_model')}
    checks['vieneu_model']=voice['model_ready']
    if probe_models and checks['whisper_model']and checks['whisper']:
        from .prepare_whisper import verify_model
        verify_model(data/'models/faster-whisper');checks['whisper_decode_probe']=True
    return {'at':time.time(),'checks':checks,'missing':[k for k,v in checks.items()if not v],
        'online_accounts':'not tested by this check','whisper_probe_requested':probe_models,
        'vieneu_probe':'prepared WAV hash and offline asset sizes checked','cpu_video_max_mb':cpu['max_bytes']//1024**2,'cpu_video_max_seconds':cpu['max_seconds']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--probe-models',action='store_true');args=p.parse_args()
    data=Path(os.environ.get('SCENEFORGE_LOCAL_DATA',str(Path.home()/'.sceneforge-local')));data.mkdir(parents=True,exist_ok=True)
    result=verify(data,args.probe_models);(data/'local-runtime-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['missing']:raise SystemExit('Local setup incomplete. Read missing fields above; no model download was performed.')

if __name__=='__main__':main()
