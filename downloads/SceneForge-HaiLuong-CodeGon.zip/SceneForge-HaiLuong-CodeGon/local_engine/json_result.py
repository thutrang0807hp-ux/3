"""Accept one complete JSON object, never synthesize or guess missing content."""
import json

def object_result(text):
    if not isinstance(text,str)or len(text)>500000:raise ValueError('JSON result too large')
    try:
        result=json.loads(text.strip())
        if isinstance(result,dict):return result
    except ValueError:pass
    objects=[];start=None;depth=0;quoted=False;escape=False
    for index,char in enumerate(text):
        if start is None:
            if char=='{':start=index;depth=1;quoted=False;escape=False
            continue
        if quoted:
            if escape:escape=False
            elif char=='\\':escape=True
            elif char=='"':quoted=False
        elif char=='"':quoted=True
        elif char=='{':depth+=1
        elif char=='}':
            depth-=1
            if depth==0:
                try:
                    candidate=json.loads(text[start:index+1])
                    if isinstance(candidate,dict):objects.append(candidate)
                except ValueError:pass
                start=None
                if len(objects)>1:raise ValueError('Multiple JSON objects; review required')
    if len(objects)!=1 or start is not None:raise ValueError('Missing or incomplete JSON object')
    return objects[0]
