"""Atomic, source/options-bound checkpoints for resumable CPU-only analysis."""
import hashlib,json,os
from pathlib import Path
from .library import atomic_json

class Checkpoints:
 def __init__(self,config):
  self.root=Path(config['work'])/'checkpoint';self.root.mkdir(exist_ok=True)
  identity={k:config.get(k)for k in ('source_sha256','fps','duration','width','height','threshold','min_scene','transcribe','ocr','language')}
  self.identity=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
  path=self.root/'manifest.json'
  if path.exists()and json.loads(path.read_text()).get('identity')!=self.identity:raise ValueError('Checkpoint không khớp nguồn hoặc tùy chọn; chưa dùng kết quả cũ.')
  atomic_json(path,{'version':1,'identity':self.identity})
 def read(self,name):
  path=self.root/(name+'.json')
  if not path.is_file():return None
  value=json.loads(path.read_text())
  if value.get('identity')!=self.identity:raise ValueError('Một phần checkpoint không khớp nguồn.')
  return value['value']
 def write(self,name,value):atomic_json(self.root/(name+'.json'),{'identity':self.identity,'value':value})
