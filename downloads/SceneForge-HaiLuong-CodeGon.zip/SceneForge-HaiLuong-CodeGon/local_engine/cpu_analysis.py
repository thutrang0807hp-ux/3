"""Bounded local CPU analysis, explicit jobs; never sends media to a provider."""
import asyncio,base64,importlib.util,json,math,os,shutil,sys,tempfile,time,uuid
from pathlib import Path
from .local_jobs import LocalJobs,JobRegistry,job_room
from fastapi import HTTPException, Request
from .machine_checks import run_command
from .video_analysis import input_video

def capabilities(data):
 def installed(name):return importlib.util.find_spec(name)is not None
 ffmpeg=bool(shutil.which('ffmpeg')and shutil.which('ffprobe'))
 cv=installed('cv2');scenes=installed('scenedetect');whisper=installed('faster_whisper');ocr=installed('rapidocr_onnxruntime')
 model=data/'models/faster-whisper'
 model_ready=all((model/n).is_file()for n in ('model.bin','config.json','tokenizer.json'))
 return {'available':ffmpeg and cv and scenes,'ffmpeg':ffmpeg,'opencv':cv,'scenedetect':scenes,'ocr':ocr,'whisper':whisper,'whisper_model':model_ready,'max_bytes':500*1024**2,'max_seconds':600,'binary_upload':True,'note':'CPU, không PyTorch. Chép lời cần model có sẵn trong models/faster-whisper; không tự tải. OCR lấy mẫu đầu/giữa/cuối cảnh, không quét mọi khung.'}

def install_cpu_analysis(app,data,lock=None,store=None):
 jobs=JobRegistry(store or LocalJobs(data),'analysis');lock=lock or asyncio.Lock();cache=data/'cpu-analysis';cache.mkdir(exist_ok=True)
 def workspace(job):return cache/job['id']
 def resumable(job):return(workspace(job)/'source').is_file()and(workspace(job)/'options.json').is_file()
 def public(job):return {k:job.get(k)for k in ('id','state','progress','phase','error','result','resumable','completed_scenes','total_scenes','completed_audio','total_audio','room_id')}
 def find(id):
  if id not in jobs:raise HTTPException(404,'Lượt phân tích không còn trên máy; tệp nguồn trong dự án vẫn giữ.')
  return jobs[id]
 for saved in jobs.values():
  if saved.get('recovered')and resumable(saved):saved.update(state='paused',resumable=True,phase='Lượt trước tạm dừng · có thể tiếp tục phần còn thiếu',error=None)
 def clean():
  for key,job in list(jobs.items()):
   age=time.time()-job['at']
   if job['state']in ('done','error','cancelled')and not resumable(job)and age>1800 or job['state']=='paused'and age>7*86400:
    shutil.rmtree(workspace(job),ignore_errors=True);jobs.pop(key)
 def admit_count():
  if len(jobs)<4:return
  old=[k for k,v in jobs.items()if v['state']in ('done','error','cancelled')and not resumable(v)]
  if not old:raise HTTPException(409,'Có 4 lượt còn dữ liệu tạm; tiếp tục hoặc bỏ lượt cũ trước.')
  jobs.pop(min(old,key=lambda k:jobs[k]['at']))
 def prepare(job,raw,body):
  from .library import atomic_json
  work=workspace(job);work.mkdir(exist_ok=True);source=work/'source'
  try:
   if isinstance(raw,Path):raw.replace(source)
   else:source.write_bytes(raw)
   atomic_json(work/'options.json',body);job.update(resumable=True)
  except OSError:
   shutil.rmtree(work,ignore_errors=True)
   job.update(state='error',resumable=False,phase='Chưa nhận lượt CPU',error='Không ghi được dữ liệu chuẩn bị; chưa chạy CPU.')
   raise HTTPException(507,'Không ghi được dữ liệu chuẩn bị CPU; chưa xếp lượt chạy.')from None
 async def process(job,raw=None,body=None):
  from .library import atomic_json
  work=workspace(job);finished=False
  try:
   async with lock:
    if raw is not None:prepare(job,raw,body)
    body=json.loads((work/'options.json').read_text());source=work/'source'
    job.update(state='running',phase='Đối chiếu nguồn và đọc checkpoint',error=None,progress=job.get('progress',0))
    with source.open('rb')as handle:source_hash=__import__('hashlib').file_digest(handle,'sha256').hexdigest()
    saved=json.loads((work/'config.json').read_text())if(work/'config.json').is_file()else None
    if saved and saved.get('source_sha256')!=source_hash:raise ValueError('Video tạm đã thay đổi; chưa dùng checkpoint cũ.')
    code,out,_=await run_command(shutil.which('ffprobe'),'-v','error','-protocol_whitelist','file,pipe','-show_streams','-show_format','-of','json',str(source),timeout=20)
    if code:raise ValueError('Không đọc được video nguồn bằng ffprobe.')
    meta=json.loads(out);v=next(s for s in meta['streams']if s.get('codec_type')=='video');duration=float(meta['format']['duration']);w=int(v['width']);h=int(v['height']);rate=v.get('avg_frame_rate','0/1').split('/');fps=float(rate[0])/float(rate[1])
    if not all(math.isfinite(x)for x in (duration,fps))or not 0<duration<=600 or not 1<=fps<=120 or w*h>8388608:raise ValueError('CPU nhận video tối đa 10 phút, 120 fps, 8,4 triệu điểm ảnh.')
    if abs(duration-body['duration'])>max(.15,2/fps):raise ValueError('Thời lượng nguồn khác dữ liệu dự án. Nhập lại video trước khi phân tích.')
    original_fps=fps;fps=min(fps,24);proxy=work/'proxy.avi'
    config={'work':str(work),'data':str(data),'source_sha256':source_hash,'fps':fps,'duration':duration,'width':w,'height':h,'audio':any(s.get('codec_type')=='audio'for s in meta['streams']),**{k:body[k]for k in ('threshold','min_scene','transcribe','ocr','language')}}
    atomic_json(work/'config.json',config)
    if not(proxy.is_file()and(work/'proxy-ready.json').is_file()):
     if shutil.disk_usage(data).free<512*1024**2:raise ValueError('Cần 512 MB trống để hoàn tất bản đo; nguồn và checkpoint vẫn giữ.')
     job.update(phase='FFmpeg tạo bản đo nhỏ · giữ bản gốc',progress=8)
     code,_,_=await run_command(shutil.which('ffmpeg'),'-v','error','-nostdin','-threads','2','-protocol_whitelist','file,pipe','-i',str(source),'-map','0:v:0','-an','-vf','scale=480:480:force_original_aspect_ratio=decrease:force_divisible_by=2,fps='+str(fps)+':round=near','-fps_mode','cfr','-c:v','mjpeg','-q:v','5','-threads','2','-t','600','-fs',str(480*1024**2),'-y',str(proxy),timeout=300)
     if code:raise ValueError('FFmpeg chưa tạo được bản đo video.')
     atomic_json(work/'proxy-ready.json',{'source_sha256':source_hash})
    job.update(phase='Tiếp tục CPU từ phần chưa hoàn tất',progress=max(15,job.get('progress',0)))
    task=asyncio.create_task(run_command(sys.executable,'-m','local_engine.cpu_worker',str(work/'config.json'),timeout=600,tree=True))
    try:
     while not task.done():
      await asyncio.wait({task},timeout=.3)
      try:
       status=json.loads((work/'progress.json').read_text());values={k:status[k]for k in ('progress','phase','completed_scenes','total_scenes','completed_audio','total_audio')if k in status}
       for k in ('progress','completed_scenes','completed_audio'):
        if k in values:values[k]=max(job.get(k)or 0,values[k])
       job.update(**values)
      except (OSError,ValueError,KeyError):pass
     code,_,_=await task
    finally:
     if not task.done():task.cancel()
     try:await task
     except asyncio.CancelledError:pass
    if code or not(work/'result.json').exists():
     message=json.loads((work/'error.json').read_text()).get('error')if(work/'error.json').exists()else None
     raise ValueError(message or 'CPU chưa hoàn tất. Phần đã đo được giữ để tiếp tục; bản dự án cũ vẫn giữ.')
    result=json.loads((work/'result.json').read_text());result['proxy']={'max_side':480,'fps':fps,'source_fps':original_fps,'original_preserved':True};result['source_sha256']=source_hash
    job.update(state='done',resumable=False,phase='Xong · cần rà trước khi áp dụng',progress=100,result=result);finished=True
  except asyncio.CancelledError:job.update(state='paused'if resumable(job)else'cancelled',resumable=resumable(job),phase='Đã tạm dừng · giữ phần đã làm',error=None)
  except asyncio.TimeoutError:job.update(state='paused',resumable=resumable(job),phase='Hết thời gian lượt này · tiếp tục phần còn thiếu',error='Đã giữ checkpoint; bấm Tiếp tục, không cần tải lại video.')
  except Exception as e:job.update(state='paused'if resumable(job)else'error',resumable=resumable(job),error=str(e)if isinstance(e,ValueError)else 'CPU chưa hoàn tất; dữ liệu tạm còn giữ để tiếp tục hoặc bỏ lượt.')
  finally:
   if finished:shutil.rmtree(work,ignore_errors=True)
   if isinstance(raw,Path)and raw!=work/'source':raw.unlink(missing_ok=True)
 @app.get('/local-api/analysis/local/capabilities')
 async def available():return capabilities(data)
 @app.post('/local-api/analysis/local/jobs')
 async def start(body:dict):
  clean()
  if any(j['state']in ('queued','running')for j in jobs.values()):raise HTTPException(409,'Máy đang phân tích video. Chờ hoặc dừng lượt hiện tại.')
  c=capabilities(data)
  if not c['available']:raise HTTPException(409,'Cần cài FFmpeg/ffprobe và requirements-cpu.txt trong companion. Không tự cài hoặc tải model.')
  threshold=body.get('threshold',27);minimum=body.get('min_scene',.12)
  if type(threshold)not in (int,float)or not math.isfinite(threshold)or not 5<=threshold<=80 or type(minimum)not in (int,float)or not math.isfinite(minimum)or not .08<=minimum<=3:raise HTTPException(400,'Độ nhạy 5–80; cảnh tối thiểu 0,08–3 giây.')
  for key in ('transcribe','ocr'):
   if type(body.get(key,False))is not bool:raise HTTPException(400,'Tùy chọn không hợp lệ.')
  if body.get('transcribe')and not(c['whisper']and c['whisper_model']):raise HTTPException(409,'Chưa có faster-whisper và model trên máy; không tải model trong lúc phân tích.')
  if body.get('ocr')and not c['ocr']:raise HTTPException(409,'Chưa cài RapidOCR; bỏ chọn OCR hoặc cài requirements-cpu.txt.')
  duration=body.get('duration')
  if type(duration)not in (float,int)or not math.isfinite(duration)or not 0<duration<=300:raise HTTPException(400,'Phân tích CPU tối đa 5 phút.')
  safe={**body,'scenes':[{'start':0,'end':duration}]};media=input_video(safe);raw=base64.b64decode(media['data'])
  if shutil.disk_usage(data).free<512*1024**2:raise HTTPException(409,'Cần ít nhất 512 MB trống để tạo bản đo.')
  admit_count()
  try:room_id=job_room(body.get('room_id'))
  except ValueError as e:raise HTTPException(400,str(e))
  job={'room_id':room_id,'id':str(uuid.uuid4()),'state':'queued','progress':0,'phase':'Đang xếp','at':time.time()};job=jobs.create(job)
  options={'duration':duration,'threshold':float(threshold),'min_scene':float(minimum),'transcribe':body.get('transcribe',False),'ocr':body.get('ocr',False),'language':body.get('language')if body.get('language')in ('zh','vi','en')else None}
  prepare(job,raw,options);job['task']=asyncio.create_task(process(job));return public(job)
 @app.post('/local-api/analysis/local/upload')
 async def upload(request:Request):
  clean()
  if any(j['state']in ('queued','running')for j in jobs.values()):raise HTTPException(409,'Máy đang phân tích video; chờ lượt hiện tại.')
  c=capabilities(data)
  if not c['available']:raise HTTPException(409,'Thiếu bộ CPU trong môi trường app. Chạy install-cpu.bat.')
  try:
   q=request.query_params;duration=float(q.get('duration','0'));threshold=float(q.get('threshold','27'));minimum=float(q.get('min_scene','.35'));room_id=job_room(q.get('room_id'))
   if not all(math.isfinite(x)for x in (duration,threshold,minimum))or not 0<duration<=600 or not 5<=threshold<=80 or not .08<=minimum<=3:raise ValueError()
  except (ValueError,TypeError):raise HTTPException(400,'Thời lượng/ngưỡng cảnh không hợp lệ; tối đa 10 phút.')from None
  transcribe=q.get('transcribe')=='true';ocr=q.get('ocr')=='true'
  if transcribe and not(c['whisper']and c['whisper_model']):raise HTTPException(409,'Whisper/model chưa sẵn sàng trong môi trường app.')
  if ocr and not c['ocr']:raise HTTPException(409,'RapidOCR chưa sẵn sàng trong môi trường app.')
  source=cache/('upload-'+uuid.uuid4().hex);accepted=False
  try:
   size=0
   with source.open('xb')as out:
    async for chunk in request.stream():
     size+=len(chunk)
     if size>c['max_bytes']:raise HTTPException(413,'Video local tối đa 500 MB.')
     out.write(chunk)
   if not size:raise HTTPException(400,'Tệp video trống.')
   if shutil.disk_usage(data).free<512*1024**2:raise HTTPException(409,'Cần thêm 512 MB trống để tạo bản đo.')
   # Recheck after upload: another request may have been accepted meanwhile.
   if any(j['state']in ('queued','running')for j in jobs.values()):raise HTTPException(409,'Máy đang phân tích; chưa nhận thêm việc.')
   admit_count()
   job=jobs.create({'room_id':room_id,'id':str(uuid.uuid4()),'state':'queued','progress':0,'phase':'Đang xếp','at':time.time()})
   options={'duration':duration,'threshold':threshold,'min_scene':minimum,'transcribe':transcribe,'ocr':ocr,'language':q.get('language')if q.get('language')in ('zh','vi','en')else None}
   prepare(job,source,options);job['task']=asyncio.create_task(process(job));job['task'].add_done_callback(lambda _:source.unlink(missing_ok=True));accepted=True;return public(job)
  finally:
   if not accepted:source.unlink(missing_ok=True)
 @app.get('/local-api/analysis/local/jobs/{id}')
 async def status(id:str):return public(find(id))
 @app.post('/local-api/analysis/local/jobs/{id}/cancel')
 async def cancel(id:str,body:dict):
  job=find(id)
  if job['state']in ('queued','running'):
   job['task'].cancel()
   try:await job['task']
   except asyncio.CancelledError:pass
   job.update(state='paused',resumable=resumable(job),phase='Đã tạm dừng · giữ phần đã làm')
  return public(job)
 @app.post('/local-api/analysis/local/jobs/{id}/resume')
 async def resume(id:str,body:dict):
  job=find(id)
  if body.get('confirm')is not True:raise HTTPException(400,'Xác nhận tiếp tục đo CPU trên máy.')
  if job['state']in ('queued','running','done'):return public(job)
  if not resumable(job):raise HTTPException(404,'Dữ liệu tạm đã hết hạn hoặc bị bỏ; nguồn trong dự án vẫn giữ.')
  if any(j['state']in ('queued','running')for j in jobs.values()):raise HTTPException(409,'Máy đang phân tích một lượt khác.')
  job.update(state='queued',phase='Xếp tiếp phần còn thiếu',error=None,at=time.time());job['task']=asyncio.create_task(process(job));return public(job)
 @app.post('/local-api/analysis/local/jobs/{id}/discard')
 async def discard(id:str,body:dict):
  job=find(id)
  if body.get('confirm')is not True:raise HTTPException(400,'Xác nhận bỏ dữ liệu phân tích tạm, không xóa nguồn dự án.')
  if job.get('task')and not job['task'].done():raise HTTPException(409,'Tạm dừng lượt đo trước khi bỏ dữ liệu tạm.')
  shutil.rmtree(workspace(job),ignore_errors=True);job.update(state='cancelled',resumable=False,phase='Đã bỏ dữ liệu tạm');return public(job)
 return jobs

def install_frame_cleanup(app):
 @app.post('/local-api/analysis/local/clean-frame')
 async def clean_frame(body:dict):
  encoded=body.get('image');polygons=body.get('polygons')
  if not isinstance(encoded,str)or len(encoded)>4*1024**2 or not encoded.startswith(('data:image/jpeg;base64,','data:image/png;base64,'))or not isinstance(polygons,list)or not 1<=len(polygons)<=20:raise HTTPException(400,'Cần ảnh JPEG/PNG và 1–20 vùng chữ đã chọn.')
  checked=[]
  for box in polygons:
   if not isinstance(box,list)or len(box)!=4:raise HTTPException(400,'Vùng chữ cần 4 đỉnh.')
   for p in box:
    if not isinstance(p,list)or len(p)!=2 or any(type(n)not in (float,int)or not math.isfinite(n)or not 0<=n<=1 for n in p):raise HTTPException(400,'Tọa độ vùng chữ phải trong ảnh.')
   checked.append(box)
  try:raw=base64.b64decode(encoded.split(',',1)[1],validate=True)
  except ValueError:raise HTTPException(400,'Ảnh không hợp lệ.')
  def transform():
   import io,cv2,numpy as np
   from PIL import Image
   with Image.open(io.BytesIO(raw))as img:
    if img.width>2000 or img.height>2000 or img.width*img.height>2000000:raise ValueError('Ảnh vượt kích thước xử lý 2 triệu điểm ảnh.')
    img.verify()
   image=cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_COLOR)
   if image is None:raise ValueError('Không đọc được ảnh.')
   h,w=image.shape[:2];mask=np.zeros((h,w),np.uint8)
   for polygon in checked:cv2.fillPoly(mask,[np.array([[round(x*(w-1)),round(y*(h-1))]for x,y in polygon],np.int32)],255)
   mask=cv2.dilate(mask,np.ones((5,5),np.uint8))
   if np.count_nonzero(mask)>mask.size*.2:raise ValueError('Vùng che vượt 20% ảnh; thu nhỏ vùng để tránh phá khung.')
   result=cv2.inpaint(image,mask,3,cv2.INPAINT_TELEA);ok,bytes_=cv2.imencode('.jpg',result,[cv2.IMWRITE_JPEG_QUALITY,92])
   if not ok:raise ValueError('Không tạo được ảnh kết quả.')
   return {'image':'data:image/jpeg;base64,'+base64.b64encode(bytes_).decode(),'engine':'OpenCV TELEA','needs_review':True,'note':'Chỉ tô lấp vùng đã chọn trên ảnh tĩnh; có thể có vệt. Bản gốc giữ nguyên, chưa duyệt khung và không xử lý logo trong video.'}
  try:return await asyncio.to_thread(transform)
  except ImportError:raise HTTPException(409,'Cần cài requirements-cpu.txt để xử lý ảnh.')
  except Exception as e:raise HTTPException(400,str(e)if isinstance(e,ValueError)else 'Không xử lý được ảnh khung; bản gốc vẫn giữ.')
