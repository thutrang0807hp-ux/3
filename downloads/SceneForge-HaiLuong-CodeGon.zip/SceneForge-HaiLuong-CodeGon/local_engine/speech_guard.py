"""Quarantine suspicious ASR, never delete source words or claim linguistic truth."""
import json,re,unicodedata,math
from pathlib import Path

def normalize(text):
 return ''.join(c for c in unicodedata.normalize('NFKC',text).casefold()if c.isalnum()or c.isspace()).strip()

def classify(text,no_speech_prob=None,avg_logprob=None,config=None):
 config=config or json.loads(Path(__file__).with_name('speech_guard.json').read_text());clean=normalize(text);words=clean.split();reasons=[]
 if re.search(r'([^\W_]+)(?:\s+\1){2,}(?:\s|$)',clean,re.UNICODE)or re.search(r'([\u3400-\u9fff]{1,12})\1{2,}',clean):reasons.append('Có chữ lặp từ 3 lần liên tiếp')
 if clean and all(c.isdigit()or c.isspace()for c in clean):reasons.append('Câu chỉ có số')
 if any(normalize(p)in clean for p in config['phrases']):reasons.append('Giống câu ASR hay bịa; vẫn có thể là câu thật')
 if type(no_speech_prob)in (int,float)and math.isfinite(no_speech_prob)and no_speech_prob>=config['no_speech_probability']:reasons.append('Whisper báo xác suất không có lời cao')
 if type(avg_logprob)in (int,float)and math.isfinite(avg_logprob)and avg_logprob<config['average_log_probability']:reasons.append('Whisper báo độ tin cậy thấp')
 cjk=bool(re.search(r'[\u3400-\u9fff]',clean));fragment=(len(clean.replace(' ',''))<=2 if cjk else 0<len(words)<=2)
 return {'status':'suspect'if reasons else 'fragment'if fragment else 'clear','label':'Nghi bịa'if reasons else 'Mảnh vụn'if fragment else 'Thật','reasons':reasons,'accepted':False,'thresholds_calibrated':bool(config.get('calibrated')),'note':'Nhãn Thật chỉ nghĩa không thấy dấu hiệu theo bộ lọc, không chứng nhận lời chính xác.'}
