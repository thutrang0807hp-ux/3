"""Account and replay rules, independent of provider-specific browser code."""
import time,math

def apply_probe(account,status,credit=None,verification=False):
 result=dict(account);now=time.time()
 if verification:result['state']='verification'
 elif status==401:result['state']='expired'
 elif 200<=status<300:
  result['state']='ready';result['consecutive_errors']=0
  if isinstance(credit,(int,float)) and not isinstance(credit,bool) and math.isfinite(credit):result.update(credit=credit,credit_at=now)
 # 403 is ambiguous; 429/server/network errors never erase a valid balance or session.
 result['checked_at']=now
 return result

def record_failure(account,reason,verification=False,exhausted=False,now=None):
 now=now or time.time();a=dict(account);a['failures']=a.get('failures',0)+1;a['consecutive_errors']=a.get('consecutive_errors',0)+1
 if verification:a['state']='verification'
 elif exhausted:a['state']='exhausted'
 elif a['consecutive_errors']>=3:a['state']='cooldown';a['cooldown_until']=now+300;a['cooldown_probe_done']=False
 a['last_error']=reason
 return a

def next_account(accounts,current,rotation=False):
 if current and current.get('state')=='verification':return None
 if current and current.get('enabled',True) and current.get('state') in {'ready','active'}:return current
 if not rotation:return None
 return next((a for a in sorted(accounts,key=lambda a:a.get('priority',0)) if a.get('enabled',True) and a.get('state')=='ready'),None)

def may_submit(job):
 # Unknown results and submitted jobs are status-only, including after a restart.
 return job.get('state')=='waiting' and not job.get('provider_task_id') and not job.get('submitted_at')

def should_refresh(account,now=None):
 expiry=account.get('expires_at');return bool(expiry and 0<expiry-(now or time.time())<3600)
