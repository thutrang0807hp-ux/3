"""Install one M2M100 CT2 int8 bundle. Argos packages are no longer used."""
import argparse,hashlib,json,os,shutil,tempfile,time,urllib.request
from pathlib import Path
from .translation_worker import translate,MODEL_FILES,MODEL_FOLDER,MODEL_ID,LANGUAGES

SOURCE_URL='https://huggingface.co/facebook/m2m100_418M/resolve/main/config.json'

def check_download():
 with urllib.request.urlopen(urllib.request.Request(SOURCE_URL,method='HEAD'),timeout=30) as response:
  if response.status!=200:raise ValueError('Nguồn model chưa truy cập được.')
 print('Nguồn tải M2M100 truy cập được; chưa cài model.')

def convert_source(source,output):
 # Conversion only. These libraries never run inside the translation worker.
 from ctranslate2.converters import TransformersConverter
 converter=TransformersConverter(str(source),copy_files=['sentencepiece.bpe.model'])
 converter.convert(str(output),quantization='int8')


def install(target,source=None,convert_from=None,download=False):
 target=Path(target).resolve();target.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='m2m100-install-',dir=target.parent) as temporary:
  stage=Path(temporary)/'model'
  if source is not None:
   stage.mkdir();source=Path(source).resolve()
   for name in MODEL_FILES:
    original=source/name
    if not original.is_file() or not 0<original.stat().st_size<=2*1024**3:raise ValueError('Thiếu/sai kích thước file M2M100: '+name)
    shutil.copy2(original,stage/name)
   for name in ('README.md','LICENSE','vocab.json','tokenizer_config.json'):
    if (source/name).is_file() and (source/name).stat().st_size<32*1024**2:shutil.copy2(source/name,stage/name)
  else:
   if download:
    check_download()
    from huggingface_hub import snapshot_download
    # Explicit setup only. Runtime workers always use local files.
    original=snapshot_download(MODEL_ID,allow_patterns=['config.json','pytorch_model.bin','model.safetensors','sentencepiece.bpe.model','vocab.json','tokenizer_config.json','special_tokens_map.json','README.md','LICENSE'])
   else:original=convert_from
   convert_source(original,stage)
   for name in ('README.md','LICENSE'):
    path=Path(original)/name
    if path.is_file():shutil.copy2(path,stage/name)
  # Both a Chinese and an Italian sentence must produce a new Vietnamese output.
  samples={}
  for language,text in [('zh','你好，欢迎使用。'),('it','Buongiorno, questo è un prodotto.')]:
   result=translate(stage,[{'id':language,'original':text}],language)
   translation=result['lines'][0]['translation'].strip()
   if not translation or translation==text:raise ValueError('Chưa xác minh được dịch thử '+language+' → vi.')
   samples[language]=translation
  rows=[{'path':name,'bytes':(stage/name).stat().st_size,'sha256':hashlib.sha256((stage/name).read_bytes()).hexdigest()} for name in MODEL_FILES]
  marker={'ready':True,'model':MODEL_ID,'backend':'ctranslate2-cpu-int8','at':time.time(),'languages':LANGUAGES,'samples':samples,'files':rows,'quality_certified':False}
  # Never overwrite a different model; identical imports can resume safely.
  for row in rows:
   existing=target/row['path']
   if existing.exists() and hashlib.sha256(existing.read_bytes()).hexdigest()!=row['sha256']:raise ValueError('Có model khác tại đích; không ghi đè: '+row['path'])
  target.mkdir(exist_ok=True)
  for file in stage.iterdir():
   if file.is_file() and not (target/file.name).exists():os.replace(file,target/file.name)
  status=target/'setup-status.tmp';status.write_text(json.dumps(marker,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(status,target/'setup-status.json')
 print('Đã nạp và thử M2M100 CPU Trung/Ý → Việt:',target)
 return marker

def main():
 p=argparse.ArgumentParser(description=__doc__)
 group=p.add_mutually_exclusive_group(required=True);group.add_argument('--from-directory',type=Path,help='Bộ CT2 int8 đã có, không tải lại.');group.add_argument('--convert-from',type=Path,help='Bộ gốc Transformers để chuyển int8.');group.add_argument('--download',action='store_true');group.add_argument('--check-download',action='store_true')
 p.add_argument('--directory',type=Path,default=Path(os.environ.get('SCENEFORGE_LOCAL_DATA',str(Path.home()/'.sceneforge-local')))/'models/translation'/MODEL_FOLDER);a=p.parse_args()
 try:
  if a.check_download:check_download()
  else:install(a.directory,a.from_directory,a.convert_from,a.download)
 except Exception as error:raise SystemExit('Chưa cài xong M2M100: '+str(error))
if __name__=='__main__':main()
