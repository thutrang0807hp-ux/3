"""OS-owned process lock: stale files never mean a running instance."""
import os,socket
from pathlib import Path
class Instance:
 def __init__(self,root):self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True);self.file=None
 def acquire(self):
  f=(self.root/'instance.lock').open('a+b')
  if f.seek(0,2)==0:f.write(b'0');f.flush()
  f.seek(0)
  try:
   if os.name=='nt':
    import msvcrt
    msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
   else:
    import fcntl
    fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
  except OSError:f.close();return False
  self.file=f;return True
 def close(self):
  if self.file:self.file.close();self.file=None
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
def listen(preferred=8840):
 sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
 if os.name=='nt':sock.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
 try:sock.bind(('127.0.0.1',preferred))
 except OSError:
  try:sock.bind(('127.0.0.1',0))
  except BaseException:sock.close();raise
 sock.listen(128);sock.set_inheritable(True);return sock
