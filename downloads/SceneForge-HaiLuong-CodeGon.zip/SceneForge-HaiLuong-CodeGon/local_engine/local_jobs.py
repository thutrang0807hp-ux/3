"""Durable local-only job status. Interrupted work is reported, never rerun."""
import json,re,sqlite3,threading,time
from contextlib import contextmanager
from .schema import migrate
FIELDS={'id','state','progress','phase','error','result','bytes','normalize','fps','duration','created','at','room_id','recovered','resumable','completed_scenes','total_scenes','completed_audio','total_audio'}
ACTIVE={'uploading','queued','running'}
class LocalJobs:
 def __init__(self,root):
  self.path=root/'local-jobs.sqlite';self.lock=threading.RLock()
  migrate(self.path,['CREATE TABLE IF NOT EXISTS job(lane TEXT,id TEXT,payload TEXT NOT NULL,updated REAL NOT NULL,PRIMARY KEY(lane,id))'])
 @contextmanager
 def db(self):
  db=sqlite3.connect(self.path,timeout=30)
  try:
   with db:yield db
  finally:db.close()
 def write(self,lane,job):
  payload=json.dumps({k:v for k,v in job.items()if k in FIELDS},ensure_ascii=False,allow_nan=False)
  with self.lock,self.db()as db:
   db.execute('PRAGMA synchronous=FULL')
   db.execute('INSERT OR REPLACE INTO job VALUES(?,?,?,?)',(lane,job['id'],payload,time.time()))
 def delete(self,lane,id):
  with self.lock,self.db()as db:db.execute('DELETE FROM job WHERE lane=? AND id=?',(lane,id))
 def load(self,lane):
  with self.lock,self.db()as db:rows=db.execute('SELECT payload FROM job WHERE lane=?',(lane,)).fetchall()
  result=[]
  for row in rows:
   job=json.loads(row[0])
   if not re.fullmatch(r'[a-f0-9-]{1,64}',job.get('id','')):continue
   if job.get('state')in ACTIVE:
    job.update(state='error',recovered=True,phase='Lượt trước bị ngắt',error='Ứng dụng đã dừng trước khi hoàn tất. Không tự chạy lại; nguồn và timeline đã lưu vẫn giữ nguyên.')
    self.write(lane,job)
   result.append(job)
  return result
 def recent(self):
  with self.lock,self.db()as db:rows=db.execute('SELECT lane,payload FROM job ORDER BY updated DESC LIMIT 100').fetchall()
  return [dict(lane=lane,**{k:v for k,v in json.loads(payload).items()if k in {'id','state','progress','phase','error','bytes','created','at','room_id','recovered'}})for lane,payload in rows]
class DurableJob(dict):
 def __init__(self,registry,value):super().__init__(value);self.registry=registry;self.last=0
 def flush(self,force=True):
  now=time.monotonic()
  if force or now-self.last>=1:self.registry.store.write(self.registry.lane,self);self.last=now
 def __setitem__(self,key,value):
  old=self.get(key);super().__setitem__(key,value)
  if key in FIELDS and old!=value:self.flush(key not in {'progress','phase'})
 def update(self,*args,**kwargs):
  values=dict(*args,**kwargs);changed={k for k,v in values.items()if k in FIELDS and self.get(k)!=v};super().update(values)
  if changed:self.flush(bool(changed-{'progress','phase'}))
class JobRegistry(dict):
 def __init__(self,store,lane):
  super().__init__();self.store=store;self.lane=lane
  for job in store.load(lane):dict.__setitem__(self,job['id'],DurableJob(self,job))
 def create(self,value):
  job=DurableJob(self,value);job.flush();dict.__setitem__(self,job['id'],job);return job
 def pop(self,key,*default):
  if key in self:self.store.delete(self.lane,key)
  return super().pop(key,*default)

def job_room(value):
 if value is None:return None
 if not isinstance(value,str)or len(value)>128:raise ValueError('Mã phòng không hợp lệ.')
 return value or None
