"""Verify and install a local VieNeu model ZIP; no Hub downloads.

The SDK must already be installed separately. Existing different models are kept
unchanged; use a fresh engine directory for another model bundle.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile
from .voice_worker import V3_FILES, CODEC_FILES
from .prepare_voice import prepare


def import_bundle(bundle, directory, verify_speech=True):
    root = Path(directory).resolve()
    runtime = root / 'runtime'
    runtime.mkdir(parents=True, exist_ok=True, mode=0o700)
    target = runtime / 'offline'
    expected = {'vieneu/' + n for n in V3_FILES} | {'codec/' + n for n in CODEC_FILES}
    with zipfile.ZipFile(bundle) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or 'manifest.json' not in names or archive.getinfo('manifest.json').file_size > 1024**2:
            raise ValueError('Manifest hoặc danh sách ZIP không hợp lệ.')
        manifest = json.loads(archive.read('manifest.json'))
        if not isinstance(manifest, dict) or manifest.get('format') != 'sceneforge-vieneu-onnx-v1':
            raise ValueError('Sai định dạng gói model.')
        rows = manifest.get('files', [])
        if not isinstance(rows, list) or len(rows) != len(expected) or {r.get('path') for r in rows if isinstance(r, dict)} != expected:
            raise ValueError('Gói thiếu hoặc thừa file model.')
        total = 0
        for row in rows:
            name, size = row['path'], row.get('bytes')
            if type(size) is not int or not 0 < size <= 512 * 1024**2 or name not in names or archive.getinfo(name).file_size != size:
                raise ValueError('Kích thước file model không hợp lệ.')
            if not isinstance(row.get('sha256'), str) or len(row['sha256']) != 64:
                raise ValueError('Thiếu mã SHA256.')
            total += size
        if total > 1024**3:
            raise ValueError('Gói model vượt giới hạn 1 GB.')
        with tempfile.TemporaryDirectory(prefix='voice-import-', dir=runtime) as temporary:
            staged = Path(temporary) / 'offline'
            staged.mkdir()
            for row in rows:
                name = row['path']  # Exact allowlist, never extract arbitrary archive paths.
                output = staged / name
                output.parent.mkdir(parents=True, exist_ok=True)
                digest, count = hashlib.sha256(), 0
                with archive.open(name) as source, output.open('xb') as out:
                    while True:
                        chunk = source.read(1024**2)
                        if not chunk:
                            break
                        count += len(chunk)
                        if count > row['bytes']:
                            raise ValueError('File giải nén vượt kích thước đã khai báo.')
                        digest.update(chunk); out.write(chunk)
                if count != row['bytes'] or digest.hexdigest() != row['sha256']:
                    raise ValueError('File model hỏng hoặc sai SHA256: ' + name)
            # Preserve user files and reject different existing weights. A partial
            # identical import can be safely finished on the next invocation.
            for row in rows:
                existing = target / row['path']
                if existing.exists() and (not existing.is_file() or hashlib.sha256(existing.read_bytes()).hexdigest() != row['sha256']):
                    raise ValueError('Có file model khác trong thư mục đích; không ghi đè: ' + row['path'])
            target.mkdir(exist_ok=True)
            for row in rows:
                output = target / row['path']
                output.parent.mkdir(parents=True, exist_ok=True)
                if not output.exists():
                    os.replace(staged / row['path'], output)
            (runtime / 'offline-import.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    if verify_speech:
        prepare(root, offline_only=True)
    print('Imported and SHA256-verified', len(expected), 'model files. Original ZIP preserved.')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    default = Path(os.environ.get('SCENEFORGE_LOCAL_DATA', str(Path.home() / '.sceneforge-local'))) / 'engines/vieneu'
    parser.add_argument('--directory', type=Path, default=default)
    args = parser.parse_args()
    try:
        import_bundle(args.bundle, args.directory)
    except (ValueError, KeyError, OSError, zipfile.BadZipFile, RuntimeError) as error:
        raise SystemExit('Chưa cài xong gói model: ' + str(error))


if __name__ == '__main__':
    main()
