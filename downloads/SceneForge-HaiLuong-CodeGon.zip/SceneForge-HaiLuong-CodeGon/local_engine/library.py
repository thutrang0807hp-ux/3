"""Durable library checkpoints, content-addressed assets and conservative cleanup.
Browser databases are a working cache. Checkpoints are CAS protected, never overwrite
another client's changes, and retain all referenced/trashed/timeline media.
"""
from pathlib import Path
import hashlib,json,os,re,shutil,sqlite3,tempfile,threading,time,uuid,zipfile
from contextlib import contextmanager

HASH=re.compile(r'^[a-f0-9]{64}$')
DBS={'sceneforge-app-shell':{'products','rooms','jobs','files','prefs','notifications'},'sceneforge-workflows':{'projects'},'sceneforge-editor-local':{'drafts'}}
LIBRARY_SCHEMA='''CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS asset(hash TEXT PRIMARY KEY,size INTEGER NOT NULL,mime TEXT,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS record(db TEXT,store TEXT,key TEXT,data TEXT NOT NULL,PRIMARY KEY(db,store,key));
CREATE TABLE IF NOT EXISTS asset_ref(db TEXT,store TEXT,key TEXT,hash TEXT REFERENCES asset(hash),PRIMARY KEY(db,store,key,hash));
CREATE INDEX IF NOT EXISTS ref_hash ON asset_ref(hash);
CREATE TABLE IF NOT EXISTS pin(hash TEXT PRIMARY KEY REFERENCES asset(hash),note TEXT);
CREATE TABLE IF NOT EXISTS room_index(id TEXT PRIMARY KEY,product_id TEXT,name TEXT,stage TEXT,archived INTEGER,trashed INTEGER);
CREATE INDEX IF NOT EXISTS room_product ON room_index(product_id,stage);
CREATE TABLE IF NOT EXISTS published(room_id TEXT,hash TEXT,path TEXT,PRIMARY KEY(room_id,hash,path));
CREATE TABLE IF NOT EXISTS mutation_receipt(id TEXT PRIMARY KEY,kind TEXT,base_revision INTEGER,result_revision INTEGER,digest TEXT,operation_id TEXT,created REAL);
INSERT OR IGNORE INTO meta VALUES('revision','0');'''

class Conflict(ValueError):pass

def sync_parent(path):
 if os.name!='nt':
  fd=os.open(str(path.parent),os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
  try:os.fsync(fd)
  finally:os.close(fd)

def atomic_json(path,value):
 tmp=path.with_name(path.name+'.tmp-'+uuid.uuid4().hex)
 with tmp.open('w',encoding='utf8')as f:json.dump(value,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path);sync_parent(path)

def hashes(value):
 if isinstance(value,dict):
  if value.get('$sf')in ('blob','file','dataurl'):
   h=value.get('hash','')
   if not HASH.fullmatch(h):raise ValueError('Mã file không hợp lệ.')
   yield h
  else:
   for v in value.values():yield from hashes(v)
 elif isinstance(value,list):
  for v in value:yield from hashes(v)

class Library:
 def __init__(self,data):
  self.data=Path(data);self.config=self.data/'library-location.json';self.lock=threading.RLock()
  self.root=Path(json.loads(self.config.read_text())['root'])if self.config.exists()else self.data/'SceneForge'
  from .library_lock import acquire
  self._root_guard=acquire(self.root);self.lock=self._root_guard.lock
  self.setup()
  from .storage_lifecycle import Lifecycle
  self.lifecycle=Lifecycle(self)
  self.lifecycle.resume()
  self.backup(daily=True)
 def setup(self):
  for name in ('kho','xuat','cache','sao-luu','schema-backups'): (self.root/name).mkdir(parents=True,exist_ok=True)
  self.path=self.root/'thu-vien.db'
  from .schema import migrate
  from .storage_lifecycle import SCHEMA
  migrate(self.path,[statement.strip()for statement in (LIBRARY_SCHEMA+';'+SCHEMA).split(';')if statement.strip()],version=3)
  with self.db()as db:
   db.execute('PRAGMA journal_mode=WAL')
   db.execute("INSERT OR IGNORE INTO meta VALUES('library_id',?)",(str(uuid.uuid4()),))
 @contextmanager
 def db(self):
  db=sqlite3.connect(self.path,timeout=30);db.execute('PRAGMA foreign_keys=ON');db.execute('PRAGMA synchronous=FULL');db.execute('PRAGMA busy_timeout=30000')
  try:
   with db:yield db
  finally:db.close()
 def asset_path(self,h):
  if not HASH.fullmatch(h):raise ValueError('Mã file không hợp lệ.')
  return self.root/'kho'/h[:2]/h
 def read_asset_path(self,h):
  path=self.asset_path(h)
  if path.is_file():return path
  with self.db()as db:row=db.execute('SELECT op_id FROM asset_lifecycle WHERE hash=?',(h,)).fetchone()
  return self.root/'kho'/'.cho-xoa'/row[0]/h if row and row[0]else path
 def add_file(self,tmp,mime='application/octet-stream',expected=None):
  tmp=Path(tmp)
  with tmp.open('rb')as source:digest=hashlib.file_digest(source,'sha256').hexdigest()
  if expected and expected!=digest:raise ValueError('File không khớp dấu vân tay.')
  size=tmp.stat().st_size
  with self.lock:
   with self.db()as db:self.lifecycle.revive(digest,db)
   dest=self.asset_path(digest);dest.parent.mkdir(exist_ok=True)
   if dest.exists():
    if dest.stat().st_size!=size:raise ValueError('File trong kho không đúng kích thước.')
    with dest.open('rb')as existing:
     if hashlib.file_digest(existing,'sha256').hexdigest()!=digest:raise ValueError('File trong kho đã bị thay đổi; chưa ghi đè.')
   else:
    stage=dest.with_name(dest.name+'.tmp-'+uuid.uuid4().hex)
    try:
     with tmp.open('rb')as source,stage.open('xb')as out:shutil.copyfileobj(source,out,1024*1024);out.flush();os.fsync(out.fileno())
     os.replace(stage,dest);sync_parent(dest)
    finally:stage.unlink(missing_ok=True)
   with self.db()as db:
    db.execute('INSERT OR IGNORE INTO asset VALUES(?,?,?,?)',(digest,size,str(mime)[:150],time.time()))
    db.execute('INSERT OR REPLACE INTO upload_lease VALUES(?,?)',(digest,time.time()+86400))
  return {'hash':digest,'size':size}
 def snapshot(self):
  with self.lock,self.db()as db:
   rev=int(db.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0]);records=[{'db':d,'store':s,'key':json.loads(k),'value':json.loads(v)}for d,s,k,v in db.execute('SELECT db,store,key,data FROM record ORDER BY db,store,key')]
   return {'format':'SceneForge-library-1','mutations':[dict(id=i,kind=k,base_revision=b,result_revision=r,digest=d,operation_id=o)for i,k,b,r,d,o in db.execute('SELECT id,kind,base_revision,result_revision,digest,operation_id FROM mutation_receipt ORDER BY created DESC LIMIT 100')],'revision':rev,'records':records,'pins':[dict(hash=h,note=n)for h,n in db.execute('SELECT hash,note FROM pin')],'library_id':db.execute("SELECT value FROM meta WHERE key='library_id'").fetchone()[0],'lifecycle':{'release':[list(r)for r in db.execute('SELECT room_id,hash,retain_until,mode FROM room_release')],'deleted':[list(r)for r in db.execute('SELECT room_id,deleted_at FROM deleted_room')]}}
 def validate(self,records):
  if not isinstance(records,list)or len(records)>100000:raise ValueError('Danh sách dữ liệu không hợp lệ.')
  rows=[];seen=set();refs=set()
  for row in records:
   if not isinstance(row,dict)or row.get('store')not in DBS.get(row.get('db'),set())or not isinstance(row.get('key'),(str,int,float)):raise ValueError('Bản ghi không hợp lệ.')
   key=json.dumps(row['key'],ensure_ascii=False,separators=(',',':'));identity=(row['db'],row['store'],key)
   if identity in seen:raise ValueError('Bản ghi bị trùng mã.')
   seen.add(identity);data=json.dumps(row['value'],ensure_ascii=False,separators=(',',':'),allow_nan=False)
   refs.update(hashes(row['value']));rows.append((*identity,data))
  if sum(len(v[3].encode('utf8'))for v in rows)>64*1024*1024:raise ValueError('Metadata vượt 64 MB.')
  return rows,refs
 def commit(self,records,revision,merge=False,pins=None,lifecycle=None,mutation_id=None):
  rows,refs=self.validate(records)
  if mutation_id is not None and(not isinstance(mutation_id,str)or not re.fullmatch(r'[A-Za-z0-9_-]{8,128}',mutation_id)):raise ValueError('Mã lưu không hợp lệ.')
  digest=hashlib.sha256(json.dumps(sorted(rows),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
  with self.lock,self.db()as db:
   db.execute('BEGIN IMMEDIATE')
   actual=int(db.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0])
   if mutation_id:
    receipt=db.execute('SELECT kind,base_revision,digest FROM mutation_receipt WHERE id=?',(mutation_id,)).fetchone()
    if receipt:
     if receipt!=('checkpoint',revision,digest):raise Conflict('Mã lưu trùng nhưng nội dung khác.')
     return self.snapshot()
   if revision!=actual:raise Conflict('Dữ liệu trên máy đã đổi ở cửa sổ khác. Chưa ghi đè; tải lại hoặc xuất bản trình duyệt trước.')
   for d,s,k,v in rows:
    if d=='sceneforge-app-shell'and s=='rooms'and db.execute('SELECT 1 FROM deleted_room WHERE room_id=?',(str(json.loads(k)),)).fetchone():raise Conflict('Mã dự án đã xóa. Đổi mã dự án khi nhập ZIP; không ghi đè ghi nhận xóa.')
   for h in refs:
    self.lifecycle.revive(h,db)
    asset=db.execute('SELECT size FROM asset WHERE hash=?',(h,)).fetchone()
    if not asset or not self.asset_path(h).is_file()or self.asset_path(h).stat().st_size!=asset[0]:raise ValueError('Thiếu tư liệu '+h[:12]+'. Chưa chuyển dữ liệu.')
   if lifecycle:
    for r,h,due,mode in lifecycle['release']:db.execute('INSERT OR IGNORE INTO room_release VALUES(?,?,?,?)',(r,h,due,mode))
    for r,at in lifecycle['deleted']:db.execute('INSERT OR IGNORE INTO deleted_room VALUES(?,?)',(r,at))
    db.execute("UPDATE meta SET value=? WHERE key='library_id'",(lifecycle['library_id'],))
   if merge:
    for d,s,k,v in rows:
     prior=db.execute('SELECT data FROM record WHERE db=? AND store=? AND key=?',(d,s,k)).fetchone()
     if prior and prior[0]!=v:raise Conflict('ZIP có mã dữ liệu trùng nhưng nội dung khác. Không ghi đè.')
   else:db.execute('DELETE FROM asset_ref');db.execute('DELETE FROM record');db.execute('DELETE FROM room_index')
   for d,s,k,v in rows:
    db.execute('INSERT OR IGNORE INTO record VALUES(?,?,?,?)',(d,s,k,v))
    data=json.loads(v)
    for h in set(hashes(data)):db.execute('INSERT OR IGNORE INTO asset_ref VALUES(?,?,?,?)',(d,s,k,h))
    if d=='sceneforge-app-shell'and s=='rooms':db.execute('INSERT OR REPLACE INTO room_index VALUES(?,?,?,?,?,?)',(str(json.loads(k)),data.get('productId'),data.get('name'),data.get('stage'),bool(data.get('archived')),bool(data.get('trashedAt'))))
   if pins is not None:
    db.execute('DELETE FROM pin')
    for pin in pins:
     if db.execute('SELECT 1 FROM asset WHERE hash=?',(pin['hash'],)).fetchone():db.execute('INSERT OR REPLACE INTO pin VALUES(?,?)',(pin['hash'],str(pin.get('note',''))[:500]))
   db.execute('DELETE FROM upload_lease WHERE hash IN (SELECT hash FROM asset_ref)')
   db.execute("UPDATE meta SET value=? WHERE key='revision'",(str(actual+1),))
   if mutation_id:self.record_mutation(db,mutation_id,'checkpoint',actual,actual+1,digest)
  from .storage_jobs import acknowledge_imports
  acknowledge_imports(self,records=None if merge else records,records_revision=actual+1)
  warnings=[]
  try:self.backup(daily=True)
  except (OSError,sqlite3.Error)as e:warnings.append('Đã lưu SQLite nhưng chưa tạo được sao lưu metadata: '+str(e))
  try:self.publish_exports()
  except (OSError,ValueError)as e:warnings.append('Đã lưu SQLite nhưng chưa chép được bản xuất: '+str(e))
  return {**self.snapshot(),'warnings':warnings}
 def record_mutation(self,db,id,kind,base,result,digest,operation=None):
  db.execute('INSERT INTO mutation_receipt VALUES(?,?,?,?,?,?,?)',(id,kind,base,result,digest,operation,time.time()))
  db.execute('DELETE FROM mutation_receipt WHERE id NOT IN (SELECT id FROM mutation_receipt ORDER BY created DESC LIMIT 100)')
 def backup(self,daily=False):
  with self.lock:
   folder=self.root/'sao-luu';day=time.strftime('%Y-%m-%d')
   if daily and any(folder.glob(day+'*.sqlite')):return
   name=day+'-'+time.strftime('%H%M%S')+'-'+uuid.uuid4().hex[:6]+'.sqlite';dest=folder/name;tmp=folder/(name+'.tmp')
   with self.db()as source:
    if daily and not source.execute('SELECT 1 FROM record LIMIT 1').fetchone():return
    target=sqlite3.connect(tmp)
    try:source.backup(target);check=target.execute('PRAGMA integrity_check').fetchone()[0]
    finally:target.close()
   if check!='ok':tmp.unlink(missing_ok=True);raise ValueError('Sao lưu không qua kiểm tra.')
   os.replace(tmp,dest);sync_parent(dest)
   for old in sorted(folder.glob('*.sqlite'),reverse=True)[14:]:old.unlink()
   return name
 def backups(self):return [{'name':p.name,'bytes':p.stat().st_size,'at':p.stat().st_mtime}for p in sorted((self.root/'sao-luu').glob('*.sqlite'),reverse=True)]
 def verify(self,refs):
  for h in refs:
   p=self.read_asset_path(h)
   if not p.is_file():raise ValueError('Thiếu tư liệu '+h[:12])
   with p.open('rb')as f:
    if hashlib.file_digest(f,'sha256').hexdigest()!=h:raise ValueError('Tư liệu bị thay đổi '+h[:12])
 def pause_recovered(self,records):
  records=json.loads(json.dumps(records))
  for r in records:
   if r['db']!='sceneforge-app-shell'or not isinstance(r['value'],dict):continue
   value=r['value']
   if r['store']=='rooms':
    if value.get('allowAutoGemini'):value['allowAutoGemini']=False
    if isinstance(value.get('archivePolicy'),dict)and value['archivePolicy'].get('automatic'):value['archivePolicy']['paused']=True;value['archivePolicy']['error']='Khôi phục dữ liệu; cần rà lại lịch thu gọn.'
    if value.get('stage')in ('new','analysis'):value['stage']='new';value['analysisDeferred']=True
   if r['store']=='jobs'and value.get('status')in ('running','submitted','unknown'):value['status']='unknown';value['error']='Khôi phục từ sao lưu; cần kiểm tra kết quả, không tự gửi lại.'
   if r['store']=='prefs'and r['key']=='main':value['paused']=True
  return records
 def restore(self,name,revision,allow_partial=False):
  if Path(name).name!=name or not name.endswith('.sqlite'):raise ValueError('Tên sao lưu không hợp lệ.')
  with self.lock:
   path=self.root/'sao-luu'/name
   if not path.is_file():raise ValueError('Không có sao lưu.')
   db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
   try:
    if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Sao lưu bị hỏng.')
    rows=[dict(db=d,store=s,key=json.loads(k),value=json.loads(v))for d,s,k,v in db.execute('SELECT db,store,key,data FROM record')];pins=[dict(hash=h,note=n)for h,n in db.execute('SELECT hash,note FROM pin')]
   finally:db.close()
   rows=self.lifecycle.restore_records(rows)
   for h in self.validate(rows)[1]:
    with self.db()as current:self.lifecycle.revive(h,current)
   required=self.validate(rows)[1]|{p['hash']for p in pins};missing=set()
   for h in required:
    try:self.verify({h})
    except ValueError:missing.add(h)
   skipped=set()
   if missing:
    if not allow_partial:raise ValueError('Thiếu tư liệu ngoài ý muốn: '+str(len(missing))+' file. Có thể chọn khôi phục các dự án còn đủ.')
    from .storage_lifecycle import owner,collect_strings
    bad=[row for row in rows if set(hashes(row['value']))&missing]
    if any(owner(row)is None for row in bad)or any(p['hash']in missing for p in pins):raise ValueError('Thiếu tư liệu dùng chung hoặc bản ghim. Chưa tự khôi phục một phần; cần bổ sung file trước.')
    skipped={owner(row)for row in bad};badkeys={str(row['key'])for row in rows if owner(row)in skipped}
    while True:
     extra={owner(row)for row in rows if owner(row)and collect_strings(row['value'])&badkeys}-skipped
     if not extra:break
     skipped.update(extra);badkeys.update(str(row['key'])for row in rows if owner(row)in extra)
    rows=[row for row in rows if owner(row)not in skipped]
    if not any(row['store']=='rooms'for row in rows):raise ValueError('Không còn dự án đủ tư liệu để khôi phục; thư viện hiện tại được giữ.')
   self.backup();result=self.commit(self.pause_recovered(rows),revision,pins=pins)
   result['restore_report']={'skipped_rooms':sorted(skipped),'released_rooms':[r['key']for r in rows if r['store']=='rooms'and r['value'].get('restoredReleased')],'missing_files':len(missing)}
   return result
 def status(self):
  with self.lock,self.db()as db:
   stored=[(self.read_asset_path(h),size)for h,size in db.execute('SELECT hash,size FROM asset')]
   return {'root':str(self.root),'companionRoot':str(self.data),'logsRoot':str(self.data/'logs'),'revision':int(db.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0]),'records':db.execute('SELECT count(*) FROM record').fetchone()[0],'assets':db.execute('SELECT count(*) FROM asset').fetchone()[0],'assetBytes':sum(p.stat().st_size for p,_ in stored if p.is_file()),'missingAssets':sum(not p.is_file()for p,_ in stored),'backups':self.backups(),'browserBackups':[{'name':p.name,'bytes':p.stat().st_size}for p in sorted((self.root/'sao-luu').glob('trinh-duyet-*.zip'),reverse=True)],'outputRoot':str(self.output_root()),'pins':db.execute('SELECT count(*) FROM pin').fetchone()[0]}
 def protected_hashes(self):
  return self.lifecycle.protected()
 def cleanup_plan(self):
  with self.lock:
   protected=self.protected_hashes();cutoff=time.time()-86400;items=[]
   for p in (self.root/'kho').glob('*/*'):
    if HASH.fullmatch(p.name)and p.is_file()and p.name not in protected and p.stat().st_mtime<cutoff:items.append({'hash':p.name,'size':p.stat().st_size})
   items.sort(key=lambda i:i['hash'])
   token=hashlib.sha256(json.dumps(items,sort_keys=True).encode()).hexdigest()
   return {'token':token,'items':items,'bytes':sum(i['size']for i in items),'note':'Giữ mọi file được dự án, timeline, Thùng rác, bản ghim hoặc 14 sao lưu tham chiếu; bỏ qua file mới dưới 24 giờ.'}
 def cleanup(self,token):
  try:from send2trash import send2trash
  except ImportError:raise ValueError('Chưa cài Send2Trash. Chạy lại bộ khởi động để cài thư viện; chưa xóa file nào.')
  with self.lock,self.db()as db:
   db.execute('BEGIN IMMEDIATE')
   plan=self.cleanup_plan()
   if plan['token']!=token:raise Conflict('Danh sách dọn đã thay đổi. Hãy xem lại trước.')
   done=[];errors=[]
   for item in plan['items']:
    try:send2trash(str(self.asset_path(item['hash'])))
    except OSError as e:errors.append({'hash':item['hash'],'error':str(e)});continue
    db.execute('DELETE FROM asset WHERE hash=?',(item['hash'],))
    done.append(item)
   return {'files':len(done),'bytes':sum(i['size']for i in done),'errors':errors}
 def release_compacted(self,room_id,revision):
  """Release only hashes retired by an explicitly compacted room, never live/pinned/backup assets."""
  if not isinstance(room_id,str)or len(room_id)>200:raise ValueError('Mã dự án không hợp lệ.')
  with self.lock,self.db()as db:
   db.execute('BEGIN IMMEDIATE')
   actual=int(db.execute("SELECT value FROM meta WHERE key='revision'").fetchone()[0])
   if revision!=actual:raise Conflict('Thư viện đã thay đổi; lưu ổn định trước khi dọn kho.')
   row=db.execute("SELECT data FROM record WHERE db='sceneforge-app-shell' AND store='rooms' AND key=?",(json.dumps(room_id,ensure_ascii=False,separators=(',',':')),)).fetchone()
   if not row:raise ValueError('Không có dự án trong thư viện.')
   room=json.loads(row[0]);candidates=room.get('archiveRetiredHashes',[])
   if room.get('archiveState')!='final-only'or not room.get('compactedAt'):raise ValueError('Dự án chưa chốt giữ thành phẩm.')
   if not isinstance(candidates,list)or len(candidates)>20000 or any(not isinstance(h,str)or not HASH.fullmatch(h)for h in candidates):raise ValueError('Danh sách file đã thu gọn không hợp lệ.')
   # A snapshot, other room, trash, pin or backup can retain a byte-identical file.
   protected=self.protected_hashes();removed=[];kept=[];errors=[]
   for h in sorted(set(candidates)):
    lifecycle=db.execute('SELECT state FROM asset_lifecycle WHERE hash=?',(h,)).fetchone()
    if lifecycle and lifecycle[0]!='present':kept.append(h);continue
    if h in protected:kept.append(h);continue
    asset=db.execute('SELECT size FROM asset WHERE hash=?',(h,)).fetchone()
    if not asset:continue
    try:self.asset_path(h).unlink(missing_ok=True)
    except OSError as e:errors.append({'hash':h,'error':str(e)});continue
    db.execute('DELETE FROM asset WHERE hash=?',(h,));removed.append({'hash':h,'size':asset[0]})
   return {'files':len(removed),'bytes':sum(x['size']for x in removed),'protected':len(kept),'errors':errors,'note':'Chỉ dọn file trung gian đã rời dự án; giữ file dùng chung, ghim, Thùng rác và sao lưu. File ngoài app không bị xóa.'}
 def set_pin(self,h,pinned,note=''):
  with self.lock,self.db()as db:
   if not db.execute('SELECT 1 FROM asset WHERE hash=?',(h,)).fetchone():raise ValueError('Không có tư liệu.')
   if pinned:self.lifecycle.revive(h,db,cancel=False)
   if pinned:db.execute('INSERT OR REPLACE INTO pin VALUES(?,?)',(h,str(note)[:500]))
   else:db.execute('DELETE FROM pin WHERE hash=?',(h,))
 def bundle(self,room_id=None,snapshot=None):
  with self.lock:
   if snapshot is None:
    with self.db()as db:
     waiting=db.execute("SELECT 1 FROM purge_op WHERE state!='cancelled' AND due>? AND restore_data!='{}'"+(" AND room_id=?"if room_id else'')+' LIMIT 1',(time.time(),room_id)if room_id else(time.time(),)).fetchone()
     if waiting:raise ValueError('Còn dự án/tư liệu trong thời hạn chờ xóa. Lấy lại hoặc chốt xóa trước khi xuất ZIP; chuyển nguyên thư viện vẫn giữ khu chờ.')
   snap=snapshot or self.snapshot()
   snap['scope']='project'if room_id else'library'
   if room_id:snap.pop('lifecycle',None)
   if room_id:
    room=next((r['value']for r in snap['records']if r['db']=='sceneforge-app-shell'and r['store']=='rooms'and r['key']==room_id),None)
    if not room:raise ValueError('Không có phòng.')
    snap['records']=[r for r in snap['records']if (r['db']=='sceneforge-app-shell'and ((r['store']=='rooms'and r['key']==room_id)or(r['store']=='products'and r['key']==room.get('productId'))or(r['store']=='jobs'and isinstance(r['value'],dict)and r['value'].get('roomId')==room_id)or(r['store']=='files'and str(r['key']).startswith((room_id+':','bank:'+str(room.get('productId'))+':')))))or(r['db']in ('sceneforge-workflows','sceneforge-editor-local')and r['key']==room_id)]
   if room_id:
    def strings(v):
     if isinstance(v,str):yield v
     elif isinstance(v,dict):
      for x in v.values():yield from strings(x)
     elif isinstance(v,list):
      for x in v:yield from strings(x)
    known={(r['db'],r['store'],str(r['key']))for r in snap['records']}
    all_files=[r for r in self.snapshot()['records']if r['db']=='sceneforge-app-shell'and r['store']=='files']
    while True:
     used={v for r in snap['records']for v in strings(r['value'])};extra=[r for r in all_files if str(r['key'])in used and (r['db'],r['store'],str(r['key']))not in known]
     if not extra:break
     snap['records'].extend(extra);known.update((r['db'],r['store'],str(r['key']))for r in extra)
   refs=self.validate(snap['records'])[1]
   if not room_id:refs.update(p['hash']for p in snap['pins'])
   self.verify(refs);snap['pins']=[p for p in snap['pins']if p['hash']in refs]
   snap['assets']={h:{'size':self.asset_path(h).stat().st_size}for h in sorted(refs)}
   path=self.root/'cache'/('phong-'if room_id else 'thu-vien-');path=path.with_name(path.name+uuid.uuid4().hex+'.zip')
   with zipfile.ZipFile(path,'w',zipfile.ZIP_STORED,strict_timestamps=False)as z:
    z.writestr('du-an.json',json.dumps(snap,ensure_ascii=False))
    for h in sorted(refs):z.write(self.asset_path(h),'assets/'+h)
   return path
 def import_bundle(self,path,revision):
  with self.lock,zipfile.ZipFile(path)as z:
   names=z.namelist()
   if len(names)>60001 or len(names)!=len(set(names))or 'du-an.json'not in names or z.getinfo('du-an.json').file_size>64*1024*1024:raise ValueError('ZIP không hợp lệ.')
   if sum(i.file_size for i in z.infolist())>4*1024**3:raise ValueError('ZIP vượt 4 GB giải nén.')
   snap=json.loads(z.read('du-an.json'))
   if snap.get('format')!='SceneForge-library-1':raise ValueError('Không đúng ZIP SceneForge mới.')
   rows,refs=self.validate(self.pause_recovered(snap['records']))
   refs.update(p['hash']for p in snap.get('pins',[])if isinstance(p,dict)and HASH.fullmatch(str(p.get('hash',''))))
   if set(names)!={'du-an.json'}|{'assets/'+h for h in refs}:raise ValueError('ZIP thiếu hoặc thừa file.')
   # Reject collisions before changing even the asset store.
   current=self.snapshot()
   if current['revision']!=revision:raise Conflict('Thư viện đã đổi.')
   existing={(r['db'],r['store'],json.dumps(r['key'],ensure_ascii=False,separators=(',',':'))):json.dumps(r['value'],ensure_ascii=False,separators=(',',':'),allow_nan=False)for r in current['records']}
   if any((d,s,k)in existing and existing[d,s,k]!=v for d,s,k,v in rows):raise Conflict('Mã dự án/sản phẩm trùng nhưng nội dung khác; không ghi đè.')
   for h in refs:
    fd,tmp=tempfile.mkstemp(dir=self.root/'cache');os.close(fd)
    try:
     with z.open('assets/'+h)as source,open(tmp,'wb')as out:shutil.copyfileobj(source,out,1024*1024)
     self.add_file(tmp,expected=h)
    finally:Path(tmp).unlink(missing_ok=True)
   lifecycle=None
   policy=snap.get('lifecycle')
   if snap.get('scope')=='library'and policy and not any(r['store']=='rooms'for r in current['records'])and not current['lifecycle']['release']and not current['lifecycle']['deleted']:
    import math
    try:
     source_id=str(uuid.UUID(snap['library_id']));release=policy['release'];deleted=policy['deleted']
     if len(release)+len(deleted)>100000:raise ValueError()
     for r,h,due,mode in release:
      if not isinstance(r,str)or len(r)>200 or not HASH.fullmatch(h)or not isinstance(due,(int,float))or not math.isfinite(due)or mode not in {'now:unused','retain:unused','now:compact','retain:compact','now:delete','retain:delete'}:raise ValueError()
     for r,at in deleted:
      if not isinstance(r,str)or len(r)>200 or not isinstance(at,(int,float))or not math.isfinite(at):raise ValueError()
     if any(r['store']=='rooms'and r['key']in {v[0]for v in deleted}for r in snap['records']):raise ValueError()
     lifecycle={'library_id':source_id,'release':release,'deleted':deleted}
    except (ValueError,TypeError,KeyError):raise ValueError('Chính sách lưu trữ trong ZIP không hợp lệ.')from None
   self.backup();return self.commit(self.pause_recovered(snap['records']),revision,merge=True,pins=current['pins']+[p for p in snap.get('pins',[])if p.get('hash')in refs],lifecycle=lifecycle)
 def relocate(self,target,revision):
  target=Path(target).expanduser().resolve()
  with self.lock:
   if self.snapshot()['revision']!=revision:raise Conflict('Thư viện đã đổi.')
   old=self.root.resolve()
   if target==old or old in target.parents or target in old.parents:raise ValueError('Chọn thư mục khác, không nằm trong thư mục hiện tại.')
   if target.exists():raise ValueError('Chọn đường dẫn thư mục mới chưa tồn tại, để không ghi đè.')
   target.parent.mkdir(parents=True,exist_ok=True);stage=target.with_name(target.name+'.moving-'+uuid.uuid4().hex)
   try:
    stage.mkdir()
    for name in ('kho','xuat','sao-luu','schema-backups'):shutil.copytree(old/name,stage/name)
    (stage/'cache').mkdir()
    with self.db()as source:
     dest=sqlite3.connect(stage/'thu-vien.db')
     try:source.backup(dest)
     finally:dest.close()
    for name in ('kho','xuat','sao-luu','schema-backups'):
     for p in (old/name).rglob('*'):
      if p.is_file():
       q=stage/p.relative_to(old)
       with p.open('rb')as a,q.open('rb')as b:
        if hashlib.file_digest(a,'sha256').digest()!=hashlib.file_digest(b,'sha256').digest():raise ValueError('Bản chép chưa khớp; chưa đổi nơi lưu.')
    os.replace(stage,target)
    from .library_lock import acquire
    guard=acquire(target);atomic_json(self.config,{'root':str(target)});self.root=target;self._root_guard=guard;self.lock=guard.lock;self.setup()
    with self.db()as db:
     row=db.execute("SELECT value FROM meta WHERE key='output_root'").fetchone()
     if row:
      prior=Path(row[0])
      if prior==old or old in prior.parents:db.execute("UPDATE meta SET value=? WHERE key='output_root'",(str(target/prior.relative_to(old)),))
   finally:
    if stage.exists():shutil.rmtree(stage)
   return {'root':str(target),'oldRoot':str(old),'oldKept':True}

 def output_root(self):
  with self.db()as db:row=db.execute("SELECT value FROM meta WHERE key='output_root'").fetchone()
  return Path(row[0])if row else self.root/'xuat'
 def set_output(self,path):
  dest=Path(path).expanduser().resolve()if path else self.root/'xuat'
  internal=self.root.resolve();standard=(self.root/'xuat').resolve()
  if (dest==internal or internal in dest.parents)and not(dest==standard or standard in dest.parents):raise ValueError('Trong thư viện chỉ đặt bản xuất ở xuat/. Hoặc chọn thư mục riêng bên ngoài.')
  for name in ('kho','cache','sao-luu'):
   protected=(self.root/name).resolve()
   if dest==protected or protected in dest.parents:raise ValueError('Không đặt bản xuất trong kho nội bộ/cache/sao lưu.')
  dest.mkdir(parents=True,exist_ok=True)
  with self.lock,self.db()as db:
   if dest==standard:db.execute("DELETE FROM meta WHERE key='output_root'")
   else:db.execute("INSERT OR REPLACE INTO meta VALUES('output_root',?)",(str(dest),))
  return {'path':str(dest)}
 def publish_exports(self):
  def clean(name):return re.sub(r'[\\/:*?"<>|\x00-\x1f]','-',str(name)).strip(' .')[:90]or 'Video'
  with self.lock:
   rows=self.snapshot()['records'];rooms={str(r['key']):r['value']for r in rows if r['db']=='sceneforge-app-shell'and r['store']=='rooms'};products={str(r['key']):r['value']for r in rows if r['db']=='sceneforge-app-shell'and r['store']=='products'};output=self.output_root()
   for row in rows:
    if row['db']!='sceneforge-app-shell'or row['store']!='files':continue
    key=str(row['key']);suffix=':export:srt'if key.endswith(':export:srt')else ':export'if key.endswith(':export')else None
    if not suffix:continue
    rid=key[:-len(suffix)];room=rooms.get(rid);v=row['value']
    if not room or not isinstance(v,dict)or v.get('$sf')not in ('blob','file'):continue
    h=v['hash']
    with self.db()as db:
     if db.execute('SELECT 1 FROM published WHERE room_id=? AND hash=?',(rid,h)).fetchone():continue
    product=products.get(str(room.get('productId')),{});folder=output/clean(product.get('name','San-pham'));folder.mkdir(parents=True,exist_ok=True)
    ext='.srt'if suffix.endswith(':srt')else '.webm'if 'webm'in v.get('type','')else '.mp4';name=clean(room.get('name',rid))+'_'+time.strftime('%Y-%m-%d')+'_'+h[:8]+ext;dest=folder/name
    if dest.exists():
     with dest.open('rb')as f:same=hashlib.file_digest(f,'sha256').hexdigest()==h
     if not same:dest=folder/(dest.stem+'_'+uuid.uuid4().hex[:8]+ext)
    if not dest.exists():
     tmp=dest.with_name(dest.name+'.tmp-'+uuid.uuid4().hex)
     try:
      with self.asset_path(h).open('rb')as source,tmp.open('xb')as out:shutil.copyfileobj(source,out,1024*1024);out.flush();os.fsync(out.fileno())
      os.replace(tmp,dest);sync_parent(dest)
     finally:tmp.unlink(missing_ok=True)
    path=str(dest.relative_to(self.root))if self.root in dest.parents else str(dest)
    with self.db()as db:db.execute('INSERT OR IGNORE INTO published VALUES(?,?,?)',(rid,h,path))
 def export_folder(self,room_id):
  with self.lock,self.db()as db:row=db.execute('SELECT path FROM published WHERE room_id=? ORDER BY rowid DESC LIMIT 1',(room_id,)).fetchone()
  if not row:return self.output_root()
  p=Path(row[0]);return (p if p.is_absolute()else self.root/p).parent

 def cache_plan(self):
  with self.lock:
   items=[{'name':p.name,'size':p.stat().st_size}for p in (self.root/'cache').glob('*.zip')if p.is_file()and p.name.startswith(('phong-','thu-vien-'))and p.stat().st_mtime<time.time()-3600]
   items.sort(key=lambda i:i['name']);return {'items':items,'bytes':sum(i['size']for i in items),'token':hashlib.sha256(json.dumps(items,sort_keys=True).encode()).hexdigest()}
 def clean_cache(self,token):
  with self.lock:
   plan=self.cache_plan()
   if plan['token']!=token:raise Conflict('Cache đã thay đổi. Hãy xem lại trước.')
   for item in plan['items']:(self.root/'cache'/item['name']).unlink(missing_ok=True)
   return {'files':len(plan['items']),'bytes':plan['bytes']}
