"""A durable negative receipt is proof; an HTTP code or missing row is not."""
from functools import wraps
from fastapi import HTTPException

def guarded_submission(method):
    @wraps(method)
    async def guarded(self,body):
        try:return await method(self,body)
        except OSError:
            rid=body.get('request_id')
            try:self.valid_id(rid)
            except HTTPException:raise HTTPException(507,'Không ghi được dữ liệu chuẩn bị trên máy.')from None
            receipt=self.ledger.receipt(rid)
            detail={**receipt,'code':'NOT_SUBMITTED'if receipt.get('submitted')is False else'REQUEST_EXISTS',
                    'message':'Không ghi được dữ liệu trên máy. '+('Chưa gửi yêu cầu tạo; dọn ổ hoặc kiểm quyền ghi rồi chuẩn bị lượt mới.'if receipt.get('submitted')is False else'Kiểm tra lượt đã gửi trước khi tạo lại.')}
            raise HTTPException(507,detail)from None
        except HTTPException as error:
            rid=body.get('request_id')
            try:self.valid_id(rid)
            except HTTPException:raise error
            if not(400<=error.status_code<500 or error.status_code==507):raise
            receipt=self.ledger.reject_before_claim(rid)
            detail=error.detail if isinstance(error.detail,dict)else {'message':str(error.detail)}
            # Existing submitted/done/unknown rows can never become negative receipts.
            detail={**detail,**receipt,'code':detail.get('code','NOT_SUBMITTED'if receipt['submitted']is False else'REQUEST_EXISTS')}
            raise HTTPException(error.status_code,detail)from None
    return guarded
