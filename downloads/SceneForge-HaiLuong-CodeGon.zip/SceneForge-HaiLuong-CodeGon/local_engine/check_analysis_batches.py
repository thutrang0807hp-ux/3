"""Global scene/line codes, partial contract validation and bounded clear evidence."""
import base64,io
from PIL import Image
from .frame_analysis import checked_input,assemble_partial
from .gemini_chat import evidence_sheets

def main():
    raw=io.BytesIO();Image.new('RGB',(576,1024),'blue').save(raw,format='PNG');image='data:image/png;base64,'+base64.b64encode(raw.getvalue()).decode()
    body={'duration':16,'batch':{'offset':8,'start':8,'end':16},'scenes':[{'start':i,'end':i+1,'frames':[image]*3,'ocr':[]}for i in range(8,16)],'lines':[{'id':'source-'+str(i),'source_index':i,'start':i,'end':i+.5,'original':'Đây là sản phẩm thật để kiểm tra.'}for i in range(8,16)]}
    scenes,source,eligible,images=checked_input(body)
    assert scenes[0]['code']=='C09'and source[0]['code']=='L009'and len(images)==24
    response={'scenes':[],'lines':{r['code']:{'translation':'Lời dịch','newText':'Lời viết lại','faceTalking':False}for r in eligible}}
    for s in scenes:response['scenes'].append({'code':s['code'],'line_ids':s['line_ids'],'description':'Evidence','hasPerson':False,'faceTalking':False,'hasProduct':True,'competitorLogo':False,'visual':{l:{k:''for k in ('person','product','scale','composition','background','lighting')}for l in ('vi','en')},'motion':{l:{k:''for k in ('camera','initial','action','final')}for l in ('vi','en')},'promptFrame':{'vi':'Khung','en':'Frame'}})
    response['scenes'][1]['line_ids']=['L999']
    result=assemble_partial(response,scenes,source,eligible)
    assert result['can_apply']and result['partial']and len(result['scenes'])==7 and result['invalid_codes']==['C10']
    assert result['scenes'][0]['start']==8 and result['script'][0]['sourceLineId']=='source-8'
    sheets=evidence_sheets(images);assert len(sheets)==6
    for sheet in sheets:
        with Image.open(io.BytesIO(base64.b64decode(sheet['data'])))as picture:assert picture.size==(1280,2320)
    print('PASS: 8-scene batch retains C09/L009 global IDs and timings, one bad scene blocks only that scene, 24 original 576x1024 evidence images fit six labelled sheets.')

if __name__=='__main__':main()
