"""Gemini Chat SDK worker. No API key, browser-cookie discovery or automatic resend."""
import asyncio
import base64
import contextlib
import json
import os
from pathlib import Path
import sys
from urllib.parse import urlsplit


def single_send_type(base):
    class SingleSend(base):
        async def _generate(self, *args, **kwargs):
            self._sf_received_output = False
            async for item in base._generate.__wrapped__(self, *args, **kwargs):
                self._sf_received_output = True
                yield item
    return SingleSend


async def execute(body, client_type=None):
    os.environ['GEMINI_COOKIE_PATH'] = str(Path(body['_workspace']) / 'cookie-cache')
    from gemini_webapi import GeminiClient, GeneratedImage
    from gemini_webapi.exceptions import AuthError, UsageLimitExceededError, ModelInvalidError
    from loguru import logger
    logger.remove()
    import importlib
    importlib.import_module('gemini_webapi.utils.get_access_token').HAS_BC3 = False

    cookies = body.get('session', {}).get('cookies', {})
    if not cookies.get('__Secure-1PSID'):
        return {'ok': False, 'accepted': False, 'reason': 'auth'}
    if client_type is None and not callable(getattr(getattr(GeminiClient,'_generate',None),'__wrapped__',None)):
        return {'ok':False,'accepted':False,'reason':'sdk_incompatible','code':'SDK_CONTRACT_MISMATCH'}
    client = (client_type or single_send_type(GeminiClient))(secure_1psid=cookies['__Secure-1PSID'], secure_1psidts=cookies.get('__Secure-1PSIDTS'))
    client.cookies = cookies
    sent = False
    try:
        await client.init(timeout=450, auto_refresh=False, auto_close=False, watchdog_timeout=10000, verbose=False)
        if not client._check_account_status() or getattr(client, '_cookie_source', '') == 'Guest' or not client.access_token:
            raise AuthError('account required')
        models = [{'id': m.model_name, 'name': m.model_name} for m in (client.list_models() or [])]
        if body['operation'] == 'check':
            answer = {'ok': True, 'models': models}
        else:
            model = body.get('model') or None
            if model and model not in {m['id'] for m in models}:
                return {'ok': False, 'accepted': False, 'reason': 'input'}
            refs = []
            for index, media in enumerate(body.get('references', [])):
                ext = {'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp',
                       'video/mp4': '.mp4', 'video/webm': '.webm', 'video/quicktime': '.mov'}[media['mime_type']]
                path = Path(body['_workspace']) / (str(index) + ext)
                path.write_bytes(base64.b64decode(media['data'], validate=True))
                refs.append(path)
            sent = True
            response = await client.generate_content(body['prompt'], files=refs or None, model=model)
            if body.get('kind') == 'image':
                images = [i for i in response.images if isinstance(i, GeneratedImage)]
                if not images:
                    return {'ok': False, 'accepted': True, 'reason': 'no_generated_image'}
                url = urlsplit(images[0].url)
                if url.scheme != 'https' or not url.hostname or not (url.hostname == 'googleusercontent.com' or url.hostname.endswith('.googleusercontent.com')):
                    raise ValueError('unsupported generated image URL')
                await images[0].save(path=str(Path(body['output']).parent), filename=Path(body['output']).name,
                                     client=client.client, full_size=False, verbose=False)
                answer = {'ok': True, 'image': True}
            else:
                text = response.text
                if not isinstance(text, str) or not text.strip() or len(text) > 500000:
                    raise ValueError('invalid text')
                answer = {'ok': True, 'text': text}
        answer['session'] = {'cookies': {c.name: c.value for c in client.cookies.jar
                               if c.domain.lstrip('.') == 'google.com' or c.domain.endswith('.google.com')}}
        return answer
    except UsageLimitExceededError:
        # SDK typed error maps Google's explicit usage-limit rejection, not a
        # generic HTTP 429/network error.
        return {'ok': False, 'accepted': True if getattr(client, '_sf_received_output', False) else False, 'reason': 'quota'}
    except AuthError:
        return {'ok': False, 'accepted': sent, 'reason': 'auth'}
    except ModelInvalidError:
        return {'ok': False, 'accepted': sent, 'reason': 'input'}
    except Exception:
        return {'ok': False, 'accepted': None if sent else False, 'reason': 'unknown'}
    finally:
        with contextlib.suppress(Exception):
            await client.close()


if __name__ == '__main__':
    body = json.loads(sys.stdin.buffer.read(45 * 1024**2))
    with contextlib.redirect_stdout(sys.stderr):
        result = asyncio.run(execute(body))
    sys.stdout.write(json.dumps(result))
