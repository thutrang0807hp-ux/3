"""Review repros + late results through actual browser/API/files; provider GET fixture only."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1];raw=(root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()
 with tempfile.TemporaryDirectory(prefix='sf-photo-review-fixes-')as data:
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'review-photo',name:'Review fixture',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoContentMatches==="function"')
    wf.evaluate('''()=>{
     const vi='Bạn có biết không? Làn da khô ráp cần được chăm sóc mỗi ngày bằng sản phẩm phù hợp với nhu cầu và thói quen của bạn, chỉ một lượng nhỏ là đủ.';
     const plan=text=>{const b={seconds:9,text};return photoPlanParts(b);};
     if(plan(vi).some(p=>p.duration<3||p.generationDuration>8.001))throw Error('Review repro: tiny or overlong clip');
     if(photoPlanParts({seconds:2,text:'Một cảnh.'})[0].duration!==2)throw Error('Short scene was padded');
     for(const text of ['皮肤干燥怎么办？只要一点点，就能保湿一整天。现在下单还送小样。','顔も商品も自然に見せてください。手で商品を持ち上げて、ゆっくり回してください。','손으로 제품을 들고 천천히 돌려 주세요. 자연스럽게 보여 주세요.','Đưa sản phẩm lên. Giữ đúng màu sắc, rồi đặt xuống.','产品👩🏽‍💻展示，自然光。继续展示产品。']){
      const b={seconds:13,text},parts=photoPlanParts(b),rows=SFClipPlanning.assignText(text,13,parts);
      if(rows.some(r=>!r.text)||rows.map(r=>r.text).join('').replace(/\\s/g,'')!==text.replace(/\\s/g,''))throw Error('Dialogue lost/duplicated: '+text);
      if(parts.slice(0,-1).some(p=>!photoTextTimeline(b).breaks.some(c=>Math.abs(c.at-p.end)<.001)))throw Error('Clip boundary not aligned to shared text map');
      if(rows.some(r=>/[\\uD800-\\uDBFF]$|^[\\uDC00-\\uDFFF]/u.test(r.text)))throw Error('Unicode grapheme broken');
     }
     for(let seconds=.2;seconds<80;seconds+=.73){const parts=photoPlanParts({seconds,text:vi.repeat(3)});if(parts.length!==Math.ceil((seconds-.001)/8)||parts.some(p=>p.duration<=0||p.generationDuration>8.002)||Math.abs(parts.reduce((n,p)=>n+p.duration,0)-seconds)>.002)throw Error('Planner duration invariant');}
    }''')
    wf.evaluate('''async raw=>{
     const canvas=document.createElement('canvas');canvas.width=90;canvas.height=160;canvas.getContext('2d').fillRect(0,0,90,160);const image=canvas.toDataURL();await bridge.putFile(room.id+':ref',await(await fetch(image)).blob());draft.refs={product:{images:[{id:'p',key:room.id+':ref',name:'Product',image}]},background:{images:[]},person:{images:[]}};
     draft.beats=[{id:'b',name:'Product',type:'wide',seconds:6,text:'Một câu ngắn.',visualPrompt:'Real product on a table',motionPrompt:'Slow push',angle:'Medium',movement:'Push',clips:[]}];draft.voice.mode='native';draft.flowJobs=[];draft.storyboardImages=[{id:'one',key:room.id+':story:one',name:'Plan one'},{id:'two',key:room.id+':story:two',name:'Plan two'}];draft.storyboardImage='one';
     const b=draft.beats[0];photoFreezeParts(b);const p=photoParts(b)[0],bytes=Uint8Array.from(atob(raw),c=>c.charCodeAt(0)),file=new Blob([bytes],{type:'video/mp4'}),info=await photoReadClip(file,6);const key=room.id+':current';await bridge.putFile(key,file);b.clips=[{id:'current',key,part:'a',name:'Approved current',version:10,generationOrder:10,slotStart:0,slotEnd:6,signature:photoSceneSignature(b,p),reviewDecision:{status:'accepted'},...info}];b.chosenParts={a:'current'};
     const signature=b.clips[0].signature;draft.storyboardImage='two';if(photoSceneSignature(b,p)!==signature||!photoClipValid(b,p))throw Error('Storyboard-only change invalidates accepted video');
     // Old array signature remains usable after storyboard-only change, with exact old speech.
     const old=JSON.stringify([photoSignatureBeforeFlow(b),'one',room.id+':story:one',b.approvedFrame||null,b.clipPlan||null,b.clipPlanning||null,{id:'a',text:photoPartText(b,p),prompt:null}]);b.clips[0].signature=old;if(!photoClipValid(b,p))throw Error('Legacy approval invalidated by storyboard migration');b.clips[0].signature=signature;
     b.motionPrompt='Different action';if(photoClipValid(b,p)||photoLatest(b,'a'))throw Error('Changed generation input reused accepted clip');b.motionPrompt='Slow push';
     draft.plan=[{id:'preserve-plan',clipId:'current'}];await save();render();
    }''',base64.b64encode(raw).decode())
    calls=[];page.on('request',lambda req:calls.append((req.method,req.url))if req.method=='POST'and '/local-api/flow/jobs'in req.url else None)
    for rid,reason,order in [('flow-old-content','content_changed',11),('flow-old-order','older_request',9)]:
     wf.evaluate('''({rid,reason,order})=>{const b=draft.beats[0],p=photoParts(b)[0],original=b.motionPrompt;if(reason==='content_changed')b.motionPrompt='Old scene';const signature=photoSceneSignature(b,p);b.motionPrompt=original;draft.flowJobs.push({id:rid,provider:'flow',kind:'video',beatId:'b',part:'a',signature,generationOrder:order,generationDuration:6,slotStart:0,slotEnd:6,state:'done'});}''',{'rid':rid,'reason':reason,'order':order})
     page.route('**/local-api/flow/jobs/'+rid,lambda route,request,rid=rid:route.fulfill(json={'id':rid,'state':'done','result':{'mime_type':'video/mp4','account_id':'fixture'}}))
     page.route('**/local-api/flow/files/'+rid,lambda route:route.fulfill(body=raw,content_type='video/mp4'))
     wf.evaluate('async()=>{await photoRecoverFlows();}')
     assert wf.evaluate('photoLatest(draft.beats[0],"a").id')=='current'
     assert wf.evaluate('photoClipValid(draft.beats[0],photoParts(draft.beats[0])[0])')
     assert wf.evaluate('draft.plan[0].id')=='preserve-plan'
     assert wf.evaluate('draft.beats[0].staleClips.at(-1).staleReason')==reason
    wf.evaluate('photoSentJobs()');assert wf.locator('a').count()==2;wf.evaluate("$('#photoDialog').close()")
    assert not calls,calls
    # Approval prunes only the selected slot's alternatives; late-result bytes survive.
    wf.evaluate('async()=>{const b=draft.beats[0];await photoApproveSlots([{b,p:photoParts(b)[0]}]);}')
    assert wf.evaluate('draft.beats[0].staleClips.length')==2
    page.evaluate('async()=>{await flushFrames();await SceneForgeStorage.checkpoint();}')
    page.reload();page.wait_for_function('SceneForgeStorage.state.active');page.evaluate("openRoom('review-photo','analysis')")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&draft.beats[0]?.id==="b"')
    assert wf.evaluate('photoClipValid(draft.beats[0],photoParts(draft.beats[0])[0])')
    wf.evaluate('photoPlanningDialog()');assert '1 lượt gen'in wf.locator('#photoDialogBody').inner_text()
    assert not errors,errors;browser.close()
   print('PASS review repros: balanced 9s, legitimate short scene, multilingual/Unicode dialogue coverage; storyboard-only edits and legacy approval survive; actual prompt edits invalidate; stale content/older requests retained separately without replacing approved clip/plan; no generation POST; stale files preserved through approval + reload; generation-count UI.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()
if __name__=='__main__':main()
