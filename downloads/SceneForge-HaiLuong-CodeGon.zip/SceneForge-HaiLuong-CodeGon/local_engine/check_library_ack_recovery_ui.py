"""Lost checkpoint/cleanup responses recover, while genuinely unsaved edits stay separate."""
import os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1]
 with tempfile.TemporaryDirectory(prefix='sf-library-ack-')as data:
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('SceneForgeStorage.state.active&&window.SceneForgeApp?.getReadiness().rooms')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();await new Promise(r=>setTimeout(r,100));await SceneForgeStorage.checkpoint();}")
    def lose_post(route):
     if route.request.method=='POST':
      response=route.fetch();assert response.status==200;route.abort()
     else:route.continue_()
    page.route('**/local-api/library/snapshot',lose_post,times=1)
    page.evaluate("async()=>{await io('prefs','readwrite','ack-proof','committed');try{await SceneForgeStorage.checkpoint()}catch{}}")
    assert not page.evaluate('SceneForgeStorage.state.active')
    page.reload();page.wait_for_function('SceneForgeStorage.state.active',timeout=30000)
    assert page.evaluate("async()=>await io('prefs','readonly','ack-proof')")=='committed'
    # Cleanup changes records and removes real bytes. Lose its response too.
    plan=page.evaluate("async()=>{const r={id:'cleanup-ack',name:'cleanup',mode:'reference',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await io('files','readwrite',r.id+':source',new Blob(['source fixture']));await new Promise(r=>setTimeout(r,100));await SceneForgeStorage.checkpoint();return await SceneForgeStorage.api('lifecycle/plan',{room_id:r.id,mode:'delete',days:0,revision:SceneForgeStorage.state.revision});}")
    page.route('**/local-api/library/lifecycle/execute',lose_post,times=1)
    page.evaluate('async plan=>{try{await storageApplyPlan(plan)}catch{}}',plan)
    assert not page.evaluate('SceneForgeStorage.state.active')
    page.reload();page.wait_for_function('SceneForgeStorage.state.active',timeout=30000)
    assert not page.evaluate("!!roomFor('cleanup-ack')")
    # A later unsaved local edit must NOT be overwritten just because a receipt exists.
    page.route('**/local-api/library/snapshot',lose_post,times=1)
    page.evaluate("async()=>{await io('prefs','readwrite','second-proof','saved remotely');try{await SceneForgeStorage.checkpoint()}catch{}await io('prefs','readwrite','unsaved-proof','keep this local edit');}")
    page.reload();page.wait_for_function('SceneForgeStorage.state.managed&&!!SceneForgeStorage.state.error',timeout=30000)
    assert not page.evaluate('SceneForgeStorage.state.active')
    assert page.evaluate("async()=>await io('prefs','readonly','unsaved-proof')")=='keep this local edit'
    remote=page.evaluate("async()=>await SceneForgeStorage.api('snapshot')");assert not any(r['key']=='unsaved-proof'for r in remote['records'])
    browser.close()
   print('PASS real browser/API: lost checkpoint ACK auto-reconciles by durable receipt and exact local digest; lost cleanup ACK hydrates deletion without resurrection; changed unsaved local data preserved and conflict shown. No provider calls.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()
if __name__=='__main__':main()
