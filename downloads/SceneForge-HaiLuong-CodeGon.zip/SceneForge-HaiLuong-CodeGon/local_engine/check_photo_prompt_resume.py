"""Storyboard -> batched prompts -> project board -> whole draft -> real editor.
Chromium + actual SQLite/library; deterministic provider transport, no online AI.
"""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64,json
from pathlib import Path
from playwright.sync_api import sync_playwright


def main():
 root=Path(__file__).resolve().parents[1]
 video=(root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()
 with tempfile.TemporaryDirectory(prefix='sf-story-production-') as data:
  with socket.socket() as sock:
   sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];sent=[];responses={}
    page.on('pageerror',lambda e:errors.append(str(e)))
    status={'installed':True,'configured':True,'account_binding':True,'models':['veo-portrait'],'accounts':[],'per_account':2,'max_concurrency':3,'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'token'}}
    for service in ['gemini-chat','flow','muse']:
     page.route('**/local-api/'+service+'/status',lambda route:route.fulfill(json=status))
    def dispatch(route):
     body=route.request.post_data_json;sent.append(body);rid=body['request_id']
     if body['kind']=='text':
      source=json.loads(body['prompt'].split('\n',1)[1]);rows=[]
      for b in source['beats']:
       rows.append({k:b[k] for k in ['id','type','seconds','text']}|{'angle':'Medium','movement':'Slow push','visualPrompt':'Original product on table','motionPrompt':'One slow camera push','refRoles':['product'],'partPrompts':{p['id']:{'visualPrompt':'Original product','motionPrompt':'Slow push '+p['id']}for p in b['parts']}})
      responses[rid]={'id':rid,'state':'done','result':{'text':json.dumps({'beats':rows}),'account_id':'fixture-gemini'}}
     elif body['kind']=='video':
      responses[rid]={'id':rid,'state':'done','result':{'mime_type':'video/mp4','account_id':'fixture-flow'}}
     route.fulfill(json={'id':rid,'state':'submitted'})
    for service in ['gemini-chat','flow','muse']:
     page.route('**/local-api/'+service+'/jobs',dispatch)
     page.route('**/local-api/'+service+'/jobs/*',lambda route:route.fulfill(json=responses.get(route.request.url.rsplit('/',1)[-1],{'state':'unknown'})))
     page.route('**/local-api/'+service+'/files/*',lambda route:route.fulfill(body=video,content_type='video/mp4'))
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'story-fixture',name:'Story production',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoPrepareStoryboard==="function"')
    wf.evaluate('''async()=>{const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=800;canvas.getContext('2d').fillRect(0,0,1200,800);const image=canvas.toDataURL(),key=room.id+':story';await bridge.putFile(key,await(await fetch(image)).blob());draft.refs={product:{images:[{id:'p',name:'Original',image}]},person:{images:[]},background:{images:[]}};draft.idea='Giới thiệu sản phẩm';draft.voice.mode='native';draft.beats=Array.from({length:9},(_,i)=>({id:'b'+i,name:'Cảnh '+(i+1),type:'wide',seconds:4,text:'Xin chào.',clips:[]}));draft.providers={creative:'gemini',video:'flow',flowModel:'veo-portrait'};draft.flowJobs=[];draft.geminiJobs=[];draft.storyboardImages=[{id:'one',key,preview:image,name:'Overall',version:1}];draft.storyboardImage='one';await save();render();await photoToolbarRefresh(true);}''')
    assert wf.locator('[data-node=frames]').count()==0
    assert wf.locator('[data-node=bank] .productionSlot').count()==9
    assert wf.locator('.productionDirections').evaluate('(n)=>!n.open')
    wf.locator('#photoNext').click();wf.locator('#productionPrepareSend').wait_for();assert not sent
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoMediaBusy&&!photoProductionWorking')
    assert len(sent)==2 and all(j['kind']=='text' for j in sent)
    assert [len(json.loads(j['prompt'].split('\n',1)[1])['beats'])for j in sent]==[8,1]
    assert all(len(j['references'])==2 for j in sent)
    assert wf.evaluate("async refs=>{const r=refs.at(-1),b=await createImageBitmap(await(await fetch('data:'+r.mime_type+';base64,'+r.data)).blob());return b.width;}",sent[0]['references'])==1200
    # Restart with durable intents. Recovery never dispatches again.
    page.evaluate('async()=>{await flushFrames();await SceneForgeStorage.checkpoint();}')
    page.reload();page.wait_for_function('!!db&&SceneForgeStorage.state.active')
    page.evaluate("async()=>{document.querySelector('#shellDialog').close();await openRoom('story-fixture','analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoWorkflowReceive==="function"')
    wf.evaluate('async()=>{await photoWorkflowReceive();await photoWorkflowReceive();}')
    assert len(sent)==2
    assert wf.evaluate('photoPromptsCurrent()')
    assert wf.locator('#photoApplyChat').count()==0
    assert wf.evaluate('draft.beats.every(b=>b.partPrompts.a.motionPrompt==="Slow push a")')
    # Reopening preparation with current prompts must not call Gemini again.
    wf.evaluate('photoPrepareStoryboard()');assert len(sent)==2
    # Only the edited group needs another request; the other eight beats keep
    # their imported directions and can be adopted without another AI send.
    wf.evaluate("async()=>{draft.beats[8].text='Một lời mới.';await save();await photoPrepareStoryboard();}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    assert len(sent)==3 and len(json.loads(sent[-1]['prompt'].split('\n',1)[1])['beats'])==1
    wf.evaluate('photoWorkflowReceive()');assert wf.evaluate('photoPromptsCurrent()')
    # Simulate the last group having a confirmed pre-send failure. Retry keeps
    # the other imported group and sends exactly this missing group.
    wf.evaluate("async()=>{draft.geminiJobs.at(-1).state='not_submitted';photoProductionState().promptSource=null;await save();await photoPrepareStoryboard();}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    assert len(sent)==4 and len(json.loads(sent[-1]['prompt'].split('\n',1)[1])['beats'])==1
    wf.evaluate('photoWorkflowReceive()');assert wf.evaluate('photoPromptsCurrent()')
    # A batch response may be used when an unrelated group changed, but it must
    # not mark the entire edited script ready. No extra call during receive.
    wf.evaluate("async()=>{draft.beats[8].text='Lời lần ba.';await save();await photoPrepareStoryboard();}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    assert len(sent)==5
    wf.evaluate("async()=>{draft.beats[0].text='Nhóm đầu đã sửa.';await save();await photoWorkflowReceive();}")
    assert wf.evaluate("draft.geminiJobs.at(-1).state==='imported'&&!photoPromptsCurrent()")
    wf.evaluate('photoPrepareStoryboard()');wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    assert len(sent)==6 and len(json.loads(sent[-1]['prompt'].split('\n',1)[1])['beats'])==8
    wf.evaluate('photoWorkflowReceive()');assert wf.evaluate('photoPromptsCurrent()')
    # A failing durable checkpoint prevents dispatch. The intent is recorded as
    # not_submitted; retry will not replay any successful group.
    wf.evaluate("async()=>{draft.beats[8].text='Không gửi khi ổ lỗi.';await save();await photoPrepareStoryboard();window.oldCheckpoint=parent.SceneForgeStorage.checkpoint;parent.SceneForgeStorage.checkpoint=async()=>{throw Error('fixture disk full');};}")
    wf.locator('#productionPrepareSend').click();wf.wait_for_function('!photoProductionWorking')
    assert len(sent)==6 and wf.evaluate("draft.geminiJobs.at(-1).state==='not_submitted'")
    wf.evaluate('parent.SceneForgeStorage.checkpoint=oldCheckpoint')
    assert not errors,errors
    browser.close()
    print('PASS photo prompt reuse: 9 beats -> 8+1; all current sends zero; editing or retry sends only missing group; unrelated input change preserves valid batch without marking whole project current; checkpoint failure sends zero. Actual Chromium/SQLite, fixture provider only.')
  finally:
   proc.terminate();proc.wait(timeout=15)

if __name__=='__main__':main()
