"""Photo edits through real Chromium, library and editor; no generation calls."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64,json,io,wave,math,struct
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1]
 raw=base64.b64encode((root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()).decode()
 with tempfile.TemporaryDirectory(prefix='sf-photo-edits-')as data:
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1500,'height':1000});errors=[];posts=[]
    page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:posts.append(r.url)if r.method=='POST'and any('/local-api/'+s+'/jobs' in r.url for s in ['flow','muse','gemini-chat'])else None)
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'edit-fixture',name:'Edit fixture',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoApplyBeatEdits==="function"')
    wf.evaluate('''async raw=>{const canvas=document.createElement('canvas');canvas.width=90;canvas.height=160;canvas.getContext('2d').fillRect(0,0,90,160);const image=canvas.toDataURL(),png=await(await fetch(image)).blob();draft.refs={product:{images:[{id:'product',name:'Product',image}]},person:{images:[{id:'person',name:'Person',image}]},background:{images:[]}};draft.idea='Giới thiệu sản phẩm';draft.voice.mode='none';draft.flowJobs=[];draft.geminiJobs=[{id:'fixture-prompts',state:'imported'}];draft.beats=['product','person'].map((role,i)=>({id:'b'+i,name:'Cảnh '+(i+1),type:'wide',seconds:i?4:6,text:i?'Câu thứ hai.':'Câu thứ nhất.',angle:'Medium',movement:'Push',visualPrompt:'Reference identity',motionPrompt:'Slow push',refRoles:[role],clips:[],frames:[]}));const bytes=Uint8Array.from(atob(raw),c=>c.charCodeAt(0)),file=new Blob([bytes],{type:'video/mp4'}),info=await photoReadClip(file,6);for(const [i,b]of draft.beats.entries()){photoFreezeParts(b);const key=room.id+':clip:'+i;await bridge.putFile(key,file);const fk=room.id+':frame:'+i;await bridge.putFile(fk,png);b.frames=[{id:'frame'+i,key:fk,name:'Frame',preview:image,version:1}];b.approvedFrame='frame'+i;const p=photoParts(b)[0];b.clips=[{id:'clip'+i,key,name:'Clip '+i,version:1,generationOrder:1,part:p.id,slotStart:0,slotEnd:p.end,frameId:b.approvedFrame,signature:photoSceneSignature(b,p),reviewDecision:{status:'accepted'},...info}];b.chosenParts={a:'clip'+i};}draft.production={promptJobs:['fixture-prompts'],expectedBatches:1,promptSource:photoProductionInput()};await save();render();window.editInitial=structuredClone(draft);}''',raw)
    assert wf.evaluate('photoDraftCounts().ready')==2
    # The actual editor saves through the guarded retiming proposal, not a bare seconds assignment.
    wf.evaluate("editBeat('b0')");wf.locator('#beatSeconds').fill('5.7');wf.locator('#saveBeat').click();wf.locator('#photoConfirmEdit').wait_for()
    assert wf.evaluate('draft.beats[0].seconds')==6
    assert '1 clip tận dụng' in wf.locator('#photoDialogBody').inner_text()
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    assert wf.evaluate('draft.beats[0].clipPlan.seconds')==5.7
    assert wf.evaluate('photoDraftCounts().ready')==2
    assert wf.evaluate('photoPromptsCurrent()')
    assert wf.evaluate("photoLatest(draft.beats[0],'a').key")=='edit-fixture:clip:0'
    assert wf.evaluate("photoLatest(draft.beats[0],'a').reuseReason")=='retime-muted-video'
    assert wf.evaluate('draft.beats[0].clips.length')==2
    # A larger change has a bounded new plan and exposes exactly one missing slot.
    wf.evaluate("async()=>{await photoApplyBeatEdits([{id:'b0',patch:{seconds:16}}]);}");assert '1 phần cần clip phù hợp' in wf.locator('#photoDialogBody').inner_text()
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    assert wf.evaluate('photoParts(draft.beats[0]).length')==2
    assert wf.evaluate('photoDraftCounts().ready')==2 # one reused slot plus the other beat
    assert wf.evaluate('photoDraftCounts().total')==3
    status={'configured':True,'account_binding':True,'models':['veo-portrait'],'per_account':1,'max_concurrency':3,'selection':{'available':True,'mode':'selected','token':'fixture'}}
    page.route('**/local-api/flow/status',lambda route:route.fulfill(json=status))
    wf.evaluate("async()=>{photoTools().flowModel='veo-portrait';await photoRunClips();}")
    assert '1 yêu cầu' in wf.locator('#photoConfirmFlow').inner_text()
    wf.locator('#closePhotoDialog').click()
    # Missing media fails atomically; retry must not append local reuse records twice.
    wf.evaluate("async()=>{draft=structuredClone(editInitial);window.realGetFile=bridge.getFile;bridge.getFile=async key=>key==='edit-fixture:clip:1'?null:realGetFile(key);await photoApplyBeatEdits([{id:'b0',patch:{seconds:5.7}},{id:'b1',patch:{seconds:3.7}}]);}")
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    assert 'Thiếu clip' in wf.locator('#photoEditError').inner_text()
    assert wf.evaluate('draft.beats.map(b=>b.seconds)')==[6,4]
    assert wf.evaluate('draft.beats.map(b=>b.clips.length)')==[1,1]
    wf.evaluate('()=>{bridge.getFile=realGetFile;}')
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    assert wf.evaluate('draft.beats.map(b=>b.clips.length)')==[2,2]
    # A previously stuck mismatch can be repaired even when the seconds input is unchanged.
    wf.evaluate("async()=>{draft=structuredClone(editInitial);draft.beats[0].seconds=5.7;await photoApplyBeatEdits([{id:'b0',patch:{seconds:5.7}}]);}")
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    assert wf.evaluate('draft.beats[0].clipPlan.seconds===5.7&&photoDraftCounts().ready===2')
    # Speech-bearing clips must not be silently shortened.
    wf.evaluate("async()=>{draft=structuredClone(editInitial);draft.voice.mode='native';for(const b of draft.beats){const p=photoParts(b)[0];b.clips[0].signature=photoSceneSignature(b,p);}await photoApplyBeatEdits([{id:'b0',patch:{seconds:5.7}}]);}")
    assert '1 phần cần clip phù hợp' in wf.locator('#photoDialogBody').inner_text()
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    assert wf.evaluate('photoDraftCounts().ready')==1
    assert wf.evaluate('draft.beats[0].clips.length')==1
    # An unresolved dispatch cannot be retimed or lose its binding.
    wf.evaluate("async()=>{draft=structuredClone(editInitial);draft.flowJobs=[{id:'flow-unknown',state:'unknown',provider:'flow',beatId:'b0',part:'a'}];const before=JSON.stringify(draft);try{await photoApplyBeatEdits([{id:'b0',patch:{seconds:5}}]);throw Error('Unexpected edit');}catch(e){if(e.message==='Unexpected edit')throw e;}if(JSON.stringify(draft)!==before)throw Error('Unknown job mutated');draft.flowJobs=[];}")
    # Upload an unused role through the actual file input. Neither frame gets cleared.
    png=wf.evaluate("editInitial.refs.product.images[0].image.split(',')[1]")
    wf.evaluate("()=>{draft=structuredClone(editInitial);selectedRef='background';render();}")
    wf.locator('#photoRefFile').set_input_files({'name':'background.png','mimeType':'image/png','buffer':base64.b64decode(png)})
    wf.wait_for_function("draft.refs.background.images.length===1&&!photoMediaBusy&&!photoEditBusy")
    assert wf.evaluate('draft.beats.map(b=>b.approvedFrame)')==['frame0','frame1']
    assert wf.evaluate('photoDraftCounts().ready===2&&photoPromptsCurrent()')
    # A used role invalidates only its scene; the other frame, clip and file survive.
    wf.evaluate("selectedRef='product'")
    wf.locator('#photoRefFile').set_input_files({'name':'product2.png','mimeType':'image/png','buffer':base64.b64decode(png)})
    wf.wait_for_function("draft.refs.product.images.length===2&&!photoMediaBusy&&!photoEditBusy")
    assert wf.evaluate('draft.beats[0].approvedFrame||null')is None
    assert wf.evaluate('draft.beats[1].approvedFrame')=='frame1'
    assert wf.evaluate("photoLatest(draft.beats[1],'a').id")=='clip1'
    assert wf.evaluate('draft.beats[0].clips.length')==1
    # Actual WAV upload preserves an existing plan. File <-> AI changes preserve manual cues.
    wav=io.BytesIO()
    with wave.open(wav,'wb')as w:
     w.setnchannels(1);w.setsampwidth(2);w.setframerate(8000);w.writeframes(b''.join(struct.pack('<h',int(1000*math.sin(2*math.pi*220*i/8000)))for i in range(8*8000)))
    wf.evaluate("async()=>{draft=structuredClone(editInitial);draft.voice.mode='file';for(const b of draft.beats)b.clips[0].signature=photoSceneSignature(b,photoParts(b)[0]);draft.post.cues=[{start:0,end:6,text:'Phụ đề riêng'}];draft.post.cueSignature=photoCueSignature();await save();render();}")
    wf.locator('#photoVoiceFile').set_input_files({'name':'new-voice.wav','mimeType':'audio/wav','buffer':wav.getvalue()})
    wf.wait_for_function("draft.voice.name==='new-voice.wav'&&!photoMediaBusy&&!photoEditBusy")
    assert wf.evaluate('draft.beats.map(b=>b.seconds)')==[6,4]
    assert wf.evaluate('photoDraftCounts().ready')==2
    wf.evaluate("async()=>{await photoSetVoiceMode('ai');}")
    assert wf.evaluate('photoDraftCounts().ready===2&&draft.post.cueSignature===photoCueSignature()')
    wf.evaluate("async()=>{await photoInstallVoice({...draft.voice,mode:'ai'},[{start:0,end:3},{start:3,end:8}]);await photoAlignVoice();}");wf.locator('#photoConfirmEdit').wait_for()
    assert wf.evaluate('draft.beats.map(b=>b.seconds)')==[6,4]
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    assert wf.evaluate('draft.beats.map(b=>b.seconds)')==[3,5]
    assert abs(wf.evaluate('seconds()')-8)<.001
    assert wf.evaluate('photoDraftCounts().ready')==2
    assert wf.evaluate('draft.post.cues[0].text')=='Phụ đề riêng'
    assert wf.evaluate('draft.post.cueSignature!==photoCueSignature()')
    # Mute native audio uses a local reuse record, not another paid generation.
    wf.evaluate("async()=>{draft=structuredClone(editInitial);draft.voice.mode='native';for(const b of draft.beats)b.clips[0].signature=photoSceneSignature(b,photoParts(b)[0]);await photoSetVoiceMode('none');}")
    assert wf.evaluate('photoDraftCounts().ready')==2
    assert wf.evaluate('draft.beats.every(b=>b.clips.length===2)')
    # Fork via real parent bridge. Simulate losing the reply after creation; retry is idempotent.
    wf.evaluate("async()=>{draft=structuredClone(editInitial);await save();window.beforeFork=JSON.stringify(draft);await photoApplyFormula('honest-review');}")
    page.evaluate("()=>{const original=SceneForgeApp.photoBridge.forkDraft;let first=true;SceneForgeApp.photoBridge.forkDraft=async data=>{const r=await original(data);if(first){first=false;throw Error('Fixture lost fork reply');}return r;};}")
    wf.locator('#photoConfirmFork').click();wf.wait_for_function('!photoEditBusy')
    assert 'lost fork reply' in wf.locator('#photoForkError').inner_text()
    assert page.evaluate("SceneForgeApp.getState().rooms.filter(r=>r.forkedFrom==='edit-fixture').length")==1
    assert wf.evaluate('JSON.stringify(draft)===beforeFork')
    wf.locator('#photoConfirmFork').click()
    page.wait_for_function("!switching&&SceneForgeApp.getState().currentRoom!=='edit-fixture'")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function("loaded&&draft.formula==='honest-review'")
    assert wf.evaluate('draft.beats.every(b=>!b.clips&&!b.frames)&&!draft.flowJobs?.length&&!draft.geminiJobs?.length&&!draft.voice.key')
    source=page.evaluate("SceneForgeApp.getState().rooms.find(r=>r.id==='edit-fixture').photoDraft")
    assert len(source['beats'][0]['clips'])==1
    assert source['beats'][0]['clips'][0]['id']=='clip0'
    assert page.evaluate("SceneForgeApp.getState().rooms.filter(r=>r.forkedFrom==='edit-fixture').length")==1
    assert wf.evaluate("async()=>!!await bridge.getFile('edit-fixture:clip:0')")
    page.evaluate('async()=>{await flushFrames();await SceneForgeStorage.checkpoint();}')
    page.reload();page.wait_for_function('SceneForgeStorage.state.active')
    assert page.evaluate("SceneForgeApp.getState().rooms.filter(r=>r.forkedFrom==='edit-fixture').length")==1
    # Final retimed payload uses actual kept bytes and survives the cleanup transaction.
    page.wait_for_function('appBootReady&&!switching&&!!SceneForgeApp.getState().currentRoom')
    page.evaluate("async()=>{document.querySelector('#shellDialog').close();await openRoom('edit-fixture','analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&room.id==="edit-fixture"&&typeof photoApplyBeatEdits==="function"')
    wf.evaluate("async()=>{await photoApplyBeatEdits([{id:'b0',patch:{seconds:5.7}}]);}")
    wf.locator('#photoConfirmEdit').click();wf.wait_for_function('!photoEditBusy&&!photoMediaBusy')
    wf.evaluate('async()=>{await photoPreviewDraft();}')
    wf.locator('#productionFinal').click()
    page.wait_for_function("!!document.querySelector('#standaloneEditorDemo')?.contentWindow.SceneForgeEditor")
    ed=page.locator('#standaloneEditorDemo').element_handle().content_frame();ed.wait_for_function('SceneForgeEditor.getState().items.filter(i=>i.kind==="video").length===2')
    items=ed.evaluate('SceneForgeEditor.getState().items.filter(i=>i.kind==="video")')
    assert abs(items[0]['duration']-5.7)<.001 and abs(items[1]['start']-5.7)<.001
    assert wf.evaluate("async()=>!!await bridge.getFile('edit-fixture:clip:0')")
    final=page.evaluate("SceneForgeApp.getState().rooms.find(r=>r.id==='edit-fixture').photoDraft")
    assert len(final['beats'][0]['clips'])==1 and final['beats'][0]['clips'][0]['origin']=='local-reuse'
    assert not posts,posts
    assert not errors,errors;browser.close()
   print('PASS photo edits: actual edit dialog 6->5.7 and 16s plan, local file reuse/no copies, legacy mismatch repair, native speech not truncated, unknown job binding retained; real unused/used role uploads preserve unaffected frames/clip; actual WAV replacement retains timeline, file/AI cues preserved, explicit realignment; mute native without gen; real formula fork with lost-reply retry and SQLite reload; original project/assets retained; retimed final cleanup retains the shared file and imports a real 5.7+4s editor timeline. Zero provider job POSTs.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()
if __name__=='__main__':main()
