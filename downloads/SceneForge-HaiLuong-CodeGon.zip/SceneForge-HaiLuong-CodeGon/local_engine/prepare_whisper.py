"""Explicit Whisper setup; local import never downloads model weights."""
import argparse,hashlib,json,os,shutil,tempfile,time
from pathlib import Path

REQUIRED=('model.bin','config.json','tokenizer.json','vocabulary.txt')
OPTIONAL=('preprocessor_config.json','README.md')

def verify_model(directory,probe=None):
 from faster_whisper import WhisperModel
 for name in REQUIRED:
  path=directory/name
  if not path.is_file() or not path.stat().st_size:raise ValueError('Thiếu file model: '+name)
 for name in ('config.json','tokenizer.json'):json.loads((directory/name).read_text(encoding='utf-8'))
 os.environ['HF_HUB_OFFLINE']='1'
 model=WhisperModel(str(directory),device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,local_files_only=True)
 # Decode through the same AV/VAD path used in production. Silence checks the
 # complete audio pipeline without inventing a speech-quality certification.
 if probe is None:
  import wave
  with tempfile.TemporaryDirectory(prefix='whisper-probe-') as temporary:
   audio=Path(temporary)/'silence.wav'
   with wave.open(str(audio),'wb') as wav:
    wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(16000);wav.writeframes(b'\0'*(16000*2))
   segments,_=model.transcribe(str(audio),language='vi',vad_filter=True)
   list(segments)
  return {'audio_pipeline_verified':True,'speech_verified':False}
 segments,info=model.transcribe(str(probe),language='vi',word_timestamps=True,beam_size=3,vad_filter=True,condition_on_previous_text=False)
 rows=[{'start':s.start,'end':s.end,'text':s.text} for s in segments]
 if not rows:raise ValueError('Chưa nhận được lời từ âm thanh thử.')
 return {'audio_pipeline_verified':True,'speech_verified':True,'language':info.language,'segments':rows}

def prepare(target,source=None,model_name='base',download=False,probe=None):
 target=Path(target).resolve();target.parent.mkdir(parents=True,exist_ok=True)
 if source is None and not download:raise ValueError('Chọn --from-directory hoặc --download; không tự tải model.')
 with tempfile.TemporaryDirectory(prefix='whisper-install-',dir=target.parent) as temporary:
  staged=Path(temporary)/'model';staged.mkdir()
  if source is not None:
   source=Path(source).resolve()
   for name in REQUIRED+OPTIONAL:
    original=source/name
    if not original.is_file():
     if name in REQUIRED:raise ValueError('Thiếu file model: '+name)
     continue
    if original.stat().st_size>512*1024**2:raise ValueError('File model quá lớn: '+name)
    shutil.copy2(original,staged/name)
  else:
   from faster_whisper.utils import download_model
   download_model(model_name,output_dir=str(staged))
  verification=verify_model(staged,probe)
  rows=[{'name':n,'bytes':(staged/n).stat().st_size,'sha256':hashlib.sha256((staged/n).read_bytes()).hexdigest()} for n in REQUIRED]
  # Do not replace a different model or erase existing user files.
  for row in rows:
   existing=target/row['name']
   if existing.exists() and hashlib.sha256(existing.read_bytes()).hexdigest()!=row['sha256']:
    raise ValueError('Đã có model khác; không ghi đè: '+row['name'])
  target.mkdir(exist_ok=True)
  for name in REQUIRED+OPTIONAL:
   if (staged/name).exists() and not (target/name).exists():os.replace(staged/name,target/name)
  marker={'ready':True,'at':time.time(),'backend':'faster-whisper-cpu-int8','files':rows,**verification}
  temporary_marker=target/'setup-status.tmp';temporary_marker.write_text(json.dumps(marker,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temporary_marker,target/'setup-status.json')
 print('Đã nạp model CPU và kiểm tra đường đọc âm thanh offline:',target)
 return marker

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--download',action='store_true')
 parser.add_argument('--model',choices=['tiny','base','small'],default='base')
 parser.add_argument('--from-directory',type=Path,help='Thư mục chứa model đã tải, không gọi Hugging Face.')
 default=Path(os.environ.get('SCENEFORGE_LOCAL_DATA',str(Path.home()/'.sceneforge-local')))/'models/faster-whisper'
 parser.add_argument('--directory',type=Path,default=default)
 parser.add_argument('--probe',type=Path,help='Âm thanh tiếng Việt thật để kiểm tra thêm nhận dạng.')
 args=parser.parse_args()
 if bool(args.from_directory)==bool(args.download):parser.error('Chọn một trong --from-directory hoặc --download.')
 try:prepare(args.directory,args.from_directory,args.model,args.download,args.probe)
 except Exception as error:raise SystemExit('Chưa cài xong Whisper: '+str(error))
if __name__=='__main__':main()
