"""One local process owns a library root. Cloud/NAS multi-host writes unsupported."""
import threading,weakref
from .instance import Instance
_guards=weakref.WeakValueDictionary();_mutex=threading.Lock()
class Guard:
 def __init__(self,root):
  self.instance=Instance(root)
  if not self.instance.acquire():raise RuntimeError('Thư viện đang được bộ chạy khác sử dụng. Đóng bộ chạy đó; không dùng chung thư viện qua đồng bộ/NAS.')
  self.lock=threading.RLock()
 def __del__(self):
  if getattr(self,'instance',None):self.instance.close()
def acquire(root):
 key=str(root.resolve())
 with _mutex:
  guard=_guards.get(key)
  if guard is None:guard=Guard(root);_guards[key]=guard
  return guard
