"""Measured local settings/health, masked diagnostics and bounded confirmed-429 retry."""
import asyncio,datetime,importlib.metadata,json,math,os,re,shutil,subprocess,time
from pathlib import Path
from fastapi import HTTPException, Request
from .cpu_analysis import capabilities as cpu_capabilities
import httpx

DEFAULTS={'aiTier':'free','autoWatermark':True,'resolution':1080,'fps':30,'normalizeAudio':True,'sidecarSrt':False,'voiceSpeed':1.0,'lowSpaceGB':5}
def gemini_retry_delay(response,attempt,settings):
 if response.status_code!=429 or settings.get('aiTier','free')!='free':return None
 try:delay=float(response.headers.get('retry-after',str(5*(attempt+1))))
 except (ValueError,TypeError):return None
 return delay if math.isfinite(delay) and 0<=delay<=30 else None

def scrub(value):
 if isinstance(value,dict):return {k:('[ẨN]' if any(x in k.lower() for x in ('key','cookie','token','authorization','secret','password','prompt','excerpt'))else scrub(v))for k,v in value.items()}
 if isinstance(value,list):return [scrub(v)for v in value]
 if isinstance(value,str):
  value=re.sub(r'AIza[\w-]{15,}', '[ẨN KEY]',value)
  return re.sub(r'(?i)(bearer\s+|(?:cookie|token|password|api[_-]?key)\s*[:=]\s*)[^\r\n,;]+',r'\1[ẨN]',value)
 return value

def install_package5(app,vault,data):
 def settings():return {**DEFAULTS,**(vault.secret('package5-settings')or{})}
 @app.get('/local-api/settings')
 async def get_settings():return settings()
 @app.post('/local-api/settings')
 async def save_settings(body:dict):
  out=settings()
  for key,value in body.items():
   if key not in DEFAULTS:raise HTTPException(400,'Tùy chọn không được hỗ trợ.')
   valid=(key=='aiTier'and value in ('free','paid'))or(key=='resolution'and type(value)is int and value in (720,1080))or(key=='fps'and type(value)is int and value in (30,60))or(key in ('autoWatermark','normalizeAudio','sidecarSrt')and type(value)is bool)or(key=='voiceSpeed'and type(value)in (int,float)and .8<=value<=1.3)or(key=='lowSpaceGB'and type(value)in (int,float)and 1<=value<=100)
   if not valid:raise HTTPException(400,'Giá trị cài đặt không hợp lệ.')
   out[key]=value
  vault.set_secret('package5-settings',out);return out
 @app.post('/local-api/ai/check-key')
 async def check_key(body:dict):
  key=vault.secret('gemini')
  if not key:raise HTTPException(409,'Chưa lưu Gemini key.')
  try:
   async with httpx.AsyncClient(timeout=20)as client:r=await client.get('https://generativelanguage.googleapis.com/v1beta/models',headers={'x-goog-api-key':key},params={'pageSize':1})
  except httpx.HTTPError:raise HTTPException(502,'Không kết nối được Google; chưa kết luận key hỏng.')
  result={'ok':r.status_code==200,'http_status':r.status_code,'at':time.time(),'note':'Google chấp nhận key để đọc danh sách mô hình. Chưa kiểm chứng quota tạo nội dung.'if r.status_code==200 else 'Google chưa chấp nhận yêu cầu kiểm tra (HTTP '+str(r.status_code)+').'}
  vault.set_secret('gemini-check',result);return result
 @app.get('/local-api/ai/usage')
 async def usage():
  start=datetime.datetime.now(datetime.timezone.utc).replace(day=1,hour=0,minute=0,second=0,microsecond=0).timestamp()
  rows=[r for r in vault.rows('logs')if r.get('kind')=='Gemini'and r['at']>=start]
  # Retry rows are individual rejected requests, not extra generated content.
  free=settings()['aiTier']=='free';known=[r for r in rows if isinstance(r.get('cost'),(int,float))and r.get('cost_unit')=='VND']
  return {'requests':len(rows),'rateLimits':sum(r.get('http_status')==429 for r in rows),'costVND':None,'costNote':'Nhật ký chưa có giá thanh toán đã xác minh. Gói miễn phí không thu phí dịch vụ trong hạn mức; đổi tùy chọn trong app không thay gói thanh toán của key.','tier':settings()['aiTier'],'keyCheck':vault.secret('gemini-check')}
 @app.get('/local-api/system')
 async def system(request:Request):
  engines=[]
  for name in ('flow2api','Muse web SDK','Gemini Chat SDK','vieneu'):
   if name=='Gemini Chat SDK':
    directory=Path(os.environ.get('SCENEFORGE_GEMINI_WEB_DIRECTORY',str(data/'engines/gemini-web')))
    executable=directory/'venv'/('Scripts/python.exe'if os.name=='nt'else'bin/python')
    try:marker=json.loads((directory/'installation.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):marker={}
    installed=executable.is_file()and marker.get('import_checked')is True
    engines.append({'name':name,'version':marker.get('revision','')[:7]if installed else None,'state':'installed'if installed else'missing','note':'SDK riêng; đăng nhập trong Cài đặt → Tài khoản → Gemini Chat. Không đồng nghĩa đã tạo nội dung thật.'if installed else'Chạy local_engine/install-gemini-web.bat; không tải model AI.'})
    continue
   if name=='Muse web SDK':
    directory=Path(os.environ.get('SCENEFORGE_MUSE_WEB_DIRECTORY',str(data/'engines/muse-web')))
    python=directory/'venv'/('Scripts/python.exe'if os.name=='nt'else'bin/python')
    try:marker=json.loads((directory/'installation.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):marker={}
    installed=python.is_file()and marker.get('import_checked')is True
    engines.append({'name':name,'version':marker.get('revision','')[:7]if installed else None,'state':'installed'if installed else'missing','note':'SDK riêng và adapter clip Muse; kiểm tra phiên/tạo video bằng tài khoản của bạn.'if installed else'Chạy local_engine/install-muse-web.bat; không tải model AI.'})
    continue
   if name=='vieneu':
    from .local_tts import tts_status
    voice=tts_status(data)
    engines.append({'name':name,'version':None,'state':'ready'if voice['model_ready']else'installed'if voice['installed']else'missing','note':'Model đã qua thử WAV và chạy offline.'if voice['model_ready']else'SDK riêng có thể đã cài; cần install-voice.bat tải và thử model.'})
    continue
   if name=='flow2api':
    directory=Path(os.environ.get('SCENEFORGE_FLOW_DIRECTORY',str(data/'engines/flow2api')))
    try:
     marker=json.loads((directory/'installation.json').read_text())
     executable=directory/'venv'/('Scripts/python.exe'if os.name=='nt'else'bin/python')
     installed=bool(marker.get('dependencies_checked')and executable.is_file()and(directory/'source/main.py').is_file())
    except (OSError,ValueError,TypeError):marker={};installed=False
    engines.append({'name':name,'version':marker.get('revision')if installed else None,'state':'installed'if installed else'missing','configured':bool((vault.secret('flow-engine')or{}).get('key')),'note':'Repo và môi trường riêng đã cài; không đồng nghĩa tài khoản/tạo nội dung đã kiểm chứng.'if installed else'Chạy local_engine/install-flow.bat để cài repo và môi trường riêng.'})
    continue
   try:version=importlib.metadata.version(name)
   except importlib.metadata.PackageNotFoundError:version=None
   engines.append({'name':name,'version':version,'state':'installed'if version else 'missing','note':'Có gói; chưa có adapter khởi chạy được kiểm chứng.'if name!='vieneu'else 'SDK; chưa kiểm chứng mô hình hoặc danh sách giọng.'})
  path=shutil.which('ffmpeg');version=None
  if path:
   try:
    result=await asyncio.to_thread(subprocess.run,[path,'-version'],capture_output=True,text=True,timeout=5)
    if result.returncode==0:version=result.stdout.splitlines()[0]
   except (OSError,subprocess.SubprocessError):pass
  engines.append({'name':'FFmpeg','version':version,'state':'ready'if version else 'missing','note':'Kiểm tra chương trình thực tế trên máy.'})
  disk=shutil.disk_usage(data)
  return {'cpu_analysis':cpu_capabilities(data),'engines':engines,'disk':{'total':disk.total,'free':disk.free,'used':disk.used,'scope':'Ổ chứa dữ liệu companion; không phải dung lượng dự án trong thư mục bạn chọn.'},'service':request.url.netloc,'checkedAt':time.time()}
 @app.get('/local-api/diagnostics')
 async def diagnostics():
  from .runtime_safety import diagnostic_tail
  return scrub({'service':'sceneforge-local','version':5,'runtime':diagnostic_tail(data),'settings':settings(),'logs':sorted(vault.rows('logs'),key=lambda r:r['at'],reverse=True)[:30]})
