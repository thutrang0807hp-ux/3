"""Bounded binary upload -> offline Whisper, sharing the local analysis lane."""
import asyncio
import json
from pathlib import Path
import shutil
import sys
import tempfile
from fastapi import HTTPException, Request
from .cpu_analysis import capabilities
from .machine_checks import run_command

def install_speech_captions(app,data,lane):
    busy=asyncio.Lock()
    @app.get('/local-api/speech/capabilities')
    async def status():
        c=capabilities(data)
        return {'available':c['ffmpeg']and c['whisper']and c['whisper_model'],'max_bytes':100*1024**2,'max_seconds':1800,'offline':True,'busy':busy.locked()}
    @app.post('/local-api/speech/transcribe')
    async def start(request:Request):
        if not(await status())['available']:raise HTTPException(409,'Whisper hoặc model chưa sẵn sàng trong môi trường app. Kiểm tra Cài đặt → Động cơ.')
        if busy.locked():raise HTTPException(409,'Đang chép lời; đợi lượt hiện tại.')
        async with busy:
            with tempfile.TemporaryDirectory(prefix='caption-speech-',dir=data)as tmp:
                root=Path(tmp);source=root/'source';size=0
                with source.open('wb')as out:
                    async for chunk in request.stream():
                        size+=len(chunk)
                        if size>100*1024**2:raise HTTPException(413,'Mỗi clip/âm thanh tối đa 100 MB.')
                        out.write(chunk)
                if size==0:raise HTTPException(400,'Tệp trống.')
                if shutil.disk_usage(data).free<256*1024**2:raise HTTPException(409,'Cần ít nhất 256 MB trống để xử lý âm thanh.')
                async with lane:
                    rc,raw,_=await run_command('ffprobe','-v','error','-protocol_whitelist','file,pipe','-show_streams','-show_format','-of','json',str(source),timeout=30)
                    try:
                        meta=json.loads(raw);duration=float(meta['format']['duration'])
                        if rc or not 0<duration<=1800:raise ValueError()
                    except (ValueError,KeyError,TypeError):raise HTTPException(400,'Không đọc được tệp hoặc thời lượng vượt 30 phút.')from None
                    if not any(s.get('codec_type')=='audio'for s in meta['streams']):return {'segments':[],'language':None,'duration':duration,'no_audio':True,'provider_requests':0}
                    wav=root/'speech.wav';result=root/'result.json'
                    rc,_,_=await run_command('ffmpeg','-v','error','-nostdin','-threads','2','-protocol_whitelist','file,pipe','-i',str(source),'-vn','-ac','1','-ar','16000','-y',str(wav),timeout=120,tree=True)
                    if rc:raise HTTPException(400,'Không đọc được âm thanh trong clip.')
                    rc,_,_=await run_command(sys.executable,'-m','local_engine.speech_worker',str(data/'models/faster-whisper'),str(wav),str(result),timeout=1200,tree=True)
                    if rc or not result.is_file():raise HTTPException(503,'Whisper chưa chép lời được; không tải model hoặc gọi API thay thế.')
                    body=json.loads(result.read_text());body['duration']=duration
                    for s in body['segments']:
                        s['start']=max(0,s['start']);s['end']=min(duration,s['end'])
                    body['segments']=[s for s in body['segments']if s['end']>s['start']]
                    return body
