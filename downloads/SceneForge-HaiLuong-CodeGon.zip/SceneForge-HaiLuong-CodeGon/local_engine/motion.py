"""Spatially balanced LK + RANSAC background motion at ~6 Hz; provisional thresholds."""
import cv2,numpy as np,math,statistics
THRESHOLDS={'translation_per_second':.025,'fast_translation_per_second':.2,'zoom_log_per_second':.035,'rotation_degrees_per_second':2.0,'jitter':.13,'calibrated':False}

def measure_motion(read_frame,start,end,fps,thresholds=None):
 cfg={**THRESHOLDS,**(thresholds or {})};dt=max(1/fps,1/6);times=np.arange(start,max(start,end-1/fps),dt).tolist();pairs=[]
 if len(times)>1:
  previous=cv2.cvtColor(read_frame(times[0]),cv2.COLOR_BGR2GRAY)
  for t0,t1 in zip(times,times[1:]):
   current=cv2.cvtColor(read_frame(t1),cv2.COLOR_BGR2GRAY);h,w=previous.shape;points=[]
   # Balance points per cell, so a detailed moving person cannot dominate one cell.
   for gy in range(4):
    for gx in range(4):
     x0,x1=gx*w//4,(gx+1)*w//4;y0,y1=gy*h//4,(gy+1)*h//4
     local=cv2.goodFeaturesToTrack(previous[y0:y1,x0:x1],maxCorners=25,qualityLevel=.01,minDistance=5)
     if local is not None:local[:,:,0]+=x0;local[:,:,1]+=y0;points.extend(local)
   if len(points)>=12:
    p=np.asarray(points,np.float32).reshape(-1,1,2);q,status,_=cv2.calcOpticalFlowPyrLK(previous,current,p,None)
    if q is not None:
     valid=status.ravel()==1;p,q=p[valid],q[valid]
     if len(p)>=12:
      affine,inliers=cv2.estimateAffinePartial2D(p,q,method=cv2.RANSAC,ransacReprojThreshold=2,maxIters=2000,confidence=.99)
      if affine is not None and inliers is not None and inliers.mean()>=.6:
       good=p[inliers.ravel()==1].reshape(-1,2);cells={(min(3,int(x/w*4)),min(3,int(y/h*4)))for x,y in good};edge=np.mean((good[:,0]<w*.2)|(good[:,0]>w*.8)|(good[:,1]<h*.2)|(good[:,1]>h*.8))
       if len(cells)>=6 and edge>=.2:
        elapsed=t1-t0;center=np.array([w/2,h/2]);delta=affine[:,:2]@center+affine[:,2]-center;scale=math.hypot(affine[0,0],affine[0,1]);angle=math.degrees(math.atan2(affine[1,0],affine[0,0]))
        pairs.append({'dx':float(delta[0]/w/elapsed),'dy':float(delta[1]/h/elapsed),'zoom':math.log(max(scale,1e-6))/elapsed,'rotation':angle/elapsed,'dt':elapsed,'inliers':float(inliers.mean()),'coverage':len(cells)/16})
   previous=current
 reliable=len(pairs)>=2 and len(pairs)>=max(2,int((len(times)-1)*.5))
 dx=float(statistics.median(p['dx']for p in pairs))if pairs else 0.;dy=float(statistics.median(p['dy']for p in pairs))if pairs else 0.;zoom=float(statistics.median(p['zoom']for p in pairs))if pairs else 0.;rotation=float(statistics.median(p['rotation']for p in pairs))if pairs else 0.;jitter=float(np.std([[p['dx'],p['dy']]for p in pairs],axis=0).max())if pairs else 0.
 labels=[];speed=math.hypot(dx,dy)
 if not reliable:labels=['không đo chắc'];kind='uncertain'
 else:
  if abs(zoom)>cfg['zoom_log_per_second']:labels.append('zoom vào'if zoom>0 else 'zoom ra')
  if abs(dx)>cfg['translation_per_second']:labels.append(('lia phải'if dx<0 else 'lia trái')+(' (nhanh)'if abs(dx)>cfg['fast_translation_per_second']else''))
  if abs(dy)>cfg['translation_per_second']:labels.append('máy đi xuống'if dy<0 else 'máy đi lên')
  if abs(rotation)>cfg['rotation_degrees_per_second']:labels.append('xoay máy')
  if jitter>cfg['jitter']:labels.append('cầm tay, hơi rung')
  if not labels:labels=['máy đứng yên']
  kind='zoom'if abs(zoom)>cfg['zoom_log_per_second']else 'pan'if speed>cfg['translation_per_second']else 'static'
 return {'kind':kind,'labels':labels,'reliable':reliable,'translation_per_second':[round(dx,5),round(dy,5)],'scale_per_second':round(zoom,5),'rotation_degrees_per_second':round(rotation,4),'jitter':round(jitter,5),'cumulative_translation':[round(sum(p['dx']*p['dt']for p in pairs),5),round(sum(p['dy']*p['dt']for p in pairs),5)],'cumulative_zoom':round(math.exp(sum(p['zoom']*p['dt']for p in pairs)),5),'valid_pairs':len(pairs),'thresholds':cfg,'note':'LK + RANSAC theo nền phân bố nhiều vùng; ngưỡng tạm cần hiệu chỉnh D9. Ít điểm hoặc chủ thể che nền: không đo chắc.'}
