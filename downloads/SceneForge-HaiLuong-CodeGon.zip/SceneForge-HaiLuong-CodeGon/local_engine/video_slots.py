"""Configurable admission of independent video jobs on the same account."""
import asyncio
from contextlib import asynccontextmanager
from fastapi import HTTPException


class VideoSlots:
    def __init__(self, vault, service):
        self.vault, self.service = vault, service
        self.condition = asyncio.Condition()
        self.active = {}

    def limit(self):
        value = (self.vault.secret(self.service + '-video-slots') or {}).get('per_account', 1)
        return value if type(value) is int and 1 <= value <= 16 else 1

    def status(self):
        return {'per_account': self.limit(), 'max_concurrency': max(3, self.limit()),
                'active_by_account': dict(self.active), 'maximum_setting': 16}

    def configure(self, body, busy=False):
        value = body.get('per_account')
        if type(value) is not int or not 1 <= value <= 16:
            raise HTTPException(400, 'Số clip đồng thời phải từ 1 đến 16.')
        if busy or any(self.active.values()):
            raise HTTPException(409, 'Đợi hàng đợi kết thúc trước khi đổi số clip đồng thời.')
        self.vault.set_secret(self.service + '-video-slots', {'per_account': value})
        return self.status()

    @asynccontextmanager
    async def slot(self, aid):
        async with self.condition:
            await self.condition.wait_for(lambda: self.active.get(aid, 0) < self.limit()
                and sum(self.active.values()) < max(3, self.limit()))
            self.active[aid] = self.active.get(aid, 0) + 1
        try:
            yield
        finally:
            async with self.condition:
                self.active[aid] -= 1
                if not self.active[aid]:
                    self.active.pop(aid)
                self.condition.notify_all()
