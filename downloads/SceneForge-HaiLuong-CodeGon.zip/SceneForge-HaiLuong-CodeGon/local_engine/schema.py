"""Transactional schema upgrades. Never open a newer database for writing."""
import os,sqlite3,time,uuid
from pathlib import Path

def migrate(path,statements,version=1):
 path=Path(path);existing=path.exists()and path.stat().st_size>0
 db=sqlite3.connect(path,timeout=30)
 try:
  current=db.execute('PRAGMA user_version').fetchone()[0]
  if current>version:raise RuntimeError('Dữ liệu được tạo bằng SceneForge mới hơn. Hãy cập nhật ứng dụng; chưa sửa dữ liệu.')
  if current==version:return
  if existing:
   folder=path.parent/'schema-backups';folder.mkdir(exist_ok=True)
   backup=folder/(path.stem+'-v'+str(current)+'-'+str(time.time_ns())+'-'+uuid.uuid4().hex[:6]+'.sqlite')
   target=sqlite3.connect(backup)
   try:
    db.backup(target)
    if target.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Không xác minh được bản sao trước nâng cấp.')
   finally:target.close()
   with backup.open('rb')as f:os.fsync(f.fileno())
  db.execute('BEGIN IMMEDIATE')
  # Recheck after obtaining the writer lock; another startup may have finished.
  current=db.execute('PRAGMA user_version').fetchone()[0]
  if current>version:raise RuntimeError('Phiên bản dữ liệu mới hơn ứng dụng.')
  if current<version:
   for statement in statements:db.execute(statement)
   db.execute('PRAGMA user_version='+str(int(version)))
   if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Nâng cấp không qua kiểm tra dữ liệu.')
  db.commit()
 except BaseException:db.rollback();raise
 finally:db.close()
