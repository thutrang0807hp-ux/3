"""Batch continuity, no resend of unknown, explicit continuation and partial apply."""
import base64,io
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from threading import Thread
from PIL import Image
from playwright.sync_api import sync_playwright

def main():
 class Quiet(SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 root=Path(__file__).resolve().parents[1];server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
 raw=io.BytesIO();Image.new('RGB',(90,160),'red').save(raw,format='PNG');image='data:image/png;base64,'+base64.b64encode(raw.getvalue()).decode();posts=[]
 def route(r):
  path=r.request.url.split('/local-api/')[1]
  if path=='status':return r.fulfill(json={'ai_source':'gemini_chat','ai_configured':True})
  if path.startswith('gemini-chat/jobs/'):return r.fulfill(json={'state':'unknown','store_id':'fixture-store'})
  if path=='ai/analyze-frames':
   body=r.request.post_data_json;posts.append(body);assert len(body['scenes'])<=8 and body['batch']['offset']in (0,8,16)
   if body['batch']['offset']==8 and len([p for p in posts if p['batch']['offset']==8])==1:return r.fulfill(status=502,json={'detail':'connection lost'})
   rows=[{'start':s['start'],'end':s['end'],'description':'Valid '+str(s['start']),'hasPerson':False,'faceTalking':False,'hasProduct':True,'competitorLogo':False,'visual':{'vi':{},'en':{}},'motion':{'vi':{},'en':{}},'promptFrame':{'vi':'Khung','en':'Frame'}}for s in body['scenes']]
   return r.fulfill(json={'scenes':rows,'script':[],'can_apply':True,'partial':False,'contract':'scene-line-ids-batch-v1','warnings':[]})
  return r.fulfill(json={})
 try:
  with sync_playwright()as pw:
   b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.route('**/local-api/**',route)
   p.goto(f'http://127.0.0.1:{server.server_port}/workflow.html');p.wait_for_function('!!window.SceneForgeWorkflow')
   p.evaluate('''async image=>{project=blankProject();project.source={asset:'fixture',poster:image,duration:17};project.scenes=Array.from({length:17},(_,i)=>sceneRecord(i,i+1,i,[image]));project.analysis.aiRequest={state:'submitted',source:'gemini_chat',request_id:crypto.randomUUID()};window.batchBody={request_id:project.analysis.aiRequest.request_id,ai_source:'gemini_chat',provider:'gemini',room_id:project.id,duration:17,scenes:project.scenes.map(s=>({start:s.start,end:s.end,frames:[image],ocr:[]})),lines:[]};window.batchResult=await runFrameAnalysis(batchBody);render();}''',image)
   assert len(posts)==3 and p.evaluate('batchResult.partial&&batchResult.scenes.length===9&&project.analysis.aiRequest.batches[1].state==="unknown"')
   p.evaluate('runFrameAnalysis(batchBody)');assert len(posts)==3
   p.evaluate('runFrameAnalysis({...batchBody,confirm_remaining:true})');assert len(posts)==3
   p.evaluate('''()=>{project.analysis.pendingAI={id:project.id,sourceAsset:project.source.asset,editSignature:analysisEditSignature(),result:batchResult};showLiveAnalysisResult(project.analysis.pendingAI);}''')
   p.locator('#applyPartialAnalysis').click();p.wait_for_function('!document.querySelector("#modal").open')
   assert p.evaluate('project.scenes.filter(s=>s.aiImported).length===9&&project.scenes.filter(s=>s.analysisState==="attention").length===8&&project.scenes[9].start===9')
   old=posts[1]['request_id'];p.evaluate('project.analysis.aiRequest.batches[1].state="abandoned"');p.evaluate('runFrameAnalysis({...batchBody,confirm_remaining:true})')
   assert len(posts)==4 and posts[3]['request_id']!=old and p.evaluate('project.analysis.aiRequest.batches.every(j=>j.state==="received")')
   assert not errors,errors;b.close();print('PASS: 17 scenes -> 3 durable batches; unknown batch is read only on resume, valid 9 scenes apply independently, explicit released-batch continuation uses one fresh ID without resending good batches.')
 finally:server.shutdown()

if __name__=='__main__':main()
