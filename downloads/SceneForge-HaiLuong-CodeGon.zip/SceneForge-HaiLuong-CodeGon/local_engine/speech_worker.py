"""Offline word-timed transcription of rendered audio, never translation or generation."""
import json
import os
from pathlib import Path
import sys
os.environ['HF_HUB_OFFLINE']='1'
os.environ['HF_HUB_DISABLE_TELEMETRY']='1'

def transcribe(model_path, audio):
    from faster_whisper import WhisperModel
    model=WhisperModel(str(model_path),device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,local_files_only=True)
    rows,info=model.transcribe(str(audio),language=None,word_timestamps=True,vad_filter=True,condition_on_previous_text=False,beam_size=3)
    segments=[]
    for row in rows:
        if len(segments)>=1000:raise ValueError('Too many speech segments')
        if row.text.strip():segments.append({'start':float(row.start),'end':float(row.end),'text':row.text.strip(),'words':[{'start':float(w.start),'end':float(w.end),'word':w.word}for w in row.words or []]})
    return {'language':info.language,'segments':segments,'provider_requests':0}

if __name__=='__main__':
    Path(sys.argv[3]).write_text(json.dumps(transcribe(sys.argv[1],sys.argv[2]),ensure_ascii=False))
