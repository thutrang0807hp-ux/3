"""Loopback session boundary and bounded, metadata-only diagnostics."""
import logging,secrets,time
from logging.handlers import RotatingFileHandler
from urllib.parse import urlsplit
from starlette.responses import JSONResponse

class LocalSession:
 def __init__(self):self.secret=secrets.token_urlsafe(32)
 async def dispatch(self,request,call_next):
  authority=request.headers.get('host','')
  try:
   parsed=urlsplit('//'+authority);host=parsed.hostname;port=parsed.port
  except ValueError:return JSONResponse({'detail':'Host không hợp lệ.'},403)
  if host not in {'localhost','127.0.0.1','testserver'}or parsed.username or parsed.password:return JSONResponse({'detail':'Chỉ truy cập qua loopback.'},403)
  origin=request.headers.get('origin')
  if request.headers.get('sec-fetch-site')=='cross-site' or (origin and origin!=request.url.scheme+'://'+authority):return JSONResponse({'detail':'Origin không được phép.'},403)
  private=request.url.path.startswith('/local-api/') and request.url.path!='/local-api/health'
  cookie='sceneforge_session_'+str(port or 0)
  if private:
   supplied=request.cookies.get(cookie,'')
   if not secrets.compare_digest(supplied,self.secret):return JSONResponse({'detail':'Phiên ứng dụng đã đổi. Tải lại trang SceneForge trên máy.'},403)
   if request.method not in {'GET','HEAD'}and request.headers.get('x-sceneforge-local')!='1':return JSONResponse({'detail':'Thiếu yêu cầu cùng ứng dụng.'},403)
  response=await call_next(request)
  content_type=response.headers.get('content-type','')
  if 'text/html'in content_type and response.status_code==200:
   response.set_cookie(cookie,self.secret,httponly=True,samesite='strict',path='/local-api')
   response.headers['Cache-Control']='no-store'
   response.headers['Content-Security-Policy']="frame-ancestors 'self'"
  if private:response.headers['Cache-Control']='no-store'
  response.headers['X-Content-Type-Options']='nosniff'
  response.headers['Referrer-Policy']='same-origin'
  return response

def service_logger(root):
 folder=root/'logs';folder.mkdir(parents=True,exist_ok=True)
 logger=logging.getLogger('sceneforge.runtime.'+str(root));logger.setLevel(logging.INFO);logger.propagate=False
 if not logger.handlers:
  handler=RotatingFileHandler(folder/'runtime.log',maxBytes=1024*1024,backupCount=4,encoding='utf8')
  handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'));logger.addHandler(handler)
 return logger

def record_request(logger,request,status,started):
 # Do not log bodies, query strings, headers, credentials, prompts or exception text.
 path=request.url.path
 category=path.split('/')[2]if path.startswith('/local-api/')and len(path.split('/'))>2 else 'ui'
 logger.info('method=%s category=%s status=%d elapsed_ms=%d',request.method,category if category.replace('-','').isalnum()else 'other',status,round((time.monotonic()-started)*1000))

def diagnostic_tail(root):
 try:
  with (root/'logs/runtime.log').open('rb')as source:
   source.seek(0,2);size=source.tell();source.seek(max(0,size-8192));lines=source.read().decode('utf8',errors='replace').splitlines()
  return lines[-20:]
 except OSError:return []
