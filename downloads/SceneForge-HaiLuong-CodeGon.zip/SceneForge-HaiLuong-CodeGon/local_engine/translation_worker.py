"""Single multilingual M2M100 CPU model; direct translation to Vietnamese, no hub calls."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='2'
import argparse,gc,json,re
from pathlib import Path

def validate_lines(raw):
 if not isinstance(raw,list) or not 1<=len(raw)<=300:raise ValueError('Dịch từ 1 đến 300 câu mỗi lượt.')
 out=[];seen=set();total=0
 for row in raw:
  if not isinstance(row,dict) or not isinstance(row.get('id'),str) or not 0<len(row['id'])<=160 or row['id'] in seen:raise ValueError('ID câu thiếu hoặc trùng.')
  text=row.get('original')
  if not isinstance(text,str) or not text.strip() or len(text)>3000:raise ValueError('Câu nguồn cần từ 1 đến 3.000 ký tự.')
  total+=len(text);seen.add(row['id']);out.append({'id':row['id'],'original':text})
 if total>30000:raise ValueError('Tối đa 30.000 ký tự mỗi lượt dịch.')
 return out

LANGUAGES="af am ar ast az ba be bg bn br bs ca ceb cs cy da de el en es et fa ff fi fr fy ga gd gl gu ha he hi hr ht hu hy id ig ilo is it ja jv ka kk km kn ko lb lg ln lo lt lv mg mk ml mn mr ms my ne nl no ns oc or pa pl ps pt ro ru sd si sk sl so sq sr ss su sv sw ta th tl tn tr uk ur uz vi wo xh yi yo zh zu".split()
MODEL_ID='facebook/m2m100_418M'
MODEL_FOLDER='m2m100-418m-int8'
MODEL_FILES=('model.bin','config.json','shared_vocabulary.json','sentencepiece.bpe.model')

def normalize_language(code):
 aliases={'jw':'jv','in':'id','iw':'he','zh-cn':'zh','zh-tw':'zh','zh-hans':'zh','zh-hant':'zh'}
 code=aliases.get(str(code).lower(),str(code).lower())
 if code not in LANGUAGES:raise ValueError('M2M100 chưa hỗ trợ mã ngôn ngữ này: '+code)
 return code

def load_model(path):
 import ctranslate2,sentencepiece
 path=Path(path)
 for name in MODEL_FILES:
  if not (path/name).is_file():raise ValueError('Thiếu file M2M100: '+name)
 vocabulary=json.loads((path/'shared_vocabulary.json').read_text(encoding='utf-8'))
 if not isinstance(vocabulary,list) or not all(token in vocabulary for token in ('__zh__','__it__','__vi__','</s>')):raise ValueError('Sai từ vựng M2M100 đa ngôn ngữ.')
 tokenizer=sentencepiece.SentencePieceProcessor(model_file=str(path/'sentencepiece.bpe.model'))
 engine=ctranslate2.Translator(str(path),device='cpu',compute_type='int8',inter_threads=1,intra_threads=2)
 return engine,tokenizer

def translate(root,lines,source='zh'):
 rows=validate_lines(lines);source=normalize_language(source)
 engine,tokenizer=load_model(root)
 try:
  translated=[]
  for row in rows:
   if source=='vi':translated.append(row['original']);continue
   pieces=[]
   for sentence in re.split(r'(?<=[。！？.!?；;\n])',row['original']):
    tokens=tokenizer.encode(sentence,out_type=str)
    for at in range(0,len(tokens),192):
     # Same special tokens as M2M100Tokenizer: source language prefix, EOS suffix.
     chunk=['__'+source+'__',*tokens[at:at+192],'</s>']
     result=engine.translate_batch([chunk],target_prefix=[['__vi__']],beam_size=2,max_batch_size=1,max_input_length=0,max_decoding_length=512,replace_unknowns=True)[0]
     output=result.hypotheses[0]
     if len(output)>=512:raise ValueError('Câu dịch vượt giới hạn đầu ra; chia câu ngắn hơn.')
     output=[t for t in output if t not in ('__vi__','</s>','<s>','<pad>')]
     decoded=tokenizer.decode_pieces(output).strip()
     if not decoded:raise ValueError('Model trả câu rỗng; giữ bản lời cũ.')
     pieces.append(decoded)
   text=' '.join(pieces).strip()
   if not text or len(text)>12000:raise ValueError('Đầu ra dịch không hợp lệ.')
   translated.append(text)
  return {'provider':'local-m2m100-ct2','model':MODEL_ID,'source_language':source,'target_language':'vi','pivot':None,'provider_requests':0,'lines':[{'id':r['id'],'original':r['original'],'translation':text} for r,text in zip(rows,translated)]}
 finally:
  engine.unload_model();del engine;gc.collect()

def main():
 os.environ['HF_HUB_OFFLINE']='1'
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 body=json.loads(args.input.read_text(encoding='utf-8'));result=translate(args.root,body['lines'],body.get('source_language','zh'));args.output.write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
if __name__=='__main__':main()
