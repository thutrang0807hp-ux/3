"""Sanitized account inventory from the owned Flow engine extension."""
import json
import hashlib
import time
from fastapi import HTTPException
from .account_pool import AccountPool


class FlowAccounts:
    def __init__(self, flow):
        self.flow, self.vault = flow, flow.vault
        self.pool = AccountPool(self.vault, 'flow')
        self.locks = {}

    async def request(self, method, path, body=None):
        config = self.flow.config()
        if not config.get('key'):
            raise HTTPException(409, 'Kết nối engine Flow trước.')
        try:
            async with self.flow.client_factory() as client:
                response = await client.request(method, config['url'] + '/sceneforge/' + path,
                    headers={'Authorization': 'Bearer ' + config['key']}, json=body, timeout=120)
                if response.status_code != 200 or len(response.content) > 1024**2:
                    raise ValueError()
                return response.json()
        except Exception:
            raise HTTPException(409, 'Engine Flow chưa có cầu nối tài khoản hoặc chưa phản hồi. Chạy start-flow.bat bản mới; chưa gửi tạo nội dung.') from None

    async def sync(self):
        data = await self.request('GET', 'accounts')
        if data.get('protocol') != 'sceneforge-account-pin-v1' or data.get('single_attempt') is not True:
            raise HTTPException(409, 'Cần engine có ghim tài khoản và một lần gửi.')
        rows = data.get('accounts', [])
        if not isinstance(rows, list) or len(rows) > 200:
            raise HTTPException(502, 'Danh sách engine chưa hợp lệ.')
        ids = set()
        config = self.flow.config()
        identity = hashlib.sha256((config['url'] + config['key']).encode()).hexdigest()
        for r in rows:
            if type(r.get('id')) is not int or r['id'] < 1:
                raise HTTPException(502, 'Mã tài khoản engine chưa hợp lệ.')
            aid = 'flow-engine-' + str(r['id'])
            ids.add(aid)
            previous = next((a for a in self.pool.rows() if a['id'] == aid), {})
            if previous.get('engine_instance') != identity:
                previous = {}
            self.vault.put('accounts', {**previous, 'id': aid, 'service': 'flow', 'name': str(r.get('name', aid))[:80],
                'engine_id': r['id'], 'engine_instance': identity, 'enabled': bool(r.get('enabled')) and previous.get('enabled', True),
                'state': previous.get('state', 'unverified'), 'session_verified': previous.get('session_verified', False),
                'active': previous.get('active', False), 'priority': previous.get('priority', len(ids)),
                'credit': previous.get('credit'), 'engine_seen': time.time()})
        for row in self.pool.rows():
            if row.get('engine_id') and row['id'] not in ids:
                row.update(session_verified=False, state='unverified')
                self.vault.put('accounts', row)
        config = self.flow.config()
        config['account_binding'] = True
        config['task_journal'] = data.get('task_journal')is True
        self.vault.set_secret('flow-engine', config)
        return {'accounts': self.pool.rows(), 'selection': self.pool.status()}

    async def check(self, aid):
        row = next((a for a in self.pool.rows() if a['id'] == aid), None)
        if not row or not row.get('engine_id'):
            raise HTTPException(409, 'Đồng bộ tài khoản từ engine Flow trước.')
        result = await self.request('POST', 'accounts/' + str(row['engine_id']) + '/check', {})
        if result.get('ok'):
            row.update(session_verified=True, state='ready', credit=result.get('credit'), credit_at=time.time())
            self.vault.put('accounts', row)
            if not any(a.get('active') for a in self.pool.rows()):
                self.pool.select({'mode': 'selected', 'account_id': aid})
        return result

    async def prepare_concurrency(self, aid):
        row = next(a for a in self.pool.rows() if a['id'] == aid)
        expected = self.flow.video_slots.limit()
        result = await self.request('POST', 'accounts/' + str(row['engine_id']) + '/concurrency', {'per_account': expected})
        if result.get('per_account') != expected:
            raise HTTPException(409, 'Engine chưa xác nhận số clip đồng thời; chưa gửi tạo.')

    async def import_session(self, cookies):
        await self.request('POST', 'accounts', {'cookies': cookies})
        return await self.sync()

    async def remove(self, aid):
        if aid in self.flow.assignments.values():
            raise HTTPException(409, 'Đợi các việc Flow của tài khoản hoàn tất.')
        row = next((a for a in self.pool.rows() if a['id'] == aid), None)
        if row and row.get('engine_id'):
            await self.request('DELETE', 'accounts/' + str(row['engine_id']))


def install_flow_accounts(app, flow):
    service = FlowAccounts(flow)
    flow.account_service = service
    @app.post('/local-api/flow/accounts/sync')
    async def sync(body: dict):
        return await service.sync()
    @app.post('/local-api/flow/accounts/import')
    async def import_session(body: dict):
        return await service.import_session(body.get('cookies'))
    @app.post('/local-api/flow/concurrency')
    async def concurrency(body: dict):
        return flow.video_slots.configure(body, bool(flow.tasks))
    @app.post('/local-api/flow/selection')
    async def select(body: dict):
        return service.pool.select(body)
    return service
