"""Compact toolbar routing/layout with actual app+storage and read-only service fixtures."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1];raw=base64.b64encode((root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()).decode()
 with tempfile.TemporaryDirectory(prefix='sf-photo-toolbar-')as data:
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];posts=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:posts.append(r.url)if r.method=='POST'and any('/local-api/'+s+'/jobs'in r.url for s in ['flow','muse','gemini-chat'])else None)
    status={'configured':True,'installed':True,'account_binding':True,'models':['veo-portrait'],'accounts':[],'per_account':2,'max_concurrency':3,'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'token'}}
    for service in ['flow','muse','gemini-chat']:page.route('**/local-api/'+service+'/status',lambda route:route.fulfill(json=status))
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'toolbar-photo',name:'Toolbar fixture',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoToolbarStep==="function"')
    wf.evaluate('''async()=>{const canvas=document.createElement('canvas');canvas.width=90;canvas.height=160;canvas.getContext('2d').fillRect(0,0,90,160);draft.refs={product:{images:[{id:'p',name:'Product',image:canvas.toDataURL()}]},background:{images:[]},person:{images:[]}};draft.idea='Giới thiệu sản phẩm';draft.voice.mode='none';draft.beats=[{id:'beat',name:'Sản phẩm',type:'wide',seconds:6,text:'',visualPrompt:'',motionPrompt:'',clips:[]}];draft.providers={creative:'gemini',video:'flow',flowModel:'veo-portrait'};draft.flowJobs=[];draft.geminiJobs=[];await save();render();await photoToolbarRefresh(true);}''')
    assert wf.locator('#photoNext').inner_text()=='Tạo storyboard'
    assert wf.locator('#photoProviderBar .primary').count()==1
    assert not wf.locator('#prepareMissing').is_visible()
    before=wf.evaluate('JSON.stringify({positions:draft.positions,view})')
    def geometry():return wf.evaluate("()=>{const bar=document.querySelector('#photoProviderBar'),v=document.querySelector('#photoViewport');return{height:bar.getBoundingClientRect().height,top:v.getBoundingClientRect().top,overflow:bar.scrollWidth>bar.clientWidth+1};}")
    wide=geometry();assert not wide['overflow'],wide
    wf.locator('#photoNext').click();wf.locator('#photoSendChat').wait_for();assert not posts;wf.locator('#closePhotoDialog').click()
    wf.evaluate("async()=>{const image=draft.refs.product.images[0].image;const key=room.id+':story';await bridge.putFile(key,await(await fetch(image)).blob());draft.storyboardImages=[{id:'one',key,preview:image,name:'Storyboard',version:1}];draft.storyboardImage='one';await save();render();}")
    assert wf.locator('#photoNext').inner_text()=='Chốt storyboard & chuẩn bị'
    wf.locator('#photoNext').click();wf.locator('#productionPrepareSend').wait_for();assert not posts;wf.locator('#closePhotoDialog').click()
    wf.evaluate("async()=>{draft.beats[0].visualPrompt='Real product';draft.beats[0].motionPrompt='Slow push';draft.geminiJobs=[{id:'fixture-prompts',state:'imported'}];draft.production={promptJobs:['fixture-prompts'],expectedBatches:1,promptSource:photoProductionInput()};await save();render();}")
    assert wf.locator('#photoNext').inner_text()=='Tạo video · 1 phần thiếu'
    wf.locator('#photoNext').click();wf.locator('#photoConfirmFlow').wait_for();assert not posts;wf.locator('#closePhotoDialog').click()
    # Menus route to the original dialogs; nothing creates an AI task automatically.
    wf.locator('#photoMore summary').click();wf.locator('[data-photo-option=planning]').click();assert 'Chia clip'in wf.locator('#photoDialogTitle').inner_text();wf.locator('#closePhotoDialog').click()
    wf.evaluate("()=>{draft.flowJobs=[{id:'flow-wait',provider:'flow',beatId:'beat',part:'a',kind:'video',state:'unknown'}];render();}")
    assert wf.locator('#photoNext').inner_text()=='Xem tiến độ'
    wf.locator('#photoNext').click();assert 'Tiến độ & kết quả'==wf.locator('#photoDialogTitle').inner_text();assert 'Chưa rõ kết quả'in wf.locator('#photoDialogBody').inner_text()
    page.route('**/local-api/flow/jobs/flow-wait/reconcile',lambda route:route.fulfill(json={'id':'flow-wait','state':'unknown'}))
    wf.locator('#photoProgressReceive').click();wf.wait_for_function('!photoToolbar.busy');assert not posts
    wf.locator('#closePhotoDialog').click()
    wf.evaluate('''async raw=>{const b=draft.beats[0],p=photoParts(b)[0],key=room.id+':clip',bytes=Uint8Array.from(atob(raw),c=>c.charCodeAt(0));await bridge.putFile(key,new Blob([bytes],{type:'video/mp4'}));draft.flowJobs=[];b.clips=[{id:'clip',part:'a',version:1,key,duration:12,signature:photoSceneSignature(b,p),reviewDecision:{status:'accepted'}}];b.chosenParts={a:'clip'};window.toolbarEditorOpened=false;actions['open-editor']=()=>{toolbarEditorOpened=true;};await save();render();}''',raw)
    assert wf.locator('#photoNext').inner_text()=='Xem & chốt bản ghép'
    wf.locator('#photoNext').click();wf.locator('#productionFinal').wait_for();assert not posts;wf.locator('#closePhotoDialog').click()
    # Refreshes preserve keyboard focus, bar height, view and saved node placement.
    wf.locator('#photoVideoSource').focus();wf.evaluate('render()');assert wf.evaluate('document.activeElement.id')=='photoVideoSource'
    assert geometry()==wide,(geometry(),wide)
    assert wf.evaluate('JSON.stringify({positions:draft.positions,view})')==before
    content=wf.evaluate('JSON.stringify([draft.beats,draft.storyboardImages])')
    wf.locator('#photoVideoSource').select_option('muse');wf.wait_for_function("photoTools().video==='muse'&&!photoToolbar.reading");assert wf.evaluate('JSON.stringify([draft.beats,draft.storyboardImages])')==content
    # Known missing connection appears contextually, with no new persistent config row.
    status['selection']['available']=False
    wf.evaluate("async()=>{await photoToolbarRefresh(true);}");wf.wait_for_function("photoToolbarConnection('muse')===false&&!photoToolbar.reading");assert wf.locator('#photoVideoConnect').is_visible();assert geometry()==wide
    wf.evaluate("()=>{draft.beats[0].clips=[];render();}");assert wf.locator('#photoNext').inner_text()=='Kết nối Muse'
    wf.locator('#photoVideoSource').select_option('flow');wf.wait_for_function("photoTools().video==='flow'&&!photoToolbar.reading");wf.locator('#photoNext').click();wf.locator('#photoFlowUse').wait_for();assert not posts;wf.locator('#closePhotoDialog').click()
    status['selection']['available']=True;wf.evaluate('async()=>{await photoToolbarRefresh(true);render();}');wf.wait_for_function("photoToolbarConnection('flow')===true&&!photoToolbar.reading")
    (root/'artifacts').mkdir(exist_ok=True);wf.locator('#photoProviderBar').screenshot(path=str(root/'artifacts/photo-toolbar-compact.png'))
    page.set_viewport_size({'width':800,'height':1000});small=geometry();assert not small['overflow'],small
    wf.locator('#photoMore summary').click();assert wf.locator('[data-photo-option=history]').is_visible();wf.locator('#photoMore summary').press('Escape');assert not wf.locator('#photoMore').evaluate('(n)=>n.open')
    page.set_viewport_size({'width':390,'height':1000});assert not geometry()['overflow'],geometry()
    assert not errors,errors;browser.close()
   print('PASS compact toolbar: guided storyboard/prompt/clip confirmation, zero AI job POSTs; unified read-only recovery; whole-draft preview route; sources preserve content; contextual connection, focus and geometry stable; advanced dialogs accessible and no overflow at wide/narrow widths. Real browser/storage, service status fixtures.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()
if __name__=='__main__':main()
