from .admission import guarded_submission
from contextlib import nullcontext
"""Flow2API loopback bridge. Explicit submissions, bounded concurrency, no retries.

This speaks the inspected upstream OpenAI-compatible protocol. Real provider
generation must still be verified with a user's locally configured Flow engine.
"""
import asyncio, base64, hashlib, io, json, os, re, time, uuid
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from .account_pool import AccountPool
from fastapi import HTTPException
from fastapi.responses import FileResponse
from PIL import Image
from .batch_images import BatchImages
from .request_ledger import NO_RESULT, RequestConflict


def local_url(value):
    try:
        p = urlsplit(value)
        if p.scheme != 'http' or p.hostname != '127.0.0.1' or not p.port or p.username or p.password or p.path not in ('', '/') or p.query or p.fragment:
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise HTTPException(400, 'Địa chỉ engine phải là http://127.0.0.1:PORT, không có đường dẫn.')
    return value.rstrip('/')


class FlowProvider:
    def __init__(self, vault, root, ledger, client_factory=None):
        self.vault, self.ledger = vault, ledger
        self.root = Path(root) / 'flow-results'
        self.root.mkdir(exist_ok=True, mode=0o700)
        self.client_factory = client_factory or (lambda: httpx.AsyncClient(timeout=1800, follow_redirects=False, trust_env=False))
        self.tasks = {}
        self.assignments = {}
        self.reconcile_locks = {}
        self.lane = asyncio.Semaphore(3)
        from .video_slots import VideoSlots
        self.video_slots = VideoSlots(vault, 'flow')

    def config(self):
        return self.vault.secret('flow-engine') or {}

    def status(self):
        c = self.config()
        return {'configured': bool(c.get('url') and c.get('key')), 'url': c.get('url', 'http://127.0.0.1:8766'),
                **self.video_slots.status(), 'account_binding': bool(c.get('account_binding')), 'task_journal':bool(c.get('task_journal')), 'selection': AccountPool(self.vault, 'flow').status(),
                'models': c.get('models', []), 'model_details': c.get('model_details', []), 'checked_at': c.get('checked_at'),
                'generation_verified': bool(c.get('generation_verified')),
                'automatic_retry': False, 'muse_available': False}

    def configure(self, body):
        if self.tasks:
            raise HTTPException(409, 'Đợi các tác vụ Flow hiện tại hoàn tất trước khi đổi engine.')
        url = local_url(body.get('url'))
        key = body.get('key')
        if not isinstance(key, str) or not 12 <= len(key) <= 512 or any(ch in key for ch in '\r\n'):
            raise HTTPException(400, 'Nhập API key riêng của engine Flow, tối thiểu 12 ký tự; không nhập cookie Google.')
        self.vault.set_secret('flow-engine', {'url': url, 'key': key, 'models': [], 'generation_verified': False})
        return self.status()

    async def discover(self):
        c = self.config()
        if not c.get('key'):
            raise HTTPException(409, 'Chưa cấu hình engine Flow cục bộ.')
        try:
            async with self.client_factory() as client:
                r = await client.get(c['url'] + '/v1/models', headers={'Authorization': 'Bearer ' + c['key']}, timeout=15)
                if r.status_code != 200:
                    raise ValueError()
                if len(r.content) > 1024 * 1024:
                    raise ValueError()
                rows = r.json()['data']
                models = [m['id'] for m in rows if isinstance(m, dict) and isinstance(m.get('id'), str)
                          and re.fullmatch(r'[A-Za-z0-9._:-]{1,160}', m['id'])]
        except (httpx.HTTPError, ValueError, KeyError, TypeError):
            raise HTTPException(502, 'Chưa đọc được model từ engine Flow. Không gửi yêu cầu tạo nào.')
        details = [{'id': m['id'], 'description': str(m.get('description', ''))[:300]} for m in rows if isinstance(m, dict) and m.get('id') in models]
        c.update(models=sorted(set(models)), model_details=details, checked_at=time.time())
        self.vault.set_secret('flow-engine', c)
        return self.status()

    @staticmethod
    def valid_id(value):
        if not isinstance(value, str) or not re.fullmatch(r'flow-[a-f0-9-]{36}', value):
            raise HTTPException(400, 'Mã tác vụ Flow không hợp lệ.')
        try:
            uuid.UUID(value[5:])
        except ValueError:
            raise HTTPException(400, 'Mã tác vụ Flow không hợp lệ.')

    def lookup(self, request_id):
        self.valid_id(request_id)
        with self.ledger.connect() as db:
            row = db.execute('SELECT state,result,updated FROM request WHERE id=?', (request_id,)).fetchone()
        if not row:
            raise HTTPException(404, 'Không có tác vụ Flow này.')
        return {**self.ledger.receipt(request_id), 'request_id': request_id, 'state': row[0], 'result': json.loads(row[1]) if row[0] == 'done' else None,
                'updated': row[2], 'automatic_retry': False}

    @guarded_submission
    async def submit(self, body):
        if body.get('confirm_send') is not True:
            raise HTTPException(409, 'Xác nhận gửi tới Flow; tạo video/ảnh có thể tốn credit.')
        c = self.config()
        if not c.get('key') or body.get('model') not in c.get('models', []):
            raise HTTPException(409, 'Kết nối engine, đọc model và chọn model Flow trước.')
        rid = body.get('request_id')
        self.valid_id(rid)
        prompt, refs, kind = body.get('prompt'), body.get('references', []), body.get('kind')
        if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 20000 or kind not in ('image', 'video'):
            raise HTTPException(400, 'Prompt tối đa 20.000 ký tự; đầu ra ảnh hoặc video.')
        model = body['model'].lower()
        if kind == 'video' and 'image' in model or kind == 'image' and model.startswith(('veo-', 'omni-')):
            raise HTTPException(400, 'Model đã chọn không khớp loại đầu ra. Chưa gửi yêu cầu.')
        if not isinstance(refs, list) or len(refs) > 8 or sum(BatchImages.decode_image(r) for r in refs) > 24 * 1024**2:
            raise HTTPException(400, 'Tối đa 8 ảnh tham chiếu, tổng 24 MB.')
        if len(self.tasks) >= 30:
            raise HTTPException(429, 'Hàng chờ Flow đầy; chưa gửi tác vụ mới.')
        payload = {'kind': kind, 'model': body['model'], 'prompt': prompt, 'references': refs, 'engine': c['url'],'room_id':str(body.get('room_id',''))[:100],'scene_id':str(body.get('scene_id',''))[:100]}
        if hasattr(self, 'account_service'):
            selection = self.account_service.pool.status()
            if not c.get('account_binding') or not selection['available'] or body.get('selection_token') != selection['token']:
                raise HTTPException(409, 'Đồng bộ và chọn tài khoản Flow; rà lại lựa chọn trước khi gửi.')
            payload.update(mode=selection['mode'], plan=selection['permitted'], selection_token=selection['token'])
        try:
            _, cached = self.ledger.claim(rid, payload)
        except (ValueError, RequestConflict) as e:
            raise HTTPException(409, str(e))
        if cached is not NO_RESULT:
            return self.lookup(rid)
        if 'plan' in payload:
            self.assignments[rid] = min(payload['plan'], key=lambda a: list(self.assignments.values()).count(a)) if payload['mode'] == 'balanced' else payload['plan'][0]
        self.tasks[rid] = asyncio.create_task(self.run(rid, payload, c))
        def finished(task):
            self.tasks.pop(rid, None)
            self.assignments.pop(rid, None)
        self.tasks[rid].add_done_callback(finished)
        return self.lookup(rid)

    @staticmethod
    def output_url(data):
        if isinstance(data.get('url'), str):
            return data['url']
        try:
            text = data['choices'][0]['message']['content']
            if not isinstance(text, str):
                return None
            match = re.search(r'!\[[^\]]*\]\(([^\s)]+)\)|<video[^>]*\bsrc=[\"\x27]([^\"\x27]+)', text)
            return next((v for v in match.groups() if v), None) if match else None
        except (KeyError, IndexError, TypeError):
            return None

    async def run(self, rid, payload, config):
        if not hasattr(self, 'account_service'):
            return await self._run_one(rid, payload, config)
        import contextlib
        service = self.account_service
        sent = False
        plan = payload['plan'] if payload['mode'] == 'failover' else payload['plan'][:1]
        if payload['mode'] == 'balanced':
            plan = [self.assignments[rid]]
        try:
            for aid in plan:
                async with self.video_slots.slot(aid):
                    self.assignments[rid] = aid
                    row = next((a for a in service.pool.rows() if a['id'] == aid), None)
                    if not row or not service.pool.eligible(row):
                        continue
                    checked = await service.check(aid)
                    reason = 'auth' if checked.get('accepted') is False and checked.get('reason') == 'auth' else (
                        'quota' if checked.get('ok') and checked.get('credit') == 0 and payload['kind'] == 'video' else None)
                    if reason:
                        service.pool.limit(aid, reason)
                        if payload['mode'] == 'failover':
                            continue
                        break
                    if not checked.get('ok'):
                        break
                    await service.prepare_concurrency(aid)
                    sent = True
                    return await self._run_one(rid, {**payload, 'account_id': aid, 'engine_id': row['engine_id']}, config)
            self.ledger.finish(rid, 'unknown' if sent else 'failed')
        except asyncio.CancelledError:
            self.ledger.finish(rid, 'unknown')
            raise
        except Exception:
            self.ledger.finish(rid, 'unknown' if sent else 'failed')

    async def _run_one(self, rid, payload, config, recovered_response=None):
        state, result, code = 'unknown', None, 'UNKNOWN'
        tmp = self.root / (rid + '.partial')
        try:
            async with self.lane if not hasattr(self, 'account_service') else nullcontext():
                parts = [{'type': 'text', 'text': payload.get('prompt','')}] + [
                    {'type': 'image_url', 'image_url': {'url': 'data:' + r['mime_type'] + ';base64,' + r['data']}}
                    for r in payload.get('references',[])]
                async with self.client_factory() as client:
                    self.ledger.set_metadata(rid,{'provider':'flow','account_id':payload.get('account_id'),'engine_id':payload.get('engine_id'),'model':payload['model'],'kind':payload['kind'],'room_id':payload.get('room_id'),'scene_id':payload.get('scene_id'),'engine_instance':hashlib.sha256((config['url']+config['key']).encode()).hexdigest()})
                    if recovered_response is None:
                        async with client.stream('POST', config['url'] + '/v1/chat/completions',
                                                 headers={'Authorization': 'Bearer ' + config['key'], 'X-SceneForge-Request':rid, **({'X-SceneForge-Account': str(payload['engine_id'])} if 'engine_id' in payload else {})},
                                                 json={'model': payload['model'], 'messages': [{'role': 'user', 'content': parts}], 'stream': False}) as r:
                            if r.status_code != 200:
                                state = 'failed' if r.status_code in (400, 401, 403, 404, 422, 429) else 'unknown'
                                code = 'HTTP_' + str(r.status_code)
                                return
                            if 'engine_id' in payload and r.headers.get('x-sceneforge-account') != str(payload['engine_id']):
                                code = 'ACCOUNT_BINDING_UNCONFIRMED'
                                return
                            chunks, total = [], 0
                            async for chunk in r.aiter_bytes():
                                total += len(chunk)
                                if total > 2 * 1024**2:
                                    raise ValueError('oversized response')
                                chunks.append(chunk)
                        response_data=json.loads(b''.join(chunks))
                    else:response_data=recovered_response
                    url = self.output_url(response_data)
                    p, origin = urlsplit(url or ''), urlsplit(config['url'])
                    # Never fetch arbitrary model-supplied URLs or send engine keys to a CDN.
                    if not url or p.username or p.password or p.fragment or not (
                        (p.scheme, p.hostname, p.port) == (origin.scheme, origin.hostname, origin.port)
                        or p.scheme == 'https' and p.hostname in ('storage.googleapis.com', 'lh3.googleusercontent.com') and p.port in (None, 443)):
                        code = 'UNSUPPORTED_RESULT_URL'
                        return
                    size = 0
                    async with client.stream('GET', url, headers={}) as media:
                        if media.status_code != 200:
                            code = 'RESULT_DOWNLOAD_FAILED'
                            return
                        mime = media.headers.get('content-type', '').split(';')[0]
                        allowed = {'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp'} if payload['kind'] == 'image' else {'video/mp4': '.mp4', 'video/webm': '.webm'}
                        if mime not in allowed:
                            code = 'RESULT_TYPE_MISMATCH'
                            return
                        if self.ledger.storage:
                            try:expected=int(media.headers.get('content-length','0'))
                            except ValueError:expected=0
                            self.ledger.storage.reserve_download(rid,expected or 8*1024**2)
                        digest = hashlib.sha256()
                        with tmp.open('xb') as out:
                            async for chunk in media.aiter_bytes():
                                size += len(chunk)
                                if size > (24 if payload['kind'] == 'image' else 500) * 1024**2:
                                    raise ValueError('oversized media')
                                if self.ledger.storage and(size==len(chunk)or size//(8*1024**2)!=(size-len(chunk))//(8*1024**2)):self.ledger.storage.reserve_download(rid,8*1024**2)
                                digest.update(chunk)
                                out.write(chunk)
                            out.flush()
                            os.fsync(out.fileno())
                    if not size:
                        raise ValueError('empty media')
                    if payload['kind'] == 'image':
                        with Image.open(tmp) as image:
                            if image.width * image.height > 40_000_000:
                                raise ValueError('oversized image')
                            image.verify()
                    else:
                        # Check actual decode before accepting a file as a completed video.
                        from .machine_checks import run_command
                        rc, output, _ = await run_command('ffprobe', '-v', 'error', '-protocol_whitelist', 'file,pipe', '-show_streams', '-of', 'json', str(tmp), timeout=30)
                        if rc or not any(s.get('codec_type') == 'video' for s in json.loads(output).get('streams', [])):
                            raise ValueError('invalid video')
                    name = rid + allowed[mime]
                    os.replace(tmp, self.root / name)
                    result = {'file': name, 'mime_type': mime, 'sha256': digest.hexdigest(), 'bytes': size,
                              'account_id': payload.get('account_id'),'room_id':payload.get('room_id'),'scene_id':payload.get('scene_id'),
                              'model': payload['model'], 'kind': payload['kind'], 'origin': 'flow', 'cost': None}
                    state, code = 'done', 'DONE'
                    current = self.config()
                    if current.get('url') == config['url'] and current.get('key') == config['key']:
                        current['generation_verified'] = True
                        self.vault.set_secret('flow-engine', current)
        except asyncio.CancelledError:
            code = 'INTERRUPTED'
            raise
        except Exception:
            code = 'NETWORK_OR_RESULT_UNKNOWN'
        finally:
            tmp.unlink(missing_ok=True)
            self.ledger.finish(rid, state, result)
            self.vault.put('logs', {'id': rid, 'kind': 'Flow', 'state': state, 'code': code, 'at': time.time(), 'cost': None})

    async def reconcile(self,rid):
        async with self.reconcile_locks.setdefault(rid,asyncio.Lock()):
            return await self._reconcile(rid)

    async def _reconcile(self,rid):
        record=self.lookup(rid)
        if record['state']=='done':return record
        if rid in self.tasks:raise HTTPException(409,'Lượt vẫn đang chạy trong app; chờ kết quả.')
        meta=self.ledger.metadata(rid);config=self.config()
        if not meta.get('engine_id')or meta.get('engine_instance')!=hashlib.sha256((config.get('url','')+config.get('key','')).encode()).hexdigest():raise HTTPException(409,'Không có định danh engine/tài khoản gốc để đối soát. Không tạo lại.')
        async with self.client_factory()as client:
            response=await client.get(config['url']+'/sceneforge/tasks/'+rid+'?refresh_media=true',headers={'Authorization':'Bearer '+config['key']},timeout=120)
            if response.status_code!=200 or len(response.content)>2*1024**2:raise HTTPException(409,'Engine chưa tìm được kết quả; kiểm tra lịch sử. Không gửi tạo mới.')
            remote=response.json()
        if remote.get('state')!='done':return {**record,'reconciliation':remote.get('state','unknown')}
        if remote.get('account_id')!=meta['engine_id']:raise HTTPException(409,'Tài khoản engine không khớp lượt gốc; chưa nhận kết quả.')
        (self.root/(rid+'.partial')).unlink(missing_ok=True)
        await self._run_one(rid,meta,config,recovered_response=remote['response'])
        return self.lookup(rid)

    def file(self, rid):
        if self.ledger.storage:
            stored=self.ledger.storage.file(rid)
            if stored is not None:
                record=self.lookup(rid)
                if record['state']=='done':return FileResponse(stored,media_type=record['result'].get('mime_type','application/octet-stream'),filename=record['result'].get('file',rid))
        record = self.lookup(rid)
        if record['state'] != 'done':
            raise HTTPException(409, 'Chưa có kết quả Flow được lưu. Không tự gửi lại.')
        result = record['result']
        name = result.get('file', '')
        if name not in {rid + ext for ext in ('.png', '.jpg', '.webp', '.mp4', '.webm')} or not (self.root / name).is_file():
            raise HTTPException(404, 'Thiếu tệp kết quả Flow.')
        return FileResponse(self.root / name, media_type=result['mime_type'], filename=name)

    async def close(self):
        tasks = list(self.tasks.values())
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)


def install_flow_provider(app, vault, root, ledger):
    service = FlowProvider(vault, root, ledger)
    app.get('/local-api/flow/status')(lambda: service.status())
    @app.post('/local-api/flow/configure')
    async def configure(body: dict):
        return service.configure(body)
    app.post('/local-api/flow/models')(service.discover)
    @app.post('/local-api/flow/jobs')
    async def submit(body: dict):
        return await service.submit(body)
    app.get('/local-api/flow/jobs/{request_id}')(service.lookup)
    app.get('/local-api/flow/jobs/{rid}/reconcile')(service.reconcile)
    app.get('/local-api/flow/files/{rid}')(service.file)
    return service
