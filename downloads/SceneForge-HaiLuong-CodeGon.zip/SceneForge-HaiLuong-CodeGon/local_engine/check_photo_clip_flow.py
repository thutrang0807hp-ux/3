"""Real browser/local library; provider transport is a fixture, no online AI calls."""
import os,socket,subprocess,sys,tempfile,time,urllib.request,base64,json
from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1];raw=base64.b64encode((root/'scripts/native-preview/assets/subtitle-sample.mp4').read_bytes()).decode()
 with tempfile.TemporaryDirectory(prefix='sf-photo-flow-')as data:
  with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   for _ in range(100):
    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/local-api/health',timeout=.2);break
    except OSError:time.sleep(.1)
   with sync_playwright()as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(f'http://127.0.0.1:{port}/');page.wait_for_function('!!db&&SceneForgeStorage.state.active&&!!SceneForgeStorageActions')
    page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'photo-fixture',name:'Photo fixture',mode:'photos',stage:'review',productId:products[0].id,refs:structuredClone(products[0].refs)};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}")
    wf=page.locator('#workflowFrame').element_handle().content_frame();wf.wait_for_function('loaded&&typeof photoParts==="function"')
    state=wf.evaluate('''async raw=>{
     const c=document.createElement('canvas');c.width=90;c.height=160;c.getContext('2d').fillRect(0,0,90,160);const image=c.toDataURL();draft.refs={product:{description:'Real product',images:[{id:'ref',name:'product.png',image}]},background:{images:[]},person:{images:[]}};
     draft.beats=[{id:'beat',name:'Demo',type:'wide',seconds:13,text:'Câu đầu. Câu tiếp.',angle:'Medium',movement:'Slow push',visualPrompt:'Product on table',motionPrompt:'Hand picks up product',frames:[],clips:[]}];draft.providers={creative:'gemini',video:'flow',flowModel:'veo-portrait'};draft.voice.mode='native';draft.flowJobs=[];
     const b=draft.beats[0];photoFreezeParts(b);if(photoParts(b).length!==2)throw Error('Long beat not split');const joined=photoParts(b).map(p=>photoPartText(b,p)).join(' ');if(joined!==b.text)throw Error('Dialogue duplicated or lost');
     const hold={id:'hold',seconds:9,text:'',clips:[],clipPlanning:{holdTail:true}};if(photoParts(hold).length!==1||photoParts(hold)[0].holdTail!==1)throw Error('Shared tail planner not used');
     const legacy={id:'legacy',seconds:13,text:'',clips:[{id:'legacy-clip'}]};if(photoParts(legacy).length!==1)throw Error('Old layout remapped');
     const bytes=Uint8Array.from(atob(raw),c=>c.charCodeAt(0)),info=await photoReadClip(new Blob([bytes],{type:'video/mp4'}));
     for(let n=1;n<=15;n++){const key=room.id+':photo-clip:a'+n;await bridge.putFile(key,new Blob([bytes,new Uint8Array([n,0,0,0])],{type:'video/mp4'}));b.clips.push({id:'a'+n,key,name:'Clip '+n,part:'a',version:n,signature:photoSceneSignature(b,photoParts(b)[0]),slotStart:0,slotEnd:photoParts(b)[0].end,...info});}
     const key=room.id+':photo-clip:b1';await bridge.putFile(key,new Blob([bytes,new Uint8Array([99])],{type:'video/mp4'}));b.clips.push({id:'b1',key,name:'Rejected other slot',part:'b',version:1,signature:photoSceneSignature(b,photoParts(b)[1]),reviewDecision:{status:'rejected'},...info});b.chosenClip='a1';b.chosenParts={a:'a1'};
     await save();render();return{parts:photoParts(b),image};
    }''',raw)
    assert wf.locator('[data-node=bank] .productionSlot').count()==2
    wf.evaluate("photoSlotDialog('beat','a')");assert 'Bản 15'in wf.locator('#photoDialogBody').inner_text();assert wf.locator('[data-photo-choose-clip]').count()==0
    wf.evaluate("$('#photoDialog').close()")
    page.evaluate('async()=>{await flushFrames();await SceneForgeStorage.checkpoint();}')
    snap=page.evaluate("async()=>await SceneForgeStorage.api('snapshot')");oldfiles={r['key']:r['value']['hash']for r in snap['records']if r['store']=='files'and isinstance(r['value'],dict)and 'hash'in r['value']}
    wf.evaluate("async()=>{const b=draft.beats[0];await photoApproveSlots([{b,p:photoParts(b)[0]}]);}")
    assert wf.evaluate("draft.beats[0].clips.map(c=>c.id)")==['a15','b1']
    for n in range(1,15):assert page.request.get(f'http://127.0.0.1:{port}/local-api/library/assets/'+oldfiles['photo-fixture:photo-clip:a'+str(n)]).status==404
    assert page.request.get(f'http://127.0.0.1:{port}/local-api/library/assets/'+oldfiles['photo-fixture:photo-clip:a15']).status==200
    # Independent slots prepare concurrently; per-account backend manages actual slots.
    status={'configured':True,'account_binding':True,'models':['veo-portrait'],'per_account':2,'max_concurrency':3,'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'t'}}
    page.route('**/local-api/flow/status',lambda route:route.fulfill(json=status));sent=[]
    def jobs(route):
     body=route.request.post_data_json;sent.append(body);route.fulfill(json={'id':body['request_id'],'state':'submitted'})
    page.route('**/local-api/flow/jobs',jobs)
    wf.evaluate("async()=>{draft.geminiJobs=[{id:'fixture-prompts',state:'imported'}];draft.production={promptJobs:['fixture-prompts'],expectedBatches:1,promptSource:photoProductionInput()};await photoRunClips({beatId:'beat',part:'a',regenerate:true});}");assert '1 yêu cầu'in wf.locator('#photoConfirmFlow').inner_text()
    assert wf.evaluate("photoLatest(draft.beats[0],'a').id")=='a15'
    wf.locator('#photoConfirmFlow').click();wf.wait_for_function('!photoMediaBusy');assert len(sent)==1, wf.locator('#photoToast').inner_text()
    assert sent[0]['part']=='a'and len(sent[0]['references'])==1 and 'EXACT VIETNAMESE DIALOGUE'in sent[0]['prompt']
    assert not wf.evaluate("photoClipValid(draft.beats[0],photoParts(draft.beats[0])[0])")
    # Ambiguous response blocks a second send. Reconcile only reads and imports.
    rid=sent[0]['request_id'];wf.evaluate("draft.flowJobs[0].state='unknown'")
    page.route('**/local-api/flow/jobs/'+rid+'/reconcile',lambda route:route.fulfill(json={'id':rid,'state':'done','result':{'mime_type':'video/mp4','account_id':'fixture-account'}}))
    page.route('**/local-api/flow/files/'+rid,lambda route:route.fulfill(body=base64.b64decode(raw),content_type='video/mp4'))
    wf.evaluate('async()=>{await photoRecoverFlows();}');assert len(sent)==1
    assert wf.evaluate("photoLatest(draft.beats[0],'a').requestId")==rid
    assert not wf.evaluate("photoClipValid(draft.beats[0],photoParts(draft.beats[0])[0])")
    # Continuity waits for approval, then uses the previous final frame.
    wf.evaluate("async()=>{const b=draft.beats[0];b.clipPlanning={continuity:true};for(const c of b.clips)c.signature=photoSceneSignature(b,photoParts(b).find(p=>p.id===(c.part||'a')));const a=photoLatest(b,'a');a.reviewDecision={status:'accepted'};if(!photoChainReady(b,photoParts(b)[1]))throw Error('Approved tail unavailable');const refs=await photoPartReferences(b,photoParts(b)[1]);if(refs.length!==2)throw Error('Tail + product not attached');a.reviewDecision={status:'rejected'};if(photoChainReady(b,photoParts(b)[1]))throw Error('Unapproved continuity allowed');}")
    # A change to the next part does not invalidate the already approved predecessor.
    wf.evaluate("async()=>{const b=draft.beats[0],a=photoLatest(b,'a');a.reviewDecision={status:'accepted'};b.partText={b:'Lời khác'};if(!photoCues().some(c=>c.text==='Lời khác'))throw Error('Captions kept stale whole-beat dialogue');if(!photoClipValid(b,photoParts(b)[0]))throw Error('Unrelated part invalidated predecessor');}")
    # Gemini receives original product file + ONE overall storyboard, and writes all parts.
    chat=[]
    page.route('**/local-api/gemini-chat/status',lambda route:route.fulfill(json={'installed':True,'configured':True,'selection':{'available':True,'mode':'selected','account_name':'Fixture','token':'g'}}))
    def chat_job(route):
     body=route.request.post_data_json;chat.append(body);route.fulfill(json={'id':body['request_id'],'state':'submitted'})
    page.route('**/local-api/gemini-chat/jobs',chat_job)
    wf.evaluate("async()=>{const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=800;canvas.getContext('2d').fillRect(0,0,1200,800);const file=await(await fetch(canvas.toDataURL())).blob();await bridge.putFile(room.id+':storyboard:one',file);draft.storyboardImages=[{id:'one',key:room.id+':storyboard:one',name:'Overall',preview:canvas.toDataURL(),version:1}];draft.storyboardImage='one';await save();await photoGchatSubmit('text',photoChatPack(),'writing');}")
    wf.locator('#photoSendChat').click();wf.wait_for_function('!photoMediaBusy');assert len(chat)==1
    assert len(chat[0]['references'])==2 and 'CLIP PLAN'in chat[0]['prompt']
    assert wf.evaluate("async refs=>{const r=refs.at(-1),image=await createImageBitmap(await(await fetch('data:'+r.mime_type+';base64,'+r.data)).blob());return image.width;}",chat[0]['references'])==1200
    data_story=wf.evaluate("()=>({beats:draft.beats.map(b=>({id:b.id,seconds:b.seconds,text:b.text,type:b.type,angle:'Medium',movement:'Push',visualPrompt:'Original product on table',motionPrompt:'Hand lifts product',refRoles:['product'],partPrompts:Object.fromEntries(photoParts(b).map(p=>[p.id,{visualPrompt:'Product '+p.id,motionPrompt:'Action '+p.id}]))}))})")
    chatid=chat[0]['request_id'];page.route('**/local-api/gemini-chat/jobs/'+chatid,lambda route:route.fulfill(json={'id':chatid,'state':'done','result':{'text':json.dumps(data_story),'account_id':'fixture'}}))
    wf.evaluate('async()=>{await photoRecoverChat();}');wf.locator('#photoApplyChat').click();wf.wait_for_function("draft.geminiJobs.at(-1).state==='imported'")
    assert wf.evaluate("draft.beats[0].partPrompts.b.motionPrompt")=='Action b'
    # Real editor import: optional silent tail becomes an image hold after video.
    wf.evaluate("async()=>{const old=draft.beats[0].clips.filter(c=>(c.part||'a')==='a').at(-1);const b={id:'silent',name:'Silent tail',type:'wide',seconds:9,text:'',visualPrompt:'Product',motionPrompt:'Slow turn',clips:[],clipPlanning:{holdTail:true}};draft.beats=[b];photoFreezeParts(b);b.clips=[{...old,id:'silent-clip',part:'a',slotStart:0,slotEnd:9,signature:photoSceneSignature(b,photoParts(b)[0]),continuityFrom:null,reviewDecision:{status:'accepted'}}];b.chosenParts={a:'silent-clip'};draft.flowJobs=[];draft.voice.mode='none';b.clips[0].signature=photoSceneSignature(b,photoParts(b)[0]);draft.post.captions=false;draft.post.musicMode='off';draft.placement='assembled';assemble();await save();await openEditor();}")
    page.wait_for_function("!!document.querySelector('#standaloneEditorDemo')?.contentWindow.SceneForgeEditor")
    ed=page.locator('#standaloneEditorDemo').element_handle().content_frame();ed.wait_for_function("SceneForgeEditor.getState().items.length===2")
    items=ed.evaluate('SceneForgeEditor.getState().items');assert [(i['kind'],i['duration'])for i in items]==[('video',8),('image',1)]
    assert not errors,errors;browser.close()
   print('PASS Photo Studio browser + actual SQLite/files: long beat split without duplicate dialogue; one storyboard, optional frames; latest 15th version; approval physically retires old 14, preserves other slot; exact-part regenerate; provider selection/concurrency fixture; unknown reconciles without resending; received clip needs approval; approved previous tail + original product refs. Gemini single-storyboard/original refs + part prompts, real editor video/still handoff. No online AI calls.')
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill()
if __name__=='__main__':main()
