"""Install a pinned Muse web SDK in an isolated venv; never log in or generate."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import venv

REVISION = 'bf964f7c022f11a3574e2e17a8ec57e7c9b0e596'
URL = 'https://github.com/minhquan130599/MuseAI-API.git'


def install(root):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    source = root / 'source'
    def run(*args):
        subprocess.run(list(map(str, args)), check=True)
    if not source.exists():
        run('git', 'clone', URL, source)
    run('git', '-C', source, 'checkout', '--detach', REVISION)
    # This upstream snapshot has literal display-line prefixes in source/TOML.
    # Normalize only in the installation checkout; preserve the pinned revision.
    for file in [source / 'pyproject.toml', *source.glob('muse_ai/*.py')]:
        text = file.read_text(encoding='utf-8')
        file.write_text(re.sub(r'^ *\d+ \| ?', '', text, flags=re.M), encoding='utf-8')
    env = root / 'venv'
    if not env.exists():
        venv.create(env, with_pip=True)
    python = env / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    run(python, '-m', 'pip', 'install', source)
    run(python, '-m', 'pip', 'check')
    run(python, '-c', 'from muse_ai import MuseAuth, MuseClient; import inspect; assert "download" in inspect.signature(MuseClient.generate_video).parameters; print("Muse SDK import OK; no account requests")')
    (root / 'installation.json').write_text(json.dumps({'repository': URL, 'revision': REVISION,
        'import_checked': True, 'account_verified': False, 'generation_verified': False,
        'license': 'No license file in inspected snapshot; SDK excluded from SceneForge distribution',
        'line_prefix_patch': True}, indent=2), encoding='utf-8')
    print('Installed SDK only. No login, model download or generation performed.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    data = Path(os.environ.get('SCENEFORGE_LOCAL_DATA', str(Path.home() / '.sceneforge-local')))
    default = Path(os.environ.get('SCENEFORGE_MUSE_WEB_DIRECTORY', str(data / 'engines/muse-web')))
    parser.add_argument('--directory', type=Path, default=default)
    install(parser.parse_args().directory)
