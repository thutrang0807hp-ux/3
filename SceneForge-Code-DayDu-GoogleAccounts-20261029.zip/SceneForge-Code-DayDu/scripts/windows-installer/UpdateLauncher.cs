using System;using System.IO;using System.IO.Compression;using System.Diagnostics;using System.Text;using System.Windows.Forms;
internal static class UpdateLauncher {
 [STAThread] static int Main(){
  string folder=Path.Combine(Path.GetTempPath(),"SceneForge-update-"+Guid.NewGuid().ToString("N"));
  try{
   Directory.CreateDirectory(folder);
   using(var stream=System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("SceneForgePatch.zip"))using(var archive=new ZipArchive(stream,ZipArchiveMode.Read)){
    foreach(var entry in archive.Entries){string file=Path.GetFullPath(Path.Combine(folder,entry.FullName.Replace('/',Path.DirectorySeparatorChar)));if(!file.StartsWith(folder+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("Invalid update path");Directory.CreateDirectory(Path.GetDirectoryName(file));if(entry.Name.Length>0)using(var source=entry.Open())using(var target=File.Create(file))source.CopyTo(target);}
   }
   string code="& ([scriptblock]::Create([IO.File]::ReadAllText((Join-Path $env:SF_PATCH_ROOT 'apply_update.ps1'))))";
   var start=new ProcessStartInfo(Path.Combine(Environment.GetEnvironmentVariable("WINDIR"),"System32","WindowsPowerShell","v1.0","powershell.exe"),"-STA -NoLogo -NoProfile -NonInteractive -EncodedCommand "+Convert.ToBase64String(Encoding.Unicode.GetBytes(code))){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=folder};
   start.EnvironmentVariables["SF_PATCH_ROOT"]=folder;
   using(var process=Process.Start(start)){process.WaitForExit();return process.ExitCode;}
  }catch(Exception e){MessageBox.Show("Chưa cập nhật được SceneForge.\n"+e.Message,"SceneForge",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;}
  finally{try{if(Directory.Exists(folder))Directory.Delete(folder,true);}catch{}}
 }
}
