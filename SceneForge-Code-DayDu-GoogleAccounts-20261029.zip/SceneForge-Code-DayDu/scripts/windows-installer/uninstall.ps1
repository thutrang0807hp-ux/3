﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$release=[IO.Path]::GetFullPath($env:SF_TASK_ROOT).TrimEnd('\')
$cfg=Get-Content -LiteralPath (Join-Path $release 'install-settings.json') -Raw|ConvertFrom-Json
$marker=Get-Content -LiteralPath (Join-Path $release 'installation.json') -Raw|ConvertFrom-Json
$root=[IO.Path]::GetFullPath($cfg.install_root).TrimEnd('\')
if($marker.app_id -ne 'SceneForge' -or $release -ne (Join-Path (Join-Path $root 'releases') $marker.version) -or $root.Length -le 3){throw 'Thông tin cài đặt không hợp lệ; chưa xóa gì.'}
$form=New-Object Windows.Forms.Form;$form.Text='Gỡ cài đặt SceneForge';$form.Size=New-Object Drawing.Size(620,300);$form.StartPosition='CenterScreen';$form.Font=New-Object Drawing.Font('Segoe UI',10)
$label=New-Object Windows.Forms.Label;$label.SetBounds(20,20,565,90);$label.Text="Gỡ ứng dụng tại: $root`r`n`r`nMặc định GIỮ dự án, tài khoản và model tại: $($cfg.data_directory)";$form.Controls.Add($label)
$delete=New-Object Windows.Forms.CheckBox;$delete.Text='Xóa cả dữ liệu và model (không khôi phục được)';$delete.SetBounds(20,125,560,30);$delete.Enabled=[bool]$cfg.data_created;$form.Controls.Add($delete)
$go=New-Object Windows.Forms.Button;$go.Text='Gỡ ứng dụng';$go.SetBounds(310,205,140,33);$form.Controls.Add($go)
$cancel=New-Object Windows.Forms.Button;$cancel.Text='Hủy';$cancel.SetBounds(465,205,110,33);$cancel.Add_Click({$form.Close()});$form.Controls.Add($cancel)
function Under([string]$a,[string]$b){return $a.StartsWith($b.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)}
function RemoveApp([bool]$erase){
 if($erase -and !$cfg.data_created){throw 'Thư mục dữ liệu đã tồn tại trước khi cài; không tự xóa.'}
 if($erase -and $env:SCENEFORGE_UNINSTALL_TEST -ne '1' -and [Windows.Forms.MessageBox]::Show($form,'XÓA toàn bộ dự án/tài khoản/model tại '+$cfg.data_directory+'?','Xác nhận xóa dữ liệu','YesNo','Warning') -ne 'Yes'){return}
 $go.Enabled=$false
 try{
  # Kill only processes whose executable is inside this selected application installation.
  $processes=Get-CimInstance Win32_Process|Where-Object { $_.ExecutablePath -and (Under $_.ExecutablePath (Join-Path $root 'releases')) }
  foreach($p in $processes){if($p.ProcessId -ne $PID){Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue}}
  Start-Sleep -Milliseconds 700
  $registration=Join-Path $release 'registration.json';$reg=if(Test-Path -LiteralPath $registration){Get-Content -LiteralPath $registration -Raw|ConvertFrom-Json}else{$null}
  if(!('SceneForgeShortcut' -as [type])){Add-Type -TypeDefinition ([IO.File]::ReadAllText((Join-Path $release 'app\ShellShortcut.cs')))}
  if($reg){
   $links=@($reg.desktop_link);if(Test-Path -LiteralPath $reg.menu_directory){$links+=Get-ChildItem -LiteralPath $reg.menu_directory -Filter '*.lnk'|ForEach-Object {$_.FullName}}
   foreach($link in $links){if($link -and(Test-Path -LiteralPath $link)){if(Under ([SceneForgeShortcut]::Target($link)) (Join-Path $root 'releases')){Remove-Item -LiteralPath $link -Force}}}
   if($reg.registry_key -like 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SceneForge-*' -and(Test-Path $reg.registry_key)){
    if((Get-ItemProperty $reg.registry_key).InstallLocation -eq $root){Remove-Item -LiteralPath $reg.registry_key -Recurse -Force}
   }
  }
  Set-Location ([IO.Path]::GetPathRoot($root))
  [IO.Directory]::SetCurrentDirectory([IO.Path]::GetPathRoot($root))
  foreach($dir in Get-ChildItem -LiteralPath (Join-Path $root 'releases') -Directory){
   $m=Join-Path $dir.FullName 'installation.json'
   if(Test-Path -LiteralPath $m){$owned=Get-Content -LiteralPath $m -Raw|ConvertFrom-Json;if($owned.app_id -eq 'SceneForge' -and $owned.install_root -eq $root){Remove-Item -LiteralPath $dir.FullName -Recurse -Force}}
  }
  if($erase){
   $data=[IO.Path]::GetFullPath($cfg.data_directory).TrimEnd('\')
   if($data.Length -le 3 -or (Under $root $data)){throw 'Thư mục dữ liệu không an toàn để xóa.'}
   Remove-Item -LiteralPath $data -Recurse -Force
   if($cfg.cache_created -and !(Under $cfg.cache_directory $data) -and $cfg.cache_directory -ne $data){Remove-Item -LiteralPath $cfg.cache_directory -Recurse -Force -ErrorAction SilentlyContinue}
  }
  if($env:SCENEFORGE_UNINSTALL_TEST -eq '1'){@{passed=$true;data_deleted=$erase}|ConvertTo-Json|Set-Content -LiteralPath $env:SCENEFORGE_UNINSTALL_RESULT -Encoding UTF8}else{[void][Windows.Forms.MessageBox]::Show('Đã gỡ ứng dụng. '+$(if($erase){'Dữ liệu đã được xóa.'}else{'Dữ liệu của bạn được giữ nguyên.'}),'SceneForge')}
  $form.Close()
 }catch{if($env:SCENEFORGE_UNINSTALL_TEST -eq '1'){@{passed=$false;error="$_"}|ConvertTo-Json|Set-Content -LiteralPath $env:SCENEFORGE_UNINSTALL_RESULT -Encoding UTF8;throw};[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Chưa gỡ xong');$go.Enabled=$true}
}
$go.Add_Click({RemoveApp $delete.Checked})
if($env:SCENEFORGE_UNINSTALL_TEST -eq '1'){RemoveApp $false}else{[void]$form.ShowDialog()}
