using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

// Explicit wide-character Shell APIs preserve Vietnamese link names and target paths.
[ComImport, Guid("00021401-0000-0000-C000-000000000046")]
internal class SceneForgeShellLinkObject { }
[ComImport, Guid("000214F9-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface ISceneForgeShellLinkW {
 void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder path,int length,IntPtr findData,int flags);
 void GetIDList(out IntPtr list);
 void SetIDList(IntPtr list);
 void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder text,int length);
 void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string text);
 void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder path,int length);
 void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string path);
 void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder text,int length);
 void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string text);
 void GetHotkey(out short key);
 void SetHotkey(short key);
 void GetShowCmd(out int command);
 void SetShowCmd(int command);
 void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder path,int length,out int index);
 void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string path,int index);
 void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string path,int reserved);
 void Resolve(IntPtr window,int flags);
 void SetPath([MarshalAs(UnmanagedType.LPWStr)] string path);
}
public static class SceneForgeShortcut {
 public static void Write(string file,string target,string directory,string description) {
  object instance=new SceneForgeShellLinkObject();
  try {
   var link=(ISceneForgeShellLinkW)instance;
   link.SetPath(target);link.SetWorkingDirectory(directory);link.SetDescription(description);link.SetShowCmd(1);
   ((IPersistFile)instance).Save(file,true);
  } finally { Marshal.FinalReleaseComObject(instance); }
 }
 public static string Target(string file) {
  object instance=new SceneForgeShellLinkObject();
  try {
   ((IPersistFile)instance).Load(file,0);
   var path=new StringBuilder(32768);
   ((ISceneForgeShellLinkW)instance).GetPath(path,path.Capacity,IntPtr.Zero,4);
   return path.ToString();
  } finally { Marshal.FinalReleaseComObject(instance); }
 }
}
