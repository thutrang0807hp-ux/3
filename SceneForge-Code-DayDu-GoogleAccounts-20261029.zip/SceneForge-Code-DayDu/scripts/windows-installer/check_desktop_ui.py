"""Exercise the installed native window through WebView2 CDP, including the real source button."""
from pathlib import Path
import json,os,sys,time,subprocess,urllib.request
app=Path(sys.argv[1]);data=Path(sys.argv[2]);port=int(sys.argv[3]);wave=Path(sys.argv[4]);output=Path(sys.argv[5])
sys.path.insert(0,str(app));os.chdir(app)
from paths import configure
configure(app)
from playwright.sync_api import sync_playwright
video=data/'desktop-voice-test.mp4'
subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=180x320:r=12','-i',str(wave),'-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest','-y',str(video)],check=True,creationflags=0x08000000)
# Installed browser launch/cookie transport only. No user account is supplied.
import asyncio
from local_engine.google_login import open_google_login
async def verify_google_login_transport():
 login=await open_google_login('https://gemini.google.com/',data)
 profile=login.profile
 try:
  assert login.connection is None and login.pw is None
  assert '--enable-automation'not in login.process.args
  await login.cookies()
  await login.connection.contexts[0].add_cookies([{'name':'sceneforge_test_session','value':'fixture-not-a-real-account','domain':'.google.com','path':'/','secure':True}])
  assert any(c['name']=='sceneforge_test_session'for c in await login.cookies())
 finally:await login.close()
 assert not profile.exists()and login.process.poll()is not None
 login=await open_google_login('https://labs.google/fx/tools/flow',data)
 profile=login.profile
 assert login.connection is None
 await login.close()
 assert not profile.exists()and login.process.poll()is not None
asyncio.run(verify_google_login_transport())
state=json.loads((data/'desktop-state.json').read_text(encoding='utf-8-sig'));assert state['phase']=='ready'and not state['console']
report={'native_window':True,'browser_container':'WebView2','app_version':state['app_version'],'requests':[],'checks':['installed Chrome/Edge login starts without automation; save reads only synthetic cookie; cancel cleans up'],'real_google_login_verified':False}
# Native startup must leave the configured local Flow API usable, without provider generation.
from local_engine.vault import Vault
import httpx
connection=Vault(data).secret('flow-engine');assert connection
limit=time.monotonic()+90;last=None
while time.monotonic()<limit:
 try:
  response=httpx.get(connection['url']+'/sceneforge/accounts',headers={'Authorization':'Bearer '+connection['key']},timeout=3);response.raise_for_status();inventory=response.json()
  assert inventory['protocol']=='sceneforge-account-pin-v1'and inventory['single_attempt']
  report['flow_engine']={'ready':True,'protocol':inventory['protocol']};break
 except Exception as e:last=str(e);time.sleep(1)
else:raise AssertionError('Flow engine startup failed: '+str(last)+' | '+(data/'flow-startup.log').read_text(encoding='utf-8',errors='replace')[-5000:])
with sync_playwright()as pw:
 browser=pw.chromium.connect_over_cdp('http://127.0.0.1:'+str(port));context=browser.contexts[0]
 deadline=time.monotonic()+60;p=None
 while time.monotonic()<deadline:
  p=next((p for p in context.pages if p.url.startswith(state['url'])),None)
  if p:break
  time.sleep(.2)
 assert p,'Native WebView2 application page missing'
 errors=[];cloud=[];uploads=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 def request(r):
  if r.method=='POST'and'/analysis/local/upload'in r.url:uploads.append(r.url)
  if r.method=='POST'and any(s in r.url for s in ['/gemini-chat/jobs','/flow/jobs','/muse/jobs','/ai/analyze']):cloud.append(r.url)
 p.on('request',request)
 p.wait_for_function('appBootReady&&SceneForgeStorage.state.active',timeout=60000)
 p.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();if(document.querySelector('#shellDialog').open)document.querySelector('#shellDialog').close();const r={id:'desktop-reference',name:'Desktop real button',mode:'reference',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis')}")
 frame=p.locator('#workflowFrame').element_handle().content_frame();frame.wait_for_function('!!window.SFPromptPipeline')
 frame.locator('#sourceFile').set_input_files(str(video))
 frame.wait_for_function('!!project.source&&!project.scenes.length')
 def click_source_and_check(label):
  before=len(uploads)
  # Invoke the actual DOM button and its registered click handler, never the pipeline API.
  frame.locator('#node-source [data-action="analyze"]').evaluate('(button)=>button.click()')
  frame.wait_for_function('!g6PipelineActive&&(!!project.analysis.local||!!project.analysis.pipeline6?.error)',timeout=300000)
  result=frame.evaluate('({steps:project.analysis.pipeline6,local:project.analysis.local,script:project.script,scenes:project.scenes.length})')
  assert not result['steps'].get('error'),result['steps']
  assert len(uploads)>before,(label,'Source button never submitted local CPU job')
  assert 'transcribe=true'in uploads[-1]and'ocr=true'in uploads[-1],uploads[-1]
  measured=result['local']['result'];assert measured['speech']['state']=='transcribed'and result['script'],measured['speech']
  assert any(row.get('words')for row in result['script']),'No actual Whisper word timestamps'
  assert measured['ocr_state']=='sampled'and measured['provider_requests']==0
  assert all(result['steps']['steps'][key]=='done'for key in ['cuts','speech','ocr','camera','quality']),result['steps']
  assert not frame.locator('#node-analysis').inner_text().find('Chưa có bản chép lời')>=0
  report['checks'].append(label);return result
 result=click_source_and_check('fresh video: source button runs real Whisper, OCR, camera and quality measurements')
 report['transcript']=[r['original']for r in result['script']]
 states=frame.evaluate("({frames:SFMediaNodes.slots('frame').map(r=>r.bucket),clips:SFMediaNodes.slots('clip').map(r=>r.bucket)})")
 assert set(states['frames'])=={'source'}and set(states['clips'])=={'blocked'},states
 assert frame.locator('#node-videos .mnPicture img').count()==0
 assert 'xong'not in frame.locator('#node-frames > header').inner_text()
 report['checks'].append('unapproved source frames labelled honestly; Veo waiting slots have no fake video thumbnails')
 # Exact old screenshot state: scenes exist, while local measurements and speech are absent.
 frame.evaluate('async()=>{delete project.analysis.local;delete project.analysis.semantic;delete project.analysis.pipeline6;project.script=[];await storeProject();render()}')
 click_source_and_check('existing cut-only project: same source button completes missing local measurements')
 # A completed measurement without speech must not permanently block later transcription.
 frame.evaluate("async()=>{project.analysis.local.result.speech={state:'not_requested',audio_present:true};project.script=[];await storeProject();render()}")
 click_source_and_check('partial older CPU result: missing speech is filled instead of skipped')
 before=len(uploads);frame.locator('#node-source [data-action="analyze"]').evaluate('(button)=>button.click()');frame.wait_for_function('!g6PipelineActive')
 assert len(uploads)==before,'Completed CPU result was sent again unnecessarily'
 report['checks'].append('repeat click reuses complete measurements; no duplicate CPU job or paid generation')
 # Regression: six real cuts with an audio tail longer than the final picture.
 from PIL import Image
 shots=data/'six-shots';shots.mkdir()
 for i,color in enumerate(['red','blue','green','purple','yellow','black']):Image.new('RGB',(180,320),color).save(shots/('shot-'+str(i)+'.png'))
 segmented=data/'six-shots-audio-tail.mp4'
 subprocess.run(['ffmpeg','-v','error','-framerate','1','-i',str(shots/'shot-%d.png'),'-f','lavfi','-i','sine=frequency=440:duration=6.084','-r','24','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-y',str(segmented)],check=True,creationflags=0x08000000)
 p.evaluate("async()=>{const r={id:'desktop-cuts',name:'Six shots audio tail',mode:'reference',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis')}")
 frame=p.locator('#workflowFrame').element_handle().content_frame();frame.wait_for_function('!!window.SFMediaNodes')
 frame.locator('#sourceFile').set_input_files(str(segmented));frame.wait_for_function('!!project.source&&!project.scenes.length')
 frame.locator('#node-source [data-action="analyze"]').evaluate('(b)=>b.click()')
 try:
  frame.wait_for_function('!g6PipelineActive&&(!!project.analysis.local||project.analysis.pipeline6?.paused||!!project.analysis.pipeline6?.error)',timeout=120000)
 except Exception as timeout:
  diagnostic=frame.evaluate('({pipeline:project.analysis.pipeline6,localJob:project.analysis.localJob,scenes:project.scenes.length})')
  diagnostic['cpu_progress']=[{'job':x.parent.name,'progress':json.loads(x.read_text(encoding='utf-8-sig'))}for x in (data/'cpu-analysis').glob('*/progress.json')]
  diagnostic['cpu_files']=[{'job':x.name,'files':[y.name for y in x.iterdir()]}for x in (data/'cpu-analysis').iterdir()if x.is_dir()]
  raise AssertionError('Six-shot timeout diagnostic: '+json.dumps(diagnostic,ensure_ascii=False))from timeout
 check=frame.evaluate('({pipeline:project.analysis.pipeline6,result:project.analysis.local?.result,scenes:project.scenes.length})')
 assert not check['pipeline'].get('error'),check['pipeline']
 assert check['scenes']==6,check
 assert check['result']['cut_detector']['revision']==3
 assert [round(s['start'],2)for s in check['result']['scenes']]==[0,1,2,3,4,5]
 report['checks'].append('native source button detects six actual shots and completes final-frame sampling when audio outlasts picture')
 api=context.request;headers={'X-SceneForge-Local':'1','Content-Type':'video/mp4'}
 duration=float(json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-of','json',str(video)]))['format']['duration'])
 response=api.post(state['url']+'local-api/export/mp4?fps=30&normalize=false&duration='+str(duration)+'&room_id=desktop-reference',data=video.read_bytes(),headers=headers,timeout=60000);assert response.ok,response.text();rid=response.json()['id'];deadline=time.monotonic()+120
 while time.monotonic()<deadline:
  status=api.get(state['url']+'local-api/export/jobs/'+rid).json()
  if status['state']in ['done','error','cancelled']:break
  time.sleep(.25)
 assert status['state']=='done',status
 rendered=api.get(state['url']+'local-api/export/jobs/'+rid+'/file');assert rendered.ok
 (data/'desktop-export.mp4').write_bytes(rendered.body());report['checks'].append('real MP4 export remains working after small update')
 p.evaluate("async()=>{const r={id:'desktop-photos',name:'Desktop photos',mode:'photos',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis')}")
 f=p.locator('#workflowFrame').element_handle().content_frame();f.wait_for_function('loaded&&!!window.SFPhotoPromptPipeline');report['checks'].append('photo workflow opens in the same native app')
 assert not errors,errors;assert not cloud,cloud
 report['requests']=uploads;report['online_generation_requests']=cloud;report['page_errors']=errors
 # Leave window lifecycle to its owning native process; disconnecting CDP does not close it.
 browser.close()
output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('PASS native WebView2, real source-node button, missing-step recovery, actual ASR/OCR and MP4')
