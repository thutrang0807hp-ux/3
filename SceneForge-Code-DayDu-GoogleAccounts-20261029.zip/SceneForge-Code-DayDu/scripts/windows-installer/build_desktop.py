"""Build the Windows WebView2 host; small redistributable files only, no Python/models."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,urllib.request,zipfile
SDK_VERSION='1.0.3537.50'
SDK_URL=f'https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/{SDK_VERSION}/microsoft.web.webview2.{SDK_VERSION}.nupkg'
RUNTIME_URL='https://go.microsoft.com/fwlink/p/?LinkId=2124703'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True)
 sdk=out/'webview2-sdk.nupkg'
 if not sdk.exists():urllib.request.urlretrieve(SDK_URL,sdk)
 with zipfile.ZipFile(sdk)as z:
  for name in ['Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.WinForms.dll']:
   entry=next(n for n in z.namelist()if n.endswith('/'+name)and'/net462/'in n);(out/name).write_bytes(z.read(entry))
  entry=next(n for n in z.namelist()if n.endswith('/x64/WebView2Loader.dll'));(out/'WebView2Loader.dll').write_bytes(z.read(entry))
  for n in z.namelist():
   if Path(n).name.lower()in ['license.txt','license.md','license']:(out/'WebView2-LICENSE.txt').write_bytes(z.read(n))
 bootstrap=out/'MicrosoftEdgeWebview2Setup.exe'
 if not bootstrap.exists():urllib.request.urlretrieve(RUNTIME_URL,bootstrap)
 compiler=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
 subprocess.run([str(compiler),'/nologo','/target:winexe','/platform:x64','/optimize+',f'/out:{out/"SceneForge.exe"}','/reference:System.Windows.Forms.dll','/reference:System.Drawing.dll','/reference:System.Web.Extensions.dll',f'/reference:{out/"Microsoft.Web.WebView2.Core.dll"}',f'/reference:{out/"Microsoft.Web.WebView2.WinForms.dll"}',str(Path(__file__).with_name('DesktopHost.cs'))],check=True)
 (out/'desktop-components.json').write_text(json.dumps({'sdk':SDK_VERSION,'sdk_url':SDK_URL,'sdk_sha256':digest(sdk),'runtime_bootstrapper_url':RUNTIME_URL,'files':{p.name:digest(p)for p in out.iterdir()if p.suffix.lower()in ['.dll','.exe']}},indent=2),encoding='utf-8')
 sdk.unlink();print('Built native desktop host and WebView2 components')
if __name__=='__main__':main()
