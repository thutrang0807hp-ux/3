"""Actual hosted app, browser/storage/media. Fixture model/account/quality results, no cloud generation."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import tempfile,subprocess,socket,time,os,urllib.request,io,json,base64,hashlib
from PIL import Image
r=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='sf-prompt-pipeline-')as tmp:
 video=Path(tmp)/'clip.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=blue:size=180x320:rate=12:duration=8','-c:v','libx264','-pix_fmt','yuv420p',str(video)],check=True);mp4=video.read_bytes();image=io.BytesIO();Image.new('RGB',(180,320),'blue').save(image,format='PNG');png=image.getvalue();encoded=base64.b64encode(png).decode()
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 proc=subprocess.Popen(['python','-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=r,env={**os.environ,'SCENEFORGE_LOCAL_DATA':tmp+'/data'},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  base=f'http://127.0.0.1:{port}/'
  for _ in range(100):
   try:urllib.request.urlopen(base+'local-api/health',timeout=.2);break
   except OSError:time.sleep(.1)
  with sync_playwright()as pw:
   b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page(viewport={'width':1600,'height':1050});errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.goto(base);p.wait_for_function('appBootReady&&SceneForgeStorage.state.active');p.evaluate('''async()=>{prefs.package5WelcomeDone=true;await savePrefs();document.querySelector('#shellDialog').close();const r={id:'prompt-pipeline-test',name:'Prompt pipeline',mode:'photos',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis');}''');f=p.locator('#workflowFrame').element_handle().content_frame();f.wait_for_function('loaded&&!!window.SFPhotoPromptPipeline');posts=[];jobs={};flags={'unknown':False,'bad_refs':False}
   def route(req):
    path=req.request.url.split('/local-api/')[1]
    if path.endswith('/status'):return req.fulfill(json={'installed':True,'configured':True,'account_binding':True,'models':['fixture-portrait'],'selection':{'available':True,'token':'selected-A','mode':'selected','account_name':'Fixture'}})
    if path=='analysis/frame-check':
     data=req.request.post_data_json;raw=base64.b64decode(data['image'].split(',')[1]);return req.fulfill(json={'can_quick_approve':True,'sha256':hashlib.sha256(raw).hexdigest(),'expected_label':data['expected_label'],'warnings':[]})
    if path.endswith('/jobs'):
     data=req.request.post_data_json;posts.append((path,data));rid=data['request_id']
     if data['kind']=='text':
      context=json.loads(data['prompt'].split('\n',1)[1]);rows=[]
      for beat in context['beats']:
       rows.append({'id':beat['id'],'angle':'Medium shot','movement':'Hold still','visualPrompt':'Use R1 product on a table','motionPrompt':'Slow push toward the product','refRoles':['product'],'partPrompts':{part['id']:{'visualPrompt':'Product on table','motionPrompt':'Slow push toward the product'}for part in beat['parts']}})
      result={'beats':rows}
      jobs[rid]={'state':'unknown'if flags['unknown']else'done','result':{'text':json.dumps(result),'account_id':'fixture'},'store_id':'fixture'}
     else:jobs[rid]={'state':'done','result':{'mime_type':'image/png'if data['kind']=='image'else'video/mp4','account_id':'fixture'},'store_id':'fixture'}
     return req.fulfill(json={'state':'submitted','store_id':'fixture'})
    if '/jobs/'in path:return req.fulfill(json=jobs.get(path.rsplit('/',1)[-1],{'state':'unknown','store_id':'fixture'}))
    if '/files/'in path:
     record=jobs[path.rsplit('/',1)[-1]];clip=record['result'].get('mime_type')=='video/mp4';return req.fulfill(body=mp4 if clip else png,content_type='video/mp4'if clip else'image/png')
    req.continue_()
   p.route('**/local-api/gemini-chat/**',route);p.route('**/local-api/flow/**',route);p.route('**/local-api/analysis/frame-check',route)
   f.evaluate('''async data=>{draft=newDraft();draft.refs={product:{images:[{id:'target',name:'Product',image:'data:image/png;base64,'+data}]},person:{images:[]},background:{images:[]}};draft.idea='Product introduction';draft.voice.mode='native';draft.beats=[0,1].map(i=>({id:'beat-'+i,name:'Cảnh '+(i+1),type:'wide',seconds:4,text:'Xin chào.',clips:[],promptContextVersion:1,promptDirty:'Chưa viết prompt'}));draft.providers={creative:'gemini',video:'flow',flowModel:'fixture-portrait'};draft.flowJobs=[];draft.geminiJobs=[];await save();render();}''',encoded)
   result=f.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("clips",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert 'đủ clip'in result['message'],result
   assert [d['kind']for _,d in posts]==['image','text','video','video'],[(path,d['kind'])for path,d in posts]
   assert f.evaluate('photoDraftCounts().ready')==2
   context=json.loads(posts[1][1]['prompt'].split('\n',1)[1]);assert context['referenceBindings'][0]['code']=='R1'and context['referenceBindings'][-1]['purpose'].startswith('overview')
   before=len(posts);f.evaluate('async()=>SceneForgeWorkflow.workspaceRunAutomatic("clips",SceneForgeWorkflow.workspaceAutoPlan().signature)');assert len(posts)==before
   assert f.locator('#productionPrepareSend,#photoConfirmFlow,#photoSendChat').count()==0
   # Manual directions and stale notes survive attempted regeneration. No cloud request.
   f.evaluate('''async()=>{draft.beats[0].manualDirections=true;draft.beats[0].motionPrompt='My manual motion';photoMarkPromptDirty(['beat-0'],'Lời đã đổi');await save();}''');count=len(posts)
   error=f.evaluate('async()=>{try{await SFPhotoPromptPipeline.run("clips");return null}catch(e){return e.message}}');assert error and len(posts)==count
   assert f.evaluate('draft.beats[0].motionPrompt')=='My manual motion'
   # A fresh per-scene mode creates and binds original start frames without overview pollution.
   f.evaluate('''async data=>{draft=newDraft();draft.refs={product:{images:[{id:'target',name:'Product',image:'data:image/png;base64,'+data}]},person:{images:[]},background:{images:[]}};draft.idea='Frame mode';draft.voice.mode='native';draft.beats=[{id:'frame-beat',name:'Cầm sản phẩm',type:'wide',seconds:4,text:'Xin chào.',clips:[],promptContextVersion:1}];draft.providers={creative:'gemini',video:'flow',flowModel:'fixture-portrait'};draft.flowJobs=[];draft.geminiJobs=[];draft.storyboardPlan={mode:'frames',slots:{}};for(const r of SFStoryboard.slots())r.s.selected=true;await save();render();}''',encoded)
   count=len(posts);result=f.evaluate('async()=>SFPhotoPromptPipeline.run("clips")');assert 'đủ clip'in result['message'],result
   fresh=[d for _,d in posts[count:]];assert [d['kind']for d in fresh]==['image','text','video']
   assert f.evaluate('!photoOverall()&&SFStoryboard.summary().ready===1&&photoDraftCounts().ready===1')
   assert base64.b64decode(fresh[-1]['references'][0]['data'])==png
   assert fresh[0]['prompt'].startswith('IMAGE EDIT CONTRACT v2') and 'R1 for the actual replacement product' in fresh[0]['prompt']
   assert any(r.get('edge')=='start'for r in json.loads(fresh[1]['prompt'].split('\n',1)[1])['referenceBindings'])
   # Default prompt can be retried from the inspector without turning the generated header into authored text.
   count=len(posts)
   f.evaluate('()=>SFStoryboard.inspect(SFStoryboard.slots()[0].id,"start")')
   f.locator('[data-sb="retry"]').click();f.wait_for_selector('#sbSendConfirm')
   f.locator('#sbSendConfirm').click()
   f.wait_for_function('draft.geminiJobs.at(-1).state==="submitted"')
   assert len(posts)==count+1 and posts[-1][1]['kind']=='image'
   assert posts[-1][1]['prompt'].count('IMAGE EDIT CONTRACT v2')==1
   assert not errors,errors;b.close();print('PASS photo one-click: overall PNG -> bound production prompt -> two real MP4 imports without intermediate confirmation; rerun sends zero; manual dirty prompt is preserved and blocks sends; per-scene frame mode binds original generated PNG into motion/video without overview; fixture services only')
 finally:proc.terminate();proc.wait(timeout=10)
