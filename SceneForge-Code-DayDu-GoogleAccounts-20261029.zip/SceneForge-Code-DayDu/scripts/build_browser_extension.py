"""Deterministic, source-only ZIP for one-time manual browser installation."""
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
folder=root/'browser-extension'
with zipfile.ZipFile(root/'browser-extension-package.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for path in sorted(folder.iterdir()):
        if not path.is_file():continue
        item=zipfile.ZipInfo('SceneForge-Browser-Connect/'+path.name,date_time=(2026,10,29,0,0,0))
        item.compress_type=zipfile.ZIP_DEFLATED
        item.external_attr=0o644<<16
        archive.writestr(item,path.read_bytes())
