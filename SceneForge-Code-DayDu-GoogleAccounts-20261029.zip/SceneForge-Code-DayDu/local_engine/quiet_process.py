"""Keep command-line workers invisible only inside the Windows desktop app."""
import os,subprocess

def enable():
 if os.name!='nt' or os.environ.get('SCENEFORGE_DESKTOP')!='1' or getattr(subprocess.Popen,'_sceneforge_no_console',False):return
 original=subprocess.Popen
 class DesktopProcess(original):
  _sceneforge_no_console=True
  def __init__(self,*args,**kwargs):
   if len(args)>13:
    args=list(args);args[13]=int(args[13])|subprocess.CREATE_NO_WINDOW
   else:kwargs['creationflags']=int(kwargs.get('creationflags',0))|subprocess.CREATE_NO_WINDOW
   super().__init__(*args,**kwargs)
 subprocess.Popen=DesktopProcess
