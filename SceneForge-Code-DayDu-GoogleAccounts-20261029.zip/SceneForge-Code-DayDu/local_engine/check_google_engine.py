"""Owned Flow re-import: verify exact identity, preserve limits, refuse active jobs."""
import asyncio,sys,types
from types import SimpleNamespace
import httpx
from fastapi import FastAPI,Header,HTTPException


async def main():
    names=['src','src.core','src.core.auth','src.core.config'];saved={n:sys.modules.get(n)for n in names}
    for n in names:sys.modules[n]=types.ModuleType(n)
    async def auth(authorization:str=Header(default='')):
        if authorization!='Bearer fixture':raise HTTPException(401)
    sys.modules['src.core.auth'].verify_api_key_header=auth
    sys.modules['src.core.config'].config=SimpleNamespace(flow_max_retries=1)
    try:
        from .flow_account_engine import extend
        current=SimpleNamespace(id=7,email='same@fixture.invalid',is_active=True)
        updates=[];resets=[];flags={'duplicate':True,'active':False,'wrong_identity':False}
        class Tokens:
            def __init__(self):self.db=self
            async def get_active_tokens(self):return [current]
            async def add_token(self,**kw):
                if flags['duplicate']:raise ValueError('provider duplicate; never parse this string')
                return SimpleNamespace(id=8)
            async def detect_account_identity(self,cookies):return {'email':'same@fixture.invalid','st':'verified-session','google_cookies':cookies}
            async def get_token_by_email(self,email):
                assert email=='same@fixture.invalid'
                return None if flags['wrong_identity']else current
            async def update_token(self,aid,**kw):updates.append((aid,kw))
        class Limits:
            async def get_image_inflight(self,aid):return int(flags['active'])
            async def get_video_inflight(self,aid):return 0
            async def reset_token(self,aid,**kw):resets.append((aid,kw))
        app=extend(SimpleNamespace(app=FastAPI(),token_manager=Tokens(),concurrency_manager=Limits()))
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app),base_url='http://fixture',headers={'Authorization':'Bearer fixture'})as c:
            data={'cookies':[{'domain':'.google.com','name':'fixture','value':'private-fixture'}]}
            response=await c.post('/sceneforge/accounts',json=data)
            assert response.status_code==200 and response.json()=={'id':7,'existing':True}
            assert updates[0][0]==7 and updates[0][1]['auto_enable_on_update']is False and not resets
            flags['active']=True
            assert(await c.post('/sceneforge/accounts',json=data)).status_code==409 and len(updates)==1
            flags['active']=False;flags['wrong_identity']=True
            assert(await c.post('/sceneforge/accounts',json=data)).status_code==409 and len(updates)==1
            flags['wrong_identity']=False;flags['duplicate']=False
            assert(await c.post('/sceneforge/accounts',json=data)).json()=={'id':8}
            assert resets==[(8,{'image_concurrency':1,'video_concurrency':1})]
        print('PASS owned Flow account import: provider-verified exact duplicate identity, credential refresh preserves existing concurrency and disabled policy, active jobs/unknown identity refuse mutation; new account defaults only. Fixture provider only.')
    finally:
        for n,v in saved.items():
            if v is None:sys.modules.pop(n,None)
            else:sys.modules[n]=v


if __name__=='__main__':asyncio.run(main())
