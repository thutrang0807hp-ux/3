"""Owned account-pinning extension around the pinned Flow2API checkout.

Run with the engine's Python, --source <checkout>. No vendor code is copied.
"""
try:
    from .quiet_process import enable as _quiet_desktop_workers
except ImportError:
    from quiet_process import enable as _quiet_desktop_workers
_quiet_desktop_workers()

import argparse
import asyncio
from contextvars import ContextVar
import json
from pathlib import Path
import sys

PIN = ContextVar('sceneforge_flow_account', default=None)


def extend(engine,journal_path=None):
    from fastapi import Depends, HTTPException
    from src.core.auth import verify_api_key_header
    from src.core.config import config
    original = engine.token_manager.get_active_tokens
    async def scoped_tokens():
        rows = await original()
        selected = PIN.get()
        return rows if selected is None else [r for r in rows if r.id == selected]
    engine.token_manager.get_active_tokens = scoped_tokens

    class PinMiddleware:
        def __init__(self, app):
            self.app = app
        async def __call__(self, scope, receive, send):
            if scope['type'] != 'http' or scope.get('path') != '/v1/chat/completions':
                return await self.app(scope, receive, send)
            headers = dict(scope.get('headers', []))
            raw = headers.get(b'x-sceneforge-account', b'')
            selected = int(raw) if raw.isdigit() else None
            token = PIN.set(selected)
            async def tagged(message):
                if message['type'] == 'http.response.start' and selected is not None:
                    message['headers'] = list(message.get('headers', [])) + [(b'x-sceneforge-account', str(selected).encode())]
                await send(message)
            try:
                await self.app(scope, receive, tagged)
            finally:
                PIN.reset(token)
    engine.app.add_middleware(PinMiddleware)

    if journal_path is None and getattr(getattr(engine,'db',None),'db_path',None):journal_path=Path(engine.db.db_path).with_name('sceneforge-tasks.sqlite')
    journal=None
    if journal_path is not None:
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
        from local_engine.flow_task_journal import install_journal
        journal=install_journal(engine,journal_path)

    @engine.app.get('/sceneforge/accounts')
    async def accounts(key=Depends(verify_api_key_header)):
        rows = await engine.token_manager.get_all_tokens()
        return {'protocol': 'sceneforge-account-pin-v1', 'single_attempt': config.flow_max_retries == 1, 'task_journal':journal is not None,
                'accounts': [{'id': r.id, 'name': r.email or r.name or str(r.id), 'enabled': bool(r.is_active)} for r in rows]}

    @engine.app.post('/sceneforge/accounts')
    async def add(body: dict, key=Depends(verify_api_key_header)):
        cookies = body.get('cookies')
        if not isinstance(cookies, list) or not 1 <= len(cookies) <= 200:
            raise HTTPException(400, 'Cookie list required')
        clean = []
        for c in cookies:
            domain = str(c.get('domain', '')).lstrip('.') if isinstance(c, dict) else ''
            if domain in ('google.com', 'labs.google', 'flow.google.com') or domain.endswith('.google.com') or domain.endswith('.labs.google'):
                if isinstance(c.get('name'), str) and isinstance(c.get('value'), str) and len(c['value']) <= 16000:
                    clean.append(c)
        if not clean:
            raise HTTPException(400, 'No Flow/Google session')
        try:
            try:
                token = await engine.token_manager.add_token(st='', google_cookies=json.dumps(clean),
                            remark='SceneForge', image_concurrency=1, video_concurrency=1, auto_refresh_enabled=False)
            except ValueError:
                # Reconnecting the same browser account must not create a guessed
                # duplicate or select an unrelated sole row. Resolve identity through
                # the provider, then update that exact existing account only.
                identity = await engine.token_manager.detect_account_identity(json.dumps(clean))
                email = identity.get('email')
                if not isinstance(email,str) or not email.strip() or not identity.get('st'):raise ValueError('No verified identity')
                token = await engine.token_manager.db.get_token_by_email(email.strip().lower())
                if token is None or not token.is_active:raise ValueError('Account not eligible')
                if (await engine.concurrency_manager.get_image_inflight(token.id) or await engine.concurrency_manager.get_video_inflight(token.id)):
                    raise ValueError('Account has running work')
                await engine.token_manager.update_token(token.id,st=identity['st'],google_cookies=identity.get('google_cookies') or json.dumps(clean),auto_refresh_enabled=False,auto_enable_on_update=False)
                return {'id':token.id,'existing':True}
            await engine.concurrency_manager.reset_token(token.id, image_concurrency=1, video_concurrency=1)
            return {'id': token.id}
        except Exception:
            raise HTTPException(409, 'Flow session could not be imported; no generation sent') from None

    @engine.app.post('/sceneforge/accounts/{aid}/check')
    async def check(aid: int, key=Depends(verify_api_key_header)):
        row = await engine.token_manager.get_token(aid)
        if row is None or not row.is_active:
            return {'ok': False, 'accepted': False, 'reason': 'auth'}
        try:
            valid = await engine.token_manager.ensure_valid_token(row)
            if not valid:
                return {'ok': False, 'accepted': False, 'reason': 'auth'}
            balance = await engine.token_manager._get_credits_for_token(valid, valid.at)
            credit = balance.get('credits')
            if type(credit) not in (int, float) or credit < 0:
                credit = None
            return {'ok': True, 'credit': credit, 'checked': True}
        except Exception:
            return {'ok': False, 'accepted': None, 'reason': 'unknown'}
    limit_locks = {}
    async def apply_limit(aid, value, kind):
        maximum = 4 if kind == 'image' else 16
        if type(value) is not int or not 1 <= value <= maximum:
            raise HTTPException(400, 'Concurrency out of range')
        async with limit_locks.setdefault(aid, asyncio.Lock()):
            row = await engine.token_manager.get_token(aid)
            if row is None:
                raise HTTPException(404, 'Account not found')
            def setting(name):
                result = getattr(row, name, 1)
                return result if type(result) is int else 1
            image, video = setting('image_concurrency'), setting('video_concurrency')
            current = image if kind == 'image' else video
            # Never replace an in-use engine semaphore just to re-ack an unchanged setting.
            if current != value:
                if await engine.concurrency_manager.get_video_inflight(aid) or await engine.concurrency_manager.get_image_inflight(aid):
                    raise HTTPException(409, 'Account has active work; keep existing limits')
                if kind == 'image': image = value
                else: video = value
                await engine.token_manager.update_token(aid, **{kind + '_concurrency': value})
                await engine.concurrency_manager.reset_token(aid, video_concurrency=video, image_concurrency=image)
            return {'per_account': value, **({'kind':'image'} if kind=='image' else {})}

    @engine.app.post('/sceneforge/accounts/{aid}/concurrency')
    async def concurrency(aid: int, body: dict, key=Depends(verify_api_key_header)):
        return await apply_limit(aid, body.get('per_account'), 'video')

    @engine.app.post('/sceneforge/accounts/{aid}/image-concurrency')
    async def image_concurrency(aid: int, body: dict, key=Depends(verify_api_key_header)):
        return await apply_limit(aid, body.get('per_account'), 'image')

    @engine.app.delete('/sceneforge/accounts/{aid}')
    async def remove(aid: int, key=Depends(verify_api_key_header)):
        if await engine.concurrency_manager.get_video_inflight(aid) or await engine.concurrency_manager.get_image_inflight(aid):
            raise HTTPException(409, 'Account has active work')
        await engine.token_manager.delete_token(aid)
        return {'ok': True}
    return engine.app


def quiet_desktop_startup(engine):
    """Start the local API without opening account browser windows before user action."""
    import os
    if os.environ.get('SCENEFORGE_FLOW_QUIET_START') != '1':return
    from contextlib import asynccontextmanager
    from src.services import browser_captcha_personal as browsers
    original = engine.app.router.lifespan_context
    @asynccontextmanager
    async def lifespan(app):
        saved=[]
        async def no_login(*args, **kwargs):return None
        async def no_warmup(*args, **kwargs):return []
        def restore():
            for cls,name,method in saved:setattr(cls,name,method)
            saved.clear()
        for cls in (browsers.BrowserCaptchaService, getattr(browsers, '_PersonalBrowserPoolService', None)):
            if cls is None:continue
            for name,replacement in [('open_login_window',no_login),('warmup_resident_tabs',no_warmup)]:
                if name in cls.__dict__:
                    saved.append((cls,name,cls.__dict__[name]));setattr(cls,name,replacement)
        try:
            async with original(app):
                restore()  # User-triggered account/generation operations retain the original methods.
                yield
        finally:restore()
    engine.app.router.lifespan_context=lifespan


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.source.resolve()))
    from src import main as engine
    from src.core.config import config
    if config.server_host != '127.0.0.1' or config.flow_max_retries != 1:
        raise SystemExit('Flow requires loopback and max_retries=1 before account-pinned service can start')
    import uvicorn
    quiet_desktop_startup(engine)
    uvicorn.run(extend(engine), host='127.0.0.1', port=config.server_port, access_log=False)
