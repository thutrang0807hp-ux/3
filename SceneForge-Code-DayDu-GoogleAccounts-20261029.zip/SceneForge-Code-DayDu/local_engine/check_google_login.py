"""Real installed-browser lifecycle; no Google credentials or generation calls.

Windows uses installed Chrome/Edge normally. Linux CI uses an explicit local
Chromium shim for headless/root support, not an application login option.
"""
import asyncio
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from local_engine.google_login import open_google_login, installed_browser


async def main():
    with tempfile.TemporaryDirectory(prefix='sf-google-login-check-') as data:
        if os.name != 'nt':
            shim=Path(data)/'chromium-test'
            shim.write_text('#!/bin/sh\nexec /usr/bin/chromium --headless=new --no-sandbox --host-resolver-rules="MAP * ~NOTFOUND" "$@"\n')
            shim.chmod(0o700)
            os.environ['SCENEFORGE_BROWSER']=str(shim)
        executable=installed_browser()
        login=await open_google_login('https://gemini.google.com/',data)
        profile=login.profile
        try:
            assert login.connection is None and login.pw is None,'Automation attached during login'
            assert profile.parent==Path(data)/'login-sessions'
            assert '--enable-automation' not in login.process.args
            assert '--remote-debugging-address=127.0.0.1' in login.process.args
            # First read is the user-confirm/save phase; still no real sign-in.
            await login.cookies()
            await login.connection.contexts[0].add_cookies([{'name':'sceneforge_test_session','value':'fixture-not-a-real-account','domain':'.google.com','path':'/','secure':True}])
            cookies=await login.cookies()
            assert any(c['name']=='sceneforge_test_session'for c in cookies)
        finally:
            await login.close();await login.stop()
        assert not profile.exists() and login.process.poll() is not None
        # Cancel before saving must clean up its browser without reading cookies.
        login=await open_google_login('https://labs.google/fx/tools/flow',data)
        profile=login.profile
        assert login.connection is None
        await login.close()
        assert not profile.exists() and login.process.poll() is not None
        with patch.dict(os.environ,{'SCENEFORGE_BROWSER':''}):
            # Destination validation runs before starting any process.
            try:await open_google_login('https://example.org/',data)
            except ValueError:pass
            else:raise AssertionError('Unexpected destination accepted')
        report={'passed':True,'browser':Path(executable).name,'checks':['installed browser opens without automation attached','dedicated profile; loopback-only debugging','save phase reads synthetic test cookie','close/cancel remove isolated profile and owned browser'],'real_google_login_verified':False,'real_accounts_used':0,'generation_requests':0}
        print(json.dumps(report))
        if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(report,indent=2))


if __name__=='__main__':asyncio.run(main())
