"""Small encrypted conversation cursors, not a prompt/history archive."""
import hashlib


def conversation_key(room_id, account_id):
    digest = hashlib.sha256((room_id + '\0' + account_id).encode()).hexdigest()
    return 'gemini-image-chat:' + digest


def valid_metadata(value):
    # SDK metadata contains cid/rid/rcid plus optional opaque context strings.
    return (isinstance(value, list) and 2 <= len(value) <= 10
            and all(v is None or isinstance(v, str) and len(v) <= 100000 for v in value)
            and isinstance(value[0], str) and value[0].startswith('c_')
            and isinstance(value[1], str) and value[1].startswith('r_'))
