"""Isolated CPU worker. Input paths are created by our job manager, never browser paths."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='2'
os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
import base64,json,math,statistics,subprocess,sys,time
from pathlib import Path
import cv2,numpy as np
from scenedetect import detect,ContentDetector
from .motion import measure_motion
from .speech_guard import classify
from .cpu_checkpoint import Checkpoints
from .proxy_frames import ProxyFrames
cv2.setNumThreads(2)

def analyze(config):
 work=Path(config['work']);fps=config['fps'];duration=config['duration'];start=time.monotonic();checkpoint=Checkpoints(config)
 def progress(value,phase,**extra):
  from .library import atomic_json
  atomic_json(work/'progress.json',{'progress':value,'phase':phase,**extra})
 def command(*args):
  p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
  if p.returncode:raise ValueError('Không đọc được khung/âm thanh từ video.')
  return p.stdout
 proxy=work/'proxy.avi';progress(18,'PySceneDetect · tìm mốc cắt')
 capture=ProxyFrames(proxy);frame_count=capture.count
 if frame_count<duration*fps-3:raise ValueError('Bản đo vượt giới hạn dung lượng hoặc bị cắt cụt; thử video ngắn hơn.')
 cuts=checkpoint.read('cuts')
 if cuts is None:
  pairs=detect(str(proxy),ContentDetector(threshold=config['threshold'],min_scene_len=max(2,round(config['min_scene']*fps))),start_in_scene=True)
  cuts=[0.]+[round(a.get_seconds(),6)for a,b in pairs if a.get_frames()>0]+[duration];cuts=sorted(set(cuts))
  cuts=[t for t in cuts if t==0 or t==duration or .03<t<duration-.03]
  if len(cuts)>101:raise ValueError('Quá 100 cảnh. Tăng ngưỡng hoặc cảnh tối thiểu rồi thử lại.')
  checkpoint.write('cuts',cuts)
 face=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml');scenes=[]
 ocr=None;ocr_state='not_requested';speech_state='not_requested';warnings=[]
 if config['ocr']:
  progress(22,'Nạp RapidOCR trên CPU')
  from rapidocr_onnxruntime import RapidOCR
  ocr=RapidOCR(intra_op_num_threads=2,inter_op_num_threads=1);ocr_state='sampled'
 def read_frame(at):
  return capture.read(round(at*fps))
 def source_frame(at,width):
  # FFmpeg autorotation is used consistently in proxy and original snapshots.
  raw=command('ffmpeg','-v','error','-nostdin','-threads','2','-ss',str(min(max(0,at),max(0,(frame_count-2)/fps))),'-protocol_whitelist','file,pipe','-i',str(work/'source'),'-frames:v','1','-vf',f"scale=w='min({width},iw)':h='min(1024,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2",'-f','image2pipe','-c:v','mjpeg','-threads','2','pipe:1')
  image=cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_COLOR)
  if image is None:raise ValueError('Không lấy được ảnh nguồn.')
  return image
 def data_url(image):
  ok,encoded=cv2.imencode('.jpg',image,[cv2.IMWRITE_JPEG_QUALITY,80])
  if not ok:raise ValueError('Không tạo được ảnh xem trước.')
  return 'data:image/jpeg;base64,'+base64.b64encode(encoded).decode()
 try:
  for index,(a,b)in enumerate(zip(cuts,cuts[1:])):
   progress(25+round(index/max(1,len(cuts)-1)*55),'OpenCV · cảnh '+str(index+1)+'/'+str(len(cuts)-1),completed_scenes=index,total_scenes=len(cuts)-1)
   saved=checkpoint.read('scene-'+str(index))
   if saved is not None:
    if saved.get('start')!=a or saved.get('end')!=b:raise ValueError('Mốc checkpoint khác cảnh hiện tại.')
    scenes.append(saved);continue
   margin=min(1/fps,(b-a)/5);times=[min(t,max(0,(frame_count-2)/fps))for t in [a+margin,(a+b)/2,max(a,b-margin-1/fps)]]
   sample=[read_frame(t)for t in times];gray=[cv2.cvtColor(f,cv2.COLOR_BGR2GRAY)for f in sample]
   brightness=float(statistics.median(float(g.mean())for g in gray));sharpness=float(statistics.median(cv2.Laplacian(g,cv2.CV_64F).var()for g in gray))
   camera=measure_motion(read_frame,a+margin,b-margin,fps);jitter=camera['jitter']
   issues=[]
   if not camera['reliable']:issues.append('Chuyển động máy: không đo chắc; chưa tự điền prompt')
   if brightness<40:issues.append('Khung tối ở các mẫu đã đo')
   if sharpness<35:issues.append('Khung ít chi tiết / có thể mờ')
   if jitter>.15:issues.append('Chuyển động không đều / có thể rung')
   thumbnails=[];evidence_frames=[];ocr_rows=[];faces=[];clean_frame_image=None
   for t,g in zip(times,gray):
    image=source_frame(t,768);evidence_frames.append(data_url(image));thumbnails.append(data_url(cv2.resize(image,(180,max(2,round(image.shape[0]*180/image.shape[1]))))))
    if ocr and abs(t-times[1])<.0001:clean_frame_image=data_url(image)
    detected=face.detectMultiScale(g,scaleFactor=1.1,minNeighbors=5,minSize=(20,20))if not face.empty()else []
    faces.append({'at':round(t,4),'count':len(detected)})
    if ocr:
     result,_=ocr(image)
     for box,text,score in (result or [])[:50]:
      if score<.6:continue
      ih,iw=image.shape[:2];points=[[round(float(x)/iw,5),round(float(y)/ih,5)]for x,y in box]
      ocr_rows.append({'at':round(t,4),'text':text[:500],'confidence':round(float(score),4),'polygon':points})
   scenes.append({'start':a,'end':b,'thumbs':thumbnails,'evidence_frames':evidence_frames,'sample_times':times,'clean_frame_image':clean_frame_image,'camera':camera,'quality':{'brightness_0_255':round(brightness,2),'laplacian_variance_proxy':round(sharpness,2),'motion_variation':round(jitter,4)},'warnings':issues,'faces':{'detected':any(f['count']for f in faces),'samples':faces,'note':'Có mặt ở mẫu không đồng nghĩa đang nói. Không thấy mặt không chứng minh không có người.'},'ocr':ocr_rows})
   checkpoint.write('scene-'+str(index),scenes[-1])
 finally:capture.close()
 transcript=[];language=None
 if config['transcribe']:
  if not config['audio']:speech_state='no_audio'
  else:
   from faster_whisper import WhisperModel
   model=None;chunk_seconds=30;chunks=math.ceil(duration/chunk_seconds)
   for chunk in range(chunks):
    core_start=chunk*chunk_seconds;core_end=min(duration,core_start+chunk_seconds)
    saved=checkpoint.read('audio-'+str(chunk))
    if saved is not None:
     transcript.extend(saved['transcript']);language=language or saved.get('language');continue
    progress(84+round(chunk/max(1,chunks)*14),'Whisper · đoạn '+str(chunk+1)+'/'+str(chunks),completed_scenes=len(scenes),total_scenes=len(scenes),completed_audio=chunk,total_audio=chunks)
    if model is None:model=WhisperModel(str(Path(config['data'])/'models/faster-whisper'),device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,local_files_only=True)
    # Context overlap, but retain words only in this chunk's core interval: no duplicate speech.
    offset=max(0,core_start-.5);until=min(duration,core_end+.5);wav=work/('speech-'+str(chunk)+'.wav')
    command('ffmpeg','-v','error','-nostdin','-ss',str(offset),'-protocol_whitelist','file,pipe','-i',str(work/'source'),'-t',str(until-offset),'-vn','-ac','1','-ar','16000','-y',str(wav))
    segments,info=model.transcribe(str(wav),language=config['language'],word_timestamps=True,beam_size=3,vad_filter=True,condition_on_previous_text=False)
    rows=[];language=language or info.language
    for seg in segments:
     if len(transcript)+len(rows)>=1000:raise ValueError('Quá nhiều đoạn lời; thử video ngắn hơn.')
     words=[{'start':max(core_start,float(w.start)+offset),'end':min(core_end,float(w.end)+offset),'text':w.word[:500],'probability':round(float(w.probability),4)}for w in(seg.words or[])if core_start<=(float(w.start)+float(w.end))/2+offset<core_end]
     words=[w for w in words if w['end']>w['start']]
     if words:text=''.join(w['text']for w in words).strip();begin=words[0]['start'];finish=words[-1]['end']
     elif not seg.words and core_start<=(float(seg.start)+float(seg.end))/2+offset<core_end:text=seg.text.strip();begin=max(core_start,float(seg.start)+offset);finish=min(core_end,float(seg.end)+offset)
     else:continue
     if not text or finish<=begin:continue
     rows.append({'start':begin,'end':finish,'original':text[:5000],'no_speech_prob':float(seg.no_speech_prob),'avg_logprob':float(seg.avg_logprob),'speechReview':classify(text,float(seg.no_speech_prob),float(seg.avg_logprob)),'words':words})
    checkpoint.write('audio-'+str(chunk),{'transcript':rows,'language':info.language});transcript.extend(rows);wav.unlink(missing_ok=True)
   speech_state='transcribed'
 result={'cut_detector':{'name':'PySceneDetect.ContentDetector','revision':3,'threshold':config['threshold'],'min_scene':config['min_scene']},'version':1,'engine':'PySceneDetect + OpenCV + FFmpeg','at':time.time(),'duration':duration,'fps':fps,'width':config['width'],'height':config['height'],'cuts':cuts,'scenes':scenes,'transcript':transcript,'speech':{'state':speech_state,'language':language,'audio_present':config['audio']},'ocr_state':ocr_state,'elapsed_seconds':round(time.monotonic()-start,3),'provider_requests':0,'timing_note':'Mốc trên bản đo CFR tối đa 24 fps; sai số mốc có thể khoảng một khung bản đo. Video VFR có thể lệch; cần rà lại khi xem. Không nhận diện sản phẩm, không viết mô tả/biên dịch bằng CPU.','warnings':warnings}
 from .library import atomic_json
 atomic_json(work/'result.json',result)
 progress(99,'Đã đo xong')
if __name__=='__main__':
 config=json.loads(Path(sys.argv[1]).read_text())
 try:analyze(config)
 except Exception as e:
  message=str(e)if isinstance(e,ValueError)else 'Không nạp/chạy được engine hoặc model CPU. Kiểm tra cài đặt và thử video ngắn hơn.'
  (Path(config['work'])/'error.json').write_text(json.dumps({'error':message}))
  raise SystemExit(1)
