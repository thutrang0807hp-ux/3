"""Original local services for SceneForge. No upstream engine is auto-started."""

from .quiet_process import enable as _quiet_desktop_workers
_quiet_desktop_workers()
