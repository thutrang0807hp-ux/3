"""Bounded sequential FFmpeg proxy reader; no OpenCV random-seek dependency."""
import json
from pathlib import Path
import subprocess

import numpy as np


class ProxyFrames:
    def __init__(self, path):
        self.path = str(Path(path))
        probe = subprocess.run(['ffprobe', '-v', 'error', '-protocol_whitelist', 'file,pipe',
                                '-show_streams', '-of', 'json', self.path],
                               capture_output=True, timeout=20)
        try:
            stream = next(s for s in json.loads(probe.stdout)['streams'] if s['codec_type'] == 'video')
            self.width, self.height = int(stream['width']), int(stream['height'])
            self.count = int(stream['nb_frames'])
            if probe.returncode or not 0 < self.width*self.height <= 480*480 or self.count < 1:
                raise ValueError()
        except (ValueError, KeyError, StopIteration):
            raise ValueError('Không đọc được thông tin bản đo video (bộ đọc FFmpeg v3).') from None
        self.size = self.width*self.height*3
        self.process = None
        self.next_index = 0
        self.last_index = -1
        self.last_frame = None

    def close(self):
        if self.process is not None:
            if self.process.poll() is None:
                self.process.kill()
            self.process.stdout.close()
            self.process.wait(timeout=10)
            self.process = None

    def _start(self):
        self.close()
        self.process = subprocess.Popen(['ffmpeg', '-v', 'error', '-nostdin', '-threads', '2',
            '-protocol_whitelist', 'file,pipe', '-i', self.path, '-map', '0:v:0',
            '-an', '-sn', '-dn', '-pix_fmt', 'bgr24', '-f', 'rawvideo', '-threads', '2', 'pipe:1'],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.next_index = 0

    def read(self, index):
        target = min(self.count-1, max(0, int(index)))
        if target == self.last_index:
            return self.last_frame.copy()
        if self.process is None or target < self.next_index:
            self._start()
        while self.next_index <= target:
            raw = bytearray()
            while len(raw) < self.size:
                block = self.process.stdout.read(self.size-len(raw))
                if not block:
                    failed = self.next_index
                    self.close()
                    raise ValueError('Bộ đọc FFmpeg v3 chưa giải mã được khung '+str(failed+1)+'/'+str(self.count)+'. Đã giữ dữ liệu để tiếp tục; không dùng khung sai thay thế.')
                raw.extend(block)
            self.next_index += 1
        self.last_index = target
        self.last_frame = np.frombuffer(raw, dtype=np.uint8).reshape(self.height, self.width, 3).copy()
        return self.last_frame.copy()
