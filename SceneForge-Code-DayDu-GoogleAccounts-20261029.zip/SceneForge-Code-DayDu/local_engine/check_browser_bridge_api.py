"""App authentication and pairing transport; SDK check is a fixture, no generation."""
import json
import os
from pathlib import Path
import tempfile
import time
from fastapi.testclient import TestClient


def main():
    with tempfile.TemporaryDirectory(prefix='sf-pair-api-')as data:
        os.environ['SCENEFORGE_LOCAL_DATA']=data
        from . import server
        bridge=server.BROWSER_BRIDGE;calls=[];secret='fixture-cookie-not-a-user-session'
        async def runner(body):
            assert body['operation']=='check';calls.append(body['operation'])
            return {'ok':True,'session':body['session'],'models':[]}
        server.GEMINI_CHAT.runner=runner
        with TestClient(server.app)as c:
            c.get('/');local={'X-SceneForge-Local':'1'};wire={'Origin':bridge.origin,'X-SceneForge-Bridge':'1'}
            def issue():
                r=c.post('/local-api/browser-bridge/pairs',headers=local,json={'service':'gemini_chat','name':'Fixture'});assert r.status_code==200,r.text;return r.json()
            pair=issue()
            assert c.post('/local-api/browser-bridge/claim',headers={**wire,'Origin':'https://evil.example'},json={'code':pair['code']}).status_code==403
            assert c.post('/local-api/browser-bridge/pairs',headers={**wire,**local},json={'service':'flow','name':'x'}).status_code==403
            assert c.get('/local-api/status',headers={'Origin':bridge.origin}).status_code==403
            claim=c.post('/local-api/browser-bridge/claim',headers=wire,json={'code':pair['code']});assert claim.status_code==200,claim.text
            assert claim.headers['access-control-allow-origin']==bridge.origin
            payload={'code':pair['code'],'submission':claim.json()['submission'],'cookies':[{'domain':'.google.com','path':'/','name':'__Secure-1PSID','value':secret}]}
            response=c.post('/local-api/browser-bridge/complete',headers=wire,json=payload);assert response.status_code==200,response.text
            for _ in range(50):
                status=c.get('/local-api/browser-bridge/pairs/'+pair['id']).json()
                if status['state']=='done':break
                time.sleep(.02)
            assert status['state']=='done',status
            assert calls==['check']
            assert c.post('/local-api/browser-bridge/complete',headers=wire,json=payload).status_code==409
            assert secret not in c.get('/local-api/status').text
            assert secret not in json.dumps(status)
            assert secret.encode()not in (Path(data)/'vault.sqlite').read_bytes()
            pair=issue();bridge.pairs[pair['id']]['expires_at']=time.time()-1
            assert c.post('/local-api/browser-bridge/claim',headers=wire,json={'code':pair['code']}).status_code==410
            pair=issue();claim=c.post('/local-api/browser-bridge/claim',headers=wire,json={'code':pair['code']}).json()
            payload.update(code=pair['code'],submission=claim['submission']);payload['cookies'][0]['domain']='.evil.example'
            assert c.post('/local-api/browser-bridge/complete',headers=wire,json=payload).status_code==400
            assert c.post('/local-api/browser-bridge/complete',headers=wire,content=b'x'*131073).status_code==413
            c.post('/local-api/browser-bridge/pairs/'+pair['id']+'/cancel',headers=local,json={})
            assert c.post('/local-api/browser-bridge/claim',headers=wire,json={'code':pair['code']}).status_code==404
            assert calls==['check']
            assert secret not in (Path(data)/'logs/runtime.log').read_text()
        print('PASS real app pairing routes, one-use code, origin isolation, encrypted vault, expiry/cancel/replay/domain/body-size guards; one fixture SDK check, no generation or real accounts.')


if __name__=='__main__':main()
