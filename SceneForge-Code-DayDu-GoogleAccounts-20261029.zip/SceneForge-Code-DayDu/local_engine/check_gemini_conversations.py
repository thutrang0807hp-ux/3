"""Real adapter/vault/ledger with synthetic SDK transport; no Google calls."""
import asyncio
import tempfile
import uuid
from pathlib import Path
from PIL import Image
from .gemini_chat import GeminiChat
from .gemini_conversations import conversation_key
from .vault import Vault
from .request_ledger import RequestLedger


async def main():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); vault = Vault(root / 'vault'); ledger = RequestLedger(root)
        calls = []; active = {}; highest = {}; behavior = {}; turns = {}
        async def runner(body):
            if body['operation'] == 'check':
                return {'ok': True, 'session': body['session'], 'models': []}
            cursor = body.get('conversation', {}).get('metadata')
            name = body['prompt']; room = name.split(':')[0]
            calls.append((name, cursor, body.get('conversation')))
            active[room] = active.get(room, 0) + 1
            highest[room] = max(highest.get(room, 0), active[room])
            await asyncio.sleep(.03)
            active[room] -= 1
            if behavior.get(room) == 'unknown':
                return {'ok': False, 'accepted': None, 'reason': 'unknown'}
            if behavior.get(room) == 'quota':
                return {'ok': False, 'accepted': False, 'reason': 'quota'}
            if body['kind'] == 'text':
                return {'ok': True, 'text': 'fixture text'}
            turns[room] = turns.get(room, 0) + 1
            cid = cursor[0] if cursor else 'c_' + uuid.uuid4().hex
            Image.new('RGB', (20, 30), 'blue').save(body['output'], format='PNG')
            return {'ok': True, 'conversation': {'metadata': [cid, 'r_' + str(turns[room]), 'rc_fixture']}}
        app = GeminiChat(vault, root, ledger, runner)
        account = await app.import_session('Fixture', [{'domain': '.google.com', 'name': '__Secure-1PSID', 'value': 'synthetic'}])
        aid = account['id']
        async def send(room, suffix, kind='image', adapter=None):
            engine = adapter or app
            rid = 'gchat-' + str(uuid.uuid4())
            await engine.submit({'request_id': rid, 'kind': kind, 'role': 'image' if kind == 'image' else 'writing',
                'prompt': room + ':' + suffix, 'references': [], 'room_id': room, 'scene_id': suffix,
                'confirm_send': True, 'selection_token': engine.selection()['token']})
            return rid
        ids = [await send('project-A', str(i)) for i in range(3)]
        await asyncio.gather(*list(app.tasks.values()))
        assert all(app.lookup(i)['state'] == 'done' for i in ids)
        assert highest['project-A'] == 1
        rows = [r for r in calls if r[0].startswith('project-A:')]
        assert rows[0][1] is None and rows[1][1][1] == 'r_1' and rows[2][1][1] == 'r_2'
        cid = rows[1][1][0]
        # Recreating adapter simulates application restart, restoring only the tiny encrypted cursor.
        restarted = GeminiChat(vault, root, ledger, runner)
        rid = await send('project-A', 'restart', adapter=restarted)
        await asyncio.gather(*list(restarted.tasks.values()))
        assert restarted.lookup(rid)['state'] == 'done' and calls[-1][1][0] == cid
        rid = await send('project-B', 'first'); await asyncio.gather(*list(app.tasks.values()))
        assert calls[-1][1] is None
        # Analysis/writing never enters or changes the image conversation.
        old = vault.secret(conversation_key('project-A', aid))
        rid = await send('project-A', 'writer', kind='text'); await asyncio.gather(*list(app.tasks.values()))
        assert calls[-1][2] is None and vault.secret(conversation_key('project-A', aid)) == old
        behavior['uncertain'] = 'unknown'
        rid = await send('uncertain', 'first'); await asyncio.gather(*list(app.tasks.values()))
        assert app.lookup(rid)['state'] == 'unknown'
        before = len(calls)
        rid = await send('uncertain', 'second'); await asyncio.gather(*list(app.tasks.values()))
        assert len(calls) == before and app.lookup(rid)['state'] == 'failed'
        assert ledger.metadata(rid)['last_error_code'] == 'CHAT_TURN_UNRESOLVED'
        # A process interrupted mid-send is equally guarded after restart.
        vault.set_secret(conversation_key('interrupted', aid), {'state': 'in_flight', 'request_id': 'old'})
        rid = await send('interrupted', 'new'); await asyncio.gather(*list(app.tasks.values()))
        assert len(calls) == before and app.lookup(rid)['state'] == 'failed'
        # Account identity is part of the key; no cursor can leak into another account.
        assert conversation_key('project-A', aid) != conversation_key('project-A', 'other-account')
        assert cid.encode() not in vault.path.read_bytes()
        assert all('metadata' not in str(app.lookup(i).get('result', {})) for i in ids)
    print('PASS project image chats: queued same-project turns, cursor restart persistence, project/account isolation, stateless writing, encrypted metadata, uncertain/interrupted turns block new sends. Synthetic SDK, zero generation calls to Google.')


if __name__ == '__main__':
    asyncio.run(main())
