"""Chromium account/settings, storyboard and translation with service fixtures."""
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from pathlib import Path
import base64,io,json
from PIL import Image
from playwright.sync_api import sync_playwright

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass

def main():
    root=Path(__file__).resolve().parents[1]
    image=io.BytesIO();Image.new('RGB',(90,160),'#a95565').save(image,format='PNG');raw=image.getvalue()
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
    state={'accounts':[],'mode':'selected','active':None,'source':'gemini_chat','roles':{},'jobs':{},'story':[],'posts':[],'flow_slots':1}
    def selection():return {'mode':state['mode'],'account_id':state['active'],'account_name':next((a['name']for a in state['accounts']if a['id']==state['active']),None),'available':bool(state['accounts']),'token':json.dumps([state['mode'],state['active'],state['roles']],sort_keys=True)}
    def chat_status():return {'installed':True,'configured':bool(state['accounts']),'accounts':state['accounts'],'selection':selection(),'roles':state['roles'],'generation_verified':False}
    def route(r):
        path=r.request.url.split('/local-api/')[1];body=r.request.post_data_json if r.request.method=='POST'else{}
        if path=='status':data={'accounts':state['accounts'],'logs':[],'rotation':{'gemini_chat':state['mode']!='selected'},'engines':{'gemini_chat':{**chat_status(),'generation':False},'flow':{'adapter':True,'per_account':state['flow_slots']}},'ai_source':state['source'],'ai_configured':bool(state['accounts']),'tts':{}}
        elif path=='system':data={'engines':[],'disk':{'free':10*1024**3}}
        elif path=='logs':data=[]
        elif path=='gemini-chat/status':data=chat_status()
        elif path=='browser-bridge/setup':data={'folder':'Fixture extension folder','download':'/fixture-extension.zip'}
        elif path=='browser-bridge/pairs':
            aid='account-'+str(len(state['accounts'])+1)
            state['accounts'].append({'id':aid,'service':'gemini_chat','name':body['name'],'active':not state['accounts'],'enabled':True,'session_verified':True,'state':'ready','priority':len(state['accounts']),'models':[{'id':'fixture-model','name':'Fixture'}]})
            state['active']=state['active']or aid;data={'id':aid,'code':str(len(state['accounts'])).zfill(8),'state':'issued','message':'Fixture extension transfer'}
        elif path.startswith('browser-bridge/pairs/'):
            data={'id':path.split('/')[2],'state':'done','message':'Fixture extension completed'}
        elif path=='gemini-chat/selection':state['mode']=body['mode'];state['active']=body.get('account_id')or state['active'];data={'selection':selection()}
        elif path=='gemini-chat/roles':state['roles']=body;data={'roles':body}
        elif path=='flow/concurrency':state['flow_slots']=body['per_account'];data={'per_account':state['flow_slots']}
        elif path=='ai/routing':state['source']=body.get('source',state['source']);data={'source':state['source']}
        elif path=='gemini-chat/jobs':
            assert body['selection_token']==selection()['token']and body['confirm_send']is True
            state['posts'].append(body)
            state['jobs'][body['request_id']]={'state':'done','result':{'kind':body['kind'],'text':json.dumps({'beats':state['story']}),'mime_type':'image/png','file':body['request_id']+'.png','account_id':state['active']}}
            data={'state':'submitted','request_id':body['request_id']}
        elif path.startswith('gemini-chat/jobs/'):data=state['jobs'][path.split('/')[-1]]
        elif path.startswith('gemini-chat/files/'):return r.fulfill(body=raw,content_type='image/png')
        elif path=='gemini-chat/translate':data={'lines':[{'id':l['id'],'translation':'Xin chào'}for l in body['lines']]}
        else:data={}
        r.fulfill(json=data)
    try:
        with sync_playwright()as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page(viewport={'width':1600,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.route('**/local-api/**',route)
            page.goto(f'http://127.0.0.1:{server.server_port}/');page.wait_for_function('SceneForgeApp.getState().products.length>0');page.evaluate("accountScreen('gemini_chat')")
            for n in(1,2):
                page.locator('#connectAccount').click();page.locator('#bridgeName').fill('Gemini '+str(n));page.locator('#bridgeCreate').click();page.locator('#connectAccount').wait_for()
            page.locator('#accountDispatchMode').select_option('failover');page.wait_for_function('document.querySelector("#accountDispatchMode").value==="failover"');assert state['mode']=='failover'and state['active']=='account-1'
            page.evaluate("g5OpenSettings('ai')");page.locator('#aiRouteSource').wait_for();assert page.locator('#aiRouteSource').input_value()=='gemini_chat';page.locator('[data-gchat-role=writing]').evaluate("el=>{for(let d=el.closest('details');d;d=d.parentElement.closest('details'))d.open=true;}");page.locator('[data-gchat-role=writing]').select_option('fixture-model');page.locator('#saveGchatRoles').click();page.wait_for_timeout(100);assert state['roles']['writing']=='fixture-model'
            page.evaluate("accountScreen('flow')");page.locator('#videoPerAccount').wait_for();page.locator('#videoPerAccount').fill('12');page.locator('#saveVideoConcurrency').click();page.wait_for_function('document.querySelector("#videoPerAccount").value==="12"');assert state['flow_slots']==12
            page.goto(f'http://127.0.0.1:{server.server_port}/photos.html')
            product_image='data:image/png;base64,'+base64.b64encode(raw).decode()
            state['story']=page.evaluate('''async image=>{window.fixtureFiles=new Map();window.SceneForgeApp={photoBridge:{listRecipes:async()=>[],saveDraft:async()=>{},getFile:async k=>fixtureFiles.get(k),putFile:async(k,f)=>fixtureFiles.set(k,f),engine:async(path,body)=>{const r=await fetch('/local-api/'+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json','X-SceneForge-Local':'1'},body:body===undefined?undefined:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.detail);return d;}}};const refs=Object.fromEntries(['product','person','outfit','background'].map(k=>[k,{description:'',images:[]}]));refs.product.images=[{id:crypto.randomUUID(),name:'product.png',image}];await SceneForgeWorkflow.openRoom({id:'room-chat',name:'Chat fixture',product:{id:'product-chat',name:'Son',sceneBank:[]},refs});draft.beats=draft.beats.slice(0,1);draft.beats[0].text='Lời gốc';render();return draft.beats.map(b=>({id:b.id,seconds:b.seconds,text:b.text,type:'detail',angle:'Cận cảnh',movement:'Đẩy máy nhẹ',visualPrompt:'Fixture product on table',motionPrompt:'Slow push in',refRoles:['product']}));}''',product_image)
            page.locator('#photoAllPrompts').click();page.locator('#photoSendChat').wait_for();assert not state['posts'];page.locator('#photoSendChat').click();page.wait_for_function('draft.geminiJobs[0].state==="submitted"');page.locator('#photoRecoverChat').click();page.locator('#photoApplyChat').wait_for();page.locator('#photoApplyChat').click();page.wait_for_function('draft.beats[0].visualPrompt==="Fixture product on table"')
            page.locator('#photoOverallStory').click();page.get_by_role('button',name='Tạo storyboard bằng Gemini Chat',exact=True).click();page.locator('#photoSendChat').click();page.wait_for_function('draft.geminiJobs.length===2&&draft.geminiJobs[1].state==="submitted"');page.locator('#photoRecoverChat').click();page.wait_for_function('draft.storyboardImages.length===1');assert page.evaluate('draft.storyboardImages[0].origin')=='gemini-chat'
            page.locator('#photoAllPrompts').click();page.locator('#photoSendChat').wait_for();assert '2 ảnh tham khảo' in page.locator('#photoDialogBody').inner_text();page.evaluate("document.querySelector('#photoDialog').close()")
            page.screenshot(path='/tmp/sceneforge-gemini-chat-fixture.png')
            page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html');page.wait_for_function('!!window.SceneForgeWorkflow')
            page.evaluate("()=>{project.script=[{id:'line-chat',start:0,end:2,original:'你好',translation:'',newText:'Lời tự sửa'}];actions['chat-translate']();}")
            page.locator('#prepareChatTranslation').click();page.locator('#autoChatTranslation').click();page.locator('#applyChatTranslation').wait_for();page.locator('#applyChatTranslation').click();assert page.evaluate("project.script[0].translation==='Xin chào'&&project.script[0].original==='你好'&&project.script[0].newText==='Lời tự sửa'&&project.script[0].start===0&&project.script[0].end===2")
            assert not errors,errors;browser.close()
            print('PASS: Chromium multi-account Chat settings and failover mode, role model selection, reviewed prompt job, storyboard image receipt, storyboard+product attachments, translation review preserving source/timing/manual text. Service fixtures only.')
    finally:server.shutdown()

if __name__=='__main__':main()
