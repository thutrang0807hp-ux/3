"""Automatic analysis UI pauses/resumes same CPU job, without uploading or calling Gemini again."""
import hashlib,json,base64,io
from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from threading import Thread
from PIL import Image
from playwright.sync_api import sync_playwright

def main():
 root=Path(__file__).resolve().parents[1];data=b'cpu-source-fixture';out=io.BytesIO();Image.new('RGB',(90,160),'navy').save(out,format='PNG');image='data:image/png;base64,'+base64.b64encode(out.getvalue()).decode()
 scene={'start':0,'end':2,'thumbs':[image]*3,'evidence_frames':[image]*3,'sample_times':[.05,1,1.95],'camera':{'kind':'static','reliable':True,'labels':['máy đứng yên'],'note':'fixture'},'warnings':[],'quality':{'brightness_0_255':60,'laplacian_variance_proxy':80,'motion_variation':0},'faces':{'detected':False,'samples':[],'note':'fixture'},'ocr':[]}
 result={'cut_detector':{'name':'PySceneDetect.ContentDetector','revision':3},'scenes':[scene],'transcript':[],'cuts':[0,2],'source_sha256':hashlib.sha256(data).hexdigest(),'speech':{'state':'not_requested','audio_present':False},'ocr_state':'not_requested','elapsed_seconds':1}
 class Quiet(SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root/'dist/web-demo')));Thread(target=server.serve_forever,daemon=True).start()
 counts={'upload':0,'resume':0,'other_post':0};resumed=False
 def route(r):
  nonlocal resumed
  path=r.request.url.split('/local-api/')[1]
  if path=='analysis/local/capabilities':return r.fulfill(json={'available':True,'max_bytes':500*1024**2,'max_seconds':600,'binary_upload':True,'whisper':False,'whisper_model':False,'ocr':False})
  if path.startswith('analysis/local/upload'):
   counts['upload']+=1;return r.fulfill(json={'id':'cpu-fixture','state':'queued','room_id':'cpu-pipeline'})
  if path=='analysis/local/jobs/cpu-fixture/resume':
   assert r.request.post_data_json['confirm']is True;counts['resume']+=1;resumed=True;return r.fulfill(json={'id':'cpu-fixture','state':'queued','room_id':'cpu-pipeline'})
  if path=='analysis/local/jobs/cpu-fixture':return r.fulfill(json={'id':'cpu-fixture','state':'done'if resumed else'paused','room_id':'cpu-pipeline','resumable':not resumed,'completed_scenes':1,'total_scenes':1,'result':result if resumed else None})
  if r.request.method=='POST':counts['other_post']+=1
  return r.fulfill(status=200,json={})
 try:
  with sync_playwright()as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();page.route('**/local-api/**',route);page.goto(f'http://127.0.0.1:{server.server_port}/workflow.html?room=cpu-pipeline');page.wait_for_function('!!window.SceneForgeWorkflow&&typeof g6AnalyzePipeline==="function"')
   page.evaluate('''async image=>{const file=new Blob(['cpu-source-fixture'],{type:'video/mp4'});project.source={asset:putAsset(file),name:'fixture.mp4',poster:image,width:90,height:160,duration:2};await g6AnalyzePipeline();}''',image)
   assert page.evaluate('project.analysis.pipeline6.paused&&project.analysis.localJob.resumable')
   page.evaluate("project.analysis.local={source:project.source.asset,result:{cut_detector:{revision:2},speech:{state:'no_audio',audio_present:false},ocr_state:'not_requested'}}")
   page.locator('#node-source [data-action="analyze"]').evaluate('(b)=>b.click()');page.wait_for_function('project.analysis.pipeline6.steps.cuts==="done"&&!g6PipelineActive',timeout=30000)
   assert page.evaluate('project.scenes.length')==1
   assert counts=={'upload':1,'resume':1,'other_post':0},counts
   browser.close()
  print('PASS automatic CPU UI: paused job shown as resumable, explicit resume reuses original job/source upload, validates source hash, applies completed result and stops before Gemini. Service fixture; zero generation posts.')
 finally:server.shutdown()
if __name__=='__main__':main()
