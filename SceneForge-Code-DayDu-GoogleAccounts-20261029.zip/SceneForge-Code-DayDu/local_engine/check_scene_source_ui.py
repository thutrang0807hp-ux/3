"""Real local backend and DOM clicks; optional user source stays on this machine."""
import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

from playwright.sync_api import sync_playwright


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    report={'checks':[], 'source':args.source.name, 'online_generation_requests':[]}
    with tempfile.TemporaryDirectory(prefix='sf-scene-source-') as data:
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        log=open(Path(data)/'backend.log','w+')
        proc=subprocess.Popen([sys.executable,'-m','uvicorn','local_engine.server:app','--host','127.0.0.1','--port',str(port),'--log-level','warning'],cwd=root,env={**os.environ,'SCENEFORGE_LOCAL_DATA':data},stdout=log,stderr=log)
        try:
            base='http://127.0.0.1:'+str(port)
            for _ in range(150):
                try:urllib.request.urlopen(base+'/local-api/health',timeout=.3);break
                except OSError:time.sleep(.2)
            else:
                log.seek(0);raise AssertionError(log.read())
            with sync_playwright() as pw:
                browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page(viewport={'width':1600,'height':1000})
                errors=[];uploads=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                def request(r):
                    if r.method=='POST' and '/analysis/local/upload' in r.url:uploads.append(r.url)
                    if r.method=='POST' and any(x in r.url for x in ['/gemini-chat/jobs','/flow/jobs','/ai/analyze']):report['online_generation_requests'].append(r.url)
                page.on('request',request)
                page.goto(base)
                page.wait_for_function('appBootReady&&SceneForgeStorage.state.active')
                page.evaluate("async()=>{prefs.package5WelcomeDone=true;await savePrefs();if(document.querySelector('#shellDialog').open)document.querySelector('#shellDialog').close();const r={id:'source-review',name:'Source review',mode:'reference',stage:'review',productId:products[0].id};rooms.push(r);await persistRoom(r);await openRoom(r.id,'analysis')}")
                frame=page.locator('#workflowFrame').element_handle().content_frame()
                frame.wait_for_function('!!window.SFMediaNodes')
                frame.locator('#sourceFile').set_input_files(str(args.source))
                frame.wait_for_function('!!project.source&&!project.scenes.length')
                def click_and_wait():
                    before=len(uploads)
                    frame.locator('#node-source [data-action="analyze"]').evaluate('(b)=>b.click()')
                    frame.wait_for_function('!g6PipelineActive&&(!!project.analysis.local||!!project.analysis.pipeline6?.error||project.analysis.pipeline6?.paused)',timeout=300000)
                    result=frame.evaluate('({pipeline:project.analysis.pipeline6,local:project.analysis.local,scenes:project.scenes.map(s=>({start:s.start,end:s.end,approved:frameApproved(s)}))})')
                    assert not result['pipeline'].get('error'),result['pipeline']
                    assert len(uploads)==before+1,uploads
                    assert len(result['scenes'])==6,result['scenes']
                    assert [round(s['start'],2) for s in result['scenes']]==[0,8,16,24,32,40],result['scenes']
                    assert result['local']['result']['cut_detector']['name']=='PySceneDetect.ContentDetector'
                    return result
                result=click_and_wait()
                report['scenes']=result['scenes'];report['checks'].append('actual source-node click detects six shots on uploaded 48-second source')
                # Source frames are available for review, not generated or approved.
                states=frame.evaluate("({frames:SFMediaNodes.slots('frame').map(r=>r.bucket),clips:SFMediaNodes.slots('clip').map(r=>r.bucket)})")
                assert set(states['frames'])=={'source'},states
                assert set(states['clips'])=={'blocked'},states
                assert frame.locator('#node-videos .mnPicture img').count()==0
                assert 'khung gốc chưa duyệt' in frame.locator('#node-frames > header').inner_text()
                assert 'xong' not in frame.locator('#node-frames > header').inner_text()
                # Even a stale action must stop before provider preflight or POST.
                frame.locator('#node-videos').evaluate("n=>{const b=document.createElement('button');b.dataset.mn='retry-one';b.dataset.kind='clip';b.dataset.id=project.scenes[0].id;b.dataset.part=clipParts(project.scenes[0])[0].id;n.append(b);b.click();b.remove()}")
                page.wait_for_timeout(150)
                assert not report['online_generation_requests']
                report['checks'].append('source frames labelled unapproved; blocked Veo slots have no fake video thumbnails; stale retry cannot submit')
                # Old measurements with missing provenance cannot suppress a new CPU cut.
                frame.evaluate("async()=>{const r=project.analysis.local.result;delete r.cut_detector;r.cuts=[0,project.source.duration];r.scenes=[{...r.scenes[0],start:0,end:project.source.duration}];project.scenes=[sceneRecord(0,project.source.duration,0,project.scenes[0].thumbs)];project.analysis.cuts=[0,project.source.duration];await storeProject();render()}")
                click_and_wait();report['checks'].append('old one-scene local result is remeasured and replaced with six scenes')
                before=len(uploads)
                frame.locator('#node-source [data-action="analyze"]').evaluate('(b)=>b.click()')
                frame.wait_for_function('!g6PipelineActive')
                assert len(uploads)==before
                report['checks'].append('repeat click reuses verified result without duplicate job')
                # Explicit recut must run CPU and apply cuts, rather than opening a separate unapplied result.
                frame.locator('[data-nd="cuts"]').evaluate('(b)=>b.click()')
                frame.locator('[data-nd="detect"][data-id="27"]').click()
                frame.wait_for_function('!g6PipelineActive&&project.scenes.length===6',timeout=300000)
                assert len(uploads)==before+1
                report['checks'].append('scene-node re-detect uses CPU and applies six boundaries')
                assert not errors,errors
                assert not report['online_generation_requests']
                report['page_errors']=errors;report['passed']=True
                args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2))
                browser.close()
                print(json.dumps(report,ensure_ascii=False))
        finally:
            proc.terminate()
            try:proc.wait(timeout=20)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            log.close()


if __name__=='__main__':main()
