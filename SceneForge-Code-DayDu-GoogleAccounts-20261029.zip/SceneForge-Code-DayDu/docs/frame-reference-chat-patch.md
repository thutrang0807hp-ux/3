# Frame references and project Gemini image conversations — 29/10/2026

Patch version: 2026.10.29.5, applied to the existing verified Windows v2 baseline (including v1–v4 updates). No model/runtime replacement, no new nodes, no changes to stored project images or approved choices.

## Confirmed defect and change

The node create/retry path called `directDialog` directly. It could send the original analysis prompt plus a generic `CONNECTED REFERENCES` suffix without the replacement-aware prompt writer used by the automatic pipeline. A source description such as “young man” could therefore conflict with the connected female identity/outfit/product images.

Both paths now prepare the same version-2 prompt contract before image dispatch. Current role bindings are explicit, numbered in exact attachment order, with the primary face first within the person role. R1 supplies source composition/pose, not replacement identity. The Gemini writing input excludes replaced person/product/background fields; outfit replacement also removes the source person field. The image request explicitly replaces connected identities, rejects collage/inset output, and resolves roles from this request rather than older chat turns. Prompt preparation is refreshed after input changes; no heuristic claims to recognize a face or prove a generated replacement succeeded.

User-authored scene text remains authoritative and is not overwritten. Generated binding headers are rebuilt rather than accumulated into manual text. Editing upstream references after a tracked manual edit preserves it and uses the existing Keep/Rewrite decision. Existing old results and jobs are retained; unmatched in-flight results are not silently applied to new inputs.

The photo workflow's individual storyboard frames use the same explicit role instructions and exact existing attachment order, including the selected start frame for an end-frame request. The optional overview remains a separate contact-sheet workflow; it is not sent through the single-frame instruction.

## Project chat behavior

Image requests with a room ID use `GeminiClient.start_chat` / `ChatSession.send_message`. Only the small cid/rid/rcid/context cursor is stored in the encrypted vault, keyed by project and account. No new prompt history archive or quality-scoring database. Existing request receipts remain unchanged. Analysis and JSON prompt-writing requests remain stateless so they cannot mix JSON and image turns.

Image turns in one project are serialized even if account image concurrency is configured above one. Different projects retain existing admission limits. Different accounts never share cursors. New chats start on the first v5 image request; old chats made by earlier versions cannot be automatically identified retroactively. Restart restores a completed cursor. If an image turn is interrupted or its delivery is uncertain, the project/account cursor blocks further sends rather than silently replaying a turn or creating a new conversation. An unresolved cursor currently requires investigation of the existing task; no automatic reset/retry is provided.

## Verification and limits

- Actual browser app fixtures cover one-click reference and photo flows, node retry -> writer -> image, attachment byte equality/order (different face/outfit files), primary face ordering, removal of source person text from writer input, manual preservation and changed-reference protection.
- Actual adapter/vault/ledger fixtures cover serial turns, restart persistence, project/account separation, stateless writing, encrypted cursors and interrupted/uncertain-turn guards.
- Actual pinned SDK `ChatSession` is exercised with fake transport, including cursor restore and generated-image saving; zero real Google generation in these tests.
- Windows release gate repeats adapter and actual installed SDK checks, native WebView2 startup, update preservation, original CPU/speech/export tests, extension authentication transport, close and uninstall behavior.

These checks prove data routing and lifecycle, not that Gemini visually follows every identity or product detail. The user's real Scene 2 must still be reviewed after generating a new image. No automatic visual-face or product correctness certificate is claimed. Account connection through the previous extension remains unchanged.
