# SceneForge 2026.10.29.2 — scene analysis and Google sign-in

This is a small update for the existing Windows v2 baseline (and the first desktop patch). Models, installed Python and user projects are retained.

## Verified source-video regression

On the user-provided 48.084042-second video, ContentDetector already finds cuts at 8, 16, 24, 32 and 40 seconds. The full CPU pipeline previously failed while sampling the final scene: container/audio duration extends beyond the last picture, and a rounded seek read past the last proxy frame. Bound proxy and original-image sampling by the actual available video frames, while preserving full source duration and audio timing. Source video is unchanged.

The real local application, actual source-node DOM button, and actual CPU worker now complete six scenes. Regression also covers old one-scene measurements without detector provenance, repeated clicks without duplicate uploads, explicit re-detect applying boundaries, and blocked video generation. See checks/scene-source-check.json. The original user video is not included in this public source archive.

Old unmarked measurements are refreshed on the next Analyze click. Complete current measurements are reused. Explicit re-detect runs the CPU path and applies the result rather than leaving a separate unapplied result. A paused/failed CPU job exposes its actual error and a resume action. Changing detected scene boundaries archives the prior scene data and invalidates semantic results for the old boundaries; the edited timeline is untouched.

## Honest image/video states

An available source image is labelled “Khung gốc · chưa duyệt”, not counted as a generated image. Video slots without clips have no image thumbnail pretending to be generated video. Before frame approval they show “Chờ duyệt khung”. Generation also checks approval before opening provider preflight. Existing provider and stale-input guards remain.

## Google sign-in transport

Google Gemini Chat and Flow login now open installed Chrome/Edge with a dedicated isolated profile, launched directly as a normal browser process. No automation is attached while the user enters credentials. Only the user's Save action connects via loopback CDP to read the session; cookies are imported into the existing encrypted vault, not sent to frontend. Normal personal browser profiles are neither read nor modified. Cancel/close terminates only this owned browser and removes its temporary profile. No anti-detection flags, fake user agent, CAPTCHA solving or automatic sign-in retries were added.

Browser launch, deferred connection, synthetic-cookie read and cleanup are tested. Successful real Google account authentication and online image/video generation are NOT verified. Google can still reject an account/browser/device or require user verification. Installing Chrome/Edge is required if neither is present.

## Build and check

1. Rebuild frontend: `python scripts/demo-web/build.py`.
2. `python -m local_engine.check_gemini_chat_routes` (SDK fixture, no real generation).
3. `python local_engine/check_google_login.py` (installed-browser lifecycle and synthetic session only).
4. For a private matching video: `python local_engine/check_scene_source_ui.py --source /path/to/video.mp4 --output /path/to/report.json`. This regression expects the six known boundaries above; it does not upload that video anywhere.
5. Windows: build_desktop.py, then build_patch.py; check_desktop_patch.ps1 tests installed GUI, actual source button/ASR/OCR, six-cut video with longer audio, native browser login transport without a real account, export, close, update and uninstall.

The old full-installer build script is still the v2 baseline. Deliver the baseline plus this small patch; do not describe it as a newly rebuilt complete installer.
