# Frame node: one-click execution and original-size downloads — 29/10/2026

Patch: 2026.10.29.6, cumulative update for the verified Windows v2 baseline, including prior v1–v5 fixes. No model/runtime reinstall or account reconnection.

## User-reported problems

Node Retry opened the generic provider setup dialog, then a separate prepared-request confirmation. Repeating this for every frame added unnecessary clicks. Partial nodes also hid Create whenever any other frame was already available. Finally, Gemini's worker explicitly called `GeneratedImage.save(full_size=False)`, selecting the SDK's 1024 preview download path even when the prompt requested 1080×1920.

## Changes

- Clicking Create/Retry on a frame is now the send action. The shared validated prompt writer, account preflight, durable intent, dispatch, polling and import execute automatically; no generic provider dialog or second confirmation is opened from this path. The separate AI-direct utility retains its explicit provider setup; video dispatch is unchanged.
- A header button, `Tạo lại N khung`, creates new versions for all eligible frames in that node, including already approved images. Older versions stay stored. In-flight or ambiguous slots are excluded from the count and never resent.
- Frame-node runs show the current scene/stage and completed count, import results as they arrive, and expose Stop Sending More. A pause does not erase the already submitted request. Account/reference changes, stale manual prompts or provider failure stop new sends; a known failed receipt can be retried by a subsequent explicit click. Unknown receipts remain read-only.
- A partial node displays Create for missing frames alongside Approve for available ones. Existing approval is not performed automatically by a node rerun.
- The shared Gemini worker now requests `full_size=True`. The pinned SDK first tries its original-download RPC and redirect chain; when unavailable it uses the large-image URL variant. Neither branch generates a second image. The original downloaded bytes are preserved.
- Frame tiles display their actual original-file dimensions; below-HD warnings also state the measured size. Prompt text is not treated as evidence of output dimensions. No resizing, upscaling or fabricated HD certification is introduced.

## Validation

Actual-browser service fixtures cover one-click inspector retry, whole-node rerun, stop before the next scene, failure followed by an explicit retry, partial-node controls, unchanged role binding/manual protection and actual file import. Both reference-video and photo automation suites run; the download change applies to Gemini images from both workflows. Only the reference-video frame-node controls changed.

Actual pinned SDK save code is tested with synthetic HTTP/RPC responses for the original-download path and large-URL fallback. Downloaded bytes match exactly. A separate CPU measurement checks 572×1024 vs 1080×1920, below-HD approval refusal, size warnings and unchanged image hashes. Project-chat and runtime safety checks remain in place.

The Windows release gate checks the installed SDK worker plus native startup, CPU/speech/export, extension transport, updating without data loss, closing and uninstall behavior. No live Google generation is used in these tests. Actual maximum image dimensions still depend on Gemini/account/model; 1080×1920 in a prompt cannot guarantee that exact output. Existing small images are preserved; this fixes downloads for new requests.
