# Google account connections: shared or separate — 29/10/2026

Patch 2026.10.29.7, extension 1.1.0 / pairing protocol 2. Cumulative small update for the verified Windows v2 baseline and earlier patches. Existing accounts, projects, models and frame-generation changes remain.

## Behavior

A connection dialog defaults to requesting Gemini Chat and Flow in one user-issued code. The checkbox can be cleared to connect only the chosen service. Both Accounts and the source panels of the reference-video and photo workspaces show the selected name and session readiness for each service, with direct actions for a joint connection or separate Chat/Flow connections. Account selection is global to the app; already accepted tasks keep their pinned account plan.

The extension reads only the requested Google/Gemini/Labs cookies when the user presses Connect and sends them to the existing guarded loopback bridge. The backend filters each service's domain scope again, verifies each independently and selects the exact imported account for new work. Flow import now returns its actual imported engine account ID, then checks that account; it never guesses from a one-row inventory. A partial result names which service succeeded and which failed, retaining the other service's existing selection. There is no generation, quota purchase, paid fallback or automatic pairing replay.

A small encrypted association records successful two-service pairings by both provider account IDs and the Flow engine instance. The UI marks a shared pairing only when the currently selected, eligible accounts match that association and engine. Choosing another account or enabling account balancing does not silently change the other service. Existing separate accounts are not merged by name, cookie similarity or row count.

If Flow already knows the account, the owned engine resolves the incoming browser session's actual identity through the provider and refreshes only that exact existing active row. Unknown identities and busy accounts refuse mutation. Reconnection preserves existing concurrency settings and does not auto-enable a disabled account. New accounts retain the normal initial limits.

A shared browser transfer is not proof that two websites are using the same Google email. With multiple signed-in Google accounts, the user should check the active account on Gemini and Flow. Gemini's app label remains user supplied; Flow's name comes from the provider inventory. No email identity is fabricated.

## Extension update

The extension ID, public manifest key, host permissions and no-background-script architecture remain unchanged. Reload the unpacked extension once in chrome://extensions or edge://extensions after updating the app. If the user loaded an independent ZIP copy, use the new folder/ZIP exposed by the app. Do not uninstall the app or reconnect accounts unnecessarily.

Legacy single-service pairings remain supported. A joint pairing requires protocol 2 acknowledgement; an older extension gets an explicit reload message before any provider import, rather than silently claiming both services were transferred. Codes still expire, are one-use and require the exact extension Origin. The new status endpoint remains inside the normal app session boundary.

## Verification

- Real app API plus actual account adapters with fixture provider I/O: combined checks/selection, domain isolation, exact Flow identity, separate connections preserving the other selection, partial success, old-extension rejection, encrypted metadata, authenticated status reads; zero content generation.
- Actual browser app: default joint dialog, Flow-only dialog, names and connection actions in both workspace source panels, cancellation and queued-dialog-close regression.
- Owned Flow ASGI extension fixtures: duplicate identity refresh, active-job and unknown-identity refusal, concurrency preservation; existing image-concurrency tests still pass.
- Windows release gate: actual unpacked extension transfers both scoped synthetic sessions and records a shared pair; installed-app API/engine checks, existing SDK/image-chat, CPU/speech/export, update preservation, close and uninstall checks.

Real Google account connectivity and generation are not certified by these fixtures. Individual services may still require their own login, access or verification even when using one Google account.
