# Windows desktop patch · 2026.10.29.1

Small self-extracting updater for the published v2 installer (baseline payload SHA-256 `8178af48a4db6180eb0fb3ef042b04ea21617c7380ca2e106d8e967990eb0c35`). It replaces application code and desktop-host files, retaining the installed Python, FFmpeg, Whisper model, engine environments, account vault and project library. The original v2 remains the base installation; this is an update, not an independent installation.

The source-video Analyze button now runs the local CPU pipeline instead of only the browser cut detector. Existing cut-only projects and CPU measurements with transcription missing can complete their missing work. Completed measurements are reused, and handwritten/imported script lines are preserved. Local processing does not automatically submit paid image/video generation. A completed transcription with zero recognized words is distinguished from transcription that never ran. Camera motion is still an OpenCV image-motion estimate; it does not reliably distinguish camera motion from moving subjects.

The new `DesktopHost.cs` is a Windows GUI executable hosting the interface in WebView2. The backend and command-line workers have no console windows. Closing the window flushes the active room and SQLite-backed library before terminating the owned backend job; if saving is blocked, it asks before discarding pending changes. A second launch focuses the same app. Provider account-login windows may open when the user requests account work; automatic Flow startup defers browser login/warmup.

WebView2 uses Microsoft's installed shared runtime. If absent, the app invokes the included Microsoft bootstrapper on first opening; that requires Internet and can download the shared runtime. SDK binaries and license accompany the desktop host. The updater is unsigned, as is the v2 base; no trusted Authenticode identity is claimed.

`apply_update.ps1` verifies every payload file, checks the recognized installation marker, stops owned app processes before replacement, backs up the old code below `updates/`, and restores replaced files if application fails. It does not delete data/model directories. It preserves the v2 installation record so Windows uninstall still works. `app-build.json` records the applied application version.

Build on Windows with Python 3.12 and the Windows .NET Framework C# compiler:

```sh
python scripts/demo-web/build.py
python scripts/windows-installer/build_desktop.py --output desktop
python scripts/windows-installer/build_patch.py --desktop desktop --output patch
```

The current WebView2 SDK is pinned in `build_desktop.py`; downloaded component hashes are recorded in `desktop-components.json`. Building a UI/code patch does not re-download models or rebuild the full 550 MB base installer.

Windows validation runs `check_desktop_patch.ps1` and `check_desktop_ui.py`. It installs the known v2 on a fresh runner, applies the actual small EXE, opens the real native window, and uses CDP only as an automation transport to press the actual source-node button. Real Whisper/OCR/camera/quality execution is checked for fresh, cut-only and partial old projects; repeated clicks must reuse completed work. It also checks MP4 export, photo-workflow loading, singleton launch, close lifecycle, and uninstall preserving user data. It does not certify online image/video generation with real accounts.

## Verified release

Windows run: https://github.com/thutrang0807hp-ux/3/actions/runs/40760213167. The actual self-extracting update EXE is 3,890,688 bytes, SHA-256 `314fdc55e31bde72b649a9c26f6a9f42cc1d501e84a580fe173ec0854f960941`. See `checks/native-desktop-check.json`. Source-button tests ran inside the real native window with real Whisper/OCR jobs; no paid-generation requests were sent. SQLite recovery across a clean browser profile was separately checked in `checks/native-storage-profile.log`.
